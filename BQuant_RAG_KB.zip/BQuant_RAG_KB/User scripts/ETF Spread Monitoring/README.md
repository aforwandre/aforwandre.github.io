# ETF Spread Monitoring

> **CRITICAL ACCOUNT-SAFETY STOP:** never request, probe, test, generate, or
> use ESG, GHG, climate, or sustainable-finance data items. A violation can
> cause the Bloomberg account to be suspended or deleted. Avoid unreviewed
> separately licensed data; if no core alternative exists, obtain Bloomberg
> HelpDesk confirmation before changing any BQL call.

BQuant Desktop validation build for historical ETF share-class bid-ask spreads,
a peer comparison, and the HSBC book taxonomy / fund-flow views. The highway is
`RAG KB/27-etf-spread-monitor.md`.

The operator selected the field set on 2026-10-22 and re-confirmed it in chat on
2026-10-24: `LEGATRUU`-style HSBC book share classes, `PX_BID` / `PX_ASK` /
`PX_MID` / `PX_LAST`, share-class taxonomy, `fund_total_assets(currency='USD')`,
`fund_class_assets()`, `fund_expense_ratio()`, `tracking_error()`,
`nav_tracking_error()`, fund flows, and benchmark
peers. The benchmark column is `long_comp_name()` of the `fund_benchmark_prim` index id. This remains a **validation run**: entitlement, units, and request
breadth are not proven until the first Desktop run is recorded.

## Files to copy into BQuant

```text
MAIN.ipynb
etf_spread/
  __init__.py
  app.py
  book_view.py
  cache.py
  data.py
  engine.py
  flow_view.py
  metrics.py
  peers.py
```

Copy `config.py` and `peer_map.py` only when the Desktop project does not
already have the live book and the live peer list. The copies in this folder
still hold three dummy lines each. Do not paste them over a book that is
already typed.

Copy the Python files, then `MAIN.ipynb`. Open `MAIN.ipynb`, restart the
kernel, and run the single notebook cell. The app does not query Bloomberg
until **Refresh** is clicked. Do not copy `tests/` or `upload/` into the
Desktop project.

`upload/` is the hand-copy staging folder. Each `*.py.txt` is a runtime file
with the `.txt` suffix added. `upload/MAIN.ipynb.txt` is **the code for the
notebook cell to paste**, not a notebook JSON file. Do not copy
`upload/etf_spread/config.py.txt` over a Desktop `config.py` that already has
the typed book. The staged config still holds the three dummy `IsinEntry`
lines. Do not copy `upload/etf_spread/peer_map.py.txt` over a Desktop
`peer_map.py` that already has the live peer list. The staged map still holds
the three dummy `PeerMapEntry` lines.

## Book config

`etf_spread/config.py` holds `ISIN_BOOK`, one line per share class:

```python
IsinEntry("Fund name", "IE00XXXXXXXXXX", "HSAX LN Equity", "1", "Equity")
```

- `fund_name`: repeat the same exact fund name on every share class of that fund.
- `isin`: the share-class ISIN.
- `ticker`: the listing yellow key used for quotes and history.
- `order`: the table order.
- `strategy`: the Strategy text read by the top dropdown and the fund menu. It is not a BQL predicate and it is not a table column.

`SHARE_CLASSES` is the legacy placeholder sample; the live screen reads
`ISIN_BOOK` only. `share_class_id` stays the legacy placeholder key.

## What the app does

- **HSBC ETF tab.** Exactly the typed `ISIN_BOOK` rows, in typed order. A linked share class that is not typed is not shown, and a typed row is never swapped for another class of that fund. Above the tabs: Strategy
  and Refresh. On the tab: Spread, Return, NAV Return, and Peers only
  or HSBC + Peers. There is no Primary Share only checkbox. Period buttons and Custom redraw the cache. Return percent
  is the USD total-return index, `(end / start - 1) * 100`, on that row's
  quote dates. A London holiday uses the last print on or before the HSBC
  quote. When Return is on, each selected period also shows `Bmk Return %`.
  Clicking a data cell plots the cached series under the table.
- **Flows tab.** Refresh loads the heatmap. Both show modes are one line per
  fund name. HSBC + Peers adds the peer funds' flows onto that line. 1M and
  3M sum by week. Longer periods sum by month. Rows follow the typed
  IsinEntry order, the same order as the HSBC ETF tab.
- **Peers Details tab.** The peer list is the manual map for the selected
  fund name. There is no Search button and no 200-name cap. The screen says
  Top 5 Peers; the code does not cut the list. HSBC anchor rows keep the
  typed IsinEntry order, and each fund's peers sit under their anchor.
  Spread and Return follow the
  HSBC ETF choices.

The spread is `PX_ASK - PX_BID` (the operator corrected the earlier direction on
2026-10-22). Spread % is `(PX_ASK - PX_BID) / PX_MID * 100` because the header
already says percent. A blank PX_MID is (PX_BID + PX_ASK) / 2 on every spread-percent path. Return does not use PX_MID. A peer
row's Latest Spread % reads that mid from the quote history. Daily values are computed first. Window columns are the percent average only; the absolute period average is not calculated. Window averages are the
mean of those daily values. Data-as-of is the last completed weekday on a
Monday-to-Friday schedule; one-off exchange holidays are not filtered, and a
weekday with no quote carries the previous bid/ask/mid, so funds with different
market holidays stay aligned. Fund AUM is a separate full-dollar request divided by one
million; class AUM is already in millions (non-USD converted by `{CCY}USD` /
`USD{CCY}`). The expense ratio stays on the vendor scale (0.09 stays 0.09). Both
tracking-error numbers are converted to percent (vendor value x100) and shown
as `1Y Tracking Error (%)` / `1Y NAV Tracking Error (%)`. Return uses the
gross total-return index in USD, not PX_LAST. NAV Return uses
`fund_net_asset_val()` in USD and the same percent formula. The NAV table and the NAV chart use that same Bmk Return column. There is no separate benchmark NAV return, and the benchmark index is not on the NAV request. The latest quote
columns are `Latest Spread` and `Latest Spread %`. Fund Info, to the left of
the period buttons, starts open and hides Class Name, ISIN, Currency, Class
AUM, PX_LAST, PX_BID, PX_ASK, Benchmark, and Primary when closed.
On Peers Details, Peer Avg stays on the HSBC row. A peer row shows its own
last, assets, tracking error, benchmark, and benchmark return.
That HSBC row is bold, and its fund-name cell is tinted.
Missing or crossed quotes stay blank; nothing is zero-filled. On screen,
price columns (`PX_LAST`, `PX_BID`, `PX_ASK`) keep their quote precision.
Spread and spread % use three decimals. Other numeric cells use two decimals.

## Metrics requests and authority

The quote, share-class, AUM, expense, tracking-error, peer, taxonomy, and flow
requests follow `RAG KB/27` and the project rule. Both tracking errors are
separate cached requests on the typed ticker: `tracking_error()['value']`
(PX_LAST based) and `nav_tracking_error()['value']` (NAV based, catalog row
`Net Asset Value Tracking Error`). The NAV item was requested by the operator on
2026-10-24 from the FLDS tab; its exact units and semantics still need the
Desktop validation record. A failed field request leaves that cell blank and does
not drop the quotes.

## History cache

`Use cache` is on by default. A quote, total-return, NAV, or fund-flow row whose
date is **older than the last completed London session** is settled: the Refresh
writes it once to `cache/` next to `MAIN.ipynb` and serves it from disk on every
later run, so a daily Refresh asks Bloomberg only for the missing days. The
assumption is that a settled print is not back-dated. Uncheck `Use cache` to
request the full window again; that run writes nothing.

- The stored frame is the **raw request output** (`Bid`/`Ask`/`Mid`, `Level`,
  `Flow`) in USD as Bloomberg returned it. `Spread`, `Percent Spread`, the flow
  total-return percent, and the `/ 1e6` flow scaling are computed **after** the
  merge, so a formula change still applies on the next Refresh.
- **Changing the book or the peer list needs no cache action.** The unit is one
  `(ID, DATE)` row and coverage is tracked per identifier, so a share class or
  peer added later has no stored head and gets its own full-window request on
  that Refresh; a removed one is simply no longer requested or shown, and its
  rows stay on disk. A changed ticker is a new identifier and is requested
  again. There is nothing to clear by hand.
- **A ticker that now points at a different security is not reused.** A fund
  re-pointed to another share class, a peer whose primary listing moved, or a
  reused ticker keeps the same string, so nothing above would notice. Each
  identifier is therefore filed in `manifest.json` with the **ISIN** this run
  resolved (`data.share_class_identities()`, taken from the book directory and
  the peer link frame, so it costs no request). If the ISIN changed, that
  identifier's stored rows are dropped and its **whole** window is requested
  again, and the status detail names it: `N identifier(s) now resolve to a
  different security (...)`. Proving a change needs both sides, so an
  identifier with no ISIN on one side — a benchmark index, or a run where the
  profile pull failed — keeps its stored rows rather than being re-pulled
  blindly.
- **Changing what is requested discards the cache automatically.** Three tokens
  must match, or the file is ignored and the window is requested again:
  `SERIES_CONTRACT` (the stored column set), `CACHE_GENERATION` (a manual token
  for "same columns, wrong stored row"), and the **request fingerprint** — a
  hash of the executable source of the four builders plus the date helper and
  the response combiner, recorded per file by `manifest.json`. Editing an item,
  a parameter such as `fill` or `currency`, or a date argument therefore makes
  the old rows unusable instead of replaying them under new code. A comment or
  docstring edit does not move that hash.
- A stored file is used only when those tokens match the file's `manifest.json`.
  A missing, unreadable, mislabelled, or all-blank file reads as "no cache" and
  is simply requested again. A write failure is a note in the status line and
  never fails the Refresh. The folder is created only by a write.
- A gap is requested with absolute dates. The five-year preset stays the frozen
  relative range only when a fund has no stored history at all; with a stored
  head, the missing older part is asked for by date.
- The answer is **trimmed to the window the Refresh asked for**, so a `1Y` run
  after a `5Y` run does not answer with five years. The cache may be wider than
  the answer; the answer is never wider than the request.
- Rows on or after the last completed session are never written, because that
  print can still move. The tail of the window is therefore re-requested on
  every run (one to three days).
- To rebuild from scratch, delete `cache/` or uncheck `Use cache`.
- The folder grows: rows of a share class or peer that left the book are kept,
  because a narrower Strategy selection must not delete another Strategy's
  history. Nothing prunes them today.


## Local checks

From this folder, run:

```bash
python3 -m unittest discover -s tests -v
```

The suite uses synthetic pandas frames and a fake `bql` module; it never executes
a Bloomberg request. `upload/` is refreshed from the runtime files after every
code change.
