"""ETF and share-class list for ETF Spread Monitoring.

Replace the sample rows with the live book. ``share_class_id`` is the book
key. ``listing_ticker`` is display text until route card 27 approves a
pricing identity. This module does not name a data item.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


PERIOD_KEYS = ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y", "Custom")
DEFAULT_PERIOD = "1Y"

# Mon–Fri sessions. Long enough for the 5Y preset. Not an exchange calendar.
HISTORY_BUSINESS_DAYS = 1400

BOOK_SOURCE = "placeholder"
PEER_SOURCE = "placeholder"

OBSERVATION_COLUMNS = (
    "Share Class ID",
    "Peer Group ID",
    "DATE",
    "Bid",
    "Ask",
    "Source",
    "Series",
)


@dataclass(frozen=True)
class ShareClass:
    share_class_id: str
    etf_id: str
    label: str
    listing_ticker: str
    currency: str
    peer_group_id: str
    enabled: bool = True


# Samples only. They are not the 54-ETF book.
SHARE_CLASSES = (
    ShareClass(
        "SAMPLE-A",
        "SAMPLE-ETF-1",
        "Sample ETF 1 USD",
        "SAMPLE1 US Equity",
        "USD",
        "SAMPLE-PEER-1",
    ),
    ShareClass(
        "SAMPLE-B",
        "SAMPLE-ETF-1",
        "Sample ETF 1 HKD",
        "SAMPLE1 HK Equity",
        "HKD",
        "SAMPLE-PEER-1",
    ),
    ShareClass(
        "SAMPLE-C",
        "SAMPLE-ETF-2",
        "Sample ETF 2 USD",
        "SAMPLE2 US Equity",
        "USD",
        "SAMPLE-PEER-2",
    ),
    ShareClass(
        "SAMPLE-OFF",
        "SAMPLE-ETF-9",
        "Sample disabled line",
        "SAMPLE9 US Equity",
        "USD",
        "SAMPLE-PEER-2",
        False,
    ),
)


def enabled_share_classes() -> tuple[ShareClass, ...]:
    return tuple(row for row in SHARE_CLASSES if row.enabled)


@dataclass(frozen=True)
class IsinEntry:
    """The primary share class of one ETF.

    One line per fund. ``fund_name`` is that ETF. ``isin`` and ``ticker``
    are its primary share class, for example ``HSAX LN Equity``. ``order``
    is the table position, for example ``1``. ``strategy`` replaces the
    Strategy column, for example ``Equity``.
    """

    fund_name: str
    isin: str
    ticker: str
    order: str
    strategy: str


# One primary share class per fund, inside the parentheses.
# IsinEntry("Fund name", "IE00XXXXXXXXXX", "HSAX LN Equity", "1", "Equity"),
ISIN_BOOK: tuple[IsinEntry, ...] = (
    IsinEntry("DUMMY HSBC ETF ONE", "IE00DUMMY00001", "DUM1 LN Equity", "1", "Equity"),
    IsinEntry(
        "DUMMY HSBC ETF TWO", "IE00DUMMY00003", "DUM3 LN Equity", "2", "Fixed Income"
    ),
)


def isin_book_frame() -> pd.DataFrame:
    rows = ISIN_BOOK
    return pd.DataFrame(
        {
            "Fund Name": [row.fund_name.strip() for row in rows],
            "ISIN": [row.isin.strip().upper() for row in rows],
            "Ticker": [row.ticker.strip() for row in rows],
            "Order": [str(row.order).strip() for row in rows],
            "Strategy": [str(row.strategy).strip() for row in rows],
        }
    )


def share_class_directory() -> pd.DataFrame:
    rows = enabled_share_classes()
    return pd.DataFrame(
        {
            "Share Class ID": [row.share_class_id for row in rows],
            "ETF ID": [row.etf_id for row in rows],
            "Label": [row.label for row in rows],
            "Listing Ticker": [row.listing_ticker for row in rows],
            "Currency": [row.currency for row in rows],
            "Peer Group ID": [row.peer_group_id for row in rows],
        }
    )
