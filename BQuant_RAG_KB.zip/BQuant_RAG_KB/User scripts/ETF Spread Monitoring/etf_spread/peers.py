"""Peer comparison table. No request is built here."""

from __future__ import annotations

import pandas as pd

from .book_view import (
    AVERAGE_PERIODS,
    absolute_quote_spread,
    clean_market_text,
    history_averages,
    last_completed_london_day,
    percent_quote_spread,
    resolved_mid,
    preferred_long_name,
)
from .metrics import return_percents
from .peer_map import fund_name_key

PEER_COLUMNS = (
    "Role",
    "Name",
    "Share Class",
    "ISIN",
    "Ticker",
    "Currency",
    "Fund AUM (USD mn)",
    "Expense Ratio",
    "NAV Tracking Error",
    "Tracking Error",
    "Last",
    "Bid",
    "Ask",
    "Absolute Spread",
    "Percent Spread",
)


def _shown_text(value) -> str:
    return clean_market_text(value)


def selected_book_fields(row) -> dict[str, object]:
    """Identity for the Selected peer row, taken from the book already loaded.

    The share-class directory stores the listing ``Name``. The displayed book
    stores ``Fund Name``. A blank listing name uses the fund name. This does
    not send another request.
    """
    name = _shown_text(row.get("Name")) or _shown_text(row.get("Fund Name"))
    share_class = _shown_text(row.get("Share Class"))
    currency = _shown_text(row.get("Currency"))
    return {
        "Name": name or pd.NA,
        "Share Class": share_class or pd.NA,
        "Currency": currency or pd.NA,
    }


def fund_choices(book: pd.DataFrame | None) -> list[str]:
    """Fund names in book order. The same name is listed once."""
    if book is None or book.empty or "Fund Name" not in book.columns:
        return []
    seen: list[str] = []
    for value in book["Fund Name"].tolist():
        text = clean_market_text(value)
        if not text or text in seen:
            continue
        seen.append(text)
    return seen


def primary_ticker(frame: pd.DataFrame | None, fund_name: str) -> str:
    """Typed ticker of the Primary Yes row. Another class is not a substitute."""
    if frame is None or frame.empty or not fund_name:
        return ""
    needed = {"Fund Name", "Primary", "Ticker"}
    if not needed.issubset(frame.columns):
        return ""
    rows = frame.loc[frame["Fund Name"].astype(str).str.strip().eq(str(fund_name).strip())]
    yes = rows.loc[rows["Primary"].astype(str).str.strip().eq("Yes")]
    if yes.empty:
        return ""
    ticker = str(yes["Ticker"].iloc[0]).strip()
    if ticker.lower() in {"", "nan", "none", "<na>"}:
        return ""
    return ticker


def primary_isin(frame: pd.DataFrame | None, fund_name: str) -> str:
    """Typed ISIN of the Primary Yes row. Another class is not a substitute."""
    if frame is None or frame.empty or not fund_name:
        return ""
    needed = {"Fund Name", "Primary", "ISIN"}
    if not needed.issubset(frame.columns):
        return ""
    rows = frame.loc[frame["Fund Name"].astype(str).str.strip().eq(str(fund_name).strip())]
    yes = rows.loc[rows["Primary"].astype(str).str.strip().eq("Yes")]
    if yes.empty:
        return ""
    isin = str(yes["ISIN"].iloc[0]).strip().upper()
    if isin.lower() in {"", "nan", "none", "<na>"}:
        return ""
    return isin


def peer_columns(selected: list[str] | None, mode: str = "Spread") -> list[str]:
    """Base columns plus the period columns for Spread or Return."""
    chosen = set(selected or [])
    columns = list(PEER_COLUMNS)
    for period in AVERAGE_PERIODS:
        if period not in chosen:
            continue
        if str(mode) == "Return":
            columns.append(f"{period} Return %")
        else:
            columns.append(f"{period} Avg Spread %")
    return columns


def peer_view(
    snapshot: pd.DataFrame | None,
    history: pd.DataFrame | None,
    selected: list[str] | None,
    mode: str = "Spread",
    returns: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Selected primary first, then peers. Period columns come from the cache."""
    if snapshot is None or snapshot.empty:
        return pd.DataFrame(columns=peer_columns(selected, mode))
    frame = snapshot.copy()
    for column in PEER_COLUMNS:
        if column not in frame.columns:
            frame[column] = pd.NA
    if {"Bid", "Ask"}.issubset(frame.columns):
        frame["Mid"] = resolved_mid(
            frame["Bid"],
            frame["Ask"],
            frame["Mid"] if "Mid" in frame.columns else None,
        )
        frame["Absolute Spread"] = absolute_quote_spread(frame["Bid"], frame["Ask"])
        frame["Percent Spread"] = percent_quote_spread(frame["Absolute Spread"], frame["Mid"])
    frame = frame.drop(
        columns=[
            column
            for column in frame.columns
            if column.endswith(" Avg Spread") or column.endswith(" Avg Spread %") or column.endswith(" Return %")
        ],
        errors="ignore",
    )
    if str(mode) == "Return":
        percents = return_percents(returns, last_completed_london_day())
        if not percents.empty and "Ticker" in frame.columns:
            frame = frame.merge(percents, left_on="Ticker", right_on="ID", how="left")
            frame = frame.drop(columns=["ID"], errors="ignore")
        chosen = set(selected or [])
        for period in AVERAGE_PERIODS:
            column = f"{period} Return %"
            if period in chosen and column not in frame.columns:
                frame[column] = pd.NA
    else:
        averages = history_averages(history, last_completed_london_day())
        if not averages.empty and "Ticker" in frame.columns:
            frame = frame.merge(averages, left_on="Ticker", right_on="ID", how="left")
            frame = frame.drop(columns=["ID"], errors="ignore")
    frame["_role"] = frame["Role"].astype(str).str.strip().ne("Selected")
    frame = frame.sort_values(["_role", "Name"], kind="mergesort", na_position="last")
    frame = frame.drop(columns=["_role"])
    columns = [column for column in peer_columns(selected, mode) if column in frame.columns]
    return frame.loc[:, columns].reset_index(drop=True)


def funds_for_strategy(book: pd.DataFrame | None, strategy: str) -> list[str]:
    """All, then the fund names that use this typed Strategy.

    An empty strategy or All keeps every fund. Names stay in book order.
    """
    if book is None or book.empty or "Fund Name" not in book.columns:
        return ["All"]
    view = book
    chosen = str(strategy or "").strip()
    if chosen and chosen != "All" and "Strategy" in view.columns:
        view = view.loc[view["Strategy"].astype(str).eq(chosen)]
    return ["All", *fund_choices(view)]


def fund_menu_options(book: pd.DataFrame | None, strategy: str) -> list[tuple[str, str]]:
    """Dropdown labels use the long name. The value stays the typed fund name."""
    names = funds_for_strategy(book, strategy)
    labels: dict[str, str] = {}
    if book is not None and not book.empty and "Fund Name" in book.columns:
        work = book.copy()
        work["_fund"] = work["Fund Name"].map(fund_name_key)
        work["_order"] = range(len(work))
        work["_primary"] = 0
        if "Primary" in work.columns:
            work["_primary"] = work["Primary"].astype(str).str.strip().eq("Yes").astype(int)
        work = work.sort_values(
            ["_fund", "_primary", "_order"],
            ascending=[True, False, True],
            kind="mergesort",
        )
        for _, row in work.iterrows():
            key = row["_fund"]
            if not key or key in labels:
                continue
            labels[key] = preferred_long_name(row.get("Long Name"), row.get("Fund Name")) or key
    options = []
    for name in names:
        if name == "All":
            options.append(("All", "All"))
            continue
        label = labels.get(fund_name_key(name), name) or name
        options.append((label, name))
    return options


FUND_INFO_GROUP = "Fund Info"
FUND_INFO_COLUMNS = (
    "Share Class",
    "ISIN",
    "Currency",
    "Share Class AUM (USD mn)",
    "Last",
    "Bid",
    "Ask",
    "Benchmark",
    "Primary",
)


def visible_with_groups(columns, collapsed) -> list[str]:
    """Drop a closed period's metric columns, and Fund Info when that group is closed.

    Fund Info starts open. Its columns stay in the frame until the operator
    closes that group. That group includes Benchmark and Primary.
    Fund Name and Fund AUM are not in the group. Strategy is not a column:
    the typed text only drives the top dropdown and the fund menu.
    """
    hidden = {str(period) for period in (collapsed or []) if str(period)}
    hide_info = FUND_INFO_GROUP in hidden
    if not hidden:
        return list(columns)
    kept = []
    for column in columns:
        text = str(column)
        if hide_info and text in FUND_INFO_COLUMNS:
            continue
        period = text.split(" ", 1)[0]
        metric = (
            " Avg Spread" in text
            or text.endswith(" Return %")
            or "Peer Avg" in text
            or "Bmk Return" in text
        )
        if metric and period in hidden:
            continue
        kept.append(column)
    return kept


def _ticker_key(value) -> str:
    return clean_market_text(value).upper()


def _latest_quotes(history: pd.DataFrame | None) -> dict[str, pd.Series]:
    """Last bid, ask, and mid for each ticker. A blank date is skipped."""
    if history is None or history.empty or "ID" not in history.columns:
        return {}
    frame = history.copy()
    if "DATE" in frame.columns:
        frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
        frame = frame.dropna(subset=["DATE"]).sort_values("DATE", kind="mergesort")
    if frame.empty:
        return {}
    frame["_id"] = frame["ID"].map(_ticker_key)
    frame = frame.loc[frame["_id"].ne("")]
    if frame.empty:
        return {}
    latest = frame.groupby("_id", sort=False).tail(1)
    return {str(row["_id"]): row for _, row in latest.iterrows()}


def _by_id(frame: pd.DataFrame | None) -> dict[str, pd.Series]:
    if frame is None or frame.empty or "ID" not in frame.columns:
        return {}
    found = {}
    for _, row in frame.iterrows():
        key = _ticker_key(row.get("ID"))
        if key:
            found[key] = row
    return found


def _own_spread_column(column: str) -> bool:
    text = str(column)
    return " Avg Spread" in text and "Peer" not in text


def _own_return_column(column: str) -> bool:
    text = str(column)
    return (
        text.endswith(" Return %")
        and "Peer" not in text
        and "Bmk" not in text
        and "NAV" not in text
    )


def _own_nav_column(column: str) -> bool:
    text = str(column)
    return text.endswith(" NAV Return %") and "Peer" not in text and "Bmk" not in text


def _has_cell(value) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    try:
        return not bool(pd.isna(value))
    except (TypeError, ValueError):
        return True


def _benchmark_return_source(column: str) -> str:
    """Map ``Bmk Return %`` to the total-return percent of that index."""
    text = str(column)
    if "Peer" in text or "NAV" in text:
        return ""
    if text.endswith(" Bmk Return %"):
        return text.replace(" Bmk Return %", " Return %")
    return ""


_PEER_FACT_FIELDS = (
    "Last",
    "Fund AUM (USD mn)",
    "Share Class AUM (USD mn)",
    "Tracking Error",
    "NAV Tracking Error",
    "Benchmark",
    "Benchmark Index",
)


def _facts_by_ticker(facts: pd.DataFrame | None) -> dict[str, pd.Series]:
    if facts is None or facts.empty or "Ticker" not in facts.columns:
        return {}
    found = {}
    for _, row in facts.iterrows():
        key = _ticker_key(row.get("Ticker"))
        if key:
            found[key] = row
    return found


def _apply_peer_facts(row: dict, fact: pd.Series | None) -> None:
    if fact is None:
        return
    for column in _PEER_FACT_FIELDS:
        if column not in row:
            continue
        value = fact.get(column)
        if _has_cell(value):
            row[column] = value


def _apply_peer_benchmark_return(row: dict, columns, percents, nav_percents) -> None:
    """The peer's own total-return benchmark. Peer Avg stays untouched."""
    _ = nav_percents
    index_key = _ticker_key(row.get("Benchmark Index"))
    if not index_key:
        return
    for column in columns:
        source = _benchmark_return_source(column)
        if not source:
            continue
        series = percents.get(index_key)
        if series is None or source not in getattr(series, "index", []):
            continue
        value = series.get(source)
        if _has_cell(value):
            row[column] = value


def _nav_percent_frame(levels: pd.DataFrame | None, as_of, custom_start, custom_end) -> pd.DataFrame:
    """Same percent columns as total return, named for NAV."""
    frame = return_percents(levels, as_of, custom_start, custom_end)
    renamed = {
        column: str(column).replace(" Return %", " NAV Return %")
        for column in frame.columns
        if str(column).endswith(" Return %")
    }
    return frame.rename(columns=renamed)


def peer_detail_rows(
    hsbc: pd.DataFrame | None,
    links: pd.DataFrame | None,
    quote_history: pd.DataFrame | None,
    return_history: pd.DataFrame | None,
    custom_start=None,
    custom_end=None,
    nav_history: pd.DataFrame | None = None,
    facts: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Each primary HSBC row, then that fund's primary peers.

    A peer's own spread and return come from the history already loaded.
    Peer-average cells stay blank on a peer row. Last, assets, tracking
    error, strategy, and the benchmark name come from ``facts`` when that
    frame has them. Bmk Return uses that peer's own benchmark. This does
    not send a request.
    """
    if hsbc is None or hsbc.empty:
        return pd.DataFrame() if hsbc is None else hsbc.iloc[0:0].copy()
    columns = list(hsbc.columns)
    if "HSBC Fund" not in columns:
        columns.append("HSBC Fund")
    links_by_fund: dict[str, list[pd.Series]] = {}
    if links is not None and not links.empty and "Fund Name" in links.columns:
        for _, link in links.iterrows():
            fund = fund_name_key(link.get("Fund Name"))
            if fund:
                links_by_fund.setdefault(fund, []).append(link)
    as_of = last_completed_london_day()
    averages = _by_id(history_averages(quote_history, as_of, custom_start, custom_end))
    percents = _by_id(return_percents(return_history, as_of, custom_start, custom_end))
    nav_percents = _by_id(_nav_percent_frame(nav_history, as_of, custom_start, custom_end))
    latest = _latest_quotes(quote_history)
    fact_rows = _facts_by_ticker(facts)
    grouped: list[tuple[str, list[pd.Series]]] = []
    position: dict[str, int] = {}
    for _, record in hsbc.iterrows():
        fund = fund_name_key(record.get("Fund Name"))
        if fund not in position:
            position[fund] = len(grouped)
            grouped.append((fund, []))
        grouped[position[fund]][1].append(record)
    rows: list[dict[str, object]] = []
    for fund, records in grouped:
        for record in records:
            rows.append({column: record.get(column, pd.NA) for column in columns})
            rows[-1]["HSBC Fund"] = fund
        for link in links_by_fund.get(fund, []):
            ticker = clean_market_text(link.get("Ticker"))
            key = ticker.upper()
            if not key:
                continue
            row = {column: pd.NA for column in columns}
            name = preferred_long_name(link.get("Long Name"), link.get("Name")) or ticker
            if "Fund Name" in row:
                row["Fund Name"] = name
            if "Long Name" in row:
                row["Long Name"] = name
            if "Share Class" in row:
                row["Share Class"] = clean_market_text(link.get("Share Class")) or pd.NA
            if "ISIN" in row:
                isin = clean_market_text(link.get("Primary ISIN")) or clean_market_text(link.get("ISIN"))
                row["ISIN"] = isin or pd.NA
            if "Currency" in row:
                row["Currency"] = clean_market_text(link.get("Currency")) or pd.NA
            if "Primary" in row:
                row["Primary"] = "Yes"
            if "Ticker" in row:
                row["Ticker"] = ticker
            row["HSBC Fund"] = fund
            quote = latest.get(key)
            if quote is not None:
                for column in ("Bid", "Ask", "Mid"):
                    if column in row and column in quote.index:
                        row[column] = quote.get(column)
                if "Bid" in row and "Ask" in row:
                    spread = absolute_quote_spread(pd.Series([row["Bid"]]), pd.Series([row["Ask"]]))
                    if "Absolute Spread" in row:
                        row["Absolute Spread"] = spread.iloc[0]
                    if "Percent Spread" in row:
                        quoted_mid = quote.get("Mid") if "Mid" in quote.index else pd.NA
                        mid = resolved_mid(row.get("Bid"), row.get("Ask"), quoted_mid)
                        row["Percent Spread"] = percent_quote_spread(spread, mid).iloc[0]
            averaged = averages.get(key)
            if averaged is not None:
                for column in columns:
                    if _own_spread_column(column) and column in averaged.index:
                        row[column] = averaged.get(column)
            returned = percents.get(key)
            if returned is not None:
                for column in columns:
                    if _own_return_column(column) and column in returned.index:
                        row[column] = returned.get(column)
            nav_returned = nav_percents.get(key)
            if nav_returned is not None:
                for column in columns:
                    if _own_nav_column(column) and column in nav_returned.index:
                        row[column] = nav_returned.get(column)
            _apply_peer_facts(row, fact_rows.get(key))
            _apply_peer_benchmark_return(row, columns, percents, nav_percents)
            rows.append(row)
    return pd.DataFrame(rows, columns=columns)
