"""Fund-flow heatmap. No request is built here."""

from __future__ import annotations

import pandas as pd

from .book_view import london_period_bounds, preferred_long_name
from .peer_map import fund_name_key

FLOW_PERIODS = ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y")
FLOW_GROUPS = ("Strategy",)
WEEKLY_PERIODS = {"1M", "3M"}


def _sum_present(values: pd.Series):
    """Sum of real numbers. An all-blank bucket stays blank, not zero."""
    numeric = pd.to_numeric(values, errors="coerce")
    if int(numeric.notna().sum()) == 0:
        return pd.NA
    return float(numeric.sum())


def heatmap_size(labels) -> tuple[int, int]:
    """Figure height and left margin so every fund name stays on its own row.

    Height grows by a fixed amount per row. The left margin grows with the
    longest name. Neither side squeezes a later row off the axis.
    """
    names = ["" if label is None else str(label) for label in labels]
    rows = max(len(names), 1)
    height = 72 + 28 * rows
    longest = max((len(name) for name in names), default=8)
    left = min(720, max(160, longest * 7 + 36))
    return height, left


def flow_bucket(period: str) -> str:
    """Week for the two short windows. Calendar month after that.

    A one-month window drawn as one column is not a heatmap, so 1M and 3M
    use weeks. 6M through 5Y use months so a five-year grid stays readable.
    """
    return "W-FRI" if str(period).strip() in WEEKLY_PERIODS else "M"


def _book_tickers(book: pd.DataFrame | None) -> set[str]:
    if book is None or book.empty or "Ticker" not in book.columns:
        return set()
    keys = book["Ticker"].fillna("").astype(str).str.strip().str.upper()
    return {key for key in keys if key and key not in {"NAN", "NONE", "<NA>"}}


def _ticker_groups(book: pd.DataFrame, group: str) -> pd.DataFrame:
    """One group per ticker. A repeated ticker is not a second flow."""
    columns = ["ID_KEY", "Category"]
    if book is None or book.empty or "Ticker" not in book.columns or group not in book.columns:
        return pd.DataFrame(columns=columns)
    work = book.loc[:, ["Ticker", group]].copy()
    work["ID_KEY"] = work["Ticker"].fillna("").astype(str).str.strip().str.upper()
    work["Category"] = work[group].fillna("").astype(str).str.strip()
    work = work.loc[~work["ID_KEY"].isin({"", "NAN", "NONE", "<NA>"})]
    work = work.loc[work["Category"].ne("")]
    work = work.loc[~work["Category"].str.lower().isin({"nan", "none", "<na>"})]
    work = work.drop_duplicates("ID_KEY", keep="first")
    return work.loc[:, columns]


def flow_matrix(
    flows: pd.DataFrame | None,
    book: pd.DataFrame | None,
    group: str,
    period: str,
    as_of,
) -> tuple[pd.DataFrame, list[str]]:
    """Category by bucket. Values are the flow units already on the frame.

    The same ticker counts once. A blank category is left out. A bucket
    with no flow stays blank, not zero. Dates are filtered, not rolled
    with a business-day offset.
    """
    notes: list[str] = []
    empty = pd.DataFrame()
    key = str(period or "").strip()
    if key not in FLOW_PERIODS:
        return empty, [f"Unknown flow period: {period}."]
    if str(group) not in FLOW_GROUPS:
        return empty, [f"Unknown flow group: {group}."]
    start, end, bound_notes = london_period_bounds(key, as_of)
    notes.extend(bound_notes)
    if bound_notes or start is None or end is None:
        return empty, notes
    bucket = flow_bucket(key)
    bucket_label = "week" if bucket == "W-FRI" else "month"
    notes.append(
        f"{key}: {pd.Timestamp(start).date().isoformat()} to "
        f"{pd.Timestamp(end).date().isoformat()}, summed by {bucket_label}."
    )
    if flows is None or flows.empty:
        return empty, notes + ["No fund-flow rows yet."]
    missing = [name for name in ("ID", "DATE", "Flow") if name not in flows.columns]
    if missing:
        return empty, notes + [f"Missing columns: {', '.join(missing)}."]
    groups = _ticker_groups(book, group)
    on_book = _book_tickers(book)
    if groups.empty:
        return empty, notes + [f"No {group} is available for these tickers."]
    return _flow_from_groups(flows, groups, on_book, start, end, bucket, notes)


def fund_flow_tickers(book: pd.DataFrame | None) -> pd.DataFrame:
    """One listing ticker per fund.

    ``fund_flow`` is a fund figure. Another share class of the same fund is
    not a second flow. A Primary Yes row is the ticker that is kept.
    Otherwise the first row in book order is kept. Funds keep the book's
    first-appearance order, which is the typed IsinEntry order.
    """
    columns = ["Ticker", "ID_KEY", "Category"]
    if book is None or book.empty or "Ticker" not in book.columns:
        return pd.DataFrame(columns=columns)
    work = book.copy()
    work["Ticker"] = work["Ticker"].fillna("").astype(str).str.strip()
    work["ID_KEY"] = work["Ticker"].str.upper()
    fund = (
        work["Fund Name"].map(fund_name_key)
        if "Fund Name" in work.columns
        else pd.Series("", index=work.index)
    )
    work["_fund"] = fund
    work["Category"] = [
        fund_name or ticker
        for fund_name, ticker in zip(fund.tolist(), work["ID_KEY"].tolist())
    ]
    work["_order"] = range(len(work))
    work["_primary"] = 0
    if "Primary" in work.columns:
        work["_primary"] = work["Primary"].astype(str).str.strip().eq("Yes").astype(int)
    work = work.loc[~work["ID_KEY"].isin({"", "NAN", "NONE", "<NA>"})]
    work = work.loc[work["Category"].astype(str).str.strip().ne("")]
    categories = list(dict.fromkeys(work["Category"].tolist()))
    rank = {category: index for index, category in enumerate(categories)}
    work["_rank"] = work["Category"].map(rank)
    work = work.sort_values(
        ["_rank", "_primary", "_order"],
        ascending=[True, False, True],
        kind="mergesort",
    )
    work = work.drop_duplicates("Category", keep="first")
    return work.loc[:, columns].reset_index(drop=True)


def flow_row_labels(book: pd.DataFrame | None) -> dict[str, str]:
    """Typed fund key to the long name of the kept share class.

    The heatmap still groups on the typed fund name. Only the label changes.
    Two funds that share one long name are qualified with the typed key, so
    the heatmap keeps one row per fund instead of collapsing them.
    """
    labels: dict[str, str] = {}
    if book is None or book.empty or "Fund Name" not in book.columns:
        return labels
    work = book.copy()
    work["_fund"] = work["Fund Name"].map(fund_name_key)
    work["_order"] = range(len(work))
    work["_primary"] = 0
    if "Primary" in work.columns:
        work["_primary"] = work["Primary"].astype(str).str.strip().eq("Yes").astype(int)
    work = work.sort_values(
        ["_fund", "_primary", "_order"],
        ascending=[True, False, True],
        kind="mergesort",
    )
    for _, row in work.iterrows():
        key = row["_fund"]
        if not key or key in labels:
            continue
        labels[key] = preferred_long_name(row.get("Long Name"), row.get("Fund Name")) or key
    shared: dict[str, list[str]] = {}
    for key, label in labels.items():
        shared.setdefault(label, []).append(key)
    for label, keys in shared.items():
        if len(keys) > 1:
            for key in keys:
                labels[key] = f"{label} ({key})"
    return labels


def flow_request_tickers(book: pd.DataFrame | None, peer_tickers) -> list[str]:
    """Tickers for one fund-flow pull: one HSBC ticker per fund, then peers."""
    chosen = fund_flow_tickers(book)
    ordered: list[str] = []
    seen: set[str] = set()
    candidates = []
    if not chosen.empty:
        candidates.extend(chosen["Ticker"].tolist())
    candidates.extend(peer_tickers or [])
    for value in candidates:
        ticker = "" if value is None else str(value).strip()
        key = ticker.upper()
        if not key or key in {"NAN", "NONE", "<NA>"} or key in seen:
            continue
        seen.add(key)
        ordered.append(ticker)
    return ordered


def _hsbc_groups(book: pd.DataFrame | None) -> pd.DataFrame:
    """One HSBC ticker per fund name. Share classes of that fund are not added."""
    chosen = fund_flow_tickers(book)
    return chosen.loc[:, ["ID_KEY", "Category"]]


def _peer_groups(links: pd.DataFrame | None, book: pd.DataFrame | None) -> pd.DataFrame:
    """Every peer ticker, labeled by the HSBC fund name. The same ticker can sit in two groups."""
    columns = ["ID_KEY", "Category"]
    if links is None or links.empty or not {"Fund Name", "Ticker"}.issubset(links.columns):
        return pd.DataFrame(columns=columns)
    allowed: set[str] | None = None
    if book is not None and not book.empty and "Fund Name" in book.columns:
        allowed = {fund_name_key(value) for value in book["Fund Name"].tolist()}
        allowed.discard("")
    rows = []
    seen: set[tuple[str, str]] = set()
    for _, row in links.iterrows():
        fund = fund_name_key(row.get("Fund Name"))
        ticker = str(row.get("Ticker", "")).strip().upper()
        if not fund or not ticker or ticker in {"NAN", "NONE", "<NA>"}:
            continue
        if allowed is not None and fund not in allowed:
            continue
        key = (ticker, fund)
        if key in seen:
            continue
        seen.add(key)
        rows.append({"ID_KEY": ticker, "Category": fund})
    if not rows:
        return pd.DataFrame(columns=columns)
    return pd.DataFrame(rows, columns=columns)


def hsbc_flow_matrix(flows, book, period: str, as_of) -> tuple[pd.DataFrame, list[str]]:
    """One row per fund name, from that fund's single listing ticker."""
    notes: list[str] = []
    empty = pd.DataFrame()
    key = str(period or "").strip()
    if key not in FLOW_PERIODS:
        return empty, [f"Unknown flow period: {period}."]
    start, end, bound_notes = london_period_bounds(key, as_of)
    notes.extend(bound_notes)
    if bound_notes or start is None or end is None:
        return empty, notes
    bucket = flow_bucket(key)
    bucket_label = "week" if bucket == "W-FRI" else "month"
    notes.append(
        f"{key}: {pd.Timestamp(start).date().isoformat()} to "
        f"{pd.Timestamp(end).date().isoformat()}, summed by {bucket_label}."
    )
    groups = _hsbc_groups(book)
    if groups.empty:
        return empty, notes + ["No HSBC ETF is available."]
    return _flow_from_groups(flows, groups, set(groups["ID_KEY"]), start, end, bucket, notes)


def _hsbc_fund_groups(book: pd.DataFrame | None) -> pd.DataFrame:
    """One HSBC ticker per fund name, so peers add onto that fund once."""
    return _hsbc_groups(book)


def combined_flow_matrix(flows, links, book, period: str, as_of) -> tuple[pd.DataFrame, list[str]]:
    """One line per fund: that fund's single flow, plus its peer funds.

    Share classes of the same fund are not added. A ticker that is both an
    HSBC listing and a peer of the same fund counts once. The show mode
    only slices the cache.
    """
    notes: list[str] = []
    empty = pd.DataFrame()
    key = str(period or "").strip()
    if key not in FLOW_PERIODS:
        return empty, [f"Unknown flow period: {period}."]
    start, end, bound_notes = london_period_bounds(key, as_of)
    notes.extend(bound_notes)
    if bound_notes or start is None or end is None:
        return empty, notes
    bucket = flow_bucket(key)
    bucket_label = "week" if bucket == "W-FRI" else "month"
    notes.append(
        f"{key}: {pd.Timestamp(start).date().isoformat()} to "
        f"{pd.Timestamp(end).date().isoformat()}, summed by {bucket_label}."
    )
    peers = _peer_groups(links, book)
    hsbc = _hsbc_fund_groups(book)
    if peers.empty and hsbc.empty:
        return empty, notes + ["No HSBC ETF or Top 5 Peers group is available."]
    if peers.empty:
        notes.append("No Top 5 Peers group is available. Paste ISINs into peer_map.py and Refresh.")
    groups = pd.concat([hsbc, peers], ignore_index=True)
    groups = groups.drop_duplicates(["ID_KEY", "Category"], keep="first")
    return _flow_from_groups(flows, groups, set(groups["ID_KEY"]), start, end, bucket, notes)


def peer_group_flow_matrix(flows, links, book, period: str, as_of) -> tuple[pd.DataFrame, list[str]]:
    """One row per peer group. The value is the sum of every ticker in that list."""
    notes: list[str] = []
    empty = pd.DataFrame()
    key = str(period or "").strip()
    if key not in FLOW_PERIODS:
        return empty, [f"Unknown flow period: {period}."]
    start, end, bound_notes = london_period_bounds(key, as_of)
    notes.extend(bound_notes)
    if bound_notes or start is None or end is None:
        return empty, notes
    bucket = flow_bucket(key)
    bucket_label = "week" if bucket == "W-FRI" else "month"
    notes.append(
        f"{key}: {pd.Timestamp(start).date().isoformat()} to "
        f"{pd.Timestamp(end).date().isoformat()}, summed by {bucket_label}."
    )
    groups = _peer_groups(links, book)
    if groups.empty:
        return empty, notes + ["No Top 5 Peers group is available. Paste ISINs into peer_map.py and Refresh."]
    return _flow_from_groups(flows, groups, set(groups["ID_KEY"]), start, end, bucket, notes)


def _flow_from_groups(flows, groups, on_book, start, end, bucket, notes) -> tuple[pd.DataFrame, list[str]]:
    """Category by bucket. A blank bucket stays blank, not zero.

    Rows keep the groups order, which is the typed IsinEntry order.
    """
    empty = pd.DataFrame()
    if flows is None or getattr(flows, "empty", True):
        return empty, list(notes) + ["No fund-flow rows yet."]
    missing = [name for name in ("ID", "DATE", "Flow") if name not in flows.columns]
    if missing:
        return empty, list(notes) + [f"Missing columns: {', '.join(missing)}."]
    work = flows.loc[:, ["ID", "DATE", "Flow"]].copy()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work["Flow"] = pd.to_numeric(work["Flow"], errors="coerce")
    work["ID_KEY"] = work["ID"].fillna("").astype(str).str.strip().str.upper()
    work = work.dropna(subset=["DATE"])
    work = work.loc[~work["ID_KEY"].isin({"", "NAN", "NONE", "<NA>"})]
    work = work.sort_values("DATE", kind="mergesort")
    work = work.loc[(work["DATE"] >= start) & (work["DATE"] <= end)]
    if work.empty:
        return empty, notes + ["No fund flow inside this period."]
    known = set(groups["ID_KEY"])
    unmatched = sorted(set(work["ID_KEY"]) - on_book)
    if unmatched:
        notes.append(f"{len(unmatched)} flow tickers are not on this book.")
    work = work.loc[work["ID_KEY"].isin(known)]
    if work.empty:
        return empty, notes
    # One figure per ticker per day, then one category per ticker.
    daily = (
        work.groupby(["ID_KEY", "DATE"], sort=False)["Flow"]
        .apply(_sum_present)
        .reset_index(name="Flow")
    )
    daily = daily.merge(groups, on="ID_KEY", how="left")
    daily = daily.dropna(subset=["Flow"])
    if daily.empty:
        return empty, notes + ["Fund flow in this period is blank."]
    period_key = "W-FRI" if bucket == "W-FRI" else "M"
    daily["Bucket"] = pd.to_datetime(
        daily["DATE"].dt.to_period(period_key).dt.end_time,
        errors="coerce",
    )
    if getattr(daily["Bucket"].dt, "tz", None) is not None:
        daily["Bucket"] = daily["Bucket"].dt.tz_localize(None)
    daily["Bucket"] = daily["Bucket"].dt.normalize()
    daily.loc[daily["Bucket"] > end, "Bucket"] = end
    matrix = (
        daily.groupby(["Category", "Bucket"], sort=False)["Flow"]
        .apply(_sum_present)
        .unstack("Bucket")
    )
    # Rows follow the groups order, which is the typed IsinEntry order.
    order = [
        category
        for category in dict.fromkeys(groups["Category"].tolist())
        if category in matrix.index
    ]
    in_order = set(order)
    dropped = sorted(str(name) for name in matrix.index if name not in in_order)
    if dropped:
        notes.append(f"Flow rows left out of the book order: {', '.join(dropped)}.")
    matrix = matrix.reindex(order)
    matrix = matrix.reindex(sorted(matrix.columns), axis=1)
    return matrix, notes
