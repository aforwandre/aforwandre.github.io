"""Daily history cache for the four history requests. No request is built here.

A row is settled once its date is before the last completed session. Those
rows are written once and served from disk on the next Refresh, so a daily
run asks Bloomberg only for the missing days. The assumption is that a
settled print is not back-dated; uncheck Use cache to re-request the whole
window.

The stored frame is the raw request output, not a computed metric, so a
formula change still runs on the next Refresh. A stored file is ignored
unless the contract token, the generation token, and that kind's columns
all match. Nothing here raises on a read: an unreadable file simply reads as
"no cache" and the window is requested again. pyarrow is not required.
"""

from __future__ import annotations

import ast
import hashlib
import inspect
import json
import os
import textwrap
from pathlib import Path

import pandas as pd


CACHE_DIR_NAME = "cache"
CACHE_ENABLED = True

# Raw request columns per kind. The derived columns (Spread, Percent Spread)
# are computed after the merge, so they are not stored.
KIND_COLUMNS = {
    "quotes": ("Bid", "Ask", "Mid"),
    "returns": ("Level",),
    "navs": ("Level",),
    "flows": ("Flow",),
}
KINDS = ("quotes", "returns", "navs", "flows")

# Derived from the stored column set. Adding, removing, or renaming a stored
# column changes this token, so stale files are ignored on the next Refresh.
SERIES_CONTRACT = "|".join(
    f"{kind}:{'/'.join(columns)}" for kind, columns in KIND_COLUMNS.items()
)

# What the stored rows *mean*, not which columns they hold. Bump this when a
# stored row would be wrong under the new code but the column set looks the
# same. A bump discards every earlier file, so the next Refresh re-requests.
CACHE_GENERATION = "daily-append-1"

# The frozen five-year window is a relative range. Only the coverage check
# needs an absolute anchor, so the head of the window is read as this many
# years before the request end.
RELATIVE_YEARS = 5

# Returned when a function's source cannot be read. It is a stable string, so
# a build that cannot inspect itself keeps using its own files instead of
# invalidating them on every Refresh.
SOURCE_UNAVAILABLE = "source-unavailable"


def fingerprint(functions) -> str:
    """Token for *what the request asks*, derived from the builder source.

    The column names never change while the item behind one does: swapping
    ``px_bid`` for another price item, dropping ``fill='prev'``, or changing
    the currency leaves ``Bid`` / ``Level`` / ``Flow`` in place. The stored
    rows then look valid and a wrong number is replayed forever.

    Reading the builder source closes that hole without anyone remembering to
    bump a constant. Comments, docstrings, and formatting are removed first,
    so a comment edit does not throw a five-year series away; a change to an
    item, a parameter, or an argument name does.
    """
    parts = []
    for function in functions or ():
        parts.append(_executable_source(function))
    joined = "\n".join(parts).encode("utf-8")
    return hashlib.sha256(joined).hexdigest()[:16]


def _executable_source(function) -> str:
    try:
        source = inspect.getsource(function)
    except (OSError, TypeError):
        return SOURCE_UNAVAILABLE
    try:
        tree = ast.parse(textwrap.dedent(source))
    except SyntaxError:
        return SOURCE_UNAVAILABLE
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = list(node.body)
        if (
            body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            node.body = body[1:] or [ast.Pass()]
    try:
        return ast.unparse(tree)
    except Exception:
        return SOURCE_UNAVAILABLE


def cache_dir(root: Path | None = None) -> Path:
    """Where the series files live. Does not create it.

    ``root`` is the project folder; the folder is created only by a write, so
    a read-only project folder does not fail a Refresh that only reads.
    """
    base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    return base / CACHE_DIR_NAME


def _manifest_path(root: Path | None) -> Path:
    return cache_dir(root) / "manifest.json"


def _read_manifest(root: Path | None) -> dict:
    path = _manifest_path(root)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _usable_series(root: Path | None, fingerprint_value=None) -> dict:
    """Manifest entries that this build may serve. Anything else reads as empty.

    ``fingerprint_value`` is checked only when the caller passes one, so a
    test or a caller that does not know the request shape is not silently
    served rows built from a different request either: it records no token and
    reads back only what it wrote in the same shape.
    """
    payload = _read_manifest(root)
    if payload.get("contract") != SERIES_CONTRACT:
        return {}
    if payload.get("generation") != CACHE_GENERATION:
        return {}
    series = payload.get("series")
    if not isinstance(series, dict):
        return {}
    if fingerprint_value is None:
        return series
    usable = {}
    for kind, entry in series.items():
        if not isinstance(entry, dict):
            continue
        if entry.get("fingerprint") != fingerprint_value:
            # The request that produced these rows is not the request this
            # build sends: a different item, a different fill, a different
            # currency, or a different date argument. The columns look the
            # same, so nothing else would catch it.
            continue
        usable[kind] = entry
    return usable


def _id_key(value) -> str:
    """The key an identifier is filed under. Case and stray spaces are noise."""
    return str(value or "").strip().upper()


def identity_tokens(identities) -> dict[str, str]:
    """Normalise a ``{identifier: security identity}`` map. Blank entries drop."""
    found: dict[str, str] = {}
    for key, value in (identities or {}).items():
        identifier = _id_key(key)
        token = str(value or "").strip().upper()
        if identifier and token:
            found[identifier] = token
    return found


def _identity_ledger(root: Path | None) -> dict:
    """Identifier -> the security that identifier resolved to when it was stored."""
    payload = _read_manifest(root)
    if payload.get("contract") != SERIES_CONTRACT:
        # The rows those identities describe are already unusable.
        return {}
    if payload.get("generation") != CACHE_GENERATION:
        return {}
    ledger = payload.get("identities")
    if not isinstance(ledger, dict):
        return {}
    return {
        _id_key(key): str(value or "").strip().upper()
        for key, value in ledger.items()
        if _id_key(key) and str(value or "").strip()
    }


def stale_identities(root: Path | None, identities) -> dict[str, tuple[str, str]]:
    """Identifiers that now resolve to a different security than their stored rows.

    A ticker is not a security. A fund can be re-pointed to another share
    class, a peer's primary listing can change, and a ticker can be reused:
    the request then returns a different instrument under the same string.
    Every row check in this module compares dates and column names, so
    without this the old series would answer for the new security and look
    perfectly healthy.

    Only a real mismatch counts. An identifier with nothing recorded, or a
    run that cannot say what an identifier is, keeps its stored rows: proving
    a change needs both sides.
    """
    wanted = identity_tokens(identities)
    if not wanted:
        return {}
    ledger = _identity_ledger(root)
    stale: dict[str, tuple[str, str]] = {}
    for key, value in (identities or {}).items():
        identifier = _id_key(key)
        token = str(value or "").strip().upper()
        if not identifier or not token:
            continue
        recorded = ledger.get(identifier, "")
        if not recorded or recorded == token:
            continue
        # The caller's own spelling is the key, so a report can name the
        # identifier exactly as the book or the peer map spells it.
        stale[str(key)] = (recorded, token)
    return stale


def _write_manifest(series: dict, root: Path | None, identities=None) -> None:
    path = _manifest_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "contract": SERIES_CONTRACT,
        "generation": CACHE_GENERATION,
        "series": series,
    }
    ledger = {
        _id_key(key): str(value or "").strip().upper()
        for key, value in (identities or {}).items()
        if _id_key(key) and str(value or "").strip()
    }
    if ledger:
        payload["identities"] = ledger
    text = json.dumps(payload, indent=2, sort_keys=True)
    writable = path.parent / f"{path.name}.tmp"
    writable.write_text(text, encoding="utf-8")
    os.replace(writable, path)


def _file_name(kind: str) -> str:
    return f"{kind}.csv"


def _empty(kind: str) -> pd.DataFrame:
    return pd.DataFrame(columns=["ID", "DATE", *KIND_COLUMNS[kind]])


def _columns(kind: str) -> list[str]:
    return ["ID", "DATE", *KIND_COLUMNS[kind]]


def read_series(
    kind: str,
    root: Path | None = None,
    fingerprint_value=None,
    identities=None,
) -> pd.DataFrame:
    """Stored rows for one kind. Never raises; an unusable file reads as empty.

    ``identities`` is the ``{identifier: security}`` map this run resolved.
    Rows of an identifier that now points at a different security are dropped,
    so that identifier is requested in full instead of being answered from a
    series that belongs to another instrument.
    """
    if kind not in KIND_COLUMNS:
        return pd.DataFrame(columns=["ID", "DATE"])
    empty = _empty(kind)
    entry = _usable_series(root, fingerprint_value).get(kind)
    if not isinstance(entry, dict):
        return empty
    name = str(entry.get("file", "")).strip()
    if not name:
        return empty
    path = cache_dir(root) / name
    if not path.is_file():
        return empty
    try:
        frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    except Exception:
        return empty
    if any(column not in frame.columns for column in _columns(kind)):
        return empty
    frame = frame.loc[:, _columns(kind)].copy()
    frame["ID"] = frame["ID"].fillna("").astype(str).str.strip()
    frame = frame.loc[~frame["ID"].eq("")]
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
    frame = frame.dropna(subset=["DATE"])
    for column in KIND_COLUMNS[kind]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    if frame.empty:
        return empty
    values = frame.loc[:, list(KIND_COLUMNS[kind])]
    if int(values.notna().to_numpy().sum()) == 0:
        # A stored file with no value at all would be served forever and the
        # repair could never run, so it is treated as absent.
        return empty
    frame["DATE"] = frame["DATE"].dt.normalize()
    stale = stale_identities(root, identities) if identities else {}
    if stale:
        changed_keys = {_id_key(name) for name in stale}
        changed = frame["ID"].astype(str).map(_id_key).isin(changed_keys)
        if changed.any():
            frame = frame.loc[~changed]
    if frame.empty:
        return empty
    frame = frame.sort_values(["DATE", "ID"], kind="mergesort")
    frame = frame.drop_duplicates(["ID", "DATE"], keep="last")
    return frame.reset_index(drop=True)


def subset(frame: pd.DataFrame | None, identifiers) -> pd.DataFrame:
    """Rows of one stored kind for these identifiers only."""
    if frame is None or frame.empty or "ID" not in frame.columns:
        return frame if frame is not None else pd.DataFrame()
    wanted = {str(value).strip() for value in (identifiers or []) if str(value).strip()}
    if not wanted:
        return frame.iloc[0:0].copy()
    return frame.loc[frame["ID"].astype(str).str.strip().isin(wanted)].copy()


def coverage(frame: pd.DataFrame | None) -> dict[str, tuple[pd.Timestamp, pd.Timestamp]]:
    """First and last stored date per identifier."""
    found: dict[str, tuple[pd.Timestamp, pd.Timestamp]] = {}
    if frame is None or frame.empty or "ID" not in frame.columns or "DATE" not in frame.columns:
        return found
    work = frame.copy()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work = work.dropna(subset=["DATE"])
    for identifier, group in work.groupby("ID", sort=False):
        dates = pd.to_datetime(group["DATE"], errors="coerce").dropna()
        if dates.empty:
            continue
        found[str(identifier)] = (dates.min().normalize(), dates.max().normalize())
    return found


def plan_gaps(
    kind: str,
    identifiers,
    cached: pd.DataFrame | None,
    request_start=None,
    request_end=None,
    default_end=None,
) -> list[tuple[object, object, list[str]]]:
    """Requests still needed for these identifiers.

    A triple with ``None`` start and end is the caller's own full request,
    which may be a relative range. A head or tail triple always carries
    absolute dates, so no window is skipped and no gap is left behind when a
    stored series starts late or stops early.
    """
    if kind not in KIND_COLUMNS:
        return []
    ordered: list[str] = []
    seen: set[str] = set()
    for value in identifiers or []:
        text = str(value).strip()
        if text and text not in seen:
            seen.add(text)
            ordered.append(text)
    if not ordered:
        return []
    if request_end is not None:
        end_absolute = pd.Timestamp(request_end).normalize()
    elif default_end is not None:
        end_absolute = pd.Timestamp(default_end).normalize()
    else:
        end_absolute = pd.Timestamp.today().normalize()
    if request_start is not None:
        start_absolute = pd.Timestamp(request_start).normalize()
    else:
        start_absolute = end_absolute - pd.DateOffset(years=RELATIVE_YEARS)
    spans = coverage(cached)
    missing: list[str] = []
    heads: dict[pd.Timestamp, list[str]] = {}
    tails: dict[pd.Timestamp, list[str]] = {}
    for identifier in ordered:
        span = spans.get(identifier)
        if span is None:
            missing.append(identifier)
            continue
        low, high = span
        if low > start_absolute:
            heads.setdefault(low - pd.Timedelta(days=1), []).append(identifier)
        if high < end_absolute:
            tails.setdefault(high + pd.Timedelta(days=1), []).append(identifier)
    jobs: list[tuple[object, object, list[str]]] = []
    if missing:
        jobs.append((request_start, request_end, missing))
    for last_head_day, members in heads.items():
        # The stored series starts after the window, so the older part is asked
        # for with absolute dates. The frozen relative range is never re-sent
        # for a fund that already has a head.
        if start_absolute <= last_head_day and _has_weekday(start_absolute, last_head_day):
            jobs.append((start_absolute, last_head_day, members))
    for first_tail_day, members in tails.items():
        if first_tail_day <= end_absolute and _has_weekday(first_tail_day, end_absolute):
            jobs.append((first_tail_day, end_absolute, members))
    return jobs


def _has_weekday(start, end) -> bool:
    """True when the window holds a Monday-to-Friday day.

    A weekend-only gap is not requested: the window edge can land on a
    Saturday when the five-year anchor moves one day forward, and a request
    that can only return "no rows" would report a failure every Refresh.
    """
    try:
        low = pd.Timestamp(start).normalize()
        high = pd.Timestamp(end).normalize()
    except (TypeError, ValueError):
        return False
    if pd.isna(low) or pd.isna(high) or low > high:
        return False
    days = pd.bdate_range(low, high)
    return len(days) > 0


def merge(kind: str, cached: pd.DataFrame | None, live_frames) -> pd.DataFrame:
    """Stored rows plus this run's rows. A live row wins on the same key."""
    if kind not in KIND_COLUMNS:
        return pd.DataFrame(columns=["ID", "DATE"])
    columns = _columns(kind)
    pieces: list[pd.DataFrame] = []
    for frame in [cached, *(live_frames or [])]:
        if frame is None or getattr(frame, "empty", True):
            continue
        work = frame.copy()
        if "ID" not in work.columns and "index" in work.columns:
            work = work.rename(columns={"index": "ID"})
        if "ID" not in work.columns or "DATE" not in work.columns:
            continue
        for column in KIND_COLUMNS[kind]:
            if column not in work.columns:
                work[column] = pd.NA
        work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
        work = work.dropna(subset=["DATE"])
        if work.empty:
            continue
        work["DATE"] = work["DATE"].dt.normalize()
        pieces.append(work.loc[:, columns])
    if not pieces:
        return _empty(kind)
    merged = pd.concat(pieces, ignore_index=True, sort=False)
    # Stored rows come first, so keeping the last copy lets the live row win.
    merged = merged.sort_values(["ID", "DATE"], kind="mergesort")
    merged = merged.drop_duplicates(["ID", "DATE"], keep="last")
    merged = merged.sort_values(["DATE", "ID"], kind="mergesort")
    return merged.loc[:, columns].reset_index(drop=True)


def trim_to_window(frame: pd.DataFrame | None, start=None, end=None) -> pd.DataFrame:
    """Keep the rows inside the window the caller asked for, inclusive.

    The stored series is usually wider than the window: a run at ``1Y`` after
    the rows were stored by a ``5Y`` run would otherwise hand the app five
    years when it asked for one, and the period analytics would silently be
    computed over a different span than the one on screen.
    """
    if frame is None or frame.empty or "DATE" not in frame.columns:
        return frame if frame is not None else pd.DataFrame()
    work = frame.copy()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work = work.dropna(subset=["DATE"])
    if start is not None:
        low = pd.Timestamp(start).normalize()
        if not pd.isna(low):
            work = work.loc[work["DATE"] >= low]
    if end is not None:
        high = pd.Timestamp(end).normalize()
        if not pd.isna(high):
            work = work.loc[work["DATE"] <= high]
    return work.reset_index(drop=True)


def save(
    kind: str,
    frame: pd.DataFrame | None,
    settled_before,
    root: Path | None = None,
    fingerprint_value=None,
    identities=None,
) -> int:
    """Write the settled rows of one kind. Returns how many rows were stored.

    Rows on or after ``settled_before`` are not written: that session can
    still change. A frame that lost a stored column, that holds no value at
    all, or that carries no settled row raises ``ValueError`` so the caller
    can report it instead of leaving a poisoned file behind.

    ``fingerprint_value`` is recorded with the file. Existing rows are merged
    only from a file written under the same token, so a request change cannot
    mix old rows with new ones in one series.

    ``identities`` is written for the identifiers this call rewrote, and only
    for those: recording a new identity while old rows were still in the file
    would make the next read accept them as the new security.
    """
    if kind not in KIND_COLUMNS:
        raise ValueError(f"Unknown history kind: {kind}")
    if frame is None or frame.empty:
        raise ValueError(f"Refusing to cache an empty {kind} frame.")
    missing = [column for column in _columns(kind) if column not in frame.columns]
    if missing:
        raise ValueError(
            f"Refusing to cache a partially parsed {kind} frame: missing {', '.join(missing)}"
        )
    work = frame.copy()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work = work.dropna(subset=["DATE"])
    work["DATE"] = work["DATE"].dt.normalize()
    settled = pd.Timestamp(settled_before).normalize()
    work = work.loc[work["DATE"] < settled]
    if work.empty:
        return 0
    work["ID"] = work["ID"].fillna("").astype(str).str.strip()
    work = work.loc[~work["ID"].eq("")]
    for column in KIND_COLUMNS[kind]:
        work[column] = pd.to_numeric(work[column], errors="coerce")
    if work.empty:
        return 0
    values = work.loc[:, list(KIND_COLUMNS[kind])]
    if int(values.notna().to_numpy().sum()) == 0:
        raise ValueError(f"Refusing to cache a {kind} frame with no value.")
    existing = read_series(kind, root, fingerprint_value, identities)
    replaced = set(work["ID"].tolist())
    if not existing.empty:
        existing = existing.loc[~existing["ID"].astype(str).isin(replaced)]
    combined = pd.concat([existing, work.loc[:, _columns(kind)]], ignore_index=True, sort=False)
    combined = combined.sort_values(["ID", "DATE"], kind="mergesort")
    combined = combined.drop_duplicates(["ID", "DATE"], keep="last")
    combined = combined.sort_values(["DATE", "ID"], kind="mergesort")
    combined = combined.reset_index(drop=True)
    combined["DATE"] = pd.to_datetime(combined["DATE"], errors="coerce")
    combined = combined.dropna(subset=["DATE"])
    stored = combined.copy()
    stored["DATE"] = stored["DATE"].dt.strftime("%Y-%m-%d")
    for column in KIND_COLUMNS[kind]:
        stored[column] = stored[column].map(_number_text)
    folder = cache_dir(root)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / _file_name(kind)
    writable = folder / f"{path.name}.tmp"
    stored.to_csv(writable, index=False, encoding="utf-8")
    os.replace(writable, path)
    series = _usable_series(root, fingerprint_value)
    series[kind] = {
        "file": path.name,
        "rows": int(len(stored)),
        "ids": int(stored["ID"].nunique()),
        "fingerprint": fingerprint_value,
    }
    ledger = _identity_ledger(root)
    tokens = identity_tokens(identities)
    for identifier in set(work["ID"].map(_id_key)):
        if identifier in tokens:
            ledger[identifier] = tokens[identifier]
    _write_manifest(series, root, ledger)
    return int(len(work))


def _number_text(value) -> str:
    """One cell as text. A blank stays blank instead of becoming ``nan``."""
    if value is None or pd.isna(value):
        return ""
    return repr(float(value))
