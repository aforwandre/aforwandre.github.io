"""ETF Spread Monitoring application package."""

from __future__ import annotations

__all__ = ["ETFSpreadMonitor"]


def __getattr__(name):
    if name == "ETFSpreadMonitor":
        from .app import ETFSpreadMonitor

        return ETFSpreadMonitor
    raise AttributeError(name)
