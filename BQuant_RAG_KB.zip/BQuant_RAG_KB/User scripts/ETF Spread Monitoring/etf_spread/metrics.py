"""Period returns and peer averages. No request is built here.

Return percent uses a total-return index level. The level on a non-trading
day is the latest level on or before that day, the same rule as
``fill='prev'``. A later session is not used. Return percent is
``(end / start - 1) * 100``. A missing or non-positive start stays blank.

Peer and benchmark windows use the HSBC listing's quote dates. A London
holiday is not a peer or benchmark session: the value is the last print on
or before the HSBC quote date.
"""

from __future__ import annotations

import pandas as pd

from .book_view import (
    CUSTOM_PERIOD,
    TAXONOMY_COLUMNS,
    absolute_quote_spread,
    clean_market_text,
    custom_bounds,
    display_columns,
    london_trading_days,
    percent_quote_spread,
    resolved_mid,
    previous_london_day,
    share_class_chart,
)
from .engine import period_bounds
from .peer_map import fund_name_key


def _clean_ticker(value) -> str:
    return clean_market_text(value)


def member_tickers(anchor: str, peers, include_anchor: bool) -> list[str]:
    """Tickers in the average. The anchor is included only for HSBC + Peers.

    A ticker is listed once. Order is the anchor first, then the peer list.
    """
    ordered: list[str] = []
    seen: set[str] = set()

    def add(value) -> None:
        text = _clean_ticker(value)
        key = text.upper()
        if not text or key in seen:
            return
        seen.add(key)
        ordered.append(text)

    if include_anchor:
        add(anchor)
    for ticker in list(peers or []):
        add(ticker)
    return ordered


def _mean(values: pd.Series):
    numeric = pd.to_numeric(values, errors="coerce")
    if int(numeric.notna().sum()) == 0:
        return pd.NA
    return float(numeric.mean())


def _levels(frame: pd.DataFrame) -> pd.Series:
    work = frame.copy()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce").dt.normalize()
    work["Level"] = pd.to_numeric(work["Level"], errors="coerce")
    work = work.dropna(subset=["DATE"]).sort_values("DATE", kind="mergesort")
    work = work.drop_duplicates("DATE", keep="last")
    if work.empty:
        return pd.Series(dtype=float)
    return work.set_index("DATE")["Level"].sort_index()


def level_on_or_before(levels: pd.Series, day):
    """Latest level on or before ``day``. A later print is not used."""
    if levels is None or levels.empty or day is None or pd.isna(day):
        return pd.NA
    day_ts = pd.Timestamp(day).normalize()
    eligible = levels.loc[levels.index <= day_ts].dropna()
    if eligible.empty:
        return pd.NA
    return float(eligible.iloc[-1])


def _period_window(period: str, as_of, custom_start=None, custom_end=None):
    """One inclusive window for spread and return.

    A custom end after the last completed London session is cut back to that
    session. A window that then starts after it ends is rejected.
    """
    end_session = previous_london_day(as_of)
    if end_session is None:
        return None, None
    end_session = pd.Timestamp(end_session).normalize()
    key = str(period or "").strip()
    if key == CUSTOM_PERIOD:
        start, custom_end_ts = custom_bounds(custom_start, custom_end)
        if start is None or custom_end_ts is None:
            return None, None
        capped = min(pd.Timestamp(custom_end_ts).normalize(), end_session)
        if start > capped:
            return None, None
        return start, capped
    start, bound_end, notes = period_bounds(key, end_session)
    if notes or start is None or bound_end is None:
        return None, None
    return pd.Timestamp(start).normalize(), pd.Timestamp(bound_end).normalize()


def _percent_from_levels(levels: pd.Series, start, end, *, first_inside: bool = False):
    """Percent change from the level on or before each edge.

    A window with no level is blank. ``first_inside`` is the Peers tab path.
    It uses the first non-null level inside the window only when nothing is
    on or before the start, which covers a weekend start and a listing whose
    history begins inside the window. That level must be positive. A later
    positive print is not used in its place.
    """
    if levels is None or levels.empty or start is None or end is None:
        return pd.NA
    start_ts = pd.Timestamp(start).normalize()
    end_ts = pd.Timestamp(end).normalize()
    if start_ts > end_ts:
        return pd.NA
    inside = levels.loc[(levels.index >= start_ts) & (levels.index <= end_ts)].dropna()
    if inside.empty:
        return pd.NA
    start_level = level_on_or_before(levels, start)
    end_level = level_on_or_before(levels, end)
    if first_inside and pd.isna(start_level):
        start_level = float(inside.iloc[0])
    if pd.isna(start_level) or pd.isna(end_level) or float(start_level) <= 0:
        return pd.NA
    return (float(end_level) / float(start_level) - 1.0) * 100.0


def _id_rows(frame: pd.DataFrame | None, ticker: str) -> pd.DataFrame:
    key = _clean_ticker(ticker).upper()
    if (
        frame is None
        or frame.empty
        or not key
        or "ID" not in frame.columns
        or "DATE" not in frame.columns
    ):
        return pd.DataFrame()
    work = frame.copy()
    work["_key"] = work["ID"].astype(str).str.strip().str.upper()
    work = work.loc[work["_key"].eq(key)].copy()
    if work.empty:
        return work
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce").dt.normalize()
    work = work.dropna(subset=["DATE"]).sort_values("DATE", kind="mergesort")
    return work.drop_duplicates("DATE", keep="last")


def _prints_from_rows(work: pd.DataFrame | None) -> pd.DataFrame:
    """One row per date. A date with no numeric spread is not a quote."""
    empty = pd.DataFrame(columns=["DATE", "Spread", "Percent Spread"])
    if work is None or work.empty or "DATE" not in work.columns:
        return empty
    rows = work.copy()
    rows["DATE"] = pd.to_datetime(rows["DATE"], errors="coerce").dt.normalize()
    rows = rows.dropna(subset=["DATE"]).sort_values("DATE", kind="mergesort")
    if rows.empty:
        return empty
    rows = rows.drop_duplicates("DATE", keep="last")
    if {"Bid", "Ask"}.issubset(rows.columns):
        rows["Spread"] = absolute_quote_spread(rows["Bid"], rows["Ask"])
        rows["Mid"] = resolved_mid(
            rows["Bid"],
            rows["Ask"],
            rows["Mid"] if "Mid" in rows.columns else None,
        )
        rows["Percent Spread"] = percent_quote_spread(rows["Spread"], rows["Mid"])
    if "Spread" not in rows.columns:
        rows["Spread"] = pd.NA
    if "Percent Spread" not in rows.columns:
        rows["Percent Spread"] = pd.NA
    rows = rows.loc[:, ["DATE", "Spread", "Percent Spread"]]
    valid = pd.to_numeric(rows["Spread"], errors="coerce").notna()
    return rows.loc[valid].reset_index(drop=True)


def _quote_prints(history: pd.DataFrame | None, ticker: str) -> pd.DataFrame:
    """One row per quote date. This is not the carried London calendar."""
    return _prints_from_rows(_id_rows(history, ticker))


def _quote_index(history: pd.DataFrame | None) -> dict[str, pd.DataFrame]:
    """Quote prints grouped once by ticker."""
    if (
        history is None
        or history.empty
        or "ID" not in history.columns
        or "DATE" not in history.columns
    ):
        return {}
    work = history.copy()
    work["_key"] = work["ID"].astype(str).str.strip().str.upper()
    index: dict[str, pd.DataFrame] = {}
    for key, group in work.groupby("_key", sort=False):
        text = str(key or "").strip()
        if not text:
            continue
        index[text] = _prints_from_rows(group)
    return index


def _level_index(history: pd.DataFrame | None) -> dict[str, pd.Series]:
    """Total-return levels grouped once by ticker."""
    if (
        history is None
        or history.empty
        or "ID" not in history.columns
        or "Level" not in history.columns
        or "DATE" not in history.columns
    ):
        return {}
    work = history.copy()
    work["_key"] = work["ID"].astype(str).str.strip().str.upper()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work = work.dropna(subset=["DATE"])
    index: dict[str, pd.Series] = {}
    for key, group in work.groupby("_key", sort=False):
        text = str(key or "").strip()
        if not text:
            continue
        index[text] = _levels(group)
    return index


def _quote_dates_from_prints(prints: pd.DataFrame | None) -> pd.DatetimeIndex:
    if prints is None or prints.empty or "DATE" not in prints.columns:
        return pd.DatetimeIndex([])
    return pd.DatetimeIndex(pd.to_datetime(prints["DATE"])).unique().sort_values()


def _quote_dates(history: pd.DataFrame | None, ticker: str) -> pd.DatetimeIndex:
    return _quote_dates_from_prints(_quote_prints(history, ticker))


def _dated_series(prints: pd.DataFrame, column: str) -> pd.Series:
    if prints is None or prints.empty or column not in prints.columns or "DATE" not in prints.columns:
        return pd.Series(dtype=float)
    work = prints.dropna(subset=["DATE"]).sort_values("DATE", kind="mergesort")
    values = pd.to_numeric(work[column], errors="coerce")
    series = pd.Series(values.to_numpy(), index=pd.DatetimeIndex(pd.to_datetime(work["DATE"])))
    return series[~series.index.duplicated(keep="last")].sort_index()


def _levels_for(levels: pd.DataFrame | None, ticker: str) -> pd.Series:
    rows = _id_rows(levels, ticker)
    if rows.empty or "Level" not in rows.columns:
        return pd.Series(dtype=float)
    return _levels(rows)


def _on_or_before_date(dates: pd.DatetimeIndex, day):
    if dates is None or len(dates) == 0 or day is None or pd.isna(day):
        return None
    day_ts = pd.Timestamp(day).normalize()
    eligible = dates[dates <= day_ts]
    if len(eligible) == 0:
        return None
    return pd.Timestamp(eligible[-1]).normalize()


def _anchor_endpoints(dates: pd.DatetimeIndex, window_start, window_end):
    """HSBC quote dates that bound the window.

    The end is the last quote on or before the window end. The start is the
    last quote on or before the window start. A fund whose first quote is
    inside the window uses that first quote, so peer and benchmark do not
    start before the fund.
    """
    if window_start is None or window_end is None or dates is None or len(dates) == 0:
        return None, None
    end_date = _on_or_before_date(dates, window_end)
    if end_date is None:
        return None, None
    start_date = _on_or_before_date(dates, window_start)
    if start_date is None:
        start_ts = pd.Timestamp(window_start).normalize()
        inside = dates[(dates >= start_ts) & (dates <= end_date)]
        if len(inside) == 0:
            return None, None
        start_date = pd.Timestamp(inside[0]).normalize()
    window_start_ts = pd.Timestamp(window_start).normalize()
    if end_date < window_start_ts or start_date > end_date:
        return None, None
    return start_date, end_date


def _anchor_weekdays(dates: pd.DatetimeIndex, window_start, window_end) -> pd.DatetimeIndex:
    """London weekdays for a return path, from the quote on or before the start."""
    start_date, _end_date = _anchor_endpoints(dates, window_start, window_end)
    if start_date is None or window_end is None:
        return pd.DatetimeIndex([])
    end = pd.Timestamp(window_end).normalize()
    if start_date > end:
        return pd.DatetimeIndex([])
    return london_trading_days(start_date, end)


def _spread_weekdays(dates: pd.DatetimeIndex, window_start, window_end) -> pd.DatetimeIndex:
    """London weekdays inside the window, from the first HSBC quote in it.

    A weekend or holiday window start does not pull in the previous session.
    The fund's first quote, when it falls inside the window, is the first day.
    """
    if dates is None or len(dates) == 0 or window_start is None or window_end is None:
        return pd.DatetimeIndex([])
    start_ts = pd.Timestamp(window_start).normalize()
    end = pd.Timestamp(window_end).normalize()
    first = pd.Timestamp(dates.min()).normalize()
    begin = max(start_ts, first)
    if begin > end:
        return pd.DatetimeIndex([])
    return london_trading_days(begin, end)


def _aligned_mean(dates: pd.DatetimeIndex, weekdays: pd.DatetimeIndex, series: pd.Series):
    samples = []
    for day in weekdays:
        quote_day = _on_or_before_date(dates, day)
        if quote_day is None:
            continue
        samples.append(level_on_or_before(series, quote_day))
    return _mean(pd.Series(samples, dtype=object))


def _aligned_path(
    levels: pd.Series,
    quote_dates: pd.DatetimeIndex,
    plot_days: pd.DatetimeIndex,
    start_date,
) -> pd.DataFrame:
    rows = []
    for day in plot_days:
        quote_day = _on_or_before_date(quote_dates, day)
        if quote_day is None or start_date is None:
            value = pd.NA
        else:
            value = _percent_from_levels(levels, start_date, quote_day)
        rows.append((pd.Timestamp(day).normalize(), value))
    if not rows:
        return pd.DataFrame(columns=["DATE", "Return %"])
    return pd.DataFrame(rows, columns=["DATE", "Return %"])


def return_percents(
    levels: pd.DataFrame | None,
    as_of,
    custom_start=None,
    custom_end=None,
) -> pd.DataFrame:
    """One return percent per ticker and period."""
    from .book_view import AVERAGE_PERIODS

    periods = (*AVERAGE_PERIODS, CUSTOM_PERIOD)
    columns = ["ID", *[f"{period} Return %" for period in periods]]
    if levels is None or levels.empty or "ID" not in levels.columns or "Level" not in levels.columns:
        return pd.DataFrame(columns=columns)
    rows = []
    frame = levels.copy()
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
    frame = frame.dropna(subset=["DATE"])
    for identifier, group in frame.groupby("ID", sort=False):
        series = _levels(group)
        row = {"ID": identifier}
        for period in periods:
            start, end = _period_window(period, as_of, custom_start, custom_end)
            row[f"{period} Return %"] = _percent_from_levels(
                series, start, end, first_inside=True
            )
        rows.append(row)
    if not rows:
        return pd.DataFrame(columns=columns)
    return pd.DataFrame(rows, columns=columns)


def _period_list(selected) -> list[str]:
    ordered = []
    seen = set()
    for value in list(selected or []):
        text = str(value).strip()
        if text and text not in seen:
            seen.add(text)
            ordered.append(text)
    return ordered


def visible_book_columns(
    selected,
    show_spread: bool,
    show_return: bool,
    show_nav: bool = False,
) -> list[str]:
    """Identity columns, then the metric columns for the checked periods."""
    head: list[str] = []
    tail: list[str] = []
    in_tail = False
    for column in display_columns():
        if column.endswith(" Avg Spread") or column.endswith(" Avg Spread %"):
            continue
        if column in TAXONOMY_COLUMNS or column == "Primary":
            in_tail = True
        if in_tail:
            tail.append(column)
        else:
            head.append(column)
    metrics: list[str] = []
    for period in _period_list(selected):
        if show_spread:
            metrics.extend(
                [
                    f"{period} Avg Spread %",
                    f"{period} Peer Avg Spread %",
                ]
            )
        if show_return:
            metrics.extend(
                [
                    f"{period} Return %",
                    f"{period} Peer Avg Return %",
                    f"{period} Bmk Return %",
                ]
            )
        if show_nav:
            metrics.extend(
                [
                    f"{period} NAV Return %",
                    f"{period} Peer Avg NAV Return %",
                ]
            )
            if not show_return:
                metrics.append(f"{period} Bmk Return %")
    return head + metrics + tail


def peer_metric_frame(
    book: pd.DataFrame | None,
    links: pd.DataFrame | None,
    quote_history: pd.DataFrame | None,
    return_history: pd.DataFrame | None,
    selected,
    include_anchor: bool,
    as_of,
    custom_start=None,
    custom_end=None,
    nav_history: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Peer-average columns for each book row, keyed by Ticker."""
    periods = _period_list(selected)
    include_nav = nav_history is not None
    columns = ["Ticker"]
    for period in periods:
        columns.extend(
            [
                f"{period} Peer Avg Spread %",
                f"{period} Return %",
                f"{period} Peer Avg Return %",
                f"{period} Bmk Return %",
            ]
        )
        if include_nav:
            columns.extend(
                [
                    f"{period} NAV Return %",
                    f"{period} Peer Avg NAV Return %",
                ]
            )
    if book is None or book.empty or "Ticker" not in book.columns:
        return pd.DataFrame(columns=columns)
    peers_by_fund: dict[str, list[str]] = {}
    if links is not None and not links.empty and {"Fund Name", "Ticker"}.issubset(links.columns):
        named = links.copy()
        named["_fund"] = named["Fund Name"].map(fund_name_key)
        for fund, group in named.groupby("_fund", sort=False):
            if not fund:
                continue
            peers_by_fund[str(fund)] = [
                _clean_ticker(value) for value in group["Ticker"].tolist() if _clean_ticker(value)
            ]
    prints_by = _quote_index(quote_history)
    levels_by = _level_index(return_history)
    nav_by = _level_index(nav_history) if include_nav else {}
    empty_prints = pd.DataFrame(columns=["DATE", "Spread", "Percent Spread"])
    rows = []
    for _, record in book.iterrows():
        anchor = _clean_ticker(record.get("Ticker"))
        anchor_key = anchor.upper()
        fund = fund_name_key(record.get("Fund Name")) if "Fund Name" in book.columns else ""
        peers = peers_by_fund.get(fund, [])
        members = member_tickers(anchor, peers, include_anchor)
        benchmark = _clean_ticker(record.get("Benchmark Index")) if "Benchmark Index" in book.columns else ""
        anchor_prints = prints_by.get(anchor_key, empty_prints)
        quote_dates = _quote_dates_from_prints(anchor_prints)
        own_levels = levels_by.get(anchor_key, pd.Series(dtype=float))
        benchmark_levels = levels_by.get(benchmark.upper(), pd.Series(dtype=float)) if benchmark else pd.Series(dtype=float)
        own_nav = nav_by.get(anchor_key, pd.Series(dtype=float))
        row = {"Ticker": anchor}
        for period in periods:
            spread_start, spread_end = _period_window(period, as_of, custom_start, custom_end)
            weekdays = _spread_weekdays(quote_dates, spread_start, spread_end)
            percent_values = [
                _aligned_mean(
                    quote_dates,
                    weekdays,
                    _dated_series(prints_by.get(ticker.upper(), empty_prints), "Percent Spread"),
                )
                for ticker in members
            ]
            row[f"{period} Peer Avg Spread %"] = _mean(pd.Series(percent_values, dtype=object))
            return_start, return_end = _period_window(period, as_of, custom_start, custom_end)
            actual_start, actual_end = _anchor_endpoints(quote_dates, return_start, return_end)
            if actual_start is None or actual_end is None:
                row[f"{period} Return %"] = pd.NA
                row[f"{period} Peer Avg Return %"] = pd.NA
                row[f"{period} Bmk Return %"] = pd.NA
                if include_nav:
                    row[f"{period} NAV Return %"] = pd.NA
                    row[f"{period} Peer Avg NAV Return %"] = pd.NA
                continue
            row[f"{period} Return %"] = _percent_from_levels(own_levels, actual_start, actual_end)
            peer_returns = [
                _percent_from_levels(levels_by.get(ticker.upper(), pd.Series(dtype=float)), actual_start, actual_end)
                for ticker in members
            ]
            row[f"{period} Peer Avg Return %"] = _mean(pd.Series(peer_returns, dtype=object))
            row[f"{period} Bmk Return %"] = _percent_from_levels(benchmark_levels, actual_start, actual_end)
            if include_nav:
                row[f"{period} NAV Return %"] = _percent_from_levels(own_nav, actual_start, actual_end)
                nav_returns = [
                    _percent_from_levels(nav_by.get(ticker.upper(), pd.Series(dtype=float)), actual_start, actual_end)
                    for ticker in members
                ]
                row[f"{period} Peer Avg NAV Return %"] = _mean(pd.Series(nav_returns, dtype=object))
        rows.append(row)
    return pd.DataFrame(rows, columns=columns)


def _daily_mean(frames: list[pd.DataFrame], value: str) -> pd.DataFrame:
    if not frames:
        return pd.DataFrame(columns=["DATE", value])
    pieces = []
    for frame in frames:
        if frame is None or frame.empty or value not in frame.columns:
            continue
        piece = frame.loc[:, ["DATE", value]].copy()
        piece["DATE"] = pd.to_datetime(piece["DATE"], errors="coerce")
        pieces.append(piece)
    if not pieces:
        return pd.DataFrame(columns=["DATE", value])
    stacked = pd.concat(pieces, ignore_index=True, sort=False)
    stacked = stacked.dropna(subset=["DATE"])
    averaged = (
        stacked.groupby("DATE", sort=True)[value]
        .apply(_mean)
        .reset_index()
    )
    return averaged


def _snapped_spread(history, ticker: str, quote_dates: pd.DatetimeIndex, days) -> pd.DataFrame:
    prints = _quote_prints(history, ticker)
    percent = _dated_series(prints, "Percent Spread")
    rows = []
    for day in days:
        quote_day = _on_or_before_date(quote_dates, day)
        if quote_day is None:
            rows.append((pd.Timestamp(day), pd.NA))
            continue
        rows.append((pd.Timestamp(day), level_on_or_before(percent, quote_day)))
    return pd.DataFrame(rows, columns=["DATE", "Percent Spread"])


def spread_comparison(
    history: pd.DataFrame | None,
    anchor: str,
    peers,
    period: str,
    as_of,
    include_anchor: bool,
    custom_start=None,
    custom_end=None,
) -> pd.DataFrame:
    """Selected share class plus the peer-average spread percent.

    Peer values are taken on the HSBC quote date on or before each London
    weekday. A peer print after that quote date is not used. The absolute
    peer average is not built.
    """
    own = share_class_chart(history, anchor, period, as_of, custom_start, custom_end)
    members = member_tickers(anchor, peers, include_anchor)
    quote_dates = _quote_dates(history, anchor)
    days = [] if own is None or own.empty else own["DATE"].tolist()
    frames = []
    if len(quote_dates) and days:
        frames = [_snapped_spread(history, ticker, quote_dates, days) for ticker in members]
    peer_percent = _daily_mean(frames, "Percent Spread").rename(
        columns={"Percent Spread": "Peer Spread %"}
    )
    if own is None or own.empty:
        base = pd.DataFrame(columns=["DATE", "Percent Spread"])
    else:
        base = own.copy()
    if base.empty and peer_percent.empty:
        return pd.DataFrame(columns=["DATE", "Percent Spread", "Peer Spread %"])
    if base.empty:
        base = peer_percent.loc[:, ["DATE"]].copy()
        base["Percent Spread"] = pd.NA
    base["DATE"] = pd.to_datetime(base["DATE"], errors="coerce")
    out = base.merge(peer_percent, on="DATE", how="left")
    return out.sort_values("DATE", kind="mergesort").reset_index(drop=True)


def return_comparison(
    levels: pd.DataFrame | None,
    anchor: str,
    peers,
    period: str,
    as_of,
    include_anchor: bool,
    custom_start=None,
    custom_end=None,
    quotes: pd.DataFrame | None = None,
    benchmark_id: str = "",
) -> pd.DataFrame:
    """Selected share class, peer average, and benchmark on HSBC quote dates."""
    empty = pd.DataFrame(columns=["DATE", "Return %", "Peer Return %", "Bmk Return %"])
    start, end = _period_window(period, as_of, custom_start, custom_end)
    if start is None or end is None or levels is None or levels.empty or "ID" not in levels.columns:
        return empty
    quote_dates = _quote_dates(quotes, anchor)
    actual_start, actual_end = _anchor_endpoints(quote_dates, start, end)
    if actual_start is None or actual_end is None:
        return empty
    plot_days = _anchor_weekdays(quote_dates, start, end)
    if len(plot_days) == 0:
        plot_days = pd.DatetimeIndex([actual_start, actual_end])
    own = _aligned_path(_levels_for(levels, anchor), quote_dates, plot_days, actual_start)
    frames = [
        _aligned_path(_levels_for(levels, ticker), quote_dates, plot_days, actual_start)
        for ticker in member_tickers(anchor, peers, include_anchor)
    ]
    peer = _daily_mean(frames, "Return %").rename(columns={"Return %": "Peer Return %"})
    if str(benchmark_id or "").strip():
        benchmark = _aligned_path(
            _levels_for(levels, benchmark_id),
            quote_dates,
            plot_days,
            actual_start,
        ).rename(columns={"Return %": "Bmk Return %"})
    else:
        benchmark = pd.DataFrame({"DATE": pd.to_datetime(list(plot_days)), "Bmk Return %": pd.NA})
    if own.empty and peer.empty and benchmark.empty:
        return empty
    if own.empty:
        own = pd.DataFrame({"DATE": plot_days, "Return %": pd.NA})
    own["DATE"] = pd.to_datetime(own["DATE"], errors="coerce")
    out = own.merge(peer, on="DATE", how="left")
    out = out.merge(benchmark.loc[:, ["DATE", "Bmk Return %"]], on="DATE", how="left")
    return out.sort_values("DATE", kind="mergesort").reset_index(drop=True)


def _legend_name(label: str, used: set[str]) -> str:
    base = clean_market_text(label) or "Series"
    name = base
    number = 2
    while name in used:
        name = f"{base} ({number})"
        number += 1
    used.add(name)
    return name


def peer_member_spreads(
    history: pd.DataFrame | None,
    anchor: str,
    members,
    period: str,
    as_of,
    custom_start=None,
    custom_end=None,
) -> pd.DataFrame:
    """Percent spread of each peer on the selected row's chart dates.

    ``members`` is ``(ticker, legend name)``. The selected ticker is omitted.
    The column name is the legend plus `` Spread %``.
    """
    own = share_class_chart(history, anchor, period, as_of, custom_start, custom_end)
    if own is None or own.empty:
        return pd.DataFrame(columns=["DATE"])
    out = own.loc[:, ["DATE"]].copy()
    out["DATE"] = pd.to_datetime(out["DATE"], errors="coerce").dt.normalize()
    quote_dates = _quote_dates(history, anchor)
    days = own["DATE"].tolist()
    anchor_key = _clean_ticker(anchor).upper()
    used = {"DATE", "Spread %", "Peer Avg Spread %"}
    if not len(quote_dates):
        return out
    for ticker, label in list(members or []):
        if _clean_ticker(ticker).upper() == anchor_key:
            continue
        column = _legend_name(f"{label} Spread %", used)
        snapped = _snapped_spread(history, ticker, quote_dates, days)
        snapped = snapped.rename(columns={"Percent Spread": column})
        snapped["DATE"] = pd.to_datetime(snapped["DATE"], errors="coerce").dt.normalize()
        out = out.merge(snapped.loc[:, ["DATE", column]], on="DATE", how="left")
    return out


def peer_member_returns(
    levels: pd.DataFrame | None,
    anchor: str,
    members,
    period: str,
    as_of,
    custom_start=None,
    custom_end=None,
    quotes: pd.DataFrame | None = None,
    legend_suffix: str = " Return %",
) -> pd.DataFrame:
    """Return percent of each peer on the selected row's quote dates.

    ``members`` is ``(ticker, legend name)``. The selected ticker is omitted.
    The column name is the legend plus ``legend_suffix``.
    """
    empty = pd.DataFrame(columns=["DATE"])
    start, end = _period_window(period, as_of, custom_start, custom_end)
    if start is None or end is None or levels is None or levels.empty or "ID" not in levels.columns:
        return empty
    quote_dates = _quote_dates(quotes, anchor)
    actual_start, actual_end = _anchor_endpoints(quote_dates, start, end)
    if actual_start is None or actual_end is None:
        return empty
    plot_days = _anchor_weekdays(quote_dates, start, end)
    if len(plot_days) == 0:
        plot_days = pd.DatetimeIndex([actual_start, actual_end])
    out = pd.DataFrame({"DATE": pd.to_datetime(list(plot_days)).normalize()})
    anchor_key = _clean_ticker(anchor).upper()
    used = {
        "DATE",
        "Return %",
        "Peer Avg Return %",
        "Bmk Return %",
        "NAV Return %",
        "Peer NAV Return %",
        "Bmk NAV Return %",
    }
    for ticker, label in list(members or []):
        if _clean_ticker(ticker).upper() == anchor_key:
            continue
        column = _legend_name(f"{label}{legend_suffix}", used)
        path = _aligned_path(_levels_for(levels, ticker), quote_dates, plot_days, actual_start)
        path = path.rename(columns={"Return %": column})
        path["DATE"] = pd.to_datetime(path["DATE"], errors="coerce").dt.normalize()
        out = out.merge(path.loc[:, ["DATE", column]], on="DATE", how="left")
    return out
