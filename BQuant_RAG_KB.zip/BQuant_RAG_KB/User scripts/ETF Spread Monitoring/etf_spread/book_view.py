"""Book table and per-fund chart frames. No request is built here."""

from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .engine import period_bounds

# Bloomberg leaves a description after the token: "N/A - suspended",
# "#N/A Invalid Security", "N.A. (no last)". "NA US Equity" is not a token.
_MISSING_EXACT = frozenset(
    {
        "",
        "na",
        "n/a",
        "n.a",
        "n.a.",
        "#n/a",
        "#n/a n/a",
        "null",
        "none",
        "nan",
        "nat",
        "<na>",
        "nil",
        "n.s",
        "n.s.",
        "n.d",
        "n.d.",
        "n.m",
        "n.m.",
        "-",
        "--",
        "---",
        "—",
        "–",
        ".",
        "..",
        "...",
        "blank",
        "empty",
        "undefined",
        "unavailable",
        "not available",
        "not applicable",
        "field not applicable",
        "fld not applicable",
        "no data",
        "no value",
    }
)
_MISSING_PREFIX = re.compile(
    r"^(?:n/a|#n/a|n\.a\.?|not available|not applicable|field not applicable|"
    r"fld not applicable|no data|no value)(?:$|[\s:\-–—;,/(\[].*)",
    re.IGNORECASE,
)
_NA_NOTE = re.compile(r"^na(?:$|[\s]*[:\-–—(;,/].*)", re.IGNORECASE)


def missing_market_text(value) -> bool:
    """True when a cell is empty or a Bloomberg missing token.

    A zero is not a text token. ``NA US Equity`` stays text. ``N/A`` with
    any trailing description is missing.
    """
    if value is None:
        return True
    if not isinstance(value, str):
        try:
            if pd.isna(value):
                return True
        except (TypeError, ValueError):
            return True
        return False
    text = " ".join(value.strip().lower().split())
    if text in _MISSING_EXACT:
        return True
    if _MISSING_PREFIX.match(text) or _NA_NOTE.match(text):
        return True
    return False


def clean_market_text(value) -> str:
    """Strip a market string. A missing token becomes an empty string."""
    if missing_market_text(value):
        return ""
    return str(value).strip()


def preferred_long_name(long_name, fallback) -> str:
    """Shown name from ``long_comp_name``. A blank long name keeps the fallback."""
    text = clean_market_text(long_name)
    if text:
        return text
    return clean_market_text(fallback)


def market_numbers(values, *, allow_zero: bool = False) -> pd.Series:
    """Numeric cells. Missing tokens are blank.

    ``allow_zero`` is for a real zero: fund flow, expense, tracking error,
    and a computed return. Quotes, levels, and asset amounts leave zero
    blank, because a zero print from Bloomberg is an empty price.
    """
    series = values if isinstance(values, pd.Series) else pd.Series(values)
    if series.empty:
        return pd.to_numeric(series, errors="coerce")
    missing = series.map(missing_market_text)
    numeric = pd.to_numeric(series.mask(missing), errors="coerce").replace(
        [np.inf, -np.inf],
        np.nan,
    )
    if not allow_zero:
        numeric = numeric.mask(numeric.le(0))
    return numeric


def absolute_quote_spread(bid, ask) -> pd.Series:
    """Ask minus bid when both quotes are positive and ask is at least bid.

    A crossed, non-positive, or non-numeric quote stays blank. This is the
    operator's absolute difference. It is not a vendor average.
    """
    bid_n = market_numbers(bid, allow_zero=False)
    ask_n = market_numbers(ask, allow_zero=False)
    valid = bid_n.gt(0) & ask_n.gt(0) & ask_n.ge(bid_n)
    return (ask_n - bid_n).where(valid)


def resolved_mid(bid, ask, mid=None) -> pd.Series:
    """Positive mid, otherwise the average of a positive bid and ask.

    PX_MID is often blank. PX_BID and PX_ASK are the quotes that are present.
    Return percent does not use this value.
    """
    bid_s = bid if isinstance(bid, pd.Series) else pd.Series(bid)
    ask_s = ask if isinstance(ask, pd.Series) else pd.Series(ask, index=bid_s.index)
    bid_n = pd.to_numeric(bid_s, errors="coerce")
    ask_n = pd.to_numeric(ask_s, errors="coerce")
    midpoint = ((bid_n + ask_n) / 2.0).where(bid_n.gt(0) & ask_n.gt(0))
    if mid is None:
        return midpoint
    mid_s = mid if isinstance(mid, pd.Series) else pd.Series(mid, index=bid_s.index)
    mid_n = pd.to_numeric(mid_s.reindex(bid_s.index), errors="coerce")
    return mid_n.where(mid_n.gt(0), midpoint)


def percent_quote_spread(absolute, mid) -> pd.Series:
    """Absolute spread divided by the mid, then multiplied by 100.

    The column header already says percent. A blank absolute spread, a
    blank mid, or a mid that is not positive stays blank.
    """
    absolute_n = market_numbers(absolute, allow_zero=True)
    mid_n = market_numbers(mid, allow_zero=False)
    valid = absolute_n.notna() & mid_n.gt(0)
    return (absolute_n / mid_n * 100).where(valid)

AVERAGE_PERIODS = ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y")
HISTORY_RANGES = ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y")


def periods_within(max_range: str) -> list[str]:
    """Presets that fit inside the history loaded at Refresh.

    ``6M`` does not include ``YTD``, because a late-year YTD is longer
    than six months. A ``YTD`` pull only offers ``YTD``, because early in
    the year ``1M`` can be longer than the year to date. ``1Y`` and longer
    include ``YTD``.
    """
    order = ("1M", "3M", "6M", "1Y", "3Y", "5Y")
    key = str(max_range or "5Y").strip()
    if key not in HISTORY_RANGES:
        key = "5Y"
    if key == "YTD":
        return ["YTD"]
    limit = order.index(key)
    chosen = list(order[: limit + 1])
    if key in {"1Y", "3Y", "5Y"}:
        chosen.insert(chosen.index("1Y"), "YTD")
    return chosen
CUSTOM_PERIOD = "Custom"


def _normalize_bound(value):
    if value is None:
        return None
    try:
        stamp = pd.Timestamp(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(stamp):
        return None
    return stamp.normalize()


def custom_bounds(custom_start=None, custom_end=None):
    """Inclusive custom bounds. A weekend endpoint stays a bound (card 27)."""
    start = _normalize_bound(custom_start)
    end = _normalize_bound(custom_end)
    if start is None or end is None or start > end:
        return None, None
    return start, end

TAXONOMY_COLUMNS = ("Benchmark",)


def quote_as_of(history: pd.DataFrame | None):
    """Latest cleaned quote date before the weekday roll."""
    if history is None or history.empty or "DATE" not in history.columns:
        return None
    dates = pd.to_datetime(history["DATE"], errors="coerce").dropna()
    if dates.empty:
        return None
    return pd.Timestamp(dates.max()).normalize()


def london_trading_days(start, end) -> pd.DatetimeIndex:
    """Monday-to-Friday schedule.

    Exchange holidays are deliberately not filtered: a weekday with no quote
    carries the previous available price, which keeps funds with different
    market holidays aligned on the same schedule.
    """
    start_ts = pd.Timestamp(start).normalize()
    end_ts = pd.Timestamp(end).normalize()
    if end_ts < start_ts:
        return pd.DatetimeIndex([])
    return pd.bdate_range(start_ts, end_ts)



def previous_london_day(day) -> pd.Timestamp | None:
    """Latest weekday on or before ``day``."""
    if day is None or pd.isna(day):
        return None
    day_ts = pd.Timestamp(day).normalize()
    days = london_trading_days(day_ts - pd.Timedelta(days=14), day_ts)
    days = days[days <= day_ts]
    if len(days) == 0:
        return None
    return pd.Timestamp(days[-1]).normalize()


def last_completed_london_day(today=None):
    """The weekday before today. Today's realtime print is not included."""
    day = pd.Timestamp.today().normalize() if today is None else pd.Timestamp(today).normalize()
    return previous_london_day(day - pd.Timedelta(days=1))


def london_period_bounds(period: str, as_of):
    """First and last weekday inside a preset window."""
    start, end, notes = period_bounds(period, as_of)
    if notes or start is None or end is None:
        return None, None, notes
    days = london_trading_days(start, end)
    if len(days) == 0:
        return None, None, ["No weekday in this period."]
    return pd.Timestamp(days[0]).normalize(), pd.Timestamp(days[-1]).normalize(), []


def carry_london_quotes(group: pd.DataFrame, as_of) -> pd.DataFrame:
    """Spread on each weekday. A weekday with no quote keeps the previous one.

    Market holidays are not filtered, so a missing quote is carried forward.
    Nothing is filled before the first quote.
    """
    empty = pd.DataFrame(columns=["Spread", "Percent Spread"])
    if group is None or group.empty or as_of is None or "DATE" not in group.columns:
        return empty
    ordered = group.copy()
    ordered["DATE"] = pd.to_datetime(ordered["DATE"], errors="coerce")
    ordered = ordered.dropna(subset=["DATE"]).sort_values("DATE", kind="mergesort")
    ordered = ordered.drop_duplicates("DATE", keep="last")
    if ordered.empty:
        return empty
    as_of_ts = pd.Timestamp(as_of).normalize()
    ordered = ordered.loc[ordered["DATE"] <= as_of_ts]
    if ordered.empty:
        return empty
    if {"Bid", "Ask"}.issubset(ordered.columns):
        ordered["Mid"] = resolved_mid(
            ordered["Bid"],
            ordered["Ask"],
            ordered["Mid"] if "Mid" in ordered.columns else None,
        )
    ordered = ordered.set_index("DATE")
    days = london_trading_days(ordered.index.min(), as_of_ts)
    if len(days) == 0:
        return empty
    columns = [column for column in ("Bid", "Ask", "Mid", "Spread", "Percent Spread") if column in ordered.columns]
    carried = (
        ordered.loc[:, columns]
        .reindex(days.union(ordered.index))
        .sort_index()
        .ffill()
        .reindex(days)
    )
    if {"Bid", "Ask"}.issubset(carried.columns):
        previous_percent = (
            carried["Percent Spread"].copy()
            if "Percent Spread" in carried.columns
            else None
        )
        carried["Spread"] = absolute_quote_spread(carried["Bid"], carried["Ask"])
        bid_n = pd.to_numeric(carried["Bid"], errors="coerce")
        ask_n = pd.to_numeric(carried["Ask"], errors="coerce")
        mid = resolved_mid(
            carried["Bid"],
            carried["Ask"],
            carried["Mid"] if "Mid" in carried.columns else None,
        )
        spread_n = pd.to_numeric(carried["Spread"], errors="coerce")
        if previous_percent is not None:
            prev = pd.to_numeric(previous_percent, errors="coerce")
            mid_ok = pd.to_numeric(mid, errors="coerce")
            quote_missing = bid_n.isna() | ask_n.isna() | bid_n.le(0) | ask_n.le(0)
            restore = spread_n.isna() & quote_missing & prev.notna() & mid_ok.gt(0)
            if bool(restore.any()):
                carried["Spread"] = spread_n.mask(restore, prev / 100.0 * mid_ok)
        carried["Percent Spread"] = percent_quote_spread(carried["Spread"], mid)
    elif {"Percent Spread", "Mid"}.issubset(carried.columns):
        prev = pd.to_numeric(carried["Percent Spread"], errors="coerce")
        mid_ok = pd.to_numeric(carried["Mid"], errors="coerce")
        spread_n = (
            pd.to_numeric(carried["Spread"], errors="coerce")
            if "Spread" in carried.columns
            else pd.Series(pd.NA, index=carried.index)
        )
        restore = spread_n.isna() & prev.notna() & mid_ok.gt(0)
        if bool(restore.any()):
            carried["Spread"] = spread_n.mask(restore, prev / 100.0 * mid_ok)
            carried["Percent Spread"] = percent_quote_spread(carried["Spread"], mid_ok)
    return carried


def period_window_html(as_of, custom_start=None, custom_end=None) -> str:
    """Data-as-of line and the weekday windows used for each average."""
    session = previous_london_day(as_of)
    if session is None:
        return "<p><b>Data as of</b> unavailable. Quote history has no London session.</p>"
    parts = [f"<p><b>Data as of</b> {session.date().isoformat()}</p><p>"]
    windows = []
    for period in AVERAGE_PERIODS:
        start, end, notes = london_period_bounds(period, session)
        if notes or start is None or end is None:
            windows.append(f"{period}: unavailable")
            continue
        windows.append(
            f"{period}: {pd.Timestamp(start).date().isoformat()} to {pd.Timestamp(end).date().isoformat()}"
        )
    custom_start_ts, custom_end_ts = custom_bounds(custom_start, custom_end)
    if custom_start_ts is not None and custom_end_ts is not None:
        windows.append(
            f"{CUSTOM_PERIOD}: {custom_start_ts.date().isoformat()} to "
            f"{custom_end_ts.date().isoformat()}"
        )
    elif custom_start is not None or custom_end is not None:
        windows.append(f"{CUSTOM_PERIOD}: unavailable (check both dates)")
    parts.append(" · ".join(windows))
    parts.append("</p>")
    return "".join(parts)


def _mean(values: pd.Series) -> float:
    numeric = pd.to_numeric(values, errors="coerce")
    if int(numeric.notna().sum()) == 0:
        return pd.NA
    return float(numeric.mean())


def history_averages(
    history: pd.DataFrame | None,
    as_of,
    custom_start=None,
    custom_end=None,
) -> pd.DataFrame:
    """Mean spread percent for each preset window and Custom.

    The absolute average is not stored. Price levels differ across funds,
    so that average is not a comparable column.
    """
    periods = (*AVERAGE_PERIODS, CUSTOM_PERIOD)
    columns = ["ID"]
    for period in periods:
        columns.append(f"{period} Avg Spread %")
    if history is None or history.empty or "ID" not in history.columns:
        return pd.DataFrame(columns=columns)
    frame = history.copy()
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
    frame = frame.dropna(subset=["DATE"])
    if frame.empty or as_of is None:
        return pd.DataFrame(columns=columns)
    as_of_ts = previous_london_day(as_of)
    if as_of_ts is None:
        return pd.DataFrame(columns=columns)
    custom_start_ts, custom_end_ts = custom_bounds(custom_start, custom_end)
    custom_days = None
    if custom_start_ts is not None and custom_end_ts is not None:
        custom_days = london_trading_days(custom_start_ts, custom_end_ts)
    rows = []
    for identifier, group in frame.groupby("ID", sort=False):
        carried = carry_london_quotes(group, as_of_ts)
        row = {"ID": identifier}
        for period in periods:
            if period == CUSTOM_PERIOD:
                if (
                    custom_days is None
                    or len(custom_days) == 0
                    or carried.empty
                ):
                    row[f"{period} Avg Spread %"] = pd.NA
                    continue
                window = carried.loc[carried.index.isin(custom_days)]
            else:
                start, end, notes = london_period_bounds(period, as_of_ts)
                if notes or start is None or end is None or carried.empty:
                    row[f"{period} Avg Spread %"] = pd.NA
                    continue
                window = carried.loc[(carried.index >= start) & (carried.index <= end)]
            row[f"{period} Avg Spread %"] = _mean(
                window.get("Percent Spread", pd.Series(dtype=float))
            )
        rows.append(row)
    return pd.DataFrame(rows, columns=columns)


def display_columns() -> list[str]:
    columns = [
        "Fund Name",
        "Share Class",
        "ISIN",
        "Currency",
        "Fund AUM (USD mn)",
        "Share Class AUM (USD mn)",
        "Last",
        "Bid",
        "Ask",
        "Absolute Spread",
        "Percent Spread",
        "NAV Tracking Error",
    "Tracking Error",
    ]
    for period in (*AVERAGE_PERIODS, CUSTOM_PERIOD):
        columns.append(f"{period} Avg Spread %")
    columns.extend(TAXONOMY_COLUMNS)
    columns.append("Primary")
    return columns


def book_display(
    directory: pd.DataFrame | None,
    history: pd.DataFrame | None,
    custom_start=None,
    custom_end=None,
) -> pd.DataFrame:
    """One row per typed book share class. Peers stay out of this table.

    ``frame`` holds the typed ``IsinEntry`` rows only. Ticker, Strategy,
    Benchmark Index, and Long Name stay on the frame as hidden keys; the
    table columns come from ``display_columns()``, so Strategy is not a
    column and is used only by the top dropdown and the fund menu.
    """
    if directory is None or directory.empty:
        return pd.DataFrame()
    frame = directory.copy()
    if "List" in frame.columns:
        frame = frame.loc[frame["List"].fillna("Book").eq("Book")]
    if frame.empty:
        return frame
    if "Order" in frame.columns:
        frame["_order"] = pd.to_numeric(frame["Order"], errors="coerce")
        frame = frame.sort_values("_order", kind="mergesort", na_position="last")
        frame = frame.drop(columns=["_order"])
    as_of = last_completed_london_day()
    averages = history_averages(history, as_of, custom_start, custom_end)
    key = "Ticker" if "Ticker" in frame.columns else "ISIN"
    if not averages.empty and key in frame.columns:
        frame = frame.merge(averages, left_on=key, right_on="ID", how="left")
    for column in display_columns():
        if column not in frame.columns:
            frame[column] = pd.NA
    shown = frame.loc[:, display_columns()].copy()
    # The table hides these. The flow heatmap and the fund menu still use them.
    if "Ticker" in frame.columns:
        shown.insert(0, "Ticker", frame["Ticker"].to_numpy())
    if "Strategy" in frame.columns:
        shown["Strategy"] = frame["Strategy"].to_numpy()
    if "Benchmark Index" in frame.columns:
        shown["Benchmark Index"] = frame["Benchmark Index"].to_numpy()
    if "Long Name" in frame.columns:
        shown["Long Name"] = frame["Long Name"].to_numpy()
    return shown


def share_class_chart(
    history: pd.DataFrame | None,
    ticker: str,
    period: str,
    as_of,
    custom_start=None,
    custom_end=None,
) -> pd.DataFrame:
    """Daily London spread and spread percent for one typed ticker.

    The window is the same London session rule as the table averages.
    A session before the first quote stays blank. A weekend or bank
    holiday is not a row. This does not send a request.
    """
    empty = pd.DataFrame(columns=["DATE", "Spread", "Percent Spread"])
    key = "" if ticker is None else str(ticker).strip()
    if (
        history is None
        or history.empty
        or not key
        or key.lower() in {"nan", "none", "<na>"}
        or "ID" not in history.columns
    ):
        return empty
    frame = history.loc[history["ID"].astype(str).str.strip().str.casefold().eq(key.casefold())].copy()
    if frame.empty:
        return empty
    as_of_ts = previous_london_day(as_of)
    if as_of_ts is None:
        return empty
    carried = carry_london_quotes(frame, as_of_ts)
    if carried.empty or "Spread" not in carried.columns or "Percent Spread" not in carried.columns:
        return empty
    if str(period).strip() == CUSTOM_PERIOD:
        start, end = custom_bounds(custom_start, custom_end)
        if start is None or end is None:
            return empty
        days = london_trading_days(start, end)
        if len(days) == 0:
            return empty
        window = carried.loc[carried.index.isin(days), ["Spread", "Percent Spread"]]
    else:
        start, end, notes = london_period_bounds(period, as_of_ts)
        if notes or start is None or end is None:
            return empty
        window = carried.loc[(carried.index >= start) & (carried.index <= end), ["Spread", "Percent Spread"]]
    if window.empty:
        return empty
    out = window.reset_index()
    date_column = "DATE" if "DATE" in out.columns else out.columns[0]
    if date_column != "DATE":
        out = out.rename(columns={date_column: "DATE"})
    return out.loc[:, ["DATE", "Spread", "Percent Spread"]]
