"""HSBC book table, peer comparison, and a fund-flow heatmap."""

from __future__ import annotations

import asyncio
from functools import partial
from html import escape

import pandas as pd
import ipywidgets as widgets

from .book_view import (
    AVERAGE_PERIODS,
    CUSTOM_PERIOD,
    HISTORY_RANGES,
    book_display,
    clean_market_text,
    last_completed_london_day,
    london_period_bounds,
    market_numbers,
    missing_market_text,
    period_window_html,
    periods_within,
    preferred_long_name,
)
from .config import isin_book_frame
from .cache import CACHE_ENABLED
from .data import (
    SourceResult,
    fetch_parallel_histories,
    fetch_peer_facts,
    fetch_peer_links,
    fetch_share_class_directory,
    history_request_bounds,
    share_class_identities,
)
from .flow_view import (
    FLOW_PERIODS,
    combined_flow_matrix,
    flow_request_tickers,
    flow_row_labels,
    heatmap_size,
    hsbc_flow_matrix,
)
from .metrics import (
    peer_member_returns,
    peer_member_spreads,
    peer_metric_frame,
    return_comparison,
    spread_comparison,
    visible_book_columns,
)
from .peer_map import fund_name_key, map_rows
from .peers import FUND_INFO_GROUP, fund_menu_options, peer_detail_rows, visible_with_groups

DISPLAY_NAMES = {
    "Share Class": "Class Name",
    "Share Class AUM (USD mn)": "Class AUM (USD mn)",
    "Last": "PX_LAST",
    "Bid": "PX_BID",
    "Ask": "PX_ASK",
    "Absolute Spread": "Latest Spread",
    "Percent Spread": "Latest Spread %",
    "Tracking Error": "1Y Tracking Error (%)",
    "NAV Tracking Error": "1Y NAV Tracking Error (%)",
}
FROZEN_HEADERS = ("Fund Name", "Class Name")


def _display_name_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Copy whose Fund Name is the long name. The source frame keeps the typed key."""
    shown = frame.copy()
    if "Fund Name" not in shown.columns or "Long Name" not in shown.columns:
        return shown
    shown["Fund Name"] = [
        preferred_long_name(long_name, typed) or _cell_text(typed)
        for long_name, typed in zip(shown["Long Name"].tolist(), shown["Fund Name"].tolist())
    ]
    return shown


def _environment_markup(activity: str) -> str:
    """The Environment line. Processing is red. Idle is green."""
    color = "#c62828" if activity == "Processing" else "#1b7f37"
    return f"<p style=\"color:{color}\">Environment: {escape(activity)}</p>"


def _phase_markup(phase: str) -> str:
    """The first status word. Idle and Please Click Refresh are red. Refreshed is green."""
    if phase in {"Idle", "Please Click Refresh"}:
        color = "#c62828"
    elif phase == "Refreshed":
        color = "#1b7f37"
    else:
        return f"<b>{escape(phase)}</b>"
    return f"<b style=\"color:{color}\">{escape(phase)}</b>"


def _is_spread_column(name: str) -> bool:
    text = str(name)
    return text in {
        "Absolute Spread",
        "Percent Spread",
        "Spread",
        "Spread %",
        "Latest Spread",
        "Latest Spread %",
    } or text.endswith(" Avg Spread") or text.endswith(" Avg Spread %")


PRICE_COLUMNS = {"Last", "Bid", "Ask", "PX_LAST", "PX_BID", "PX_ASK"}


def _fmt(column: str, value) -> str:
    """Price columns keep quote precision. Spreads use 3 dp. Other numbers use 2 dp."""
    if missing_market_text(value):
        return ""
    text_column = str(column)
    if text_column in PRICE_COLUMNS:
        number = market_numbers(pd.Series([value]), allow_zero=False).iloc[0]
        if pd.isna(number):
            return ""
        return f"{float(number):.6g}"
    number = market_numbers(pd.Series([value]), allow_zero=True).iloc[0]
    if pd.notna(number):
        if _is_spread_column(text_column):
            return f"{float(number):.3f}"
        return f"{float(number):.2f}"
    text = clean_market_text(value)
    return text


def _format_frame(frame: pd.DataFrame) -> pd.DataFrame:
    pretty = frame.copy()
    for column in pretty.columns:
        pretty[column] = [_fmt(column, value) for value in pretty[column]]
    return pretty


def _fit_column_widths(frame: pd.DataFrame) -> dict[str, int]:
    widths = {}
    for column in frame.columns:
        header = len(str(column))
        longest = 0 if frame.empty else int(frame[column].astype(str).map(len).max())
        widths[str(column)] = min(480, max(64, max(header, longest) * 9 + 28))
    return widths


def _choices(values) -> list[str]:
    seen = []
    for value in values:
        text = "" if value is None or pd.isna(value) else str(value).strip()
        if not text or text.lower() in {"nan", "none", "<na>"} or text in seen:
            continue
        seen.append(text)
    return ["All", *seen]


def _clean_text(value) -> str:
    text = "" if value is None or (not isinstance(value, str) and pd.isna(value)) else str(value).strip()
    if text.lower() in {"", "nan", "none", "<na>"}:
        return ""
    return text


def _ticker_values(frame: pd.DataFrame | None) -> list[str]:
    if frame is None or frame.empty or "Ticker" not in frame.columns:
        return []
    found = []
    for value in frame["Ticker"].tolist():
        text = _clean_text(value)
        if text and text not in found:
            found.append(text)
    return found


def _benchmark_ids(frame: pd.DataFrame | None) -> list[str]:
    if frame is None or frame.empty or "Benchmark Index" not in frame.columns:
        return []
    found = []
    for value in frame["Benchmark Index"].tolist():
        text = _clean_text(value)
        if text and not missing_market_text(text) and text not in found:
            found.append(text)
    return found


def _benchmark_id(frame: pd.DataFrame | None, ticker: str) -> str:
    key = _clean_text(ticker).upper()
    if (
        not key
        or frame is None
        or frame.empty
        or "Ticker" not in frame.columns
        or "Benchmark Index" not in frame.columns
    ):
        return ""
    rows = frame.loc[frame["Ticker"].map(_clean_text).str.upper().eq(key)]
    if rows.empty:
        return ""
    text = _clean_text(rows["Benchmark Index"].iloc[0])
    if missing_market_text(text):
        return ""
    return text


def _row_choice_expr(flags: list[bool], yes: str, no: str) -> str | None:
    """0-based ``cell.row`` choice. An all-false list stays unstyled."""
    if not flags or not any(flags):
        return None
    choices = [yes if flag else no for flag in flags]

    def tree(lo: int, hi: int) -> str:
        if hi - lo == 1:
            return f"'{choices[lo]}'"
        mid = (lo + hi) // 2
        return f"(cell.row < {mid} ? {tree(lo, mid)} : {tree(mid, hi)})"

    return tree(0, len(choices))


def _grid_renderers(ipd, row_flags) -> dict:
    """Left-align Fund Name. An HSBC row is bold, and its name cell is tinted.

    Number cells do not take a color expression. On this Desktop, attaching
    one has blanked the values in that column.
    """
    try:
        left_name = ipd.TextRenderer(horizontal_alignment="left")
    except Exception:
        return {}
    aligned = {
        "renderers": {"Fund Name": left_name},
        "corner_renderer": left_name,
    }
    flags = [bool(flag) for flag in (row_flags or [])]
    font_source = _row_choice_expr(flags, "bold 12px sans-serif", "12px sans-serif")
    paint_source = _row_choice_expr(flags, "#1e3a2f", "#1b1f27")
    if font_source is None or paint_source is None:
        return aligned
    try:
        from ipydatagrid import VegaExpr
    except Exception:
        return aligned
    try:
        font = VegaExpr(font_source)
        paint = VegaExpr(paint_source)
        name = ipd.TextRenderer(
            horizontal_alignment="left",
            font=font,
            text_color="#e8eaed",
            background_color=paint,
        )
        return {
            "default_renderer": ipd.TextRenderer(font=font),
            "renderers": {"Fund Name": name},
            "corner_renderer": left_name,
        }
    except Exception:
        return aligned


def _frozen_table(frame: pd.DataFrame, fit_rows: bool = False, row_flags=None) -> str:
    """Fund Name stays fixed. The rest scrolls from the next column.

    ``fit_rows`` drops the fixed viewport so a chart under the table
    sits after the last row.
    """
    widths = _fit_column_widths(frame)
    headers = list(frame.columns)
    frozen_width = widths.get(headers[0], 120) if headers else 0
    head = []
    for index, name in enumerate(headers):
        sticky = "position:sticky;left:0;z-index:3;" if index == 0 else ""
        head.append(
            f"<th class='{'frozen' if index == 0 else ''}' style='{sticky}top:0;min-width:{widths[name]}px'>"
            f"{escape(str(name))}</th>"
        )
    flags = list(row_flags or [])
    body = []
    for position, (_, row) in enumerate(frame.iterrows()):
        marked = position < len(flags) and bool(flags[position])
        paint = "font-weight:700;background:#1e3a2f;" if marked else ""
        cells = []
        for index, name in enumerate(headers):
            sticky = "position:sticky;left:0;z-index:1;" if index == 0 else ""
            cells.append(
                f"<td style='{sticky}{paint}'>{escape(_fmt(name, row[name]))}</td>"
            )
        body.append("<tr>" + "".join(cells) + "</tr>")
    box = "overflow-x:auto;max-width:100%" if fit_rows else "overflow:auto;max-height:640px;max-width:100%"
    return (
        f"<div style='{box}'>"
        "<style>"
        "table.book{border-collapse:collapse;width:max-content}"
        "table.book th,table.book td{white-space:nowrap;padding:2px 8px;"
        "text-align:left;background:#1b1f27;color:#e8eaed;border:1px solid #333}"
        "table.book th{position:sticky;top:0;z-index:2}"
        "</style>"
        f"<table class='book'><thead><tr>{''.join(head)}</tr></thead>"
        f"<tbody>{''.join(body)}</tbody></table></div>"
        f"<!-- frozen-width:{frozen_width} -->"
    )


class ETFSpreadMonitor:
    """Refresh loads the book, the peer history, and the flow heatmap."""

    def __init__(self):
        self._events_bound = False
        self._syncing = False
        self._busy = False
        self._view_busy = False
        self._phase = "Idle"
        self._status_detail = "Choose a Strategy, then click Refresh."
        self._refresh_detail = ""
        self._source = pd.DataFrame()
        self._directory = pd.DataFrame()
        self._hsbc_flows = pd.DataFrame()
        self._hsbc_notes = ""
        self._notes = ""
        self._quote_history = pd.DataFrame()
        self._return_history = pd.DataFrame()
        self._nav_history = pd.DataFrame()
        self._peer_links = pd.DataFrame()
        self._peer_facts = pd.DataFrame()
        self._shown_rows = pd.DataFrame()
        self._chart_ticker = ""
        self._chart_isin = ""
        self._chart_fund = ""
        self._chart_label = ""
        self._peer_shown = pd.DataFrame()
        self._peer_chart_ticker = ""
        self._peer_chart_fund = ""
        self._peer_chart_label = ""
        self._suppress_chart_row = False
        self.update_button = widgets.Button(
            description="Refresh",
            button_style="primary",
            layout=widgets.Layout(width="110px", height="28px"),
        )
        self._peer_snapshot = pd.DataFrame()
        self._peer_history = pd.DataFrame()
        self._peer_returns = pd.DataFrame()
        self._peer_notes = ""
        self._collapsed_book: set[str] = set(AVERAGE_PERIODS)
        self._loaded_strategy = None
        self._loaded_range = "1Y"
        self._loaded_cache = bool(CACHE_ENABLED)
        self.status = widgets.HTML(
            "<p>" + _phase_markup("Idle") + " Choose a Strategy, then click Refresh.</p>"
            + _environment_markup("Idle")
        )
        self.flow_status = widgets.HTML(
            "<p>Refresh loads the flows. 1M and 3M are weekly. Longer periods are monthly.</p>"
        )
        self.strategy_filter = widgets.Dropdown(
            options=self._strategy_options(),
            value="All",
            description="Strategy",
            style={"description_width": "initial"},
        )
        self.history_range = widgets.Dropdown(
            options=list(HISTORY_RANGES),
            value="1Y",
            description="Max Data range",
            style={"description_width": "initial"},
        )
        self.use_cache = widgets.Checkbox(
            value=CACHE_ENABLED,
            description="Use cache",
            indent=False,
            tooltip=(
                "Serve settled history from the local cache and request only "
                "the missing days. Uncheck to request the whole window again."
            ),
        )
        self.fund_filter = widgets.Dropdown(
            options=fund_menu_options(isin_book_frame(), "All"),
            value="All",
            description="Fund",
            style={"description_width": "initial"},
        )
        self.show_spread = widgets.Checkbox(description="Spread", value=True, indent=False)
        self.show_return = widgets.Checkbox(description="Return", value=True, indent=False)
        self.show_nav = widgets.Checkbox(description="NAV Return", value=True, indent=False)
        self.peer_average = widgets.Dropdown(
            options=["Peers only", "HSBC + Peers"],
            value="Peers only",
            description="Peer Average",
            style={"description_width": "initial"},
        )
        self.hsbc_period = widgets.Dropdown(
            options=list(FLOW_PERIODS),
            value="1Y",
            description="Flows Period",
            style={"description_width": "initial"},
        )
        self.flow_mode = widgets.Dropdown(
            options=[("HSBC ETF", "HSBC ETF"), ("HSBC + Peers", "Peer group")],
            value="HSBC ETF",
            description="Show",
        )
        self.peer_fund = widgets.Dropdown(
            options=fund_menu_options(isin_book_frame(), "All"),
            value="All",
            description="Fund",
            style={"description_width": "initial"},
        )
        self.peer_status = widgets.HTML(
            "<p>The typed HSBC rows and their Top 5 Peers. Fund follows the Strategy above.</p>"
        )
        self.peer_table = widgets.VBox()
        self.table = widgets.VBox()
        self.chart_period = widgets.Dropdown(
            options=[*AVERAGE_PERIODS, CUSTOM_PERIOD],
            value="1Y",
            description="Chart Period",
            style={"description_width": "initial"},
        )
        end_default = last_completed_london_day()
        start_default = end_default - pd.Timedelta(days=30)
        self.custom_check = widgets.Checkbox(
            description="Custom", value=False, indent=False
        )
        self.custom_start = widgets.DatePicker(
            description="Start",
            value=start_default.date(),
            disabled=True,
            layout=widgets.Layout(width="155px"),
        )
        self.custom_end = widgets.DatePicker(
            description="End",
            value=end_default.date(),
            disabled=True,
            layout=widgets.Layout(width="155px"),
        )
        self.chart_row = widgets.Dropdown(
            options=[("(click a row)", -1)],
            description="Share class",
        )
        self.chart_row.layout.display = "none"
        self.chart_status = widgets.HTML("<p>Click a share class to plot its daily spread.</p>")
        self.chart_output = widgets.Output()
        self.peer_chart_period = widgets.Dropdown(
            options=[*AVERAGE_PERIODS, CUSTOM_PERIOD],
            value="1Y",
            description="Chart Period",
            style={"description_width": "initial"},
        )
        self.peer_chart_row = widgets.Dropdown(
            options=[("(click a row)", -1)],
            description="Share class",
        )
        self.peer_chart_row.layout.display = "none"
        self.peer_chart_status = widgets.HTML("<p>Click a row to plot it.</p>")
        self.peer_chart_output = widgets.Output()
        self.flow_output = widgets.Output()
        self._bind_events()

    def _bind_events(self) -> None:
        if self._events_bound:
            return
        self.update_button.on_click(self._on_update)
        self.peer_fund.observe(self._on_peer_controls, names="value")
        self.hsbc_period.observe(self._on_flow_controls, names="value")
        self.flow_mode.observe(self._on_flow_controls, names="value")
        self.chart_period.observe(self._on_chart_period, names="value")
        self.peer_chart_period.observe(self._on_chart_period, names="value")
        for widget in (
            self.custom_check,
            self.custom_start,
            self.custom_end,
            self.show_spread,
            self.show_return,
            self.show_nav,
            self.peer_average,
        ):
            widget.observe(self._on_table_controls, names="value")
        self.chart_row.observe(self._on_chart_row, names="value")
        self.peer_chart_row.observe(self._on_peer_chart_row, names="value")
        self.fund_filter.observe(self._on_book_controls, names="value")
        self.strategy_filter.observe(self._on_pull_choice, names="value")
        self.history_range.observe(self._on_pull_choice, names="value")
        self.use_cache.observe(self._on_pull_choice, names="value")
        self._events_bound = True

    def render(self):
        book = widgets.VBox(
            [
                widgets.HTML("<h3 style='margin:0'>HSBC ETF</h3>"),
                widgets.HBox(
                    [
                        self.fund_filter,
                        self.show_spread,
                        self.show_return,
                        self.show_nav,
                        self.peer_average,
                    ]
                ),
                widgets.HBox(
                    [
                        self.custom_check,
                        self.custom_start,
                        self.custom_end,
                    ]
                ),
                self.table,
                self.chart_row,
                widgets.HBox([self.chart_period]),
                self.chart_status,
                self.chart_output,
            ]
        )
        flows = widgets.VBox(
            [
                widgets.HTML(
                    "<h3 style='margin:0'>Flows</h3>"
                    "<p>Refresh loads this heatmap. 1M and 3M are weekly. Longer periods are monthly. "
                    "HSBC + Peers is one line per fund: that fund's HSBC ETF and its Top 5 Peers added together.</p>"
                ),
                widgets.HBox([self.hsbc_period, self.flow_mode]),
                self.flow_status,
                self.flow_output,
            ]
        )
        peers = widgets.VBox(
            [
                widgets.HTML(
                    "<h3 style='margin:0'>Peers Details</h3>"
                    "<p>The IsinEntry rows of the chosen fund, then each fund's Top 5 Peers. "
                    "Spread, Return, NAV Return, and the periods, including Custom, follow the HSBC ETF tab. "
                    "The HSBC rows are the typed share classes; the peer rows are their primary peers. "
                    "The charts below follow the HSBC ETF tab and add one line for each Top 5 Peer.</p>"
                ),
                widgets.HBox([self.peer_fund]),
                self.peer_status,
                self.peer_table,
                self.peer_chart_row,
                widgets.HBox([self.peer_chart_period]),
                self.peer_chart_status,
                self.peer_chart_output,
            ]
        )
        self.tabs = widgets.Tab(children=[book, flows, peers])
        self.tabs.set_title(0, "HSBC ETF")
        self.tabs.set_title(1, "Flows")
        self.tabs.set_title(2, "Peers Details")
        self.tabs.layout.display = "none"
        return widgets.VBox(
            [
                self.status,
                widgets.HBox(
                    [
                        self.strategy_filter,
                        self.history_range,
                        self.use_cache,
                        self.update_button,
                    ],
                    layout=widgets.Layout(align_items="center"),
                ),
                self.tabs,
            ]
        )

    def _show_results(self, visible: bool) -> None:
        self.tabs.layout.display = None if visible else "none"

    def _strategy_options(self) -> list[str]:
        """All, plus the strategy text typed as the fifth IsinEntry field."""
        book = isin_book_frame()
        if book is None or book.empty or "Strategy" not in book.columns:
            return ["All"]
        return _choices(book["Strategy"].tolist())

    def _settings_text(self) -> str:
        metrics = []
        if self.show_spread.value:
            metrics.append("Spread")
        if self.show_return.value:
            metrics.append("Return")
        if self.show_nav.value:
            metrics.append("NAV Return")
        metric = " + ".join(metrics) if metrics else "no metric"
        periods = ", ".join(self._selected_periods()) or "no period"
        average = self.peer_average.value or "Peers only"
        strategy = self.strategy_filter.value or "All"
        loaded = self._loaded_range or "1Y"
        cache_text = "cache on" if self.use_cache.value else "cache off"
        return (
            f"Showing the typed IsinEntry classes; {metric}; {periods}; strategy {strategy}; "
            f"history {loaded}; {cache_text}; "
            f"flow {self.flow_mode.value}; peers {self.peer_fund.value}; average {average}."
        )

    def _set_status(self, phase: str, detail: str | None = None) -> None:
        self._phase = phase
        if detail is not None:
            self._status_detail = detail
        if phase == "Refreshed" and detail is not None:
            self._refresh_detail = detail
        shown = self._status_detail
        if len(shown) > 700:
            shown = shown[:700].rstrip() + " …"
        detail_text = f" {escape(shown)}" if shown else ""
        activity = "Processing" if self._busy or self._view_busy else "Idle"
        self.status.value = (
            f"<p>{_phase_markup(phase)}{detail_text} {escape(self._settings_text())}</p>"
            + _environment_markup(activity)
        )

    def _show_activity(self, work) -> None:
        """Paint Processing, then redraw from the cache.

        A published app does not show the notebook kernel indicator. The
        status line is updated and the handler returns so that line can
        paint before the cache work runs.
        """
        if self._syncing or self._busy or self._view_busy:
            return
        self._view_busy = True
        self._set_status(self._phase or "Idle")

        def _later() -> None:
            try:
                work()
            except Exception as exc:
                self._view_busy = False
                self._set_status("Error", str(exc))
                return
            self._view_busy = False
            self._set_status(self._phase or "Idle")

        try:
            asyncio.get_running_loop().call_later(0.05, _later)
        except RuntimeError:
            _later()

    def _period_choices(self) -> list[str]:
        """Periods inside the loaded history, plus Custom while that checkbox is on."""
        periods = periods_within(self._loaded_range)
        if self.custom_check.value:
            periods.append(CUSTOM_PERIOD)
        return periods

    def _apply_loaded_range(self) -> None:
        """Period menus follow the history Refresh actually loaded."""
        allowed = periods_within(self._loaded_range)
        chart_options = [*allowed, CUSTOM_PERIOD]
        self._syncing = True
        try:
            for dropdown, options in (
                (self.chart_period, chart_options),
                (self.peer_chart_period, chart_options),
                (self.hsbc_period, allowed),
            ):
                current = dropdown.value
                dropdown.options = list(options)
                dropdown.value = current if current in options else allowed[-1]
        finally:
            self._syncing = False

    def _selected_periods(self) -> list[str]:
        """Periods whose columns are open. The buttons start closed."""
        return [period for period in self._period_choices() if period not in self._collapsed_book]

    def _custom_dates(self):
        """Inclusive custom dates from the two pickers, or (None, None)."""
        if not self.custom_check.value:
            return None, None
        start = self.custom_start.value
        end = self.custom_end.value
        if start is None or end is None or start > end:
            return None, None
        return start, end

    def _on_table_controls(self, _change=None) -> None:
        """Redraw the book and the chart from the cache. No request is sent."""
        self._show_activity(self._redraw_table_controls)

    def _redraw_table_controls(self) -> None:
        enabled = bool(self.custom_check.value)
        self.custom_start.disabled = not enabled
        self.custom_end.disabled = not enabled
        if not enabled:
            self._collapsed_book.discard(CUSTOM_PERIOD)
        if enabled:
            start, end = self._custom_dates()
            if start is None or end is None:
                self._shown_rows = pd.DataFrame()
                self._chart_ticker = ""
                self.table.children = (
                    widgets.HTML("<p>Custom period needs a start date on or before the end date.</p>"),
                )
                self.chart_output.clear_output()
                self.peer_chart_output.clear_output()
                self.chart_status.value = (
                    "<p>Custom period needs a start date on or before the end date.</p>"
                )
                self.peer_chart_status.value = (
                    "<p>Custom period needs a start date on or before the end date.</p>"
                )
                self._set_status(
                    "Error",
                    "Custom period needs a start date on or before the end date.",
                )
                return
        try:
            self._reapply_book_view()
            self._redraw_peers()
            self._draw_spread_chart()
            self._draw_peer_chart()
            phase = self._phase if self._phase not in {"", "Idle", "Error"} else "Refreshed"
            self._set_status(phase)
        except Exception as exc:
            self._set_status("Error", str(exc))

    def _include_anchor(self) -> bool:
        return self.peer_average.value == "HSBC + Peers"

    def _on_peer_controls(self, _change=None) -> None:
        self._show_activity(self._redraw_peer_controls)

    def _redraw_peer_controls(self) -> None:
        try:
            self._redraw_peers()
            phase = self._phase if self._phase not in {"", "Idle", "Error"} else "Refreshed"
            self._set_status(phase)
        except Exception as exc:
            self._set_status("Error", str(exc))

    def _reapply_book_view(self) -> None:
        start, end = self._custom_dates()
        self._source = book_display(
            self._directory, self._quote_history, start, end
        )
        self._refresh_filters()
        self._redraw_table()

    def _choice_frame(self) -> pd.DataFrame:
        loaded = self._source
        if loaded is not None and not loaded.empty and "Fund Name" in loaded.columns:
            return loaded
        return isin_book_frame()

    def _apply_fund_choices(self) -> None:
        """Fund lists follow the Strategy above. A missing choice returns to All."""
        names = fund_menu_options(self._choice_frame(), self.strategy_filter.value)
        self._syncing = True
        try:
            values = [item[1] if isinstance(item, tuple) else item for item in names]
            for dropdown in (self.fund_filter, self.peer_fund):
                current = dropdown.value
                dropdown.options = names
                dropdown.value = current if current in values else "All"
        finally:
            self._syncing = False

    def _group_bar(self, periods, collapsed: set[str], callback):
        buttons = []
        info_closed = FUND_INFO_GROUP in collapsed
        info = widgets.Button(
            description=f"{FUND_INFO_GROUP} {'+' if info_closed else '-'}",
            layout=widgets.Layout(width="130px"),
        )
        info.on_click(partial(callback, FUND_INFO_GROUP))
        buttons.append(info)
        for period in periods:
            closed = period in collapsed
            button = widgets.Button(
                description=f"{period} {'+' if closed else '-'}",
                layout=widgets.Layout(width="88px"),
            )
            button.on_click(partial(callback, period))
            buttons.append(button)
        if not buttons:
            return widgets.HTML("")
        return widgets.HBox(buttons)

    def _toggle_book_group(self, period: str, _button) -> None:
        self._show_activity(lambda: self._apply_period_toggle(period))

    def _apply_period_toggle(self, period: str) -> None:
        self._toggle_group(self._collapsed_book, period)
        self._redraw_table()
        self._redraw_peers()

    def _toggle_group(self, collapsed: set[str], period: str) -> None:
        if period in collapsed:
            collapsed.discard(period)
        else:
            collapsed.add(period)

    def _redraw_peers(self, _change=None) -> None:
        header = f"<p>{escape(self._peer_notes)}</p>" if self._peer_notes else ""
        periods = self._selected_periods()
        bar = self._group_bar(self._period_choices(), self._collapsed_book, self._toggle_book_group)
        view = self._peers_source()
        if view is None or view.empty:
            self._peer_shown = pd.DataFrame()
            self.peer_table.children = (widgets.HTML(header + "<p>No Top 5 Peers rows yet.</p>"), bar)
            return
        view = self._with_peer_metrics(view, periods, self._custom_dates())
        detail = peer_detail_rows(
            view,
            self._peer_links,
            self._quote_history,
            self._return_history,
            *self._custom_dates(),
            self._nav_history,
            self._peer_facts,
        )
        if detail is None or detail.empty:
            self._peer_shown = pd.DataFrame()
            self.peer_table.children = (widgets.HTML(header + "<p>No Top 5 Peers rows yet.</p>"), bar)
            return
        columns = visible_with_groups(
            visible_book_columns(
                periods,
                bool(self.show_spread.value),
                bool(self.show_return.value),
                bool(self.show_nav.value),
            ),
            self._collapsed_book,
        )
        columns = [column for column in columns if column in detail.columns]
        named = _display_name_frame(detail)
        show = named.loc[:, columns].rename(columns=DISPLAY_NAMES) if columns else named.iloc[:, 0:0]
        self._peer_shown = detail.reset_index(drop=True)
        hsbc_flags = self._hsbc_row_flags(detail)
        if self._peer_chart_ticker:
            keys = self._peer_shown["Ticker"].map(_clean_text).str.upper() if "Ticker" in self._peer_shown.columns else pd.Series(dtype=str)
            if self._peer_chart_ticker.upper() not in set(keys):
                self._peer_chart_ticker = ""
                self._peer_chart_fund = ""
                self._peer_chart_label = ""
        _grid, body = self._rendered_table(
            show,
            click=True,
            on_click=self._on_peer_click,
            row_flags=hsbc_flags,
        )
        self._set_peer_chart_rows(_grid is None)
        self.peer_table.children = (widgets.HTML(header), bar, body)

    def _on_update(self, _event) -> None:
        book = self._strategy_book()
        self._set_busy(True)
        self._show_results(False)
        self._loaded_strategy = None
        self._set_status("Loading", "Reading the HSBC book.")
        self._peer_snapshot = pd.DataFrame()
        self._peer_history = pd.DataFrame()
        self._peer_returns = pd.DataFrame()
        self._peer_notes = ""
        self.peer_table.children = ()
        self.peer_status.value = (
            "<p>The typed HSBC rows and their Top 5 Peers. Fund follows the Strategy above.</p>"
        )
        try:
            if book is None or book.empty:
                self._source = pd.DataFrame()
                self._loaded_strategy = self.strategy_filter.value
                self._loaded_cache = bool(self.use_cache.value)
                self._loaded_range = str(self.history_range.value or "1Y").strip() or "1Y"
                detail = "This Strategy has no rows in ISIN_BOOK."
                self._set_status("Refreshed", detail)
                return
            directory = fetch_share_class_directory(
                book,
                progress=self._show_progress,
                include_peers=False,
            )
            identifiers = _ticker_values(book)
            fund_names = []
            if "Fund Name" in book.columns:
                fund_names = [str(value) for value in book["Fund Name"].tolist()]
            peer_notes: list[str] = []
            try:
                peer_notes = self._resolve_peers(fund_names)
            except Exception as exc:
                self._peer_links = pd.DataFrame()
                peer_notes = [f"Peer list failed: {exc}"]
            directory_frame = pd.DataFrame()
            if directory is not None and directory.observations is not None:
                directory_frame = directory.observations
            peer_tickers = _ticker_values(self._peer_links)
            self._peer_facts = pd.DataFrame()
            try:
                facts = fetch_peer_facts(self._peer_links, progress=self._show_progress)
                if facts is not None and facts.observations is not None:
                    self._peer_facts = facts.observations
                if facts is not None:
                    peer_notes.extend(list(facts.errors))
            except Exception as exc:
                self._peer_facts = pd.DataFrame()
                peer_notes.append(f"Peer details failed: {exc}")
            quote_ids = list(dict.fromkeys([*identifiers, *peer_tickers]))
            return_ids = list(
                dict.fromkeys(
                    [
                        *quote_ids,
                        *_benchmark_ids(directory_frame),
                        *_benchmark_ids(self._peer_facts),
                    ]
                )
            )
            flow_ids = flow_request_tickers(directory_frame, peer_tickers)
            if not flow_ids:
                flow_ids = list(dict.fromkeys(identifiers))
            # Identifier -> ISIN for this run. The cache discards a stored
            # series whose ticker now resolves to a different security, so a
            # changed primary share class or a re-pointed peer starts fresh.
            identities = share_class_identities(
                directory_frame, self._peer_links, self._peer_facts
            )
            as_of = last_completed_london_day()
            range_key = str(self.history_range.value or "1Y").strip()
            if range_key not in HISTORY_RANGES:
                range_key = "1Y"
            self._loaded_range = range_key
            self._apply_loaded_range()
            hist_start, hist_end = history_request_bounds(range_key, as_of)
            if hist_start is None or hist_end is None:
                start, end, window_notes = london_period_bounds("5Y", as_of)
            else:
                start, end, window_notes = hist_start, hist_end, []
            if window_notes or start is None or end is None:
                quotes, returns, _skipped, navs = fetch_parallel_histories(
                    quote_ids,
                    return_ids,
                    None,
                    None,
                    None,
                    progress=self._show_progress,
                    history_start=hist_start,
                    history_end=hist_end,
                    nav_ids=quote_ids,
                    as_of=as_of,
                    use_cache=bool(self.use_cache.value),
                    identities=identities,
                )
                flows = SourceResult(
                    pd.DataFrame(columns=["ID", "DATE", "Flow"]),
                    list(window_notes) or ["The five-year window is unavailable."],
                )
            else:
                quotes, returns, flows, navs = fetch_parallel_histories(
                    quote_ids,
                    return_ids,
                    flow_ids,
                    start,
                    end,
                    progress=self._show_progress,
                    history_start=hist_start,
                    history_end=hist_end,
                    nav_ids=quote_ids,
                    as_of=as_of,
                    use_cache=bool(self.use_cache.value),
                    identities=identities,
                )
            self._return_history = (
                returns.observations if returns is not None and returns.observations is not None else pd.DataFrame()
            )
            self._nav_history = (
                navs.observations if navs is not None and navs.observations is not None else pd.DataFrame()
            )
            self._hsbc_flows = (
                flows.observations if flows is not None and flows.observations is not None else pd.DataFrame()
            )
            self._hsbc_notes = " ".join(flows.errors) if flows is not None else ""
            self._publish(directory, quotes)
            self._notes = " ".join(
                part
                for part in (
                    self._notes,
                    *peer_notes,
                    *(returns.errors if returns is not None else []),
                    *(navs.errors if navs is not None else []),
                )
                if part
            )
            if self._hsbc_flows.empty:
                self._show_hsbc_progress("Fund flow returned no rows.")
            else:
                self._show_hsbc_progress("Fund flow loaded. Change the period or the show mode to slice it.")
            if self._source is None or self._source.empty:
                detail = self._notes or "No book rows were returned. Check the uploaded config and the request log."
                self._set_status("Refreshed", detail)
            else:
                self._redraw_peers()
                if self._chart_ticker:
                    self._draw_spread_chart()
                if self._peer_chart_ticker:
                    self._draw_peer_chart()
                self._loaded_strategy = self.strategy_filter.value
                self._loaded_cache = bool(self.use_cache.value)
                self._show_results(True)
                self._set_status(
                    "Refreshed",
                    f"{len(self._source)} share class row(s). {self._notes}".strip(),
                )
        except Exception as exc:
            self._source = pd.DataFrame()
            self._shown_rows = pd.DataFrame()
            self._chart_ticker = ""
            self._chart_isin = ""
            self._chart_fund = ""
            self._set_chart_rows(False)
            self._directory = pd.DataFrame()
            self._quote_history = pd.DataFrame()
            self._return_history = pd.DataFrame()
            self._nav_history = pd.DataFrame()
            self._peer_links = pd.DataFrame()
            self._peer_facts = pd.DataFrame()
            self._hsbc_flows = pd.DataFrame()
            self._show_results(False)
            self.table.children = (
                widgets.HTML("<p>Refresh failed. Previous rows were cleared.</p>"),
            )
            self.chart_output.clear_output()
            self.peer_chart_output.clear_output()
            self.chart_status.value = "<p>Refresh failed. Click a row after a successful Refresh.</p>"
            self.peer_chart_status.value = "<p>Refresh failed. Click a row after a successful Refresh.</p>"
            self._set_status("Error", str(exc))
        finally:
            self._set_busy(False)

    def _resolve_peers(self, fund_names: list[str] | None = None) -> list[str]:
        """Resolve the manual map. Quote history is loaded with the book."""
        if not map_rows():
            self._peer_links = pd.DataFrame()
            return ["peer_map.py has no ISINs."]
        linked = fetch_peer_links(progress=self._show_progress, fund_names=fund_names)
        self._peer_links = (
            linked.observations if linked is not None and linked.observations is not None else pd.DataFrame()
        )
        if linked is None:
            return []
        return list(linked.errors)

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        self.update_button.disabled = busy
        for widget in (
            self.fund_filter,
            self.strategy_filter,
            self.history_range,
            self.show_spread,
            self.show_return,
            self.show_nav,
            self.peer_average,
            self.hsbc_period,
            self.flow_mode,
            self.peer_fund,
            self.chart_period,
            self.peer_chart_period,
            self.peer_chart_row,
            self.custom_check,
            self.custom_start,
            self.custom_end,
            self.chart_row,
        ):
            widget.disabled = busy
        if not busy:
            enabled = bool(self.custom_check.value)
            self.custom_start.disabled = not enabled
            self.custom_end.disabled = not enabled
        self._set_status(self._phase or "Idle")

    def _strategy_book(self) -> pd.DataFrame:
        """Typed rows for the Strategy chosen before Refresh."""
        book = isin_book_frame()
        if book is None or book.empty:
            return pd.DataFrame() if book is None else book
        chosen = str(self.strategy_filter.value or "All").strip() or "All"
        if chosen != "All" and "Strategy" in book.columns:
            book = book.loc[book["Strategy"].astype(str).eq(chosen)].copy()
        return book

    def _on_pull_choice(self, _change=None) -> None:
        """Strategy, Max Data range, and Use cache apply on the next Refresh."""
        if self._syncing or self._busy:
            return
        if self._loaded_strategy is None:
            return
        strategy_same = self.strategy_filter.value == self._loaded_strategy
        range_key = str(self.history_range.value or "1Y").strip() or "1Y"
        if (
            strategy_same
            and range_key == self._loaded_range
            and bool(self.use_cache.value) == self._loaded_cache
        ):
            self._show_results(True)
            self._set_status("Refreshed", self._refresh_detail)
            return
        if not strategy_same:
            self._show_results(False)
        self._set_status("Please Click Refresh", "")

    def _on_book_controls(self, _change=None) -> None:
        """The Fund menu redraws the HSBC table. The heatmap uses that fund too."""
        self._show_activity(self._redraw_book_controls)

    def _on_flow_controls(self, change=None) -> None:
        self._show_activity(lambda: self._draw_flow(change))

    def _redraw_book_controls(self) -> None:
        self._redraw_table()
        self._draw_spread_chart()
        self._draw_peer_chart()
        try:
            self._draw_flow()
        except Exception as exc:
            self.flow_status.value = f"<p>Error: {escape(str(exc))}</p>"
        phase = self._phase if self._phase not in {"", "Idle"} else "Refreshed"
        self._set_status(phase)

    def _show_hsbc_progress(self, message: str) -> None:
        text = escape(message)
        if self._hsbc_notes:
            text += " " + escape(self._hsbc_notes)
        self.flow_status.value = f"<p>{text}</p>"

    def _draw_flow(self, _change=None) -> None:
        """Slice the cached flow. The show mode does not send a request."""
        view = self._flow_book()
        as_of = last_completed_london_day()
        if self.flow_mode.value == "Peer group":
            matrix, notes = combined_flow_matrix(
                self._hsbc_flows,
                self._peer_links,
                view,
                self.hsbc_period.value,
                as_of,
            )
        else:
            matrix, notes = hsbc_flow_matrix(
                self._hsbc_flows,
                view,
                self.hsbc_period.value,
                as_of,
            )
        blocks = [note for note in notes if note]
        if self._hsbc_notes:
            blocks.append(self._hsbc_notes)
        labels = flow_row_labels(view)
        if matrix is not None and not matrix.empty and labels:
            matrix = matrix.rename(index=lambda name: labels.get(str(name), name))
        figure = _show_heatmap(
            matrix,
            self.hsbc_period.value,
            "USD",
            "Fund",
        )
        if figure is not None:
            blocks.append(figure)
        _put_output(self.flow_output, blocks)
        if _change is not None:
            phase = self._phase if self._phase not in {"", "Idle", "Loading"} else "Refreshed"
            self._set_status(phase)

    def _show_progress(self, message: str) -> None:
        self._set_status("Loading", message)

    def _publish(self, directory, history) -> None:
        notes = []
        frame = pd.DataFrame()
        if directory is not None:
            notes.extend(directory.errors)
            frame = directory.observations if directory.observations is not None else frame
        history_frame = pd.DataFrame()
        if history is not None:
            notes.extend(history.errors)
            if history.observations is not None:
                history_frame = history.observations
        self._directory = frame
        self._source = book_display(frame, history_frame, *self._custom_dates())
        self._quote_history = history_frame
        self._notes = " ".join(notes)
        self._refresh_filters()
        self._redraw_table()
        if self._chart_ticker:
            self._draw_spread_chart()
        if self._peer_chart_ticker:
            self._draw_peer_chart()
        try:
            self._draw_flow()
        except Exception as exc:
            self.flow_status.value = f"<p>Error: {escape(str(exc))}</p>"

    def _refresh_filters(self) -> None:
        strategies = self._strategy_options()
        self._syncing = True
        try:
            self.strategy_filter.options = strategies
            if self.strategy_filter.value not in strategies:
                self.strategy_filter.value = "All"
        finally:
            self._syncing = False
        self._apply_fund_choices()

    def _limited_book(self, fund: str) -> pd.DataFrame:
        """The typed IsinEntry rows for the chosen Strategy and Fund.

        The frame already holds the typed rows only, so there is no primary
        filter and no row is swapped for another share class of that fund.
        """
        frame = self._source
        if frame is None or frame.empty:
            return pd.DataFrame() if frame is None else frame
        view = frame
        strategy = self.strategy_filter.value
        if strategy and strategy != "All" and "Strategy" in view.columns:
            view = view.loc[view["Strategy"].astype(str).eq(strategy)]
        if fund and fund != "All" and "Fund Name" in view.columns:
            view = view.loc[view["Fund Name"].astype(str).eq(fund)]
        return view

    def _filtered_book(self) -> pd.DataFrame:
        """HSBC ETF table. The typed IsinEntry rows only."""
        return self._limited_book(self.fund_filter.value)

    def _flow_book(self) -> pd.DataFrame:
        """Flows. One later step keeps the Primary Yes ticker per fund.

        The fund menu still applies. There is no share-class switch on this tab.
        """
        return self._limited_book(self.fund_filter.value)

    def _peers_source(self) -> pd.DataFrame:
        """The typed HSBC rows for the Peers Details fund, after Strategy."""
        return self._limited_book(self.peer_fund.value)

    def _with_peer_metrics(self, view: pd.DataFrame, periods=None, custom=None) -> pd.DataFrame:
        if periods is None:
            periods = self._selected_periods()
        if custom is None:
            custom = self._custom_dates()
        start, end = custom
        metrics = peer_metric_frame(
            view,
            self._peer_links,
            self._quote_history,
            self._return_history,
            periods,
            self._include_anchor(),
            last_completed_london_day(),
            start,
            end,
            self._nav_history,
        )
        if metrics is None or metrics.empty or "Ticker" not in view.columns:
            return view
        drop = [
            column
            for column in view.columns
            if "Peer Avg" in str(column) or str(column).endswith(" Return %")
        ]
        base = view.drop(columns=drop, errors="ignore")
        return base.merge(metrics, on="Ticker", how="left")

    def _chart_peers(self, fund: str | None = None) -> list[str]:
        links = self._peer_links
        fund = fund_name_key(self._chart_fund if fund is None else fund)
        if (
            links is None
            or links.empty
            or not fund
            or "Fund Name" not in links.columns
            or "Ticker" not in links.columns
        ):
            return []
        rows = links.loc[links["Fund Name"].map(fund_name_key).eq(fund)]
        return _ticker_values(rows)

    def _redraw_table(self, _change=None) -> None:
        as_of = last_completed_london_day()
        header = period_window_html(as_of, *self._custom_dates())
        if self._notes:
            header += f"<p>{escape(self._notes)}</p>"
        view = self._filtered_book()
        if view is None or view.empty:
            self._shown_rows = pd.DataFrame()
            self._set_chart_rows(False)
            self.table.children = (
                widgets.HTML(
                    header
                    + "<p>No book rows yet. Type the share classes into ISIN_BOOK in config.py "
                    "and press Refresh.</p>"
                ),
            )
            return
        view = self._with_peer_metrics(view)
        self._shown_rows = view.reset_index(drop=True)
        periods = self._selected_periods()
        columns = [
            column
            for column in visible_with_groups(
                visible_book_columns(
                    periods,
                    bool(self.show_spread.value),
                    bool(self.show_return.value),
                    bool(self.show_nav.value),
                ),
                self._collapsed_book,
            )
            if column in self._shown_rows.columns
        ]
        named = _display_name_frame(self._shown_rows)
        show = named.loc[:, columns].rename(columns=DISPLAY_NAMES) if columns else named.iloc[:, 0:0]
        if show.empty:
            self._shown_rows = pd.DataFrame()
            self._set_chart_rows(False)
            self.table.children = (widgets.HTML(header + "<p>No rows match these filters.</p>"),)
            return
        bar = self._group_bar(self._period_choices(), self._collapsed_book, self._toggle_book_group)
        has_grid, body = self._rendered_table(show, click=True)
        self._set_chart_rows(not has_grid)
        self.table.children = (widgets.HTML(header), bar, body)

    def _hsbc_row_flags(self, detail: pd.DataFrame) -> list[bool]:
        """Peers Details only. A row is an HSBC line when its ticker is on the book."""
        if detail is None or detail.empty or "Ticker" not in detail.columns:
            return []
        book = self._source
        if book is None or book.empty or "Ticker" not in book.columns:
            return [False] * len(detail)
        keys = {
            _clean_text(value).upper()
            for value in book["Ticker"].tolist()
            if _clean_text(value)
        }
        return [_clean_text(value).upper() in keys for value in detail["Ticker"].tolist()]

    def _rendered_table(self, show: pd.DataFrame, click: bool, on_click=None, row_flags=None):
        """Grid when ipydatagrid is present. Otherwise the sticky Fund Name table."""
        pretty = _format_frame(show.reset_index(drop=True))
        flags = list(row_flags) if row_flags is not None else None
        if flags is not None and len(flags) != len(pretty):
            flags = None
        grid = self._spread_grid(pretty, click=click, on_click=on_click, row_flags=flags)
        if grid is None:
            return False, widgets.HTML(_frozen_table(pretty, fit_rows=True, row_flags=flags))
        return True, grid

    def _spread_grid(self, show: pd.DataFrame, click: bool = True, on_click=None, row_flags=None):
        """Grid whose height follows the row count. Fund Name is the row header."""
        try:
            import ipydatagrid as ipd
        except ImportError:
            return None
        frame = show.reset_index(drop=True)
        header_size = 64
        if "Fund Name" in frame.columns:
            labels = [str(value) for value in frame["Fund Name"].tolist()]
            longest = max([len("Fund Name"), *[len(label) for label in labels]], default=12)
            header_size = min(360, max(140, longest * 8 + 28))
            frame = frame.set_index("Fund Name")
            frame.index.name = "Fund Name"
        widths = _fit_column_widths(frame)
        widths.pop("Fund Name", None)
        height = min(36 + 28 * max(len(frame), 1) + 8, 12000)
        layout = {"height": f"{height}px", "width": "100%"}
        common = {
            "layout": layout,
            "base_row_size": 28,
            "base_column_size": 140,
        }
        aligned = _grid_renderers(ipd, row_flags)
        sized = {"column_widths": widths} if widths else {}
        grid = None
        for extra in (
            {"selection_mode": "row", "base_row_header_size": header_size, **aligned, **sized},
            {"base_row_header_size": header_size, **aligned, **sized},
            {**aligned, **sized},
            {"selection_mode": "row", "base_row_header_size": header_size, **sized},
            {"base_row_header_size": header_size, **sized},
            sized,
            {"selection_mode": "row", "base_row_header_size": header_size, **aligned},
            {"base_row_header_size": header_size, **aligned},
            aligned,
            {"selection_mode": "row", "base_row_header_size": header_size},
            {"base_row_header_size": header_size},
            {},
        ):
            try:
                grid = ipd.DataGrid(frame, **common, **extra)
                break
            except TypeError:
                grid = None
            except Exception:
                return None
        if grid is None:
            return None
        if click:
            if not hasattr(grid, "on_cell_click"):
                return None
            grid.on_cell_click(on_click or self._on_book_click)
        return grid

    def _set_chart_rows(self, visible: bool) -> None:
        """Share-class list used only when the grid cannot take a click."""
        self._suppress_chart_row = True
        try:
            if not visible or self._shown_rows is None or self._shown_rows.empty:
                self.chart_row.layout.display = "none"
                return
            options = []
            rows = self._shown_rows.reset_index(drop=True)
            for index, record in rows.iterrows():
                fund = preferred_long_name(record.get("Long Name"), record.get("Fund Name")) or _cell_text(record.get("Fund Name"))
                share_class = _cell_text(record.get("Share Class"))
                isin = _cell_text(record.get("ISIN"))
                label = " | ".join(part for part in (fund, share_class, isin) if part) or f"Row {index + 1}"
                options.append((label, int(index)))
            self.chart_row.options = options
            self.chart_row.layout.display = ""
        finally:
            self._suppress_chart_row = False

    def _on_chart_row(self, _change=None) -> None:
        if self._suppress_chart_row or self.chart_row.layout.display == "none":
            return
        row = self.chart_row.value
        self._show_activity(lambda: self._select_book_row(row))

    def _on_book_click(self, event) -> None:
        if not isinstance(event, dict):
            return
        if event.get("region") in {"column-header", "corner-header", "row-header"}:
            return
        row = event.get("primary_key_row")
        if row is None:
            row = event.get("row")
        self._show_activity(lambda: self._select_book_row(row))

    def _select_book_row(self, row) -> None:
        try:
            index = int(row)
        except (TypeError, ValueError):
            return
        frame = self._shown_rows
        if frame is None or frame.empty or index < 0 or index >= len(frame):
            return
        record = frame.iloc[index]
        ticker = _cell_text(record.get("Ticker") if "Ticker" in frame.columns else "")
        fund = _cell_text(record.get("Fund Name") if "Fund Name" in frame.columns else "")
        share_class = _cell_text(record.get("Share Class") if "Share Class" in frame.columns else "")
        isin = _cell_text(record.get("ISIN") if "ISIN" in frame.columns else "")
        self._chart_ticker = ticker
        self._chart_isin = isin.upper()
        self._chart_fund = fund
        label = preferred_long_name(record.get("Long Name"), fund) or fund
        self._chart_label = " — ".join(part for part in (label, share_class, ticker) if part)
        self._draw_spread_chart()

    def _on_chart_period(self, change=None) -> None:
        """One Chart Period drives both charts. Changing it does not send a request."""
        self._show_activity(lambda: self._apply_chart_period(change))

    def _apply_chart_period(self, change=None) -> None:
        value = getattr(change, "new", None) if change is not None else None
        owner = getattr(change, "owner", None) if change is not None else None
        if value is not None:
            self._syncing = True
            try:
                for dropdown in (self.chart_period, self.peer_chart_period):
                    if dropdown is not owner and dropdown.value != value:
                        dropdown.value = value
            finally:
                self._syncing = False
        self._draw_spread_chart()
        self._draw_peer_chart()

    def _set_peer_chart_rows(self, visible: bool) -> None:
        self._suppress_chart_row = True
        try:
            if not visible or self._peer_shown is None or self._peer_shown.empty:
                self.peer_chart_row.layout.display = "none"
                return
            options = []
            rows = self._peer_shown.reset_index(drop=True)
            for index, record in rows.iterrows():
                fund = preferred_long_name(record.get("Long Name"), record.get("Fund Name")) or _cell_text(record.get("Fund Name"))
                share_class = _cell_text(record.get("Share Class"))
                isin = _cell_text(record.get("ISIN"))
                label = " | ".join(part for part in (fund, share_class, isin) if part) or f"Row {index + 1}"
                options.append((label, int(index)))
            self.peer_chart_row.options = options
            self.peer_chart_row.layout.display = ""
        finally:
            self._suppress_chart_row = False

    def _on_peer_chart_row(self, _change=None) -> None:
        if self._suppress_chart_row or self.peer_chart_row.layout.display == "none":
            return
        row = self.peer_chart_row.value
        self._show_activity(lambda: self._select_peer_row(row))

    def _on_peer_click(self, event) -> None:
        if not isinstance(event, dict):
            return
        if event.get("region") in {"column-header", "corner-header", "row-header"}:
            return
        row = event.get("primary_key_row")
        if row is None:
            row = event.get("row")
        self._show_activity(lambda: self._select_peer_row(row))

    def _select_peer_row(self, row) -> None:
        try:
            index = int(row)
        except (TypeError, ValueError):
            return
        frame = self._peer_shown
        if frame is None or frame.empty or index < 0 or index >= len(frame):
            return
        record = frame.iloc[index]
        ticker = _cell_text(record.get("Ticker") if "Ticker" in frame.columns else "")
        fund = _cell_text(record.get("Fund Name") if "Fund Name" in frame.columns else "")
        hsbc = _cell_text(record.get("HSBC Fund") if "HSBC Fund" in frame.columns else "") or fund
        share_class = _cell_text(record.get("Share Class") if "Share Class" in frame.columns else "")
        self._peer_chart_ticker = ticker
        self._peer_chart_fund = hsbc
        label = preferred_long_name(record.get("Long Name"), fund) or fund
        self._peer_chart_label = " — ".join(part for part in (label, share_class, ticker) if part)
        self._draw_peer_chart()

    def _peer_line_names(self, fund: str, skip_ticker: str) -> list[tuple[str, str]]:
        """Ticker and legend name for each peer of this HSBC fund, except the selected row."""
        links = self._peer_links
        key = fund_name_key(fund)
        skip = _clean_text(skip_ticker).upper()
        if (
            links is None
            or links.empty
            or not key
            or "Fund Name" not in links.columns
            or "Ticker" not in links.columns
        ):
            return []
        rows = links.loc[links["Fund Name"].map(fund_name_key).eq(key)]
        found: list[tuple[str, str]] = []
        seen: set[str] = set()
        for _, record in rows.iterrows():
            ticker = _clean_text(record.get("Ticker"))
            ticker_key = ticker.upper()
            if not ticker_key or ticker_key in seen or ticker_key == skip:
                continue
            seen.add(ticker_key)
            legend = preferred_long_name(record.get("Long Name"), record.get("Name")) or ticker
            found.append((ticker, legend))
        return found

    def _chart_benchmark(self, ticker: str, fund: str) -> str:
        for frame in (self._shown_rows, self._source, self._peer_shown):
            found = _benchmark_id(frame, ticker)
            if found:
                return found
        source = self._source
        key = fund_name_key(fund)
        if (
            source is None
            or source.empty
            or not key
            or "Fund Name" not in source.columns
            or "Benchmark Index" not in source.columns
        ):
            return ""
        rows = source.loc[source["Fund Name"].map(fund_name_key).eq(key)]
        for value in rows["Benchmark Index"].tolist():
            text = _clean_text(value)
            if text:
                return text
        return ""

    def _draw_spread_chart(self, _change=None) -> None:
        """Slice the cached history for the HSBC ETF chart. This does not send a request."""
        self._plot_charts(
            self.chart_output,
            self.chart_status,
            self._chart_ticker,
            self._chart_fund,
            self._chart_label,
            self.chart_period.value,
            extra_peers=False,
            empty_message="Click a share class to plot it.",
        )

    def _draw_peer_chart(self, _change=None) -> None:
        """Same charts as HSBC ETF, plus one line for each other Top 5 Peer."""
        self._plot_charts(
            self.peer_chart_output,
            self.peer_chart_status,
            self._peer_chart_ticker,
            self._peer_chart_fund,
            self._peer_chart_label,
            self.peer_chart_period.value,
            extra_peers=True,
            empty_message="Click a row to plot it.",
        )

    def _plot_charts(
        self,
        output,
        status,
        ticker: str,
        fund: str,
        label: str,
        period,
        extra_peers: bool,
        empty_message: str,
    ) -> None:
        """Spread % and return from the cache. Absolute spread is not drawn."""
        if not ticker:
            _put_output(output, [])
            status.value = f"<p>{empty_message}</p>"
            return
        shown = escape(label or ticker)
        show_spread = bool(self.show_spread.value)
        show_return = bool(self.show_return.value)
        show_nav = bool(self.show_nav.value)
        if not show_spread and not show_return and not show_nav:
            _put_output(output, [])
            status.value = f"<p>{shown}. Select Spread, Return, NAV Return, or a combination.</p>"
            return
        peers = self._chart_peers(fund)
        include_anchor = self._include_anchor()
        as_of = last_completed_london_day()
        custom = self._custom_dates()
        names = self._peer_line_names(fund, ticker) if extra_peers else []
        try:
            spread_series = (
                spread_comparison(
                    self._quote_history,
                    ticker,
                    peers,
                    period,
                    as_of,
                    include_anchor,
                    *custom,
                )
                if show_spread
                else pd.DataFrame()
            )
            return_series = (
                return_comparison(
                    self._return_history,
                    ticker,
                    peers,
                    period,
                    as_of,
                    include_anchor,
                    *custom,
                    quotes=self._quote_history,
                    benchmark_id=self._chart_benchmark(ticker, fund),
                )
                if show_return or show_nav
                else pd.DataFrame()
            )
            spread_members = (
                peer_member_spreads(
                    self._quote_history,
                    ticker,
                    names,
                    period,
                    as_of,
                    *custom,
                )
                if show_spread and names
                else pd.DataFrame()
            )
            return_members = (
                peer_member_returns(
                    self._return_history,
                    ticker,
                    names,
                    period,
                    as_of,
                    *custom,
                    quotes=self._quote_history,
                )
                if show_return and names
                else pd.DataFrame()
            )
            nav_series = (
                return_comparison(
                    self._nav_history,
                    ticker,
                    peers,
                    period,
                    as_of,
                    include_anchor,
                    *custom,
                    quotes=self._quote_history,
                    benchmark_id="",
                )
                if show_nav
                else pd.DataFrame()
            )
            if show_nav and not nav_series.empty:
                nav_series = nav_series.rename(
                    columns={
                        "Return %": "NAV Return %",
                        "Peer Return %": "Peer NAV Return %",
                    }
                )
                nav_series = _borrow_total_return_benchmark(nav_series, return_series)
            nav_members = (
                peer_member_returns(
                    self._nav_history,
                    ticker,
                    names,
                    period,
                    as_of,
                    *custom,
                    quotes=self._quote_history,
                    legend_suffix=" NAV Return %",
                )
                if show_nav and names
                else pd.DataFrame()
            )
        except Exception as exc:
            _put_output(output, [])
            status.value = f"<p>{shown}. Chart failed: {escape(str(exc))}</p>"
            return
        spread_ready = (
            not spread_series.empty
            and "Percent Spread" in spread_series.columns
            and not spread_series["Percent Spread"].isna().all()
        )
        return_ready = (
            not return_series.empty
            and "Return %" in return_series.columns
            and not return_series["Return %"].isna().all()
        )
        nav_ready = (
            not nav_series.empty
            and "NAV Return %" in nav_series.columns
            and not nav_series["NAV Return %"].isna().all()
        )
        wanted = []
        if show_spread:
            wanted.append(spread_ready)
        if show_return:
            wanted.append(return_ready)
        if show_nav:
            wanted.append(nav_ready)
        if wanted and not any(wanted):
            _put_output(output, [])
            if show_spread and not show_return and not show_nav:
                message = f"{shown}. No London quote in {escape(str(period))}."
            elif show_return and not show_spread and not show_nav:
                message = f"{shown}. No total-return level in {escape(str(period))}."
            elif show_nav and not show_spread and not show_return:
                message = f"{shown}. No NAV level in {escape(str(period))}."
            else:
                message = f"{shown}. No cached history in {escape(str(period))}."
            status.value = f"<p>{message}</p>"
            return
        parts = []
        if show_spread:
            parts.append("spread %")
        if show_return:
            parts.append("return")
        if show_nav:
            parts.append("NAV return")
        average = "HSBC + Top 5 Peers" if include_anchor else "Top 5 Peers"
        benchmark = " and the benchmark" if show_return or show_nav else ""
        each_peer = " Each Top 5 Peer is its own line." if extra_peers else ""
        status.value = (
            f"<p>{shown}. {' and '.join(parts)} for {escape(str(period))}, "
            f"with the {average} average{benchmark}.{each_peer}</p>"
        )
        blocks = []
        if show_spread and spread_ready:
            blocks.append(_show_spread_chart(spread_series, label or ticker, period, spread_members))
        if show_return and return_ready:
            blocks.append(_show_return_chart(return_series, label or ticker, period, return_members))
        if show_nav and nav_ready:
            blocks.append(
                _show_return_chart(
                    nav_series,
                    label or ticker,
                    period,
                    nav_members,
                    own="NAV Return %",
                    peer="Peer NAV Return %",
                    benchmark="Bmk Return %",
                    y_title="NAV Return %",
                )
            )
        _put_output(output, blocks)


def _borrow_total_return_benchmark(nav_series: pd.DataFrame, return_series: pd.DataFrame) -> pd.DataFrame:
    """Use the total-return benchmark on the NAV chart.

    A benchmark index has no NAV return. The column name stays
    ``Bmk Return %`` so the legend matches the return chart.
    """
    frame = nav_series.copy()
    if "Bmk Return %" in frame.columns:
        frame = frame.drop(columns=["Bmk Return %"])
    if (
        return_series is None
        or return_series.empty
        or "DATE" not in frame.columns
        or "DATE" not in return_series.columns
        or "Bmk Return %" not in return_series.columns
    ):
        return frame
    borrowed = return_series.loc[:, ["DATE", "Bmk Return %"]].copy()
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
    borrowed["DATE"] = pd.to_datetime(borrowed["DATE"], errors="coerce")
    borrowed = borrowed.dropna(subset=["DATE"]).drop_duplicates("DATE", keep="last")
    return frame.merge(borrowed, on="DATE", how="left")


def _show_heatmap(matrix: pd.DataFrame, period: str, currency: str, row_title: str = "Group"):
    if matrix is None or matrix.empty:
        return None
    try:
        import plotly.graph_objects as go
    except ImportError:
        return "Plotly is unavailable, so the flow heatmap was not drawn."
    labels = [pd.Timestamp(column).date().isoformat() for column in matrix.columns]
    names = [str(label) for label in matrix.index]
    height, left = heatmap_size(names)
    figure = go.Figure(
        data=[
            go.Heatmap(
                z=matrix.to_numpy(),
                x=labels,
                y=names,
                colorscale="RdYlGn",
                zmid=0,
                colorbar={"title": f"{currency} mn"},
            )
        ]
    )
    figure.update_layout(
        title=f"Net fund flow, {period}",
        xaxis_title="Bucket end",
        yaxis={
            "title": row_title,
            "automargin": True,
            "autorange": "reversed",
            "tickfont": {"size": 12},
            "ticklabelstep": 1,
        },
        height=height,
        margin={"t": 48, "l": left, "r": 24, "b": 48},
    )
    return figure


def _cell_text(value) -> str:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "<na>"}:
        return ""
    return text


def _chart_frame(figure, title: str, y_title: str) -> None:
    """One legend line per series, under the plot.

    Plotly does not separate a horizontal legend when the names are long.
    The bottom margin grows with the series count so the last line stays
    visible, below the date labels.
    """
    count = sum(1 for trace in figure.data if getattr(trace, "name", None))
    count = max(count, 1)
    plot_height = 280
    tick_band = 48
    row_px = 18
    legend_px = row_px * count
    figure.update_layout(
        title=title,
        yaxis={"title": y_title},
        legend={
            "orientation": "v",
            "yanchor": "top",
            "y": -(tick_band / plot_height),
            "xanchor": "left",
            "x": 0,
            "xref": "paper",
            "yref": "paper",
            "font": {"size": 12},
            "traceorder": "normal",
        },
        margin={"l": 48, "r": 24, "t": 56, "b": tick_band + legend_px + 8},
        template="plotly_dark",
        height=plot_height + 56 + tick_band + legend_px + 8,
    )


def _show_spread_chart(series: pd.DataFrame, title: str, period: str, members: pd.DataFrame | None = None) -> None:
    """Spread percent for the selected row and the peer average.

    Absolute spread is not drawn. ``members`` adds one percent line per peer.
    """
    try:
        import plotly.graph_objects as go
    except ImportError:
        return "Plotly is unavailable, so the spread chart was not drawn."
    figure = go.Figure()
    if "Percent Spread" in series.columns:
        figure.add_trace(
            go.Scatter(
                x=series["DATE"],
                y=series["Percent Spread"],
                mode="lines",
                name="Spread %",
                connectgaps=False,
            )
        )
    if "Peer Spread %" in series.columns:
        figure.add_trace(
            go.Scatter(
                x=series["DATE"],
                y=series["Peer Spread %"],
                mode="lines",
                name="Peer Avg Spread %",
                connectgaps=False,
            )
        )
    _add_member_lines(figure, members)
    _chart_frame(figure, f"{title} — {period}", "Spread %")
    return figure


def _show_return_chart(
    series: pd.DataFrame,
    title: str,
    period: str,
    members: pd.DataFrame | None = None,
    own: str = "Return %",
    peer: str = "Peer Return %",
    benchmark: str = "Bmk Return %",
    y_title: str = "Return %",
) -> None:
    """Percent for the selected row, the peer average, and the benchmark."""
    try:
        import plotly.graph_objects as go
    except ImportError:
        return "Plotly is unavailable, so the return chart was not drawn."
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=series["DATE"],
            y=series[own],
            mode="lines",
            name=own,
            connectgaps=False,
        )
    )
    if peer in series.columns:
        figure.add_trace(
            go.Scatter(
                x=series["DATE"],
                y=series[peer],
                mode="lines",
                name=f"Peer Avg {y_title}" if y_title != "Return %" else "Peer Avg Return %",
                connectgaps=False,
            )
        )
    if benchmark in series.columns:
        figure.add_trace(
            go.Scatter(
                x=series["DATE"],
                y=series[benchmark],
                mode="lines",
                name="Bmk Return %",
                connectgaps=False,
            )
        )
    _add_member_lines(figure, members)
    heading = f"{title} — {period} return" if y_title == "Return %" else f"{title} — {period} {y_title}"
    _chart_frame(figure, heading, y_title)
    return figure


def _add_member_lines(figure, members: pd.DataFrame | None) -> None:
    """One line per peer column. A column that is entirely blank is left out."""
    if members is None or members.empty or "DATE" not in members.columns:
        return
    import plotly.graph_objects as go

    for column in members.columns:
        if column == "DATE":
            continue
        values = members[column]
        if values.isna().all():
            continue
        figure.add_trace(
            go.Scatter(
                x=members["DATE"],
                y=values,
                mode="lines",
                name=str(column),
                connectgaps=False,
            )
        )


def _plain_json(value):
    """A JSON copy of a Plotly figure, including array values."""
    import json

    def convert(item):
        if isinstance(item, dict):
            return {str(key): convert(inner) for key, inner in item.items()}
        if isinstance(item, (list, tuple)):
            return [convert(inner) for inner in item]
        if hasattr(item, "tolist"):
            return convert(item.tolist())
        if isinstance(item, (str, int, bool)) or item is None:
            return item
        if isinstance(item, float):
            return item
        return str(item)

    return json.loads(json.dumps(convert(value)))


def _figure_display_data(figure) -> dict:
    """The notebook mime bundle for one figure, stored as plain JSON."""
    import json

    try:
        import plotly.io as pio

        payload = json.loads(pio.to_json(figure))
    except Exception:
        payload = _plain_json(figure.to_plotly_json())
    return {
        "output_type": "display_data",
        "data": {
            "application/vnd.plotly.v1+json": payload,
            "text/plain": "Figure",
        },
        "metadata": {},
    }


def _output_items(blocks) -> tuple:
    """Text lines and figures for an Output widget."""
    items = []
    for block in blocks:
        if block is None:
            continue
        if isinstance(block, str):
            text = block if block.endswith("\n") else block + "\n"
            items.append({"output_type": "stream", "name": "stdout", "text": text})
            continue
        items.append(_figure_display_data(block))
    return tuple(items)


def _put_output(output, blocks) -> None:
    """Replace an Output widget's contents.

    ``display()`` inside ``widgets.Output`` is kept only for the original
    widget callback. A timer used to paint Processing has no parent message,
    so that figure never appears. The outputs trait does not use that id.
    """
    output.outputs = _output_items(blocks)
