"""Period windows and placeholder spread math.

The functions here are pure table logic. They do not fetch. Invalid quotes
stay blank so a missing print cannot look like a tight market.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime

import numpy as np
import pandas as pd

from .config import OBSERVATION_COLUMNS, PERIOD_KEYS, enabled_share_classes


SUMMARY_COLUMNS = (
    "Series",
    "Share Class ID",
    "Peer Group ID",
    "ETF ID",
    "Label",
    "Listing Ticker",
    "Currency",
    "Last Spread",
    "Mean Spread",
    "Median Spread",
    "Min Spread",
    "Max Spread",
    "Observations",
    "Priced",
    "Window Start",
    "Window End",
)

CHART_COLUMNS = ("DATE", "Series Name", "Spread", "Series")

SPREAD_STAT_COLUMNS = (
    "Last Spread",
    "Mean Spread",
    "Median Spread",
    "Min Spread",
    "Max Spread",
)


@dataclass
class PreparedObservations:
    frame: pd.DataFrame
    dropped_rows: int = 0


@dataclass
class SpreadView:
    summary: pd.DataFrame
    chart: pd.DataFrame
    as_of: pd.Timestamp | None
    window_start: pd.Timestamp | None
    window_end: pd.Timestamp | None
    notes: list[str] = field(default_factory=list)


def _empty_summary() -> pd.DataFrame:
    return pd.DataFrame(columns=list(SUMMARY_COLUMNS))


def _empty_chart() -> pd.DataFrame:
    return pd.DataFrame(columns=list(CHART_COLUMNS))


def _blank_view(notes: list[str], as_of=None) -> SpreadView:
    return SpreadView(
        summary=_empty_summary(),
        chart=_empty_chart(),
        as_of=as_of,
        window_start=None,
        window_end=None,
        notes=notes,
    )


def _as_timestamp(value):
    if value is None or value == "":
        return None
    if isinstance(value, datetime) and not isinstance(value, pd.Timestamp):
        value = value.date() if hasattr(value, "date") else value
    try:
        stamp = pd.Timestamp(value)
    except Exception:
        return None
    if pd.isna(stamp):
        return None
    return stamp.normalize()


def quote_spread_bps(bid, ask) -> pd.Series:
    """Placeholder midpoint spread in bps.

    Valid only when both quotes are positive and ask is at least bid.
    ``ask == bid`` is zero. A crossed, non-positive, or non-numeric quote
    is blank. This is not a signed Bloomberg formula.
    """
    bid_n = pd.to_numeric(bid, errors="coerce").replace([np.inf, -np.inf], np.nan)
    ask_n = pd.to_numeric(ask, errors="coerce").replace([np.inf, -np.inf], np.nan)
    mid = (bid_n + ask_n) / 2.0
    valid = bid_n.gt(0) & ask_n.gt(0) & ask_n.ge(bid_n) & mid.gt(0)
    spread = (ask_n - bid_n) / mid * 10000.0
    return spread.where(valid)


def quote_status(bid, ask) -> pd.Series:
    bid_n = pd.to_numeric(bid, errors="coerce").replace([np.inf, -np.inf], np.nan)
    ask_n = pd.to_numeric(ask, errors="coerce").replace([np.inf, -np.inf], np.nan)
    positive = bid_n.gt(0) & ask_n.gt(0)
    status = pd.Series(np.full(len(bid_n), "missing"), index=bid_n.index)
    status = status.mask(positive & ask_n.ge(bid_n), "ok")
    status = status.mask(positive & ask_n.lt(bid_n), "crossed")
    return status


def prepare_observations(observations: pd.DataFrame | None) -> PreparedObservations:
    """Clean one cache. Sort by DATE only. Keep the last duplicate key."""
    if observations is None:
        observations = pd.DataFrame(columns=list(OBSERVATION_COLUMNS))
    missing = [name for name in OBSERVATION_COLUMNS if name not in observations.columns]
    if missing:
        raise KeyError(f"Missing observation columns: {missing}")

    frame = observations.loc[:, list(OBSERVATION_COLUMNS)].copy()
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
    frame["Share Class ID"] = frame["Share Class ID"].fillna("").astype(str).str.strip()
    frame["Peer Group ID"] = frame["Peer Group ID"].fillna("").astype(str).str.strip()
    frame["Series"] = frame["Series"].fillna("").astype(str).str.strip()

    keep_series = frame["Series"].isin(["Book", "Peer"])
    book_id_ok = frame["Series"].ne("Book") | frame["Share Class ID"].ne("")
    peer_id_ok = frame["Series"].ne("Peer") | frame["Peer Group ID"].ne("")
    date_ok = frame["DATE"].notna()
    usable = keep_series & book_id_ok & peer_id_ok & date_ok
    dropped_rows = int((~usable).sum())
    frame = frame.loc[usable].copy()
    frame["DATE"] = frame["DATE"].dt.normalize()
    frame = frame.sort_values("DATE", kind="mergesort")
    frame = frame.drop_duplicates(
        subset=["Series", "Share Class ID", "Peer Group ID", "DATE"],
        keep="last",
    )
    frame["Spread"] = quote_spread_bps(frame["Bid"], frame["Ask"])
    frame["Quote Status"] = quote_status(frame["Bid"], frame["Ask"])
    frame = frame.reset_index(drop=True)
    return PreparedObservations(frame=frame, dropped_rows=dropped_rows)


def period_bounds(
    period_key: str,
    as_of: pd.Timestamp,
    custom_start=None,
    custom_end=None,
) -> tuple[pd.Timestamp | None, pd.Timestamp | None, list[str]]:
    """Return an inclusive window ending on ``as_of`` for a preset."""
    key = str(period_key or "").strip()
    end = pd.Timestamp(as_of).normalize()
    if key not in PERIOD_KEYS:
        return None, None, [f"Unknown period: {period_key}."]
    if key == "Custom":
        start = _as_timestamp(custom_start)
        custom_end_ts = _as_timestamp(custom_end)
        if start is None or custom_end_ts is None:
            return None, None, ["Custom period needs a start and an end."]
        if start > custom_end_ts:
            return start, custom_end_ts, ["Custom start is after custom end."]
        return start, min(custom_end_ts, end), []
    if key == "YTD":
        start = pd.Timestamp(year=end.year, month=1, day=1)
    else:
        offsets = {
            "1M": dict(months=1),
            "3M": dict(months=3),
            "6M": dict(months=6),
            "1Y": dict(years=1),
            "3Y": dict(years=3),
            "5Y": dict(years=5),
        }
        start = (end - pd.DateOffset(**offsets[key])).normalize()
    return start, end, []


def _directory() -> dict[str, object]:
    return {row.share_class_id: row for row in enabled_share_classes()}


def _stats(group: pd.DataFrame) -> dict[str, float | int]:
    ordered = group.sort_values("DATE", kind="mergesort")
    valid = ordered["Spread"].dropna()
    last = float(valid.iloc[-1]) if not valid.empty else np.nan
    return {
        "Last Spread": last,
        "Mean Spread": float(ordered["Spread"].mean(skipna=True)),
        "Median Spread": float(ordered["Spread"].median(skipna=True)),
        "Min Spread": float(ordered["Spread"].min(skipna=True)),
        "Max Spread": float(ordered["Spread"].max(skipna=True)),
        "Observations": int(len(ordered)),
        "Priced": int(ordered["Spread"].notna().sum()),
    }


def _currency_label(values: list[str]) -> str:
    cleaned = sorted({value for value in values if value})
    if not cleaned:
        return ""
    if len(cleaned) == 1:
        return cleaned[0]
    return "Mixed"


def _summarize(
    window: pd.DataFrame,
    window_start: pd.Timestamp,
    window_end: pd.Timestamp,
) -> pd.DataFrame:
    directory = _directory()
    rows = []
    book = window.loc[window["Series"].eq("Book")]
    for share_class_id, group in book.groupby("Share Class ID", sort=False):
        info = directory.get(str(share_class_id))
        peer_group_id = str(group["Peer Group ID"].iloc[0])
        row = {
            "Series": "Book",
            "Share Class ID": str(share_class_id),
            "Peer Group ID": peer_group_id,
            "ETF ID": "" if info is None else info.etf_id,
            "Label": str(share_class_id) if info is None else info.label,
            "Listing Ticker": "" if info is None else info.listing_ticker,
            "Currency": "" if info is None else info.currency,
            "Window Start": window_start,
            "Window End": window_end,
        }
        row.update(_stats(group))
        rows.append(row)

    selected_groups = set(book["Peer Group ID"].astype(str))
    peer = window.loc[
        window["Series"].eq("Peer") & window["Peer Group ID"].isin(selected_groups)
    ]
    for peer_group_id, group in peer.groupby("Peer Group ID", sort=False):
        members = book.loc[book["Peer Group ID"].astype(str).eq(str(peer_group_id))]
        currencies = []
        for share_class_id in members["Share Class ID"].astype(str).unique():
            info = directory.get(share_class_id)
            if info is not None:
                currencies.append(info.currency)
        row = {
            "Series": "Peer",
            "Share Class ID": "",
            "Peer Group ID": str(peer_group_id),
            "ETF ID": "",
            "Label": f"Peer {peer_group_id}",
            "Listing Ticker": "",
            "Currency": _currency_label(currencies),
            "Window Start": window_start,
            "Window End": window_end,
        }
        row.update(_stats(group))
        rows.append(row)

    summary = pd.DataFrame(rows, columns=list(SUMMARY_COLUMNS))
    if summary.empty:
        return summary
    summary["_order"] = summary["Series"].map({"Book": 0, "Peer": 1}).fillna(2)
    summary = summary.sort_values(["_order", "Label"], kind="mergesort")
    return summary.drop(columns="_order").reset_index(drop=True)


def _chart_frame(window: pd.DataFrame) -> pd.DataFrame:
    if window.empty:
        return _empty_chart()
    directory = _directory()
    chart = window.loc[:, ["DATE", "Series", "Share Class ID", "Peer Group ID", "Spread"]].copy()

    def series_name(row) -> str:
        if row["Series"] == "Peer":
            return f"Peer {row['Peer Group ID']}"
        info = directory.get(str(row["Share Class ID"]))
        if info is None:
            return str(row["Share Class ID"])
        return info.label

    chart["Series Name"] = chart.apply(series_name, axis=1)
    chart = chart.loc[:, list(CHART_COLUMNS)]
    return chart.sort_values(["DATE", "Series Name"], kind="mergesort").reset_index(drop=True)


def build_view(
    observations: pd.DataFrame | None,
    period_key: str,
    share_class_ids: list[str] | tuple[str, ...] | None,
    custom_start: date | None = None,
    custom_end: date | None = None,
    show_peer: bool = True,
) -> SpreadView:
    """Slice one loaded cache. This does not fetch."""
    prepared = prepare_observations(observations)
    notes: list[str] = []
    if prepared.dropped_rows:
        notes.append(f"Skipped {prepared.dropped_rows} unusable rows.")

    selected = [str(value).strip() for value in (share_class_ids or []) if str(value).strip()]
    if not selected:
        return _blank_view(["Select at least one share class."])

    frame = prepared.frame
    if frame.empty or frame["DATE"].isna().all():
        return _blank_view([*notes, "No observations."])

    as_of = pd.Timestamp(frame["DATE"].max()).normalize()
    start, end, bound_notes = period_bounds(period_key, as_of, custom_start, custom_end)
    notes.extend(bound_notes)
    if start is not None and end is not None and start > end:
        if not any("after" in note for note in notes):
            notes.append("The window ends before it starts.")
    if start is None or end is None or start > end:
        view = _blank_view(notes, as_of=as_of)
        view.window_start = start
        view.window_end = end
        return view

    loaded_min = pd.Timestamp(frame["DATE"].min()).normalize()
    if start < loaded_min:
        notes.append(
            f"Loaded history starts {loaded_min:%Y-%m-%d}. "
            "Earlier dates are not in the cache."
        )

    book = frame.loc[
        frame["Series"].eq("Book") & frame["Share Class ID"].isin(selected)
    ]
    groups = set(book["Peer Group ID"].astype(str))
    peer = frame.loc[
        frame["Series"].eq("Peer") & frame["Peer Group ID"].isin(groups)
    ]
    if not show_peer:
        peer = peer.iloc[0:0]
    window = pd.concat([book, peer], ignore_index=True, sort=False)
    if not window.empty:
        window = window.loc[(window["DATE"] >= start) & (window["DATE"] <= end)].copy()

    if window.empty:
        notes.append("No observations in this period.")
        view = _blank_view(notes, as_of=as_of)
        view.window_start = start
        view.window_end = end
        return view

    if show_peer and groups and not window["Series"].eq("Peer").any():
        notes.append("No peer rows in the loaded cache.")

    crossed = int((window["Quote Status"] == "crossed").sum())
    if crossed:
        notes.append(f"{crossed} crossed quotes were left blank.")

    return SpreadView(
        summary=_summarize(window, start, end),
        chart=_chart_frame(window),
        as_of=as_of,
        window_start=start,
        window_end=end,
        notes=notes,
    )
