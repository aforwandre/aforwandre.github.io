"""Spread history for the book and for peers.

Spread rows still come from the placeholder or the unconnected Bloomberg
source. The linked share-class list is a separate pull, using the
2026-10-22 HelpDesk sample. Fund assets and class assets are a second
pull on the same umbrella, in USD. That pull does not include a primary
flag.

A parser version constant is intentionally absent until the first Desktop
spread pull is frozen and the bundle registry has a reviewed row.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
import hashlib

import numpy as np
import pandas as pd

try:
    import bql
except ImportError:
    bql = None

from .config import (
    BOOK_SOURCE,
    HISTORY_BUSINESS_DAYS,
    OBSERVATION_COLUMNS,
    PEER_SOURCE,
    enabled_share_classes,
    isin_book_frame,
)
from .peer_map import choose_primary_isins, fund_name_key, map_rows
from . import cache
from .book_view import (
    HISTORY_RANGES,
    absolute_quote_spread,
    clean_market_text,
    last_completed_london_day,
    london_period_bounds,
    market_numbers,
    missing_market_text,
    percent_quote_spread,
    resolved_mid,
)


@dataclass
class SourceResult:
    observations: pd.DataFrame
    errors: list[str] = field(default_factory=list)


@dataclass
class SpreadPayload:
    observations: pd.DataFrame
    as_of: pd.Timestamp | None
    errors: list[str]
    book_source: str
    peer_source: str


def empty_observations() -> pd.DataFrame:
    return pd.DataFrame(columns=list(OBSERVATION_COLUMNS))


def _note(progress, message: str) -> None:
    if progress is not None:
        progress(message)


def _seed(key: str) -> int:
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
    return int(digest[:8], 16)


def _business_days(today: date, count: int) -> pd.DatetimeIndex:
    """Weekday dates ending on the latest weekday on or before ``today``."""
    if count < 1:
        return pd.DatetimeIndex([])
    return pd.bdate_range(end=pd.Timestamp(today), periods=count)


def _placeholder_bps(key: str, count: int) -> np.ndarray:
    rng = np.random.default_rng(_seed(key))
    base = 8.0 + (_seed(key) % 17)
    wave = np.sin(np.linspace(0.0, 12.0, count)) * 2.0
    noise = rng.normal(0.0, 0.6, count)
    return np.clip(base + wave + noise, 0.4, None)


def _quotes_from_bps(bps: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mid = np.full(bps.shape, 100.0)
    half = bps / 10000.0 / 2.0
    return mid * (1.0 - half), mid * (1.0 + half)


def _quote_rows(
    keys: list[tuple[str, str]],
    today: date,
    series: str,
    source: str,
) -> pd.DataFrame:
    """Build placeholder quotes.

    ``keys`` is ``(share_class_id, peer_group_id)`` for book rows, or
    ``("", peer_group_id)`` for a peer series.
    """
    if not keys:
        return empty_observations()
    dates = _business_days(today, HISTORY_BUSINESS_DAYS)
    frames = []
    for share_class_id, peer_group_id in keys:
        seed_key = share_class_id or f"peer:{peer_group_id}"
        bps = _placeholder_bps(seed_key, len(dates))
        bid, ask = _quotes_from_bps(bps)
        frames.append(
            pd.DataFrame(
                {
                    "Share Class ID": share_class_id,
                    "Peer Group ID": peer_group_id,
                    "DATE": dates,
                    "Bid": bid,
                    "Ask": ask,
                    "Source": source,
                    "Series": series,
                }
            )
        )
    return pd.concat(frames, ignore_index=True)


class PlaceholderBookSource:
    """Deterministic book history. Same inputs always return the same rows."""

    def fetch(self, today: date) -> SourceResult:
        rows = enabled_share_classes()
        if not rows:
            return SourceResult(
                empty_observations(),
                ["No enabled share classes in config."],
            )
        keys = [(row.share_class_id, row.peer_group_id) for row in rows]
        return SourceResult(_quote_rows(keys, today, "Book", "placeholder"))


class BloombergBookSource:
    """Future book adapter. It does not connect and does not build a request."""

    def fetch(self, today: date) -> SourceResult:
        del today
        return SourceResult(
            empty_observations(),
            [
                "Bloomberg book data is not connected. "
                "Route card 27 has no approved quote request."
            ],
        )


class PlaceholderPeerSource:
    """One placeholder series per peer group on the enabled book."""

    def fetch(self, today: date) -> SourceResult:
        groups = []
        seen = set()
        for row in enabled_share_classes():
            group_id = str(row.peer_group_id).strip()
            if not group_id or group_id in seen:
                continue
            seen.add(group_id)
            groups.append(("", group_id))
        if enabled_share_classes() and not groups:
            return SourceResult(
                empty_observations(),
                ["Enabled share classes have no peer group id."],
            )
        return SourceResult(_quote_rows(groups, today, "Peer", "placeholder"))


class BloombergPeerSource:
    """Future peer adapter. It does not connect and does not build a request."""

    def fetch(self, today: date) -> SourceResult:
        del today
        return SourceResult(
            empty_observations(),
            [
                "Bloomberg peer data is not connected. "
                "Route card 27 has no approved peer request."
            ],
        )


def book_source_for(name: str):
    if name == "placeholder":
        return PlaceholderBookSource()
    if name == "bloomberg":
        return BloombergBookSource()
    raise ValueError(f"Unknown book source: {name}")


def peer_source_for(name: str):
    if name == "placeholder":
        return PlaceholderPeerSource()
    if name == "bloomberg":
        return BloombergPeerSource()
    raise ValueError(f"Unknown peer source: {name}")


def fetch_spread_payload(
    today: date | None = None,
    book_source_name: str | None = None,
    peer_source_name: str | None = None,
    progress=None,
) -> SpreadPayload:
    """Load book and peer history through the current refresh date.

    Calling this again with the same arguments rebuilds the same placeholder
    rows. Bloomberg source names return diagnostics instead of rows.
    """
    refresh_day = today or date.today()
    book_name = book_source_name or BOOK_SOURCE
    peer_name = peer_source_name or PEER_SOURCE

    _note(progress, f"Loading book history ({book_name})…")
    book = book_source_for(book_name).fetch(refresh_day)
    _note(progress, f"Loading peer history ({peer_name})…")
    peer = peer_source_for(peer_name).fetch(refresh_day)

    frames = [
        frame
        for frame in (book.observations, peer.observations)
        if frame is not None and not frame.empty
    ]
    observations = (
        pd.concat(frames, ignore_index=True, sort=False)
        if frames
        else empty_observations()
    )
    as_of = None
    if not observations.empty and "DATE" in observations.columns:
        dates = pd.to_datetime(observations["DATE"], errors="coerce")
        if dates.notna().any():
            as_of = pd.Timestamp(dates.max()).normalize()
    return SpreadPayload(
        observations=observations,
        as_of=as_of,
        errors=[*book.errors, *peer.errors],
        book_source=book_name,
        peer_source=peer_name,
    )


SHARE_CLASS_COLUMNS = (
    "Fund Name",
    "List",
    "Fund Company",
    "Ticker",
    "Name",
    "Long Name",
    "Share Class",
    "ISIN",
    "ID BB Company",
    "Benchmark",
    "Benchmark Index",
    "Strategy",
    "Currency",
    "Fund AUM (USD mn)",
    "Share Class AUM (USD mn)",
    "Primary",
    "Expense Ratio",
    "Bid",
    "Ask",
    "Mid",
    "Last",
    "Absolute Spread",
    "Percent Spread",
    "Tracking Error",
)
SHARE_CLASS_BATCH = 8


def tracking_error_number(value) -> float:
    """Vendor number converted to percent for display (x100).

    The operator confirmed on 2026-10-24 that the NAV tracking error is on the
    same scale as ``tracking_error()`` and asked for both columns in percent.
    The catalog items have no window argument.
    """
    number = market_numbers(pd.Series([value]), allow_zero=True).iloc[0]
    if pd.isna(number):
        return np.nan
    return float(number) * 100.0


def expense_ratio_number(value) -> float:
    """Keep the vendor scale. 0.09 is 0.09 percent, net of waivers."""
    number = market_numbers(pd.Series([value]), allow_zero=True).iloc[0]
    if pd.isna(number):
        return np.nan
    return float(number)


def empty_share_classes() -> pd.DataFrame:
    return pd.DataFrame(columns=list(SHARE_CLASS_COLUMNS))


def representative_seeds(book: pd.DataFrame | None) -> list[tuple[str, str]]:
    """One seed ISIN per typed fund name, in first-seen order."""
    if book is None or book.empty:
        return []
    seeds: list[tuple[str, str]] = []
    seen: set[str] = set()
    for _, row in book.iterrows():
        fund = str(row.get("Fund Name", "")).strip()
        isin = str(row.get("ISIN", "")).strip().upper()
        if not fund or not isin or fund in seen:
            continue
        if isin.lower() in {"nan", "none"}:
            continue
        seen.add(fund)
        seeds.append((fund, isin))
    return seeds


def _chunks(values, size: int):
    for start in range(0, len(values), size):
        yield values[start : start + size]


def _is_response(value) -> bool:
    if value is None or isinstance(
        value, (tuple, list, dict, str, bytes, pd.DataFrame, Exception)
    ):
        return False
    return "response" in type(value).__name__.lower()


def _response_items(response) -> list:
    items = []
    try:
        count = len(response)
    except Exception:
        count = None
    if count is not None and count > 0:
        for index in range(count):
            try:
                item = response[index]
            except Exception:
                item = None
            if item is not None and hasattr(item, "df"):
                items.append(item)
        if items:
            return items
    try:
        for item in response:
            if hasattr(item, "df"):
                items.append(item)
    except TypeError:
        pass
    return items


_COMBINE_META_COLUMNS = {
    "ID",
    "DATE",
    "DATETIME",
    "CURRENCY",
    "ORIG_IDS",
    "REVISION_DATE",
    "NORMALIZED_SCALE",
}


def _item_frame_for_combine(item) -> pd.DataFrame:
    """Normalize one item frame to ID (+DATE) + one named value column.

    The response may put the security id in the index, use a lowercase
    ``id`` column, or store DATE in the index or a column. Row-number
    indexes are rejected instead of becoming fake ids.
    """
    name = getattr(item, "name", None)
    raw = item.df()
    if not isinstance(raw, pd.DataFrame):
        raise ValueError(f"BQL item {name!r} did not return a DataFrame.")
    frame = raw.copy()
    frame.columns = [str(column) for column in frame.columns]

    if not any(str(column).strip().upper() == "ID" for column in frame.columns):
        if isinstance(frame.index, pd.RangeIndex):
            raise ValueError(
                f"BQL item {name!r} has a row-number index and no ID column; "
                f"columns={list(frame.columns)}."
            )
        frame = frame.reset_index()
        frame.columns = [str(column) for column in frame.columns]

    id_column = next(
        (column for column in frame.columns if str(column).strip().upper() == "ID"),
        None,
    )
    if id_column is None:
        for candidate in ("index", "level_0"):
            if candidate in frame.columns:
                id_column = candidate
                break
    if id_column is None:
        raise ValueError(
            f"BQL item {name!r} has no usable ID column; columns={list(frame.columns)}."
        )
    if id_column != "ID":
        frame = frame.rename(columns={id_column: "ID"})

    date_column = next(
        (
            column
            for column in frame.columns
            if str(column).strip().upper() in {"DATE", "DATETIME"}
        ),
        None,
    )
    if date_column is not None and date_column != "DATE":
        frame = frame.rename(columns={date_column: "DATE"})
    if "DATE" in frame.columns:
        frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
        frame = frame.loc[frame["DATE"].notna()].copy()
        frame["DATE"] = frame["DATE"].dt.normalize()

    value_column = None
    if name and name in frame.columns:
        value_column = name
    else:
        candidates = [
            column
            for column in frame.columns
            if column not in {"ID", "DATE"}
            and str(column).strip().upper() not in _COMBINE_META_COLUMNS
        ]
        if len(candidates) == 1:
            value_column = candidates[0]
    if value_column is None:
        raise ValueError(
            f"BQL item {name!r} has no single value column; columns={list(frame.columns)}."
        )

    output_name = name or value_column
    keys = ["ID", *(["DATE"] if "DATE" in frame.columns else [])]
    out = frame.loc[:, [*keys, value_column]].copy()
    if value_column != output_name:
        out = out.rename(columns={value_column: output_name})
    out["ID"] = out["ID"].astype("string").fillna("").str.strip()
    out = out.loc[
        out["ID"].ne("") & ~out["ID"].str.lower().isin({"nan", "none", "<na>"})
    ].copy()
    return out


def _dedupe_keys(frame: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    ordered = frame.sort_values(keys, kind="mergesort")
    return ordered.drop_duplicates(keys, keep="last").reset_index(drop=True)


def _combine_items(response) -> pd.DataFrame:
    """Combine multi-item responses on their real keys.

    A quote response can be sparse: one item may carry fewer DATE rows than
    another. Concatenating the frames positionally would borrow a value from
    another date (KB 18: merge on the real ID/DATE keys). Time-series items
    are merged on ID+DATE; one-row-per-ID items are merged on ID.
    """
    frames = []
    for item in _response_items(response):
        try:
            frame = _item_frame_for_combine(item)
        except Exception:
            raise
        if not frame.empty:
            frames.append(frame)
    if not frames:
        return pd.DataFrame()

    date_frames = [frame for frame in frames if "DATE" in frame.columns]
    plain_frames = [frame for frame in frames if "DATE" not in frame.columns]
    has_time_series = any(frame["ID"].duplicated().any() for frame in date_frames)

    if has_time_series:
        # A time-series response may contain a sparse item (one DATE row
        # only). It still belongs on ID+DATE, not on ID as a static value.
        series_frames = date_frames
        static_frames = plain_frames
        base = _dedupe_keys(series_frames[0], ["ID", "DATE"])
        for frame in series_frames[1:]:
            extra = _dedupe_keys(frame, ["ID", "DATE"])
            base = base.merge(
                extra,
                on=["ID", "DATE"],
                how="outer",
                validate="one_to_one",
            )
    else:
        static_frames = []
        for frame in frames:
            extra = _collapse_static_duplicates(frame)
            if extra is not None and not extra.empty:
                static_frames.append(extra)
        if not static_frames:
            return pd.DataFrame()
        base = static_frames[0]

    for frame in static_frames:
        if frame is base:
            continue
        extra = frame.drop(columns=["DATE"], errors="ignore")
        if extra["ID"].duplicated().any():
            extra = _collapse_static_duplicates(extra)
        if extra.empty or "ID" not in extra.columns:
            continue
        base = base.merge(extra, on="ID", how="outer", validate="many_to_one")

    if base.columns.duplicated().any():
        duplicates = sorted(set(base.columns[base.columns.duplicated()].tolist()))
        raise ValueError(f"Multi-item response produced duplicate columns: {duplicates}.")
    sort_columns = [column for column in ("ID", "DATE") if column in base.columns]
    return base.sort_values(sort_columns, kind="mergesort").reset_index(drop=True)


def fund_aum_usd_millions(amount, currency, rates: dict) -> float:
    """Native fund assets to USD millions.

    ``fund_total_assets()`` is the full amount in ``fund_total_assets_crncy()``.
    USD is only divided by one million. Another ISO code is converted first.
    """
    number = _usd_amount(amount)
    code = iso_currency_code(currency)
    if pd.isna(number) or not code:
        return pd.NA
    if code == "USD":
        return float(number) / 1_000_000
    spec = rates.get(code)
    if spec is None:
        return pd.NA
    operation, rate = spec
    if rate is None or pd.isna(rate) or float(rate) <= 0:
        return pd.NA
    usd = float(number) * float(rate) if operation == "multiply" else float(number) / float(rate)
    return usd / 1_000_000


def company_id_from_frame(frame: pd.DataFrame | None) -> str:
    """Read the umbrella id. A blank result must not open the universe."""
    if frame is None or frame.empty:
        return ""
    if "ID BB Company" in frame.columns:
        value = frame["ID BB Company"].iloc[0]
    else:
        value_columns = [
            column for column in frame.columns if column not in {"ID", "DATE"}
        ]
        if not value_columns:
            return ""
        value = frame[value_columns[0]].iloc[0]
    text = clean_market_text(value)
    if not text:
        return ""
    if text.endswith(".0") and text[:-2].isdigit():
        return text[:-2]
    return text


def _execute_many(service, labeled):
    responses = list(
        service.execute_many(
            [request for _, request in labeled],
            on_request_error=lambda error: error,
            num_retries=1,
        )
    )
    paired = []
    for index, (label, _request) in enumerate(labeled):
        if index >= len(responses):
            paired.append((label, None))
            continue
        paired.append((label, responses[index]))
    return paired


def _execute_waves(service, labeled):
    """Send prepared requests together.

    Each request already holds at most ``SHARE_CLASS_BATCH`` identifiers.
    Desktop times out one request after two minutes. The wave does not
    enlarge that request. A failed request stays paired with its label.
    """
    paired = []
    pending = list(labeled)
    for batch in _chunks(pending, SHARE_CLASS_BATCH):
        paired.extend(_execute_many(service, batch))
    return paired


def _umbrella_request(bq, isin: str):
    return bql.Request(
        isin,
        {"ID BB Company": bq.data.id_bb_company()["value"]},
    )


def _share_class_request(bq, company_id: str):
    universe = bq.univ.fundsuniv("active").filter(
        bq.data.id_bb_company() == str(company_id)
    )
    items = {
        "Ticker": bq.data.id()["value"],
        "Name": bq.data.name()["value"],
        "Long Name": bq.data.long_comp_name()["value"],
        "Fund Company": bq.data.fund_comp_name()["value"],
        "Share Class": bq.data.fund_open_shr_class()["value"],
        "ISIN": bq.data.id_isin()["value"],
        "Currency": bq.data.crncy(),
        "Share Class AUM": bq.data.fund_class_assets(),
        "Share Class AUM Currency": bq.data.fund_class_assets_crncy(),
        # 0.3 on this item means 0.3 percent. Do not divide by 100.
        "Expense Ratio": bq.data.fund_expense_ratio()["value"],
        "Bid": bq.data.px_bid(),
        "Ask": bq.data.px_ask(),
        "Mid": bq.data.px_mid(),
        "Last": bq.data.px_last(),
    }
    return bql.Request(
        universe,
        items,
        with_params={"mode": "cached", "showids": "f"},
    )


def iso_currency_code(value) -> str:
    """Keep an ISO code such as USD or EUR. Do not translate it."""
    text = clean_market_text(value).upper()
    if not text or missing_market_text(text):
        return ""
    return text


def collapse_publication_lines(frame: pd.DataFrame | None) -> pd.DataFrame:
    """Keep the line whose response currency matches the share-class currency.

    A mismatched line is dropped. When the two currencies disagree and no
    line matches, the rows are dropped rather than mixing prices.
    """
    if frame is None or frame.empty:
        return pd.DataFrame() if frame is None else frame
    if "CURRENCY" not in frame.columns or "Currency" not in frame.columns:
        return frame
    work = frame.copy()
    response_ccy = work["CURRENCY"].map(iso_currency_code)
    share_ccy = work["Currency"].map(iso_currency_code)
    matched = response_ccy.eq(share_ccy) & share_ccy.ne("")
    if not bool(matched.any()):
        return frame.iloc[0:0].copy()
    return work.loc[matched].drop(columns=["CURRENCY"]).reset_index(drop=True)


def _item_frame_keeping_currency(item) -> pd.DataFrame:
    """One item, with the response CURRENCY kept when Bloomberg sends it.

    This is only for the peer listing read. The book combiner stays on
    ``_combine_items`` and still drops CURRENCY.
    """
    name = getattr(item, "name", None)
    raw = item.df()
    if not isinstance(raw, pd.DataFrame):
        raise ValueError(f"BQL item {name!r} did not return a DataFrame.")
    frame = raw.copy()
    frame.columns = [str(column) for column in frame.columns]
    if not any(str(column).strip().upper() == "ID" for column in frame.columns):
        if isinstance(frame.index, pd.RangeIndex):
            raise ValueError(
                f"BQL item {name!r} has a row-number index and no ID column; "
                f"columns={list(frame.columns)}."
            )
        frame = frame.reset_index()
        frame.columns = [str(column) for column in frame.columns]
    id_column = next(
        (column for column in frame.columns if str(column).strip().upper() == "ID"),
        None,
    )
    if id_column is None:
        for candidate in ("index", "level_0"):
            if candidate in frame.columns:
                id_column = candidate
                break
    if id_column is None:
        raise ValueError(
            f"BQL item {name!r} has no usable ID column; columns={list(frame.columns)}."
        )
    if id_column != "ID":
        frame = frame.rename(columns={id_column: "ID"})
    currency_column = next(
        (column for column in frame.columns if str(column).strip().upper() == "CURRENCY"),
        None,
    )
    if currency_column is not None and currency_column != "CURRENCY":
        frame = frame.rename(columns={currency_column: "CURRENCY"})
    value_column = None
    if name and name in frame.columns:
        value_column = name
    else:
        skipped = {"ID", "DATE", "CURRENCY"}
        candidates = [
            column
            for column in frame.columns
            if column not in skipped
            and str(column).strip().upper() not in _COMBINE_META_COLUMNS
        ]
        if len(candidates) == 1:
            value_column = candidates[0]
    # Desktop 2026-10-30: crncy() on the peer listing returned only ID and
    # CURRENCY. That associated column is the share-class currency.
    currency_is_value = False
    if value_column is None and name == "Currency" and "CURRENCY" in frame.columns:
        value_column = "CURRENCY"
        currency_is_value = True
    if value_column is None:
        raise ValueError(
            f"BQL item {name!r} has no single value column; columns={list(frame.columns)}."
        )
    output_name = name or value_column
    keys = ["ID"]
    if "CURRENCY" in frame.columns and not currency_is_value:
        keys.append("CURRENCY")
    out = frame.loc[:, [*keys, value_column]].copy()
    if value_column != output_name:
        out = out.rename(columns={value_column: output_name})
    out["ID"] = out["ID"].astype("string").fillna("").str.strip()
    out = out.loc[
        out["ID"].ne("") & ~out["ID"].str.lower().isin({"nan", "none", "<na>"})
    ].copy()
    return out


def _collapse_static_duplicates(frame: pd.DataFrame) -> pd.DataFrame:
    """One row per ID. Disagreeing duplicate IDs are dropped."""
    if frame is None or frame.empty or "ID" not in frame.columns:
        return frame
    if not frame["ID"].duplicated().any():
        return frame
    kept = []
    for _, group in frame.groupby("ID", sort=False):
        values = group.drop(columns=["ID"])
        if len(group) == 1 or int(values.nunique(dropna=False).max()) <= 1:
            kept.append(group.head(1))
    if not kept:
        return frame.iloc[0:0].copy()
    return pd.concat(kept, ignore_index=True, sort=False)


def _combine_keeping_currency(response) -> pd.DataFrame:
    """Merge a listing response on ID and CURRENCY. Duplicate IDs do not raise."""
    frames = []
    for item in _response_items(response):
        frame = _item_frame_keeping_currency(item)
        if not frame.empty:
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    currency_frames = [frame for frame in frames if "CURRENCY" in frame.columns]
    plain_frames = [frame for frame in frames if "CURRENCY" not in frame.columns]
    base = None
    if currency_frames:
        base = currency_frames[0].drop_duplicates(["ID", "CURRENCY"], keep="last")
        for frame in currency_frames[1:]:
            extra = frame.drop_duplicates(["ID", "CURRENCY"], keep="last")
            base = base.merge(extra, on=["ID", "CURRENCY"], how="outer")
    for frame in plain_frames:
        extra = _collapse_static_duplicates(frame)
        if extra.empty:
            continue
        if base is None:
            base = extra
            continue
        base = base.merge(extra, on="ID", how="left")
    if base is None:
        return pd.DataFrame()
    return base.reset_index(drop=True)


def keep_one_listing(frame: pd.DataFrame | None) -> tuple[pd.DataFrame, list[str]]:
    """One ticker per primary ISIN. Extra listings are noted and dropped."""
    notes: list[str] = []
    if frame is None or frame.empty:
        return pd.DataFrame() if frame is None else frame, notes
    if "ISIN" not in frame.columns:
        return frame, notes
    ticker_column = "Ticker" if "Ticker" in frame.columns else ("ID" if "ID" in frame.columns else "")
    if not ticker_column:
        return frame, notes
    work = frame.copy()
    work["_isin"] = work["ISIN"].map(
        lambda value: "" if value is None or (not isinstance(value, str) and pd.isna(value)) else str(value).strip().upper()
    )
    work["_ticker"] = work[ticker_column].map(
        lambda value: "" if value is None or (not isinstance(value, str) and pd.isna(value)) else str(value).strip()
    )
    kept = []
    for isin, group in work.groupby("_isin", sort=False):
        if not isin or isin in {"NAN", "NONE", "<NA>"}:
            notes.append("A listing row had no ISIN and was dropped.")
            continue
        tickers: list[str] = []
        for ticker in group["_ticker"].tolist():
            if ticker and ticker.lower() not in {"nan", "none", "<na>"} and ticker not in tickers:
                tickers.append(ticker)
        if not tickers:
            notes.append(f"{isin}: listing had no ticker and was dropped.")
            continue
        if len(tickers) > 1:
            notes.append(
                f"{isin}: kept {tickers[0]} and dropped {len(tickers) - 1} other listing(s)."
            )
        kept.append(group.loc[group["_ticker"].eq(tickers[0])].head(1))
    if not kept:
        drop = [column for column in work.columns if str(column).startswith("_")]
        return work.iloc[0:0].drop(columns=drop), notes
    out = pd.concat(kept, ignore_index=True, sort=False)
    drop = [column for column in out.columns if str(column).startswith("_")]
    return out.drop(columns=drop), notes


def fx_to_usd_millions(amount, currency, rates: dict) -> float:
    """Share-class assets are already in millions.

    A USD amount is kept. Another ISO code is converted with a positive
    spot. ``multiply`` uses ``{CCY}USD``. ``divide`` uses ``USD{CCY}``.
    """
    number = _usd_amount(amount)
    code = iso_currency_code(currency)
    if pd.isna(number) or not code:
        return pd.NA
    if code == "USD":
        return float(number)
    spec = rates.get(code)
    if spec is None:
        return pd.NA
    operation, rate = spec
    if rate is None or pd.isna(rate) or float(rate) <= 0:
        return pd.NA
    if operation == "multiply":
        return float(number) * float(rate)
    return float(number) / float(rate)


def _spot_rates_to_usd(bq, currencies, errors, progress) -> dict:
    """One positive spot per non-USD code. A missing pair does not invent a rate."""
    codes = []
    seen = set()
    for currency in currencies:
        code = iso_currency_code(currency)
        if not code or code == "USD" or code in seen:
            continue
        seen.add(code)
        codes.append(code)
    if not codes:
        return {}
    pair_to_code = {}
    pairs = []
    for code in codes:
        multiply_id = f"{code}USD Curncy"
        divide_id = f"USD{code} Curncy"
        pairs.extend((multiply_id, divide_id))
        pair_to_code[multiply_id.upper()] = (code, "multiply")
        pair_to_code[divide_id.upper()] = (code, "divide")
    _note(progress, f"Converting {len(codes)} non-USD share-class amounts to USD…")
    found: dict[str, tuple[str, float]] = {}
    labeled = []
    for number, batch in enumerate(_chunks(pairs, SHARE_CLASS_BATCH), start=1):
        labeled.append(
            (
                f"fx_{number}",
                bql.Request(batch, {"Rate": bq.data.px_last()}, with_params={"mode": "cached"}),
            )
        )
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: USD spot request failed.")
                continue
            frame = _combine_items(response)
            if frame.empty or "Rate" not in frame.columns:
                errors.append(f"{label}: USD spot request returned no rate.")
                continue
            if "ID" in frame.columns:
                id_column = "ID"
            elif "index" in frame.columns:
                id_column = "index"
            else:
                errors.append(f"{label}: USD spot request has no security id.")
                continue
            for _, row in frame.iterrows():
                key = str(row[id_column]).strip().upper()
                mapped = pair_to_code.get(key)
                rate = _usd_amount(row["Rate"])
                if mapped is None or pd.isna(rate) or float(rate) <= 0:
                    continue
                code, operation = mapped
                current = found.get(code)
                if current is not None and current[0] == "multiply":
                    continue
                if operation == "divide" and current is not None:
                    continue
                found[code] = (operation, float(rate))
    missing = [code for code in codes if code not in found]
    if missing:
        errors.append(
            "No USD spot for share-class currency: "
            + ", ".join(missing)
            + ". Those amounts stay blank."
        )
    return found


def usd_millions(value) -> float:
    """Full USD amount divided by one million. A missing amount stays blank."""
    number = _usd_amount(value)
    if pd.isna(number):
        return pd.NA
    return float(number) / 1_000_000


def stamp_fund_totals(table: pd.DataFrame, amounts_by_ticker: dict) -> pd.Series:
    """Copy one fund total onto every share class of that fund.

    The amount is the full USD figure from ``fund_total_assets``. It is
    divided by one million here. Share classes are not added together.
    The ticker is the Primary Yes row when that row is present.
    """
    from .flow_view import fund_flow_tickers

    empty = pd.Series(pd.NA, index=table.index, dtype="object")
    if table is None or table.empty or "Fund Name" not in table.columns:
        return empty
    chosen = fund_flow_tickers(table)
    by_fund: dict[str, float] = {}
    for _, row in chosen.iterrows():
        raw = amounts_by_ticker.get(str(row["ID_KEY"]).strip().upper())
        if raw is None or pd.isna(raw):
            continue
        millions = usd_millions(raw)
        if pd.isna(millions):
            continue
        by_fund[str(row["Category"])] = millions
    keys = table["Fund Name"].map(fund_name_key)
    return keys.map(lambda key: by_fund.get(key, pd.NA))


def _typed_ticker_list(book: pd.DataFrame | None) -> list[str]:
    """Listing tickers from IsinEntry, in first-seen order."""
    if book is None or book.empty or "Ticker" not in book.columns:
        return []
    tickers = []
    seen = set()
    for value in book["Ticker"].tolist():
        text = str(value).strip()
        key = text.upper()
        if not text or key in {"NAN", "NONE", "<NA>"} or key in seen:
            continue
        seen.add(key)
        tickers.append(text)
    return tickers


def _ticker_market_request(bq, tickers: list[str]):
    """Quotes, currency, and class assets for the typed listing.

    Class assets stay in this request because they have no currency
    argument. ``fund_total_assets(currency='USD')`` stays in its own
    request so that parameter cannot reach bid, ask, or last. There is
    no ``showids``.
    """
    return bql.Request(
        tickers,
        {
            "Currency": bq.data.crncy(),
            "Last": bq.data.px_last(),
            "Bid": bq.data.px_bid(),
            "Ask": bq.data.px_ask(),
            "Mid": bq.data.px_mid(),
            "Share Class AUM": bq.data.fund_class_assets(),
            "Share Class AUM Currency": bq.data.fund_class_assets_crncy(),
        },
        with_params={"mode": "cached"},
    )


def _ticker_tracking_request(bq, tickers: list[str]):
    """One PX_LAST-based tracking-error number per typed listing."""
    return bql.Request(
        tickers,
        {"Tracking Error": bq.data.tracking_error()["value"]},
        with_params={"mode": "cached"},
    )


def _ticker_nav_tracking_request(bq, tickers: list[str]):
    """One NAV-based tracking-error number per typed listing.

    Catalog spelling is ``nav_tracking_error()`` ("Net Asset Value Tracking
    Error", RAG KB 22). The operator confirmed on 2026-10-24 that the FLDS
    tab lists the item and returns numbers. It is a separate cached request
    so a NAV failure does not blank the PX_LAST tracking error column.
    """
    return bql.Request(
        tickers,
        {"NAV Tracking Error": bq.data.nav_tracking_error()["value"]},
        with_params={"mode": "cached"},
    )


def _ticker_expense_request(bq, tickers: list[str]):
    """Expense ratio on the vendor scale. Do not divide by 100."""
    return bql.Request(
        tickers,
        {"Expense Ratio": bq.data.fund_expense_ratio()["value"]},
        with_params={"mode": "cached"},
    )


def _ticker_fund_aum_request(bq, tickers: list[str]):
    """Fund total assets already in USD. Currency is not applied to quotes."""
    return bql.Request(
        tickers,
        {"FundAUM": bq.data.fund_total_assets(currency="USD")},
        with_params={"mode": "cached"},
    )


def _quotes_by_ticker(frame: pd.DataFrame) -> pd.DataFrame:
    if frame is None or frame.empty:
        return pd.DataFrame()
    if "ID" in frame.columns:
        id_column = "ID"
    elif "index" in frame.columns:
        id_column = "index"
    else:
        return pd.DataFrame()
    quotes = frame.copy()
    quotes["_ticker"] = quotes[id_column].astype(str).str.strip().str.upper()
    quotes = quotes.loc[~quotes["_ticker"].isin(["", "NAN", "NONE", "<NA>"])]
    return quotes.drop_duplicates("_ticker", keep="first")


def _overlay_column(table: pd.DataFrame, quotes: pd.DataFrame, column: str) -> None:
    if quotes.empty or column not in quotes.columns or "_ticker" not in table.columns:
        return
    lookup = quotes.set_index("_ticker")[column]
    mapped = table["_ticker"].map(lookup)
    current = table[column] if column in table.columns else pd.Series(pd.NA, index=table.index)
    table[column] = mapped.where(mapped.notna(), current)


def _apply_ticker_quotes(bq, table: pd.DataFrame, book: pd.DataFrame | None, errors, progress) -> pd.DataFrame:
    """Replace quotes with the typed ticker. ISIN listings are not the price source."""
    quoted = table.copy()
    tickers = _typed_ticker_list(book)
    if not tickers or "Ticker" not in quoted.columns:
        return quoted
    quoted["_ticker"] = quoted["Ticker"].fillna("").astype(str).str.strip().str.upper()
    frames = []
    labeled = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"ticker_px_{number}", _ticker_market_request(bq, batch)))
    _note(progress, f"Quoting {len(tickers)} typed tickers…")
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: typed-ticker quote failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(response))
            if frame.empty:
                errors.append(f"{label}: typed-ticker quote returned no rows.")
                continue
            frames.append(frame)
    if frames:
        market = pd.concat(frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        for column in (
            "Currency",
            "Last",
            "Bid",
            "Ask",
            "Mid",
            "Share Class AUM",
            "Share Class AUM Currency",
        ):
            _overlay_column(quoted, market, column)
    return quoted.drop(columns=["_ticker"], errors="ignore")


def _apply_book_snapshots(bq, table: pd.DataFrame, book: pd.DataFrame | None, errors, progress) -> pd.DataFrame:
    """Quotes, fund assets, and both tracking errors in one wave.

    Each family stays its own request. A failed family leaves that column
    blank and does not clear the others. Class assets stay on the quote
    request. Fund assets stay off it. The two tracking-error items stay
    apart, so a NAV failure does not blank the PX_LAST column.
    """
    from .flow_view import fund_flow_tickers

    quoted = table.copy()
    quoted["Fund AUM (USD mn)"] = pd.NA
    if "Ticker" not in quoted.columns:
        return quoted
    quoted["_ticker"] = quoted["Ticker"].fillna("").astype(str).str.strip().str.upper()
    tickers = _typed_ticker_list(book)
    chosen = fund_flow_tickers(quoted)
    fund_tickers = chosen["Ticker"].tolist() if not chosen.empty else []
    labeled = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"ticker_px_{number}", _ticker_market_request(bq, batch)))
        labeled.append((f"tracking_{number}", _ticker_tracking_request(bq, batch)))
        labeled.append((f"nav_tracking_{number}", _ticker_nav_tracking_request(bq, batch)))
    for number, batch in enumerate(_chunks(fund_tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"fund_aum_{number}", _ticker_fund_aum_request(bq, batch)))
    quote_frames = []
    te_frames = []
    nav_frames = []
    aum_frames = []
    if labeled:
        _note(
            progress,
            f"Loading quotes, fund assets, and tracking error for {len(tickers)} tickers…",
        )
        for label, response in _execute_waves(bq, labeled):
            if label.startswith("ticker_px_"):
                failure = "typed-ticker quote failed."
                empty = "typed-ticker quote returned no rows."
                bucket = quote_frames
                required = ""
            elif label.startswith("nav_tracking_"):
                failure = "NAV tracking error failed."
                empty = "NAV tracking error returned no rows."
                bucket = nav_frames
                required = "NAV Tracking Error"
            elif label.startswith("tracking_"):
                failure = "tracking error failed."
                empty = "tracking error returned no rows."
                bucket = te_frames
                required = "Tracking Error"
            elif label.startswith("fund_aum_"):
                failure = "fund assets failed."
                empty = "fund assets returned no USD total."
                bucket = aum_frames
                required = "FundAUM"
            else:
                continue
            if not _is_response(response):
                errors.append(f"{label}: {failure}")
                continue
            frame = _quotes_by_ticker(_combine_items(response))
            if frame.empty or (required and required not in frame.columns):
                errors.append(f"{label}: {empty}")
                continue
            if required == "Tracking Error":
                frame["Tracking Error"] = frame["Tracking Error"].map(tracking_error_number)
            elif required == "NAV Tracking Error":
                frame["NAV Tracking Error"] = frame["NAV Tracking Error"].map(tracking_error_number)
            bucket.append(frame)
    if quote_frames:
        market = pd.concat(quote_frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        for column in (
            "Currency",
            "Last",
            "Bid",
            "Ask",
            "Mid",
            "Share Class AUM",
            "Share Class AUM Currency",
        ):
            _overlay_column(quoted, market, column)
    if te_frames:
        values = pd.concat(te_frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        _overlay_column(quoted, values, "Tracking Error")
    if nav_frames:
        values = pd.concat(nav_frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        _overlay_column(quoted, values, "NAV Tracking Error")
    amounts: dict[str, object] = {}
    if aum_frames:
        assets = pd.concat(aum_frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        for _, row in assets.iterrows():
            amounts[str(row["_ticker"]).strip().upper()] = row["FundAUM"]
    quoted["Fund AUM (USD mn)"] = stamp_fund_totals(quoted, amounts)
    return quoted.drop(columns=["_ticker"], errors="ignore")


def fund_total_usd_millions(values) -> pd.Series:
    """One fund total per row, in USD millions.

    ``fund_total_assets(currency='USD')`` is the full dollar amount. The
    currency code is not a rate, and the rows are not added together.
    """
    series = values if isinstance(values, pd.Series) else pd.Series(values, dtype="object")
    return series.map(usd_millions)


def _apply_fund_total_usd(bq, table: pd.DataFrame, book: pd.DataFrame | None, errors, progress) -> pd.DataFrame:
    """One fund total per fund, copied onto each share class.

    The request stays separate from quotes. Share classes are not added.
    """
    from .flow_view import fund_flow_tickers

    quoted = table.copy()
    quoted["Fund AUM (USD mn)"] = pd.NA
    chosen = fund_flow_tickers(quoted)
    tickers = chosen["Ticker"].tolist() if not chosen.empty else []
    if not tickers or "Ticker" not in quoted.columns:
        return quoted
    frames = []
    labeled = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"fund_aum_{number}", _ticker_fund_aum_request(bq, batch)))
    _note(progress, f"Loading fund assets in USD for {len(tickers)} funds…")
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: fund assets failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(response))
            if frame.empty or "FundAUM" not in frame.columns:
                errors.append(f"{label}: fund assets returned no USD total.")
                continue
            frames.append(frame)
    amounts: dict[str, object] = {}
    if frames:
        assets = pd.concat(frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        for _, row in assets.iterrows():
            amounts[str(row["_ticker"]).strip().upper()] = row["FundAUM"]
    quoted["Fund AUM (USD mn)"] = stamp_fund_totals(quoted, amounts)
    return quoted


def _apply_tracking_error(bq, table: pd.DataFrame, tickers: list[str], errors, progress) -> pd.DataFrame:
    """Overlay tracking error from the typed ticker. A failed batch stays blank."""
    quoted = table.copy()
    if "Tracking Error" not in quoted.columns:
        quoted["Tracking Error"] = pd.NA
    if not tickers or "Ticker" not in quoted.columns:
        return quoted
    quoted["_ticker"] = quoted["Ticker"].fillna("").astype(str).str.strip().str.upper()
    frames = []
    labeled = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"tracking_{number}", _ticker_tracking_request(bq, batch)))
    _note(progress, f"Loading tracking error for {len(tickers)} tickers…")
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: tracking error failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(response))
            if frame.empty or "Tracking Error" not in frame.columns:
                errors.append(f"{label}: tracking error returned no rows.")
                continue
            frame["Tracking Error"] = frame["Tracking Error"].map(tracking_error_number)
            frames.append(frame)
    if frames:
        values = pd.concat(frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        _overlay_column(quoted, values, "Tracking Error")
    return quoted.drop(columns=["_ticker"], errors="ignore")


def _apply_nav_tracking_error(
    bq, table: pd.DataFrame, tickers: list[str], errors, progress
) -> pd.DataFrame:
    """Overlay the NAV-based tracking error. A failed batch stays blank."""
    quoted = table.copy()
    if "NAV Tracking Error" not in quoted.columns:
        quoted["NAV Tracking Error"] = pd.NA
    if not tickers or "Ticker" not in quoted.columns:
        return quoted
    quoted["_ticker"] = quoted["Ticker"].fillna("").astype(str).str.strip().str.upper()
    frames = []
    labeled = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append(
            (f"nav_tracking_{number}", _ticker_nav_tracking_request(bq, batch))
        )
    _note(progress, f"Loading NAV tracking error for {len(tickers)} tickers…")
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: NAV tracking error failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(response))
            if frame.empty or "NAV Tracking Error" not in frame.columns:
                errors.append(f"{label}: NAV tracking error returned no rows.")
                continue
            frame["NAV Tracking Error"] = frame["NAV Tracking Error"].map(
                tracking_error_number
            )
            frames.append(frame)
    if frames:
        values = pd.concat(frames, ignore_index=True, sort=False).drop_duplicates(
            "_ticker", keep="first"
        )
        _overlay_column(quoted, values, "NAV Tracking Error")
    return quoted.drop(columns=["_ticker"], errors="ignore")


def _apply_expense_ratio(bq, table: pd.DataFrame, tickers: list[str], errors, progress) -> pd.DataFrame:
    """Overlay the expense ratio. A failed batch stays blank."""
    quoted = table.copy()
    if "Expense Ratio" not in quoted.columns:
        quoted["Expense Ratio"] = pd.NA
    if not tickers or "Ticker" not in quoted.columns:
        return quoted
    quoted["_ticker"] = quoted["Ticker"].fillna("").astype(str).str.strip().str.upper()
    frames = []
    labeled = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"expense_{number}", _ticker_expense_request(bq, batch)))
    _note(progress, f"Loading expense ratio for {len(tickers)} tickers…")
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: expense ratio failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(response))
            if frame.empty or "Expense Ratio" not in frame.columns:
                errors.append(f"{label}: expense ratio returned no rows.")
                continue
            frame["Expense Ratio"] = frame["Expense Ratio"].map(expense_ratio_number)
            frames.append(frame)
    if frames:
        values = pd.concat(frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        _overlay_column(quoted, values, "Expense Ratio")
    return quoted.drop(columns=["_ticker"], errors="ignore")


def fund_aum_from_class(frame: pd.DataFrame) -> pd.Series:
    """Sum class AUM in USD millions for each fund."""
    empty = pd.Series(pd.NA, index=frame.index, dtype="object")
    if frame is None or frame.empty or "Fund Name" not in frame.columns:
        return empty
    if "Share Class AUM (USD mn)" not in frame.columns:
        return empty
    amounts = pd.to_numeric(frame["Share Class AUM (USD mn)"], errors="coerce")
    names = frame["Fund Name"].astype(str).str.strip()
    totals = amounts.groupby(names).sum(min_count=1)
    return names.map(totals)


def _typed_listing_tickers(book: pd.DataFrame | None) -> dict[tuple[str, str], str]:
    """Typed ticker for each fund and ISIN. Blank tickers are ignored."""
    chosen: dict[tuple[str, str], str] = {}
    if book is None or book.empty or "Ticker" not in book.columns:
        return chosen
    for _, row in book.iterrows():
        fund = str(row.get("Fund Name", "")).strip()
        isin = str(row.get("ISIN", "")).strip().upper()
        ticker = str(row.get("Ticker", "")).strip()
        if not fund or not isin or not ticker:
            continue
        if isin.lower() in {"nan", "none", "<na>"} or ticker.lower() in {"nan", "none", "<na>"}:
            continue
        chosen[(fund, isin)] = ticker
    return chosen


def _attach_table_order(table: pd.DataFrame, book: pd.DataFrame | None) -> pd.DataFrame:
    """Copy the typed order onto each fund and ISIN. A blank order sorts last."""
    if table is None or table.empty:
        return table
    ordered = table.copy()
    if book is None or book.empty or "Order" not in book.columns:
        ordered["Order"] = pd.NA
        return ordered
    orders = book.copy()
    orders["_fund"] = orders["Fund Name"].astype(str).str.strip()
    orders["_isin"] = orders["ISIN"].astype(str).str.strip().str.upper()
    orders = orders.loc[:, ["_fund", "_isin", "Order"]].drop_duplicates(
        ["_fund", "_isin"],
        keep="first",
    )
    ordered["_fund"] = ordered["Fund Name"].astype(str).str.strip()
    ordered["_isin"] = ordered["ISIN"].astype(str).str.strip().str.upper()
    ordered = ordered.drop(columns=["Order"], errors="ignore")
    ordered = ordered.merge(orders, on=["_fund", "_isin"], how="left")
    return ordered.drop(columns=["_fund", "_isin"])


def _apply_typed_strategy(table: pd.DataFrame, book: pd.DataFrame | None) -> pd.DataFrame:
    """Replace Strategy with the text typed on the book row."""
    if table is None or table.empty or book is None or book.empty or "Strategy" not in book.columns:
        return table
    typed = book.copy()
    typed["_fund"] = typed["Fund Name"].astype(str).str.strip()
    typed["_isin"] = typed["ISIN"].astype(str).str.strip().str.upper()
    typed["_typed_strategy"] = typed["Strategy"].fillna("").astype(str).str.strip()
    typed = typed.loc[:, ["_fund", "_isin", "_typed_strategy"]].drop_duplicates(
        ["_fund", "_isin"],
        keep="first",
    )
    out = table.copy()
    out["_fund"] = out["Fund Name"].astype(str).str.strip()
    out["_isin"] = out["ISIN"].astype(str).str.strip().str.upper()
    out = out.merge(typed, on=["_fund", "_isin"], how="left")
    mask = out["_typed_strategy"].fillna("").astype(str).str.strip().ne("")
    if "Strategy" not in out.columns:
        out["Strategy"] = pd.NA
    out.loc[mask, "Strategy"] = out.loc[mask, "_typed_strategy"]
    return out.drop(columns=["_fund", "_isin", "_typed_strategy"])


def _usd_amount(value) -> float:
    """Keep a positive amount. Zero and an N/A token stay blank."""
    number = market_numbers(pd.Series([value]), allow_zero=False).iloc[0]
    if pd.isna(number):
        return pd.NA
    return float(number)


def keep_primary_listing(frame: pd.DataFrame, book: pd.DataFrame | None = None) -> pd.DataFrame:
    """One row per fund and ISIN.

    A typed ticker such as ``HSAX LN Equity`` wins. Otherwise keep a
    listing that has both quotes.
    If the typed ticker is absent, that ticker is written onto the row and
    the quotes from the other listing are cleared.
    """
    if frame is None or frame.empty or "ISIN" not in frame.columns:
        return frame
    work = frame.copy()
    work["_isin"] = work["ISIN"].fillna("").astype(str).str.strip().str.upper()
    if "Fund Name" in work.columns:
        work["_fund"] = work["Fund Name"].fillna("").astype(str).str.strip()
    else:
        work["_fund"] = ""
    missing = work["_isin"].eq("") | work["_isin"].isin({"NAN", "NONE", "<NA>"})
    loose = work.loc[missing]
    keyed = work.loc[~missing].copy()
    if keyed.empty:
        return frame
    typed = _typed_listing_tickers(book)
    ticker_text = (
        keyed["Ticker"].fillna("").astype(str).str.strip().str.upper()
        if "Ticker" in keyed.columns
        else pd.Series("", index=keyed.index)
    )
    wanted = pd.Series(
        [typed.get((fund, isin), "") for fund, isin in zip(keyed["_fund"], keyed["_isin"])],
        index=keyed.index,
    )
    keyed["_wanted"] = wanted
    keyed["_typed"] = wanted.ne("") & ticker_text.eq(wanted.str.upper())
    bid = pd.to_numeric(keyed["Bid"], errors="coerce") if "Bid" in keyed.columns else pd.Series(pd.NA, index=keyed.index)
    ask = pd.to_numeric(keyed["Ask"], errors="coerce") if "Ask" in keyed.columns else pd.Series(pd.NA, index=keyed.index)
    keyed["_quoted"] = bid.notna() & ask.notna()
    keyed = keyed.sort_values(
        ["_fund", "_isin", "_typed", "_quoted"],
        ascending=[True, True, True, True],
        kind="mergesort",
    )
    chosen = keyed.groupby(["_fund", "_isin"], sort=False).tail(1).copy()
    quote_fields = (
        "Bid",
        "Ask",
        "Mid",
        "Last",
        "Absolute Spread",
        "Percent Spread",
    )
    for index, row in chosen.iterrows():
        wanted_ticker = str(row.get("_wanted", "")).strip()
        if not wanted_ticker or bool(row.get("_typed", False)):
            continue
        chosen.at[index, "Ticker"] = wanted_ticker
        for column in quote_fields:
            if column in chosen.columns:
                chosen.at[index, column] = pd.NA
    combined = pd.concat([chosen, loose], ignore_index=True, sort=False)
    drop = [column for column in combined.columns if column.startswith("_")]
    return combined.drop(columns=drop)


def _text_cell(frame: pd.DataFrame | None, column: str) -> str:
    if frame is None or frame.empty or column not in frame.columns:
        return ""
    return clean_market_text(frame[column].iloc[0])


def _profile_request(bq, isin: str):
    return bql.Request(
        isin,
        {
            "Benchmark Ticker": bq.data.fund_benchmark_prim()["value"],
            "Strategy": bq.data.fund_strategy()["value"],
        },
    )


def benchmark_index_id(value) -> str:
    """Turn a benchmark ticker into an index id. ``SPX`` becomes ``SPX Index``.

    A missing token such as ``N/A`` or ``N/A - suspended`` stays blank.
    It is not requested as an index.
    """
    text = clean_market_text(value)
    if not text:
        return ""
    if text.upper().endswith(" INDEX"):
        return text
    return f"{text} Index"


def _id_and_name(frame: pd.DataFrame) -> dict[str, str]:
    if frame is None or frame.empty or "Name" not in frame.columns:
        return {}
    if "ID" in frame.columns:
        id_column = "ID"
    elif "index" in frame.columns:
        id_column = "index"
    else:
        return {}
    names = {}
    for _, row in frame.iterrows():
        key = str(row[id_column]).strip()
        long_name = clean_market_text(row["Long Name"]) if "Long Name" in frame.columns else ""
        short_name = clean_market_text(row["Name"]) if "Name" in frame.columns else ""
        name = long_name or short_name
        if key and name:
            names[key] = name
    return names


def _primary_class_request(bq, company_id: str):
    """Primary share classes of one umbrella. This does not list every listing."""
    universe = bq.univ.fundsuniv(("active", "primary")).filter(
        bq.data.id_bb_company() == str(company_id)
    )
    return bql.Request(
        universe,
        {"ISIN": bq.data.id_isin()["value"]},
        with_params={"mode": "cached", "showids": "f"},
    )


def _mark_primary_classes(bq, table, company_ids, errors, progress) -> pd.DataFrame:
    marked = table.copy()
    if "Fund Name" not in marked.columns or "ISIN" not in marked.columns:
        return marked
    marked["Primary"] = "No"
    pairs = [(fund, company_id) for fund, company_id in company_ids.items() if str(company_id).strip()]
    if not pairs:
        return marked
    labeled = [(fund, _primary_class_request(bq, company_id)) for fund, company_id in pairs]
    _note(progress, f"Marking primary share classes for {len(labeled)} funds…")
    for batch in _chunks(labeled, SHARE_CLASS_BATCH):
        for fund, response in _execute_many(bq, batch):
            fund_rows = marked["Fund Name"].astype(str).str.strip().eq(str(fund).strip())
            if not _is_response(response):
                errors.append(f"{fund}: primary share-class request failed.")
                marked.loc[fund_rows, "Primary"] = pd.NA
                continue
            frame = _combine_items(response)
            if frame.empty or "ISIN" not in frame.columns:
                errors.append(f"{fund}: primary share-class request returned no rows.")
                marked.loc[fund_rows, "Primary"] = pd.NA
                continue
            isins = {
                str(value).strip().upper()
                for value in frame["ISIN"].tolist()
                if str(value).strip() and str(value).strip().lower() not in {"nan", "none", "<na>"}
            }
            row_isins = marked["ISIN"].astype(str).str.strip().str.upper()
            marked.loc[fund_rows & row_isins.isin(isins), "Primary"] = "Yes"
            marked.loc[fund_rows & ~row_isins.isin(isins), "Primary"] = "No"
    return marked


def _apply_benchmark_names(bq, table, errors, progress) -> pd.DataFrame:
    """Shown benchmark name of the ``fund_benchmark_prim`` index id.

    The id is already in ``Benchmark Index``. ``long_comp_name`` is preferred.
    A blank long name keeps ``name()``, then the index id.
    """
    named = table.copy()
    if "Benchmark Index" not in named.columns:
        return named
    index_ids = []
    seen = set()
    for value in named["Benchmark Index"].tolist():
        index_id = benchmark_index_id(value)
        if index_id and index_id not in seen:
            seen.add(index_id)
            index_ids.append(index_id)
    if not index_ids:
        named["Benchmark"] = ""
        return named
    _note(progress, f"Reading benchmark names for {len(index_ids)} indexes…")
    names: dict[str, str] = {}
    labeled = []
    for number, batch in enumerate(_chunks(index_ids, SHARE_CLASS_BATCH), start=1):
        labeled.append(
            (
                f"benchmark_{number}",
                bql.Request(
                    batch,
                    {
                        "Name": bq.data.name()["value"],
                        "Long Name": bq.data.long_comp_name()["value"],
                    },
                    with_params={"mode": "cached"},
                ),
            )
        )
    for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: benchmark name request failed.")
                continue
            found = _id_and_name(_combine_items(response))
            if not found:
                errors.append(f"{label}: benchmark name request returned no names.")
                continue
            names.update(found)

    def _display_name(value):
        index_id = benchmark_index_id(value)
        if not index_id:
            return ""
        return names.get(index_id, index_id)

    named["Benchmark"] = named["Benchmark Index"].map(_display_name)
    return named


TYPED_BOOK_COLUMNS = ("Fund Name", "ISIN", "Ticker", "Order", "Strategy")

PROJECTION_QUOTE_FIELDS = (
    "Bid",
    "Ask",
    "Mid",
    "Last",
    "Absolute Spread",
    "Percent Spread",
)


def typed_book_rows(book: pd.DataFrame | None) -> pd.DataFrame:
    """One row per typed ``IsinEntry``, in typed order.

    This is the whole row set of the app: the fund name, the ISIN, the
    listing ticker, the table order, and the Strategy text that the top
    dropdown reads. A line without a fund name or an ISIN is skipped.
    A repeated fund and ISIN is kept once.
    """
    columns = list(TYPED_BOOK_COLUMNS)
    if book is None or book.empty:
        return pd.DataFrame(columns=columns)
    rows = []
    seen: set[tuple[str, str]] = set()
    for _, record in book.iterrows():
        fund = str(record.get("Fund Name", "")).strip()
        isin = _upper_isin(record.get("ISIN"))
        if not fund or not isin or (fund, isin) in seen:
            continue
        seen.add((fund, isin))
        rows.append(
            {
                "Fund Name": fund,
                "ISIN": isin,
                "Ticker": clean_market_text(record.get("Ticker")),
                "Order": record.get("Order", pd.NA),
                "Strategy": clean_market_text(record.get("Strategy")),
            }
        )
    return pd.DataFrame(rows, columns=columns)


def project_onto_typed_book(
    table: pd.DataFrame | None,
    book: pd.DataFrame | None,
    fund_profile: dict[str, str] | None = None,
) -> tuple[pd.DataFrame, list[str]]:
    """Keep exactly the typed ``IsinEntry`` rows.

    A linked share class that is not typed is dropped, so a fund is never
    shown as a different share class. A typed line that Bloomberg did not
    return keeps its typed identity and blank enrichment; it is not removed.
    Quotes are cleared when the matched row is a different listing, because
    they belong to that other listing. ``fund_profile`` supplies the typed
    fund's benchmark index id when the linked set did not cover the line.
    """
    typed = typed_book_rows(book)
    if typed.empty:
        return (pd.DataFrame() if table is None else table), []
    notes: list[str] = []
    source = pd.DataFrame() if table is None else table.copy()
    if not source.empty:
        source["_isin"] = (
            source["ISIN"].map(_upper_isin)
            if "ISIN" in source.columns
            else pd.Series("", index=source.index)
        )
        source["_fund"] = (
            source["Fund Name"].fillna("").astype(str).str.strip()
            if "Fund Name" in source.columns
            else pd.Series("", index=source.index)
        )
        source["_ticker"] = (
            source["Ticker"].fillna("").astype(str).str.strip().str.upper()
            if "Ticker" in source.columns
            else pd.Series("", index=source.index)
        )
    profile = dict(fund_profile or {})
    rows: list[dict[str, object]] = []
    for _, want in typed.iterrows():
        fund = str(want["Fund Name"]).strip()
        isin = str(want["ISIN"]).strip().upper()
        ticker = str(want["Ticker"]).strip()
        record: dict[str, object] = {}
        matched = None
        if not source.empty:
            same_isin = source.loc[source["_isin"].eq(isin)]
            if not same_isin.empty:
                same_fund = same_isin.loc[same_isin["_fund"].eq(fund)]
                candidates = same_fund if not same_fund.empty else same_isin
                if ticker and candidates["_ticker"].eq(ticker.upper()).any():
                    candidates = candidates.loc[candidates["_ticker"].eq(ticker.upper())]
                matched = candidates.iloc[0]
        if matched is not None:
            record = matched.to_dict()
            if ticker and str(record.get("Ticker", "")).strip().upper() != ticker.upper():
                for column in PROJECTION_QUOTE_FIELDS:
                    if column in record:
                        record[column] = pd.NA
        else:
            record = {column: pd.NA for column in source.columns}
            notes.append(
                f"{fund} ({isin}): the typed share class was not in the linked set. "
                "Its linked fields stay blank."
            )
        record["Fund Name"] = fund
        record["ISIN"] = isin
        if ticker:
            record["Ticker"] = ticker
        record["Order"] = want["Order"]
        record["Strategy"] = str(want["Strategy"]).strip()
        record["List"] = "Book"
        if fund in profile and missing_market_text(record.get("Benchmark Index")):
            record["Benchmark Index"] = profile[fund]
        rows.append(record)
    out = pd.DataFrame(rows)
    for column in SHARE_CLASS_COLUMNS:
        if column not in out.columns:
            out[column] = pd.NA
    keep = list(SHARE_CLASS_COLUMNS)
    if "Order" not in keep:
        keep.append("Order")
    out = out.loc[:, keep]
    return out.reset_index(drop=True), notes


def fetch_share_class_directory(
    book: pd.DataFrame | None = None,
    progress=None,
    include_peers: bool = False,
) -> SourceResult:
    """Load the typed book, using linked share classes only as enrichment.

    Peer membership is the manual list in ``peer_map.py``. This pull does
    not screen Bloomberg for peers. The rows that reach the app are the
    typed ``IsinEntry`` lines, in typed order; every other share class of
    that umbrella is dropped. Primary is Yes when the typed share class is
    in the active primary universe for that umbrella. The benchmark column
    is ``long_comp_name`` of the ``fund_benchmark_prim`` index id.
    """
    if book is None:
        book = isin_book_frame()
    seeds = representative_seeds(book)
    if not seeds:
        return SourceResult(empty_share_classes(), ["ISIN_BOOK is empty."])
    gaps = []
    if bql is None:
        return SourceResult(
            empty_share_classes(),
            [
                *gaps,
                "bql is unavailable. Run this pull on Bloomberg BQuant Desktop.",
            ],
        )

    bq = bql.Service()
    errors: list[str] = list(gaps)
    company_ids: dict[str, str] = {}

    _note(progress, f"Resolving fund umbrella ids for {len(seeds)} funds…")
    umbrella_requests = [
        (fund, _umbrella_request(bq, isin)) for fund, isin in seeds
    ]
    for batch in _chunks(umbrella_requests, SHARE_CLASS_BATCH):
        for fund, response in _execute_many(bq, batch):
            if not _is_response(response):
                errors.append(f"{fund}: umbrella id request failed.")
                continue
            company_id = company_id_from_frame(_combine_items(response))
            if not company_id:
                errors.append(f"{fund}: umbrella id is blank.")
                continue
            company_ids[fund] = company_id

    frames = []
    share_requests = [
        (fund, _share_class_request(bq, company_id))
        for fund, company_id in company_ids.items()
    ]
    _note(progress, f"Loading linked share classes for {len(share_requests)} funds…")
    returned: dict[str, set[str]] = {}
    for batch in _chunks(share_requests, SHARE_CLASS_BATCH):
        for fund, response in _execute_many(bq, batch):
            if not _is_response(response):
                errors.append(f"{fund}: share-class request failed.")
                continue
            frame = _combine_items(response)
            if frame.empty:
                errors.append(f"{fund}: share-class request returned no rows.")
                continue
            frame = frame.copy()
            frame["Fund Name"] = fund
            frame["List"] = "Book"
            frame["ID BB Company"] = company_ids.get(fund, "")
            frames.append(frame)
            if "ISIN" in frame.columns:
                returned[fund] = {
                    str(value).strip().upper()
                    for value in frame["ISIN"]
                    if str(value).strip()
                }

    if include_peers:
        errors.append("Peer membership comes from peer_map.py. No benchmark screen was sent.")
    profile_requests = [(fund, _profile_request(bq, isin)) for fund, isin in seeds]
    _note(progress, f"Reading benchmark for {len(profile_requests)} funds…")
    fund_profile: dict[str, str] = {}
    fund_strategy: dict[str, str] = {}
    for batch in _chunks(profile_requests, SHARE_CLASS_BATCH):
        for fund, response in _execute_many(bq, batch):
            if not _is_response(response):
                errors.append(f"{fund}: benchmark profile failed.")
                continue
            profile = _combine_items(response)
            fund_profile[fund] = benchmark_index_id(_text_cell(profile, "Benchmark Ticker"))
            fund_strategy[fund] = _text_cell(profile, "Strategy")

    for frame in frames:
        if frame["List"].iloc[0] == "Book":
            fund = str(frame["Fund Name"].iloc[0])
            frame["Benchmark"] = ""
            frame["Benchmark Index"] = fund_profile.get(fund, "")
            frame["Strategy"] = fund_strategy.get(fund, "")

    typed: dict[str, set[str]] = {}
    for _, row in book.iterrows():
        fund = str(row.get("Fund Name", "")).strip()
        isin = str(row.get("ISIN", "")).strip().upper()
        if fund and isin:
            typed.setdefault(fund, set()).add(isin)
    for fund, wanted in typed.items():
        found = returned.get(fund, set())
        missing = sorted(wanted - found)
        if missing:
            errors.append(f"{fund}: typed ISIN not in the linked set: {', '.join(missing)}.")

    if frames:
        table = pd.concat(frames, ignore_index=True, sort=False)
    else:
        table = empty_share_classes()
    for column in SHARE_CLASS_COLUMNS:
        if column not in table.columns:
            table[column] = pd.NA
    table = table.loc[:, list(SHARE_CLASS_COLUMNS)]
    table["Expense Ratio"] = table["Expense Ratio"].map(expense_ratio_number)
    table = _mark_primary_classes(bq, table, company_ids, errors, progress)
    table = keep_primary_listing(table, book)
    table, projection_notes = project_onto_typed_book(table, book, fund_profile)
    errors.extend(projection_notes)
    table = _apply_benchmark_names(bq, table, errors, progress)
    table = _apply_book_snapshots(bq, table, book, errors, progress)
    if "Share Class AUM Currency" not in table.columns:
        table["Share Class AUM Currency"] = pd.NA
    if "Share Class AUM" not in table.columns:
        table["Share Class AUM"] = pd.NA
    rates = _spot_rates_to_usd(bq, table["Share Class AUM Currency"].tolist(), errors, progress)
    table["Share Class AUM (USD mn)"] = [
        fx_to_usd_millions(amount, currency, rates)
        for amount, currency in zip(table["Share Class AUM"], table["Share Class AUM Currency"])
    ]
    for column in ("Bid", "Ask", "Mid", "Last"):
        if column in table.columns:
            table[column] = market_numbers(table[column], allow_zero=False)
    table["Mid"] = resolved_mid(table["Bid"], table["Ask"], table["Mid"] if "Mid" in table.columns else None)
    table["Absolute Spread"] = absolute_quote_spread(table["Bid"], table["Ask"])
    table["Percent Spread"] = percent_quote_spread(table["Absolute Spread"], table["Mid"])
    table = _attach_table_order(table, book)
    table = _apply_typed_strategy(table, book)
    return SourceResult(table, errors)


def _identifier_list(values) -> list[str]:
    return [str(item).strip() for item in (values or []) if str(item).strip()]


def history_request_bounds(period: str, as_of):
    """Weekday window for a shorter Refresh. ``5Y`` stays the frozen relative range.

    ``(None, None)`` means ``range("-5y", "0d")``. Any other choice uses the
    same weekday window as the period buttons, as absolute dates.
    """
    key = str(period or "5Y").strip()
    if key == "5Y" or key not in HISTORY_RANGES:
        return None, None
    start, end, notes = london_period_bounds(key, as_of)
    if notes or start is None or end is None:
        return None, None
    return start, end


def _history_date_range(bq, start, end):
    if start is None or end is None:
        return bq.func.range("-5y", "0d")
    return bq.func.range(
        pd.Timestamp(start).date().isoformat(),
        pd.Timestamp(end).date().isoformat(),
    )


def _quote_history_request(bq, tickers, start=None, end=None):
    """Bid, ask, and mid for the Refresh window. No fill and no currency argument.

    The default window is the frozen five-year relative range.
    """
    date_range = _history_date_range(bq, start, end)
    return bql.Request(
        tickers,
        {
            "Bid": bq.data.px_bid(dates=date_range),
            "Ask": bq.data.px_ask(dates=date_range),
            "Mid": bq.data.px_mid(dates=date_range),
        },
        with_params={"mode": "cached"},
    )


def _nav_history_request(bq, tickers, start=None, end=None):
    """NAV level in USD for the Refresh window. The percent is computed in pandas.

    Catalog spelling is ``fund_net_asset_val()`` (Net Asset Value). The sample
    notebook passes ``currency='USD'``. ``dates`` and ``fill='prev'`` match
    the total-return history request.
    """
    date_range = _history_date_range(bq, start, end)
    return bql.Request(
        tickers,
        {
            "Level": bq.data.fund_net_asset_val(
                dates=date_range,
                currency="USD",
                fill="prev",
            ),
        },
        with_params={"mode": "cached"},
    )


def _return_history_request(bq, tickers, start=None, end=None):
    """Gross total-return index in USD for the Refresh window. This is not the quote request.

    The default window is the frozen five-year relative range.
    """
    date_range = _history_date_range(bq, start, end)
    return bql.Request(
        tickers,
        {
            "Level": bq.data.tot_return_index_gross_dvds(
                dates=date_range,
                currency="USD",
                fill="prev",
            ),
        },
        with_params={"mode": "cached"},
    )


def _flow_history_request(bq, tickers, start_ts, end_ts):
    """Daily fund flow in USD. The window sum stays in pandas."""
    date_range = bq.func.range(start_ts.date().isoformat(), end_ts.date().isoformat())
    return bql.Request(
        tickers,
        {"Flow": bq.data.fund_flow(dates=date_range, currency="USD")},
        with_params={"mode": "cached"},
    )


def _finish_quote_frames(frames: list[pd.DataFrame]) -> pd.DataFrame:
    history = pd.concat(frames, ignore_index=True, sort=False)
    if "ID" not in history.columns and "index" in history.columns:
        history = history.rename(columns={"index": "ID"})
    for column in ("ID", "DATE", "Bid", "Ask", "Mid"):
        if column not in history.columns:
            history[column] = pd.NA
    history["DATE"] = pd.to_datetime(history["DATE"], errors="coerce")
    history = history.dropna(subset=["DATE"])
    history["Bid"] = market_numbers(history["Bid"], allow_zero=False)
    history["Ask"] = market_numbers(history["Ask"], allow_zero=False)
    history["Mid"] = market_numbers(history["Mid"], allow_zero=False)
    history["Mid"] = resolved_mid(history["Bid"], history["Ask"], history["Mid"])
    history["Spread"] = absolute_quote_spread(history["Bid"], history["Ask"])
    history["Percent Spread"] = percent_quote_spread(history["Spread"], history["Mid"])
    return history.loc[:, ["ID", "DATE", "Bid", "Ask", "Mid", "Spread", "Percent Spread"]]


def _finish_return_frames(frames: list[pd.DataFrame]) -> pd.DataFrame:
    history = pd.concat(frames, ignore_index=True, sort=False)
    if "ID" not in history.columns and "index" in history.columns:
        history = history.rename(columns={"index": "ID"})
    if "Level" not in history.columns:
        history["Level"] = pd.NA
    history["DATE"] = pd.to_datetime(history["DATE"], errors="coerce")
    history = history.dropna(subset=["DATE"])
    history["Level"] = market_numbers(history["Level"], allow_zero=False)
    return history.loc[:, ["ID", "DATE", "Level"]]


def _finish_flow_frames(frames: list[pd.DataFrame]) -> pd.DataFrame:
    history = pd.concat(frames, ignore_index=True, sort=False)
    if "ID" not in history.columns and "index" in history.columns:
        history = history.rename(columns={"index": "ID"})
    for column in ("ID", "DATE", "Flow"):
        if column not in history.columns:
            history[column] = pd.NA
    history["DATE"] = pd.to_datetime(history["DATE"], errors="coerce")
    history = history.dropna(subset=["DATE"])
    history["Flow"] = market_numbers(history["Flow"], allow_zero=True) / 1_000_000
    history = history.sort_values("DATE", kind="mergesort")
    return history.loc[:, ["ID", "DATE", "Flow"]]


def _labeled_history(bq, identifiers, prefix, build):
    labeled = []
    for number, batch in enumerate(_chunks(identifiers, SHARE_CLASS_BATCH), start=1):
        labeled.append((f"{prefix}_{number}", build(batch)))
    return labeled


def fetch_quote_history(identifiers: list[str] | None = None, progress=None) -> SourceResult:
    """Five-year bid, ask, and mid history for the latest share-class ids."""
    identifiers = _identifier_list(identifiers)
    empty = pd.DataFrame(columns=["ID", "DATE", "Bid", "Ask", "Mid"])
    if not identifiers:
        return SourceResult(empty, ["No share-class id is available for history."])
    if bql is None:
        return SourceResult(
            empty,
            ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."],
        )
    bq = bql.Service()
    errors: list[str] = []
    frames = []
    labeled = _labeled_history(bq, identifiers, "history", lambda batch: _quote_history_request(bq, batch))
    _note(progress, f"Loading five-year quotes for {len(identifiers)} share classes…")
    for label, response in _execute_waves(bq, labeled):
        if not _is_response(response):
            errors.append(f"{label}: quote history failed.")
            continue
        frame = _combine_items(response)
        if frame.empty:
            errors.append(f"{label}: quote history returned no rows.")
            continue
        frames.append(frame)
    if not frames:
        return SourceResult(empty, errors)
    return SourceResult(_finish_quote_frames(frames), errors)


def fetch_return_history(identifiers: list[str] | None = None, progress=None) -> SourceResult:
    """Five-year gross total-return index in USD, dividends reinvested.

    ``fill='prev'`` keeps the last level on or before a non-trading day.
    The percent is not computed here.
    """
    identifiers = _identifier_list(identifiers)
    empty = pd.DataFrame(columns=["ID", "DATE", "Level"])
    if not identifiers:
        return SourceResult(empty, ["No ticker is available for total return."])
    if bql is None:
        return SourceResult(
            empty,
            ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."],
        )
    bq = bql.Service()
    errors: list[str] = []
    frames = []
    labeled = _labeled_history(bq, identifiers, "return", lambda batch: _return_history_request(bq, batch))
    _note(progress, f"Loading five-year total return for {len(identifiers)} tickers…")
    for label, response in _execute_waves(bq, labeled):
        if not _is_response(response):
            errors.append(f"{label}: total-return history failed.")
            continue
        frame = _combine_items(response)
        if frame.empty:
            errors.append(f"{label}: total-return history returned no rows.")
            continue
        frames.append(frame)
    if not frames:
        return SourceResult(empty, errors)
    return SourceResult(_finish_return_frames(frames), errors)


def fetch_fund_flows(identifiers: list[str] | None, start, end, progress=None) -> SourceResult:
    """Daily net fund flow for the typed tickers, in USD millions.

    The sample notebook sums ``fund_flow(dates=range(...), currency='USD')``
    when it wants one window. This pull leaves the sum off so each day
    remains, and the heatmap buckets those days. A response with no DATE
    is discarded. ``fund_flow_sum`` is not requested.
    """
    identifiers = _identifier_list(identifiers)
    empty = pd.DataFrame(columns=["ID", "DATE", "Flow"])
    if not identifiers:
        return SourceResult(empty, ["No ticker is available for fund flow."])
    try:
        start_ts = pd.Timestamp(start).normalize()
        end_ts = pd.Timestamp(end).normalize()
    except (TypeError, ValueError):
        return SourceResult(empty, ["Fund flow needs a start and an end."])
    if pd.isna(start_ts) or pd.isna(end_ts) or start_ts > end_ts:
        return SourceResult(empty, ["Fund flow needs a start on or before the end."])
    if bql is None:
        return SourceResult(
            empty,
            ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."],
        )
    bq = bql.Service()
    errors: list[str] = []
    frames = []
    labeled = _labeled_history(
        bq,
        identifiers,
        "flow",
        lambda batch: _flow_history_request(bq, batch, start_ts, end_ts),
    )
    _note(progress, f"Loading fund flow for {len(identifiers)} tickers…")
    for label, response in _execute_waves(bq, labeled):
        if not _is_response(response):
            errors.append(f"{label}: fund flow failed.")
            continue
        frame = _combine_items(response)
        if frame.empty or "DATE" not in frame.columns or "Flow" not in frame.columns:
            errors.append(f"{label}: fund flow response had no DATE or Flow column.")
            continue
        frames.append(frame)
    if not frames:
        return SourceResult(empty, errors)
    return SourceResult(_finish_flow_frames(frames), errors)


def _flow_window(start, end):
    """Return ``(start, end)`` or an error string. A blank window is not requested."""
    try:
        start_ts = pd.Timestamp(start).normalize()
        end_ts = pd.Timestamp(end).normalize()
    except (TypeError, ValueError):
        return None, "Fund flow needs a start and an end."
    if pd.isna(start_ts) or pd.isna(end_ts) or start_ts > end_ts:
        return None, "Fund flow needs a start on or before the end."
    return (start_ts, end_ts), ""


# Bound at import. The token describes the source this build *ships*, so a
# helper patched at runtime (a test stub, a notebook override) cannot change
# what the stored rows are checked against.
_HISTORY_REQUEST_SOURCES = (
    _quote_history_request,
    _return_history_request,
    _nav_history_request,
    _flow_history_request,
    _history_date_range,
    _combine_items,
)


def share_class_identities(*frames) -> dict[str, str]:
    """Identifier -> ISIN for every row that carries both.

    The history legs receive a ticker, and a ticker is not a security: a fund
    re-pointed to another share class, a peer whose primary listing moved, or
    a reused ticker all keep the string and change what it means. The ISIN is
    the identity the cache is allowed to compare, and it is already on the
    frames the book and peer pulls return, so this costs no request.
    """
    found: dict[str, str] = {}
    for frame in frames:
        if frame is None or getattr(frame, "empty", True):
            continue
        if "Ticker" not in frame.columns:
            continue
        isin_column = next(
            (name for name in ("ISIN", "Primary ISIN", "Peer ISIN") if name in frame.columns),
            "",
        )
        if not isin_column:
            continue
        for ticker, isin in zip(frame["Ticker"].tolist(), frame[isin_column].tolist()):
            key = clean_market_text(ticker)
            value = _upper_isin(isin)
            if key and value:
                found.setdefault(key, value)
    return found


def history_request_token() -> str:
    """Token for *what* the four history builders ask for.

    The cache stores this with each file, so editing an item, a parameter, a
    currency, or a date argument discards stored rows instead of serving them
    under code that now means something else. Column names alone cannot catch
    that: ``Bid`` stays ``Bid`` when the item behind it changes.
    """
    return cache.fingerprint(_HISTORY_REQUEST_SOURCES)


def fetch_parallel_histories(
    quote_ids,
    return_ids,
    flow_ids,
    flow_start,
    flow_end,
    progress=None,
    history_start=None,
    history_end=None,
    nav_ids=None,
    as_of=None,
    use_cache=True,
    cache_root=None,
    identities=None,
) -> tuple[SourceResult, SourceResult, SourceResult, SourceResult]:
    """One wave for quotes, total return, fund flow, and NAV.

    Each item set stays on its own request. NAV uses ``nav_ids`` when that
    list is passed, otherwise the total-return identifiers. Benchmark
    indexes have no NAV, so the app passes the fund and peer tickers only.
    ``flow_ids is None`` skips the flow leg.

    With ``use_cache`` on, a stored daily row older than ``as_of`` is served
    from the local cache and only the missing days are requested. The merge
    happens before the derived columns are built, so Spread and Percent
    Spread are computed once on the merged raw rows.

    ``identities`` maps each identifier to the security it resolved to this
    run (``share_class_identities()`` passes the ISIN). A stored series whose
    identifier now resolves to a different security is discarded and that
    identifier is requested in full, so a changed primary share class or a
    re-pointed peer ticker cannot be answered from the previous instrument's
    history.
    """
    quote_ids = _identifier_list(quote_ids)
    return_ids = _identifier_list(return_ids)
    nav_ids = _identifier_list(return_ids if nav_ids is None else nav_ids)
    quote_empty = pd.DataFrame(columns=["ID", "DATE", "Bid", "Ask", "Mid"])
    return_empty = pd.DataFrame(columns=["ID", "DATE", "Level"])
    nav_empty = pd.DataFrame(columns=["ID", "DATE", "Level"])
    flow_empty = pd.DataFrame(columns=["ID", "DATE", "Flow"])
    quote_errors = [] if quote_ids else ["No share-class id is available for history."]
    return_errors = [] if return_ids else ["No ticker is available for total return."]
    nav_errors = [] if nav_ids else ["No ticker is available for NAV."]
    flow_errors: list[str] = []
    window = None
    if flow_ids is None:
        flow_ids = []
    else:
        flow_ids = _identifier_list(flow_ids)
        if not flow_ids:
            flow_errors.append("No ticker is available for fund flow.")
        else:
            window, window_error = _flow_window(flow_start, flow_end)
            if window_error:
                flow_errors.append(window_error)
                flow_ids = []
    unavailable = "bql is unavailable. Run this pull on Bloomberg BQuant Desktop."
    if bql is None:
        if quote_ids:
            quote_errors.append(unavailable)
        if return_ids:
            return_errors.append(unavailable)
        if nav_ids:
            nav_errors.append(unavailable)
        if flow_ids:
            flow_errors.append(unavailable)
        return (
            SourceResult(quote_empty, quote_errors),
            SourceResult(return_empty, return_errors),
            SourceResult(flow_empty, flow_errors),
            SourceResult(nav_empty, nav_errors),
        )
    if not quote_ids and not return_ids and not nav_ids and not flow_ids:
        return (
            SourceResult(quote_empty, quote_errors),
            SourceResult(return_empty, return_errors),
            SourceResult(flow_empty, flow_errors),
            SourceResult(nav_empty, nav_errors),
        )
    bq = bql.Service()
    errors_of = {
        "quotes": quote_errors,
        "returns": return_errors,
        "navs": nav_errors,
        "flows": flow_errors,
    }
    failure_of = {
        "quotes": ("quote history failed.", "quote history returned no rows."),
        "returns": ("total-return history failed.", "total-return history returned no rows."),
        "navs": ("NAV history failed.", "NAV history returned no rows."),
        "flows": ("fund flow failed.", "fund flow response had no DATE or Flow column."),
    }
    builders = {
        "quotes": _quote_history_request,
        "returns": _return_history_request,
        "navs": _nav_history_request,
        "flows": _flow_history_request,
    }
    wanted = {
        "quotes": quote_ids,
        "returns": return_ids,
        "navs": nav_ids,
        "flows": flow_ids if window is not None else [],
    }
    # What the four builders ask for. A change to an item, a parameter, or the
    # currency moves this token, so stored rows built from the previous
    # request are ignored even though the column names did not change.
    request_token = history_request_token()
    identities = dict(identities or {})
    stale: dict[str, tuple[str, str]] = {}
    if use_cache:
        try:
            stale = cache.stale_identities(cache_root, identities)
        except Exception:
            stale = {}
        if stale:
            names = ", ".join(sorted(stale)[:5])
            more = "" if len(stale) <= 5 else f" and {len(stale) - 5} more"
            quote_errors.append(
                f"{len(stale)} identifier(s) now resolve to a different security "
                f"({names}{more}). Their stored history was discarded and the whole "
                "window was requested again."
            )
            _note(
                progress,
                f"{len(stale)} identifier(s) now resolve to a different security; "
                "their stored history is discarded and requested again.",
            )
    stored: dict[str, pd.DataFrame] = {kind: pd.DataFrame() for kind in cache.KINDS}
    if use_cache:
        for kind in cache.KINDS:
            try:
                stored[kind] = cache.read_series(
                    kind, cache_root, request_token, identities
                )
            except Exception:
                stored[kind] = pd.DataFrame()
    run_end = pd.Timestamp.today().normalize()
    plans: list[tuple[str, object, object, list[str]]] = []
    for kind in cache.KINDS:
        identifiers = wanted[kind]
        if not identifiers:
            continue
        if kind == "flows":
            window_start, window_end = window if window is not None else (None, None)
            gaps = cache.plan_gaps(kind, identifiers, stored[kind], window_start, window_end)
        else:
            gaps = cache.plan_gaps(
                kind,
                identifiers,
                stored[kind],
                history_start,
                history_end,
                default_end=run_end,
            )
        for gap_start, gap_end, gap_ids in gaps:
            plans.append((kind, gap_start, gap_end, gap_ids))
    labeled = []
    owner: dict[str, tuple[str, list[str]]] = {}
    for kind, start, end, identifiers in plans:
        for number, batch in enumerate(_chunks(identifiers, SHARE_CLASS_BATCH), start=1):
            label = f"{kind}_{number}"
            labeled.append((label, builders[kind](bq, batch, start, end)))
            owner[label] = (kind, list(batch))
    live: dict[str, list[pd.DataFrame]] = {kind: [] for kind in cache.KINDS}
    if labeled:
        _note(progress, "Loading quote history, total return, NAV, and fund flow…")
        for label, response in _execute_waves(bq, labeled):
            kind, _batch = owner.get(label, ("", []))
            if kind not in live:
                continue
            failure, empty = failure_of[kind]
            if not _is_response(response):
                errors_of[kind].append(f"{label}: {failure}")
                continue
            frame = _combine_items(response)
            if frame.empty or (
                kind == "flows" and ("DATE" not in frame.columns or "Flow" not in frame.columns)
            ):
                errors_of[kind].append(f"{label}: {empty}")
                continue
            live[kind].append(frame)
    elif use_cache:
        _note(progress, "History served from the local cache. No request was sent.")

    def _asked(kind: str) -> list[str]:
        seen: list[str] = []
        for job_kind, _start, _end, identifiers in plans:
            if job_kind != kind:
                continue
            for identifier in identifiers:
                if identifier not in seen:
                    seen.append(identifier)
        return seen

    def _shown(kind: str) -> list[str]:
        """Every identifier this run needs, asked or already stored."""
        seen = list(_asked(kind))
        for identifier in wanted[kind]:
            if identifier not in seen:
                seen.append(identifier)
        return seen

    def _window(kind: str):
        """The span the caller asked for. The cache may hold more than this."""
        if kind == "flows":
            return window if window is not None else (None, None)
        if history_start is not None and history_end is not None:
            return history_start, history_end
        end_day = pd.Timestamp(history_end).normalize() if history_end is not None else run_end
        return end_day - pd.DateOffset(years=cache.RELATIVE_YEARS), end_day

    merged: dict[str, pd.DataFrame] = {}
    reused = 0
    for kind in cache.KINDS:
        identifiers = _shown(kind)
        if not identifiers:
            merged[kind] = pd.DataFrame()
            continue
        window_start, window_end = _window(kind)
        rows = cache.trim_to_window(
            cache.subset(stored[kind], identifiers), window_start, window_end
        )
        reused += len(rows)
        merged[kind] = cache.merge(kind, rows, live[kind])
    written = 0
    if use_cache:
        settled_before = (
            pd.Timestamp(as_of).normalize() if as_of is not None else last_completed_london_day()
        )
        for kind in cache.KINDS:
            identifiers = _asked(kind)
            frame = merged[kind]
            if not identifiers or frame is None or frame.empty:
                continue
            fresh = frame.loc[frame["ID"].astype(str).isin(set(identifiers))]
            if fresh.empty:
                continue
            try:
                written += cache.save(
                    kind,
                    fresh,
                    settled_before,
                    cache_root,
                    request_token,
                    identities,
                )
            except Exception as exc:
                errors_of[kind].append(
                    f"{kind}: history cache was not written ({type(exc).__name__}: {exc})."
                )
    if use_cache:
        changed = f"; {len(stale)} identity change(s)" if stale else ""
        _note(
            progress,
            f"History cache: {reused} stored row(s) reused; "
            f"{written} settled row(s) written{changed}.",
        )
    quotes = SourceResult(
        _finish_quote_frames([merged["quotes"]]) if not merged["quotes"].empty else quote_empty,
        quote_errors,
    )
    returns = SourceResult(
        _finish_return_frames([merged["returns"]]) if not merged["returns"].empty else return_empty,
        return_errors,
    )
    navs = SourceResult(
        _finish_return_frames([merged["navs"]]) if not merged["navs"].empty else nav_empty,
        nav_errors,
    )
    flows = SourceResult(
        _finish_flow_frames([merged["flows"]]) if not merged["flows"].empty else flow_empty,
        flow_errors,
    )
    return quotes, returns, flows, navs


_SHOWCASE_EXCHANGES = {"JP", "US", "HK", "KS", "CH", "TT", "AU"}
_SHOWCASE_CURRENCIES = {"JPY", "USD", "HKD", "KRW", "CNY", "TWD", "AUD", "EUR", "GBP"}
_SHOWCASE_MILLIONS = (
    "MktCap_Today",
    "MktCap_1M",
    "MktCap_3M",
    "MktCap_1Y",
    "FundFlow_1M",
    "FundFlow_3M",
    "FundFlow_1Y",
)


def _showcase_code(value, allowed: set[str], label: str) -> tuple[str, str]:
    text = str(value or "").strip().upper()
    if text not in allowed:
        return "", f"Unsupported {label}: {value}."
    return text, ""


def _showcase_universe(bq, exchange: str):
    return (
        bq.univ.fundsuniv(("active", "primary"))
        .filter(bq.data.fund_typ() == "ETF")
        .filter(bq.data.exch_code() == exchange)
    )


def _showcase_request(bq, exchange: str, currency: str):
    """One exchange of primary ETFs. Quotes are not in this request."""
    today = pd.Timestamp.today().normalize()
    d_1m = (today - pd.DateOffset(months=1)).date().isoformat()
    d_3m = (today - pd.DateOffset(months=3)).date().isoformat()
    d_1y = (today - pd.DateOffset(years=1)).date().isoformat()
    items = {
        "Name": bq.data.name()["value"],
        "AssetClass": bq.data.fund_asset_class_focus()["value"],
        "GeoFocus": bq.data.fund_geo_focus()["value"],
        "Strategy": bq.data.fund_strategy()["value"],
        "Sector": bq.data.fund_industry_focus()["value"],
        "Benchmark": bq.data.fund_benchmark()["value"],
        "ActivelyManaged": bq.data.actively_managed()["value"],
        "MktCap_Today": bq.data.cur_mkt_cap(currency=currency, fill="prev"),
        "MktCap_1M": bq.data.cur_mkt_cap(currency=currency, dates=d_1m, fill="prev"),
        "MktCap_3M": bq.data.cur_mkt_cap(currency=currency, dates=d_3m, fill="prev"),
        "MktCap_1Y": bq.data.cur_mkt_cap(currency=currency, dates=d_1y, fill="prev"),
        "FundFlow_1M": bq.data.fund_flow(dates=bq.func.range("-1M", "0D"), currency=currency).sum(),
        "FundFlow_3M": bq.data.fund_flow(dates=bq.func.range("-3M", "0D"), currency=currency).sum(),
        "FundFlow_1Y": bq.data.fund_flow(dates=bq.func.range("-1Y", "0D"), currency=currency).sum(),
    }
    return bql.Request(
        _showcase_universe(bq, exchange),
        items,
        with_params={"mode": "cached", "showids": "f"},
    )


def _as_id_frame(frame: pd.DataFrame) -> pd.DataFrame:
    work = frame.copy()
    if "ID" not in work.columns and "index" in work.columns:
        work = work.rename(columns={"index": "ID"})
    return work


def _to_millions(frame: pd.DataFrame) -> pd.DataFrame:
    work = frame.copy()
    for column in _SHOWCASE_MILLIONS:
        if column not in work.columns:
            work[column] = pd.NA
            continue
        work[column] = pd.to_numeric(work[column], errors="coerce") / 1_000_000
    return work


def fetch_etf_showcase(exchange: str, currency: str, progress=None) -> SourceResult:
    """Primary ETFs on one exchange. This does not read the HSBC book."""
    empty = pd.DataFrame()
    exchange_code, exchange_error = _showcase_code(exchange, _SHOWCASE_EXCHANGES, "exchange")
    currency_code, currency_error = _showcase_code(currency, _SHOWCASE_CURRENCIES, "currency")
    errors = [note for note in (exchange_error, currency_error) if note]
    if errors:
        return SourceResult(empty, errors)
    if bql is None:
        return SourceResult(empty, ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."])
    bq = bql.Service()
    _note(progress, f"Loading primary ETFs on {exchange_code} in {currency_code}…")
    response = _execute_many(bq, [("showcase", _showcase_request(bq, exchange_code, currency_code))])
    if not response:
        return SourceResult(empty, [f"{exchange_code}: ETF taxonomy request failed."])
    _label, result = response[0]
    if not _is_response(result):
        return SourceResult(empty, [f"{exchange_code}: ETF taxonomy request failed."])
    frame = _as_id_frame(_combine_items(result))
    if frame.empty or "ID" not in frame.columns:
        return SourceResult(empty, [f"{exchange_code}: ETF taxonomy returned no rows."])
    frame = _to_millions(frame)
    if "MktCap_Today" in frame.columns:
        frame = frame.sort_values("MktCap_Today", ascending=False, kind="mergesort", na_position="last")
    return SourceResult(frame.reset_index(drop=True), [])


def fetch_showcase_flows(exchange: str, currency: str, start, end, monthly: bool, progress=None) -> SourceResult:
    """Bucketed net flow for the same exchange universe. Not the HSBC book."""
    empty = pd.DataFrame(columns=["ID", "DATE", "Flow"])
    exchange_code, exchange_error = _showcase_code(exchange, _SHOWCASE_EXCHANGES, "exchange")
    currency_code, currency_error = _showcase_code(currency, _SHOWCASE_CURRENCIES, "currency")
    errors = [note for note in (exchange_error, currency_error) if note]
    if errors:
        return SourceResult(empty, errors)
    try:
        start_ts = pd.Timestamp(start).normalize()
        end_ts = pd.Timestamp(end).normalize()
    except (TypeError, ValueError):
        return SourceResult(empty, ["Fund flow needs a start and an end."])
    if pd.isna(start_ts) or pd.isna(end_ts) or start_ts > end_ts:
        return SourceResult(empty, ["Fund flow needs a start on or before the end."])
    if bql is None:
        return SourceResult(empty, ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."])
    bq = bql.Service()
    inner = "-1M" if monthly else "-5D"
    frequency = "M" if monthly else "CW"
    window = bq.data.fund_flow(dates=bq.func.range(inner, "0D"), currency=currency_code).sum()
    series = window.rolling(
        iterationdates=bq.func.range(start_ts.date().isoformat(), end_ts.date().isoformat(), frq=frequency)
    )
    _note(progress, f"Loading {exchange_code} fund-flow buckets…")
    response = _execute_many(
        bq,
        [(
            "showcase_flow",
            bql.Request(
                _showcase_universe(bq, exchange_code),
                {"Flow": series},
                with_params={"mode": "cached", "showids": "f"},
            ),
        )],
    )
    if not response:
        return SourceResult(empty, [f"{exchange_code}: fund-flow heatmap failed."])
    _label, result = response[0]
    if not _is_response(result):
        return SourceResult(empty, [f"{exchange_code}: fund-flow heatmap failed."])
    frame = _as_id_frame(_combine_items(result))
    if frame.empty or "DATE" not in frame.columns or "Flow" not in frame.columns:
        return SourceResult(empty, [f"{exchange_code}: fund-flow response had no DATE or Flow column."])
    frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
    frame = frame.dropna(subset=["DATE"])
    frame["Flow"] = pd.to_numeric(frame["Flow"], errors="coerce") / 1_000_000
    frame = frame.sort_values("DATE", kind="mergesort")
    if "ID" not in frame.columns:
        return SourceResult(empty, [f"{exchange_code}: fund-flow response had no ID."])
    return SourceResult(frame.loc[:, ["ID", "DATE", "Flow"]], [])


def _upper_isin(value) -> str:
    text = "" if value is None or (not isinstance(value, str) and pd.isna(value)) else str(value).strip().upper()
    if text in {"", "NAN", "NONE", "<NA>"}:
        return ""
    return text


def _company_by_isin(frame: pd.DataFrame) -> dict[str, str]:
    """Map each requested ISIN to its umbrella id. The first row is not enough."""
    found: dict[str, str] = {}
    if frame is None or frame.empty or "ID BB Company" not in frame.columns:
        return found
    id_column = "ID" if "ID" in frame.columns else ("index" if "index" in frame.columns else "")
    if not id_column:
        return found
    for _, row in frame.iterrows():
        isin = _upper_isin(row.get(id_column))
        company = company_id_from_frame(pd.DataFrame([row]))
        if isin and company and isin not in found:
            found[isin] = company
    return found


def _primary_isins_of(frame: pd.DataFrame) -> list[str]:
    if frame is None or frame.empty or "ISIN" not in frame.columns:
        return []
    found: list[str] = []
    for value in frame["ISIN"].tolist():
        isin = _upper_isin(value)
        if isin and isin not in found:
            found.append(isin)
    return found


def _listing_request(bq, isins: list[str]):
    """One request for primary ISINs. Publication lines are removed afterwards."""
    return bql.Request(
        isins,
        {
            "Ticker": bq.data.id()["value"],
            "Name": bq.data.name()["value"],
            "Long Name": bq.data.long_comp_name()["value"],
            "Share Class": bq.data.fund_open_shr_class()["value"],
            "ISIN": bq.data.id_isin()["value"],
            "Currency": bq.data.crncy(),
        },
        with_params={"mode": "cached", "showids": "f"},
    )


def _prepare_listing_frame(response) -> pd.DataFrame:
    frame = _combine_keeping_currency(response)
    if frame.empty:
        return frame
    if "Ticker" not in frame.columns and "ID" in frame.columns:
        frame = frame.copy()
        frame["Ticker"] = frame["ID"]
    elif "Ticker" in frame.columns and "ID" in frame.columns:
        frame = frame.copy()
        ticker = frame["Ticker"].map(
            lambda value: "" if value is None or (not isinstance(value, str) and pd.isna(value)) else str(value).strip()
        )
        missing = ticker.eq("") | ticker.str.lower().isin({"nan", "none", "<na>"})
        frame.loc[missing, "Ticker"] = frame.loc[missing, "ID"]
    collapsed = collapse_publication_lines(frame)
    return collapsed


LINK_COLUMNS = (
    "Fund Name",
    "Peer ISIN",
    "Primary ISIN",
    "Ticker",
    "Name",
    "Long Name",
    "Share Class",
    "Currency",
)


def _book_peer_pairs(pairs: list[tuple[str, str]]) -> tuple[list[tuple[str, str]], list[str]]:
    """Keep peer rows whose fund name is on the typed book.

    A name that is not on ``ISIN_BOOK`` is named in a note and is not requested.
    """
    book = isin_book_frame()
    known: set[str] = set()
    if book is not None and not book.empty and "Fund Name" in book.columns:
        known = {fund_name_key(value) for value in book["Fund Name"].tolist()}
        known.discard("")
    kept: list[tuple[str, str]] = []
    notes: list[str] = []
    seen: set[str] = set()
    for fund, peer in pairs:
        key = fund_name_key(fund)
        if key not in known:
            note = f"{fund}: peer map name is not in ISIN_BOOK."
            if note not in seen:
                notes.append(note)
                seen.add(note)
            continue
        kept.append((fund, peer))
    return kept, notes


PEER_FACT_COLUMNS = (
    "Ticker",
    "Last",
    "Fund AUM (USD mn)",
    "Share Class AUM (USD mn)",
    "Tracking Error",
    "NAV Tracking Error",
    "Strategy",
    "Benchmark",
    "Benchmark Index",
)


def _peer_identity_rows(links: pd.DataFrame | None) -> pd.DataFrame:
    """One row per peer ticker. The ISIN is the primary listing when present."""
    columns = ["Ticker", "ISIN"]
    if links is None or links.empty or "Ticker" not in links.columns:
        return pd.DataFrame(columns=columns)
    rows = []
    seen = set()
    for _, link in links.iterrows():
        ticker = clean_market_text(link.get("Ticker"))
        key = ticker.upper()
        if not key or key in seen:
            continue
        seen.add(key)
        isin = clean_market_text(link.get("Primary ISIN")) or clean_market_text(link.get("ISIN"))
        rows.append({"Ticker": ticker, "ISIN": isin})
    return pd.DataFrame(rows, columns=columns)


def _peer_profile_request(bq, isins: list[str]):
    """Same two profile fields as the HSBC seed. No cached mode and no showids."""
    return bql.Request(
        list(isins),
        {
            "Benchmark Ticker": bq.data.fund_benchmark_prim()["value"],
            "Strategy": bq.data.fund_strategy()["value"],
        },
    )


def fetch_peer_facts(links: pd.DataFrame | None = None, progress=None) -> SourceResult:
    """Point-in-time fields for peer rows. History stays a separate pull.

    Quotes, class assets, fund assets, and both tracking errors use the
    same request families as the HSBC book. Strategy and the benchmark id
    use the same two profile fields, on the peer primary ISIN. A failed
    family leaves that column blank.
    """
    empty = pd.DataFrame(columns=list(PEER_FACT_COLUMNS))
    identities = _peer_identity_rows(links)
    if identities.empty:
        return SourceResult(empty, [])
    if bql is None:
        return SourceResult(
            empty,
            ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."],
        )
    bq = bql.Service()
    errors: list[str] = []
    table = identities.copy()
    table["Fund Name"] = table["Ticker"]
    table["Primary"] = "Yes"
    snapshot_errors: list[str] = []
    table = _apply_book_snapshots(bq, table, table, snapshot_errors, progress)
    errors.extend(f"Peer facts: {note}" for note in snapshot_errors)
    if "Share Class AUM Currency" not in table.columns:
        table["Share Class AUM Currency"] = pd.NA
    if "Share Class AUM" not in table.columns:
        table["Share Class AUM"] = pd.NA
    rates = _spot_rates_to_usd(bq, table["Share Class AUM Currency"].tolist(), errors, progress)
    table["Share Class AUM (USD mn)"] = [
        fx_to_usd_millions(amount, currency, rates)
        for amount, currency in zip(table["Share Class AUM"], table["Share Class AUM Currency"])
    ]
    if "Last" in table.columns:
        table["Last"] = market_numbers(table["Last"], allow_zero=False)
    isins = []
    seen_isins = set()
    isin_values = table["ISIN"].tolist() if "ISIN" in table.columns else []
    for value in isin_values:
        isin = _upper_isin(value)
        if isin and isin not in seen_isins:
            seen_isins.add(isin)
            isins.append(isin)
    strategy_by_isin: dict[str, str] = {}
    index_by_isin: dict[str, str] = {}
    if isins:
        labeled = []
        for number, batch in enumerate(_chunks(isins, SHARE_CLASS_BATCH), start=1):
            labeled.append((f"peer_profile_{number}", _peer_profile_request(bq, batch)))
        _note(progress, f"Reading benchmark for {len(isins)} peer ISINs…")
        for label, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{label}: benchmark profile failed.")
                continue
            try:
                profile = _combine_items(response)
            except ValueError as exc:
                errors.append(f"{label}: benchmark profile failed: {exc}")
                continue
            if profile.empty or "ID" not in profile.columns:
                errors.append(f"{label}: benchmark profile returned no rows.")
                continue
            for _, row in profile.iterrows():
                isin = _upper_isin(row.get("ID"))
                if not isin:
                    continue
                strategy_by_isin[isin] = clean_market_text(row.get("Strategy"))
                index_by_isin[isin] = benchmark_index_id(row.get("Benchmark Ticker"))
    if "ISIN" in table.columns:
        keys = table["ISIN"].map(_upper_isin)
        table["Strategy"] = keys.map(lambda isin: strategy_by_isin.get(isin, ""))
        table["Benchmark Index"] = keys.map(lambda isin: index_by_isin.get(isin, ""))
    else:
        table["Strategy"] = ""
        table["Benchmark Index"] = ""
    table = _apply_benchmark_names(bq, table, errors, progress)
    for column in PEER_FACT_COLUMNS:
        if column not in table.columns:
            table[column] = pd.NA
    return SourceResult(table.loc[:, list(PEER_FACT_COLUMNS)].reset_index(drop=True), errors)


def fetch_peer_links(progress=None, fund_names=None) -> SourceResult:
    """Resolve every peer ISIN in ``peer_map.py`` to one primary listing.

    ``fund_names`` limits the pull to those HSBC fund names. ``None`` keeps
    every name on the book.

    A fund with no umbrella id, no primary share class, or more than one
    primary share class is skipped. Publication-currency lines that do not
    match the share-class currency are dropped. One ticker is kept per
    primary ISIN.
    """
    empty = pd.DataFrame(columns=list(LINK_COLUMNS))
    raw_pairs = map_rows()
    if fund_names is not None:
        allowed = {fund_name_key(name) for name in fund_names}
        allowed.discard("")
        matched = [pair for pair in raw_pairs if fund_name_key(pair[0]) in allowed]
        if raw_pairs and not matched:
            return SourceResult(empty, ["No peer map row matches this Strategy."])
        raw_pairs = matched
    if not raw_pairs:
        return SourceResult(empty, ["peer_map.py has no ISINs."])
    pairs, errors = _book_peer_pairs(raw_pairs)
    if not pairs:
        return SourceResult(empty, errors or ["No peer map name matches ISIN_BOOK."])
    if bql is None:
        return SourceResult(empty, errors + ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."])
    bq = bql.Service()
    peer_isins = list(dict.fromkeys(peer for _fund, peer in pairs))
    company_of: dict[str, str] = {}
    labeled = []
    for batch in _chunks(peer_isins, SHARE_CLASS_BATCH):
        labeled.append((tuple(batch), bql.Request(
            batch,
            {"ID BB Company": bq.data.id_bb_company()["value"]},
            with_params={"mode": "cached"},
        )))
    _note(progress, f"Reading umbrella ids for {len(peer_isins)} peer ISINs…")
    for label, response in _execute_waves(bq, labeled):
            requested = [_upper_isin(isin) for isin in label]
            if not _is_response(response):
                errors.append(f"{', '.join(requested)}: umbrella id request failed.")
                continue
            frame = _combine_items(response)
            found = _company_by_isin(frame)
            if not found:
                errors.append(f"{', '.join(requested)}: umbrella id request returned no rows.")
                continue
            for isin, company in found.items():
                if isin in requested:
                    company_of[isin] = company
    companies = list(dict.fromkeys(company_of.values()))
    primaries_of: dict[str, list[str]] = {}
    labeled = [
        (company, _primary_class_request(bq, company))
        for company in companies
    ]
    _note(progress, f"Reading primary share classes for {len(companies)} peer funds…")
    for company, response in _execute_waves(bq, labeled):
            if not _is_response(response):
                errors.append(f"{company}: primary share-class request failed.")
                continue
            primaries_of[str(company)] = _primary_isins_of(_combine_items(response))
    by_fund: dict[str, list[str]] = {}
    for fund, peer in pairs:
        by_fund.setdefault(fund, []).append(peer)
    chosen_by_fund: dict[str, list[str]] = {}
    ordered_primaries: list[str] = []
    for fund, peers in by_fund.items():
        chosen, notes = choose_primary_isins(peers, company_of, primaries_of)
        errors.extend(notes)
        chosen_by_fund[fund] = chosen
        for primary in chosen:
            if primary not in ordered_primaries:
                ordered_primaries.append(primary)
    listings = pd.DataFrame()
    if ordered_primaries:
        frames = []
        labeled = []
        for number, batch in enumerate(_chunks(ordered_primaries, SHARE_CLASS_BATCH), start=1):
            labeled.append((f"listing_{number}", _listing_request(bq, batch)))
        _note(progress, f"Resolving {len(ordered_primaries)} primary listings…")
        for label, response in _execute_waves(bq, labeled):
                if not _is_response(response):
                    errors.append(f"{label}: primary listing request failed.")
                    continue
                try:
                    frame = _prepare_listing_frame(response)
                except ValueError as exc:
                    errors.append(f"{label}: {exc}")
                    continue
                if frame.empty:
                    errors.append(f"{label}: no listing matched the share-class currency.")
                    continue
                kept, notes = keep_one_listing(frame)
                errors.extend(notes)
                if not kept.empty:
                    frames.append(kept)
        if frames:
            listings = pd.concat(frames, ignore_index=True, sort=False)
    by_primary: dict[str, dict] = {}
    if not listings.empty and "ISIN" in listings.columns:
        for _, row in listings.iterrows():
            primary = _upper_isin(row.get("ISIN"))
            if primary and primary not in by_primary:
                by_primary[primary] = row.to_dict()
    rows = []
    for fund, primaries in chosen_by_fund.items():
        for primary in primaries:
            listing = by_primary.get(primary)
            if listing is None:
                errors.append(
                    f"{primary}: no single listing remained after publication-currency lines were removed."
                )
                continue
            rows.append(
                {
                    "Fund Name": fund,
                    "Peer ISIN": primary,
                    "Primary ISIN": primary,
                    "Ticker": listing.get("Ticker", ""),
                    "Name": listing.get("Name", ""),
                    "Long Name": listing.get("Long Name", ""),
                    "Share Class": listing.get("Share Class", ""),
                    "Currency": listing.get("Currency", ""),
                }
            )
    if not rows:
        return SourceResult(empty, errors or ["No peer primary listing was resolved."])
    return SourceResult(pd.DataFrame(rows, columns=list(LINK_COLUMNS)), errors)


def fetch_peer_spreads(
    fund_name: str,
    anchor_ticker: str,
    links: pd.DataFrame | None = None,
    progress=None,
    anchor_isin: str = "",
) -> SourceResult:
    """Quotes for one HSBC primary ticker and the peers of its fund name.

    Membership comes from ``links`` when that frame is supplied, otherwise
    from ``peer_map.py``. A benchmark screen is not sent. ``anchor_isin``
    is only the ISIN shown on the selected row.
    """
    columns = [
        "Role",
        "Name",
        "Share Class",
        "ISIN",
        "Ticker",
        "Currency",
        "Fund AUM (USD mn)",
        "Expense Ratio",
        "NAV Tracking Error",
        "Tracking Error",
        "Bid",
        "Ask",
        "Mid",
        "Last",
    ]
    empty = pd.DataFrame(columns=columns)
    fund = fund_name_key(fund_name)
    selected_isin = _upper_isin(anchor_isin)
    seed = str(anchor_ticker or "").strip()
    if not seed or seed.lower() in {"nan", "none", "<na>"}:
        return SourceResult(empty, ["Choose a fund whose primary share class is known."])
    if not fund:
        return SourceResult(empty, ["Choose a fund whose name is known."])
    errors: list[str] = []
    table_links = links
    if table_links is None:
        resolved = fetch_peer_links(progress=progress)
        errors.extend(resolved.errors)
        table_links = resolved.observations
    if table_links is None or table_links.empty or "Fund Name" not in table_links.columns:
        return SourceResult(empty, errors or [f"{fund} has no rows in peer_map.py."])
    matched = table_links.loc[
        table_links["Fund Name"].map(fund_name_key).eq(fund)
    ].copy()
    if matched.empty:
        return SourceResult(empty, errors or [f"{fund} has no rows in peer_map.py."])
    if bql is None:
        return SourceResult(empty, ["bql is unavailable. Run this pull on Bloomberg BQuant Desktop."])
    bq = bql.Service()
    peer_rows = []
    seen_tickers = {seed.upper()}
    for _, row in matched.iterrows():
        ticker = str(row.get("Ticker", "")).strip()
        if not ticker or ticker.lower() in {"nan", "none", "<na>"}:
            continue
        if ticker.upper() in seen_tickers:
            continue
        seen_tickers.add(ticker.upper())
        peer_rows.append(
            {
                "Name": row.get("Name", pd.NA),
                "Share Class": row.get("Share Class", pd.NA),
                "ISIN": row.get("Primary ISIN", row.get("ISIN", pd.NA)),
                "Ticker": ticker,
                "Currency": row.get("Currency", pd.NA),
            }
        )
    if not peer_rows:
        return SourceResult(empty, errors or [f"{fund} has no resolved peer ticker."])
    table = pd.concat(
        [
            pd.DataFrame([{"Ticker": seed, "ISIN": selected_isin, "Role": "Selected"}]),
            pd.DataFrame(peer_rows),
        ],
        ignore_index=True,
        sort=False,
    )
    for column in ("Name", "Share Class", "ISIN", "Ticker", "Currency", "Expense Ratio"):
        if column not in table.columns:
            table[column] = pd.NA
    table["_ticker"] = table["Ticker"].fillna("").astype(str).str.strip().str.upper()
    tickers = _typed_ticker_list(table)
    if not tickers:
        return SourceResult(empty, errors or ["No primary ticker is available."])
    market_frames = []
    aum_frames = []
    labeled_market = []
    labeled_aum = []
    for number, batch in enumerate(_chunks(tickers, SHARE_CLASS_BATCH), start=1):
        labeled_market.append((f"peer_px_{number}", _ticker_market_request(bq, batch)))
        labeled_aum.append((f"peer_aum_{number}", _ticker_fund_aum_request(bq, batch)))
    _note(progress, f"Quoting {len(tickers)} primary tickers…")
    for label, quote in _execute_waves(bq, labeled_market):
            if not _is_response(quote):
                errors.append(f"{label}: peer quote failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(quote))
            if not frame.empty:
                market_frames.append(frame)
    for label, assets in _execute_waves(bq, labeled_aum):
            if not _is_response(assets):
                errors.append(f"{label}: peer fund assets failed.")
                continue
            frame = _quotes_by_ticker(_combine_items(assets))
            if not frame.empty and "FundAUM" in frame.columns:
                aum_frames.append(frame)
    if market_frames:
        market = pd.concat(market_frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        for column in ("Currency", "Last", "Bid", "Ask", "Mid"):
            _overlay_column(table, market, column)
    if aum_frames:
        assets = pd.concat(aum_frames, ignore_index=True, sort=False).drop_duplicates("_ticker", keep="first")
        _overlay_column(table, assets, "FundAUM")
        if "FundAUM" in table.columns:
            table["Fund AUM (USD mn)"] = fund_total_usd_millions(table["FundAUM"])
    else:
        table["Fund AUM (USD mn)"] = pd.NA
    for column in ("Currency", "Last", "Bid", "Ask", "Mid", "Fund AUM (USD mn)"):
        if column not in table.columns:
            table[column] = pd.NA
    table["Role"] = "Peer"
    table.loc[table["_ticker"].eq(seed.upper()), "Role"] = "Selected"
    table = _apply_expense_ratio(bq, table, tickers, errors, progress)
    table = _apply_tracking_error(bq, table, tickers, errors, progress)
    table = _apply_nav_tracking_error(bq, table, tickers, errors, progress)
    for column in ("Bid", "Ask", "Mid", "Last"):
        if column in table.columns:
            table[column] = market_numbers(table[column], allow_zero=False)
    table["Mid"] = resolved_mid(table["Bid"], table["Ask"], table["Mid"] if "Mid" in table.columns else None)
    table["Absolute Spread"] = absolute_quote_spread(table["Bid"], table["Ask"])
    table["Percent Spread"] = percent_quote_spread(table["Absolute Spread"], table["Mid"])
    keep = [column for column in columns if column in table.columns]
    return SourceResult(table.loc[:, keep].reset_index(drop=True), errors)
