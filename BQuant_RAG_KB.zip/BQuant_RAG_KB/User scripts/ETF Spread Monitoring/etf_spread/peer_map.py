"""Manual peer list. BQuant Desktop cannot take an uploaded file.

Write the list in this module. One line is one peer of one HSBC fund.
A group of about a thousand lines is expected. Leave the tuple empty until
the rows are pasted. Do not put this list in ``config.py``: that file holds
the live book and must not be replaced by an empty copy.

``fund_name`` is the HSBC fund, not a share class. Use the same text as
``IsinEntry.fund_name``, including spaces and capitals. Write the peer list
once for that fund. Every share class of the fund, primary and otherwise,
uses this same list. Do not repeat the peers on each class ISIN.

``peer_isin`` is any share class of the peer fund. Refresh resolves it to
that fund's single primary share class. Two peer ISINs that resolve to the
same primary ISIN are kept once. A fund with more than one primary share
class is skipped. Quotes are then requested on that one listing, after
publication-currency lines have been removed.

Example, inside the parentheses:

    PeerMapEntry("HSBC MSCI India", "IE00PEER000001"),
    PeerMapEntry("HSBC MSCI India", "IE00PEER000002"),
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PeerMapEntry:
    """One peer ISIN belonging to one HSBC fund."""

    fund_name: str
    peer_isin: str


PEER_MAP: tuple[PeerMapEntry, ...] = (
    PeerMapEntry("DUMMY HSBC ETF ONE", "IE00PEER000001"),
    PeerMapEntry("DUMMY HSBC ETF ONE", "IE00PEER000002"),
    PeerMapEntry("DUMMY HSBC ETF TWO", "IE00PEER000003"),
)


def _isin(value) -> str:
    text = "" if value is None else str(value).strip().upper()
    if text in {"", "NAN", "NONE", "<NA>"}:
        return ""
    return text


def fund_name_key(value) -> str:
    """The book fund name, stripped. Capitals and internal spaces stay."""
    return _fund_name(value)


def _fund_name(value) -> str:
    text = "" if value is None else str(value).strip()
    if text.lower() in {"", "nan", "none", "<na>"}:
        return ""
    return text


def map_rows() -> list[tuple[str, str]]:
    """Fund name and peer ISIN, in file order, with blanks removed.

    The fund name keeps the characters typed in ``IsinEntry.fund_name``.
    It is not forced to uppercase.
    """
    rows: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for entry in PEER_MAP:
        fund = _fund_name(entry.fund_name)
        peer = _isin(entry.peer_isin)
        if not fund or not peer:
            continue
        key = (fund, peer)
        if key in seen:
            continue
        seen.add(key)
        rows.append(key)
    return rows


def choose_primary_isins(
    peer_isins: list[str],
    company_of: dict[str, str],
    primaries_of: dict[str, list[str]],
) -> tuple[list[str], list[str]]:
    """One primary ISIN per peer fund.

    ``company_of`` maps a supplied ISIN to its umbrella id.
    ``primaries_of`` maps that umbrella id to the primary ISINs returned
    for it. A fund is used only when that list has exactly one ISIN.
    The same primary ISIN is not returned twice.
    """
    chosen: list[str] = []
    seen: set[str] = set()
    notes: list[str] = []
    for raw in peer_isins:
        isin = _isin(raw)
        if not isin:
            continue
        company = str(company_of.get(isin, "")).strip()
        if not company:
            notes.append(
                f"{isin}: umbrella id is blank, so no primary share class was chosen."
            )
            continue
        primaries: list[str] = []
        for value in primaries_of.get(company, []):
            primary = _isin(value)
            if primary and primary not in primaries:
                primaries.append(primary)
        if len(primaries) == 1:
            primary = primaries[0]
        elif not primaries:
            notes.append(f"{isin}: no primary share class was returned.")
            continue
        else:
            notes.append(
                f"{isin}: {len(primaries)} primary share classes were returned, so none was chosen."
            )
            continue
        if primary in seen:
            continue
        seen.add(primary)
        chosen.append(primary)
    return chosen, notes
