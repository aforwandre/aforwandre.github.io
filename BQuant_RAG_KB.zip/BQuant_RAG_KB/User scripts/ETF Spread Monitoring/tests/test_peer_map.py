"""Manual peer map, publication lines, return percent, and peer averages."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread.book_view import previous_london_day  # noqa: E402
from etf_spread.data import collapse_publication_lines, keep_one_listing  # noqa: E402
from etf_spread.engine import period_bounds  # noqa: E402
from etf_spread.flow_view import peer_group_flow_matrix  # noqa: E402
from etf_spread.metrics import (  # noqa: E402
    level_on_or_before,
    member_tickers,
    peer_member_spreads,
    peer_metric_frame,
    return_comparison,
    return_percents,
    spread_comparison,
    visible_book_columns,
)
from etf_spread.peer_map import choose_primary_isins  # noqa: E402


AS_OF = pd.Timestamp("2026-10-23")


class PrimaryChoiceTests(unittest.TestCase):
    def test_one_primary_is_kept_and_duplicates_collapse(self):
        chosen, notes = choose_primary_isins(
            ["ie00peer", "IE00PEER", "IE00OTHER"],
            {"IE00PEER": "100", "IE00OTHER": "100"},
            {"100": ["IE00PRIMARY"]},
        )
        self.assertEqual(chosen, ["IE00PRIMARY"])
        self.assertFalse(notes)

    def test_two_primaries_and_a_blank_company_are_skipped(self):
        chosen, notes = choose_primary_isins(
            ["IE00MANY", "IE00BLANK", "IE00NONE"],
            {"IE00MANY": "200", "IE00NONE": "300"},
            {"200": ["IE00A", "IE00B"], "300": []},
        )
        self.assertEqual(chosen, [])
        self.assertTrue(any("2 primary" in note for note in notes))
        self.assertTrue(any("IE00BLANK" in note for note in notes))
        self.assertTrue(any("IE00NONE" in note for note in notes))


class PublicationLineTests(unittest.TestCase):
    def test_matching_currency_is_kept(self):
        frame = pd.DataFrame(
            {
                "ID": ["1", "1"],
                "CURRENCY": ["USD", "EUR"],
                "Currency": ["USD", "USD"],
                "Ticker": ["AAA LN Equity", "AAA US Equity"],
                "ISIN": ["IE00A", "IE00A"],
            }
        )
        kept = collapse_publication_lines(frame)
        self.assertEqual(kept["Ticker"].tolist(), ["AAA LN Equity"])
        self.assertNotIn("CURRENCY", kept.columns)

    def test_disagreement_drops_the_rows(self):
        frame = pd.DataFrame(
            {
                "ID": ["1", "1"],
                "CURRENCY": ["USD", "GBP"],
                "Currency": ["EUR", "EUR"],
                "Ticker": ["AAA LN Equity", "AAA US Equity"],
            }
        )
        self.assertTrue(collapse_publication_lines(frame).empty)

    def test_one_ticker_per_isin_notes_the_rest(self):
        frame = pd.DataFrame(
            {
                "ISIN": ["IE00A", "IE00A"],
                "Ticker": ["AAA LN Equity", "AAA US Equity"],
            }
        )
        kept, notes = keep_one_listing(frame)
        self.assertEqual(kept["Ticker"].tolist(), ["AAA LN Equity"])
        self.assertTrue(notes)


class ReturnAndAverageTests(unittest.TestCase):
    def test_weekend_uses_the_level_on_or_before_and_ignores_a_later_print(self):
        levels = pd.Series(
            [10.0, 99.0],
            index=pd.to_datetime(["2026-10-23", "2026-10-26"]),
        )
        self.assertEqual(level_on_or_before(levels, "2026-10-24"), 10.0)
        self.assertEqual(level_on_or_before(levels, "2026-10-23"), 10.0)
        end = previous_london_day(AS_OF)
        start, bound_end, notes = period_bounds("1M", end)
        self.assertFalse(notes)
        history = pd.DataFrame(
            {
                "ID": ["AAA LN Equity", "AAA LN Equity", "AAA LN Equity"],
                "DATE": [start, bound_end, bound_end + pd.Timedelta(days=3)],
                "Level": [100.0, 110.0, 999.0],
            }
        )
        percents = return_percents(history, AS_OF)
        self.assertAlmostEqual(float(percents["1M Return %"].iloc[0]), 10.0)

    def test_non_positive_start_stays_blank(self):
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        history = pd.DataFrame(
            {
                "ID": ["AAA LN Equity", "AAA LN Equity"],
                "DATE": [start, bound_end],
                "Level": [0.0, 110.0],
            }
        )
        percents = return_percents(history, AS_OF)
        self.assertTrue(pd.isna(percents["1M Return %"].iloc[0]))

    def test_peer_average_follows_the_membership_and_skips_blanks(self):
        self.assertEqual(
            member_tickers("HSBC LN Equity", ["AAA LN Equity", "AAA LN Equity"], False),
            ["AAA LN Equity"],
        )
        self.assertEqual(
            member_tickers("HSBC LN Equity", ["AAA LN Equity"], True),
            ["HSBC LN Equity", "AAA LN Equity"],
        )
        book = pd.DataFrame(
            {
                "Ticker": ["HSBC LN Equity", "HSBC US Equity", "OTHER LN Equity"],
                "ISIN": ["IE00PRIMARY", "IE00SUB", "IE00OTHER"],
                "Fund Name": ["HSBC India", "HSBC India", "Other fund"],
            }
        )
        links = pd.DataFrame(
            {
                "Fund Name": ["HSBC India", "HSBC India"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity"],
            }
        )
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        quotes = pd.DataFrame(
            {
                "ID": [
                    "HSBC LN Equity",
                    "HSBC LN Equity",
                    "HSBC US Equity",
                    "HSBC US Equity",
                    "AAA LN Equity",
                    "AAA LN Equity",
                ],
                "DATE": [start, bound_end, start, bound_end, start, bound_end],
                "Bid": [10.0, 10.0, 10.0, 10.0, 10.0, 10.0],
                "Ask": [12.0, 12.0, 12.0, 12.0, 14.0, 14.0],
                "Mid": [11.0, 11.0, 11.0, 11.0, 12.0, 12.0],
            }
        )
        returns = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity", "HSBC LN Equity", "AAA LN Equity", "AAA LN Equity"],
                "DATE": [start, bound_end, start, bound_end],
                "Level": [100.0, 110.0, 100.0, 130.0],
            }
        )
        peers_only = peer_metric_frame(
            book, links, quotes, returns, ["1M"], False, AS_OF
        )
        both = peer_metric_frame(
            book, links, quotes, returns, ["1M"], True, AS_OF
        )
        aaa_percent = 4.0 / 12.0 * 100.0
        hsbc_percent = 2.0 / 11.0 * 100.0
        self.assertNotIn("1M Peer Avg Spread", peers_only.columns)
        self.assertAlmostEqual(float(peers_only["1M Peer Avg Spread %"].iloc[0]), aaa_percent)
        self.assertAlmostEqual(float(both["1M Peer Avg Spread %"].iloc[0]), (aaa_percent + hsbc_percent) / 2.0)
        self.assertAlmostEqual(float(peers_only["1M Peer Avg Return %"].iloc[0]), 30.0)
        self.assertAlmostEqual(float(both["1M Peer Avg Return %"].iloc[0]), 20.0)
        self.assertAlmostEqual(float(peers_only["1M Return %"].iloc[0]), 10.0)
        self.assertAlmostEqual(float(peers_only["1M Peer Avg Spread %"].iloc[1]), aaa_percent)
        self.assertTrue(pd.isna(peers_only["1M Peer Avg Spread %"].iloc[2]))

    def test_peer_and_benchmark_stop_on_the_hsbc_quote_date(self):
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        holiday = bound_end
        last_quote = holiday - pd.Timedelta(days=1)
        book = pd.DataFrame(
            {
                "Ticker": ["HSBC LN Equity"],
                "Fund Name": ["HSBC India"],
                "Benchmark Index": ["SPX Index"],
            }
        )
        links = pd.DataFrame(
            {"Fund Name": ["HSBC India"], "Ticker": ["AAA LN Equity"]}
        )
        quotes = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity", "HSBC LN Equity", "AAA LN Equity", "AAA LN Equity", "AAA LN Equity"],
                "DATE": [start, last_quote, start, last_quote, holiday],
                "Bid": [10.0, 10.0, 10.0, 10.0, 10.0],
                "Ask": [12.0, 12.0, 14.0, 14.0, 30.0],
                "Mid": [11.0, 11.0, 12.0, 12.0, 20.0],
            }
        )
        returns = pd.DataFrame(
            {
                "ID": [
                    "HSBC LN Equity",
                    "HSBC LN Equity",
                    "HSBC LN Equity",
                    "AAA LN Equity",
                    "AAA LN Equity",
                    "AAA LN Equity",
                    "SPX Index",
                    "SPX Index",
                    "SPX Index",
                ],
                "DATE": [start, last_quote, holiday, start, last_quote, holiday, start, last_quote, holiday],
                "Level": [100.0, 110.0, 999.0, 100.0, 130.0, 200.0, 100.0, 150.0, 300.0],
            }
        )
        frame = peer_metric_frame(book, links, quotes, returns, ["1M"], False, AS_OF)
        self.assertAlmostEqual(float(frame["1M Return %"].iloc[0]), 10.0)
        self.assertAlmostEqual(float(frame["1M Peer Avg Return %"].iloc[0]), 30.0)
        self.assertAlmostEqual(float(frame["1M Bmk Return %"].iloc[0]), 50.0)
        self.assertAlmostEqual(float(frame["1M Peer Avg Spread %"].iloc[0]), 4.0 / 12.0 * 100.0)
        chart = return_comparison(
            returns,
            "HSBC LN Equity",
            ["AAA LN Equity"],
            "1M",
            AS_OF,
            False,
            quotes=quotes,
            benchmark_id="SPX Index",
        )
        last = chart.loc[chart["DATE"].eq(pd.Timestamp(holiday))].iloc[0]
        self.assertAlmostEqual(float(last["Return %"]), 10.0)
        self.assertAlmostEqual(float(last["Peer Return %"]), 30.0)
        self.assertAlmostEqual(float(last["Bmk Return %"]), 50.0)

    def test_nav_return_uses_the_same_percent_as_total_return(self):
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        book = pd.DataFrame(
            {
                "Ticker": ["HSBC LN Equity"],
                "Fund Name": ["HSBC India"],
                "Benchmark Index": ["SPX Index"],
            }
        )
        links = pd.DataFrame({"Fund Name": ["HSBC India"], "Ticker": ["AAA LN Equity"]})
        quotes = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity", "HSBC LN Equity"],
                "DATE": [start, bound_end],
                "Bid": [10.0, 10.0],
                "Ask": [12.0, 12.0],
                "Mid": [11.0, 11.0],
            }
        )
        levels = pd.DataFrame(
            {
                "ID": [
                    "HSBC LN Equity",
                    "HSBC LN Equity",
                    "AAA LN Equity",
                    "AAA LN Equity",
                    "SPX Index",
                    "SPX Index",
                ],
                "DATE": [start, bound_end, start, bound_end, start, bound_end],
                "Level": [100.0, 110.0, 100.0, 130.0, 100.0, 150.0],
            }
        )
        nav_levels = levels.copy()
        nav_levels.loc[
            nav_levels["ID"].eq("SPX Index") & nav_levels["Level"].eq(150.0),
            "Level",
        ] = 300.0
        frame = peer_metric_frame(
            book, links, quotes, levels, ["1M"], False, AS_OF, nav_history=nav_levels
        )
        self.assertAlmostEqual(float(frame["1M Return %"].iloc[0]), 10.0)
        self.assertAlmostEqual(float(frame["1M NAV Return %"].iloc[0]), 10.0)
        self.assertAlmostEqual(float(frame["1M Peer Avg NAV Return %"].iloc[0]), 30.0)
        self.assertNotIn("1M Bmk NAV Return %", frame.columns)
        self.assertAlmostEqual(float(frame["1M Bmk Return %"].iloc[0]), 50.0)

    def test_visible_columns_follow_the_checkboxes(self):
        spread = visible_book_columns(["1M"], True, False)
        returns = visible_book_columns(["1M"], False, True)
        both = visible_book_columns(["1M"], True, True)
        none = visible_book_columns([], True, True)
        self.assertIn("1M Avg Spread %", spread)
        self.assertNotIn("1M Avg Spread", spread)
        self.assertNotIn("1M Peer Avg Spread", spread)
        self.assertIn("1M Peer Avg Spread %", spread)
        self.assertNotIn("1M Return %", spread)
        self.assertIn("1M Return %", returns)
        self.assertNotIn("1M NAV Return %", returns)
        self.assertIn("1M Peer Avg Return %", returns)
        self.assertIn("1M Bmk Return %", returns)
        nav = visible_book_columns(["1M"], False, False, True)
        self.assertIn("1M NAV Return %", nav)
        self.assertIn("1M Peer Avg NAV Return %", nav)
        self.assertIn("1M Bmk Return %", nav)
        self.assertNotIn("1M Bmk NAV Return %", nav)
        self.assertNotIn("1M Return %", nav)
        both_nav = visible_book_columns(["1M"], False, True, True)
        self.assertEqual(both_nav.count("1M Bmk Return %"), 1)
        self.assertLess(both_nav.index("1M Bmk Return %"), both_nav.index("1M NAV Return %"))
        self.assertNotIn("1M Bmk NAV Return %", both_nav)
        self.assertNotIn("1M Avg Spread", returns)
        self.assertLess(both.index("1M Peer Avg Spread %"), both.index("1M Return %"))
        self.assertNotIn("1M Avg Spread", none)
        self.assertNotIn("1M Return %", none)
        self.assertIn("Fund Name", none)

    def test_future_custom_blank_quote_day_and_mixed_currency(self):
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        last_quote = bound_end - pd.Timedelta(days=1)
        book = pd.DataFrame(
            {
                "Ticker": ["HSBC LN Equity"],
                "Fund Name": ["HSBC India"],
                "Currency": ["GBP"],
                "Benchmark Index": ["SPX Index"],
            }
        )
        links = pd.DataFrame(
            {
                "Fund Name": ["HSBC India", "HSBC India"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity"],
                "Currency": ["GBP", "GBX"],
            }
        )
        quotes = pd.DataFrame(
            {
                "ID": [
                    "HSBC LN Equity",
                    "HSBC LN Equity",
                    "HSBC LN Equity",
                    "AAA LN Equity",
                    "AAA LN Equity",
                    "BBB LN Equity",
                ],
                "DATE": [start, last_quote, bound_end, last_quote, bound_end, last_quote],
                "Bid": [10.0, 10.0, pd.NA, 10.0, 10.0, 10.0],
                "Ask": [12.0, 12.0, pd.NA, 14.0, 30.0, 20.0],
                "Mid": [11.0, 11.0, pd.NA, 12.0, 20.0, 15.0],
            }
        )
        returns = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity", "HSBC LN Equity", "AAA LN Equity", "SPX Index", "SPX Index"],
                "DATE": [start, last_quote, last_quote, start, last_quote],
                "Level": [100.0, 110.0, 130.0, 100.0, 150.0],
            }
        )
        future = peer_metric_frame(
            book,
            links,
            quotes,
            returns,
            ["Custom"],
            False,
            AS_OF,
            custom_start=end + pd.Timedelta(days=10),
            custom_end=end + pd.Timedelta(days=20),
        )
        self.assertTrue(pd.isna(future["Custom Return %"].iloc[0]))
        self.assertTrue(pd.isna(future["Custom Peer Avg Return %"].iloc[0]))
        self.assertTrue(pd.isna(future["Custom Bmk Return %"].iloc[0]))
        self.assertTrue(pd.isna(future["Custom Peer Avg Spread %"].iloc[0]))
        aligned = peer_metric_frame(book, links, quotes, returns, ["1M"], False, AS_OF)
        self.assertAlmostEqual(
            float(aligned["1M Peer Avg Spread %"].iloc[0]),
            (4.0 / 12.0 * 100.0 + 10.0 / 15.0 * 100.0) / 2.0,
        )
        self.assertAlmostEqual(float(aligned["1M Return %"].iloc[0]), 10.0)
        self.assertAlmostEqual(float(aligned["1M Bmk Return %"].iloc[0]), 50.0)
        chart = return_comparison(
            returns,
            "HSBC LN Equity",
            ["AAA LN Equity"],
            "Custom",
            AS_OF,
            False,
            custom_start=end + pd.Timedelta(days=10),
            custom_end=end + pd.Timedelta(days=20),
            quotes=quotes,
            benchmark_id="SPX Index",
        )
        self.assertTrue(chart.empty)

    def test_peers_tab_uses_the_first_level_inside_the_window(self):
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        first = pd.Timestamp(start) + pd.Timedelta(days=3)
        history = pd.DataFrame(
            {
                "ID": ["AAA LN Equity", "AAA LN Equity"],
                "DATE": [first, bound_end],
                "Level": [100.0, 110.0],
            }
        )
        percents = return_percents(history, AS_OF)
        self.assertAlmostEqual(float(percents["1M Return %"].iloc[0]), 10.0)

    def test_a_non_positive_first_level_stays_blank(self):
        end = previous_london_day(AS_OF)
        start, bound_end, _notes = period_bounds("1M", end)
        first = pd.Timestamp(start) + pd.Timedelta(days=3)
        history = pd.DataFrame(
            {
                "ID": ["AAA LN Equity", "AAA LN Equity"],
                "DATE": [first, bound_end],
                "Level": [0.0, 110.0],
            }
        )
        percents = return_percents(history, AS_OF)
        self.assertTrue(pd.isna(percents["1M Return %"].iloc[0]))

    def test_spread_average_does_not_include_the_session_before_the_window(self):
        as_of = pd.Timestamp("2026-10-26")
        end = previous_london_day(as_of)
        start, _bound_end, _notes = period_bounds("1M", end)
        before = pd.Timestamp(start) - pd.Timedelta(days=1)
        inside = pd.Timestamp(start) + pd.Timedelta(days=2)
        book = pd.DataFrame(
            {"Ticker": ["HSBC LN Equity"], "Fund Name": ["HSBC India"], "Currency": ["GBP"]}
        )
        links = pd.DataFrame(
            {"Fund Name": ["HSBC India"], "Ticker": ["AAA LN Equity"], "Currency": ["GBP"]}
        )
        quotes = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity"] * 3 + ["AAA LN Equity"] * 3,
                "DATE": [before, inside, end, before, inside, end],
                "Bid": [10.0] * 6,
                "Ask": [20.0, 12.0, 12.0, 20.0, 12.0, 12.0],
                "Mid": [15.0, 11.0, 11.0, 15.0, 11.0, 11.0],
            }
        )
        frame = peer_metric_frame(book, links, quotes, None, ["1M"], False, as_of)
        self.assertNotIn("1M Peer Avg Spread", frame.columns)
        self.assertAlmostEqual(float(frame["1M Peer Avg Spread %"].iloc[0]), 2.0 / 11.0 * 100.0)
        quotes = pd.concat(
            [
                quotes,
                pd.DataFrame(
                    {
                        "ID": ["BBB LN Equity", "BBB LN Equity", "BBB LN Equity"],
                        "DATE": [before, inside, end],
                        "Bid": [10.0, 10.0, 10.0],
                        "Ask": [30.0, 20.0, 20.0],
                        "Mid": [20.0, 15.0, 15.0],
                    }
                ),
            ],
            ignore_index=True,
        )
        chart = spread_comparison(
            quotes,
            "HSBC LN Equity",
            ["AAA LN Equity", "BBB LN Equity"],
            "1M",
            as_of,
            False,
        )
        last = chart.dropna(subset=["Peer Spread %"]).iloc[-1]
        self.assertNotIn("Peer Spread", chart.columns)
        aaa_percent = 2.0 / 11.0 * 100.0
        bbb_percent = 10.0 / 15.0 * 100.0
        self.assertAlmostEqual(float(last["Peer Spread %"]), (aaa_percent + bbb_percent) / 2.0)
        lines = peer_member_spreads(
            quotes,
            "HSBC LN Equity",
            [("AAA LN Equity", "Peer A"), ("BBB LN Equity", "Peer B"), ("HSBC LN Equity", "HSBC")],
            "1M",
            as_of,
        )
        self.assertIn("Peer A Spread %", lines.columns)
        self.assertIn("Peer B Spread %", lines.columns)
        self.assertNotIn("HSBC Spread %", lines.columns)
        self.assertAlmostEqual(float(lines["Peer A Spread %"].dropna().iloc[-1]), aaa_percent)

    def test_blank_peer_currency_stays_in_the_absolute_average(self):
        as_of = pd.Timestamp("2026-10-26")
        end = previous_london_day(as_of)
        start, _bound_end, _notes = period_bounds("1M", end)
        inside = pd.Timestamp(start) + pd.Timedelta(days=2)
        book = pd.DataFrame(
            {"Ticker": ["HSBC LN Equity"], "Fund Name": ["HSBC India"], "Currency": ["GBP"]}
        )
        links = pd.DataFrame(
            {
                "Fund Name": ["HSBC India", "HSBC India"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity"],
                "Currency": ["", "GBX"],
            }
        )
        quotes = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity"] * 2 + ["AAA LN Equity"] * 2 + ["BBB LN Equity"] * 2,
                "DATE": [inside, end, inside, end, inside, end],
                "Bid": [10.0] * 6,
                "Ask": [12.0] * 2 + [14.0] * 2 + [20.0] * 2,
                "Mid": [11.0] * 2 + [12.0] * 2 + [15.0] * 2,
            }
        )
        frame = peer_metric_frame(book, links, quotes, None, ["1M"], False, as_of)
        self.assertNotIn("1M Peer Avg Spread", frame.columns)
        self.assertAlmostEqual(float(frame["1M Peer Avg Spread %"].iloc[0]), (4.0 / 12.0 + 10.0 / 15.0) / 2.0 * 100.0)

    def test_a_flat_print_inside_five_years_stays_zero(self):
        levels = pd.DataFrame(
            {
                "ID": ["AAA LN Equity", "AAA LN Equity"],
                "DATE": ["2025-12-30", "2025-12-31"],
                "Level": [100.0, 100.0],
            }
        )
        percents = return_percents(levels, pd.Timestamp("2026-10-29"))
        self.assertTrue(pd.isna(percents["1M Return %"].iloc[0]))
        self.assertAlmostEqual(float(percents["5Y Return %"].iloc[0]), 0.0)


class PeerGroupFlowTests(unittest.TestCase):
    def test_peer_group_sums_present_tickers_and_leaves_a_blank_group_blank(self):
        book = pd.DataFrame(
            {
                "ISIN": ["IE00HSBC", "IE00OTHER"],
                "Fund Name": ["HS", "Other"],
                "Share Class": ["Acc", "Acc"],
                "Ticker": ["HSBC LN Equity", "OTHER LN Equity"],
            }
        )
        links = pd.DataFrame(
            {
                "Fund Name": ["HS", "HS", "Other"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity", "CCC LN Equity"],
            }
        )
        flows = pd.DataFrame(
            {
                "ID": ["AAA LN Equity", "BBB LN Equity", "CCC LN Equity"],
                "DATE": ["2026-10-06", "2026-10-06", "2026-10-06"],
                "Flow": [1.0, 2.0, pd.NA],
            }
        )
        matrix, _notes = peer_group_flow_matrix(flows, links, book, "1Y", AS_OF)
        self.assertAlmostEqual(float(matrix.loc["HS"].sum(skipna=True)), 3.0)
        self.assertNotIn("Other", list(matrix.index))
