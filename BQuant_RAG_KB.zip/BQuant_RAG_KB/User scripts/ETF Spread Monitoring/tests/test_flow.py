"""Flow heatmap buckets. No Bloomberg call."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread.data import fetch_fund_flows  # noqa: E402
from etf_spread.flow_view import (  # noqa: E402
    combined_flow_matrix,
    flow_bucket,
    flow_matrix,
    heatmap_size,
    hsbc_flow_matrix,
)


AS_OF = pd.Timestamp("2026-10-23")


class HeatmapSizeTests(unittest.TestCase):
    def test_each_fund_row_keeps_its_height(self) -> None:
        short_height, short_left = heatmap_size(["A", "B"])
        tall_height, _left = heatmap_size(["A"] * 40)
        self.assertEqual(tall_height - short_height, 28 * 38)
        _height, wide_left = heatmap_size(["HSBC S&P 500 UCITS ETF"])
        self.assertGreater(wide_left, short_left)


def _book() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "Ticker": ["HSAX LN Equity", "HSAX LN Equity", "BOND LN Equity", "BLANK LN Equity"],
            "Strategy": ["Equity", "Equity", "Bond", ""],
            "Fund Name": ["HS", "HS", "Bond fund", "Blank"],
            "Share Class": ["Acc", "Dist", "Acc", "Acc"],
            "Share Class AUM (USD mn)": [1.5, 2.5, 0.0, pd.NA],
        }
    )


def _flows() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "ID": [
                "HSAX LN Equity",
                "hsax ln equity",
                "BOND LN Equity",
                "BLANK LN Equity",
                "HSAX LN Equity",
            ],
            "DATE": ["2026-10-06", "2026-10-05", "2026-09-15", "2026-10-10", "2026-09-01"],
            "Flow": [-2.0, 5.0, 8.0, 1.0, 4.0],
        }
    )


def _column_in_month(matrix: pd.DataFrame, year: int, month: int):
    matches = [
        column
        for column in matrix.columns
        if pd.Timestamp(column).year == year and pd.Timestamp(column).month == month
    ]
    return matches


class FlowMatrixTests(unittest.TestCase):
    def test_short_periods_are_weekly_and_longer_periods_are_monthly(self):
        self.assertEqual(flow_bucket("1M"), "W-FRI")
        self.assertEqual(flow_bucket("3M"), "W-FRI")
        for period in ("6M", "YTD", "1Y", "3Y", "5Y"):
            self.assertEqual(flow_bucket(period), "M")

    def test_same_ticker_is_counted_once_and_days_still_add(self):
        matrix, _notes = flow_matrix(_flows(), _book(), "Strategy", "1M", AS_OF)
        self.assertIn("Equity", matrix.index)
        self.assertNotIn("Bond", list(matrix.index))
        self.assertAlmostEqual(float(matrix.loc["Equity"].sum(skipna=True)), 3.0)

    def test_unsorted_dates_and_a_blank_group_stay_out(self):
        matrix, notes = flow_matrix(_flows(), _book(), "Strategy", "1Y", AS_OF)
        self.assertFalse(any("BLANK" in str(label) for label in matrix.index))
        september = _column_in_month(matrix, 2026, 9)
        october = _column_in_month(matrix, 2026, 10)
        self.assertEqual(len(september), 1)
        self.assertEqual(len(october), 1)
        self.assertAlmostEqual(float(matrix.loc["Equity", september[0]]), 4.0)
        self.assertAlmostEqual(float(matrix.loc["Equity", october[0]]), 3.0)
        self.assertAlmostEqual(float(matrix.loc["Bond", september[0]]), 8.0)
        self.assertFalse(any("not on this book" in note for note in notes))

    def test_missing_bucket_is_blank_and_a_zero_flow_stays_zero(self):
        flows = pd.DataFrame(
            {
                "ID": ["HSAX LN Equity", "CASH LN Equity", "BOND LN Equity"],
                "DATE": ["2026-10-05", "2026-10-05", "2026-09-15"],
                "Flow": [3.0, 0.0, 8.0],
            }
        )
        book = _book()
        extra = pd.DataFrame(
            {
                "Ticker": ["CASH LN Equity"],
                "Strategy": ["Cash"],
                "Fund Name": ["Cash fund"],
                "Share Class": ["Acc"],
                "Share Class AUM (USD mn)": [1.0],
            }
        )
        book = pd.concat([book, extra], ignore_index=True)
        matrix, _notes = flow_matrix(flows, book, "Strategy", "1Y", AS_OF)
        october = _column_in_month(matrix, 2026, 10)[0]
        self.assertAlmostEqual(float(matrix.loc["Cash", october]), 0.0)
        self.assertTrue(pd.isna(matrix.loc["Bond", october]))

    def test_weekend_flow_is_kept(self):
        book = _book()
        book.loc[book["Ticker"].eq("BLANK LN Equity"), "Strategy"] = "Listing"
        matrix, _notes = flow_matrix(_flows(), book, "Strategy", "1M", AS_OF)
        self.assertIn("Listing", list(matrix.index))
        self.assertAlmostEqual(float(matrix.loc["Listing"].sum(skipna=True)), 1.0)

    def test_ytd_drops_the_prior_year(self):
        flows = _flows()
        flows = pd.concat(
            [
                flows,
                pd.DataFrame(
                    {"ID": ["HSAX LN Equity"], "DATE": ["2025-12-15"], "Flow": [50.0]}
                ),
            ],
            ignore_index=True,
        )
        matrix, _notes = flow_matrix(flows, _book(), "Strategy", "YTD", AS_OF)
        self.assertFalse(any(pd.Timestamp(column).year == 2025 for column in matrix.columns))
        self.assertAlmostEqual(float(matrix.loc["Equity"].sum(skipna=True)), 7.0)

    def test_unknown_period_does_not_raise(self):
        matrix, notes = flow_matrix(_flows(), _book(), "Strategy", "Custom", AS_OF)
        self.assertTrue(matrix.empty)
        self.assertTrue(notes)

    def test_flow_rows_keep_the_typed_book_order(self):
        book = pd.DataFrame(
            {
                "Fund Name": ["Zulu fund", "Alpha fund"],
                "Ticker": ["ZULU LN Equity", "ALPHA LN Equity"],
                "Share Class": ["Acc", "Acc"],
            }
        )
        flows = pd.DataFrame(
            {
                "ID": ["ZULU LN Equity", "ALPHA LN Equity"],
                "DATE": ["2026-10-06", "2026-10-06"],
                "Flow": [4.0, 5.0],
            }
        )
        matrix, _notes = hsbc_flow_matrix(flows, book, "1Y", AS_OF)
        self.assertEqual(list(matrix.index), ["Zulu fund", "Alpha fund"])


class HsbcFlowTests(unittest.TestCase):
    def test_share_classes_of_one_fund_are_one_fund_name_row(self):
        book = pd.DataFrame(
            {
                "Fund Name": ["HS", "HS"],
                "Ticker": ["HSBC LN Equity", "HSBC2 LN Equity"],
                "Share Class": ["Acc", "Dist"],
            }
        )
        flows = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity", "HSBC2 LN Equity"],
                "DATE": ["2026-10-06", "2026-10-06"],
                "Flow": [4.0, 5.0],
            }
        )
        matrix, _notes = hsbc_flow_matrix(flows, book, "1Y", AS_OF)
        self.assertEqual(list(matrix.index), ["HS"])
        self.assertAlmostEqual(float(matrix.loc["HS"].sum(skipna=True)), 4.0)

    def test_primary_share_is_the_one_fund_flow(self):
        book = pd.DataFrame(
            {
                "Fund Name": ["HS", "HS"],
                "Ticker": ["HSBC LN Equity", "HSBC2 LN Equity"],
                "Primary": ["No", "Yes"],
            }
        )
        flows = pd.DataFrame(
            {
                "ID": ["HSBC LN Equity", "HSBC2 LN Equity"],
                "DATE": ["2026-10-06", "2026-10-06"],
                "Flow": [4.0, 5.0],
            }
        )
        matrix, _notes = hsbc_flow_matrix(flows, book, "1Y", AS_OF)
        self.assertEqual(list(matrix.index), ["HS"])
        self.assertAlmostEqual(float(matrix.loc["HS"].sum(skipna=True)), 5.0)


class CombinedFlowTests(unittest.TestCase):
    def test_hsbc_and_peers_add_and_a_shared_ticker_counts_once(self):
        book = pd.DataFrame(
            {
                "Fund Name": ["HS", "HS", "Other"],
                "Ticker": ["HSBC LN Equity", "HSBC2 LN Equity", "OTHER LN Equity"],
                "Share Class": ["Acc", "Dist", "Acc"],
            }
        )
        links = pd.DataFrame(
            {
                "Fund Name": ["HS", "HS", "HS", "Other"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity", "HSBC LN Equity", "CCC LN Equity"],
            }
        )
        flows = pd.DataFrame(
            {
                "ID": [
                    "AAA LN Equity",
                    "BBB LN Equity",
                    "HSBC LN Equity",
                    "CCC LN Equity",
                    "OTHER LN Equity",
                ],
                "DATE": ["2026-10-06"] * 5,
                "Flow": [1.0, 2.0, 4.0, pd.NA, 10.0],
            }
        )
        matrix, notes = combined_flow_matrix(flows, links, book, "1Y", AS_OF)
        self.assertEqual(list(matrix.index), ["HS", "Other"])
        self.assertAlmostEqual(float(matrix.loc["HS"].sum(skipna=True)), 7.0)
        self.assertAlmostEqual(float(matrix.loc["Other"].sum(skipna=True)), 10.0)
        self.assertFalse(any("not on this book" in note for note in notes))

    def test_combined_rows_keep_the_typed_book_order(self):
        book = pd.DataFrame(
            {
                "Fund Name": ["Zulu fund", "Alpha fund"],
                "Ticker": ["ZULU LN Equity", "ALPHA LN Equity"],
                "Share Class": ["Acc", "Acc"],
            }
        )
        links = pd.DataFrame(
            {
                "Fund Name": ["Zulu fund", "Alpha fund"],
                "Ticker": ["ZP LN Equity", "AP LN Equity"],
            }
        )
        flows = pd.DataFrame(
            {
                "ID": ["ZULU LN Equity", "ALPHA LN Equity", "ZP LN Equity", "AP LN Equity"],
                "DATE": ["2026-10-06"] * 4,
                "Flow": [4.0, 5.0, 1.0, 2.0],
            }
        )
        matrix, _notes = combined_flow_matrix(flows, links, book, "1Y", AS_OF)
        self.assertEqual(list(matrix.index), ["Zulu fund", "Alpha fund"])

    def test_missing_peers_still_sum_the_hsbc_tickers(self):
        book = pd.DataFrame(
            {
                "Fund Name": ["HS"],
                "Ticker": ["HSBC LN Equity"],
                "Share Class": ["Acc"],
            }
        )
        flows = pd.DataFrame(
            {"ID": ["HSBC LN Equity"], "DATE": ["2026-10-06"], "Flow": [4.0]}
        )
        matrix, notes = combined_flow_matrix(flows, pd.DataFrame(), book, "1Y", AS_OF)
        self.assertAlmostEqual(float(matrix.loc["HS"].sum(skipna=True)), 4.0)
        self.assertTrue(any("Top 5 Peers" in note for note in notes))

    def test_two_funds_with_one_long_name_keep_two_heatmap_rows(self):
        from etf_spread.flow_view import flow_row_labels

        book = pd.DataFrame(
            {
                "Fund Name": ["Fund A", "Fund B"],
                "Ticker": ["FA LN Equity", "FB LN Equity"],
                "Long Name": ["HSBC Global ETF", "HSBC Global ETF"],
                "Share Class": ["Acc", "Acc"],
            }
        )
        labels = flow_row_labels(book)
        self.assertEqual(len(set(labels.values())), 2)
        self.assertEqual(
            sorted(labels.values()),
            ["HSBC Global ETF (Fund A)", "HSBC Global ETF (Fund B)"],
        )

    def test_unique_long_names_are_not_qualified(self):
        from etf_spread.flow_view import flow_row_labels

        book = pd.DataFrame(
            {
                "Fund Name": ["Fund A", "Fund B"],
                "Ticker": ["FA LN Equity", "FB LN Equity"],
                "Long Name": ["HSBC Alpha ETF", "HSBC Beta ETF"],
                "Share Class": ["Acc", "Acc"],
            }
        )
        self.assertEqual(
            flow_row_labels(book),
            {"Fund A": "HSBC Alpha ETF", "Fund B": "HSBC Beta ETF"},
        )


class FundFlowFetchTests(unittest.TestCase):
    def test_empty_book_and_missing_bql_do_not_raise(self):
        empty = fetch_fund_flows([], AS_OF, AS_OF)
        self.assertTrue(empty.observations.empty)
        self.assertTrue(any("No ticker" in note for note in empty.errors))
        backwards = fetch_fund_flows(["HSAX LN Equity"], AS_OF, AS_OF - pd.Timedelta(days=10))
        self.assertTrue(backwards.observations.empty)
        self.assertTrue(any("start on or before" in note for note in backwards.errors))
        missing = fetch_fund_flows(["HSAX LN Equity"], "2021-10-25", AS_OF)
        self.assertTrue(missing.observations.empty)
        self.assertTrue(any("bql is unavailable" in note for note in missing.errors))
