"""Peer table helpers. These tests do not call Bloomberg."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread.data import fetch_peer_links, tracking_error_number  # noqa: E402
from etf_spread.flow_view import flow_row_labels  # noqa: E402
from etf_spread.peers import (  # noqa: E402
    FUND_INFO_COLUMNS,
    FUND_INFO_GROUP,  # noqa: E402
    fund_choices,
    fund_menu_options,
    funds_for_strategy,
    peer_columns,
    peer_detail_rows,
    peer_view,
    primary_ticker,
    selected_book_fields,
    visible_with_groups,
)

DATA_PATH = Path(__file__).resolve().parents[1] / "etf_spread" / "data.py"


class PeerTableTests(unittest.TestCase):
    def test_fund_choices_keep_book_order_once(self) -> None:
        book = pd.DataFrame({"Fund Name": ["Beta", "Alpha", "Beta", "  ", None]})
        self.assertEqual(fund_choices(book), ["Beta", "Alpha"])

    def test_primary_ticker_does_not_substitute_another_class(self) -> None:
        frame = pd.DataFrame(
            {
                "Fund Name": ["Alpha", "Alpha"],
                "Primary": ["No", "Yes"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity"],
            }
        )
        self.assertEqual(primary_ticker(frame, "Alpha"), "BBB LN Equity")
        self.assertEqual(primary_ticker(frame.iloc[:1], "Alpha"), "")

    def test_unchecked_periods_stay_out_of_the_table(self) -> None:
        self.assertNotIn("1Y Avg Spread %", peer_columns([]))
        self.assertNotIn("1M Avg Spread", peer_columns(["1M"]))
        self.assertIn("1M Avg Spread %", peer_columns(["1M"]))

    def test_selected_row_stays_first(self) -> None:
        snapshot = pd.DataFrame(
            {
                "Role": ["Peer", "Selected"],
                "Name": ["Alpha", "Beta"],
                "Ticker": ["AAA LN Equity", "BBB LN Equity"],
                "Bid": [10.0, 20.0],
                "Ask": [10.2, 20.1],
                "Mid": [10.1, 20.05],
            }
        )
        view = peer_view(snapshot, pd.DataFrame(), [])
        self.assertEqual(view["Role"].tolist(), ["Selected", "Peer"])
        self.assertNotIn("1Y Avg Spread", view.columns)

    def test_wide_strategy_is_not_priced(self) -> None:
        text = (PROJECT_ROOT / "etf_spread" / "peers.py").read_text(encoding="utf-8")
        self.assertNotIn("PEER_PRICING_LIMIT", text)
        self.assertNotIn("peer_pricing_allowed", text)

    def test_request_uses_the_manual_peer_map(self) -> None:
        text = DATA_PATH.read_text(encoding="utf-8")
        self.assertNotIn("etf_undl_index_ticker() == benchmark", text)
        self.assertIn("peer_map.py", text)
        self.assertIn('bq.data.fund_typ() == "ETF"', text)
        self.assertNotIn("bq.func.value", text)
        self.assertNotIn("mapby", text)
        self.assertNotIn("BLOOMBERG_BEST_FIT", text)
        self.assertNotIn("types=['ACTIVE'", text)
        self.assertIn('bq.data.tracking_error()["value"]', text)
        self.assertEqual(text.count("bq.data.tracking_error"), 1)
        self.assertEqual(text.count("tot_return_index_gross_dvds"), 1)

    def test_return_mode_replaces_period_spread_columns(self) -> None:
        self.assertIn("1M Return %", peer_columns(["1M"], mode="Return"))
        self.assertNotIn("1M Avg Spread %", peer_columns(["1M"], mode="Return"))
        self.assertNotIn("1M Avg Spread", peer_columns(["1M"]))
        self.assertIn("1M Avg Spread %", peer_columns(["1M"]))

    def test_peer_columns_show_nav_tracking_before_px_last_tracking(self):
        columns = peer_columns([])
        self.assertLess(
            columns.index("NAV Tracking Error"), columns.index("Tracking Error")
        )

    def test_nav_tracking_error_stays_on_the_vendor_scale(self):
        snapshot = pd.DataFrame(
            {
                "Role": ["Selected"],
                "Name": ["Beta"],
                "Ticker": ["BBB LN Equity"],
                "NAV Tracking Error": [2.5],
                "Tracking Error": [1.25],
                "Bid": [20.0],
                "Ask": [20.1],
                "Mid": [20.05],
            }
        )
        view = peer_view(snapshot, pd.DataFrame(), [])
        self.assertAlmostEqual(float(view["NAV Tracking Error"].iloc[0]), 2.5)
        self.assertAlmostEqual(float(view["Tracking Error"].iloc[0]), 1.25)

    def test_tracking_error_is_converted_to_percent(self) -> None:
        self.assertEqual(tracking_error_number(1.25), 125.0)
        self.assertTrue(pd.isna(tracking_error_number(None)))
        self.assertTrue(pd.isna(tracking_error_number("n/a")))
        self.assertIn("Tracking Error", peer_columns([]))
        self.assertIn("NAV Tracking Error", peer_columns([]))
        snapshot = pd.DataFrame(
            {
                "Role": ["Selected"],
                "Name": ["Beta"],
                "Ticker": ["BBB LN Equity"],
                "Tracking Error": [1.25],
                "Bid": [20.0],
                "Ask": [20.1],
                "Mid": [20.05],
            }
        )
        view = peer_view(snapshot, pd.DataFrame(), [])
        self.assertAlmostEqual(float(view["Tracking Error"].iloc[0]), 1.25)

    def test_selected_name_uses_the_listing_name_then_the_fund_name(self) -> None:
        listing = selected_book_fields(
            pd.Series({"Name": "HSBC S&P 500", "Fund Name": "HSBC S&P", "Share Class": "Acc", "Currency": "GBP"})
        )
        self.assertEqual(listing["Name"], "HSBC S&P 500")
        fund_only = selected_book_fields(
            pd.Series({"Fund Name": "HSBC S&P", "Share Class": "Acc", "Currency": "USD"})
        )
        self.assertEqual(fund_only["Name"], "HSBC S&P")
        self.assertEqual(fund_only["Share Class"], "Acc")
        self.assertEqual(fund_only["Currency"], "USD")

    def test_fund_choices_follow_the_typed_strategy(self) -> None:
        book = pd.DataFrame(
            {
                "Fund Name": ["ONE", "ONE", "TWO"],
                "Strategy": ["Equity", "Equity", "Fixed Income"],
            }
        )
        self.assertEqual(funds_for_strategy(book, "Equity"), ["All", "ONE"])
        self.assertEqual(funds_for_strategy(book, "All"), ["All", "ONE", "TWO"])
        self.assertEqual(funds_for_strategy(pd.DataFrame(), "Equity"), ["All"])

    def test_a_collapsed_period_hides_only_its_metric_columns(self) -> None:
        columns = ["Fund Name", "1M Avg Spread %", "1M Peer Avg Return %", "3M Return %", "Primary"]
        shown = visible_with_groups(columns, {"1M"})
        self.assertEqual(shown, ["Fund Name", "3M Return %", "Primary"])

    def test_fund_info_stays_open_until_that_group_is_closed(self) -> None:
        columns = [
            "Fund Name",
            *FUND_INFO_COLUMNS,
            "Fund AUM (USD mn)",
            "Absolute Spread",
        ]
        open_view = visible_with_groups(columns, {"1M"})
        self.assertEqual(open_view, columns)
        closed = visible_with_groups(columns, {"1M", FUND_INFO_GROUP})
        self.assertEqual(
            closed,
            ["Fund Name", "Fund AUM (USD mn)", "Absolute Spread"],
        )
        self.assertNotIn("Strategy", closed)
        self.assertNotIn("Benchmark", closed)
        self.assertNotIn("Primary", closed)

    def test_anchor_rows_keep_the_typed_book_order(self) -> None:
        hsbc = pd.DataFrame(
            [
                {
                    "Fund Name": "Zulu fund",
                    "Ticker": "Z1 LN Equity",
                    "Primary": "Yes",
                    "Percent Spread": 1.0,
                },
                {
                    "Fund Name": "Alpha fund",
                    "Ticker": "A1 LN Equity",
                    "Primary": "Yes",
                    "Percent Spread": 2.0,
                },
            ]
        )
        links = pd.DataFrame(
            [
                {
                    "Fund Name": "Zulu fund",
                    "Name": "Zulu peer",
                    "Ticker": "ZP LN Equity",
                },
                {
                    "Fund Name": "Alpha fund",
                    "Name": "Alpha peer",
                    "Ticker": "AP LN Equity",
                },
            ]
        )
        detail = peer_detail_rows(hsbc, links, pd.DataFrame(), pd.DataFrame())
        self.assertEqual(
            detail["Fund Name"].tolist(),
            ["Zulu fund", "Zulu peer", "Alpha fund", "Alpha peer"],
        )
        self.assertEqual(
            detail["HSBC Fund"].tolist(),
            ["Zulu fund", "Zulu fund", "Alpha fund", "Alpha fund"],
        )

    def test_peer_detail_lists_the_primary_then_its_peer(self) -> None:
        hsbc = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Share Class": "Acc",
                    "ISIN": "IE00HSBC00001",
                    "Currency": "GBP",
                    "Primary": "Yes",
                    "Ticker": "H1 LN Equity",
                    "Bid": 10.0,
                    "Ask": 10.2,
                    "Mid": 10.1,
                    "Absolute Spread": 0.2,
                    "Percent Spread": 1.98,
                    "1M Avg Spread %": 1.0,
                    "1M Peer Avg Spread %": 2.0,
                    "1M Return %": 5.0,
                }
            ]
        )
        links = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Name": "Peer A",
                    "Share Class": "Acc",
                    "Primary ISIN": "IE00PEER000001",
                    "Ticker": "P1 LN Equity",
                    "Currency": "USD",
                }
            ]
        )
        history = pd.DataFrame(
            {
                "ID": ["P1 LN Equity", "P1 LN Equity"],
                "DATE": ["2026-10-27", "2026-10-28"],
                "Bid": [10.0, 11.0],
                "Ask": [12.0, 13.0],
                "Mid": [11.0, 12.0],
            }
        )
        detail = peer_detail_rows(hsbc, links, history, pd.DataFrame())
        self.assertEqual(detail["Fund Name"].tolist(), ["ONE", "Peer A"])
        self.assertEqual(detail["ISIN"].tolist(), ["IE00HSBC00001", "IE00PEER000001"])
        self.assertEqual(detail["Primary"].tolist(), ["Yes", "Yes"])
        self.assertAlmostEqual(float(detail["Bid"].iloc[1]), 11.0)
        self.assertAlmostEqual(float(detail["Absolute Spread"].iloc[1]), 2.0)
        self.assertAlmostEqual(float(detail["Percent Spread"].iloc[1]), 2.0 / 12.0 * 100.0)
        self.assertNotIn("1M Avg Spread", detail.columns)
        self.assertNotIn("1M Peer Avg Spread", detail.columns)
        self.assertAlmostEqual(float(detail["1M Peer Avg Spread %"].iloc[0]), 2.0)
        self.assertTrue(pd.isna(detail["1M Peer Avg Spread %"].iloc[1]))
        self.assertTrue(pd.isna(detail["1M Return %"].iloc[1]))
        self.assertEqual(detail["HSBC Fund"].tolist(), ["ONE", "ONE"])

    def test_peer_latest_percent_reads_mid_from_the_quote_history(self) -> None:
        hsbc = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Ticker": "H1 LN Equity",
                    "Bid": 10.0,
                    "Ask": 10.2,
                    "Absolute Spread": 0.2,
                    "Percent Spread": 1.98,
                }
            ]
        )
        links = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Name": "Peer A",
                    "Ticker": "P1 LN Equity",
                    "Primary ISIN": "IE00PEER000001",
                }
            ]
        )
        history = pd.DataFrame(
            {
                "ID": ["P1 LN Equity", "P1 LN Equity"],
                "DATE": ["2026-10-27", "2026-10-28"],
                "Bid": [10.0, 11.0],
                "Ask": [12.0, 13.0],
                "Mid": [11.0, 10.0],
            }
        )
        detail = peer_detail_rows(hsbc, links, history, pd.DataFrame())
        self.assertNotIn("Mid", detail.columns)
        self.assertAlmostEqual(float(detail["Absolute Spread"].iloc[1]), 2.0)
        self.assertAlmostEqual(float(detail["Percent Spread"].iloc[1]), 2.0 / 10.0 * 100.0)

    def test_peer_row_fills_its_own_facts_and_leaves_peer_average_blank(self) -> None:
        from etf_spread.book_view import last_completed_london_day

        as_of = last_completed_london_day()
        earlier = as_of - pd.Timedelta(days=20)
        later = as_of - pd.Timedelta(days=1)
        hsbc = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Ticker": "H1 LN Equity",
                    "Last": 50.0,
                    "Fund AUM (USD mn)": 100.0,
                    "Share Class AUM (USD mn)": 10.0,
                    "Tracking Error": 0.2,
                    "NAV Tracking Error": 0.3,
                    "Strategy": "Fixed Income",
                    "Benchmark": "HSBC Index Name",
                    "Benchmark Index": "HSBC Index",
                    "Primary": "Yes",
                    "1M Return %": 1.0,
                    "1M Peer Avg Return %": 4.0,
                    "1M Bmk Return %": 8.0,
                }
            ]
        )
        links = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Name": "Peer A",
                    "Ticker": "P1 LN Equity",
                    "Primary ISIN": "IE00PEER000001",
                    "Currency": "USD",
                }
            ]
        )
        levels = pd.DataFrame(
            {
                "ID": ["P1 LN Equity", "P1 LN Equity", "SPX Index", "SPX Index"],
                "DATE": [earlier, later, earlier, later],
                "Level": [100.0, 110.0, 100.0, 150.0],
            }
        )
        facts = pd.DataFrame(
            [
                {
                    "Ticker": "P1 LN Equity",
                    "Last": 22.5,
                    "Fund AUM (USD mn)": 30.0,
                    "Share Class AUM (USD mn)": 4.0,
                    "Tracking Error": 0.11,
                    "NAV Tracking Error": 0.12,
                    "Strategy": "Equity",
                    "Benchmark": "S&P 500",
                    "Benchmark Index": "SPX Index",
                }
            ]
        )
        nav_levels = levels.copy()
        nav_levels.loc[nav_levels["ID"].eq("SPX Index") & nav_levels["Level"].eq(150.0), "Level"] = 300.0
        detail = peer_detail_rows(
            hsbc,
            links,
            pd.DataFrame(),
            levels,
            nav_history=nav_levels,
            facts=facts,
        )
        peer = detail.iloc[1]
        self.assertAlmostEqual(float(peer["Last"]), 22.5)
        self.assertAlmostEqual(float(peer["Fund AUM (USD mn)"]), 30.0)
        self.assertAlmostEqual(float(peer["Share Class AUM (USD mn)"]), 4.0)
        self.assertAlmostEqual(float(peer["Tracking Error"]), 0.11)
        self.assertAlmostEqual(float(peer["NAV Tracking Error"]), 0.12)
        # A peer row no longer takes the peer's own fund_strategy text.
        self.assertTrue(pd.isna(peer["Strategy"]))
        self.assertEqual(peer["Benchmark"], "S&P 500")
        self.assertTrue(pd.isna(peer["1M Peer Avg Return %"]))
        self.assertAlmostEqual(float(peer["1M Return %"]), 10.0)
        self.assertAlmostEqual(float(peer["1M Bmk Return %"]), 50.0)
        self.assertNotIn("1M Bmk NAV Return %", detail.columns)
        self.assertAlmostEqual(float(detail.iloc[0]["Last"]), 50.0)
        self.assertAlmostEqual(float(detail.iloc[0]["1M Peer Avg Return %"]), 4.0)
        self.assertEqual(detail.iloc[0]["Benchmark"], "HSBC Index Name")
        self.assertAlmostEqual(float(detail.iloc[0]["1M Bmk Return %"]), 8.0)

    def test_long_name_is_a_label_and_the_typed_name_stays_the_group(self) -> None:
        book = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Long Name": "HSBC Fund One Accumulating",
                    "Share Class": "Acc",
                    "Primary": "Yes",
                    "Strategy": "Equity",
                },
                {
                    "Fund Name": "ONE",
                    "Long Name": "HSBC Fund One Distributing",
                    "Share Class": "Dist",
                    "Primary": "No",
                    "Strategy": "Equity",
                },
            ]
        )
        self.assertEqual(
            fund_menu_options(book, "Equity"),
            [("All", "All"), ("HSBC Fund One Accumulating", "ONE")],
        )
        self.assertEqual(flow_row_labels(book), {"ONE": "HSBC Fund One Accumulating"})
        links = pd.DataFrame(
            [
                {
                    "Fund Name": "ONE",
                    "Name": "Peer Short",
                    "Long Name": "Peer Long Name",
                    "Ticker": "P1 LN Equity",
                    "Primary ISIN": "IE00PEER000001",
                }
            ]
        )
        detail = peer_detail_rows(book, links, pd.DataFrame(), pd.DataFrame())
        self.assertEqual(detail["HSBC Fund"].tolist(), ["ONE", "ONE", "ONE"])
        self.assertEqual(detail["Fund Name"].iloc[0], "ONE")
        self.assertEqual(detail["Fund Name"].iloc[2], "Peer Long Name")

    def test_peer_links_for_another_strategy_are_not_requested(self) -> None:
        result = fetch_peer_links(fund_names=["NOT A BOOK FUND"])
        self.assertTrue(result.observations.empty)
        self.assertIn("No peer map row matches this Strategy.", result.errors)


if __name__ == "__main__":
    unittest.main()
