"""Fund benchmark and taxonomy frames. No Bloomberg call."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread.book_view import (  # noqa: E402
    absolute_quote_spread,
    percent_quote_spread,
    periods_within,
    preferred_long_name,
)
from etf_spread.config import isin_book_frame  # noqa: E402


class FundComparisonTests(unittest.TestCase):
    def test_crossed_quote_stays_blank(self):
        spread = absolute_quote_spread(pd.Series([11.0]), pd.Series([10.0]))
        self.assertTrue(pd.isna(spread.iloc[0]))
        percent = percent_quote_spread(spread, pd.Series([10.0]))
        self.assertTrue(pd.isna(percent.iloc[0]))

    def test_percent_spread_is_absolute_over_mid(self):
        percent = percent_quote_spread(pd.Series([1.0]), pd.Series([100.0]))
        self.assertAlmostEqual(float(percent.iloc[0]), 1.0)
        quoted = absolute_quote_spread(pd.Series([10.0]), pd.Series([10.3]))
        self.assertAlmostEqual(float(quoted.iloc[0]), 0.3)
        blank = percent_quote_spread(pd.Series([1.0]), pd.Series([0.0]))
        self.assertTrue(pd.isna(blank.iloc[0]))

    def test_isin_book_paste_shape(self):
        book = isin_book_frame()
        self.assertEqual(
            list(book.columns),
            ["Fund Name", "ISIN", "Ticker", "Order", "Strategy"],
        )
        self.assertFalse(book["Fund Name"].astype(str).str.contains("SAMPLE").any())
        self.assertFalse(book["ISIN"].astype(str).str.contains("SAMPLE").any())

    def test_table_follows_numeric_order(self):
        from etf_spread.book_view import book_display

        frame = pd.DataFrame(
            {
                "Fund Name": ["Later", "Earlier"],
                "List": ["Book", "Book"],
                "Order": ["10", "2"],
                "Share Class": ["b", "a"],
            }
        )
        shown = book_display(frame, None)
        self.assertEqual(list(shown["Fund Name"]), ["Earlier", "Later"])
        self.assertNotIn("Order", shown.columns)

    def test_average_spread_percent_uses_each_days_mid(self):
        from etf_spread.book_view import history_averages

        history = pd.DataFrame(
            {
                "ID": ["A", "A"],
                "DATE": ["2026-05-01", "2026-05-05"],
                "Bid": [10.0, 20.0],
                "Ask": [11.0, 22.0],
                "Mid": [100.0, 200.0],
                "Spread": [999.0, 999.0],
                "Percent Spread": [999.0, 999.0],
            }
        )
        result = history_averages(history, "2026-05-05")
        self.assertNotIn("1M Avg Spread", result.columns)
        self.assertAlmostEqual(float(result["1M Avg Spread %"].iloc[0]), 1.0)

    def test_custom_period_average_uses_the_two_dates(self):
        from etf_spread.book_view import history_averages

        history = pd.DataFrame(
            {
                "ID": ["A", "A"],
                "DATE": ["2026-05-01", "2026-05-05"],
                "Bid": [10.0, 20.0],
                "Ask": [11.0, 22.0],
                "Mid": [100.0, 200.0],
            }
        )
        result = history_averages(
            history, "2026-05-05", custom_start="2026-05-01", custom_end="2026-05-05"
        )
        self.assertNotIn("Custom Avg Spread", result.columns)
        self.assertAlmostEqual(float(result["Custom Avg Spread %"].iloc[0]), 1.0)

    def test_custom_period_chart_filters_to_the_bounds(self):
        from etf_spread.book_view import share_class_chart

        history = pd.DataFrame(
            {
                "ID": ["A", "A", "A"],
                "DATE": ["2026-04-30", "2026-05-01", "2026-05-05"],
                "Bid": [10.0, 11.0, 12.0],
                "Ask": [10.2, 11.2, 12.2],
                "Mid": [100.0, 100.0, 100.0],
            }
        )
        chart = share_class_chart(
            history,
            "A",
            "Custom",
            "2026-05-05",
            custom_start="2026-05-01",
            custom_end="2026-05-05",
        )
        self.assertEqual(
            [str(value.date()) for value in pd.to_datetime(chart["DATE"])],
            ["2026-05-01", "2026-05-04", "2026-05-05"],
        )

    def test_share_class_chart_uses_london_sessions(self):
        from etf_spread.book_view import share_class_chart

        history = pd.DataFrame(
            {
                "ID": ["HSAX LN Equity", "HSAX LN Equity", "HSAX LN Equity", "OTHER LN Equity", "HSAX LN Equity"],
                "DATE": ["2026-05-02", "2026-03-31", None, "2026-04-30", "2026-04-30"],
                "Bid": [11.0, None, 8.0, 1.0, 20.0],
                "Ask": [12.0, None, 9.0, 2.0, 22.0],
                "Mid": [100.0, None, 100.0, 10.0, 200.0],
            }
        )
        result = share_class_chart(history, "hsax ln equity", "1M", "2026-05-01")
        dates = set(pd.to_datetime(result["DATE"]).dt.strftime("%Y-%m-%d"))
        self.assertNotIn("2026-03-31", dates)
        self.assertNotIn("2026-05-02", dates)
        self.assertNotIn("2026-05-05", dates)
        self.assertIn("2026-04-01", dates)
        self.assertIn("2026-04-30", dates)
        self.assertIn("2026-05-01", dates)
        april_first = result.loc[pd.to_datetime(result["DATE"]).dt.strftime("%Y-%m-%d").eq("2026-04-01")]
        self.assertTrue(pd.isna(april_first["Spread"].iloc[0]))
        april_thirty = result.loc[pd.to_datetime(result["DATE"]).dt.strftime("%Y-%m-%d").eq("2026-04-30")]
        self.assertAlmostEqual(float(april_thirty["Spread"].iloc[0]), 2.0)
        self.assertAlmostEqual(float(april_thirty["Percent Spread"].iloc[0]), 1.0)
        self.assertTrue(share_class_chart(history, "", "1M", "2026-05-05").empty)
        self.assertTrue(share_class_chart(history, "MISSING LN Equity", "1M", "2026-05-05").empty)

    def test_end_date_is_the_previous_weekday(self):
        from etf_spread.book_view import last_completed_london_day

        self.assertEqual(
            str(last_completed_london_day("2026-05-05").date()),
            "2026-05-04",
        )

    def test_one_row_per_isin_keeps_a_quoted_listing(self):
        from etf_spread.data import keep_primary_listing

        frame = pd.DataFrame(
            [
                {
                    "Fund Name": "Example ETF",
                    "ISIN": "IE00B0000001",
                    "Bid": 10.0,
                    "Ask": 10.2,
                    "Ticker": "GY",
                },
                {
                    "Fund Name": "Example ETF",
                    "ISIN": "IE00B0000001",
                    "Bid": 10.0,
                    "Ask": 10.1,
                    "Ticker": "LN",
                },
            ]
        )
        chosen = keep_primary_listing(frame)
        self.assertEqual(len(chosen), 1)
        self.assertEqual(list(chosen["Ticker"]), ["LN"])

    def test_typed_ticker_beats_the_other_listing(self):
        from etf_spread.data import keep_primary_listing

        frame = pd.DataFrame(
            [
                {
                    "Fund Name": "Example ETF",
                    "ISIN": "IE00B0000001",
                    "Bid": 9.0,
                    "Ask": 9.2,
                    "Currency": "GBP",
                    "Ticker": "HSAXGBP LN Equity",
                },
                {
                    "Fund Name": "Example ETF",
                    "ISIN": "IE00B0000001",
                    "Bid": 10.0,
                    "Ask": 10.1,
                    "Currency": "USD",
                    "Ticker": "HSAX LN Equity",
                },
            ]
        )
        book = pd.DataFrame(
            [
                {
                    "Fund Name": "Example ETF",
                    "ISIN": "IE00B0000001",
                    "Ticker": "HSAX LN Equity",
                }
            ]
        )
        chosen = keep_primary_listing(frame, book)
        self.assertEqual(list(chosen["Ticker"]), ["HSAX LN Equity"])
        self.assertEqual(list(chosen["Currency"]), ["USD"])

    def test_only_typed_share_classes_reach_the_table(self):
        from etf_spread.data import SHARE_CLASS_COLUMNS, project_onto_typed_book

        def row(fund, isin, ticker, strategy, **extra):
            record = {column: pd.NA for column in SHARE_CLASS_COLUMNS}
            record.update(
                {
                    "Fund Name": fund,
                    "List": "Book",
                    "ISIN": isin,
                    "Ticker": ticker,
                    "Strategy": strategy,
                }
            )
            record.update(extra)
            return record

        linked = pd.DataFrame(
            [
                row("FUND ONE", "IE00B0000001", "TYPED LN Equity", "Equity", Bid=1.0, Ask=1.1),
                row("FUND ONE", "IE00B0000009", "OTHER LN Equity", "Equity", Bid=2.0, Ask=2.1),
                row("FUND TWO", "IE00B0000002", "TWO LN Equity", "Fixed Income", Bid=3.0, Ask=3.1),
            ]
        )
        book = pd.DataFrame(
            [
                {"Fund Name": "FUND TWO", "ISIN": "IE00B0000002", "Ticker": "TWO LN Equity", "Order": 1, "Strategy": "Fixed Income"},
                {"Fund Name": "FUND ONE", "ISIN": "IE00B0000001", "Ticker": "TYPED LN Equity", "Order": 2, "Strategy": "Equity"},
            ]
        )
        projected, notes = project_onto_typed_book(linked, book)
        self.assertEqual(notes, [])
        self.assertEqual(projected["ISIN"].tolist(), ["IE00B0000002", "IE00B0000001"])
        self.assertEqual(projected["Ticker"].tolist(), ["TWO LN Equity", "TYPED LN Equity"])
        self.assertEqual(projected["Order"].tolist(), [1, 2])
        self.assertEqual(projected["Strategy"].tolist(), ["Fixed Income", "Equity"])
        self.assertNotIn("IE00B0000009", projected["ISIN"].tolist())

    def test_a_typed_line_missing_from_the_linked_set_is_kept(self):
        from etf_spread.data import SHARE_CLASS_COLUMNS, project_onto_typed_book

        linked = pd.DataFrame(
            [
                {
                    "Fund Name": "FUND ONE",
                    "List": "Book",
                    "ISIN": "IE00B0000009",
                    "Ticker": "OTHER LN Equity",
                    "Strategy": "Equity",
                    "Bid": 2.0,
                    "Ask": 2.1,
                    "Primary": "Yes",
                }
            ]
        )
        book = pd.DataFrame(
            [
                {
                    "Fund Name": "FUND ONE",
                    "ISIN": "IE00B0000001",
                    "Ticker": "TYPED LN Equity",
                    "Order": 1,
                    "Strategy": "Equity",
                }
            ]
        )
        projected, notes = project_onto_typed_book(linked, book, {"FUND ONE": "SPX Index"})
        self.assertEqual(len(projected), 1)
        self.assertEqual(projected.iloc[0]["ISIN"], "IE00B0000001")
        self.assertEqual(projected.iloc[0]["Ticker"], "TYPED LN Equity")
        self.assertEqual(projected.iloc[0]["Strategy"], "Equity")
        self.assertEqual(projected.iloc[0]["Benchmark Index"], "SPX Index")
        self.assertTrue(pd.isna(projected.iloc[0]["Bid"]))
        self.assertTrue(notes)
        self.assertEqual(list(projected.columns), [*SHARE_CLASS_COLUMNS, "Order"])

    def test_a_different_listing_loses_its_quotes(self):
        from etf_spread.data import SHARE_CLASS_COLUMNS, project_onto_typed_book

        record = {column: pd.NA for column in SHARE_CLASS_COLUMNS}
        record.update(
            {
                "Fund Name": "FUND ONE",
                "List": "Book",
                "ISIN": "IE00B0000001",
                "Ticker": "OTHER LN Equity",
                "Bid": 9.0,
                "Ask": 9.2,
                "Last": 9.1,
                "Percent Spread": 0.2,
            }
        )
        book = pd.DataFrame(
            [
                {
                    "Fund Name": "FUND ONE",
                    "ISIN": "IE00B0000001",
                    "Ticker": "TYPED LN Equity",
                    "Order": 1,
                    "Strategy": "Equity",
                }
            ]
        )
        projected, _notes = project_onto_typed_book(pd.DataFrame([record]), book)
        self.assertEqual(projected.iloc[0]["Ticker"], "TYPED LN Equity")
        self.assertTrue(pd.isna(projected.iloc[0]["Bid"]))
        self.assertTrue(pd.isna(projected.iloc[0]["Last"]))
        self.assertTrue(pd.isna(projected.iloc[0]["Percent Spread"]))

    def test_strategy_is_not_a_table_column(self):
        from etf_spread.book_view import book_display, display_columns
        from etf_spread.metrics import visible_book_columns

        self.assertNotIn("Strategy", display_columns())
        directory = pd.DataFrame(
            [
                {
                    "Fund Name": "FUND ONE",
                    "List": "Book",
                    "ISIN": "IE00B0000001",
                    "Ticker": "TYPED LN Equity",
                    "Order": 1,
                    "Strategy": "Equity",
                    "Primary": "Yes",
                }
            ]
        )
        shown = book_display(directory, pd.DataFrame())
        drawn = visible_book_columns(["1M"], True, True, False)
        self.assertNotIn("Strategy", drawn)
        self.assertIn("Benchmark", drawn)
        self.assertIn("Primary", drawn)
        # The top dropdown and the fund menu still read it from the hidden key.
        self.assertEqual(shown["Strategy"].tolist(), ["Equity"])

    def test_shorter_history_range_uses_weekdays_and_limits_periods(self):
        from etf_spread.data import history_request_bounds

        as_of = pd.Timestamp("2026-10-29")
        self.assertEqual(history_request_bounds("5Y", as_of), (None, None))
        start, end = history_request_bounds("1Y", as_of)
        self.assertEqual(start, pd.Timestamp("2025-10-29"))
        self.assertEqual(end, pd.Timestamp("2026-10-29"))
        self.assertEqual(periods_within("1Y"), ["1M", "3M", "6M", "YTD", "1Y"])
        self.assertEqual(periods_within("6M"), ["1M", "3M", "6M"])
        self.assertEqual(periods_within("YTD"), ["YTD"])
        self.assertEqual(periods_within("5Y")[-1], "5Y")

    def test_benchmark_ticker_becomes_an_index_id(self):
        from etf_spread.data import benchmark_index_id

        self.assertEqual(benchmark_index_id("SPX"), "SPX Index")
        self.assertEqual(benchmark_index_id("SPX Index"), "SPX Index")
        self.assertEqual(benchmark_index_id(""), "")
        self.assertEqual(benchmark_index_id(None), "")
        self.assertEqual(benchmark_index_id("N/A"), "")
        self.assertEqual(benchmark_index_id("N/A - suspended"), "")
        self.assertEqual(benchmark_index_id("NA US Equity"), "NA US Equity Index")

    def test_shown_name_prefers_long_comp_name(self):
        from etf_spread.data import _id_and_name

        self.assertEqual(preferred_long_name("HSBC S&P 500 UCITS ETF", "HSBC S&P"), "HSBC S&P 500 UCITS ETF")
        self.assertEqual(preferred_long_name("", "HSBC S&P"), "HSBC S&P")
        self.assertEqual(preferred_long_name("N/A", "HSBC S&P"), "HSBC S&P")
        self.assertEqual(preferred_long_name("NA US Equity", "Short"), "NA US Equity")
        frame = pd.DataFrame(
            {
                "ID": ["SPX Index"],
                "Name": ["S&P 500"],
                "Long Name": ["S&P 500 Index"],
            }
        )
        self.assertEqual(_id_and_name(frame), {"SPX Index": "S&P 500 Index"})
        blank = frame.copy()
        blank["Long Name"] = "N/A"
        self.assertEqual(_id_and_name(blank), {"SPX Index": "S&P 500"})

    def test_benchmark_label_uses_fund_benchmark_prim_index(self):
        from etf_spread import data

        table = pd.DataFrame(
            [
                {"Benchmark": "UNDX", "Benchmark Index": "SPX Index"},
                {"Benchmark": "UNDX", "Benchmark Index": ""},
            ]
        )
        seen = {}

        class _Request:
            def __init__(self, universe, items, with_params=None):
                seen["universe"] = list(universe)
                seen["items"] = set(items)

        class _Bql:
            Request = _Request

        class _Item:
            def __getitem__(self, _key):
                return self

            def __call__(self):
                return self

        class _Data:
            def __getattr__(self, _name):
                return _Item()

        class _Bq:
            data = _Data()

        def _waves(_bq, labeled):
            return [("benchmark_1", object())]

        original = (data.bql, data._execute_waves, data._is_response, data._combine_items)
        data.bql = _Bql()
        data._execute_waves = _waves
        data._is_response = lambda _response: True
        data._combine_items = lambda _response: pd.DataFrame(
            {
                "ID": ["SPX Index"],
                "Name": ["S&P 500"],
                "Long Name": ["S&P 500 Index"],
            }
        )
        try:
            named = data._apply_benchmark_names(_Bq(), table, [], None)
        finally:
            data.bql, data._execute_waves, data._is_response, data._combine_items = original
        self.assertEqual(seen["universe"], ["SPX Index"])
        self.assertIn("Long Name", seen["items"])
        self.assertEqual(list(named["Benchmark"]), ["S&P 500 Index", ""])
        self.assertEqual(named["Benchmark Index"].iloc[0], "SPX Index")

    def test_class_asset_currency_stays_an_iso_code(self):
        from etf_spread.data import iso_currency_code

        self.assertEqual(iso_currency_code("usd"), "USD")
        self.assertEqual(iso_currency_code("EUR"), "EUR")
        self.assertEqual(iso_currency_code(""), "")

    def test_fund_aum_is_reported_in_millions(self):
        from etf_spread.data import usd_millions

        self.assertAlmostEqual(usd_millions(2_500_000), 2.5)
        self.assertTrue(pd.isna(usd_millions(None)))

    def test_share_class_aum_converts_only_non_usd(self):
        from etf_spread.data import fx_to_usd_millions

        self.assertAlmostEqual(fx_to_usd_millions(12.5, "USD", {}), 12.5)
        self.assertAlmostEqual(
            fx_to_usd_millions(10.0, "EUR", {"EUR": ("multiply", 1.1)}),
            11.0,
        )
        self.assertAlmostEqual(
            fx_to_usd_millions(150.0, "JPY", {"JPY": ("divide", 150.0)}),
            1.0,
        )
        self.assertTrue(pd.isna(fx_to_usd_millions(10.0, "EUR", {})))

    def test_fund_aum_uses_the_usd_total_not_the_spot_conversion(self):
        from etf_spread.data import fund_aum_usd_millions

        frame = pd.DataFrame({"FundAUM": [2_500_000, None]})
        millions = [
            fund_aum_usd_millions(amount, "USD", {})
            for amount in frame["FundAUM"]
        ]
        self.assertAlmostEqual(float(millions[0]), 2.5)
        self.assertTrue(pd.isna(millions[1]))
        self.assertAlmostEqual(
            fund_aum_usd_millions(1_000_000, "EUR", {"EUR": ("multiply", 1.1)}),
            1.1,
        )

    def test_fund_total_stays_per_row_after_usd_conversion(self):
        from etf_spread.data import fund_total_usd_millions

        values = pd.Series([2_500_000, 2_500_000, None], index=[4, 9, 10])
        millions = fund_total_usd_millions(values)
        self.assertEqual(list(millions.index), [4, 9, 10])
        self.assertAlmostEqual(float(millions.loc[4]), 2.5)
        self.assertAlmostEqual(float(millions.loc[9]), 2.5)
        self.assertTrue(pd.isna(millions.loc[10]))

    def test_fund_total_is_copied_not_added_across_share_classes(self):
        from etf_spread.data import stamp_fund_totals

        table = pd.DataFrame(
            {
                "Fund Name": ["HS", "HS"],
                "Ticker": ["HSBC LN Equity", "HSBC2 LN Equity"],
                "Primary": ["No", "Yes"],
            }
        )
        amounts = {"HSBC LN EQUITY": 9_000_000, "HSBC2 LN EQUITY": 2_500_000}
        stamped = stamp_fund_totals(table, amounts)
        self.assertAlmostEqual(float(stamped.iloc[0]), 2.5)
        self.assertAlmostEqual(float(stamped.iloc[1]), 2.5)

    def test_fund_aum_is_the_sum_of_class_aum(self):
        from etf_spread.data import fund_aum_from_class

        frame = pd.DataFrame(
            {
                "Fund Name": ["One", "One", "Two"],
                "Share Class AUM (USD mn)": [1.5, 2.5, 4.0],
            }
        )
        totals = fund_aum_from_class(frame)
        self.assertAlmostEqual(float(totals.iloc[0]), 4.0)
        self.assertAlmostEqual(float(totals.iloc[1]), 4.0)
        self.assertAlmostEqual(float(totals.iloc[2]), 4.0)

    def test_period_windows_end_on_the_latest_quote_date(self):
        from etf_spread.book_view import period_window_html, quote_as_of

        history = pd.DataFrame(
            {
                "ID": ["A", "A"],
                "DATE": ["2026-10-20", "2026-10-21"],
            }
        )
        as_of = quote_as_of(history)
        self.assertEqual(str(as_of.date()), "2026-10-21")
        note = period_window_html(as_of)
        self.assertIn("Data as of", note)
        self.assertIn("2026-10-21", note)
        self.assertIn("1M: 2026-09-21 to 2026-10-21", note)
        self.assertIn("YTD: 2026-01-01 to 2026-10-21", note)

    def test_weekday_schedule_carries_a_holiday_gap_forward(self):
        from etf_spread.book_view import carry_london_quotes, london_trading_days

        days = london_trading_days("2026-05-01", "2026-05-06")
        self.assertIn(pd.Timestamp("2026-05-04"), days)
        self.assertIn(pd.Timestamp("2026-05-06"), days)
        carried = carry_london_quotes(
            pd.DataFrame(
                {
                    "DATE": ["2026-05-01", "2026-05-05"],
                    "Spread": [2.0, 4.0],
                    "Percent Spread": [1.0, 3.0],
                }
            ),
            "2026-05-06",
        )
        self.assertIn(pd.Timestamp("2026-05-04"), carried.index)
        self.assertAlmostEqual(float(carried.loc[pd.Timestamp("2026-05-04"), "Spread"]), 2.0)
        self.assertAlmostEqual(float(carried.loc[pd.Timestamp("2026-05-06"), "Spread"]), 4.0)

    def test_a_stored_percent_without_bid_rebuilds_the_absolute_average(self):
        from etf_spread.book_view import history_averages

        history = pd.DataFrame(
            {
                "ID": ["A", "A"],
                "DATE": ["2026-05-01", "2026-05-05"],
                "Mid": [100.0, 200.0],
                "Percent Spread": [1.0, 1.0],
            }
        )
        result = history_averages(history, "2026-05-05")
        self.assertNotIn("1M Avg Spread", result.columns)
        self.assertAlmostEqual(float(result["1M Avg Spread %"].iloc[0]), 1.0)

    def test_blank_mid_uses_the_bid_ask_average(self):
        from etf_spread.book_view import history_averages

        history = pd.DataFrame(
            {
                "ID": ["A", "A"],
                "DATE": ["2026-05-01", "2026-05-05"],
                "Bid": [10.0, 20.0],
                "Ask": [12.0, 22.0],
                "Mid": [pd.NA, pd.NA],
            }
        )
        result = history_averages(history, "2026-05-05")
        self.assertNotIn("1M Avg Spread", result.columns)
        expected = ((2.0 / 11.0) + (2.0 / 11.0) + (2.0 / 21.0)) / 3.0 * 100.0
        self.assertAlmostEqual(float(result["1M Avg Spread %"].iloc[0]), expected)


if __name__ == "__main__":
    unittest.main()
