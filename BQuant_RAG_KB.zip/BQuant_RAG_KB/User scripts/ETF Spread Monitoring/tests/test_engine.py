"""Placeholder spread cache and period windows. No Bloomberg call."""

from __future__ import annotations

import json
import re
import sys
import unittest
from datetime import date
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread.config import (  # noqa: E402
    OBSERVATION_COLUMNS,
    PERIOD_KEYS,
    enabled_share_classes,
)
from etf_spread.data import (  # noqa: E402
    company_id_from_frame,
    empty_observations,
    expense_ratio_number,
    fetch_share_class_directory,
    fetch_spread_payload,
    representative_seeds,
)
from etf_spread.engine import (  # noqa: E402
    build_view,
    prepare_observations,
    quote_spread_bps,
)


REFRESH = date(2026, 10, 22)
IDS = [row.share_class_id for row in enabled_share_classes()]


def _payload(today=REFRESH, **kwargs):
    return fetch_spread_payload(today=today, **kwargs)


class SpreadCacheTests(unittest.TestCase):
    def test_repeat_fetch_matches(self):
        first = _payload()
        second = _payload()
        pd.testing.assert_frame_equal(first.observations, second.observations)
        self.assertEqual(first.as_of, second.as_of)
        self.assertEqual(first.errors, [])

    def test_disabled_share_class_is_omitted(self):
        payload = _payload()
        self.assertNotIn("SAMPLE-OFF", set(payload.observations["Share Class ID"]))
        self.assertEqual(
            set(payload.observations.loc[
                payload.observations["Series"].eq("Book"), "Share Class ID"
            ]),
            {"SAMPLE-A", "SAMPLE-B", "SAMPLE-C"},
        )

    def test_saturday_as_of_is_the_previous_weekday(self):
        payload = _payload(today=date(2026, 10, 24))
        self.assertEqual(payload.as_of, pd.Timestamp("2026-10-23"))
        weekdays = pd.to_datetime(payload.observations["DATE"]).dt.dayofweek
        self.assertTrue((weekdays < 5).all())

    def test_placeholder_spread_round_trips(self):
        prepared = prepare_observations(_payload().observations)
        again = quote_spread_bps(prepared.frame["Bid"], prepared.frame["Ask"])
        pd.testing.assert_series_equal(
            prepared.frame["Spread"].reset_index(drop=True),
            again.reset_index(drop=True),
            check_names=False,
        )
        self.assertTrue((prepared.frame["Quote Status"] == "ok").all())
        self.assertTrue(prepared.frame["Spread"].notna().all())

    def test_bloomberg_sources_do_not_invent_rows(self):
        peer = _payload(peer_source_name="bloomberg")
        self.assertTrue(
            peer.observations.loc[peer.observations["Series"].eq("Book")].shape[0] > 0
        )
        self.assertTrue(
            peer.observations.loc[peer.observations["Series"].eq("Peer")].empty
        )
        self.assertTrue(any("peer" in error.lower() for error in peer.errors))

        book = _payload(book_source_name="bloomberg")
        self.assertTrue(
            book.observations.loc[book.observations["Series"].eq("Book")].empty
        )
        self.assertTrue(any("book" in error.lower() for error in book.errors))

    def test_unknown_source_is_rejected(self):
        with self.assertRaises(ValueError):
            _payload(book_source_name="guess")
        with self.assertRaises(ValueError):
            _payload(peer_source_name="guess")


class PeriodViewTests(unittest.TestCase):
    def setUp(self):
        self.observations = _payload().observations

    def _view(self, period, ids=None, start=None, end=None, show_peer=True):
        return build_view(
            self.observations,
            period,
            IDS if ids is None else ids,
            custom_start=start,
            custom_end=end,
            show_peer=show_peer,
        )

    def test_period_change_moves_table_and_chart_together(self):
        short = self._view("1M")
        long = self._view("1Y")
        self.assertEqual(short.notes, [])
        self.assertGreater(long.chart["DATE"].nunique(), short.chart["DATE"].nunique())
        self.assertEqual(short.chart["DATE"].max(), short.as_of)
        self.assertEqual(short.summary["Window End"].nunique(), 1)
        self.assertTrue((short.chart["DATE"] >= short.window_start).all())
        self.assertTrue((short.chart["DATE"] <= short.window_end).all())
        self.assertTrue((short.summary["Window Start"] == short.window_start).all())
        self.assertIn("Book", set(short.chart["Series"]))
        self.assertIn("Peer", set(short.chart["Series"]))

    def test_five_year_window_is_inside_the_cache(self):
        view = self._view("5Y")
        self.assertFalse(any("Loaded history starts" in note for note in view.notes))
        self.assertFalse(view.summary.empty)
        self.assertGreaterEqual(view.chart["DATE"].min(), view.window_start)

    def test_ytd_starts_on_1_january(self):
        view = self._view("YTD")
        self.assertEqual(
            view.window_start,
            pd.Timestamp(year=view.as_of.year, month=1, day=1),
        )

    def test_custom_weekend_is_empty_and_does_not_raise(self):
        view = self._view("Custom", start=date(2026, 10, 17), end=date(2026, 10, 18))
        self.assertTrue(view.summary.empty)
        self.assertTrue(view.chart.empty)
        self.assertTrue(any("No observations" in note for note in view.notes))

    def test_custom_before_cache_does_not_backfill(self):
        view = self._view("Custom", start=date(1990, 1, 1), end=date(1990, 6, 1))
        self.assertTrue(view.summary.empty)
        self.assertTrue(any("Loaded history starts" in note for note in view.notes))

    def test_custom_start_after_end(self):
        view = self._view("Custom", start=date(2026, 10, 10), end=date(2026, 10, 1))
        self.assertTrue(view.summary.empty)
        self.assertTrue(any("after" in note for note in view.notes))

    def test_custom_without_dates(self):
        view = self._view("Custom")
        self.assertTrue(any("needs a start" in note for note in view.notes))

    def test_unknown_period_and_empty_selection(self):
        unknown = self._view("2Y")
        self.assertTrue(any("Unknown period" in note for note in unknown.notes))
        empty = self._view("1Y", ids=[])
        self.assertTrue(any("Select at least one" in note for note in empty.notes))

    def test_one_share_class_keeps_its_own_peer_group(self):
        view = self._view("1Y", ids=["SAMPLE-C"])
        books = view.summary.loc[view.summary["Series"].eq("Book"), "Share Class ID"]
        peers = view.summary.loc[view.summary["Series"].eq("Peer"), "Peer Group ID"]
        self.assertEqual(set(books), {"SAMPLE-C"})
        self.assertEqual(set(peers), {"SAMPLE-PEER-2"})
        mixed = view.summary.loc[
            view.summary["Peer Group ID"].eq("SAMPLE-PEER-1")
            & view.summary["Series"].eq("Peer")
        ]
        self.assertTrue(mixed.empty)

    def test_mixed_currency_peer_is_labeled(self):
        view = self._view("1Y")
        peer = view.summary.loc[
            view.summary["Series"].eq("Peer")
            & view.summary["Peer Group ID"].eq("SAMPLE-PEER-1")
        ].iloc[0]
        single = view.summary.loc[
            view.summary["Series"].eq("Peer")
            & view.summary["Peer Group ID"].eq("SAMPLE-PEER-2")
        ].iloc[0]
        self.assertEqual(peer["Currency"], "Mixed")
        self.assertEqual(single["Currency"], "USD")

    def test_hiding_peer_removes_it_from_table_and_chart(self):
        view = self._view("1Y", show_peer=False)
        self.assertNotIn("Peer", set(view.summary["Series"]))
        self.assertNotIn("Peer", set(view.chart["Series"]))
        self.assertFalse(any("No peer rows" in note for note in view.notes))

    def test_view_does_not_mutate_the_cache(self):
        before = self.observations.copy()
        self._view("1M")
        pd.testing.assert_frame_equal(before, self.observations)


class QuoteGuardTests(unittest.TestCase):
    def _row(self, **overrides):
        row = {
            "Share Class ID": "SAMPLE-A",
            "Peer Group ID": "SAMPLE-PEER-1",
            "DATE": "2026-10-22",
            "Bid": 99.0,
            "Ask": 101.0,
            "Source": "placeholder",
            "Series": "Book",
        }
        row.update(overrides)
        return row

    def test_crossed_and_non_numeric_stay_blank(self):
        frame = pd.DataFrame(
            [
                self._row(Bid=11.0, Ask=10.0),
                self._row(DATE="2026-10-21", Bid=float("inf"), Ask=10.0),
                self._row(DATE="2026-10-20", Bid="N/A", Ask=10.0),
                self._row(DATE="2026-10-19", Bid=10.0, Ask=10.0),
                self._row(DATE=None, Bid=10.0, Ask=11.0),
                self._row(**{"Share Class ID": "", "DATE": "2026-10-16", "Bid": 10.0, "Ask": 11.0}),
            ]
        )
        prepared = prepare_observations(frame)
        status = dict(zip(prepared.frame["DATE"].dt.strftime("%Y-%m-%d"), prepared.frame["Quote Status"]))
        spread = dict(zip(prepared.frame["DATE"].dt.strftime("%Y-%m-%d"), prepared.frame["Spread"]))
        self.assertEqual(status["2026-10-22"], "crossed")
        self.assertTrue(pd.isna(spread["2026-10-22"]))
        self.assertEqual(status["2026-10-21"], "missing")
        self.assertTrue(pd.isna(spread["2026-10-21"]))
        self.assertEqual(status["2026-10-20"], "missing")
        self.assertEqual(status["2026-10-19"], "ok")
        self.assertEqual(spread["2026-10-19"], 0.0)
        self.assertGreaterEqual(prepared.dropped_rows, 2)
        self.assertNotIn("2026-10-16", status)

    def test_duplicate_unsorted_rows_keep_the_last(self):
        frame = pd.DataFrame(
            [
                self._row(DATE="2026-10-22", Bid=10.0, Ask=12.0),
                self._row(DATE="2026-10-20", Bid=10.0, Ask=11.0),
                self._row(DATE="2026-10-22", Bid=20.0, Ask=22.0),
            ]
        )
        prepared = prepare_observations(frame)
        self.assertTrue(prepared.frame["DATE"].is_monotonic_increasing)
        last = prepared.frame.loc[prepared.frame["DATE"].eq(pd.Timestamp("2026-10-22"))]
        self.assertEqual(len(last), 1)
        self.assertAlmostEqual(float(last["Bid"].iloc[0]), 20.0)

    def test_missing_columns_fail_closed(self):
        with self.assertRaises(KeyError):
            prepare_observations(pd.DataFrame({"DATE": ["2026-10-22"]}))

    def test_empty_cache_has_the_contract_columns(self):
        self.assertEqual(tuple(empty_observations().columns), OBSERVATION_COLUMNS)
        view = build_view(empty_observations(), "1Y", IDS)
        self.assertTrue(view.summary.empty)
        self.assertTrue(any("No observations" in note for note in view.notes))


class PackageBoundaryTests(unittest.TestCase):
    def test_period_keys_match_the_route_card(self):
        self.assertEqual(
            PERIOD_KEYS,
            ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y", "Custom"),
        )
        card = (WORKSPACE / "RAG KB" / "27-etf-spread-monitor.md").read_text(encoding="utf-8")
        self.assertIn(
            'PERIOD_KEYS = ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y", "Custom")',
            card,
        )

    def test_project_requests_only_the_helpdesk_share_class_items(self):
        allowed_data = {
            "crncy",
            "etf_undl_index_ticker",
            "exch_code",
            "fund_benchmark",
            "fund_benchmark_prim",
            "fund_comp_name",
            "actively_managed",
            "cur_mkt_cap",
            "fund_asset_class_focus",
            "fund_expense_ratio",
            "fund_flow",
            "fund_geo_focus",
            "fund_industry_focus",
            "fund_open_shr_class",
            "fund_strategy",
            "fund_class_assets",
            "fund_class_assets_crncy",
            "fund_total_assets",
            "fund_total_assets_crncy",
            "fund_typ",
            "id",
            "id_bb_company",
            "id_isin",
            "long_comp_name",
            "name",
            "px_ask",
            "px_bid",
            "px_last",
            "px_mid",
            "nav_tracking_error",
            "fund_net_asset_val",
            "tot_return_index_gross_dvds",
            "tracking_error",
        }
        allowed_universe = {"fundsuniv"}
        for path in PROJECT_ROOT.rglob("*"):
            if path.suffix.lower() not in {".py", ".ipynb", ".md"} or not path.is_file():
                continue
            text = path.read_text(encoding="utf-8")
            data_calls = set(re.findall(r"\bbq\.data\.([A-Za-z_]\w*)", text))
            universe_calls = set(re.findall(r"\bbq\.univ\.([A-Za-z_]\w*)", text))
            self.assertFalse(data_calls - allowed_data, msg=str(path))
            self.assertFalse(universe_calls - allowed_universe, msg=str(path))
            self.assertIsNone(
                re.search(r"^PARSER_VERSION\s*=", text, flags=re.MULTILINE),
                msg=str(path),
            )
        notebook = json.loads((PROJECT_ROOT / "MAIN.ipynb").read_text(encoding="utf-8"))
        source = "".join(notebook["cells"][0]["source"])
        self.assertIn("ETFSpreadMonitor", source)
        self.assertIn("display(app.render())", source)
        self.assertNotIn("load_on_start", source)


class ShareClassSeedTests(unittest.TestCase):
    def test_one_seed_per_fund_name(self):
        book = pd.DataFrame(
            [
                {"Fund Name": "Example Equity ETF", "ISIN": "ie00b0000001"},
                {"Fund Name": "Example Equity ETF", "ISIN": "IE00B0000002"},
                {"Fund Name": "Second Equity ETF", "ISIN": "IE00B0000003"},
            ]
        )
        self.assertEqual(
            representative_seeds(book),
            [
                ("Example Equity ETF", "IE00B0000001"),
                ("Second Equity ETF", "IE00B0000003"),
            ],
        )

    def test_blank_umbrella_id_is_not_a_universe(self):
        self.assertEqual(company_id_from_frame(pd.DataFrame()), "")
        self.assertEqual(
            company_id_from_frame(pd.DataFrame({"ID BB Company": [None]})),
            "",
        )
        self.assertEqual(
            company_id_from_frame(pd.DataFrame({"ID BB Company": [12345]})),
            "12345",
        )

    def test_missing_bql_does_not_raise(self):
        book = pd.DataFrame(
            [{"Fund Name": "Example Equity ETF", "ISIN": "IE00B0000001"}]
        )
        result = fetch_share_class_directory(book)
        self.assertTrue(result.observations.empty)
        self.assertTrue(any("bql is unavailable" in error for error in result.errors))

    def test_a_failed_pull_still_returns_the_typed_rows(self):
        from etf_spread import data

        class _Item:
            def __getitem__(self, _key):
                return self

            def __call__(self, *_args, **_kwargs):
                return self

        class _Data:
            def __getattr__(self, _name):
                return _Item()

        class _Bq:
            data = _Data()

        class _Service:
            def __call__(self):
                return _Bq()

        class _Request:
            def __init__(self, universe, items, with_params=None):
                self.universe = universe
                self.items = items

        class _Bql:
            Request = _Request

            def Service(self):
                return _Bq()

        book = pd.DataFrame(
            [
                {"Fund Name": "FUND TWO", "ISIN": "IE00B0000002", "Ticker": "TWO LN Equity", "Order": 2, "Strategy": "Fixed Income"},
                {"Fund Name": "FUND ONE", "ISIN": "IE00B0000001", "Ticker": "ONE LN Equity", "Order": 1, "Strategy": "Equity"},
            ]
        )
        original = (data.bql, data._execute_many, data._execute_waves)
        data.bql = _Bql()
        data._execute_many = lambda _bq, labeled: [(label, None) for label, _request in labeled]
        data._execute_waves = lambda _bq, labeled: [(label, None) for label, _request in labeled]
        try:
            result = fetch_share_class_directory(book)
        finally:
            data.bql, data._execute_many, data._execute_waves = original
        rows = result.observations
        self.assertEqual(rows["ISIN"].tolist(), ["IE00B0000002", "IE00B0000001"])
        self.assertEqual(rows["Ticker"].tolist(), ["TWO LN Equity", "ONE LN Equity"])
        self.assertEqual(rows["Strategy"].tolist(), ["Fixed Income", "Equity"])
        self.assertEqual(rows["Order"].tolist(), [2, 1])
        self.assertTrue(rows["Bid"].isna().all())
        self.assertTrue(result.errors)

    def test_expense_ratio_percent_point_stays_as_returned(self):
        self.assertEqual(expense_ratio_number(0.3), 0.3)
        self.assertTrue(pd.isna(expense_ratio_number("0.3%")))


if __name__ == "__main__":
    unittest.main()
