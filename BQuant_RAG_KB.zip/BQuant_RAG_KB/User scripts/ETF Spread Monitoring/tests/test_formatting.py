"""Display formatting: prices keep precision, spreads use 3 dp, other numbers use 2 dp."""

from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

sys.modules.setdefault("ipywidgets", types.ModuleType("ipywidgets"))

from etf_spread.app import (  # noqa: E402
    DISPLAY_NAMES,
    _environment_markup,
    _fmt,
    _format_frame,
    _phase_markup,
    _row_choice_expr,
)


class DisplayFormattingTests(unittest.TestCase):
    def test_non_price_numbers_use_two_decimals(self):
        self.assertEqual(_fmt("Fund AUM (USD mn)", 1234.5678), "1234.57")
        self.assertEqual(_fmt("Share Class AUM (USD mn)", 12.346), "12.35")
        self.assertEqual(_fmt("Spread", 0.1234), "0.123")
        self.assertEqual(_fmt("Latest Spread", 0.1234), "0.123")
        self.assertEqual(_fmt("Spread %", 0.9876), "0.988")
        self.assertEqual(_fmt("Latest Spread %", 0.9876), "0.988")
        self.assertEqual(_fmt("1M Avg Spread", 0.4567), "0.457")
        self.assertEqual(_fmt("1M Peer Avg Spread %", 0.1234), "0.123")
        self.assertEqual(_fmt("Tracking Error", 1.234), "1.23")
        self.assertEqual(_fmt("NAV Tracking Error", 2.346), "2.35")

    def test_environment_line_is_red_while_processing_and_green_while_idle(self):
        processing = _environment_markup("Processing")
        idle = _environment_markup("Idle")
        self.assertIn("color:#c62828", processing)
        self.assertIn("Environment: Processing", processing)
        self.assertIn("color:#1b7f37", idle)
        self.assertIn("Environment: Idle", idle)

    def test_first_status_word_uses_red_green_or_the_original_color(self):
        self.assertIn("color:#c62828", _phase_markup("Idle"))
        self.assertIn("color:#c62828", _phase_markup("Please Click Refresh"))
        self.assertIn("color:#1b7f37", _phase_markup("Refreshed"))
        loading = _phase_markup("Loading")
        self.assertNotIn("color:", loading)
        self.assertIn(">Loading<", loading)

    def test_tracking_error_headers_say_percent(self):
        self.assertEqual(DISPLAY_NAMES["Absolute Spread"], "Latest Spread")
        self.assertEqual(DISPLAY_NAMES["Percent Spread"], "Latest Spread %")
        self.assertEqual(DISPLAY_NAMES["Tracking Error"], "1Y Tracking Error (%)")
        self.assertEqual(
            DISPLAY_NAMES["NAV Tracking Error"], "1Y NAV Tracking Error (%)"
        )

    def test_price_columns_keep_quote_precision(self):
        self.assertEqual(_fmt("Bid", 100.1234), "100.123")
        self.assertEqual(_fmt("PX_LAST", 1.234567), "1.23457")

    def test_text_and_blank_cells_are_unchanged(self):
        self.assertEqual(_fmt("Currency", "USD"), "USD")
        self.assertEqual(_fmt("Fund AUM (USD mn)", float("nan")), "")
        formatted = _format_frame(
            pd.DataFrame({"Fund AUM (USD mn)": [1234.5678], "Bid": [100.1234]})
        )
        self.assertEqual(formatted.iloc[0]["Fund AUM (USD mn)"], "1234.57")
        self.assertEqual(formatted.iloc[0]["Bid"], "100.123")

    def test_hsbc_row_expression_is_bold_only_when_a_row_is_marked(self):
        source = _row_choice_expr([True, False], "bold 12px sans-serif", "12px sans-serif")
        self.assertIn("cell.row < 1", source)
        self.assertIn("bold 12px sans-serif", source)
        self.assertIsNone(_row_choice_expr([False, False], "bold", "plain"))
        self.assertIsNone(_row_choice_expr([], "bold", "plain"))


if __name__ == "__main__":
    unittest.main()
