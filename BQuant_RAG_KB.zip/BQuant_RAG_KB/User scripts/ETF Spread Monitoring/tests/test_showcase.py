"""Exchange taxonomy paths. No Bloomberg call."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread.data import fetch_etf_showcase, fetch_showcase_flows  # noqa: E402


class ShowcaseFetchTests(unittest.TestCase):
    def test_unknown_exchange_and_missing_bql_do_not_raise(self):
        rejected = fetch_etf_showcase("XX", "JPY")
        self.assertTrue(rejected.observations.empty)
        self.assertTrue(any("Unsupported exchange" in note for note in rejected.errors))
        missing = fetch_etf_showcase("JP", "JPY")
        self.assertTrue(missing.observations.empty)
        self.assertTrue(any("bql is unavailable" in note for note in missing.errors))
        flows = fetch_showcase_flows("JP", "JPY", "2026-01-01", "2026-10-01", False)
        self.assertTrue(flows.observations.empty)
        self.assertTrue(any("bql is unavailable" in note for note in flows.errors))
