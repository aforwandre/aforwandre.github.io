"""Daily history cache: contract, gaps, merge, and the write refusal rules."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from unittest import mock
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread import cache  # noqa: E402


def _quotes(identifier: str, dates, value: float = 10.0) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "ID": [identifier] * len(dates),
            "DATE": [pd.Timestamp(day) for day in dates],
            "Bid": [value] * len(dates),
            "Ask": [value + 0.1] * len(dates),
            "Mid": [value + 0.05] * len(dates),
        }
    )


class ManifestTests(unittest.TestCase):
    def test_a_missing_folder_reads_as_no_cache_and_is_not_created(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder) / "project"
            root.mkdir()
            self.assertTrue(cache.read_series("quotes", root).empty)
            self.assertFalse((root / cache.CACHE_DIR_NAME).exists())

    def test_a_contract_or_generation_change_is_ignored(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            frame = _quotes("FUND LN Equity", ["2026-10-01", "2026-10-02"])
            cache.save("quotes", frame, "2026-10-05", root)
            self.assertEqual(len(cache.read_series("quotes", root)), 2)
            manifest = cache.cache_dir(root) / "manifest.json"
            payload = json.loads(manifest.read_text(encoding="utf-8"))
            payload["generation"] = "an-older-build"
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            self.assertTrue(cache.read_series("quotes", root).empty)
            payload["generation"] = cache.CACHE_GENERATION
            payload["contract"] = "something-else"
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            self.assertTrue(cache.read_series("quotes", root).empty)

    def test_a_corrupt_or_mislabelled_file_reads_as_no_cache(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save("quotes", _quotes("FUND LN Equity", ["2026-10-01"]), "2026-10-05", root)
            path = cache.cache_dir(root) / "quotes.csv"
            path.write_text("ID,WRONG\nA,1\n", encoding="utf-8")
            self.assertTrue(cache.read_series("quotes", root).empty)
            path.write_text("\x00\x01\x02", encoding="utf-8")
            self.assertTrue(cache.read_series("quotes", root).empty)

    def test_a_file_with_no_value_at_all_is_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save("quotes", _quotes("FUND LN Equity", ["2026-10-01"]), "2026-10-05", root)
            path = cache.cache_dir(root) / "quotes.csv"
            path.write_text("ID,DATE,Bid,Ask,Mid\nA,2026-10-01,,,\n", encoding="utf-8")
            self.assertTrue(cache.read_series("quotes", root).empty)


class SaveTests(unittest.TestCase):
    def test_a_settled_row_is_written_and_a_live_row_is_not(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            frame = _quotes(
                "FUND LN Equity",
                ["2026-10-28", "2026-10-29", "2026-10-30"],
            )
            written = cache.save("quotes", frame, "2026-10-30", root)
            self.assertEqual(written, 2)
            stored = cache.read_series("quotes", root)
            self.assertEqual(
                [str(day.date()) for day in stored["DATE"]],
                ["2026-10-28", "2026-10-29"],
            )

    def test_a_later_run_keeps_the_other_identifiers(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save("quotes", _quotes("A LN Equity", ["2026-10-01"]), "2026-10-05", root)
            cache.save("quotes", _quotes("B LN Equity", ["2026-10-01"]), "2026-10-05", root)
            stored = cache.read_series("quotes", root)
            self.assertEqual(sorted(stored["ID"].unique().tolist()), ["A LN Equity", "B LN Equity"])

    def test_the_same_identifier_is_replaced_not_doubled(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save("quotes", _quotes("A LN Equity", ["2026-10-01"], 10.0), "2026-10-05", root)
            cache.save("quotes", _quotes("A LN Equity", ["2026-10-01"], 11.0), "2026-10-05", root)
            stored = cache.read_series("quotes", root)
            self.assertEqual(len(stored), 1)
            self.assertAlmostEqual(float(stored.iloc[0]["Bid"]), 11.0)

    def test_an_empty_or_partial_frame_is_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with self.assertRaises(ValueError):
                cache.save("quotes", pd.DataFrame(), "2026-10-05", root)
            partial = pd.DataFrame({"ID": ["A"], "DATE": ["2026-10-01"], "Bid": [1.0]})
            with self.assertRaisesRegex(ValueError, "missing"):
                cache.save("quotes", partial, "2026-10-05", root)
            blank = pd.DataFrame(
                {
                    "ID": ["A LN Equity"],
                    "DATE": ["2026-10-01"],
                    "Bid": [pd.NA],
                    "Ask": [pd.NA],
                    "Mid": [pd.NA],
                }
            )
            with self.assertRaisesRegex(ValueError, "no value"):
                cache.save("quotes", blank, "2026-10-05", root)

    def test_an_unwritable_folder_raises_for_the_caller_to_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / cache.CACHE_DIR_NAME).write_text("not a folder", encoding="utf-8")
            with self.assertRaises(OSError):
                cache.save("quotes", _quotes("A LN Equity", ["2026-10-01"]), "2026-10-05", root)


class GapTests(unittest.TestCase):
    def test_no_cache_means_the_caller_window_is_requested_whole(self):
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity", "B LN Equity"],
            pd.DataFrame(),
            None,
            None,
            default_end="2026-11-02",
        )
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0][0], None)
        self.assertEqual(jobs[0][1], None)
        self.assertEqual(jobs[0][2], ["A LN Equity", "B LN Equity"])

    def test_a_daily_run_asks_only_for_the_missing_days(self):
        cached = _quotes("A LN Equity", ["2026-10-28", "2026-10-29"])
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity"],
            cached,
            "2026-10-28",
            None,
            default_end="2026-11-02",
        )
        self.assertEqual(len(jobs), 1)
        self.assertEqual(pd.Timestamp(jobs[0][0]).date().isoformat(), "2026-10-30")
        self.assertEqual(pd.Timestamp(jobs[0][1]).date().isoformat(), "2026-11-02")
        self.assertEqual(jobs[0][2], ["A LN Equity"])

    def test_a_late_head_and_a_late_tail_are_both_asked_for(self):
        cached = _quotes("A LN Equity", ["2026-10-28", "2026-10-29"])
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity"],
            cached,
            "2026-10-01",
            "2026-11-02",
        )
        windows = [
            (pd.Timestamp(start).date().isoformat(), pd.Timestamp(end).date().isoformat())
            for start, end, _ids in jobs
        ]
        self.assertEqual(windows, [("2026-10-01", "2026-10-27"), ("2026-10-30", "2026-11-02")])

    def test_a_fully_covered_series_asks_for_nothing(self):
        cached = _quotes("A LN Equity", ["2026-10-01", "2026-11-02"])
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity"],
            cached,
            "2026-10-01",
            "2026-11-02",
        )
        self.assertEqual(jobs, [])

    def test_a_late_head_is_requested_with_absolute_dates(self):
        cached = _quotes("A LN Equity", ["2026-10-15", "2026-11-02"])
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity"],
            cached,
            "2026-10-01",
            "2026-11-02",
        )
        self.assertEqual(len(jobs), 1)
        self.assertEqual(pd.Timestamp(jobs[0][0]).date().isoformat(), "2026-10-01")
        self.assertEqual(pd.Timestamp(jobs[0][1]).date().isoformat(), "2026-10-14")

    def test_a_relative_window_needs_an_absolute_head(self):
        cached = _quotes("A LN Equity", ["2025-01-02", "2026-11-02"])
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity"],
            cached,
            None,
            None,
            default_end="2026-11-02",
        )
        self.assertEqual(len(jobs), 1)
        self.assertEqual(pd.Timestamp(jobs[0][0]).date().isoformat(), "2021-11-02")
        self.assertEqual(pd.Timestamp(jobs[0][1]).date().isoformat(), "2025-01-01")

    def test_a_weekend_only_tail_is_not_requested(self):
        # Saturday 2026-10-31 and Sunday 2026-11-01 hold no print.
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity"],
            _quotes("A LN Equity", ["2026-10-30"]),
            "2026-10-30",
            "2026-11-01",
        )
        self.assertEqual(jobs, [])

    def test_each_identifier_keeps_its_own_cache_horizon(self):
        cached = pd.concat(
            [
                _quotes("A LN Equity", ["2026-10-29"]),
                _quotes("B LN Equity", ["2026-10-28"]),
            ],
            ignore_index=True,
        )
        jobs = cache.plan_gaps(
            "quotes",
            ["A LN Equity", "B LN Equity", "C LN Equity"],
            cached,
            "2026-10-20",
            "2026-11-02",
        )
        windows = {
            (pd.Timestamp(start).date().isoformat(), pd.Timestamp(end).date().isoformat()): ids
            for start, end, ids in jobs
        }
        self.assertEqual(
            windows,
            {
                ("2026-10-20", "2026-11-02"): ["C LN Equity"],
                ("2026-10-20", "2026-10-27"): ["B LN Equity"],
                ("2026-10-20", "2026-10-28"): ["A LN Equity"],
                ("2026-10-30", "2026-11-02"): ["A LN Equity"],
                ("2026-10-29", "2026-11-02"): ["B LN Equity"],
            },
        )


class IdentityTests(unittest.TestCase):
    """A ticker that now points at another security must not reuse its rows."""

    def test_an_unrecorded_identifier_keeps_its_rows(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save("quotes", _quotes("FUND LN Equity", ["2026-10-01"]), "2026-11-02", root)
            self.assertEqual(cache.stale_identities(root, {"FUND LN Equity": "IE00AAA"}), {})
            stored = cache.read_series("quotes", root, None, {"FUND LN Equity": "IE00AAA"})
            self.assertEqual(len(stored), 1)

    def test_the_same_identity_keeps_its_rows(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save(
                "quotes",
                _quotes("FUND LN Equity", ["2026-10-01"]),
                "2026-11-02",
                root,
                None,
                {"FUND LN Equity": "IE00AAA"},
            )
            self.assertEqual(cache.stale_identities(root, {"FUND LN Equity": "IE00AAA"}), {})
            stored = cache.read_series("quotes", root, None, {"FUND LN Equity": "IE00AAA"})
            self.assertEqual(len(stored), 1)

    def test_a_changed_primary_share_class_discards_the_series(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save(
                "quotes",
                _quotes("HSAX LN Equity", ["2026-10-01", "2026-10-02"]),
                "2026-11-02",
                root,
                None,
                # The ticker stayed, the class behind it did not.
                {"HSAX LN Equity": "IE00AAA111"},
            )
            stale = cache.stale_identities(root, {"HSAX LN Equity": "IE00BBB222"})
            self.assertEqual(len(stale), 1)
            self.assertEqual(stale["HSAX LN Equity"], ("IE00AAA111", "IE00BBB222"))
            stored = cache.read_series(
                "quotes", root, None, {"HSAX LN Equity": "IE00BBB222"}
            )
            self.assertTrue(stored.empty)

    def test_the_change_is_scoped_to_the_identifier_that_moved(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save(
                "quotes",
                pd.concat(
                    [
                        _quotes("HSAX LN Equity", ["2026-10-01"]),
                        _quotes("PEER LN Equity", ["2026-10-01"]),
                    ],
                    ignore_index=True,
                ),
                "2026-11-02",
                root,
                None,
                {"HSAX LN Equity": "IE00AAA", "PEER LN Equity": "IE00CCC"},
            )
            stored = cache.read_series(
                "quotes",
                root,
                None,
                {"HSAX LN Equity": "IE00BBB", "PEER LN Equity": "IE00CCC"},
            )
            self.assertEqual(stored["ID"].tolist(), ["PEER LN Equity"])

    def test_a_case_or_space_difference_is_not_an_identity_change(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save(
                "quotes",
                _quotes("FUND LN Equity", ["2026-10-01"]),
                "2026-11-02",
                root,
                None,
                {"fund ln equity": "ie00aaa"},
            )
            self.assertEqual(
                cache.stale_identities(root, {"FUND LN Equity ": "IE00AAA"}), {}
            )

    def test_a_blank_identity_never_counts_as_a_change(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save(
                "quotes",
                _quotes("FUND LN Equity", ["2026-10-01"]),
                "2026-11-02",
                root,
                None,
                {"FUND LN Equity": "IE00AAA"},
            )
            # The profile pull failed this run: nothing is proven either way.
            self.assertEqual(cache.stale_identities(root, {"FUND LN Equity": ""}), {})
            self.assertEqual(cache.stale_identities(root, None), {})
            stored = cache.read_series("quotes", root, None, {"FUND LN Equity": ""})
            self.assertEqual(len(stored), 1)

    def test_a_generation_bump_also_drops_the_identity_ledger(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache.save(
                "quotes",
                _quotes("FUND LN Equity", ["2026-10-01"]),
                "2026-11-02",
                root,
                None,
                {"FUND LN Equity": "IE00AAA"},
            )
            manifest = cache.cache_dir(root) / "manifest.json"
            payload = json.loads(manifest.read_text(encoding="utf-8"))
            payload["generation"] = "an-older-build"
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            self.assertEqual(cache.stale_identities(root, {"FUND LN Equity": "IE00BBB"}), {})


class MergeTests(unittest.TestCase):
    def test_a_live_row_wins_on_the_same_key(self):
        cached = _quotes("A LN Equity", ["2026-10-28", "2026-10-29"], 10.0)
        live = _quotes("A LN Equity", ["2026-10-29", "2026-10-30"], 12.0)
        merged = cache.merge("quotes", cached, [live])
        self.assertEqual(len(merged), 3)
        update = merged.loc[merged["DATE"].eq(pd.Timestamp("2026-10-29"))].iloc[0]
        self.assertAlmostEqual(float(update["Bid"]), 12.0)

    def test_a_store_with_no_cached_rows_still_merges_the_live_frames(self):
        live = _quotes("A LN Equity", ["2026-10-30"])
        merged = cache.merge("quotes", pd.DataFrame(), [live])
        self.assertEqual(list(merged.columns), ["ID", "DATE", "Bid", "Ask", "Mid"])
        self.assertEqual(len(merged), 1)

    def test_two_kinds_do_not_share_a_column_contract(self):
        levels = pd.DataFrame(
            {"ID": ["A", "A"], "DATE": ["2026-10-01", "2026-10-02"], "Level": [100.0, 101.0]}
        )
        merged = cache.merge("returns", pd.DataFrame(), [levels])
        self.assertEqual(list(merged.columns), ["ID", "DATE", "Level"])


class FingerprintTests(unittest.TestCase):
    """The token follows the request, not the column names."""

    def test_a_changed_item_moves_the_token(self):
        def before(bq, tickers, start=None, end=None):
            return bq.data.px_bid(dates=None)

        def after(bq, tickers, start=None, end=None):
            return bq.data.px_ask(dates=None)

        self.assertNotEqual(
            cache.fingerprint([before]), cache.fingerprint([after])
        )

    def test_a_changed_parameter_moves_the_token(self):
        def before(bq, tickers, start=None, end=None):
            return bq.data.fund_net_asset_val(dates=None, currency="USD")

        def after(bq, tickers, start=None, end=None):
            return bq.data.fund_net_asset_val(dates=None, currency="USD", fill="prev")

        self.assertNotEqual(
            cache.fingerprint([before]), cache.fingerprint([after])
        )

    def test_a_comment_or_docstring_does_not_move_the_token(self):
        from unittest import mock

        def builder(bq):
            return bq.data.px_bid()

        plain = "def builder(bq):\n    return bq.data.px_bid()\n"
        annotated = (
            "def builder(bq):\n"
            '    """Serving a five-year series is expensive."""\n'
            "    # A comment that changed nothing.\n"
            "    return bq.data.px_bid()\n"
        )
        with mock.patch.object(cache.inspect, "getsource", lambda _f: plain):
            first = cache.fingerprint([builder])
        with mock.patch.object(cache.inspect, "getsource", lambda _f: annotated):
            second = cache.fingerprint([builder])
        self.assertEqual(first, second)

    def test_an_unreadable_source_is_stable(self):
        # A builtin has no source. Two calls must still agree, or every
        # Refresh would discard the cache.
        with mock.patch.object(
            cache.inspect, "getsource", side_effect=TypeError("no source")
        ):
            self.assertEqual(cache.fingerprint([len]), cache.fingerprint([len]))


class RoundTripTests(unittest.TestCase):
    def test_a_stored_frame_reads_back_with_the_same_dates_and_values(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            frame = _quotes("A LN Equity", ["2026-10-01", "2026-10-02"], 18.235)
            cache.save("quotes", frame, "2026-10-05", root)
            stored = cache.read_series("quotes", root)
            self.assertEqual(
                [str(day.date()) for day in stored["DATE"]],
                ["2026-10-01", "2026-10-02"],
            )
            self.assertAlmostEqual(float(stored.iloc[0]["Bid"]), 18.235)

    def test_a_missing_value_reads_back_blank_not_zero(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            frame = _quotes("A LN Equity", ["2026-10-01"])
            frame["Mid"] = pd.NA
            cache.save("quotes", frame, "2026-10-05", root)
            stored = cache.read_series("quotes", root)
            self.assertTrue(pd.isna(stored.iloc[0]["Mid"]))
            self.assertAlmostEqual(float(stored.iloc[0]["Ask"]), 10.1)


class _DateRange:
    def __init__(self, start, end):
        self.start = str(start)
        self.end = str(end)


class _FakeData:
    def __getattr__(self, name):
        def builder(*_args, **kwargs):
            return {"item": name, "kwargs": kwargs}

        return builder


class _FakeFunc:
    def __init__(self, calls):
        self.calls = calls

    def range(self, start, end):
        self.calls.append((str(start), str(end)))
        return _DateRange(start, end)


class _FakeService:
    def __init__(self, calls):
        self.data = _FakeData()
        self.func = _FakeFunc(calls)


class _FakeRequest:
    def __init__(self, tickers, items, with_params=None):
        self.tickers = list(tickers)
        self.items = items
        self.with_params = with_params
        window = None
        for item in items.values():
            kwargs = item.get("kwargs") if isinstance(item, dict) else None
            if kwargs and "dates" in kwargs:
                window = kwargs["dates"]
                break
        self.window_start = getattr(window, "start", None)
        self.window_end = getattr(window, "end", None)


class _FakeBql:
    def __init__(self, calls):
        self.calls = calls
        self.service = _FakeService(calls)

    def Service(self):
        return self.service

    def Request(self, tickers, items, with_params=None):
        return _FakeRequest(tickers, items, with_params)


class _FakeResponse:
    """A response type: ``_is_response`` looks for "response" in the name."""

    def __init__(self, frame):
        self.frame = frame


class WiringTests(unittest.TestCase):
    """The Refresh asks only for the days the cache cannot answer."""

    @staticmethod
    def _token():
        from etf_spread import data

        return data.history_request_token()

    def _seed(self, kind, frame, root, token=None):
        return cache.save(
            kind,
            frame,
            "2026-11-02",
            root,
            self._token() if token is None else token,
        )

    def _run(
        self,
        root,
        as_of,
        use_cache=True,
        live=False,
        quote_ids=None,
        history_start="2026-10-01",
        history_end="2026-11-02",
        identities=None,
    ):
        from unittest import mock

        from etf_spread import data

        quote_ids = ["FUND LN Equity"] if quote_ids is None else list(quote_ids)
        calls = []
        sent = []

        def record(_service, labeled):
            paired = []
            for label, request in labeled:
                sent.append((label, request))
                if live:
                    paired.append((label, _FakeResponse(self._live_frame(label, request))))
            return paired

        fake = _FakeBql(calls)
        with mock.patch.object(data, "bql", fake), mock.patch.object(
            data, "_execute_waves", record
        ), mock.patch.object(data, "_combine_items", lambda response: response.frame):
            result = data.fetch_parallel_histories(
                quote_ids,
                list(quote_ids),
                None,
                None,
                None,
                progress=None,
                history_start=history_start,
                history_end=history_end,
                nav_ids=list(quote_ids),
                as_of=as_of,
                use_cache=use_cache,
                cache_root=root,
                identities=identities,
            )
        return result, calls, sent

    @staticmethod
    def _live_frame(label, request):
        dates = ["2026-10-30", "2026-11-02"]
        rows = []
        for ticker in request.tickers:
            for day in dates:
                rows.append(
                    {
                        "ID": ticker,
                        "DATE": day,
                        "Bid": 10.0,
                        "Ask": 10.2,
                        "Mid": 10.1,
                        "Level": 100.0,
                        "Flow": 1000000.0,
                    }
                )
        return pd.DataFrame(rows)

    def test_a_cold_run_requests_the_whole_window(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _result, calls, sent = self._run(root, "2026-11-02")
            self.assertEqual(
                [label for label, _request in sent],
                ["quotes_1", "returns_1", "navs_1"],
            )
            self.assertEqual(calls, [("2026-10-01", "2026-11-02")] * 3)
            self.assertFalse((root / cache.CACHE_DIR_NAME).exists())

    def test_a_warm_run_requests_only_the_missing_days(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            days = ["2026-10-01", "2026-10-02", "2026-10-30"]
            self._seed("quotes", _quotes("FUND LN Equity", days, 10.0), root)
            levels = pd.DataFrame(
                {
                    "ID": ["FUND LN Equity"] * len(days),
                    "DATE": days,
                    "Level": [100.0] * len(days),
                }
            )
            self._seed("returns", levels, root)
            self._seed("navs", levels, root)
            result, calls, sent = self._run(root, "2026-11-03")
            quotes = result[0]
            self.assertEqual(
                [label for label, _request in sent],
                ["quotes_1", "returns_1", "navs_1"],
            )
            # The stored days are served from disk, so every request starts
            # after them instead of asking for the whole window again.
            self.assertEqual(
                {(str(call[0]), str(call[1])) for call in calls},
                {("2026-10-31", "2026-11-02")},
            )
            self.assertIn("Spread", quotes.observations.columns)
            # Two requested days, but the frame still opens on the stored day.
            self.assertEqual(
                quotes.observations["DATE"].min().date().isoformat(),
                "2026-10-01",
            )
            self.assertGreaterEqual(len(quotes.observations), 3)

    def test_cache_off_requests_the_window_and_writes_nothing(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._seed("quotes", _quotes("FUND LN Equity", ["2026-10-30"]), root)
            before = (cache.cache_dir(root) / "quotes.csv").read_text(encoding="utf-8")
            _result, calls, sent = self._run(root, "2026-11-03", use_cache=False, live=True)
            self.assertEqual(len(sent), 3)
            self.assertEqual(calls, [("2026-10-01", "2026-11-02")] * 3)
            after = (cache.cache_dir(root) / "quotes.csv").read_text(encoding="utf-8")
            self.assertEqual(before, after)

    def test_a_live_run_writes_the_settled_rows(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._run(root, "2026-11-02", live=True)
            stored = cache.read_series("quotes", root, self._token())
            self.assertEqual(
                [str(day.date()) for day in stored["DATE"].unique()],
                ["2026-10-30"],
            )

    def test_a_new_book_or_peer_identifier_gets_its_own_full_history(self):
        """A share class or peer added later does not inherit another's cache."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            days = ["2026-10-01", "2026-10-30"]
            self._seed("quotes", _quotes("OLD LN Equity", days, 10.0), root)
            self._result, calls, sent = self._run(
                root,
                "2026-11-03",
                quote_ids=["OLD LN Equity", "NEW LN Equity"],
            )
            quote_jobs = {
                (
                    pd.Timestamp(request.window_start).date().isoformat(),
                    pd.Timestamp(request.window_end).date().isoformat(),
                    tuple(request.tickers),
                )
                for label, request in sent
                if label.startswith("quotes_")
            }
            self.assertEqual(
                quote_jobs,
                {
                    # The new id has no stored head, so it gets the full window.
                    ("2026-10-01", "2026-11-02", ("NEW LN Equity",)),
                    # The known id asks only for the days after its last row.
                    ("2026-10-31", "2026-11-02", ("OLD LN Equity",)),
                },
            )
            # A new identifier never inherits another one's coverage.
            gaps = cache.plan_gaps(
                "quotes",
                ["OLD LN Equity", "NEW LN Equity"],
                _quotes("OLD LN Equity", days),
                "2026-10-01",
                "2026-11-02",
            )
            windows = {
                (pd.Timestamp(start).date().isoformat(), pd.Timestamp(end).date().isoformat()): ids
                for start, end, ids in gaps
            }
            self.assertEqual(
                windows.get(("2026-10-01", "2026-11-02")), ["NEW LN Equity"]
            )

    def test_a_narrower_run_keeps_the_other_identifiers_rows(self):
        """A Strategy filter or a dropped peer must not wipe what is stored."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            token = self._token()
            self._seed("quotes", _quotes("EQUITY LN Equity", ["2026-10-01"]), root)
            self._seed("quotes", _quotes("BOND LN Equity", ["2026-10-01"]), root)
            self._run(root, "2026-11-02", live=True, quote_ids=["EQUITY LN Equity"])
            stored = cache.read_series("quotes", root, token)
            self.assertEqual(
                sorted(stored["ID"].unique().tolist()),
                ["BOND LN Equity", "EQUITY LN Equity"],
            )

    def test_a_changed_request_discards_the_stored_rows(self):
        """Same column names, a different request: the rows must not be reused."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            days = ["2026-10-01", "2026-10-30"]
            self._seed(
                "quotes",
                _quotes("FUND LN Equity", days, 10.0),
                root,
                token="a-request-from-an-older-build",
            )
            self._result, calls, sent = self._run(root, "2026-11-03")
            # Every leg starts at the window head: nothing was reused.
            self.assertEqual({str(call[0]) for call in calls}, {"2026-10-01"})

    def test_the_window_is_trimmed_to_what_was_asked_for(self):
        """A 1Y run must not answer with the five years a 5Y run stored."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            days = ["2025-01-02", "2026-06-01", "2026-10-30"]
            for kind, frame in (
                ("quotes", _quotes("FUND LN Equity", days, 10.0)),
                (
                    "returns",
                    pd.DataFrame(
                        {
                            "ID": ["FUND LN Equity"] * len(days),
                            "DATE": days,
                            "Level": [100.0] * len(days),
                        }
                    ),
                ),
                (
                    "navs",
                    pd.DataFrame(
                        {
                            "ID": ["FUND LN Equity"] * len(days),
                            "DATE": days,
                            "Level": [100.0] * len(days),
                        }
                    ),
                ),
            ):
                self._seed(kind, frame, root)
            result, _calls, _sent = self._run(
                root,
                "2026-11-03",
                history_start="2025-11-03",
                history_end="2026-11-02",
            )
            quotes = result[0].observations
            self.assertEqual(
                quotes["DATE"].min().date().isoformat(),
                "2026-06-01",
            )

    def test_a_relinked_primary_class_requests_the_full_window_again(self):
        """The ticker did not change; the share class behind it did."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            days = ["2026-10-01", "2026-10-02", "2026-10-30"]
            # First run: the class resolves to IE00AAA and settles rows.
            self._result, _calls, _sent = self._run(
                root,
                "2026-11-03",
                live=True,
                identities={"FUND LN Equity": "IE00AAA"},
            )
            # Second run: the same ticker now resolves to IE00BBB.
            _result, calls, sent = self._run(
                root,
                "2026-11-04",
                identities={"FUND LN Equity": "IE00BBB"},
            )
            # One window covering the whole request: the stored rows belong
            # to the previous class, so nothing is reused for this ticker.
            self.assertEqual({str(call[0]) for call in calls}, {"2026-10-01"})
            self.assertEqual({str(call[1]) for call in calls}, {"2026-11-02"})
            self.assertEqual(len(sent), 3)
            # The event is named in the status detail, not only in the
            # transient progress line: the operator has to see that a fund's
            # history was re-pulled because its class moved.
            joined = " ".join(_result[0].errors)
            self.assertIn("different security", joined)
            self.assertIn("FUND LN Equity", joined)

    def test_an_unchanged_identity_keeps_the_short_request(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._run(
                root,
                "2026-11-02",
                live=True,
                identities={"FUND LN Equity": "IE00AAA"},
            )
            _result, calls, sent = self._run(
                root,
                "2026-11-04",
                identities={"FUND LN Equity": "IE00AAA"},
            )
            # The stored rows are still this security's, so only the missing
            # head and the unsettled tail are requested.
            self.assertEqual(
                {(str(call[0]), str(call[1])) for call in calls},
                {("2026-10-01", "2026-10-29"), ("2026-10-31", "2026-11-02")},
            )

    def test_a_failed_write_is_reported_and_does_not_raise(self):
        from unittest import mock

        from etf_spread import data

        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / cache.CACHE_DIR_NAME).write_text("not a folder", encoding="utf-8")
            with mock.patch.object(data, "bql", _FakeBql([])), mock.patch.object(
                cache, "save", side_effect=OSError("read-only project folder")
            ):
                result, _calls, _sent = self._run(root, "2026-11-02", live=True)
            joined = " ".join(result[0].errors)
            self.assertIn("history cache was not written", joined)


if __name__ == "__main__":
    unittest.main()
