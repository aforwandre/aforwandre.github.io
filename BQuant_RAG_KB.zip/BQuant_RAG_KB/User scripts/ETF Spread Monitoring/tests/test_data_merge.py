"""Key-based multi-item merge and column contract. No Bloomberg call."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_spread import data  # noqa: E402
from etf_spread.book_view import display_columns  # noqa: E402
from etf_spread.peers import PEER_COLUMNS  # noqa: E402


class _Item:
    def __init__(self, name, frame):
        self.name = name
        self._frame = frame

    def df(self):
        return self._frame


class _Response:
    def __init__(self, items):
        self._items = items

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        return self._items[index]


class MultiItemMergeTests(unittest.TestCase):
    def test_sparse_spread_items_merge_on_id_and_date(self):
        bid = pd.DataFrame({"ID": ["A"], "DATE": ["2026-10-20"], "Value": [10.0]})
        ask = pd.DataFrame(
            {"ID": ["A", "A"], "DATE": ["2026-10-21", "2026-10-20"], "Value": [11.0, 10.06]}
        )
        mid = pd.DataFrame(
            {"ID": ["A", "A"], "DATE": ["2026-10-21", "2026-10-20"], "Value": [10.5, 10.03]}
        )
        merged = data._combine_items(
            _Response([_Item("Bid", bid), _Item("Ask", ask), _Item("Mid", mid)])
        )
        self.assertEqual(len(merged), 2)
        first = merged.loc[merged["DATE"].eq(pd.Timestamp("2026-10-20"))].iloc[0]
        self.assertAlmostEqual(float(first["Ask"] - first["Bid"]), 0.06)
        second = merged.loc[merged["DATE"].eq(pd.Timestamp("2026-10-21"))]
        self.assertTrue(second["Bid"].isna().all())

    def test_static_items_merge_on_id_not_position(self):
        names = pd.DataFrame(
            {"ID": ["A", "B"], "DATE": ["2026-10-23", "2026-10-23"], "Name": ["Alpha", "Beta"]}
        )
        currency = pd.DataFrame(
            {"ID": ["B", "A"], "DATE": ["2026-10-22", "2026-10-22"], "Currency": ["EUR", "USD"]}
        )
        merged = data._combine_items(
            _Response([_Item("Name", names), _Item("Currency", currency)])
        )
        row = merged.loc[merged["ID"].eq("A")].iloc[0]
        self.assertEqual(row["Name"], "Alpha")
        self.assertEqual(row["Currency"], "USD")

    def test_index_only_item_is_accepted(self):
        frame = pd.DataFrame({"Name": ["Alpha"]}, index=pd.Index(["A"], name="ID"))
        merged = data._combine_items(_Response([_Item("Name", frame)]))
        self.assertEqual(merged.iloc[0]["ID"], "A")
        self.assertEqual(merged.iloc[0]["Name"], "Alpha")

    def test_disagreeing_duplicate_ids_are_dropped(self):
        names = pd.DataFrame({"ID": ["A", "A", "B"], "Name": ["One", "Two", "Beta"]})
        merged = data._combine_items(_Response([_Item("Name", names)]))
        self.assertEqual(list(merged["ID"]), ["B"])
        self.assertEqual(merged.iloc[0]["Name"], "Beta")

    def test_blank_tokens_do_not_become_numbers(self):
        from etf_spread.book_view import absolute_quote_spread, market_numbers, missing_market_text

        self.assertTrue(missing_market_text("N/A - suspended"))
        self.assertTrue(missing_market_text("#N/A Invalid Security"))
        self.assertTrue(missing_market_text("N.A. (no last sale)"))
        self.assertFalse(missing_market_text("NA US Equity"))
        self.assertFalse(missing_market_text("NAV"))
        quotes = market_numbers(
            pd.Series(["N/A - halted", 0, "", 10.5, "0 - not priced"]),
            allow_zero=False,
        )
        self.assertTrue(pd.isna(quotes.iloc[0]))
        self.assertTrue(pd.isna(quotes.iloc[1]))
        self.assertTrue(pd.isna(quotes.iloc[2]))
        self.assertAlmostEqual(float(quotes.iloc[3]), 10.5)
        self.assertTrue(pd.isna(quotes.iloc[4]))
        flows = market_numbers(pd.Series([0, "N/A - no flow"]), allow_zero=True)
        self.assertEqual(float(flows.iloc[0]), 0.0)
        self.assertTrue(pd.isna(flows.iloc[1]))
        spread = absolute_quote_spread(
            pd.Series(["N/A - suspended", 0, 10.0]),
            pd.Series([12.0, 12.0, 10.2]),
        )
        self.assertTrue(pd.isna(spread.iloc[0]))
        self.assertTrue(pd.isna(spread.iloc[1]))
        self.assertAlmostEqual(float(spread.iloc[2]), 0.2)
        self.assertTrue(pd.isna(data.expense_ratio_number("N/A - waived")))
        self.assertEqual(data.expense_ratio_number(0), 0.0)
        self.assertEqual(
            data.company_id_from_frame(pd.DataFrame({"ID BB Company": ["N/A - no company"]})),
            "",
        )
        self.assertEqual(
            data.company_id_from_frame(pd.DataFrame({"ID BB Company": [2044857600001.0]})),
            "2044857600001",
        )

    def test_peer_listing_crncy_uses_the_currency_column(self):
        currency = pd.DataFrame({"ID": ["IE00PEER"], "CURRENCY": ["USD"]})
        name = pd.DataFrame(
            {
                "ID": ["IE00PEER", "IE00PEER"],
                "CURRENCY": ["USD", "EUR"],
                "Name": ["Peer USD", "Peer EUR"],
            }
        )
        ticker = pd.DataFrame(
            {
                "ID": ["IE00PEER", "IE00PEER"],
                "CURRENCY": ["USD", "EUR"],
                "Ticker": ["P US Equity", "P LN Equity"],
            }
        )
        prepared = data._prepare_listing_frame(
            _Response(
                [
                    _Item("Currency", currency),
                    _Item("Name", name),
                    _Item("Ticker", ticker),
                ]
            )
        )
        self.assertEqual(len(prepared), 1)
        self.assertEqual(prepared.iloc[0]["Currency"], "USD")
        self.assertEqual(prepared.iloc[0]["Name"], "Peer USD")
        self.assertEqual(prepared.iloc[0]["Ticker"], "P US Equity")

    def test_row_number_index_is_rejected(self):
        frame = pd.DataFrame({"Name": ["Alpha"]})
        with self.assertRaisesRegex(ValueError, "row-number"):
            data._combine_items(_Response([_Item("Name", frame)]))


class RequestWaveTests(unittest.TestCase):
    def test_execute_waves_sends_eight_requests_together(self):
        class Service:
            def __init__(self):
                self.sizes = []

            def execute_many(self, requests, on_request_error=None, num_retries=0):
                self.sizes.append(len(requests))
                return [None] * len(requests)

        service = Service()
        labeled = [(str(index), object()) for index in range(20)]
        paired = data._execute_waves(service, labeled)
        self.assertEqual(service.sizes, [8, 8, 4])
        self.assertEqual(len(paired), 20)
        self.assertEqual(data.SHARE_CLASS_BATCH, 8)


class ColumnContractTests(unittest.TestCase):
    def test_nav_tracking_error_sits_before_px_last_tracking_error(self):
        book = display_columns()
        peers = list(PEER_COLUMNS)
        for columns in (book, peers):
            self.assertIn("NAV Tracking Error", columns)
            self.assertIn("Tracking Error", columns)
            self.assertLess(
                columns.index("NAV Tracking Error"), columns.index("Tracking Error")
            )


if __name__ == "__main__":
    unittest.main()
