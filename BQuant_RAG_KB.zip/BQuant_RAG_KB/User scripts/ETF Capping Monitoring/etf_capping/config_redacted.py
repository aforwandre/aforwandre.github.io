"""Desensitized OUTPUT copy of ``config.py``. Do not import this module.

Edit and run against ``etf_capping.config`` only. After any structural change
to ``config.py``, regenerate the matching helpers here, but keep placeholder
AIM codes, fund names, exceptions, and Thai tickers.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


WARNING_RATIO = 0.98
AIM_ACCOUNT_BATCH = 8
SECURITY_BATCH = 150

STATUS_COLORS = {
    "Breach": "#ff5c5c",
    "Near Limit": "#f5a623",
    "OK": "#5f6b7a",
    "Data Issue": "#b388ff",
}


@dataclass(frozen=True)
class AccountRule:
    aim_code: str
    fund_name: str
    capping: float
    largest: float
    level: str
    price_type: str


@dataclass(frozen=True)
class ExceptionRule:
    ticker: str
    name: str
    parent_ticker: str
    parent_name: str


@dataclass(frozen=True)
class ThaiPricingRule:
    foreign_ticker: str
    local_ticker: str
    reason: str


# Placeholder limits for all 54 sample accounts: (Capping, Largest, Type, price_type)
_SAMPLE_LIMITS = (0.10, 0.10, "Issuer", "Real Time")

ACCOUNT_RULES = tuple(
    AccountRule(
        f"ACCT{index:02d}",
        f"Sample Fund {index:02d}",
        *_SAMPLE_LIMITS,
    )
    for index in range(1, 55)
)


EXCEPTION_RULES = (
    ExceptionRule("AAA US Equity", "Sample Co A", "AAA US Equity", "Sample Co A"),
    ExceptionRule("BBB US Equity", "Sample Co B", "AAA US Equity", "Sample Co A"),
    ExceptionRule("CCC US Equity", "Sample Co C", "AAA US Equity", "Sample Co A"),
    ExceptionRule("DDD US Equity", "Sample Co D", "AAA US Equity", "Sample Co A"),
    ExceptionRule("EEE US Equity", "Sample Co E ADR", "AAA US Equity", "Sample Co A"),
)

THAI_PRICING_RULES = (
    ThaiPricingRule(
        "SAMPLE/F TB Equity",
        "SAMPLEX TB Equity",
        "Local symbol differs from a simple /F removal.",
    ),
)


def account_rules_frame() -> pd.DataFrame:
    """Return the bundled account runbook as a DataFrame."""
    return pd.DataFrame(
        [
            {
                "AIM Code": rule.aim_code,
                "Fund Name": rule.fund_name,
                "Capping": rule.capping,
                "Largest": rule.largest,
                "Level": rule.level,
                "Type": rule.price_type,
                "Primary FM": f"Sample FM {((index - 1) % 4) + 1}",
            }
            for index, rule in enumerate(ACCOUNT_RULES, start=1)
        ]
    )


def exception_rules_frame() -> pd.DataFrame:
    """Return the hard override table as a DataFrame."""
    return pd.DataFrame(
        [
            {
                "Ticker": rule.ticker,
                "Name": rule.name,
                "Parent Ticker": rule.parent_ticker,
                "Parent Name": rule.parent_name,
            }
            for rule in EXCEPTION_RULES
        ]
    )


def thai_pricing_rules_frame() -> pd.DataFrame:
    """Return the approved Thai foreign-line pricing overrides."""
    return pd.DataFrame(
        [
            {
                "Foreign Ticker": rule.foreign_ticker,
                "Local Price Ticker": rule.local_ticker,
                "Reason": rule.reason,
            }
            for rule in THAI_PRICING_RULES
        ]
    )


def thai_pricing_overrides() -> dict[str, str]:
    overrides = {}
    for rule in THAI_PRICING_RULES:
        key = rule.foreign_ticker.strip().upper()
        local = rule.local_ticker.strip()
        local_upper = local.upper()
        if not (
            key.endswith("/F TB EQUITY") or key.endswith("-R TB EQUITY")
        ):
            raise ValueError(
                f"Thai pricing override is not a foreign line: {key}"
            )
        if (
            not local_upper.endswith(" TB EQUITY")
            or "/F" in local_upper
            or local_upper.endswith("-R TB EQUITY")
        ):
            raise ValueError(
                f"Thai pricing override is not a local TB Equity: {local}"
            )
        if key in overrides:
            raise ValueError(
                f"Duplicate Thai foreign-line pricing override: {key}"
            )
        overrides[key] = local
    return overrides


def account_codes() -> list[str]:
    codes = [rule.aim_code.strip() for rule in ACCOUNT_RULES]
    duplicates = sorted({
        code for code in codes if codes.count(code) > 1
    })
    if duplicates:
        raise ValueError(f"Duplicate AIM Codes in runbook: {duplicates}")
    return codes
