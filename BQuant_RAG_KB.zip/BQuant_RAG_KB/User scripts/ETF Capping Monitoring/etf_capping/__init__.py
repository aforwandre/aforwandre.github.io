"""ETF Capping Monitoring BQuant application."""

from __future__ import annotations

__all__ = ["ETFCappingMonitor"]


def __getattr__(name):
    if name == "ETFCappingMonitor":
        from .app import ETFCappingMonitor

        return ETFCappingMonitor
    raise AttributeError(name)
