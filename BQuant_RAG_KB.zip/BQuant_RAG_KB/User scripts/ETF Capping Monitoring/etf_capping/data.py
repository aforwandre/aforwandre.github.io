"""BQL retrieval for AIM positions, descriptors, and USD pricing.

AIM request shape is frozen from the 2026-08-28 Desktop tests (IMG_6673,
IMG_6674). Isolate that contract in ``_aim_request`` and do not change
item names or parameter placement. Projected is Current plus pending, not
``pending_position()`` alone and not ``ts_position()``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta

import pandas as pd

from .config import (
    AIM_ACCOUNT_BATCH,
    SECURITY_BATCH,
    account_rules_frame,
    account_codes as bundled_account_codes,
    thai_pricing_overrides,
)
from .engine import classify_asset

try:
    import bql
except ImportError:  # Local Cursor validation never executes BQL.
    bql = None


PARSER_VERSION = "2026-09-02d"


@dataclass
class MonitorPayload:
    positions: pd.DataFrame
    errors: list[str] = field(default_factory=list)


def _require_bql():
    if bql is None:
        raise RuntimeError(
            "bql is unavailable. Run this app on Bloomberg BQuant Desktop."
        )
    return bql.Service()


def _chunks(values: list[str], size: int):
    for start in range(0, len(values), size):
        yield values[start : start + size]


def _on_request_error(error_tuple):
    return error_tuple


def _is_response(value) -> bool:
    """Cheap Desktop success test from ``07`` / ``09``.

    ``execute`` / ``execute_many`` may return ``ArrowExecuteResponse``, which
    is valid even when it is not iterable. Requiring ``__iter__`` or
    ``isinstance(..., bql.Response)`` would log a successful Arrow object as
    a request error. Error tuples from ``on_request_error`` are not
    responses. The class-name check is heuristic by design.
    """
    if value is None or isinstance(
        value, (tuple, list, dict, str, bytes, pd.DataFrame, Exception)
    ):
        return False
    return "response" in type(value).__name__.lower()


def _response_items(response) -> list:
    """Return item responses without requiring Arrow response iteration."""
    try:
        count = len(response)
    except Exception:
        count = None
    if count is not None and 0 < count <= 32:
        try:
            items = [response[index] for index in range(count)]
            if items and hasattr(items[0], "df"):
                return items
        except Exception:
            pass
    try:
        items = list(response)
        if items and hasattr(items[0], "df"):
            return items
    except TypeError:
        pass
    if hasattr(response, "single"):
        try:
            item = response.single()
            return [item] if hasattr(item, "df") else []
        except Exception:
            pass
    return []


def _lookup_item(response, name: str):
    candidates = (name, name.upper(), name.lower(), f"{name}()")
    if hasattr(response, "get"):
        for candidate in candidates:
            try:
                item = response.get(candidate)
            except Exception:
                item = None
            if item is not None and hasattr(item, "df"):
                return item
    for candidate in candidates:
        try:
            item = response[candidate]
        except Exception:
            item = None
        if item is not None and hasattr(item, "df"):
            return item
    return None


def _find_column(frame: pd.DataFrame, name: str):
    lookup = {str(column).strip().upper(): column for column in frame.columns}
    return lookup.get(name.upper())


def _item_frame(item, output_name: str | None = None) -> pd.DataFrame:
    raw = item.df().copy()
    index_names = list(raw.index.names)
    if any(name is not None for name in index_names):
        safe_names = []
        for level, name in enumerate(index_names):
            safe_names.append(
                f"__INDEX_{name}_{level}" if name in raw.columns else name
            )
        raw.index.names = safe_names
        raw = raw.reset_index()
    elif "ID" not in raw.columns:
        raw = raw.reset_index()
    item_name = getattr(item, "name", None)
    value_name = output_name or item_name
    id_column = _find_column(raw, "ID")
    date_column = _find_column(raw, "DATE")

    value_column = None
    for candidate in (item_name, output_name, "VALUE"):
        if candidate is not None:
            value_column = _find_column(raw, str(candidate))
            if value_column is not None:
                break
    if value_column is None:
        if output_name is not None:
            return pd.DataFrame()
        metadata = {"ID", "DATE", "CURRENCY", "ORIG_IDS", "REVISION_DATE"}
        remaining = [
            column for column in raw.columns if str(column).upper() not in metadata
        ]
        if len(remaining) != 1:
            return pd.DataFrame()
        value_column = remaining[0]

    if id_column is None:
        candidates = [
            column
            for column in raw.columns
            if column not in {date_column, value_column}
        ]
        id_column = candidates[0] if len(candidates) == 1 else None
    if id_column is None:
        return pd.DataFrame()

    keep = [id_column]
    if date_column is not None:
        keep.append(date_column)
    keep.append(value_column)
    out = raw.loc[:, list(dict.fromkeys(keep))].copy()
    rename = {id_column: "ID", value_column: value_name or str(value_column)}
    if date_column is not None:
        rename[date_column] = "DATE"
    out = out.rename(columns=rename)
    out["ID"] = out["ID"].astype(str)
    if "DATE" in out.columns:
        out["DATE"] = pd.to_datetime(out["DATE"], errors="coerce")
    return out.loc[:, ~out.columns.duplicated()]


def _merge_item_frames(frames: list[pd.DataFrame]) -> pd.DataFrame:
    frames = [frame for frame in frames if frame is not None and not frame.empty]
    if not frames:
        return pd.DataFrame()
    if len(frames) == 1:
        return frames[0]
    merged = frames[0]
    for extra in frames[1:]:
        keys = ["ID"]
        if "DATE" in merged.columns and "DATE" in extra.columns:
            keys.append("DATE")
        if merged.duplicated(keys).any():
            merged = merged.drop_duplicates(keys, keep="last")
        if extra.duplicated(keys).any():
            extra = extra.drop_duplicates(keys, keep="last")
        value_columns = [column for column in extra.columns if column not in keys]
        merged = merged.merge(
            extra[keys + value_columns],
            on=keys,
            how="outer",
        )
    return merged.loc[:, ~merged.columns.duplicated()]


def _response_to_frame(response, item_names: tuple[str, ...]) -> pd.DataFrame:
    frames = []
    for name in item_names:
        item = _lookup_item(response, name)
        if item is not None:
            frames.append(_item_frame(item, output_name=name))
    if frames:
        return _merge_item_frames(frames)

    items = _response_items(response)
    if items:
        return _merge_item_frames([_item_frame(item) for item in items])

    if bql is not None:
        try:
            combined = bql.combined_df(response).reset_index()
            id_column = _find_column(combined, "ID")
            if id_column is not None and id_column != "ID":
                combined = combined.rename(columns={id_column: "ID"})
            if "ID" in combined.columns:
                combined["ID"] = combined["ID"].astype(str)
            return combined
        except Exception:
            pass
    return pd.DataFrame()


def _parse_response(
    response,
    label: str,
    item_names: tuple[str, ...],
    errors: list[str],
) -> pd.DataFrame:
    if not _is_response(response):
        errors.append(
            f"{label}: request failed ({type(response).__name__}: {response})"
        )
        return pd.DataFrame()
    try:
        frame = _response_to_frame(response, item_names)
    except Exception as exc:
        errors.append(f"{label}: {type(exc).__name__}: {exc}")
        return pd.DataFrame()
    if frame is None or frame.empty:
        errors.append(f"{label}: response parsed as empty")
        return pd.DataFrame()
    return frame


def _execute_many(bq, labeled_requests, item_names, errors):
    if not labeled_requests:
        return []
    responses = list(
        bq.execute_many(
            [request for _, request in labeled_requests],
            on_request_error=_on_request_error,
            num_retries=1,
        )
    )
    parsed = []
    for (label, _request), response in zip(labeled_requests, responses):
        parsed.append((label, _parse_response(response, label, item_names, errors)))
    if len(responses) < len(labeled_requests):
        for label, _request in labeled_requests[len(responses) :]:
            errors.append(f"{label}: execute_many returned no response")
        errors.append(
            f"execute_many returned {len(responses)} responses for "
            f"{len(labeled_requests)} requests"
        )
    elif len(responses) > len(labeled_requests):
        errors.append(
            f"execute_many returned {len(responses)} responses for "
            f"{len(labeled_requests)} requests; extra responses were ignored"
        )
    return parsed


def _position_item(bq, position_mode: str):
    # Desktop 2026-08-28 IMG_6673/6674, same with_params, no dates.
    # Current: POSITION_WITHOUT_PENDING().VALUE returned the live book.
    # pending_position().value alone returned all zeros; it is the pending
    # component, not Projected. Projected is Current + Pending, which returned
    # the non-zero book in IMG_6674.
    if position_mode == "Current":
        return bq.data.position_without_pending()["value"]
    if position_mode == "Projected":
        return (
            bq.data.position_without_pending()["value"]
            + bq.data.pending_position()["value"]
        )
    raise ValueError("position_mode must be 'Current' or 'Projected'")


def _aim_request(bq, account: str, position_mode: str):
    """Locked AIM request from the 2026-08-28 Desktop tests.

    ``accounts``, ``pxnum=1377``, and ``profile='DEFAULT_PROFILE'`` stay on
    ``with_params``. Do not move them onto ``members()``. Do not add dates.
    Do not substitute ``param`` for ``pxnum``.
    """
    universe = bq.univ.members(type="AIM")
    return bql.Request(
        universe,
        {"Position": _position_item(bq, position_mode)},
        with_params={
            "accounts": [account],
            "pxnum": 1377,
            "profile": "DEFAULT_PROFILE",
        },
    )


def _previous_weekday(value: date) -> date:
    candidate = value - timedelta(days=1)
    while candidate.weekday() >= 5:
        candidate -= timedelta(days=1)
    return candidate


def _cash_currency_code(ticker) -> str:
    """Return the 3-letter ISO code from a short cash yellow key.

    Only ``USD Curncy`` / ``EUR Curncy`` style tickers qualify. Missing,
    NaN, FFX, or malformed values return '' so the cash FX loop never
    requests ``USDNAN BGNL Curncy``.
    """
    if classify_asset(ticker) != "Cash":
        return ""
    parts = str(ticker).strip().upper().split()
    if len(parts) != 2 or parts[1] != "CURNCY":
        return ""
    code = parts[0]
    if len(code) != 3 or not code.isalpha() or code == "NAN":
        return ""
    return code


def _price_date(price_type: str, today: date) -> date:
    """Bloomberg as-of date for one runbook pricing rule.

    ``today`` is the live calendar date of the refresh, not the UK UI clock.
    Last Close uses the previous weekday, i.e. through yesterday. Exchange
    holidays on that weekday are not listed here: ``px_last`` ``fill='prev'``
    walks back to the last print as of that date, which may be the session
    before yesterday. Real Time uses ``today`` with the same fill, so a
    holiday or not-yet-printed session still carries the last available
    print. A later engine fallback to zero applies only when that request
    returns no usable last price.
    """
    return _previous_weekday(today) if price_type == "Last Close" else today


def _clean_mapping_value(value) -> str:
    text = _clean_reference_value(value)
    if not text:
        return ""
    if text.upper().endswith(" EQUITY"):
        return text
    if len(text.split()) >= 2:
        return f"{text} Equity"
    return ""


def _is_thai_foreign_line(ticker) -> bool:
    if ticker is None or pd.isna(ticker):
        return False
    upper = str(ticker).strip().upper()
    return upper.endswith("/F TB EQUITY") or upper.endswith("-R TB EQUITY")


def _strip_thai_foreign_board(ticker) -> str:
    text = "" if ticker is None or pd.isna(ticker) else str(ticker).strip()
    upper = text.upper()
    for suffix in ("/F TB EQUITY", "-R TB EQUITY"):
        if upper.endswith(suffix):
            return f"{text[:-len(suffix)]} TB Equity"
    return text


def _validated_strip_source(ticker) -> str:
    upper = "" if ticker is None or pd.isna(ticker) else str(ticker).strip().upper()
    if upper.endswith("-R TB EQUITY"):
        return "Validated -R Strip"
    return "Validated /F Strip"


def _is_local_thai_equity(ticker) -> bool:
    text = "" if ticker is None or pd.isna(ticker) else str(ticker).strip()
    upper = text.upper()
    return (
        upper.endswith(" TB EQUITY")
        and "/F" not in upper
        and not upper.endswith("-R TB EQUITY")
    )


def _resolve_pricing_ticker(ticker, thai_local_ticker="") -> str:
    original = "" if ticker is None or pd.isna(ticker) else str(ticker).strip()
    if not _is_thai_foreign_line(original):
        return original
    local = _clean_mapping_value(thai_local_ticker)
    return local if _is_local_thai_equity(local) else ""


def _thai_candidate_tickers(tickers: list[str]) -> list[str]:
    overrides = thai_pricing_overrides()
    candidates = set()
    for ticker in tickers:
        if not _is_thai_foreign_line(ticker):
            continue
        normalized = str(ticker).strip().upper()
        candidates.add(overrides.get(normalized) or _strip_thai_foreign_board(ticker))
    return sorted(candidate for candidate in candidates if candidate)


def _clean_reference_value(value) -> str:
    if value is None or pd.isna(value):
        return ""
    text = str(value).strip()
    upper = text.upper()
    if (
        not text
        or upper.startswith("#N/A")
        or upper in {"FIELD NOT APPLICABLE", "N/A", "NA", "NONE", "NAN"}
    ):
        return ""
    return text


def _fetch_positions(
    bq,
    accounts: list[str],
    position_mode: str,
    errors: list[str],
    progress,
) -> pd.DataFrame:
    labeled_requests = [
        (account, _aim_request(bq, account, position_mode)) for account in accounts
    ]
    rows = []
    total = len(labeled_requests)
    for batch_number, request_batch in enumerate(
        _chunks(labeled_requests, AIM_ACCOUNT_BATCH),
        start=1,
    ):
        if progress is not None:
            progress(
                f"Loading {position_mode.lower()} AIM positions "
                f"({min(batch_number * AIM_ACCOUNT_BATCH, total)}/{total} accounts)…"
            )
        for account, frame in _execute_many(
            bq,
            request_batch,
            ("Position",),
            errors,
        ):
            if frame.empty:
                continue
            required = {"ID", "Position"}
            missing = sorted(required - set(frame.columns))
            if missing:
                errors.append(
                    f"{account}: position response missing columns {missing}; "
                    f"returned {list(frame.columns)}"
                )
                continue
            piece = frame[["ID", "Position"]].copy()
            piece = piece.rename(columns={"ID": "Ticker", "Position": "Quantity"})
            piece["AIM Code"] = account
            rows.append(piece)
    if not rows:
        return pd.DataFrame(columns=["AIM Code", "Ticker", "Quantity"])
    positions = pd.concat(rows, ignore_index=True, sort=False)
    positions["Quantity"] = pd.to_numeric(positions["Quantity"], errors="coerce")
    return positions.groupby(
        ["AIM Code", "Ticker"],
        as_index=False,
        dropna=False,
    )["Quantity"].sum(
        min_count=1,
    )


def _fetch_descriptors(
    bq,
    tickers: list[str],
    errors: list[str],
    progress,
) -> pd.DataFrame:
    if not tickers:
        return pd.DataFrame()
    if progress is not None:
        progress(f"Resolving names and market status for {len(tickers)} securities…")
    items = {
        "Name": bq.data.name(),
        "Market Status": bq.data.market_status(),
    }
    # Do not pass Request mode=cached here. Desktop 2026-09-02: cached
    # market_status() returned Delisted for 6166 HK Equity, while the same
    # item without cached, and FLDS BQL PR286, returned Active.
    requests = [
        (
            f"descriptor_{number}",
            bql.Request(batch, items),
        )
        for number, batch in enumerate(_chunks(tickers, SECURITY_BATCH), start=1)
    ]
    frames = [
        frame
        for _, frame in _execute_many(
            bq,
            requests,
            tuple(items),
            errors,
        )
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame()
    descriptors = pd.concat(frames, ignore_index=True, sort=False)
    descriptors = descriptors.rename(columns={"ID": "Ticker"})
    return descriptors.drop_duplicates("Ticker", keep="last")


def _fetch_fundamental_tickers(
    bq,
    tickers: list[str],
    errors: list[str],
    progress,
) -> pd.DataFrame:
    """Company grouping identity only. HelpDesk DT110/DT679 replacement.

    Official 2026-09-01 tabs confirm ``cast_parent_equity_ticker(mode=null)``
    (CAST parent equity ticker, ID146) and ``id_bb_company(mode=null)``
    (integer company ID, ID035) are not premium. Do not request either here:
    CAST is a parent ticker, and ``id_bb_company()`` is not a yellow key.
    """
    equity_tickers = sorted(
        {
            str(ticker).strip()
            for ticker in tickers
            if classify_asset(ticker) == "Equity"
        }
    )
    if not equity_tickers:
        return pd.DataFrame(columns=["Ticker", "Fundamental Ticker"])
    if progress is not None:
        progress(
            f"Resolving fundamental company mapping for "
            f"{len(equity_tickers)} equities…"
        )
    fundamental_ticker = bq.data.id().value(
        bq.univ.fundamentalticker(),
        mapby="lineage",
    )
    requests = [
        (
            f"fundamental_ticker_{number}",
            bql.Request(
                batch,
                {"Fundamental Ticker": fundamental_ticker},
                with_params={"mode": "cached"},
            ),
        )
        for number, batch in enumerate(
            _chunks(equity_tickers, SECURITY_BATCH),
            start=1,
        )
    ]
    frames = [
        frame
        for _, frame in _execute_many(
            bq,
            requests,
            ("Fundamental Ticker",),
            errors,
        )
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame(columns=["Ticker", "Fundamental Ticker"])
    mappings = pd.concat(frames, ignore_index=True, sort=False)
    mappings = mappings.rename(columns={"ID": "Ticker"})
    return mappings[["Ticker", "Fundamental Ticker"]].drop_duplicates(
        "Ticker",
        keep="last",
    )


def _select_thai_pricing_tickers(
    tickers: list[str],
    security_cache: pd.DataFrame,
) -> pd.DataFrame:
    columns = [
        "Ticker",
        "Thai Local Pricing Ticker",
        "Thai Price Mapping",
        "Pricing Market Status",
        "Thai Mapping Note",
    ]
    thai_foreign_lines = sorted(
        {str(ticker).strip() for ticker in tickers if _is_thai_foreign_line(ticker)}
    )
    if not thai_foreign_lines:
        return pd.DataFrame(columns=columns)
    overrides = thai_pricing_overrides()
    cache = (
        security_cache.drop_duplicates("Ticker", keep="last").set_index("Ticker")
        if not security_cache.empty and "Ticker" in security_cache.columns
        else pd.DataFrame()
    )

    def cache_value(ticker: str, column: str) -> str:
        if cache.empty or ticker not in cache.index or column not in cache.columns:
            return ""
        return _clean_reference_value(cache.at[ticker, column])

    def fundamental_value(ticker: str) -> str:
        return _clean_mapping_value(cache_value(ticker, "Fundamental Ticker"))

    def candidate_exists(ticker: str) -> bool:
        return any(
            cache_value(ticker, column)
            for column in (
                "Name",
                "Market Status",
            )
        )

    def row(
        ticker: str,
        local_ticker: str,
        source: str,
        note: str = "",
    ) -> dict[str, str]:
        return {
            "Ticker": ticker,
            "Thai Local Pricing Ticker": local_ticker,
            "Thai Price Mapping": source,
            "Pricing Market Status": cache_value(
                local_ticker,
                "Market Status",
            ),
            "Thai Mapping Note": note,
        }

    rows = []
    for ticker in thai_foreign_lines:
        normalized = ticker.upper()
        override = _clean_mapping_value(overrides.get(normalized, ""))
        if override:
            if _is_local_thai_equity(override) and candidate_exists(override):
                rows.append(row(ticker, override, "Approved Override"))
            else:
                rows.append(
                    row(
                        ticker,
                        "",
                        "Unresolved",
                        f"Approved override {override} returned no reference data.",
                    )
                )
            continue
        original_fundamental = fundamental_value(ticker)
        candidate = _strip_thai_foreign_board(ticker)
        candidate_fundamental = fundamental_value(candidate)
        if (
            _is_local_thai_equity(candidate)
            and candidate_exists(candidate)
            and original_fundamental
            and candidate_fundamental
            and original_fundamental.upper() == candidate_fundamental.upper()
        ):
            rows.append(row(ticker, candidate, _validated_strip_source(ticker)))
            continue
        rows.append(
            row(
                ticker,
                "",
                "Unresolved",
                f"Candidate {candidate} did not return usable reference data "
                "for the same fundamental ticker; HelpDesk DRSK leftover "
                "mapping may still apply.",
            )
        )
    return pd.DataFrame(rows, columns=columns).drop_duplicates(
        "Ticker",
        keep="last",
    )


def _fetch_thai_drsk_mappings(
    bq,
    tickers: list[str],
    errors: list[str],
    progress,
) -> pd.DataFrame:
    """Official leftover mapper. Thai foreign lines only.

    Official BQL tab (IMG_6671): ``bb_default_risk_obligor_ticker(mode=null)``.
    Desktop 2026-08-28 (IMG_6672): the item plus Request ``mode='cached'``
    returns a string ticker that often omits the yellow-key ``Equity`` suffix.
    Do not copy that probe's mixed NVDA/SKM/cash/index universe.
    """
    leftover = sorted(
        {str(ticker).strip() for ticker in tickers if _is_thai_foreign_line(ticker)}
    )
    columns = ["Ticker", "Thai Local Pricing Ticker"]
    if not leftover:
        return pd.DataFrame(columns=columns)
    if progress is not None:
        progress(
            f"Resolving leftover Thai local lines via HelpDesk-confirmed "
            f"obligor ticker for {len(leftover)} securities…"
        )
    requests = [
        (
            f"thai_drsk_{number}",
            bql.Request(
                batch,
                {
                    "Thai Local Pricing Ticker": (
                        bq.data.bb_default_risk_obligor_ticker(mode="cached")
                    )
                },
                with_params={"mode": "cached"},
            ),
        )
        for number, batch in enumerate(
            _chunks(leftover, SECURITY_BATCH),
            start=1,
        )
    ]
    frames = [
        frame
        for _, frame in _execute_many(
            bq,
            requests,
            ("Thai Local Pricing Ticker",),
            errors,
        )
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame(columns=columns)
    mappings = pd.concat(frames, ignore_index=True, sort=False)
    if "DATE" in mappings.columns:
        mappings = mappings.sort_values("DATE")
    mappings = mappings.rename(columns={"ID": "Ticker"})
    mappings["Thai Local Pricing Ticker"] = mappings["Thai Local Pricing Ticker"].map(
        _clean_mapping_value
    )
    local = mappings["Thai Local Pricing Ticker"].map(_is_local_thai_equity)
    mappings = mappings.loc[local, columns]
    return mappings.drop_duplicates("Ticker", keep="last")


def _apply_helpdesk_drsk(
    selected: pd.DataFrame,
    drsk: pd.DataFrame,
    security_cache: pd.DataFrame,
) -> pd.DataFrame:
    if selected.empty or drsk.empty:
        return selected
    out = selected.copy()
    cache = (
        security_cache.drop_duplicates("Ticker", keep="last").set_index("Ticker")
        if not security_cache.empty and "Ticker" in security_cache.columns
        else pd.DataFrame()
    )
    local_by_ticker = drsk.drop_duplicates("Ticker", keep="last").set_index("Ticker")[
        "Thai Local Pricing Ticker"
    ]

    def cache_value(ticker: str, column: str) -> str:
        if cache.empty or ticker not in cache.index or column not in cache.columns:
            return ""
        return _clean_reference_value(cache.at[ticker, column])

    unresolved = out["Thai Price Mapping"].eq("Unresolved")
    for index in out.index[unresolved]:
        ticker = str(out.at[index, "Ticker"]).strip()
        local = _clean_mapping_value(local_by_ticker.get(ticker, ""))
        if not _is_local_thai_equity(local):
            continue
        if not any(cache_value(local, column) for column in ("Name", "Market Status")):
            continue
        out.at[index, "Thai Local Pricing Ticker"] = local
        out.at[index, "Thai Price Mapping"] = "HelpDesk DRSK"
        out.at[index, "Pricing Market Status"] = cache_value(
            local,
            "Market Status",
        )
        out.at[index, "Thai Mapping Note"] = ""
    return out


def _concat_reference_cache(
    base: pd.DataFrame,
    extra: pd.DataFrame,
) -> pd.DataFrame:
    if extra is None or extra.empty:
        return base if base is not None else pd.DataFrame()
    if base is None or base.empty:
        return extra
    combined = pd.concat([base, extra], ignore_index=True, sort=False)
    return combined.drop_duplicates("Ticker", keep="last")


def _extend_security_cache(
    bq,
    descriptors: pd.DataFrame,
    extra_tickers: list[str],
    errors: list[str],
    progress,
) -> pd.DataFrame:
    existing = set()
    if (
        descriptors is not None
        and not descriptors.empty
        and "Ticker" in descriptors.columns
    ):
        existing = set(descriptors["Ticker"].dropna().astype(str).str.strip())
    missing = sorted(
        {
            str(ticker).strip()
            for ticker in extra_tickers
            if str(ticker).strip() and str(ticker).strip() not in existing
        }
    )
    if not missing:
        return descriptors if descriptors is not None else pd.DataFrame()
    extra_descriptors = _fetch_descriptors(bq, missing, errors, progress)
    extra_fundamentals = _fetch_fundamental_tickers(
        bq,
        missing,
        errors,
        progress,
    )
    extra_cache = extra_descriptors
    if not extra_fundamentals.empty:
        if extra_cache is None or extra_cache.empty:
            extra_cache = extra_fundamentals
        else:
            extra_cache = extra_cache.merge(
                extra_fundamentals,
                on="Ticker",
                how="outer",
                validate="one_to_one",
            )
    if extra_cache is None or extra_cache.empty:
        return descriptors if descriptors is not None else pd.DataFrame()
    if "Fundamental Ticker" in extra_cache.columns:
        extra_cache["Fundamental Ticker"] = extra_cache["Fundamental Ticker"].map(
            _clean_mapping_value
        )
    return _concat_reference_cache(descriptors, extra_cache)


def _leftover_thai_tickers(selected: pd.DataFrame) -> list[str]:
    if selected is None or selected.empty:
        return []
    unresolved = selected["Thai Price Mapping"].eq("Unresolved")
    return sorted(
        {
            str(ticker).strip()
            for ticker in selected.loc[unresolved, "Ticker"]
            if _is_thai_foreign_line(ticker)
        }
    )


def _fetch_fundamental_names(
    bq,
    descriptors: pd.DataFrame,
    errors: list[str],
) -> pd.DataFrame:
    if descriptors.empty or "Fundamental Ticker" not in descriptors.columns:
        return pd.DataFrame(columns=["Fundamental Ticker", "Fundamental Name"])
    fundamental_tickers = sorted(
        {
            str(value).strip()
            for value in descriptors["Fundamental Ticker"]
            if value is not None and not pd.isna(value) and str(value).strip()
        }
    )
    requests = [
        (
            f"fundamental_name_{number}",
            bql.Request(
                batch,
                {"Fundamental Name": bq.data.name()},
                with_params={"mode": "cached"},
            ),
        )
        for number, batch in enumerate(
            _chunks(fundamental_tickers, SECURITY_BATCH),
            start=1,
        )
    ]
    frames = [
        frame
        for _, frame in _execute_many(
            bq,
            requests,
            ("Fundamental Name",),
            errors,
        )
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame(columns=["Fundamental Ticker", "Fundamental Name"])
    names = pd.concat(frames, ignore_index=True, sort=False)
    names = names.rename(columns={"ID": "Fundamental Ticker"})
    return names.drop_duplicates("Fundamental Ticker", keep="last")


def _fetch_security_prices(
    bq,
    positions: pd.DataFrame,
    runbook: pd.DataFrame,
    today: date,
    errors: list[str],
    progress,
) -> pd.DataFrame:
    base = positions.merge(
        runbook[["AIM Code", "Type"]],
        on="AIM Code",
        how="left",
        validate="many_to_one",
    )
    base["Asset"] = base["Ticker"].map(classify_asset)
    if "Pricing Ticker" not in base.columns:
        base["Pricing Ticker"] = base["Ticker"]
    else:
        base["Pricing Ticker"] = (
            base["Pricing Ticker"].fillna("").astype(str).str.strip()
        )
    requests = []
    ticker_maps = []
    for price_type, group in base.groupby("Type", dropna=False):
        if price_type not in {"Last Close", "Real Time"}:
            continue
        price_date = _price_date(price_type, today)
        ticker_map = (
            group.loc[
                ~group["Asset"].isin(["Cash", "FFX", "Index Future"])
                & ~group.get(
                    "Reference Data Issue",
                    pd.Series(False, index=group.index),
                ).fillna(False)
                & group["Pricing Ticker"].fillna("").ne(""),
                ["Ticker", "Pricing Ticker"],
            ]
            .dropna()
            .drop_duplicates()
        )
        ticker_map["Type"] = price_type
        ticker_maps.append(ticker_map)
        tickers = sorted(ticker_map["Pricing Ticker"].unique())
        for number, batch in enumerate(_chunks(tickers, SECURITY_BATCH), start=1):
            price_item = bq.data.px_last(
                dates=price_date.isoformat(),
                currency="USD",
                fill="prev",
            )
            params = {"mode": "cached"} if price_type == "Last Close" else None
            request = (
                bql.Request(
                    batch,
                    {"Price USD": price_item},
                    with_params=params,
                )
                if params
                else bql.Request(batch, {"Price USD": price_item})
            )
            requests.append(
                (
                    f"price::{price_type}::{price_date.isoformat()}::{number}",
                    request,
                )
            )
    if progress is not None:
        progress("Loading USD prices by account pricing rule…")
    frames = []
    for label, frame in _execute_many(
        bq,
        requests,
        ("Price USD",),
        errors,
    ):
        if frame.empty:
            continue
        _, price_type, date_text, _ = label.split("::")
        piece = frame.rename(columns={"ID": "Pricing Ticker"})
        if "DATE" in piece.columns:
            piece = piece.sort_values("DATE").drop_duplicates(
                "Pricing Ticker",
                keep="last",
            )
            piece["Price Date"] = piece["DATE"].fillna(pd.Timestamp(date_text))
        else:
            piece["Price Date"] = pd.Timestamp(date_text)
        piece["Type"] = price_type
        frames.append(piece[["Pricing Ticker", "Type", "Price Date", "Price USD"]])
    output_frames = []
    if frames and ticker_maps:
        prices = pd.concat(frames, ignore_index=True, sort=False).drop_duplicates(
            ["Pricing Ticker", "Type"],
            keep="last",
        )
        mapping = pd.concat(
            ticker_maps,
            ignore_index=True,
            sort=False,
        )
        pricing_counts = (
            mapping.groupby(["Ticker", "Type"], dropna=False)["Pricing Ticker"]
            .nunique()
            .reset_index(name="_Pricing Count")
        )
        ambiguous = pricing_counts.loc[pricing_counts["_Pricing Count"].gt(1)]
        for _, row in ambiguous.iterrows():
            errors.append(
                f"price mapping::{row['Type']}::{row['Ticker']}: "
                "multiple Pricing Tickers; price was left unresolved"
            )
        mapping = (
            mapping.merge(
                pricing_counts,
                on=["Ticker", "Type"],
                how="left",
                validate="many_to_one",
            )
            .loc[lambda frame: frame["_Pricing Count"].eq(1)]
            .drop(columns="_Pricing Count")
            .drop_duplicates(
                ["Ticker", "Type"],
                keep="last",
            )
        )
        mapped_prices = mapping.merge(
            prices,
            on=["Pricing Ticker", "Type"],
            how="left",
            validate="many_to_one",
        )
        output_frames.append(
            mapped_prices[["Ticker", "Type", "Price Date", "Price USD"]]
        )
    if not output_frames:
        return pd.DataFrame(columns=["Ticker", "Type", "Price Date", "Price USD"])
    return pd.concat(
        output_frames,
        ignore_index=True,
        sort=False,
    ).drop_duplicates(
        ["Ticker", "Type"],
        keep="last",
    )


def _fetch_cash_prices(
    bq,
    positions: pd.DataFrame,
    runbook: pd.DataFrame,
    today: date,
    errors: list[str],
    progress,
) -> pd.DataFrame:
    base = positions.merge(
        runbook[["AIM Code", "Type"]],
        on="AIM Code",
        how="left",
        validate="many_to_one",
    )
    base["Asset"] = base["Ticker"].map(classify_asset)
    cash = base.loc[base["Asset"].eq("Cash"), ["Ticker", "Type"]].drop_duplicates()
    if cash.empty:
        return pd.DataFrame(columns=["Ticker", "Type", "Price Date", "Price USD"])

    requests = []
    labels = {}
    usd_rows = []
    for price_type, group in cash.groupby("Type", dropna=False):
        if price_type not in {"Last Close", "Real Time"}:
            continue
        price_date = _price_date(price_type, today)
        for ticker in group["Ticker"].dropna():
            currency = _cash_currency_code(ticker)
            if not currency:
                errors.append(
                    f"cash::{price_type}: skipped malformed cash ticker {ticker!r}"
                )
                continue
            if currency == "USD":
                usd_rows.append(
                    {
                        "Ticker": ticker,
                        "Type": price_type,
                        "Price Date": pd.Timestamp(price_date),
                        "Price USD": 1.0,
                    }
                )
                continue
            fx_ticker = f"USD{currency} BGNL Curncy"
            label = f"cashfx::{price_type}::{price_date.isoformat()}::{ticker}"
            price_item = bq.data.px_last(
                dates=price_date.isoformat(),
                fill="prev",
            )
            requests.append(
                (label, bql.Request(fx_ticker, {"USD per Local FX": price_item}))
            )
            labels[label] = ticker
    if progress is not None:
        progress("Converting cash balances to USD…")
    rows = list(usd_rows)
    for label, frame in _execute_many(
        bq,
        requests,
        ("USD per Local FX",),
        errors,
    ):
        if frame.empty:
            continue
        _, price_type, date_text, _ = label.split("::", 3)
        rate_frame = frame.copy()
        rate_frame["USD per Local FX"] = pd.to_numeric(
            rate_frame["USD per Local FX"],
            errors="coerce",
        )
        rate_frame = rate_frame.dropna(subset=["USD per Local FX"])
        if "DATE" in rate_frame.columns:
            rate_frame = rate_frame.sort_values("DATE")
        if rate_frame.empty or rate_frame.iloc[-1]["USD per Local FX"] == 0:
            errors.append(f"{label}: FX rate missing or zero")
            continue
        last = rate_frame.iloc[-1]
        actual_date = (
            last["DATE"]
            if "DATE" in rate_frame.columns and pd.notna(last["DATE"])
            else pd.Timestamp(date_text)
        )
        rows.append(
            {
                "Ticker": labels[label],
                "Type": price_type,
                "Price Date": pd.Timestamp(actual_date),
                "Price USD": 1.0 / float(last["USD per Local FX"]),
            }
        )
    return pd.DataFrame(
        rows,
        columns=["Ticker", "Type", "Price Date", "Price USD"],
    )


def fetch_monitor_payload(
    position_mode: str,
    accounts: list[str] | None = None,
    progress=None,
    today: date | None = None,
) -> MonitorPayload:
    """Fetch and normalize all inputs required by the capping engine."""
    bq = _require_bql()
    selected_accounts = list(accounts or bundled_account_codes())
    errors: list[str] = []
    # Live request calendar. Independent of the UK display clock in app.py.
    as_of = today or date.today()

    positions = _fetch_positions(
        bq,
        selected_accounts,
        position_mode,
        errors,
        progress,
    )
    if positions.empty:
        return MonitorPayload(positions=positions, errors=errors)
    returned_accounts = set(positions["AIM Code"].dropna().astype(str))
    missing_accounts = [
        account for account in selected_accounts if account not in returned_accounts
    ]
    if missing_accounts:
        errors.append(
            "AIM accounts returned no usable position rows: "
            + ", ".join(missing_accounts)
        )

    tickers = sorted(positions["Ticker"].dropna().astype(str).unique())
    thai_candidates = _thai_candidate_tickers(tickers)
    security_cache_tickers = sorted(set(tickers).union(thai_candidates))
    descriptors = _fetch_descriptors(
        bq,
        security_cache_tickers,
        errors,
        progress,
    )
    fundamental_tickers = _fetch_fundamental_tickers(
        bq,
        security_cache_tickers,
        errors,
        progress,
    )
    if not fundamental_tickers.empty:
        if descriptors.empty:
            descriptors = fundamental_tickers
        else:
            descriptors = descriptors.merge(
                fundamental_tickers,
                on="Ticker",
                how="outer",
                validate="one_to_one",
            )
    if not descriptors.empty:
        if "Fundamental Ticker" in descriptors.columns:
            descriptors["Fundamental Ticker"] = descriptors["Fundamental Ticker"].map(
                _clean_mapping_value
            )
    thai_pricing_tickers = _select_thai_pricing_tickers(
        tickers,
        descriptors,
    )
    leftover_thai = _leftover_thai_tickers(thai_pricing_tickers)
    if leftover_thai:
        drsk = _fetch_thai_drsk_mappings(
            bq,
            leftover_thai,
            errors,
            progress,
        )
        extra_locals = []
        if not drsk.empty:
            extra_locals = [
                local
                for local in drsk["Thai Local Pricing Ticker"].map(_clean_mapping_value)
                if _is_local_thai_equity(local)
            ]
        descriptors = _extend_security_cache(
            bq,
            descriptors,
            extra_locals,
            errors,
            progress,
        )
        thai_pricing_tickers = _apply_helpdesk_drsk(
            thai_pricing_tickers,
            drsk,
            descriptors,
        )
    if not descriptors.empty:
        position_descriptors = descriptors.loc[
            descriptors["Ticker"].isin(tickers)
        ].copy()
        fundamental_names = _fetch_fundamental_names(
            bq,
            position_descriptors,
            errors,
        )
        if (
            not fundamental_names.empty
            and "Fundamental Ticker" in position_descriptors.columns
        ):
            position_descriptors = position_descriptors.merge(
                fundamental_names,
                on="Fundamental Ticker",
                how="left",
                validate="many_to_one",
            )
        positions = positions.merge(
            position_descriptors,
            on="Ticker",
            how="left",
            validate="many_to_one",
        )
    if not thai_pricing_tickers.empty:
        positions = positions.merge(
            thai_pricing_tickers,
            on="Ticker",
            how="left",
            validate="many_to_one",
        )
    if "Thai Local Pricing Ticker" not in positions.columns:
        positions["Thai Local Pricing Ticker"] = ""
    if "Thai Price Mapping" not in positions.columns:
        positions["Thai Price Mapping"] = ""
    if "Market Status" not in positions.columns:
        positions["Market Status"] = ""
    if "Pricing Market Status" not in positions.columns:
        positions["Pricing Market Status"] = ""
    if "Thai Mapping Note" not in positions.columns:
        positions["Thai Mapping Note"] = ""
    is_equity = positions["Ticker"].map(classify_asset).eq("Equity")
    has_reference_data = positions.get(
        "Name", pd.Series("", index=positions.index)
    ).map(_clean_reference_value).ne("") | positions["Market Status"].map(
        _clean_reference_value
    ).ne(
        ""
    )
    positions["Reference Data Issue"] = is_equity & ~has_reference_data
    positions["Pricing Ticker"] = [
        _resolve_pricing_ticker(ticker, thai_local_ticker)
        for ticker, thai_local_ticker in zip(
            positions["Ticker"],
            positions["Thai Local Pricing Ticker"],
        )
    ]
    positions["Price Mapping"] = positions["Thai Price Mapping"].fillna("")
    non_thai = ~positions["Ticker"].map(_is_thai_foreign_line)
    positions.loc[non_thai, "Price Mapping"] = "Original Ticker"
    positions.loc[non_thai, "Pricing Market Status"] = positions.loc[
        non_thai,
        "Market Status",
    ]
    unresolved_thai = ~non_thai & positions["Pricing Ticker"].fillna("").eq("")
    positions.loc[unresolved_thai, "Price Mapping"] = "Unresolved"

    runbook = account_rules_frame()
    security_prices = _fetch_security_prices(
        bq,
        positions,
        runbook,
        as_of,
        errors,
        progress,
    )
    cash_prices = _fetch_cash_prices(
        bq,
        positions,
        runbook,
        as_of,
        errors,
        progress,
    )
    prices = pd.concat(
        [security_prices, cash_prices],
        ignore_index=True,
        sort=False,
    )
    positions = positions.merge(
        runbook[["AIM Code", "Type"]],
        on="AIM Code",
        how="left",
        validate="many_to_one",
    )
    if not prices.empty:
        positions = positions.merge(
            prices,
            on=["Ticker", "Type"],
            how="left",
            validate="many_to_one",
        )
    else:
        positions["Price Date"] = pd.NaT
        positions["Price USD"] = pd.NA

    positions.loc[
        positions["Ticker"].map(classify_asset).isin(["Index Future", "FFX"]),
        "Price USD",
    ] = 0.0
    positions = positions.drop(columns=["Type"], errors="ignore")
    if progress is not None:
        progress(
            f"Loaded {len(positions):,} position rows across "
            f"{positions['AIM Code'].nunique()} accounts."
        )
    return MonitorPayload(positions=positions, errors=errors)
