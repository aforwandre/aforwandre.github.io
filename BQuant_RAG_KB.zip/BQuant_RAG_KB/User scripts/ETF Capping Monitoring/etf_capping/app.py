"""Interactive BQuant Desktop dashboard for ETF position capping."""

from __future__ import annotations

from datetime import datetime, timezone
from functools import partial
from html import escape
import re

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import ipywidgets as widgets
from IPython.display import clear_output
from ipydatagrid import DataGrid, TextRenderer

try:
    from ipydatagrid import VegaExpr
except ImportError:
    VegaExpr = None
try:
    from ipydatagrid import Expr
except ImportError:
    Expr = None

from .config import (
    STATUS_COLORS,
    WARNING_RATIO,
    account_rules_frame,
    exception_rules_frame,
    thai_pricing_rules_frame,
)
from .data import fetch_monitor_payload
from .engine import (
    MonitorResult,
    calculate_monitor,
    monitor_weight_tone,
    select_monitor_groups,
)


def _now_uk() -> datetime:
    """UK wall-clock for UI, logs, and CSV filenames only.

    Do not pass this timestamp into BQL. Price and position requests use the
    live calendar date in ``data.fetch_monitor_payload``.
    """
    try:
        from zoneinfo import ZoneInfo

        return datetime.now(ZoneInfo("Europe/London"))
    except Exception:
        return datetime.now(timezone.utc)


def _format_now_uk(fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    now = _now_uk()
    tz_label = now.tzname() or "UK"
    return f"{now.strftime(fmt)} {tz_label}"


def _text(value) -> str:
    if value is None or pd.isna(value):
        return ""
    return str(value)


def _short_ticker(value) -> str:
    return _text(value).replace(" Equity", "").replace(" Curncy", "").strip()


def _fmt_pct(value, signed: bool = False) -> str:
    if value is None or pd.isna(value):
        return "—"
    sign = "+" if signed else ""
    return f"{float(value):{sign}.2%}"


def _pct_cell_label(value) -> str:
    """Display text for a Monitor weight cell. Same path as MDX Signal / Status."""
    if value is None or pd.isna(value):
        return ""
    return f"{float(value):.2%}"


def _fmt_number(value) -> str:
    if value is None or pd.isna(value):
        return "—"
    return f"{float(value):,.2f}"


def _fmt_date(value) -> str:
    if value is None or pd.isna(value):
        return ""
    return pd.Timestamp(value).strftime("%Y-%m-%d")


FULL_POSITION_COLUMNS = (
    "AIM Code",
    "Fund Name",
    "Asset",
    "Ticker",
    "NAME",
    "Parent/Issuer Ticker",
    "Parent/Issuer Name",
    "Quantity",
    "Price Date",
    "AIM Image",
    "Ccy",
    "USD Price",
    "MV(USD)",
    "Weight",
    "Agg Wgt (incl cash)",
    "Agg Wgt (ex cash)",
    "Capping",
    "Largest",
    "Rank",
    "Level",
    "Type",
    "Primary FM",
)
FULL_POSITION_NUMERIC_COLUMNS = {
    "Quantity",
    "USD Price",
    "MV(USD)",
    "Weight",
    "Agg Wgt (incl cash)",
    "Agg Wgt (ex cash)",
    "Capping",
    "Largest",
    "Rank",
}
FULL_POSITION_PERCENT_COLUMNS = {
    "Weight",
    "Agg Wgt (incl cash)",
    "Agg Wgt (ex cash)",
    "Capping",
    "Largest",
}
FULL_POSITION_ADVANCED_COLUMNS = tuple(
    column for column in FULL_POSITION_COLUMNS if column != "NAME"
)
HOLDING_COLORS = (
    "#7aa2f7",
    "#63d4a6",
    "#f5a623",
    "#b388ff",
    "#ff7777",
    "#5bc0be",
    "#f78c6c",
    "#82aaff",
    "#c3e88d",
    "#c792ea",
    "#89ddff",
    "#ffcb6b",
)
# Same Status cell colours: Breach / Near Limit / unflagged (OK).
MONITOR_WEIGHT_BG = {"B": "#4a2027", "N": "#4b3a20", "O": "#151a25"}
MONITOR_WEIGHT_FG = {"B": "#ff7777", "N": "#ffc45c", "O": "#9aa4b5"}
_MAX_VEGA_ROW_EXPR = 80_000


def _monitor_weight_tones(groups: pd.DataFrame, weight_column: str) -> list[str]:
    if groups is None or groups.empty:
        return []
    ranks = pd.to_numeric(groups["Rank"], errors="coerce")
    caps = pd.to_numeric(groups["Capping"], errors="coerce")
    weights = pd.to_numeric(groups[weight_column], errors="coerce")
    statuses = groups["Status"]
    return [
        monitor_weight_tone(weight, cap, rank, status)
        for weight, cap, rank, status in zip(
            weights.tolist(),
            caps.tolist(),
            ranks.tolist(),
            statuses.tolist(),
        )
    ]


def _vega_row_color_source(
    tones: list[str], palette: dict[str, str], fallback: str
) -> str | None:
    """0-based ``cell.row`` colour tree. Bond Ownership Dashboard uses ``cell.row % 2``."""
    if not tones:
        return None
    colors = [palette.get(tone, fallback) for tone in tones]

    def tree(lo: int, hi: int) -> str:
        if hi - lo == 1:
            return f"'{colors[lo]}'"
        mid = (lo + hi) // 2
        return f"(cell.row < {mid} ? {tree(lo, mid)} : {tree(mid, hi)})"

    return tree(0, len(colors))


def _python_row_color_source(
    tones: list[str], palette: dict[str, str], fallback: str
) -> str | None:
    """Relative Strength Finder ``Expr`` syntax: Python if/else on ``cell.row``."""
    if not tones:
        return None
    expr = f"'{fallback}'"
    for index, tone in reversed(list(enumerate(tones))):
        color = palette.get(tone, fallback)
        expr = f"'{color}' if cell.row == {index} else ({expr})"
    return expr


def _vega_row_color_expr(tones: list[str], palette: dict[str, str], fallback: str):
    source = _vega_row_color_source(tones, palette, fallback)
    if (
        source is not None
        and len(source) <= _MAX_VEGA_ROW_EXPR
        and VegaExpr is not None
    ):
        try:
            return VegaExpr(source)
        except Exception:
            pass
    python_source = _python_row_color_source(tones, palette, fallback)
    if (
        python_source is not None
        and len(python_source) <= _MAX_VEGA_ROW_EXPR
        and Expr is not None
    ):
        try:
            return Expr(python_source)
        except Exception:
            pass
    return None


def _status_renderer() -> TextRenderer:
    status = TextRenderer(font="bold 11px sans-serif")
    if VegaExpr is None:
        return status
    try:
        return TextRenderer(
            font="bold 11px sans-serif",
            text_color=VegaExpr(
                "cell.value === 'Breach' ? '#ff7777' : "
                "cell.value === 'Near Limit' ? '#ffc45c' : "
                "cell.value === 'Data Issue' ? '#c7a4ff' : '#9aa4b5'"
            ),
            background_color=VegaExpr(
                "cell.value === 'Breach' ? '#4a2027' : "
                "cell.value === 'Near Limit' ? '#4b3a20' : "
                "cell.value === 'Data Issue' ? '#35264c' : '#151a25'"
            ),
        )
    except Exception:
        return status


def _weight_cell_renderer(tones: list[str]) -> TextRenderer:
    """Show Incl/Ex as cell text. Do not attach VegaExpr colours here.

    Desktop blanks those columns when VegaExpr text/background colour is set,
    even with Bond-style text_value. Cap still uses format=".2%" without
    VegaExpr. Status and alert chips keep the red/amber action colours.
    ``tones`` is kept so the caller does not change.
    """
    _ = tones
    return TextRenderer(
        horizontal_alignment="right",
        font="bold 11px sans-serif",
        text_color="#e8edf5",
        background_color="#151a25",
    )


def _documentation_html() -> str:
    return """
    <style>
      .etf-doc {
        color:#dce1ea; background:#121722; border:1px solid #252d3d;
        border-radius:12px; padding:18px 20px; font:12px/1.55 sans-serif;
      }
      .etf-doc h2 {color:#f3f5f8; font-size:19px; margin:0 0 4px;}
      .etf-doc h3 {
        color:#9fc5ff; font-size:14px; margin:20px 0 7px;
        padding-bottom:5px; border-bottom:1px solid #293142;
      }
      .etf-doc h4 {color:#e8edf5; font-size:12px; margin:12px 0 4px;}
      .etf-doc p {margin:5px 0 8px;}
      .etf-doc ul, .etf-doc ol {margin:5px 0 8px 20px; padding:0;}
      .etf-doc li {margin:3px 0;}
      .etf-doc code {
        color:#b8d7ff; background:#1c2433; border-radius:4px;
        padding:1px 4px;
      }
      .etf-doc .note {
        background:#1a2331; border-left:3px solid #7aa2f7;
        padding:8px 10px; margin:8px 0; border-radius:4px;
      }
      .etf-doc .warn {
        background:#2b2418; border-left:3px solid #f5a623;
        padding:8px 10px; margin:8px 0; border-radius:4px;
      }
      .etf-doc .formula {
        display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
        gap:7px; margin:8px 0;
      }
      .etf-doc .formula div {
        background:#171d2b; border:1px solid #293142;
        border-radius:7px; padding:8px 10px;
      }
      .etf-doc table {width:100%; border-collapse:collapse; margin:7px 0;}
      .etf-doc th {
        background:#202737; color:#eef1f6; text-align:left;
        padding:6px 8px; border:1px solid #30394c;
      }
      .etf-doc td {padding:6px 8px; border:1px solid #293142;}
      .etf-doc details {margin-top:8px;}
      .etf-doc summary {color:#9fc5ff; cursor:pointer;}
      .etf-doc pre {
        white-space:pre-wrap; color:#cbd5e5; background:#0f141d;
        border:1px solid #293142; border-radius:6px; padding:10px;
      }
    </style>
    <div class="etf-doc">
      <h2>ETF Capping Monitor — Calculation Documentation</h2>
      <p>
        This page describes the implemented BQuant Desktop workflow. It is a
        read-only explanation: opening this tab does not run BQL or recalculate
        the monitor.
      </p>

      <h3>1. End-to-end flow</h3>
      <svg viewBox="0 0 1060 310" width="100%" role="img"
           aria-label="ETF capping calculation flow">
        <defs>
          <marker id="etf-arrow" markerWidth="8" markerHeight="8"
                  refX="7" refY="4" orient="auto">
            <path d="M0,0 L8,4 L0,8 Z" fill="#7aa2f7"></path>
          </marker>
        </defs>
        <g fill="#182131" stroke="#34425a" stroke-width="1.5">
          <rect x="15"  y="25"  width="230" height="85" rx="10"></rect>
          <rect x="280" y="25"  width="230" height="85" rx="10"></rect>
          <rect x="545" y="25"  width="230" height="85" rx="10"></rect>
          <rect x="810" y="25"  width="230" height="85" rx="10"></rect>
          <rect x="810" y="190" width="230" height="85" rx="10"></rect>
          <rect x="545" y="190" width="230" height="85" rx="10"></rect>
          <rect x="280" y="190" width="230" height="85" rx="10"></rect>
          <rect x="15"  y="190" width="230" height="85" rx="10"></rect>
        </g>
        <g fill="#eef1f6" font-family="sans-serif" text-anchor="middle">
          <text x="130" y="55" font-size="14" font-weight="700">AIM input</text>
          <text x="130" y="77" font-size="11">54 accounts + Current/Projected</text>
          <text x="130" y="94" font-size="11">Runbook rules</text>

          <text x="395" y="55" font-size="14" font-weight="700">Reference data</text>
          <text x="395" y="77" font-size="11">Name + Market Status</text>
          <text x="395" y="94" font-size="11">Company and Thai validation</text>

          <text x="660" y="55" font-size="14" font-weight="700">Approved USD price</text>
          <text x="660" y="77" font-size="11">Held line or Thai local line</text>
          <text x="660" y="94" font-size="11">Cash FX via BGNL</text>

          <text x="925" y="55" font-size="14" font-weight="700">Position valuation</text>
          <text x="925" y="77" font-size="11">Quantity × USD Price</text>
          <text x="925" y="94" font-size="11">Security-level Weight</text>

          <text x="925" y="220" font-size="14" font-weight="700">Company key</text>
          <text x="925" y="242" font-size="11">Exception → Fundamental</text>
          <text x="925" y="259" font-size="11">→ Original ticker</text>

          <text x="660" y="220" font-size="14" font-weight="700">Aggregate</text>
          <text x="660" y="242" font-size="11">Company MV and weights</text>
          <text x="660" y="259" font-size="11">Including / excluding cash</text>

          <text x="395" y="220" font-size="14" font-weight="700">Capping test</text>
          <text x="395" y="242" font-size="11">Rank + dynamic limit</text>
          <text x="395" y="259" font-size="11">Breach / Near / OK</text>

          <text x="130" y="220" font-size="14" font-weight="700">Application output</text>
          <text x="130" y="242" font-size="11">Monitor + Full Positions</text>
          <text x="130" y="259" font-size="11">Summary + Diagnostics</text>
        </g>
        <g fill="none" stroke="#7aa2f7" stroke-width="2"
           marker-end="url(#etf-arrow)">
          <line x1="245" y1="68" x2="278" y2="68"></line>
          <line x1="510" y1="68" x2="543" y2="68"></line>
          <line x1="775" y1="68" x2="808" y2="68"></line>
          <line x1="925" y1="110" x2="925" y2="188"></line>
          <line x1="810" y1="233" x2="777" y2="233"></line>
          <line x1="545" y1="233" x2="512" y2="233"></line>
          <line x1="280" y1="233" x2="247" y2="233"></line>
        </g>
      </svg>
      <details>
        <summary>Mermaid-compatible source</summary>
        <pre>flowchart LR
  A[54-account Runbook + Current/Projected] --&gt; B[AIM positions]
  B --&gt; C[Name + Market Status + company mapping]
  C --&gt; D[Thai local-line validation]
  D --&gt; E[Approved USD price]
  E --&gt; F[Position MV + security Weight]
  F --&gt; G[Attach company key]
  G --&gt; H[Aggregate company weights]
  H --&gt; I[Rank + dynamic capping limit]
  I --&gt; J[Monitor / Full Positions / Diagnostics]</pre>
      </details>

      <h3>2. Inputs and request lifecycle</h3>
      <ol>
        <li>
          The user selects <code>Current</code> or <code>Projected</code>.
          BQL runs only after <code>Update</code> is clicked.
        </li>
        <li>
          Current uses <code>position_without_pending()['value']</code>.
          Projected is that item plus <code>pending_position()['value']</code>.
          Desktop 2026-08-28 showed <code>pending_position()</code> alone as
          all zeros; the sum returned the non-zero book. Do not add dates,
          do not use <code>ts_position()</code>, and do not move
          <code>accounts</code>, <code>pxnum</code>, or <code>profile</code>
          onto <code>members()</code>.
        </li>
        <li>
          Each AIM request uses <code>Members(Type=AIM)</code>,
          <code>accounts=[AIM Code]</code>, <code>pxnum=1377</code>, and
          <code>profile='DEFAULT_PROFILE'</code>.
        </li>
        <li>
          Position rows are combined by exact <code>AIM Code + Ticker</code>.
          Quantities are summed without changing the held ticker.
        </li>
        <li>
          The bundled Runbook supplies fund name, Capping, Largest, display
          Level, and the account's Last Close or Real Time pricing rule.
        </li>
      </ol>
      <div class="note">
        Account requests are batched in groups of 8 and security requests in
        groups of 150. Dropdowns, searches, tab changes, and CSV exports are
        local operations and do not rerun BQL.
      </div>

      <h3>3. Asset and pricing rules</h3>
      <table>
        <tr><th>Asset</th><th>Identification</th><th>Valuation rule</th></tr>
        <tr>
          <td>Equity / Others</td>
          <td><code>Equity</code> suffix or residual classification</td>
          <td>Approved Pricing Ticker's <code>px_last</code> in USD.</td>
        </tr>
        <tr>
          <td>Cash</td>
          <td>Short <code>Curncy</code> ticker</td>
          <td>
            USD cash = 1. Other cash uses
            <code>USD{CCY} BGNL Curncy</code>; USD price = 1 / FX quote.
          </td>
        </tr>
        <tr>
          <td>Index Future</td>
          <td><code>Index</code> suffix</td>
          <td>Price and MV are forced to zero for workbook parity.</td>
        </tr>
        <tr>
          <td>FFX</td>
          <td>Long <code>Curncy</code> ticker</td>
          <td>Price and MV are forced to zero for workbook parity.</td>
        </tr>
      </table>
      <ul>
        <li>
          Last Close requests the previous weekday (through yesterday); Real
          Time requests today's live calendar date. Both use
          <code>fill='prev'</code>, so a holiday on the as-of date still
          carries the last available print (which may be the session before
          yesterday for Last Close). The header clock is UK time and does
          not shift these request dates. Security prices are requested
          directly with <code>currency='USD'</code>.
        </li>
        <li>
          Request <code>px_last(..., fill='prev')</code> for every priced
          equity. If Bloomberg returns a last price, carry it even when
          status is Suspended, Inactive, Expired, or Delisted. If that
          request is empty or non-numeric, that holding's price and MV fall
          back to zero so other holdings can still be weighted. Official
          empty-market statuses
          (<code>DLST</code>, <code>UNLS</code>, <code>PRNA</code>,
          <code>PRIV</code>, <code>INAC</code>, <code>SUSP</code>,
          <code>EXPD</code>, <code>PEND</code>, <code>LIQU</code>,
          <code>RCNA</code>) are not a missing-price error. An Active name
          in this fallback remains a data issue. Acquired/ACQU is not
          overwritten to zero when a last print exists.
        </li>
        <li>
          A normal security prices from its own held ticker. Company mapping
          never replaces its pricing identity.
        </li>
      </ul>

      <h4>Thai foreign-line exception</h4>
      <ul>
        <li>
          A ticker ending <code>/F TB Equity</code> or
          <code>-R TB Equity</code> keeps its exact AIM ticker and quantity
          but must price from an approved local <code>TB Equity</code> line
          before MV is calculated.
        </li>
        <li>
          Resolution order: explicit approved override, then a deterministic
          <code>/F</code> or <code>-R</code> strip accepted only if the local
          candidate has reference data and both lines share the same
          fundamental ticker, then HelpDesk-confirmed leftover
          <code>bb_default_risk_obligor_ticker()</code> only for remaining
          Thai foreign lines.
        </li>
        <li>
          If validation still fails, Pricing Ticker remains blank, price is
          removed, and the account is marked Data Issue. The sparse foreign
          price is never reused. Official CAST parent ticker and integer
          <code>id_bb_company()</code> are not premium, but they are the
          wrong identity for local-line pricing and are not requested.
        </li>
      </ul>
      <div class="note">
        <code>-R TB Equity</code> is the N-NDVR yellow-key pattern. The local
        Pricing Ticker must end in <code>TB Equity</code> and must not keep
        <code>/F</code> or <code>-R</code>. DRSK output is a pricing identity
        only; it never replaces the AIM ticker, quantity, or company key.
      </div>

      <h3>4. Position-level calculations</h3>
      <p>
        These calculations occur before any company consolidation. The real
        AIM position identity is preserved.
      </p>
      <div class="formula">
        <div><b>Position MV</b><br><code>Quantity × USD Price</code></div>
        <div><b>Account Total MV</b><br><code>Σ all Position MV</code></div>
        <div><b>Security Weight</b><br><code>Position MV / Account Total MV</code></div>
      </div>
      <p>
        Index Future and FFX MV are explicitly zero. A zero Account Total MV
        makes weights undefined and produces a Data Issue.
      </p>

      <h3>5. Company identity and aggregation</h3>
      <ol>
        <li>Apply a reviewed hard Exception override, if present.</li>
        <li>
          Otherwise use the lineage-mapped
          <code>fundamentalticker()</code> company key.
        </li>
        <li>
          If unavailable, retain the original held ticker as the company key
          and record a fallback diagnostic.
        </li>
      </ol>
      <div class="formula">
        <div><b>Company MV</b><br><code>Σ Position MV for AIM Code + Company Key</code></div>
        <div><b>Incl-cash Weight</b><br><code>Company MV / Account Total MV</code></div>
        <div><b>Ex-cash Weight</b><br><code>Company MV / Total Equity MV</code></div>
      </div>
      <div class="note">
        Runbook Level (Stock or Issuer) is displayed but does not select a
        different grouping method. The reviewed company key is used for the
        final aggregation in both cases.
      </div>

      <h3>6. Rank, dynamic limit, and alert status</h3>
      <ol>
        <li>
          Rank company groups within each account by
          <code>Agg Wgt (incl cash)</code>, highest first. Ranking includes
          non-equity groups to retain workbook behavior.
        </li>
        <li>
          Rank 1 uses the Runbook <code>Largest</code> limit when present;
          otherwise, and for every later rank, it uses <code>Capping</code>.
        </li>
        <li>
          Observed Weight is the larger of including-cash and excluding-cash
          company weight.
        </li>
      </ol>
      <div class="formula">
        <div><b>Dynamic Limit</b><br><code>Rank 1 and Largest present ? Largest : Capping</code></div>
        <div><b>Observed Weight</b><br><code>max(Incl Cash, Ex Cash)</code></div>
        <div><b>Headroom</b><br><code>Dynamic Limit − Observed Weight</code></div>
        <div><b>Utilisation</b><br><code>Observed Weight / Dynamic Limit</code></div>
      </div>
      <table>
        <tr><th>Status</th><th>Condition</th></tr>
        <tr><td>Breach</td><td>Observed Weight ≥ 100% of Dynamic Limit</td></tr>
        <tr><td>Near Limit</td><td>Observed Weight ≥ 98% of Dynamic Limit</td></tr>
        <tr><td>OK</td><td>Below the near-limit threshold</td></tr>
        <tr>
          <td>Data Issue</td>
          <td>
            Incomplete account, and the name is still below the near-limit
            threshold. Over-limit names keep Breach or Near Limit.
          </td>
        </tr>
      </table>

      <h3>7. Data-quality protection</h3>
      <ul>
        <li>
          Missing quantity, required reference data, required price, Runbook
          rule, unresolved Thai price mapping, or zero account MV creates a
          row/account Data Issue.
        </li>
        <li>
          One affected row propagates Data Issue quality to every company
          result in that AIM account, preventing an incomplete account from
          showing OK. Names that are still at or above the dynamic limit
          remain on the default Monitor Alerts view with Status Breach or
          Near Limit. Other within-limit names of that account stay on
          Diagnostics and the Data Issue filter.
        </li>
        <li>
          Missing AIM-account responses, malformed BQL responses, conflicting
          Pricing Tickers, and request failures are recorded in Diagnostics.
        </li>
        <li>
          Filters never widen a universe or substitute an unapproved field
          when an input fails.
        </li>
      </ul>

      <h3>8. Tab guide</h3>
      <table>
        <tr><th>Tab</th><th>Purpose</th></tr>
        <tr>
          <td>Monitor</td>
          <td>
            High company weights for monitoring. The default Alerts view lists
            Breach and Near Limit names, plus the Rank 1 equity name of those
            same funds for comparison (Rank 1 is unflagged when it sits
            between Capping and Largest). Incl Cash / Ex Cash use the same
            red / amber colours as Status when that weight exceeds Capping or
            the near-limit threshold. Incomplete-account names that are still
            at or above the limit stay on Alerts with Status Breach or Near
            Limit; other within-limit names of that account stay on
            Diagnostics and the Data Issue filter. Clicking a
            row opens the selected six-column subset of the exact cached Full
            Positions rows for that AIM account and Parent/Issuer Ticker,
            sorted by MV(USD) descending.
          </td>
        </tr>
        <tr>
          <td>Full Positions</td>
          <td>
            All security-level rows; Column L is USD Price, FX is omitted, and
            the top row provides a Fund dropdown plus live partial-keyword NAME
            search. Default order is Fund Name ascending, then Agg Wgt (incl
            cash) descending. The remaining columns are available in Advanced
            Filters.
          </td>
        </tr>
        <tr><td>Account Summary</td><td>One-row-per-account alert and data-quality summary.</td></tr>
        <tr><td>Runbook</td><td>Read-only 54-account limits, levels, and price types.</td></tr>
        <tr><td>Exceptions</td><td>Reviewed company and Thai local-pricing overrides.</td></tr>
        <tr><td>Diagnostics</td><td>Request, mapping, reference, price, and calculation issues.</td></tr>
        <tr><td>Documentation</td><td>This implemented-logic reference.</td></tr>
      </table>

      <h3>9. Operational safeguards</h3>
      <ul>
        <li>
          Restricted ESG/GHG, climate, and sustainable-finance data are never
          requested. CAST parent ticker and integer <code>id_bb_company()</code>
          are documented official items but are not requested, because they are
          the wrong identity for local-line price and company grouping.
        </li>
        <li>
          CSV buttons export the current table to project Files. They do not
          refresh BQL. Full Positions exports respect Fund, live NAME search,
          Primary FM, and all active advanced filters; Monitor exports respect
          its local filters, including Primary FM.
        </li>
        <li>
          After replacing Python files in BQuant Desktop, restart the kernel
          and Run All before validation.
        </li>
      </ul>
    </div>
    """


def _primary_fm_dropdown_options() -> list[tuple[str, str]]:
    names = (
        account_rules_frame()["Primary FM"]
        .fillna("")
        .astype(str)
        .str.strip()
    )
    unique = sorted({name for name in names if name})
    return [("All Primary FM", "All"), *[(name, name) for name in unique]]


class ETFCappingMonitor:
    """Stateful ipywidgets application; BQL runs only when Update is clicked."""

    def __init__(self):
        self._events_bound = False
        self._loading = False
        self._fixing_filter = False
        self._result: MonitorResult | None = None
        self._request_errors: list[str] = []
        self._visible_groups = pd.DataFrame()
        self._summary_frame = pd.DataFrame()
        self._full_positions_cache: pd.DataFrame | None = None
        self._selected_key: tuple[str, str] | None = None
        self._build_widgets()
        self._bind_events()
        self._render_static_tabs()

    def _build_widgets(self):
        self.title = widgets.HTML(
            value=self._header_html(
                "Ready",
                "Select Current or Projected, then click Update.",
            )
        )
        self.position_mode = widgets.Dropdown(
            options=("Current", "Projected"),
            value="Projected",
            description="AIM Position",
            layout=widgets.Layout(width="220px"),
            style={"description_width": "90px"},
        )
        self.update_button = widgets.Button(
            description="Update",
            icon="refresh",
            button_style="danger",
            layout=widgets.Layout(width="118px", height="38px"),
            tooltip="Pull fresh AIM positions and recalculate all capping limits",
        )
        self.account_filter = widgets.Dropdown(
            options=[("All Accounts", "All")],
            value="All",
            description="Account",
            layout=widgets.Layout(width="285px"),
            style={"description_width": "58px"},
        )
        self.status_filter = widgets.Dropdown(
            options=("Alerts", "Breach", "Near Limit", "Data Issue", "All"),
            value="Alerts",
            description="Show",
            layout=widgets.Layout(width="180px"),
            style={"description_width": "42px"},
        )
        self.search = widgets.Text(
            placeholder="Fund, AIM code, company or ticker",
            description="Find",
            layout=widgets.Layout(width="300px"),
            style={"description_width": "38px"},
        )
        self.primary_fm_filter = widgets.Dropdown(
            options=_primary_fm_dropdown_options(),
            value="All",
            description="Primary FM",
            layout=widgets.Layout(width="230px"),
            style={"description_width": "78px"},
        )
        self.full_positions_filter = widgets.Dropdown(
            options=[("All Funds", "All")],
            value="All",
            description="Fund",
            layout=widgets.Layout(width="390px"),
            style={"description_width": "42px"},
        )
        self.full_positions_name_search = widgets.Text(
            value="",
            description="NAME",
            placeholder="Type any part of the security name…",
            continuous_update=True,
            layout=widgets.Layout(width="360px"),
            style={"description_width": "52px"},
        )
        self.full_positions_fm_filter = widgets.Dropdown(
            options=_primary_fm_dropdown_options(),
            value="All",
            description="Primary FM",
            layout=widgets.Layout(width="230px"),
            style={"description_width": "78px"},
        )
        self._build_full_position_filter_controls()
        self.status = widgets.HTML(
            value=self._status_html(
                "Waiting for input.",
                color="#8b93a7",
            )
        )
        self.cards = widgets.HTML(value=self._empty_cards_html())
        self.alert_chips = widgets.Box(
            children=[],
            layout=widgets.Layout(
                display="flex",
                flex_flow="row wrap",
                width="100%",
                margin="2px 0 7px",
            ),
        )
        self.monitor_export = self._make_export_controls("monitor")
        self.full_positions_export = self._make_export_controls("full_positions")
        self.summary_export = self._make_export_controls("summary")
        self.runbook_export = self._make_export_controls("runbook")
        self.exceptions_export = self._make_export_controls("exceptions")
        self.diagnostics_export = self._make_export_controls("diagnostics")

        self.grid_box = widgets.VBox(
            [self._empty_state("No monitoring result yet.")],
            layout=widgets.Layout(width="100%"),
        )
        self.detail_header = widgets.HTML(
            value=self._detail_empty_html("Select an alert or table row.")
        )
        self.detail_figure = self._empty_detail_figure()
        self.listing_box = widgets.VBox(
            [self._empty_state("Listing-level positions will appear here.")]
        )
        self.monitor_left = widgets.VBox(
            [self.grid_box],
            layout=widgets.Layout(width="64%", min_width="650px"),
        )
        self.monitor_right = widgets.VBox(
            [self.detail_header, self.detail_figure, self.listing_box],
            layout=widgets.Layout(width="36%", min_width="410px"),
        )
        self.monitor_body = widgets.HBox(
            [self.monitor_left, self.monitor_right],
            layout=widgets.Layout(
                width="100%",
                align_items="flex-start",
                overflow="visible",
            ),
        )
        self.legend = widgets.HTML(value=self._legend_html())
        self.monitor_tab = widgets.VBox(
            [self.monitor_export, self.alert_chips, self.monitor_body, self.legend],
            layout=widgets.Layout(width="100%"),
        )

        self.full_positions_box = widgets.VBox(
            [self._empty_state("Run Update to load all positions.")]
        )
        self.full_positions_tab = widgets.VBox(
            [
                widgets.HBox(
                    [
                        self.full_positions_filter,
                        self.full_positions_name_search,
                        self.full_positions_fm_filter,
                        self.full_positions_export,
                    ],
                    layout=widgets.Layout(
                        display="flex",
                        flex_flow="row wrap",
                        align_items="center",
                        grid_gap="8px",
                    ),
                ),
                widgets.HTML(
                    '<div style="color:#8b93a7;font-size:12px;'
                    'padding:4px 2px 8px;">'
                    "Workbook-aligned audit view using the app calculation "
                    "inputs. Column L is USD Price; workbook Column M (FX) is "
                    "omitted because the app requests USD prices directly. "
                    "Fund selects an AIM account; NAME filters partial keywords "
                    "live as you type; Primary FM is a dropdown on these rows. "
                    "Expand Advanced Column Filters for the "
                    "remaining columns. Default sort: Fund Name ascending, then "
                    "Agg Wgt (incl cash) descending."
                    "</div>"
                ),
                self.full_column_filter_panel,
                self.full_positions_box,
            ],
            layout=widgets.Layout(width="100%"),
        )

        self.summary_box = widgets.VBox(
            [
                self.summary_export,
                self._empty_state("Run Update to build the account summary."),
            ]
        )
        self.runbook_box = widgets.VBox([self.runbook_export])
        self.exceptions_box = widgets.VBox([self.exceptions_export])
        self.diagnostics_box = widgets.VBox(
            [self.diagnostics_export, self._empty_state("No diagnostics yet.")]
        )
        self.documentation_box = widgets.VBox(
            layout=widgets.Layout(width="100%", height="640px", overflow="auto")
        )
        self.tabs = widgets.Tab(
            children=[
                self.monitor_tab,
                self.full_positions_tab,
                self.summary_box,
                self.runbook_box,
                self.exceptions_box,
                self.diagnostics_box,
                self.documentation_box,
            ]
        )
        for index, label in enumerate(
            (
                "Monitor",
                "Full Positions",
                "Account Summary",
                "Runbook",
                "Exceptions",
                "Diagnostics",
                "Documentation",
            )
        ):
            self.tabs.set_title(index, label)

        controls = widgets.HBox(
            [
                self.position_mode,
                self.update_button,
                self.account_filter,
                self.status_filter,
                self.search,
                self.primary_fm_filter,
            ],
            layout=widgets.Layout(
                display="flex",
                flex_flow="row wrap",
                align_items="center",
                grid_gap="7px",
                margin="2px 0 3px",
            ),
        )
        self.log = widgets.Output(
            layout=widgets.Layout(max_height="110px", overflow="auto")
        )
        self.footer = widgets.HTML(
            value=(
                '<div style="color:#667085;font-size:11px;padding:8px 2px 0;'
                'border-top:1px solid #252b3a;margin-top:8px;">'
                "Held ticker, quantity, position MV, and Position Wgt remain "
                "security-level values. Company key: Exception override → "
                "fundamental ticker → original ticker; it is used only for final "
                "capping aggregation. A Bloomberg last price is carried even "
                "when Suspended; empty official statuses become zero. Index "
                "futures and FFX have zero market value. Thai /F and -R "
                "pricing uses approved local-line validation, then leftover "
                "HelpDesk DRSK. Restricted ESG/GHG is never requested. CAST "
                "parent ticker and integer company ID are documented but not "
                "used as price or company key. Restart Kernel and Run All "
                "after replacing Python files."
                "</div>"
            )
        )
        self.container = widgets.VBox(
            [
                self.title,
                controls,
                self.status,
                self.cards,
                self.tabs,
                self.log,
                self.footer,
            ],
            layout=widgets.Layout(width="100%", padding="6px 8px 12px"),
        )

    def _bind_events(self):
        if self._events_bound:
            return
        self.update_button.on_click(self._on_update)
        self.account_filter.observe(self._on_local_filter, names="value")
        self.status_filter.observe(self._on_local_filter, names="value")
        self.search.observe(self._on_local_filter, names="value")
        self.primary_fm_filter.observe(self._on_local_filter, names="value")
        self.full_positions_filter.observe(
            self._on_full_positions_filter,
            names="value",
        )
        self.full_positions_name_search.observe(
            self._on_full_positions_filter,
            names="value",
        )
        self.full_positions_fm_filter.observe(
            self._on_full_positions_filter,
            names="value",
        )
        self.full_filter_apply_button.on_click(self._on_apply_full_column_filters)
        self.full_filter_clear_button.on_click(self._on_clear_full_column_filters)
        for field in self.full_column_filters.values():
            field.observe(self._on_full_column_filter_change, names="value")
        self.position_mode.observe(self._on_mode_change, names="value")
        self._events_bound = True

    def render(self):
        return self.container

    def load_on_start(self):
        """Optional helper. MAIN intentionally does not call it."""
        self._refresh()

    def _build_full_position_filter_controls(self):
        self.full_column_filters = {}
        fields = []
        for column in FULL_POSITION_ADVANCED_COLUMNS:
            if column in FULL_POSITION_PERCENT_COLUMNS:
                placeholder = "e.g. >=4% or 4%"
            elif column in FULL_POSITION_NUMERIC_COLUMNS:
                placeholder = "e.g. >=100 or 100"
            else:
                placeholder = "contains…"
            field = widgets.Text(
                value="",
                description=column,
                placeholder=placeholder,
                continuous_update=False,
                layout=widgets.Layout(width="100%"),
                style={"description_width": "145px"},
            )
            self.full_column_filters[column] = field
            fields.append(field)
        self.full_filter_apply_button = widgets.Button(
            description="Apply Filters",
            icon="filter",
            button_style="info",
            layout=widgets.Layout(width="130px", height="32px"),
        )
        self.full_filter_clear_button = widgets.Button(
            description="Clear Filters",
            icon="eraser",
            layout=widgets.Layout(width="130px", height="32px"),
        )
        self.full_filter_summary = widgets.HTML(
            '<span style="color:#8b93a7;font-size:11px;">'
            "No column filters applied.</span>"
        )
        filter_grid = widgets.GridBox(
            children=fields,
            layout=widgets.Layout(
                width="100%",
                grid_template_columns="repeat(3, minmax(290px, 1fr))",
                grid_gap="6px 10px",
            ),
        )
        filter_body = widgets.VBox(
            [
                widgets.HTML(
                    '<div style="color:#8b93a7;font-size:11px;'
                    'padding:1px 2px 7px;">'
                    "Advanced filters cover the remaining columns; NAME uses "
                    "the live search above. Text filters are case-insensitive "
                    "contains matches. "
                    "Numeric filters accept =, !=, &gt;, &gt;=, &lt;, and "
                    "&lt;=. Use % for percentage columns. Multiple filters "
                    "are combined with AND."
                    "</div>"
                ),
                filter_grid,
                widgets.HBox(
                    [
                        self.full_filter_apply_button,
                        self.full_filter_clear_button,
                        self.full_filter_summary,
                    ],
                    layout=widgets.Layout(
                        display="flex",
                        flex_flow="row wrap",
                        align_items="center",
                        grid_gap="8px",
                        margin="8px 0 2px",
                    ),
                ),
            ]
        )
        self.full_column_filter_panel = widgets.Accordion(children=[filter_body])
        self.full_column_filter_panel.set_title(
            0,
            "Advanced Column Filters — remaining "
            f"{len(FULL_POSITION_ADVANCED_COLUMNS)} columns",
        )
        self.full_column_filter_panel.selected_index = None

    def _make_export_controls(self, tab_key: str):
        button = widgets.Button(
            description="Export CSV",
            icon="download",
            button_style="",
            layout=widgets.Layout(width="122px", height="32px"),
            tooltip="Save this tab's current table as UTF-8 CSV in project Files",
        )
        status = widgets.HTML()
        button.on_click(partial(self._on_export_csv, tab_key, status))
        return widgets.HBox(
            [button, status],
            layout=widgets.Layout(
                align_items="center",
                grid_gap="8px",
                margin="3px 0 5px",
            ),
        )

    def _export_frames(self, tab_key: str) -> list[tuple[str, pd.DataFrame]]:
        if tab_key == "runbook":
            return [("Runbook", account_rules_frame().copy())]
        if tab_key == "exceptions":
            return [
                ("Exceptions", exception_rules_frame().copy()),
                ("Thai_Pricing_Overrides", thai_pricing_rules_frame().copy()),
            ]
        if self._result is None:
            return []
        if tab_key == "monitor":
            return [
                (
                    "Monitor",
                    self._monitor_grid_frame(self._visible_groups).reset_index(
                        drop=True
                    ),
                )
            ]
        if tab_key == "full_positions":
            return [
                (
                    "Full_Positions",
                    self._filtered_full_positions_frame(),
                )
            ]
        if tab_key == "summary":
            return [
                (
                    "Account_Summary",
                    self._summary_frame.rename(
                        columns={
                            "AIM Code": "AIM",
                            "Fund Name": "Fund",
                            "Data_Issues": "Data Issues",
                        }
                    ),
                )
            ]
        if tab_key == "diagnostics":
            return [("Diagnostics", self._result.diagnostics.copy())]
        return []

    def _on_export_csv(self, tab_key: str, status, _button=None):
        frames = [
            (label, frame)
            for label, frame in self._export_frames(tab_key)
            if not frame.empty
        ]
        if not frames:
            status.value = (
                '<span style="color:#f5a623;font-size:11px;">'
                "No rows to export.</span>"
            )
            return
        timestamp = _now_uk().strftime("%Y%m%d_%H%M%S")
        filenames = []
        try:
            for label, frame in frames:
                filename = f"ETF_Capping_{label}_{timestamp}.csv"
                frame.to_csv(filename, index=False, encoding="utf-8-sig")
                filenames.append(filename)
            joined = ", ".join(filenames)
            status.value = (
                '<span style="color:#63d4a6;font-size:11px;">Saved to project '
                f"Files: {escape(joined)}</span>"
            )
            with self.log:
                print("CSV export:", joined)
        except Exception as exc:
            status.value = (
                '<span style="color:#ff7777;font-size:11px;">'
                f"{escape(type(exc).__name__)}: {escape(str(exc))}</span>"
            )
            with self.log:
                print("CSV export failed:", type(exc).__name__, exc)

    def _on_update(self, _button=None):
        self._refresh()

    def _on_local_filter(self, _change=None):
        if self._fixing_filter or self._result is None:
            return
        self._render_monitor()

    def _on_full_positions_filter(self, _change=None):
        if self._fixing_filter or self._result is None:
            return
        self._render_full_positions()

    def _on_apply_full_column_filters(self, _button=None):
        if self._result is None:
            return
        self._render_full_positions()

    def _on_full_column_filter_change(self, _change=None):
        if self._fixing_filter or self._result is None:
            return
        self._render_full_positions()

    def _on_clear_full_column_filters(self, _button=None):
        self._fixing_filter = True
        try:
            for field in self.full_column_filters.values():
                field.value = ""
        finally:
            self._fixing_filter = False
        self.full_column_filter_panel.set_title(
            0,
            "Advanced Column Filters — remaining "
            f"{len(FULL_POSITION_ADVANCED_COLUMNS)} columns",
        )
        self.full_filter_summary.value = (
            '<span style="color:#8b93a7;font-size:11px;">'
            "No column filters applied.</span>"
        )
        if self._result is not None:
            self._render_full_positions()

    def _on_mode_change(self, change):
        if change.get("old") == change.get("new"):
            return
        self.title.value = self._header_html(
            "Input changed",
            f"AIM Position is now {change['new']}. Click Update to refresh BQL.",
            color="#f5a623",
        )
        self._clear_result_views(
            "Previous results were cleared to prevent Current/Projected mixing."
        )
        self.status.value = self._status_html(
            "Click Update to load the selected position mode.",
            color="#f5a623",
        )

    def _clear_result_views(self, message: str):
        self._result = None
        self._visible_groups = pd.DataFrame()
        self._summary_frame = pd.DataFrame()
        self._full_positions_cache = None
        self._selected_key = None
        self.cards.value = self._empty_cards_html()
        self.alert_chips.children = ()
        self.grid_box.children = [self._empty_state(message)]
        self.detail_header.value = self._detail_empty_html(message)
        self.listing_box.children = [self._empty_state(message)]
        self.full_positions_box.children = [self._empty_state(message)]
        self.summary_box.children = [
            self.summary_export,
            self._empty_state(message),
        ]
        self.diagnostics_box.children = [
            self.diagnostics_export,
            self._empty_state(message),
        ]
        self._clear_detail_figure()
        self._fixing_filter = True
        try:
            self.account_filter.options = [("All Accounts", "All")]
            self.account_filter.value = "All"
            self.full_positions_filter.options = [("All Funds", "All")]
            self.full_positions_filter.value = "All"
            self.full_positions_name_search.value = ""
            self.primary_fm_filter.value = "All"
            self.full_positions_fm_filter.value = "All"
            for field in self.full_column_filters.values():
                field.value = ""
        finally:
            self._fixing_filter = False
        self.full_column_filter_panel.set_title(
            0,
            "Advanced Column Filters — remaining "
            f"{len(FULL_POSITION_ADVANCED_COLUMNS)} columns",
        )
        self.full_column_filter_panel.selected_index = None
        self.full_filter_summary.value = (
            '<span style="color:#8b93a7;font-size:11px;">'
            "No column filters applied.</span>"
        )

    def _progress(self, message: str):
        self.status.value = self._status_html(message, color="#a9b1c3", loading=True)

    def _refresh(self):
        if self._loading:
            return
        self._loading = True
        self.update_button.disabled = True
        mode = self.position_mode.value
        self._progress(f"Starting {mode.lower()} AIM refresh…")
        with self.log:
            clear_output(wait=True)
            from .data import PARSER_VERSION

            print(
                _format_now_uk(),
                f"Loading {mode} positions; parser {PARSER_VERSION}",
            )
        try:
            payload = fetch_monitor_payload(mode, progress=self._progress)
            self._request_errors = payload.errors
            if payload.positions.empty:
                raise RuntimeError(
                    "No AIM positions were returned. Check account entitlement and "
                    "the _aim_request account parameter in data.py."
                )
            self._result = calculate_monitor(payload.positions, mode)
            self._full_positions_cache = None
            self._append_request_diagnostics()
            self._selected_key = None
            self._update_account_options()
            self._render_all()

            groups = self._result.groups
            account_count = groups["AIM Code"].nunique()
            latest_date = groups["Price Date"].max()
            date_text = _fmt_date(latest_date) or "n/a"
            extra = (
                f"{account_count} accounts · {len(payload.positions):,} positions · "
                f"price date through {date_text} · "
                f"{_format_now_uk()}"
            )
            if self._request_errors:
                extra += f" · {len(self._request_errors)} BQL note(s)"
            data_issue_count = int((groups["Data Quality"] == "Data Issue").sum())
            has_issues = bool(self._request_errors or data_issue_count)
            state = "Completed with issues" if has_issues else "Updated"
            state_color = "#f5a623" if has_issues else "#7aa2f7"
            self.title.value = self._header_html(state, extra, color=state_color)
            self.status.value = self._status_html(
                (
                    "Refresh completed with data issues. Review Diagnostics before "
                    "using the capping result."
                    if has_issues
                    else "Refresh completed. Filters below are local and do not rerun BQL."
                ),
                color="#f5a623" if has_issues else "#63d4a6",
            )
            if self._request_errors:
                with self.log:
                    for message in self._request_errors:
                        print("Request note:", message)
        except Exception as exc:
            self._clear_result_views(
                "Refresh failed; previous monitoring results were cleared."
            )
            self.title.value = self._header_html(
                "Error",
                str(exc),
                color="#ff5c5c",
            )
            self.status.value = self._status_html(
                f"{type(exc).__name__}: {exc}",
                color="#ff5c5c",
            )
            with self.log:
                print(type(exc).__name__, exc)
        finally:
            self._loading = False
            self.update_button.disabled = False

    def _append_request_diagnostics(self):
        if self._result is None or not self._request_errors:
            return
        request_rows = pd.DataFrame(
            [
                {
                    "AIM Code": "",
                    "Ticker": "",
                    "Category": "BQL Request",
                    "Message": message,
                }
                for message in self._request_errors
            ]
        )
        self._result.diagnostics = pd.concat(
            [self._result.diagnostics, request_rows],
            ignore_index=True,
            sort=False,
        ).drop_duplicates()

    def _update_account_options(self):
        if self._result is None:
            return
        groups = self._result.groups
        options = [("All Accounts", "All")]
        meta = (
            groups[["AIM Code", "Fund Name"]]
            .drop_duplicates()
            .sort_values(["Fund Name", "AIM Code"])
        )
        options.extend(
            (
                f"{row['AIM Code']} · {row['Fund Name']}",
                row["AIM Code"],
            )
            for _, row in meta.iterrows()
        )
        full_options = [("All Funds", "All")]
        full_meta = account_rules_frame()[["AIM Code", "Fund Name"]].sort_values(
            ["Fund Name", "AIM Code"]
        )
        full_options.extend(
            (
                f"{row['AIM Code']} · {row['Fund Name']}",
                row["AIM Code"],
            )
            for _, row in full_meta.iterrows()
        )
        current = self.account_filter.value
        valid_values = [value for _, value in options]
        full_current = self.full_positions_filter.value
        full_valid_values = [value for _, value in full_options]
        self._fixing_filter = True
        try:
            self.account_filter.options = options
            self.account_filter.value = current if current in valid_values else "All"
            self.full_positions_filter.options = full_options
            self.full_positions_filter.value = (
                full_current if full_current in full_valid_values else "All"
            )
        finally:
            self._fixing_filter = False

    def _render_all(self):
        if self._result is None:
            return
        self.cards.value = self._cards_html()
        self._render_monitor()
        self._render_full_positions()
        self._render_summary()
        self._render_diagnostics()

    def _filtered_groups(self) -> pd.DataFrame:
        if self._result is None:
            return pd.DataFrame()
        groups = self._result.groups.copy()
        groups = groups.loc[groups["Is Equity"].fillna(False)]
        account = self.account_filter.value
        if account != "All":
            groups = groups.loc[groups["AIM Code"].eq(account)]
        groups = select_monitor_groups(groups, self.status_filter.value)
        fm = self.primary_fm_filter.value
        if fm != "All" and "Primary FM" in groups.columns:
            groups = groups.loc[groups["Primary FM"].eq(fm)]

        query = (self.search.value or "").strip().lower()
        if query:
            listing_tickers = groups.get(
                "Listing Tickers",
                pd.Series("", index=groups.index),
            )
            searchable = (
                groups["AIM Code"].astype(str)
                + " "
                + groups["Fund Name"].astype(str)
                + " "
                + groups["Parent/Issuer Ticker"].astype(str)
                + " "
                + groups["Parent/Issuer Name"].astype(str)
                + " "
                + listing_tickers.astype(str)
            ).str.lower()
            groups = groups.loc[searchable.str.contains(query, regex=False, na=False)]
        if groups.empty:
            return groups
        return groups.sort_values(
            ["Fund Name", "Rank", "Observed Weight"],
            ascending=[True, True, False],
            na_position="last",
        )

    def _render_monitor(self):
        self._visible_groups = self._filtered_groups().reset_index(drop=True)
        self.alert_chips.children = tuple(self._alert_buttons())
        if self._visible_groups.empty:
            self.grid_box.children = [
                self._empty_state("No companies match the selected filters.")
            ]
            self.detail_header.value = self._detail_empty_html(
                "No row is available under the current filters."
            )
            self.listing_box.children = [
                self._empty_state("Change the filters or run Update.")
            ]
            self._clear_detail_figure()
            return

        grid_frame = self._monitor_display_frame(self._visible_groups)
        grid = DataGrid(
            grid_frame,
            base_row_size=28,
            base_column_size=92,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
                font="bold 11px sans-serif",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            renderers=self._monitor_renderers(self._visible_groups),
            column_widths={
                "AIM": 83,
                "Fund": 310,
                "Company": 200,
                "Company Key": 112,
                "Price Date": 88,
                "Incl Cash": 82,
                "Ex Cash": 82,
                "Cap": 68,
                "Largest": 68,
                "Rank": 48,
                "Limit": 68,
                "Headroom": 78,
                "Status": 84,
                "Level": 58,
                "Price": 74,
                "Primary FM": 130,
            },
            layout={"width": "100%", "height": "555px"},
        )
        grid.on_cell_click(partial(self._on_monitor_click, self._visible_groups))
        self.grid_box.children = [grid]

        available_keys = {
            (row["AIM Code"], row["Parent/Issuer Ticker"])
            for _, row in self._visible_groups.iterrows()
        }
        if self._selected_key not in available_keys:
            first = self._visible_groups.iloc[0]
            self._selected_key = (
                first["AIM Code"],
                first["Parent/Issuer Ticker"],
            )
        self._render_detail(*self._selected_key)

    def _monitor_grid_frame(self, groups: pd.DataFrame) -> pd.DataFrame:
        out = pd.DataFrame(
            {
                "AIM": groups["AIM Code"].values,
                "Fund": groups["Fund Name"].values,
                "Company": groups["Parent/Issuer Name"].values,
                "Company Key": groups["Parent/Issuer Ticker"].map(_short_ticker).values,
                "Price Date": groups["Price Date"].map(_fmt_date).values,
                "Incl Cash": pd.to_numeric(
                    groups["Agg Wgt (incl cash)"], errors="coerce"
                ).values,
                "Ex Cash": pd.to_numeric(
                    groups["Agg Wgt (ex cash)"], errors="coerce"
                ).values,
                "Cap": pd.to_numeric(groups["Capping"], errors="coerce").values,
                "Largest": pd.to_numeric(groups["Largest"], errors="coerce").values,
                "Rank": pd.to_numeric(groups["Rank"], errors="coerce").values,
                "Limit": pd.to_numeric(groups["Dynamic Limit"], errors="coerce").values,
                "Headroom": pd.to_numeric(groups["Headroom"], errors="coerce").values,
                "Status": groups["Status"].values,
                "Level": groups["Level"].values,
                "Price": groups["Type"].values,
                "Primary FM": groups["Primary FM"].fillna("").values
                if "Primary FM" in groups.columns
                else pd.Series("", index=groups.index).values,
            },
            index=pd.Index(range(1, len(groups) + 1), name="#"),
        )
        return out

    def _monitor_display_frame(self, groups: pd.DataFrame) -> pd.DataFrame:
        """Monitor grid copy. Incl/Ex are percent strings so VegaExpr can colour them."""
        out = self._monitor_grid_frame(groups)
        if out.empty:
            return out
        out = out.copy()
        out["Incl Cash"] = [_pct_cell_label(value) for value in out["Incl Cash"]]
        out["Ex Cash"] = [_pct_cell_label(value) for value in out["Ex Cash"]]
        return out

    def _full_positions_frame(self) -> pd.DataFrame:
        columns = list(FULL_POSITION_COLUMNS)
        if self._result is None:
            return pd.DataFrame(columns=columns)
        if self._full_positions_cache is None:
            positions = self._result.positions.copy()
            if positions.empty:
                self._full_positions_cache = pd.DataFrame(columns=columns)
            else:
                positions["_Sort Agg Wgt"] = pd.to_numeric(
                    positions["Agg Wgt (incl cash)"],
                    errors="coerce",
                )
                positions = positions.sort_values(
                    [
                        "Fund Name",
                        "_Sort Agg Wgt",
                        "AIM Code",
                        "Ticker",
                    ],
                    ascending=[True, False, True, True],
                    na_position="last",
                )

                def values(column: str, default=""):
                    if column in positions.columns:
                        return positions[column].to_numpy()
                    return pd.Series(default, index=positions.index).to_numpy()

                self._full_positions_cache = pd.DataFrame(
                    {
                        "AIM Code": values("AIM Code"),
                        "Fund Name": values("Fund Name"),
                        "Asset": values("Asset"),
                        "Ticker": values("Ticker"),
                        "NAME": values("Name"),
                        "Parent/Issuer Ticker": values("Parent/Issuer Ticker"),
                        "Parent/Issuer Name": values("Parent/Issuer Name"),
                        "Quantity": pd.to_numeric(
                            positions["Quantity"],
                            errors="coerce",
                        ).to_numpy(),
                        "Price Date": positions["Price Date"].map(_fmt_date).to_numpy(),
                        "AIM Image": values("AIM Position"),
                        "Ccy": pd.Series(
                            "USD",
                            index=positions.index,
                        ).to_numpy(),
                        "USD Price": pd.to_numeric(
                            positions["Price USD"],
                            errors="coerce",
                        ).to_numpy(),
                        "MV(USD)": pd.to_numeric(
                            positions["Market Value USD"],
                            errors="coerce",
                        ).to_numpy(),
                        "Weight": pd.to_numeric(
                            positions["Weight"],
                            errors="coerce",
                        ).to_numpy(),
                        "Agg Wgt (incl cash)": pd.to_numeric(
                            positions["Agg Wgt (incl cash)"],
                            errors="coerce",
                        ).to_numpy(),
                        "Agg Wgt (ex cash)": pd.to_numeric(
                            positions["Agg Wgt (ex cash)"],
                            errors="coerce",
                        ).to_numpy(),
                        "Capping": pd.to_numeric(
                            positions["Capping"],
                            errors="coerce",
                        ).to_numpy(),
                        "Largest": pd.to_numeric(
                            positions["Largest"],
                            errors="coerce",
                        ).to_numpy(),
                        "Rank": pd.to_numeric(
                            positions["Rank"],
                            errors="coerce",
                        ).to_numpy(),
                        "Level": values("Level"),
                        "Type": values("Type"),
                        "Primary FM": values("Primary FM"),
                    },
                    columns=columns,
                )
        out = self._full_positions_cache
        if out is None:
            return pd.DataFrame(columns=columns)
        account = self.full_positions_filter.value
        if account != "All":
            out = out.loc[out["AIM Code"].eq(account)]
        fm = self.full_positions_fm_filter.value
        if fm != "All" and "Primary FM" in out.columns:
            out = out.loc[out["Primary FM"].eq(fm)]
        out = out.copy()
        out.index = pd.Index(range(1, len(out) + 1), name="#")
        return out

    def _active_full_column_filters(self) -> dict[str, str]:
        return {
            column: field.value.strip()
            for column, field in self.full_column_filters.items()
            if field.value.strip()
        }

    def _full_column_filter_mask(
        self,
        frame: pd.DataFrame,
        column: str,
        query: str,
    ) -> pd.Series:
        series = frame[column]
        if column not in FULL_POSITION_NUMERIC_COLUMNS:
            if query.strip().lower() in {"<blank>", "(blank)"}:
                return series.fillna("").astype(str).str.strip().eq("")
            return (
                series.fillna("")
                .astype(str)
                .str.contains(query, case=False, regex=False, na=False)
            )

        normalized = query.replace(",", "").strip()
        match = re.fullmatch(
            r"(<=|>=|!=|==|=|<|>)?\s*" r"([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*(%)?",
            normalized,
        )
        if match is None:
            return (
                series.fillna("")
                .astype(str)
                .str.contains(query, case=False, regex=False, na=False)
            )
        operator = match.group(1) or "="
        target = float(match.group(2))
        if match.group(3):
            if column not in FULL_POSITION_PERCENT_COLUMNS:
                return pd.Series(False, index=frame.index)
            target /= 100.0
        numeric = pd.to_numeric(series, errors="coerce").astype(float)
        if operator in {"=", "=="}:
            return pd.Series(
                np.isclose(numeric, target, rtol=1e-9, atol=1e-12),
                index=frame.index,
            )
        if operator == "!=":
            return numeric.notna() & ~pd.Series(
                np.isclose(numeric, target, rtol=1e-9, atol=1e-12),
                index=frame.index,
            )
        if operator == ">":
            return numeric.gt(target)
        if operator == ">=":
            return numeric.ge(target)
        if operator == "<":
            return numeric.lt(target)
        return numeric.le(target)

    def _filtered_full_positions_frame(
        self,
        base_frame: pd.DataFrame | None = None,
    ) -> pd.DataFrame:
        frame = (
            self._full_positions_frame() if base_frame is None else base_frame.copy()
        )
        name_keyword = self.full_positions_name_search.value.strip()
        if name_keyword:
            frame = frame.loc[
                frame["NAME"]
                .fillna("")
                .astype(str)
                .str.contains(
                    name_keyword,
                    case=False,
                    regex=False,
                    na=False,
                )
            ]
        for column, query in self._active_full_column_filters().items():
            frame = frame.loc[self._full_column_filter_mask(frame, column, query)]
        return frame

    def _update_full_filter_summary(self, shown: int, total: int):
        active = self._active_full_column_filters()
        active_count = len(active)
        title = (
            f"Advanced Column Filters — {active_count} active / "
            f"{len(FULL_POSITION_ADVANCED_COLUMNS)} columns"
            if active_count
            else "Advanced Column Filters — remaining "
            f"{len(FULL_POSITION_ADVANCED_COLUMNS)} columns"
        )
        self.full_column_filter_panel.set_title(0, title)
        color = "#7aa2f7" if active_count else "#8b93a7"
        label = (
            f"{active_count} active · showing {shown:,} of {total:,} rows"
            if active_count
            else f"No advanced filters · showing {shown:,} of {total:,} rows"
        )
        self.full_filter_summary.value = (
            f'<span style="color:{color};font-size:11px;">' f"{escape(label)}</span>"
        )

    def _full_position_renderers(self) -> dict:
        percentage = TextRenderer(
            format=".4%",
            horizontal_alignment="right",
            text_color="#e8edf5",
        )
        return {
            "Quantity": TextRenderer(
                format=",.2f",
                horizontal_alignment="right",
            ),
            "USD Price": TextRenderer(
                format=",.6f",
                horizontal_alignment="right",
            ),
            "MV(USD)": TextRenderer(
                format=",.2f",
                horizontal_alignment="right",
            ),
            "Weight": percentage,
            "Agg Wgt (incl cash)": percentage,
            "Agg Wgt (ex cash)": percentage,
            "Capping": percentage,
            "Largest": percentage,
            "Rank": TextRenderer(
                format=".0f",
                horizontal_alignment="center",
            ),
        }

    def _full_position_column_widths(self) -> dict:
        return {
            "AIM Code": 92,
            "Fund Name": 250,
            "Asset": 88,
            "Ticker": 145,
            "NAME": 180,
            "Parent/Issuer Ticker": 150,
            "Parent/Issuer Name": 180,
            "Quantity": 105,
            "Price Date": 92,
            "AIM Image": 88,
            "Ccy": 48,
            "USD Price": 100,
            "MV(USD)": 115,
            "Weight": 82,
            "Agg Wgt (incl cash)": 112,
            "Agg Wgt (ex cash)": 108,
            "Capping": 76,
            "Largest": 76,
            "Rank": 54,
            "Level": 72,
            "Type": 92,
            "Primary FM": 130,
        }

    def _render_full_positions(self):
        base_frame = self._full_positions_frame()
        frame = self._filtered_full_positions_frame(base_frame)
        self._update_full_filter_summary(len(frame), len(base_frame))
        if base_frame.empty:
            account = self.full_positions_filter.value
            message = (
                "No positions were returned for the selected fund."
                if account != "All"
                else "No positions are available."
            )
            self.full_positions_box.children = [self._empty_state(message)]
            return
        if frame.empty:
            self.full_positions_box.children = [
                self._empty_state("No positions match the active column filters.")
            ]
            return
        grid = DataGrid(
            frame,
            base_row_size=28,
            base_column_size=96,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
                font="bold 11px sans-serif",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            renderers=self._full_position_renderers(),
            column_widths=self._full_position_column_widths(),
            layout={"width": "100%", "height": "600px"},
        )
        account_count = frame["AIM Code"].nunique()
        name_keyword = self.full_positions_name_search.value.strip()
        name_note = f" · NAME contains “{escape(name_keyword)}”" if name_keyword else ""
        self.full_positions_box.children = [
            widgets.HTML(
                '<div style="color:#8b93a7;font-size:11px;padding:0 2px 6px;">'
                f"{len(frame):,} of {len(base_frame):,} positions · "
                f"{account_count} fund(s){name_note}"
                "</div>"
            ),
            grid,
        ]

    def _monitor_renderers(self, groups: pd.DataFrame) -> dict:
        percentage = TextRenderer(
            format=".2%",
            horizontal_alignment="right",
            text_color="#e8edf5",
        )
        return {
            "Fund": TextRenderer(text_color="#eef1f6"),
            "Company": TextRenderer(text_color="#eef1f6"),
            "Incl Cash": _weight_cell_renderer(
                _monitor_weight_tones(groups, "Agg Wgt (incl cash)")
            ),
            "Ex Cash": _weight_cell_renderer(
                _monitor_weight_tones(groups, "Agg Wgt (ex cash)")
            ),
            "Cap": percentage,
            "Largest": percentage,
            "Limit": percentage,
            "Headroom": percentage,
            "Rank": TextRenderer(format=".0f", horizontal_alignment="center"),
            "Status": _status_renderer(),
        }

    def _on_monitor_click(self, groups: pd.DataFrame, event):
        try:
            row_number = int(event["primary_key_row"])
            row = groups.iloc[row_number]
        except Exception:
            return
        self._selected_key = (row["AIM Code"], row["Parent/Issuer Ticker"])
        self._render_detail(*self._selected_key)

    def _alert_buttons(self):
        if self._result is None:
            return []
        alerts = self._result.groups.loc[
            self._result.groups["Is Equity"].fillna(False)
            & self._result.groups["Capping Status"].isin(["Breach", "Near Limit"])
        ].copy()
        alerts["_order"] = (
            alerts["Capping Status"].map({"Breach": 0, "Near Limit": 1}).fillna(2)
        )
        alerts = alerts.sort_values(
            ["_order", "Utilisation"],
            ascending=[True, False],
        ).head(24)
        buttons = []
        for _, row in alerts.iterrows():
            status = str(row["Status"])
            button = widgets.Button(
                description=(
                    f"{status.upper()} · {row['AIM Code']} · "
                    f"{_short_ticker(row['Parent/Issuer Ticker'])} · "
                    f"{_fmt_pct(row['Observed Weight'])}"
                ),
                layout=widgets.Layout(
                    width="auto",
                    height="30px",
                    margin="2px 5px 2px 0",
                ),
                tooltip=row["Parent/Issuer Name"],
            )
            button.style.button_color = STATUS_COLORS.get(status, "#5f6b7a")
            button.on_click(
                partial(
                    self._on_alert_chip,
                    row["AIM Code"],
                    row["Parent/Issuer Ticker"],
                )
            )
            buttons.append(button)
        return buttons

    def _on_alert_chip(self, account: str, parent_ticker: str, _button=None):
        self._fixing_filter = True
        try:
            self.account_filter.value = account
            self.status_filter.value = "Alerts"
            self.search.value = ""
            self.primary_fm_filter.value = "All"
        finally:
            self._fixing_filter = False
        self.tabs.selected_index = 0
        self._selected_key = (account, parent_ticker)
        self._render_monitor()

    def _render_detail(self, account: str, parent_ticker: str):
        if self._result is None:
            return
        match = self._result.groups.loc[
            self._result.groups["AIM Code"].eq(account)
            & self._result.groups["Parent/Issuer Ticker"].eq(parent_ticker)
        ]
        if match.empty:
            return
        row = match.iloc[0]
        self.detail_header.value = self._detail_html(row)

        self._full_positions_frame()
        all_full_positions = (
            self._full_positions_cache.copy()
            if self._full_positions_cache is not None
            else pd.DataFrame(columns=FULL_POSITION_COLUMNS)
        )
        listings = all_full_positions.loc[
            all_full_positions["AIM Code"].eq(account)
            & all_full_positions["Parent/Issuer Ticker"].eq(parent_ticker)
        ].copy()
        listings["_Detail MV"] = pd.to_numeric(
            listings["MV(USD)"],
            errors="coerce",
        )
        listings = listings.sort_values(
            ["_Detail MV", "Ticker"],
            ascending=[False, True],
            na_position="last",
        )

        detail_columns = [
            "Ticker",
            "NAME",
            "Quantity",
            "MV(USD)",
            "Agg Wgt (incl cash)",
            "Agg Wgt (ex cash)",
        ]
        listing_frame = listings.loc[:, detail_columns].copy()
        listing_frame.index = pd.Index(
            range(1, len(listing_frame) + 1),
            name="#",
        )
        self._draw_detail_figure(row, listing_frame)
        listing_grid = DataGrid(
            listing_frame,
            base_row_size=25,
            base_column_size=80,
            base_row_header_size=32,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#e8edf5",
                font="bold 11px sans-serif",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            renderers={
                "Quantity": TextRenderer(
                    format=",.2f",
                    horizontal_alignment="right",
                ),
                "MV(USD)": TextRenderer(
                    format=",.2f",
                    horizontal_alignment="right",
                ),
                "Agg Wgt (incl cash)": TextRenderer(
                    format=".4%",
                    horizontal_alignment="right",
                ),
                "Agg Wgt (ex cash)": TextRenderer(
                    format=".4%",
                    horizontal_alignment="right",
                ),
            },
            column_widths={
                "Ticker": 130,
                "NAME": 220,
                "Quantity": 105,
                "MV(USD)": 115,
                "Agg Wgt (incl cash)": 112,
                "Agg Wgt (ex cash)": 108,
            },
            layout={"width": "100%", "height": "225px"},
        )
        self.listing_box.children = [
            widgets.HTML(
                '<div style="color:#8b93a7;font-size:11px;padding:4px 2px 6px;">'
                f"Fund Position breakdown · {len(listings)} actual holding(s). "
                "Rows come from the same cached Full Positions data; this Detail "
                "table shows only Ticker, NAME, Quantity, MV(USD), and the two "
                "aggregate-weight columns, sorted by MV(USD) descending. The "
                "stacked chart above is derived only from these displayed rows."
                "</div>"
            ),
            listing_grid,
        ]

    def _detail_html(self, row: pd.Series) -> str:
        status = _text(row["Status"])
        color = STATUS_COLORS.get(status, "#7aa2f7")
        quality = _text(row.get("Data Quality", "OK"))
        quality_note = ""
        if quality == "Data Issue":
            quality_note = (
                '<div style="color:#c7a4ff;font-size:10px;padding-top:4px;">'
                "Account data is incomplete; review Diagnostics.</div>"
            )
        return (
            '<div style="background:#171d2b;border:1px solid #283043;'
            'border-radius:12px;padding:13px 15px;margin:0 0 6px;">'
            '<div style="display:flex;justify-content:space-between;gap:12px;">'
            "<div>"
            f'<div style="color:#8b93a7;font-size:10px;letter-spacing:.12em;">'
            f"{escape(_text(row['AIM Code']))} · RANK {escape(_text(row['Rank']))}</div>"
            f'<div style="color:#9aa4b5;font-size:10px;padding-top:2px;">'
            f"{escape(_text(row['Fund Name']))}</div>"
            f'<div style="color:#f3f5f8;font-size:17px;font-weight:650;padding-top:3px;">'
            f"{escape(_text(row['Parent/Issuer Name']))}</div>"
            f'<div style="color:#9aa4b5;font-size:11px;padding-top:2px;">'
            f"Company key: {escape(_text(row['Parent/Issuer Ticker']))} · "
            f"{escape(_text(row['Listing Count']))} listing(s) · "
            f"{escape(_text(row['Mapping Source']))}</div>"
            f"{quality_note}"
            "</div>"
            f'<div style="color:{color};font-size:12px;font-weight:700;'
            f'padding-top:2px;">{escape(status)}</div>'
            "</div>"
            '<div style="display:flex;gap:16px;padding-top:11px;flex-wrap:wrap;">'
            f'{self._mini_metric("INCL CASH", _fmt_pct(row["Agg Wgt (incl cash)"]))}'
            f'{self._mini_metric("EX CASH", _fmt_pct(row["Agg Wgt (ex cash)"]))}'
            f'{self._mini_metric("LIMIT", _fmt_pct(row["Dynamic Limit"]))}'
            f'{self._mini_metric("HEADROOM", _fmt_pct(row["Headroom"], signed=True))}'
            "</div>"
            "</div>"
        )

    def _mini_metric(self, label: str, value: str) -> str:
        return (
            '<div style="min-width:70px;">'
            f'<div style="color:#737e91;font-size:9px;letter-spacing:.09em;">{label}</div>'
            f'<div style="color:#e8edf5;font-size:13px;font-weight:600;">{value}</div>'
            "</div>"
        )

    def _empty_detail_figure(self) -> go.FigureWidget:
        figure = go.FigureWidget()
        figure.update_layout(
            template="plotly_dark",
            height=285,
            margin=dict(l=132, r=28, t=46, b=78),
            paper_bgcolor="#121722",
            plot_bgcolor="#121722",
            showlegend=False,
            barmode="relative",
            bargap=0.34,
            hovermode="closest",
            title=dict(
                text="Holding contribution to aggregated weight",
                font=dict(size=12),
            ),
            legend=dict(
                title=dict(text="Actual AIM holdings"),
                orientation="h",
                x=0,
                y=-0.28,
                xanchor="left",
                yanchor="top",
                font=dict(size=9),
            ),
            xaxis=dict(
                tickformat=".1%",
                gridcolor="#293142",
                zerolinecolor="#4a5568",
                range=[0, 0.01],
            ),
            yaxis=dict(
                gridcolor="#293142",
                categoryorder="array",
                categoryarray=[
                    "Agg Wgt (ex cash)",
                    "Agg Wgt (incl cash)",
                ],
            ),
        )
        return figure

    def _detail_bar_breakdown(
        self,
        breakdown: pd.DataFrame,
    ) -> tuple[list[float], list[list[float]]]:
        def displayed_total(column: str) -> float:
            source = (
                breakdown[column]
                if column in breakdown.columns
                else pd.Series(dtype=float)
            )
            values = pd.to_numeric(
                source,
                errors="coerce",
            ).dropna()
            return float(values.iloc[0]) if not values.empty else 0.0

        totals = [
            displayed_total("Agg Wgt (incl cash)"),
            displayed_total("Agg Wgt (ex cash)"),
        ]
        market_values = pd.to_numeric(
            (
                breakdown["MV(USD)"]
                if "MV(USD)" in breakdown.columns
                else pd.Series(0.0, index=breakdown.index)
            ),
            errors="coerce",
        ).fillna(0.0)
        group_market_value = float(market_values.sum())
        if breakdown.empty or np.isclose(group_market_value, 0.0):
            return totals, [[0.0, 0.0] for _ in range(len(breakdown))]

        shares = market_values / group_market_value
        contributions = [
            [float(share * totals[0]), float(share * totals[1])] for share in shares
        ]
        # Assign floating-point residuals to the largest-MV first row so each
        # stacked bar reconciles exactly to the values displayed in the table.
        for column_index, total in enumerate(totals):
            residual = total - sum(values[column_index] for values in contributions)
            contributions[0][column_index] += residual
        return totals, contributions

    def _draw_detail_figure(
        self,
        row: pd.Series,
        breakdown: pd.DataFrame,
    ):
        categories = [
            "Agg Wgt (incl cash)",
            "Agg Wgt (ex cash)",
        ]
        totals, contributions = self._detail_bar_breakdown(breakdown)
        limit = float(row["Dynamic Limit"]) if pd.notna(row["Dynamic Limit"]) else 0.0
        positive_extent = max(
            [
                sum(max(values[index], 0.0) for values in contributions)
                for index in range(2)
            ]
            + [max(totals + [limit, 0.01])]
        )
        negative_extent = min(
            [
                sum(min(values[index], 0.0) for values in contributions)
                for index in range(2)
            ]
            + [min(totals + [0.0])]
        )
        span = max(positive_extent - negative_extent, 0.01)
        x_range = [
            negative_extent - (0.06 * span if negative_extent < 0 else 0.0),
            positive_extent + 0.22 * span,
        ]

        with self.detail_figure.batch_update():
            self.detail_figure.data = ()
            for index, (_, listing) in enumerate(breakdown.iterrows()):
                ticker = _text(listing.get("Ticker"))
                name = _text(listing.get("NAME"))
                quantity = (
                    float(listing["Quantity"])
                    if pd.notna(listing.get("Quantity"))
                    else np.nan
                )
                market_value = (
                    float(listing["MV(USD)"])
                    if pd.notna(listing.get("MV(USD)"))
                    else np.nan
                )
                agg_incl = (
                    float(listing["Agg Wgt (incl cash)"])
                    if pd.notna(listing.get("Agg Wgt (incl cash)"))
                    else np.nan
                )
                agg_ex = (
                    float(listing["Agg Wgt (ex cash)"])
                    if pd.notna(listing.get("Agg Wgt (ex cash)"))
                    else np.nan
                )
                custom_row = [
                    escape(ticker),
                    escape(name),
                    quantity,
                    market_value,
                    agg_incl,
                    agg_ex,
                ]
                self.detail_figure.add_bar(
                    x=contributions[index],
                    y=categories,
                    name=_short_ticker(ticker),
                    orientation="h",
                    marker_color=HOLDING_COLORS[index % len(HOLDING_COLORS)],
                    customdata=[custom_row, custom_row],
                    hovertemplate=(
                        "<b>%{customdata[0]}</b><br>"
                        "%{customdata[1]}<br>"
                        "Bar: %{y}<br>"
                        "Contribution: %{x:.4%}<br>"
                        "Quantity: %{customdata[2]:,.2f}<br>"
                        "MV USD: %{customdata[3]:,.2f}<br>"
                        "Displayed Agg Wgt incl cash: %{customdata[4]:.4%}<br>"
                        "Displayed Agg Wgt ex cash: %{customdata[5]:.4%}"
                        "<extra></extra>"
                    ),
                )
            self.detail_figure.layout.shapes = (
                dict(
                    type="line",
                    x0=limit,
                    x1=limit,
                    y0=-0.5,
                    y1=1.5,
                    line=dict(color="#f3f5f8", width=2, dash="dash"),
                ),
            )
            self.detail_figure.layout.annotations = (
                dict(
                    x=limit,
                    y=1.16,
                    xref="x",
                    yref="paper",
                    text=f"Limit {_fmt_pct(limit)}",
                    showarrow=False,
                    font=dict(color="#f3f5f8", size=10),
                ),
                dict(
                    x=totals[0],
                    y=categories[0],
                    text=_fmt_pct(totals[0]),
                    showarrow=False,
                    xanchor="left" if totals[0] >= 0 else "right",
                    xshift=5 if totals[0] >= 0 else -5,
                    font=dict(color="#eef1f6", size=10),
                ),
                dict(
                    x=totals[1],
                    y=categories[1],
                    text=_fmt_pct(totals[1]),
                    showarrow=False,
                    xanchor="left" if totals[1] >= 0 else "right",
                    xshift=5 if totals[1] >= 0 else -5,
                    font=dict(color="#eef1f6", size=10),
                ),
            )
            self.detail_figure.layout.title.text = (
                f"Holding contribution to aggregated weight · "
                f"{len(breakdown)} holding(s)"
            )
            self.detail_figure.layout.showlegend = True
            self.detail_figure.layout.xaxis.range = x_range

    def _clear_detail_figure(self):
        with self.detail_figure.batch_update():
            self.detail_figure.data = ()
            self.detail_figure.layout.shapes = ()
            self.detail_figure.layout.annotations = ()
            self.detail_figure.layout.title.text = (
                "Holding contribution to aggregated weight"
            )
            self.detail_figure.layout.showlegend = False
            self.detail_figure.layout.xaxis.range = [0, 0.01]

    def _render_summary(self):
        if self._result is None:
            return
        groups = self._result.groups.loc[
            self._result.groups["Is Equity"].fillna(False)
        ].copy()
        if "Primary FM" not in groups.columns:
            groups["Primary FM"] = ""
        groups["_valid_breach"] = groups["Capping Status"].eq("Breach")
        groups["_valid_near"] = groups["Capping Status"].eq("Near Limit")
        groups["_data_issue"] = groups["Data Quality"].eq("Data Issue")
        summary = groups.groupby(
            ["AIM Code", "Fund Name", "Primary FM", "Level", "Type"],
            as_index=False,
        ).agg(
            Companies=("Parent/Issuer Ticker", "nunique"),
            Breaches=("_valid_breach", "sum"),
            Near=("_valid_near", "sum"),
            Data_Issues=("_data_issue", "sum"),
        )
        summary["Status"] = np.select(
            [
                summary["Breaches"].gt(0),
                summary["Near"].gt(0),
                summary["Data_Issues"].gt(0),
            ],
            ["Breach", "Near Limit", "Data Issue"],
            default="OK",
        )
        summary = summary.sort_values(
            ["Breaches", "Near", "Data_Issues"],
            ascending=[False, False, False],
        ).reset_index(drop=True)
        self._summary_frame = summary
        display_frame = summary.rename(
            columns={
                "AIM Code": "AIM",
                "Fund Name": "Fund",
                "Data_Issues": "Data Issues",
            }
        )[
            [
                "AIM",
                "Fund",
                "Primary FM",
                "Level",
                "Type",
                "Companies",
                "Breaches",
                "Near",
                "Data Issues",
                "Status",
            ]
        ]
        display_frame.index = pd.Index(range(1, len(display_frame) + 1), name="#")
        grid = DataGrid(
            display_frame,
            base_row_size=28,
            base_column_size=92,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            renderers={
                "Status": _status_renderer(),
            },
            column_widths={
                "AIM": 86,
                "Fund": 310,
                "Primary FM": 130,
                "Level": 70,
                "Type": 82,
                "Companies": 76,
                "Breaches": 70,
                "Near": 60,
                "Data Issues": 78,
                "Status": 88,
            },
            layout={"width": "100%", "height": "570px"},
        )
        grid.on_cell_click(partial(self._on_summary_click, summary))
        self.summary_box.children = [
            self.summary_export,
            widgets.HTML(
                '<div style="color:#8b93a7;font-size:12px;padding:6px 2px 8px;">'
                "Click an account to open its company-level rows in Monitor."
                "</div>"
            ),
            grid,
        ]

    def _on_summary_click(self, summary: pd.DataFrame, event):
        try:
            row_number = int(event["primary_key_row"])
            account = summary.iloc[row_number]["AIM Code"]
        except Exception:
            return
        self._fixing_filter = True
        try:
            self.account_filter.value = account
            self.status_filter.value = "All"
            self.search.value = ""
            self.primary_fm_filter.value = "All"
        finally:
            self._fixing_filter = False
        self.tabs.selected_index = 0
        self._render_monitor()

    def _render_static_tabs(self):
        runbook = account_rules_frame().copy()
        runbook.index = pd.Index(range(1, len(runbook) + 1), name="#")
        runbook_grid = DataGrid(
            runbook,
            base_row_size=27,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            renderers={
                "Capping": TextRenderer(format=".1%"),
                "Largest": TextRenderer(format=".1%"),
            },
            column_widths={
                "AIM Code": 92,
                "Fund Name": 410,
                "Capping": 90,
                "Largest": 90,
                "Level": 80,
                "Type": 90,
                "Primary FM": 130,
            },
            layout={"width": "100%", "height": "575px"},
        )
        self.runbook_box.children = [
            self.runbook_export,
            widgets.HTML(
                f'<div style="color:#8b93a7;font-size:12px;padding:6px 2px 8px;">'
                f"Bundled read-only runbook · {len(runbook)} AIM accounts."
                "</div>"
            ),
            runbook_grid,
        ]

        exceptions = exception_rules_frame().copy()
        exceptions.index = pd.Index(range(1, len(exceptions) + 1), name="#")
        exception_grid = DataGrid(
            exceptions,
            base_row_size=29,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            column_widths={
                "Ticker": 145,
                "Name": 260,
                "Parent Ticker": 150,
                "Parent Name": 220,
            },
            layout={"width": "100%", "height": "250px"},
        )
        thai_pricing = thai_pricing_rules_frame().copy()
        thai_pricing.index = pd.Index(
            range(1, len(thai_pricing) + 1),
            name="#",
        )
        thai_pricing_grid = DataGrid(
            thai_pricing,
            base_row_size=29,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            column_widths={
                "Foreign Ticker": 170,
                "Local Price Ticker": 170,
                "Reason": 430,
            },
            layout={"width": "100%", "height": "130px"},
        )
        self.exceptions_box.children = [
            self.exceptions_export,
            widgets.HTML(
                '<div style="color:#8b93a7;font-size:12px;padding:6px 2px 8px;">'
                "Hard overrides take priority over every Bloomberg company mapping."
                "</div>"
            ),
            exception_grid,
            widgets.HTML(
                '<div style="color:#8b93a7;font-size:12px;padding:14px 2px 8px;">'
                "Approved Thai foreign-line pricing overrides. Leftover "
                "/F and -R lines may use HelpDesk-confirmed obligor ticker "
                "only after override and strip fail. CAST parent ticker and "
                "integer company ID are not used as local-price mappers."
                "</div>"
            ),
            thai_pricing_grid,
        ]
        self.documentation_box.children = [
            widgets.HTML(
                value=_documentation_html(),
                layout=widgets.Layout(width="100%"),
            )
        ]

    def _render_diagnostics(self):
        if self._result is None or self._result.diagnostics.empty:
            self.diagnostics_box.children = [
                self.diagnostics_export,
                self._empty_state("No diagnostics were recorded."),
            ]
            return
        diagnostics = self._result.diagnostics.copy()
        diagnostics.index = pd.Index(range(1, len(diagnostics) + 1), name="#")
        grid = DataGrid(
            diagnostics,
            base_row_size=29,
            base_row_header_size=42,
            header_renderer=TextRenderer(
                background_color="#202737",
                text_color="#eef1f6",
            ),
            default_renderer=TextRenderer(
                background_color="#151a25",
                text_color="#dce1ea",
            ),
            column_widths={
                "AIM Code": 95,
                "Ticker": 145,
                "Category": 120,
                "Message": 570,
            },
            layout={"width": "100%", "height": "570px"},
        )
        self.diagnostics_box.children = [self.diagnostics_export, grid]

    def _cards_html(self) -> str:
        groups = self._result.groups if self._result is not None else pd.DataFrame()
        positions = (
            self._result.positions if self._result is not None else pd.DataFrame()
        )
        accounts = groups["AIM Code"].nunique() if not groups.empty else 0
        equity = (
            groups.loc[groups["Is Equity"].fillna(False)]
            if not groups.empty
            else groups
        )
        breaches = (
            int(equity["Capping Status"].eq("Breach").sum()) if not equity.empty else 0
        )
        near = (
            int(equity["Capping Status"].eq("Near Limit").sum())
            if not equity.empty
            else 0
        )
        data_issues = (
            int((groups["Data Quality"] == "Data Issue").sum())
            if not groups.empty
            else 0
        )
        specs = (
            ("ACCOUNTS", accounts, "#7aa2f7", f"{len(positions):,} position rows"),
            ("BREACHES", breaches, "#ff5c5c", "At or above dynamic limit"),
            (
                "NEAR LIMIT",
                near,
                "#f5a623",
                f"At or above {WARNING_RATIO:.1%} of limit",
            ),
            (
                "DATA ISSUES",
                data_issues,
                "#b388ff",
                "Affected company group(s)",
            ),
        )
        cards = [
            (
                '<div style="flex:1;min-width:170px;background:#171d2b;'
                f"border:1px solid #283043;border-top:3px solid {color};"
                'border-radius:12px;padding:12px 14px;">'
                f'<div style="color:#7e899c;font-size:10px;letter-spacing:.12em;">{label}</div>'
                f'<div style="color:#f3f5f8;font-size:24px;font-weight:680;padding-top:3px;">{value}</div>'
                f'<div style="color:#8993a5;font-size:11px;padding-top:2px;">{note}</div>'
                "</div>"
            )
            for label, value, color, note in specs
        ]
        return (
            '<div style="display:flex;gap:10px;flex-wrap:wrap;padding:7px 0 8px;">'
            + "".join(cards)
            + "</div>"
        )

    def _empty_cards_html(self) -> str:
        return (
            '<div style="display:flex;gap:10px;flex-wrap:wrap;padding:7px 0 8px;">'
            + "".join(
                (
                    '<div style="flex:1;min-width:170px;background:#171d2b;'
                    'border:1px solid #283043;border-radius:12px;padding:12px 14px;">'
                    f'<div style="color:#7e899c;font-size:10px;letter-spacing:.12em;">{label}</div>'
                    '<div style="color:#f3f5f8;font-size:24px;font-weight:680;padding-top:3px;">—</div>'
                    '<div style="color:#8993a5;font-size:11px;padding-top:2px;">Waiting for Update</div>'
                    "</div>"
                )
                for label in ("ACCOUNTS", "BREACHES", "NEAR LIMIT", "DATA ISSUES")
            )
            + "</div>"
        )

    def _header_html(
        self,
        state: str,
        extra: str = "",
        color: str = "#7aa2f7",
    ) -> str:
        safe_extra = escape(_text(extra))
        return (
            '<div style="display:flex;justify-content:space-between;align-items:flex-end;'
            'padding:4px 2px 10px;border-bottom:1px solid #2a3142;margin-bottom:7px;">'
            "<div>"
            '<div style="color:#8b93a7;font-size:10px;letter-spacing:.15em;">BQUANT APP</div>'
            '<div style="color:#f3f5f8;font-size:23px;font-weight:680;letter-spacing:.01em;">'
            "ETF Capping Monitor</div>"
            f'<div style="color:#8b93a7;font-size:12px;padding-top:2px;">{safe_extra}</div>'
            "</div>"
            f'<div style="color:{color};font-size:12px;font-weight:650;'
            f'padding-bottom:4px;">{escape(state)}</div>'
            "</div>"
        )

    def _status_html(
        self,
        message: str,
        color: str,
        loading: bool = False,
    ) -> str:
        marker = "●" if not loading else "◌"
        safe_message = escape(_text(message))
        return (
            '<div style="background:#141a25;border:1px solid #252d3e;'
            "border-radius:8px;padding:7px 10px;margin:4px 0 2px;"
            f'color:{color};font-size:12px;">{marker}&nbsp;&nbsp;{safe_message}</div>'
        )

    def _legend_html(self) -> str:
        return (
            '<div style="display:flex;gap:24px;flex-wrap:wrap;border-top:1px solid #293142;'
            'padding:9px 2px 2px;margin-top:7px;color:#9aa4b5;font-size:11px;">'
            '<div><b style="color:#ff7777;">BREACH</b>&nbsp;&nbsp;Weight ≥ dynamic limit</div>'
            f'<div><b style="color:#ffc45c;">NEAR LIMIT</b>&nbsp;&nbsp;Weight ≥ '
            f"{WARNING_RATIO:.1%} × dynamic limit</div>"
            '<div><b style="color:#c7a4ff;">DATA ISSUE</b>&nbsp;&nbsp;Missing required '
            "price, quantity, or account rule; empty official market statuses "
            "are valid zeros if Bloomberg has no last price</div>"
            '<div><b style="color:#7aa2f7;">DYNAMIC LIMIT</b>&nbsp;&nbsp;Rank 1 uses '
            "Largest; all other ranks use Capping</div>"
            "</div>"
        )

    def _detail_empty_html(self, message: str) -> str:
        return (
            '<div style="background:#171d2b;border:1px solid #283043;'
            "border-radius:12px;padding:15px;color:#8b93a7;font-size:12px;"
            f'margin-bottom:6px;">{escape(message)}</div>'
        )

    def _empty_state(self, message: str) -> widgets.HTML:
        return widgets.HTML(
            value=(
                '<div style="background:#151a25;border:1px dashed #30394d;'
                'border-radius:10px;color:#7f899b;font-size:12px;padding:18px;">'
                f"{escape(message)}</div>"
            )
        )
