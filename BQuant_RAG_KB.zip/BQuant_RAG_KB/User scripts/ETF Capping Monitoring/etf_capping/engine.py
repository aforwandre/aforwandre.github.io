"""Pure-Pandas position weighting and capping calculations."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .config import WARNING_RATIO, account_rules_frame, exception_rules_frame


REQUIRED_POSITION_COLUMNS = ("AIM Code", "Ticker", "Quantity")
FIELD_NOT_APPLICABLE = (
    "#N/A Field Not Applicable",
    "Field Not Applicable",
    "#N/A",
    "N/A",
    "NA",
    "None",
    "nan",
)
FIELD_NOT_APPLICABLE_UPPER = {value.upper() for value in FIELD_NOT_APPLICABLE}
# Statuses where a missing px_last is expected (not a Data Issue).
# A numeric Bloomberg last price is always carried, including Suspended.
# After diagnostics, any remaining empty/non-numeric price falls back to
# zero so sibling weights still calculate.
ZERO_PRICE_MARKET_STATUSES = {
    "DLST",
    "DELISTED",
    "UNLS",
    "UNLISTED",
    "PRNA",
    "PRICE NOT AVAILABLE",
    "PRIV",
    "PRIVATE COMPANY",
    "INAC",
    "INACTIVE",
    "SUSP",
    "SUSPENDED",
    "EXPD",
    "EXPIRED",
    "PEND",
    "PENDING LISTING",
    "LIQU",
    "LIQUIDATED",
    "RCNA",
    "REASON NOT AVAILABLE",
}


@dataclass
class MonitorResult:
    positions: pd.DataFrame
    groups: pd.DataFrame
    alerts: pd.DataFrame
    diagnostics: pd.DataFrame


def _clean_text(value) -> str:
    if value is None or pd.isna(value):
        return ""
    text = str(value).strip()
    upper = text.upper()
    return (
        "" if upper in FIELD_NOT_APPLICABLE_UPPER or upper.startswith("#N/A") else text
    )


def _ensure_equity_suffix(value) -> str:
    text = _clean_text(value)
    if not text:
        return ""
    if text.endswith(" Equity"):
        return text
    return f"{text} Equity"


def _is_zero_price_market_status(value) -> bool:
    return _clean_text(value).upper() in ZERO_PRICE_MARKET_STATUSES


def classify_asset(ticker: str) -> str:
    """Match the asset classification in ETF Capping Formula.xlsx."""
    text = _clean_text(ticker)
    if text.endswith(" Curncy"):
        return "FFX" if len(text) > 11 else "Cash"
    if text.endswith(" Index"):
        return "Index Future"
    if text.endswith(" Equity"):
        return "Equity"
    return "Others"


def _validate_positions(frame: pd.DataFrame) -> None:
    missing = [
        column for column in REQUIRED_POSITION_COLUMNS if column not in frame.columns
    ]
    if missing:
        raise KeyError(f"Missing required position columns: {missing}")


def _diagnostic(
    account: str,
    ticker: str,
    category: str,
    message: str,
) -> dict[str, str]:
    return {
        "AIM Code": account,
        "Ticker": ticker,
        "Category": category,
        "Message": message,
    }


def _attach_runbook(
    positions: pd.DataFrame,
    runbook: pd.DataFrame,
    diagnostics: list[dict[str, str]],
) -> pd.DataFrame:
    rules = runbook.copy()
    required = ("AIM Code", "Fund Name", "Capping", "Largest", "Level", "Type")
    missing = [column for column in required if column not in rules.columns]
    if missing:
        raise KeyError(f"Missing runbook columns: {missing}")
    if rules["AIM Code"].duplicated().any():
        duplicates = rules.loc[rules["AIM Code"].duplicated(False), "AIM Code"].tolist()
        raise ValueError(f"Duplicate AIM Codes in runbook: {duplicates}")
    if "Primary FM" not in rules.columns:
        rules["Primary FM"] = ""

    out = positions.merge(rules, on="AIM Code", how="left", validate="many_to_one")
    out["Primary FM"] = out["Primary FM"].fillna("")
    missing_rules = out["Fund Name"].isna()
    for _, row in (
        out.loc[missing_rules, ["AIM Code", "Ticker"]].drop_duplicates().iterrows()
    ):
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Missing Runbook",
                "No bundled capping rule was found for this AIM account.",
            )
        )
    return out


def _attach_company_mapping(
    positions: pd.DataFrame,
    exceptions: pd.DataFrame,
    diagnostics: list[dict[str, str]],
) -> pd.DataFrame:
    out = positions.copy()
    overrides = exceptions.copy()
    required = ("Ticker", "Parent Ticker", "Parent Name")
    missing = [column for column in required if column not in overrides.columns]
    if missing:
        raise KeyError(f"Missing exception columns: {missing}")
    overrides["_Ticker Key"] = overrides["Ticker"].map(
        lambda value: _clean_text(value).upper()
    )
    if overrides["_Ticker Key"].eq("").any():
        raise ValueError("Exception tickers cannot be blank")
    if overrides["_Ticker Key"].duplicated().any():
        duplicates = overrides.loc[
            overrides["_Ticker Key"].duplicated(False),
            "Ticker",
        ].tolist()
        raise ValueError(f"Duplicate exception tickers: {duplicates}")

    override_ticker = overrides.set_index("_Ticker Key")["Parent Ticker"].to_dict()
    override_name = overrides.set_index("_Ticker Key")["Parent Name"].to_dict()
    ticker_keys = out["Ticker"].map(lambda value: _clean_text(value).upper())
    fundamental_values = (
        out["Fundamental Ticker"].map(_ensure_equity_suffix)
        if "Fundamental Ticker" in out.columns
        else pd.Series("", index=out.index)
    )
    fundamental_names = (
        out["Fundamental Name"].map(_clean_text)
        if "Fundamental Name" in out.columns
        else pd.Series("", index=out.index)
    )

    out["Mapping Source"] = np.where(
        ticker_keys.isin(override_ticker),
        "Exception",
        np.where(
            fundamental_values.ne(""),
            "Fundamental Ticker",
            "Original Ticker",
        ),
    )
    out["Parent/Issuer Ticker"] = ticker_keys.map(override_ticker)
    out["Parent/Issuer Ticker"] = out["Parent/Issuer Ticker"].fillna(fundamental_values)
    out["Parent/Issuer Ticker"] = out["Parent/Issuer Ticker"].replace("", np.nan)
    out["Parent/Issuer Ticker"] = out["Parent/Issuer Ticker"].fillna(out["Ticker"])

    base_names = (
        out["Name"].map(_clean_text)
        if "Name" in out.columns
        else out["Ticker"].map(_clean_text)
    )
    out["Parent/Issuer Name"] = ticker_keys.map(override_name)
    out["Parent/Issuer Name"] = out["Parent/Issuer Name"].fillna(fundamental_names)
    out["Parent/Issuer Name"] = out["Parent/Issuer Name"].replace("", np.nan)
    out["Parent/Issuer Name"] = out["Parent/Issuer Name"].fillna(base_names)
    out["Parent/Issuer Name"] = out["Parent/Issuer Name"].replace("", np.nan)
    out["Parent/Issuer Name"] = out["Parent/Issuer Name"].fillna(
        out["Parent/Issuer Ticker"]
    )

    equity_fallback = (out["Asset"] == "Equity") & (
        out["Mapping Source"] == "Original Ticker"
    )
    for _, row in (
        out.loc[equity_fallback, ["AIM Code", "Ticker"]].drop_duplicates().iterrows()
    ):
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Fundamental Ticker Fallback",
                "The fundamental ticker was unavailable; the original ticker "
                "was used as the company key.",
            )
        )
    return out


def _calculate_position_values(
    positions: pd.DataFrame,
    diagnostics: list[dict[str, str]],
) -> pd.DataFrame:
    out = positions.copy()
    out["Quantity"] = pd.to_numeric(out["Quantity"], errors="coerce")
    out["Price USD"] = pd.to_numeric(out.get("Price USD"), errors="coerce")
    out["Price USD"] = out["Price USD"].replace([np.inf, -np.inf], np.nan)
    original_market_status = (
        out["Market Status"]
        if "Market Status" in out.columns
        else pd.Series("", index=out.index)
    )
    if "Pricing Market Status" in out.columns:
        pricing_market_status = out["Pricing Market Status"].fillna("")
        market_status = pricing_market_status.where(
            pricing_market_status.astype(str).str.strip().ne(""),
            original_market_status,
        )
        if "Price Mapping" in out.columns:
            thai_pricing = (
                out["Price Mapping"]
                .fillna("")
                .isin(
                    {
                        "Approved Override",
                        "Validated /F Strip",
                        "Validated -R Strip",
                        "HelpDesk DRSK",
                        "Unresolved",
                    }
                )
            )
            market_status = market_status.where(
                ~thai_pricing,
                pricing_market_status,
            )
    else:
        market_status = original_market_status
    expected_empty_status = market_status.map(_is_zero_price_market_status)
    no_bloomberg_price = expected_empty_status & out["Price USD"].isna()
    out.loc[no_bloomberg_price, "Price USD"] = 0.0
    for _, row in (
        out.loc[no_bloomberg_price, ["AIM Code", "Ticker"]].drop_duplicates().iterrows()
    ):
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Zero Price Market Status",
                "Bloomberg returned no last price; price and market "
                "value were set to zero.",
            )
        )

    price_mapping = out.get(
        "Price Mapping",
        pd.Series("", index=out.index),
    )
    unresolved_thai = price_mapping.fillna("").eq("Unresolved") & out[
        "Quantity"
    ].fillna(0).ne(0)
    out.loc[unresolved_thai, "Price USD"] = np.nan
    for _, row in (
        out.loc[
            unresolved_thai,
            ["AIM Code", "Ticker"],
        ]
        .drop_duplicates()
        .iterrows()
    ):
        note = ""
        if "Thai Mapping Note" in out.columns:
            notes = out.loc[
                unresolved_thai & out["Ticker"].eq(row["Ticker"]),
                "Thai Mapping Note",
            ].dropna()
            if not notes.empty:
                note = _clean_text(notes.iloc[0])
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Thai Pricing Unresolved",
                note or "No verified local Thai pricing ticker was available.",
            )
        )

    reference_data_issue = (
        out.get(
            "Reference Data Issue",
            pd.Series(False, index=out.index),
        )
        .fillna(False)
        .astype(bool)
    )
    out.loc[reference_data_issue, "Price USD"] = np.nan
    for _, row in (
        out.loc[
            reference_data_issue,
            ["AIM Code", "Ticker"],
        ]
        .drop_duplicates()
        .iterrows()
    ):
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Reference Data Missing",
                "Neither Name nor Market Status was available; price and "
                "capping status were left unresolved.",
            )
        )

    missing_quantity = out["Quantity"].isna()
    for _, row in (
        out.loc[missing_quantity, ["AIM Code", "Ticker"]].drop_duplicates().iterrows()
    ):
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Missing Quantity",
                "AIM position was not numeric; market value was set to zero.",
            )
        )

    needs_price = ~out["Asset"].isin(["Index Future", "FFX"]) & out["Quantity"].fillna(
        0
    ).ne(0)
    missing_price = needs_price & out["Price USD"].isna()
    for _, row in (
        out.loc[missing_price, ["AIM Code", "Ticker"]].drop_duplicates().iterrows()
    ):
        diagnostics.append(
            _diagnostic(
                row["AIM Code"],
                row["Ticker"],
                "Missing Price",
                "USD price was unavailable; market value was set to zero so "
                "other holdings can still be weighted.",
            )
        )

    out["Price USD"] = out["Price USD"].fillna(0.0)
    out["Market Value USD"] = out["Quantity"].fillna(0) * out["Price USD"]
    out.loc[out["Asset"].isin(["Index Future", "FFX"]), "Market Value USD"] = 0.0
    out["Row Data Issue"] = (
        missing_quantity
        | missing_price
        | reference_data_issue
        | out["Fund Name"].isna()
    )
    out["Has Data Issue"] = out.groupby("AIM Code")["Row Data Issue"].transform("max")
    for account in out.loc[out["Has Data Issue"], "AIM Code"].drop_duplicates():
        diagnostics.append(
            _diagnostic(
                account,
                "",
                "Account Incomplete",
                "At least one required position input is missing; Data Quality "
                "for this account is Data Issue. Over-limit names still show "
                "Breach or Near Limit on Monitor.",
            )
        )
    return out


def _safe_ratio(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    result = numerator / denominator.replace(0, np.nan)
    return result.replace([np.inf, -np.inf], np.nan)


def _calculate_security_weights(
    positions: pd.DataFrame,
    diagnostics: list[dict[str, str]],
) -> pd.DataFrame:
    """Calculate held-security weights before any company aggregation."""
    out = positions.copy()
    account_total = out.groupby("AIM Code")["Market Value USD"].transform("sum")
    out["Weight"] = _safe_ratio(out["Market Value USD"], account_total)

    zero_accounts = out.loc[account_total.eq(0), "AIM Code"].drop_duplicates()
    if not zero_accounts.empty:
        out.loc[account_total.eq(0), "Row Data Issue"] = True
        out["Has Data Issue"] = out.groupby("AIM Code")["Row Data Issue"].transform(
            "max"
        )
    for account in zero_accounts:
        diagnostics.append(
            _diagnostic(
                account,
                "",
                "Zero Denominator",
                "Total account market value is zero; weights cannot be calculated.",
            )
        )
        diagnostics.append(
            _diagnostic(
                account,
                "",
                "Account Incomplete",
                "The account has zero total market value; Data Quality is "
                "Data Issue.",
            )
        )
    return out


def _group_positions(
    positions: pd.DataFrame,
    position_mode: str,
    diagnostics: list[dict[str, str]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    out = positions.copy()
    account_total = out.groupby("AIM Code")["Market Value USD"].transform("sum")
    equity_total = (
        out["Market Value USD"]
        .where(out["Asset"].eq("Equity"), 0.0)
        .groupby(out["AIM Code"])
        .transform("sum")
    )

    group_keys = ["AIM Code", "Parent/Issuer Ticker"]
    group_mv = out.groupby(group_keys, dropna=False)["Market Value USD"].transform(
        "sum"
    )
    out["Agg Wgt (incl cash)"] = _safe_ratio(group_mv, account_total)
    out["Agg Wgt (ex cash)"] = _safe_ratio(group_mv, equity_total)

    aggregations = {
        "Fund Name": "first",
        "Parent/Issuer Name": "first",
        "Price Date": "max",
        "Capping": "first",
        "Largest": "first",
        "Level": "first",
        "Type": "first",
        "Primary FM": "first",
        "Market Value USD": "sum",
        "Agg Wgt (incl cash)": "first",
        "Agg Wgt (ex cash)": "first",
        "Has Data Issue": "max",
        "Mapping Source": lambda values: ", ".join(
            sorted(set(values.dropna().astype(str)))
        ),
        "Ticker": "nunique",
    }
    groups = out.groupby(group_keys, as_index=False, dropna=False).agg(aggregations)
    groups = groups.rename(columns={"Ticker": "Listing Count"})
    listing_tickers = (
        out.groupby(group_keys, as_index=False, dropna=False)["Ticker"]
        .agg(lambda values: ", ".join(dict.fromkeys(values.dropna().astype(str))))
        .rename(columns={"Ticker": "Listing Tickers"})
    )
    groups = groups.merge(
        listing_tickers,
        on=group_keys,
        how="left",
        validate="one_to_one",
    )

    is_equity = (
        out.assign(_is_equity=out["Asset"].eq("Equity"))
        .groupby(group_keys, as_index=False, dropna=False)["_is_equity"]
        .max()
        .rename(columns={"_is_equity": "Is Equity"})
    )
    groups = groups.merge(is_equity, on=group_keys, how="left", validate="one_to_one")
    # Legacy parity: the xlsx ranks every parent group, including cash and other
    # assets, before the output condition keeps Equity rows only.
    groups["Rank"] = (
        groups.groupby("AIM Code")["Agg Wgt (incl cash)"]
        .rank(method="min", ascending=False, na_option="bottom")
        .astype("Int64")
    )
    groups["Dynamic Limit"] = np.where(
        groups["Rank"].eq(1) & groups["Largest"].notna(),
        groups["Largest"],
        groups["Capping"],
    )
    groups["Observed Weight"] = groups[
        ["Agg Wgt (incl cash)", "Agg Wgt (ex cash)"]
    ].max(axis=1, skipna=True)
    groups["Headroom"] = groups["Dynamic Limit"] - groups["Observed Weight"]
    groups["Utilisation"] = _safe_ratio(
        groups["Observed Weight"], groups["Dynamic Limit"]
    )
    groups["Capping Status"] = np.select(
        [
            groups["Observed Weight"].ge(groups["Dynamic Limit"]),
            groups["Observed Weight"].ge(WARNING_RATIO * groups["Dynamic Limit"]),
        ],
        ["Breach", "Near Limit"],
        default="OK",
    )
    groups.loc[~groups["Is Equity"].fillna(False), "Capping Status"] = "OK"
    groups["Data Quality"] = np.where(groups["Has Data Issue"], "Data Issue", "OK")
    groups["Status"] = np.where(
        groups["Capping Status"].ne("OK"),
        groups["Capping Status"],
        groups["Data Quality"],
    )
    groups["AIM Position"] = position_mode

    rank_lookup = groups.set_index(group_keys)["Rank"]
    limit_lookup = groups.set_index(group_keys)["Dynamic Limit"]
    status_lookup = groups.set_index(group_keys)["Status"]
    position_index = pd.MultiIndex.from_frame(out[group_keys])
    out["Rank"] = rank_lookup.reindex(position_index).to_numpy()
    out["Dynamic Limit"] = limit_lookup.reindex(position_index).to_numpy()
    out["Status"] = status_lookup.reindex(position_index).to_numpy()
    out["AIM Position"] = position_mode

    sort_columns = ["Fund Name", "Agg Wgt (incl cash)", "Parent/Issuer Ticker"]
    groups = groups.sort_values(
        sort_columns,
        ascending=[True, False, True],
        na_position="last",
    ).reset_index(drop=True)
    return out, groups


def calculate_monitor(
    raw_positions: pd.DataFrame,
    position_mode: str,
    runbook: pd.DataFrame | None = None,
    exceptions: pd.DataFrame | None = None,
) -> MonitorResult:
    """Calculate capping results from normalized positions, matching ETF Capping Formula.xlsx.

    Required input columns are ``AIM Code``, ``Ticker``, and ``Quantity``.
    The data layer should also provide ``Price USD`` and may provide ``Name``,
    ``Price Date``, ``Market Status``, ``Fundamental Ticker``, and
    ``Fundamental Name``.
    """
    if position_mode not in {"Current", "Projected"}:
        raise ValueError("position_mode must be 'Current' or 'Projected'")
    _validate_positions(raw_positions)

    diagnostics: list[dict[str, str]] = []
    positions = raw_positions.copy()
    positions["AIM Code"] = positions["AIM Code"].map(_clean_text)
    positions["Ticker"] = positions["Ticker"].map(_clean_text)
    positions = positions.loc[
        positions["AIM Code"].ne("") & positions["Ticker"].ne("")
    ].copy()
    positions["Asset"] = positions["Ticker"].map(classify_asset)
    if "Price Date" not in positions.columns:
        positions["Price Date"] = pd.NaT
    positions["Price Date"] = pd.to_datetime(positions["Price Date"], errors="coerce")

    positions = _attach_runbook(
        positions,
        account_rules_frame() if runbook is None else runbook,
        diagnostics,
    )
    # Position MV and security weight are calculated from the held
    # security's own ticker, quantity, and approved Pricing Ticker. Company
    # mapping is attached only afterward and is used only by final aggregation.
    positions = _calculate_position_values(positions, diagnostics)
    positions = _calculate_security_weights(positions, diagnostics)
    positions = _attach_company_mapping(
        positions,
        exception_rules_frame() if exceptions is None else exceptions,
        diagnostics,
    )
    positions, groups = _group_positions(positions, position_mode, diagnostics)
    alerts = groups.loc[
        groups["Is Equity"].fillna(False)
        & groups["Capping Status"].isin(["Breach", "Near Limit"])
    ].copy()
    diagnostics_frame = pd.DataFrame(
        diagnostics,
        columns=["AIM Code", "Ticker", "Category", "Message"],
    ).drop_duplicates()
    return MonitorResult(
        positions=positions,
        groups=groups,
        alerts=alerts,
        diagnostics=diagnostics_frame.reset_index(drop=True),
    )


def monitor_weight_tone(weight, capping, rank, status) -> str:
    """B/N/O colour code for a Monitor weight cell versus Capping.

    Rank 1 rows whose Status is OK stay ``O`` so a largest-name holding
    between Capping and Largest is visible without a colour flag. Data Issue
    and Breach/Near Limit rows still colour from the cell's own weight.
    """
    if weight is None or capping is None or pd.isna(weight) or pd.isna(capping):
        return "O"
    rank_one = pd.notna(rank) and int(rank) == 1
    status_text = "" if status is None or pd.isna(status) else str(status)
    if rank_one and status_text == "OK":
        return "O"
    value = float(weight)
    cap = float(capping)
    if cap <= 0:
        return "O"
    if value >= cap:
        return "B"
    if value >= WARNING_RATIO * cap:
        return "N"
    return "O"


def select_monitor_groups(groups: pd.DataFrame, status: str) -> pd.DataFrame:
    """Rows for the Monitor table.

    Alerts/Breach/Near Limit keep high holdings only, plus the Rank 1 equity
    row of those same AIM accounts so the largest name can be compared with a
    flagged later rank. Rank 1 context is not itself an alert.

    Incomplete accounts still list names whose observed weight is Breach or
    Near Limit; Monitor Status stays Breach or Near Limit so the action is
    visible. Other within-limit names of those accounts stay on the Data
    Issue filter and Diagnostics, not Alerts.
    """
    if groups is None or groups.empty:
        return pd.DataFrame()
    equity = groups.loc[groups["Is Equity"].fillna(False)].copy()
    if equity.empty:
        return equity
    rank_one = equity["Rank"].eq(1)

    def with_rank_one(flagged: pd.DataFrame) -> pd.DataFrame:
        if flagged.empty:
            return flagged.reset_index(drop=True)
        context = equity.loc[
            rank_one & equity["AIM Code"].isin(flagged["AIM Code"].unique())
        ]
        return (
            pd.concat([flagged, context], ignore_index=True)
            .drop_duplicates(["AIM Code", "Parent/Issuer Ticker"], keep="first")
            .reset_index(drop=True)
        )

    over_limit = equity["Capping Status"].isin(["Breach", "Near Limit"])
    if status == "Alerts":
        return with_rank_one(equity.loc[over_limit])
    if status == "Breach":
        return with_rank_one(equity.loc[equity["Capping Status"].eq("Breach")])
    if status == "Near Limit":
        return with_rank_one(equity.loc[equity["Capping Status"].eq("Near Limit")])
    if status == "Data Issue":
        return equity.loc[equity["Data Quality"].eq("Data Issue")].reset_index(
            drop=True
        )
    return equity.reset_index(drop=True)
