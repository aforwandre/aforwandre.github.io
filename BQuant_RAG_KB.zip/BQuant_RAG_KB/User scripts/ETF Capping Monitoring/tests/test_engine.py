"""Local tests for the pure-Pandas capping engine. No BQL is executed."""

from __future__ import annotations

import re
import sys
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from etf_capping.config import ACCOUNT_RULES, PRIMARY_FM_BY_AIM, account_rules_frame, thai_pricing_overrides
from etf_capping.data import (
    _apply_helpdesk_drsk,
    _cash_currency_code,
    _clean_mapping_value,
    _is_response,
    _is_local_thai_equity,
    _is_thai_foreign_line,
    _item_frame,
    _price_date,
    _resolve_pricing_ticker,
    _select_thai_pricing_tickers,
    _strip_thai_foreign_board,
    _thai_candidate_tickers,
)
from etf_capping.engine import (
    calculate_monitor,
    classify_asset,
    monitor_weight_tone,
    select_monitor_groups,
    _is_zero_price_market_status,
)


def _import_etf_app():
    """Load app.py without BQuant Desktop widgets."""
    import sys
    import types

    def ensure(name: str):
        if name not in sys.modules:
            sys.modules[name] = types.ModuleType(name)
        return sys.modules[name]

    plotly = ensure("plotly")
    go = ensure("plotly.graph_objects")
    plotly.graph_objects = go
    ensure("ipywidgets")
    ipython = ensure("IPython")
    display = ensure("IPython.display")
    display.clear_output = lambda *args, **kwargs: None
    ipython.display = display
    ipd = ensure("ipydatagrid")

    class TextRenderer:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class VegaExpr:
        def __init__(self, source):
            self.source = source

    ipd.DataGrid = getattr(ipd, "DataGrid", type("DataGrid", (), {}))
    ipd.TextRenderer = getattr(ipd, "TextRenderer", TextRenderer)
    ipd.VegaExpr = getattr(ipd, "VegaExpr", VegaExpr)
    ipd.Expr = getattr(ipd, "Expr", VegaExpr)
    from etf_capping import app as etf_app

    return etf_app


def _runbook(
    code: str = "TEST",
    capping: float = 0.10,
    largest: float = 0.20,
) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "AIM Code": code,
                "Fund Name": "Test Fund",
                "Capping": capping,
                "Largest": largest,
                "Level": "Stock",
                "Type": "Real Time",
            }
        ]
    )


def _empty_exceptions() -> pd.DataFrame:
    return pd.DataFrame(columns=["Ticker", "Name", "Parent Ticker", "Parent Name"])


class CappingEngineTests(unittest.TestCase):
    def test_asset_classification_matches_legacy_rules(self):
        self.assertEqual(classify_asset("NVDA US Equity"), "Equity")
        self.assertEqual(classify_asset("USD Curncy"), "Cash")
        self.assertEqual(classify_asset("USDJPY Curncy"), "FFX")
        self.assertEqual(classify_asset("ESA Index"), "Index Future")
        self.assertEqual(classify_asset("ABC Corp"), "Others")

    def test_primary_fm_is_copied_from_excel_runbook(self):
        frame = account_rules_frame()
        self.assertEqual(set(PRIMARY_FM_BY_AIM), {rule.aim_code for rule in ACCOUNT_RULES})
        self.assertFalse(frame["Primary FM"].eq("").any())
        self.assertEqual(
            frame.loc[frame["AIM Code"].eq("ACCT20"), "Primary FM"].iloc[0],
            "Sample FM 3",
        )
        self.assertEqual(
            frame.loc[frame["AIM Code"].eq("ACCT54"), "Primary FM"].iloc[0],
            "Sample FM 4",
        )
        self.assertEqual(
            frame.loc[frame["AIM Code"].eq("ACCT51"), "Primary FM"].iloc[0],
            "Sample FM 2",
        )

    def test_primary_fm_passes_through_positions_and_groups(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "AAA US Equity",
                    "Quantity": 10,
                    "Price USD": 5,
                    "Fundamental Ticker": "AAA US",
                }
            ]
        )
        runbook = _runbook(largest=1.0)
        runbook["Primary FM"] = "Sample FM 1"
        result = calculate_monitor(
            positions,
            "Current",
            runbook=runbook,
            exceptions=_empty_exceptions(),
        )
        self.assertEqual(result.positions.iloc[0]["Primary FM"], "Sample FM 1")
        self.assertEqual(result.groups.iloc[0]["Primary FM"], "Sample FM 1")

    def test_monitor_grid_puts_primary_fm_last(self):
        app_mod = _import_etf_app()
        app = object.__new__(app_mod.ETFCappingMonitor)
        groups = pd.DataFrame(
            {
                "AIM Code": ["TEST"],
                "Fund Name": ["Fund"],
                "Parent/Issuer Name": ["Nvidia"],
                "Parent/Issuer Ticker": ["NVDA US Equity"],
                "Price Date": [pd.NaT],
                "Agg Wgt (incl cash)": [0.0707],
                "Agg Wgt (ex cash)": [0.0642],
                "Capping": [0.05],
                "Largest": [0.10],
                "Rank": [1],
                "Dynamic Limit": [0.10],
                "Headroom": [0.0293],
                "Status": ["Breach"],
                "Level": ["Stock"],
                "Type": ["Last Close"],
                "Primary FM": ["Sample FM 1"],
            }
        )
        grid = app._monitor_grid_frame(groups)
        self.assertEqual(grid.columns[-1], "Primary FM")
        self.assertEqual(grid["Primary FM"].iloc[0], "Sample FM 1")

    def test_zero_price_market_status_covers_official_no_price_codes(self):
        for status in (
            "DLST",
            "Delisted",
            "UNLS",
            "Unlisted",
            "PRNA",
            "Price Not Available",
            "PRIV",
            "Private Company",
            "INAC",
            "Inactive",
            "SUSP",
            "Suspended",
            "EXPD",
            "Expired",
            "PEND",
            "Pending Listing",
            "LIQU",
            "Liquidated",
            "RCNA",
            "Reason not available",
        ):
            self.assertTrue(_is_zero_price_market_status(status), status)
        self.assertFalse(_is_zero_price_market_status("ACTV"))
        self.assertFalse(_is_zero_price_market_status("Active"))
        self.assertFalse(_is_zero_price_market_status("ACQU"))

    def test_cash_currency_code_rejects_null_and_nan_yellow_keys(self):
        self.assertEqual(_cash_currency_code("USD Curncy"), "USD")
        self.assertEqual(_cash_currency_code("EUR Curncy"), "EUR")
        self.assertEqual(_cash_currency_code(None), "")
        self.assertEqual(_cash_currency_code(float("nan")), "")
        self.assertEqual(_cash_currency_code("NAN Curncy"), "")
        self.assertEqual(_cash_currency_code("USDJPY Curncy"), "")

    def test_fundamental_mapping_combines_listings_and_uses_ex_cash_weight(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "AAA US Equity",
                    "Name": "AAA US",
                    "Quantity": 400,
                    "Price USD": 1,
                    "Fundamental Ticker": "AAA US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "AAA LN Equity",
                    "Name": "AAA London",
                    "Quantity": 200,
                    "Price USD": 1,
                    "Fundamental Ticker": "AAA US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "BBB US Equity",
                    "Name": "BBB",
                    "Quantity": 300,
                    "Price USD": 1,
                    "Fundamental Ticker": "BBB US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Name": "US Dollar",
                    "Quantity": 100,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Projected",
            runbook=_runbook(),
            exceptions=_empty_exceptions(),
        )
        aaa = result.groups.loc[
            result.groups["Parent/Issuer Ticker"].eq("AAA US Equity")
        ].iloc[0]

        self.assertEqual(aaa["Listing Count"], 2)
        self.assertAlmostEqual(aaa["Agg Wgt (incl cash)"], 0.60)
        self.assertAlmostEqual(aaa["Agg Wgt (ex cash)"], 2 / 3)
        self.assertEqual(aaa["Rank"], 1)
        self.assertAlmostEqual(aaa["Dynamic Limit"], 0.20)
        self.assertEqual(aaa["Capping Status"], "Breach")
        self.assertEqual(aaa["Mapping Source"], "Fundamental Ticker")

    def test_company_aggregation_preserves_each_position_price_and_weight(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "PARENT US Equity",
                    "Quantity": 10,
                    "Price USD": 100,
                    "Fundamental Ticker": "PARENT US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "SUB US Equity",
                    "Quantity": 20,
                    "Price USD": 5,
                    "Fundamental Ticker": "PARENT US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 100,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )
        priced = result.positions.set_index("Ticker")
        company = result.groups.loc[
            result.groups["Parent/Issuer Ticker"].eq("PARENT US Equity")
        ].iloc[0]

        self.assertEqual(priced.loc["PARENT US Equity", "Quantity"], 10)
        self.assertEqual(priced.loc["PARENT US Equity", "Price USD"], 100)
        self.assertEqual(priced.loc["PARENT US Equity", "Market Value USD"], 1000)
        self.assertAlmostEqual(priced.loc["PARENT US Equity", "Weight"], 1000 / 1200)
        self.assertEqual(priced.loc["SUB US Equity", "Quantity"], 20)
        self.assertEqual(priced.loc["SUB US Equity", "Price USD"], 5)
        self.assertEqual(priced.loc["SUB US Equity", "Market Value USD"], 100)
        self.assertAlmostEqual(priced.loc["SUB US Equity", "Weight"], 100 / 1200)
        self.assertEqual(company["Market Value USD"], 1100)
        self.assertAlmostEqual(company["Agg Wgt (incl cash)"], 1100 / 1200)
        self.assertEqual(
            company["Listing Tickers"],
            "PARENT US Equity, SUB US Equity",
        )

    def test_rank_one_uses_largest_and_second_rank_uses_capping(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "AAA US Equity",
                    "Quantity": 600,
                    "Price USD": 1,
                    "Fundamental Ticker": "AAA US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "BBB US Equity",
                    "Quantity": 350,
                    "Price USD": 1,
                    "Fundamental Ticker": "BBB US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 50,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(),
            exceptions=_empty_exceptions(),
        )
        equity = result.groups.loc[result.groups["Is Equity"]].set_index(
            "Parent/Issuer Ticker"
        )

        self.assertEqual(equity.loc["AAA US Equity", "Rank"], 1)
        self.assertAlmostEqual(equity.loc["AAA US Equity", "Dynamic Limit"], 0.20)
        self.assertEqual(equity.loc["BBB US Equity", "Rank"], 2)
        self.assertAlmostEqual(equity.loc["BBB US Equity", "Dynamic Limit"], 0.10)

    def test_warning_threshold_is_inclusive(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "BIG US Equity",
                    "Quantity": 902,
                    "Price USD": 1,
                    "Fundamental Ticker": "BIG US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "NEAR US Equity",
                    "Quantity": 98,
                    "Price USD": 1,
                    "Fundamental Ticker": "NEAR US",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )
        near = result.groups.loc[
            result.groups["Parent/Issuer Ticker"].eq("NEAR US Equity")
        ].iloc[0]

        self.assertEqual(near["Rank"], 2)
        self.assertAlmostEqual(near["Observed Weight"], 0.098)
        self.assertEqual(near["Capping Status"], "Near Limit")
        self.assertEqual(len(result.alerts), 1)

    def test_monitor_alerts_include_rank_one_context_and_skip_data_issues(self):
        groups = pd.DataFrame(
            {
                "AIM Code": ["TEST", "TEST", "TEST", "ISSUE", "ISSUE"],
                "Fund Name": ["A"] * 3 + ["B"] * 2,
                "Parent/Issuer Ticker": [
                    "BIG US Equity",
                    "HOT US Equity",
                    "SMALL US Equity",
                    "ISSUE1 US Equity",
                    "ISSUE2 US Equity",
                ],
                "Is Equity": True,
                "Rank": [1, 2, 3, 1, 2],
                "Data Quality": ["OK", "OK", "OK", "Data Issue", "Data Issue"],
                "Capping Status": ["OK", "Breach", "OK", "OK", "OK"],
                "Status": ["OK", "Breach", "OK", "Data Issue", "Data Issue"],
                "Agg Wgt (incl cash)": [0.15, 0.105, 0.05, 0.04, 0.03],
            }
        )
        alerts = select_monitor_groups(groups, "Alerts")
        tickers = set(alerts["Parent/Issuer Ticker"])

        self.assertEqual(tickers, {"BIG US Equity", "HOT US Equity"})
        self.assertTrue(
            select_monitor_groups(groups, "Data Issue")["AIM Code"].eq("ISSUE").all()
        )

    def test_monitor_alerts_keep_incomplete_over_limit_names(self):
        groups = pd.DataFrame(
            {
                "AIM Code": ["CLIM", "CLIM", "CLIM"],
                "Fund Name": ["Climate"] * 3,
                "Parent/Issuer Ticker": [
                    "NVDA US Equity",
                    "AAPL US Equity",
                    "TINY US Equity",
                ],
                "Is Equity": True,
                "Rank": [1, 2, 3],
                "Data Quality": ["Data Issue"] * 3,
                "Capping Status": ["Breach", "Breach", "OK"],
                "Status": ["Breach", "Breach", "Data Issue"],
                "Agg Wgt (incl cash)": [0.0707, 0.0642, 0.01],
            }
        )
        alerts = select_monitor_groups(groups, "Alerts")
        tickers = set(alerts["Parent/Issuer Ticker"])

        self.assertEqual(tickers, {"NVDA US Equity", "AAPL US Equity"})
        self.assertEqual(set(alerts["Status"]), {"Breach"})
        self.assertEqual(
            set(select_monitor_groups(groups, "Data Issue")["Parent/Issuer Ticker"]),
            {"NVDA US Equity", "AAPL US Equity", "TINY US Equity"},
        )

    def test_rank_one_between_largest_and_capping_is_not_colour_flagged(self):
        self.assertEqual(
            monitor_weight_tone(0.15, 0.10, 1, "OK"),
            "O",
        )
        self.assertEqual(
            monitor_weight_tone(0.105, 0.10, 2, "Breach"),
            "B",
        )
        self.assertEqual(
            monitor_weight_tone(0.098, 0.10, 2, "Near Limit"),
            "N",
        )
        self.assertEqual(
            monitor_weight_tone(0.21, 0.10, 1, "Breach"),
            "B",
        )
        self.assertEqual(
            monitor_weight_tone(0.098, 0.10, 2, "Breach"),
            "N",
        )
        self.assertEqual(
            monitor_weight_tone(0.105, 0.10, 2, "Breach"),
            "B",
        )
        self.assertEqual(
            monitor_weight_tone(0.07, 0.05, 1, "Data Issue"),
            "B",
        )

    def test_monitor_weight_tones_differ_for_incl_and_ex_cash(self):
        app = _import_etf_app()
        groups = pd.DataFrame(
            {
                "Rank": [2],
                "Capping": [0.10],
                "Status": ["Breach"],
                "Agg Wgt (incl cash)": [0.098],
                "Agg Wgt (ex cash)": [0.105],
            }
        )
        incl = app._monitor_weight_tones(groups, "Agg Wgt (incl cash)")
        ex = app._monitor_weight_tones(groups, "Agg Wgt (ex cash)")
        self.assertEqual(incl, ["N"])
        self.assertEqual(ex, ["B"])
        incl_color = app._vega_row_color_source(incl, app.MONITOR_WEIGHT_BG, "#151a25")
        ex_color = app._vega_row_color_source(ex, app.MONITOR_WEIGHT_BG, "#151a25")
        self.assertEqual(incl_color, "'#4b3a20'")
        self.assertEqual(ex_color, "'#4a2027'")
        incl_renderer = app._weight_cell_renderer(incl)
        kwargs = getattr(incl_renderer, "kwargs", None)
        if kwargs is not None:
            self.assertNotIn("text_value", kwargs)
            self.assertFalse(hasattr(kwargs.get("text_color"), "source"))

    def test_monitor_display_frame_uses_percent_strings(self):
        app_mod = _import_etf_app()
        app = object.__new__(app_mod.ETFCappingMonitor)
        groups = pd.DataFrame(
            {
                "AIM Code": ["TEST"],
                "Fund Name": ["Fund"],
                "Parent/Issuer Name": ["Nvidia"],
                "Parent/Issuer Ticker": ["NVDA US Equity"],
                "Price Date": [pd.NaT],
                "Agg Wgt (incl cash)": [0.0707],
                "Agg Wgt (ex cash)": [0.0642],
                "Capping": [0.05],
                "Largest": [0.10],
                "Rank": [1],
                "Dynamic Limit": [0.10],
                "Headroom": [0.0293],
                "Status": ["Breach"],
                "Level": ["Stock"],
                "Type": ["Last Close"],
            }
        )
        grid = app._monitor_grid_frame(groups)
        display = app._monitor_display_frame(groups)
        self.assertTrue(pd.api.types.is_numeric_dtype(grid["Incl Cash"]))
        self.assertTrue(pd.api.types.is_numeric_dtype(grid["Ex Cash"]))
        self.assertEqual(display["Incl Cash"].iloc[0], "7.07%")
        self.assertEqual(display["Ex Cash"].iloc[0], "6.42%")
        self.assertEqual(display["Status"].iloc[0], "Breach")

    def test_exception_override_has_priority_over_fundamental_ticker(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "SKM US Equity",
                    "Name": "SK Telecom ADR",
                    "Quantity": 30,
                    "Price USD": 1,
                    "Fundamental Ticker": "DIFFERENT US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "017670 KS Equity",
                    "Name": "SK Telecom",
                    "Quantity": 20,
                    "Price USD": 1,
                    "Fundamental Ticker": "ANOTHER KS",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 950,
                    "Price USD": 1,
                },
            ]
        )
        exceptions = pd.DataFrame(
            [
                {
                    "Ticker": "SKM US Equity",
                    "Name": "SK Telecom ADR",
                    "Parent Ticker": "034730 KS Equity",
                    "Parent Name": "SK Inc",
                },
                {
                    "Ticker": "017670 KS Equity",
                    "Name": "SK Telecom",
                    "Parent Ticker": "034730 KS Equity",
                    "Parent Name": "SK Inc",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Projected",
            runbook=_runbook(),
            exceptions=exceptions,
        )
        sk = result.groups.loc[
            result.groups["Parent/Issuer Ticker"].eq("034730 KS Equity")
        ].iloc[0]

        self.assertEqual(sk["Listing Count"], 2)
        self.assertEqual(sk["Parent/Issuer Name"], "SK Inc")
        self.assertEqual(sk["Mapping Source"], "Exception")
        held = result.positions.set_index("Ticker")
        self.assertEqual(held.loc["SKM US Equity", "Quantity"], 30)
        self.assertEqual(held.loc["SKM US Equity", "Price USD"], 1)

    def test_exception_matching_is_case_insensitive_without_changing_ticker(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "SKM US Equity",
                    "Quantity": 2,
                    "Price USD": 7,
                    "Fundamental Ticker": "OTHER US",
                }
            ]
        )
        exceptions = pd.DataFrame(
            [
                {
                    "Ticker": "skm us equity",
                    "Name": "SK Telecom ADR",
                    "Parent Ticker": "034730 KS Equity",
                    "Parent Name": "SK Inc",
                }
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=exceptions,
        )

        self.assertEqual(result.positions.iloc[0]["Ticker"], "SKM US Equity")
        self.assertEqual(result.positions.iloc[0]["Quantity"], 2)
        self.assertEqual(result.positions.iloc[0]["Price USD"], 7)
        self.assertEqual(
            result.groups.iloc[0]["Parent/Issuer Ticker"],
            "034730 KS Equity",
        )

    def test_missing_fundamental_ticker_falls_back_and_is_logged(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "SOLO US Equity",
                    "Quantity": 100,
                    "Price USD": 1,
                    "Fundamental Ticker": "#N/A Field Not Applicable",
                }
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertEqual(
            result.groups.iloc[0]["Parent/Issuer Ticker"],
            "SOLO US Equity",
        )
        self.assertIn(
            "Fundamental Ticker Fallback",
            set(result.diagnostics["Category"]),
        )

    def test_missing_price_marks_entire_account_incomplete(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "PRICED US Equity",
                    "Quantity": 100,
                    "Price USD": 1,
                    "Fundamental Ticker": "PRICED US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "MISSING US Equity",
                    "Quantity": 100,
                    "Price USD": None,
                    "Fundamental Ticker": "MISSING US",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(),
            exceptions=_empty_exceptions(),
        )

        self.assertEqual(set(result.groups["Data Quality"]), {"Data Issue"})
        self.assertEqual(set(result.groups["Status"]), {"Breach", "Data Issue"})
        self.assertEqual(len(result.alerts), 1)
        self.assertEqual(
            result.alerts.iloc[0]["Parent/Issuer Ticker"],
            "PRICED US Equity",
        )
        self.assertEqual(result.alerts.iloc[0]["Capping Status"], "Breach")
        self.assertEqual(result.alerts.iloc[0]["Status"], "Breach")
        self.assertEqual(
            result.groups.loc[
                result.groups["Parent/Issuer Ticker"].eq("MISSING US Equity"),
                "Status",
            ].iloc[0],
            "Data Issue",
        )
        self.assertIn("Account Incomplete", set(result.diagnostics["Category"]))

    def test_special_status_carries_last_price_or_zeros_if_missing(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "DLST US Equity",
                    "Quantity": 100,
                    "Price USD": 9,
                    "Market Status": "DLST",
                    "Fundamental Ticker": "DLST US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "UNLS US Equity",
                    "Quantity": 100,
                    "Price USD": None,
                    "Market Status": "Unlisted",
                    "Fundamental Ticker": "UNLS US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "ACQU US Equity",
                    "Quantity": 100,
                    "Price USD": 3,
                    "Market Status": "ACQU",
                    "Fundamental Ticker": "ACQU US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "LONGDLST US Equity",
                    "Quantity": 100,
                    "Price USD": 8,
                    "Market Status": " delisted ",
                    "Fundamental Ticker": "LONGDLST US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "UNLSCODE US Equity",
                    "Quantity": 100,
                    "Price USD": None,
                    "Market Status": "UNLS",
                    "Fundamental Ticker": "UNLSCODE US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "ACTV US Equity",
                    "Quantity": 100,
                    "Price USD": 4,
                    "Market Status": "ACTV",
                    "Fundamental Ticker": "ACTV US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "PRNA US Equity",
                    "Quantity": 100,
                    "Price USD": None,
                    "Market Status": "PRNA",
                    "Fundamental Ticker": "PRNA US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "SUSP US Equity",
                    "Quantity": 100,
                    "Price USD": 7,
                    "Market Status": "Suspended",
                    "Fundamental Ticker": "SUSP US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "RCNA US Equity",
                    "Quantity": 100,
                    "Price USD": None,
                    "Market Status": "Reason not available",
                    "Fundamental Ticker": "RCNA US",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(),
            exceptions=_empty_exceptions(),
        )
        priced = result.positions.set_index("Ticker")

        self.assertEqual(priced.loc["DLST US Equity", "Price USD"], 9)
        self.assertEqual(priced.loc["UNLS US Equity", "Price USD"], 0)
        self.assertEqual(priced.loc["ACQU US Equity", "Price USD"], 3)
        self.assertEqual(priced.loc["LONGDLST US Equity", "Price USD"], 8)
        self.assertEqual(priced.loc["UNLSCODE US Equity", "Price USD"], 0)
        self.assertEqual(priced.loc["ACTV US Equity", "Price USD"], 4)
        self.assertEqual(priced.loc["PRNA US Equity", "Price USD"], 0)
        self.assertEqual(priced.loc["SUSP US Equity", "Price USD"], 7)
        self.assertEqual(priced.loc["RCNA US Equity", "Price USD"], 0)
        self.assertEqual(set(result.groups["Data Quality"]), {"OK"})
        self.assertNotIn(
            "Missing Price",
            set(result.diagnostics["Category"]),
        )
        zeroed = result.diagnostics.loc[
            result.diagnostics["Category"].eq("Zero Price Market Status"),
            "Ticker",
        ]
        self.assertEqual(
            set(zeroed),
            {
                "UNLS US Equity",
                "UNLSCODE US Equity",
                "PRNA US Equity",
                "RCNA US Equity",
            },
        )

    def test_last_close_is_as_of_previous_weekday(self):
        self.assertEqual(_price_date("Last Close", date(2026, 9, 2)), date(2026, 9, 1))
        self.assertEqual(_price_date("Last Close", date(2026, 9, 7)), date(2026, 9, 4))
        self.assertEqual(_price_date("Real Time", date(2026, 9, 2)), date(2026, 9, 2))

    def test_failed_last_price_falls_back_to_zero_without_breaking_sibling_weights(
        self,
    ):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "GOOD US Equity",
                    "Quantity": 10,
                    "Price USD": 10,
                    "Market Status": "ACTV",
                    "Fundamental Ticker": "GOOD US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "BAD US Equity",
                    "Quantity": 10,
                    "Price USD": "N/A",
                    "Market Status": "ACTV",
                    "Fundamental Ticker": "BAD US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 20,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )
        priced = result.positions.set_index("Ticker")
        self.assertEqual(priced.loc["BAD US Equity", "Price USD"], 0)
        self.assertEqual(priced.loc["BAD US Equity", "Market Value USD"], 0)
        self.assertEqual(priced.loc["GOOD US Equity", "Market Value USD"], 100)
        self.assertAlmostEqual(priced.loc["GOOD US Equity", "Weight"], 100 / 120)
        self.assertAlmostEqual(priced.loc["USD Curncy", "Weight"], 20 / 120)
        self.assertFalse(pd.isna(priced.loc["GOOD US Equity", "Weight"]))
        self.assertIn("Missing Price", set(result.diagnostics["Category"]))

    def test_thai_price_uses_local_market_status(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "ABC/F TB Equity",
                    "Quantity": 100,
                    "Price USD": 5,
                    "Market Status": "UNLS",
                    "Pricing Market Status": "ACTV",
                    "Price Mapping": "Validated /F Strip",
                    "Fundamental Ticker": "ABC TB",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertEqual(result.positions.iloc[0]["Price USD"], 5)
        self.assertEqual(result.positions.iloc[0]["Ticker"], "ABC/F TB Equity")
        self.assertEqual(result.positions.iloc[0]["Quantity"], 100)
        self.assertEqual(result.groups.iloc[0]["Data Quality"], "OK")

    def test_nvdr_helpdesk_mapping_uses_local_market_status(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "PTT-R TB Equity",
                    "Quantity": 100,
                    "Price USD": 7,
                    "Market Status": "UNLS",
                    "Pricing Market Status": "ACTV",
                    "Price Mapping": "HelpDesk DRSK",
                    "Fundamental Ticker": "PTT TB",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertEqual(result.positions.iloc[0]["Price USD"], 7)
        self.assertEqual(result.positions.iloc[0]["Ticker"], "PTT-R TB Equity")
        self.assertEqual(result.groups.iloc[0]["Data Quality"], "OK")

    def test_local_delisted_keeps_bloomberg_last_price(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "ABC/F TB Equity",
                    "Quantity": 100,
                    "Price USD": 5,
                    "Market Status": "ACTV",
                    "Pricing Market Status": "DLST",
                    "Price Mapping": "Validated /F Strip",
                    "Fundamental Ticker": "ABC TB",
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertEqual(result.positions.iloc[0]["Price USD"], 5)
        self.assertNotIn(
            "Missing Price",
            set(result.diagnostics["Category"]),
        )
        self.assertNotIn(
            "Zero Price Market Status",
            set(result.diagnostics["Category"]),
        )

    def test_unresolved_thai_mapping_is_a_data_issue(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "UNKNOWN/F TB Equity",
                    "Quantity": 100,
                    "Price USD": None,
                    "Market Status": "UNLS",
                    "Pricing Market Status": "",
                    "Price Mapping": "Unresolved",
                    "Thai Mapping Note": "Approved local ticker is required.",
                    "Fundamental Ticker": "UNKNOWN TB",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 100,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertIn(
            "Thai Pricing Unresolved",
            set(result.diagnostics["Category"]),
        )
        self.assertEqual(set(result.groups["Data Quality"]), {"Data Issue"})

    def test_unresolved_thai_mapping_never_uses_prefilled_foreign_price(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "UNKNOWN/F TB Equity",
                    "Quantity": 100,
                    "Price USD": 99,
                    "Price Mapping": "Unresolved",
                    "Thai Mapping Note": "Approved local ticker is required.",
                    "Fundamental Ticker": "UNKNOWN TB",
                }
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertEqual(result.positions.iloc[0]["Price USD"], 0)
        self.assertEqual(result.positions.iloc[0]["Market Value USD"], 0)
        self.assertEqual(result.groups.iloc[0]["Data Quality"], "Data Issue")

    def test_zero_account_market_value_is_a_data_issue(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "ZERO US Equity",
                    "Quantity": 100,
                    "Price USD": 0,
                    "Fundamental Ticker": "ZERO US",
                }
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )

        self.assertTrue(pd.isna(result.positions.iloc[0]["Weight"]))
        self.assertEqual(result.groups.iloc[0]["Status"], "Data Issue")
        self.assertIn("Zero Denominator", set(result.diagnostics["Category"]))

    def test_missing_reference_data_fails_closed(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "UNKNOWN US Equity",
                    "Quantity": 100,
                    "Price USD": 12,
                    "Reference Data Issue": True,
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 100,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(largest=1.0),
            exceptions=_empty_exceptions(),
        )
        equity = result.positions.loc[
            result.positions["Ticker"].eq("UNKNOWN US Equity")
        ].iloc[0]

        self.assertEqual(equity["Price USD"], 0)
        self.assertEqual(equity["Market Value USD"], 0)
        self.assertEqual(set(result.groups["Data Quality"]), {"Data Issue"})
        self.assertIn(
            "Reference Data Missing",
            set(result.diagnostics["Category"]),
        )

    def test_rank_preserves_legacy_all_asset_group_order(self):
        positions = pd.DataFrame(
            [
                {
                    "AIM Code": "TEST",
                    "Ticker": "AAA US Equity",
                    "Quantity": 400,
                    "Price USD": 1,
                    "Fundamental Ticker": "AAA US",
                },
                {
                    "AIM Code": "TEST",
                    "Ticker": "USD Curncy",
                    "Quantity": 600,
                    "Price USD": 1,
                },
            ]
        )
        result = calculate_monitor(
            positions,
            "Current",
            runbook=_runbook(),
            exceptions=_empty_exceptions(),
        )
        equity = result.groups.loc[result.groups["Is Equity"]].iloc[0]

        self.assertEqual(equity["Rank"], 2)
        self.assertAlmostEqual(equity["Dynamic Limit"], 0.10)


class PricingTickerTests(unittest.TestCase):
    def test_thai_foreign_line_uses_local_pricing_ticker(self):
        self.assertEqual(
            _resolve_pricing_ticker(
                "ABC/F TB Equity",
                "ABC TB Equity",
            ),
            "ABC TB Equity",
        )

    def test_thai_foreign_line_without_mapping_fails_closed(self):
        self.assertEqual(
            _resolve_pricing_ticker(
                "ABC/F TB Equity",
                "Field Not Applicable",
            ),
            "",
        )

    def test_thai_foreign_line_rejects_non_local_or_foreign_price_ticker(self):
        self.assertEqual(
            _resolve_pricing_ticker(
                "ABC/F TB Equity",
                "ABC US Equity",
            ),
            "",
        )
        self.assertEqual(
            _resolve_pricing_ticker(
                "ABC/F TB Equity",
                "OTHER/F TB Equity",
            ),
            "",
        )
        self.assertEqual(
            _resolve_pricing_ticker(
                "PTT-R TB Equity",
                "PTT TB Equity",
            ),
            "PTT TB Equity",
        )
        self.assertEqual(
            _resolve_pricing_ticker(
                "PTT-R TB Equity",
                "PTT-R TB Equity",
            ),
            "",
        )

    def test_non_thai_security_ignores_thai_local_mapping(self):
        self.assertEqual(
            _resolve_pricing_ticker(
                "ABC US Equity",
                "OTHER US Equity",
            ),
            "ABC US Equity",
        )

    def test_thai_strip_candidate_only_removes_foreign_board_marker(self):
        self.assertEqual(
            _strip_thai_foreign_board("DELTA/F TB Equity"),
            "DELTA TB Equity",
        )
        self.assertEqual(
            _strip_thai_foreign_board("PTT-R TB Equity"),
            "PTT TB Equity",
        )
        self.assertTrue(_is_thai_foreign_line("DELTA/F TB Equity"))
        self.assertTrue(_is_thai_foreign_line("PTT-R TB Equity"))
        self.assertTrue(_is_local_thai_equity("DELTA TB Equity"))
        self.assertFalse(_is_local_thai_equity("DELTA/F TB Equity"))
        self.assertFalse(_is_local_thai_equity("PTT-R TB Equity"))

    def test_drsk_obligor_ticker_appends_equity_yellow_key(self):
        self.assertEqual(_clean_mapping_value("NVDA US"), "NVDA US Equity")
        self.assertEqual(_clean_mapping_value("017670 KS"), "017670 KS Equity")
        self.assertEqual(
            _clean_mapping_value("PTT TB Equity"),
            "PTT TB Equity",
        )
        self.assertEqual(_clean_mapping_value(None), "")

    def test_known_truncation_exception_is_explicit(self):
        self.assertEqual(
            thai_pricing_overrides()["CPNREI/F TB EQUITY"],
            "CPNREIT TB Equity",
        )

    def test_candidate_universe_skips_invalid_strip_for_override(self):
        candidates = _thai_candidate_tickers(
            [
                "CPNREI/F TB Equity",
                "DELTA/F TB Equity",
                "PTT-R TB Equity",
                "700 HK Equity",
            ]
        )

        self.assertIn("CPNREIT TB Equity", candidates)
        self.assertIn("DELTA TB Equity", candidates)
        self.assertIn("PTT TB Equity", candidates)
        self.assertNotIn("CPNREI TB Equity", candidates)
        self.assertNotIn("700 HK Equity", candidates)

    def test_selector_uses_approved_override(self):
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "CPNREI/F TB Equity",
                    "Fundamental Ticker": "CPNREIT TB Equity",
                    "Name": "CPN Retail Growth Leasehold REIT",
                },
                {
                    "Ticker": "CPNREIT TB Equity",
                    "Fundamental Ticker": "CPNREIT TB Equity",
                    "Name": "CPN Retail Growth Leasehold REIT",
                    "Market Status": "ACTV",
                },
            ]
        )
        result = _select_thai_pricing_tickers(
            ["CPNREI/F TB Equity"],
            cache,
        ).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "CPNREIT TB Equity")
        self.assertEqual(result["Thai Price Mapping"], "Approved Override")
        self.assertEqual(result["Pricing Market Status"], "ACTV")

    def test_selector_rejects_non_local_override(self):
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "ABC/F TB Equity",
                    "Fundamental Ticker": "ABC TB Equity",
                    "Name": "ABC Foreign",
                },
                {
                    "Ticker": "ABC US Equity",
                    "Fundamental Ticker": "ABC TB Equity",
                    "Name": "ABC US",
                    "Market Status": "ACTV",
                },
            ]
        )
        with patch(
            "etf_capping.data.thai_pricing_overrides",
            return_value={"ABC/F TB EQUITY": "ABC US Equity"},
        ):
            result = _select_thai_pricing_tickers(
                ["ABC/F TB Equity"],
                cache,
            ).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "")
        self.assertEqual(result["Thai Price Mapping"], "Unresolved")

    def test_selector_uses_strip_not_fundamental_as_price_ticker(self):
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "DELTA/F TB Equity",
                    "Fundamental Ticker": "DELTA TB Equity",
                    "Name": "Delta Electronics Thailand",
                },
                {
                    "Ticker": "DELTA TB Equity",
                    "Fundamental Ticker": "DELTA TB Equity",
                    "Name": "Delta Electronics Thailand",
                    "Market Status": "Active",
                },
            ]
        )
        result = _select_thai_pricing_tickers(
            ["DELTA/F TB Equity"],
            cache,
        ).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "DELTA TB Equity")
        self.assertEqual(result["Thai Price Mapping"], "Validated /F Strip")

    def test_selector_uses_validated_nvdr_strip(self):
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "PTT-R TB Equity",
                    "Fundamental Ticker": "PTT TB Equity",
                    "Name": "PTT NVDR",
                },
                {
                    "Ticker": "PTT TB Equity",
                    "Fundamental Ticker": "PTT TB Equity",
                    "Name": "PTT Public Company",
                    "Market Status": "ACTV",
                },
            ]
        )
        result = _select_thai_pricing_tickers(
            ["PTT-R TB Equity"],
            cache,
        ).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "PTT TB Equity")
        self.assertEqual(result["Thai Price Mapping"], "Validated -R Strip")
        self.assertEqual(result["Pricing Market Status"], "ACTV")

    def test_helpdesk_drsk_applies_only_to_leftover_unresolved(self):
        selected = pd.DataFrame(
            [
                {
                    "Ticker": "ABC/F TB Equity",
                    "Thai Local Pricing Ticker": "ABC TB Equity",
                    "Thai Price Mapping": "Validated /F Strip",
                    "Pricing Market Status": "ACTV",
                    "Thai Mapping Note": "",
                },
                {
                    "Ticker": "XYZ-R TB Equity",
                    "Thai Local Pricing Ticker": "",
                    "Thai Price Mapping": "Unresolved",
                    "Pricing Market Status": "",
                    "Thai Mapping Note": "Strip failed.",
                },
            ]
        )
        drsk = pd.DataFrame(
            [
                {
                    "Ticker": "XYZ-R TB Equity",
                    "Thai Local Pricing Ticker": "XYZ TB Equity",
                },
                {
                    "Ticker": "ABC/F TB Equity",
                    "Thai Local Pricing Ticker": "WRONG TB Equity",
                },
            ]
        )
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "XYZ TB Equity",
                    "Name": "XYZ Local",
                    "Market Status": "ACTV",
                }
            ]
        )
        result = _apply_helpdesk_drsk(selected, drsk, cache).set_index("Ticker")

        self.assertEqual(
            result.loc["ABC/F TB Equity", "Thai Local Pricing Ticker"],
            "ABC TB Equity",
        )
        self.assertEqual(
            result.loc["ABC/F TB Equity", "Thai Price Mapping"],
            "Validated /F Strip",
        )
        self.assertEqual(
            result.loc["XYZ-R TB Equity", "Thai Local Pricing Ticker"],
            "XYZ TB Equity",
        )
        self.assertEqual(
            result.loc["XYZ-R TB Equity", "Thai Price Mapping"],
            "HelpDesk DRSK",
        )
        self.assertEqual(
            result.loc["XYZ-R TB Equity", "Pricing Market Status"],
            "ACTV",
        )

    def test_helpdesk_drsk_rejects_foreign_or_empty_local(self):
        selected = pd.DataFrame(
            [
                {
                    "Ticker": "ABC-R TB Equity",
                    "Thai Local Pricing Ticker": "",
                    "Thai Price Mapping": "Unresolved",
                    "Pricing Market Status": "",
                    "Thai Mapping Note": "Strip failed.",
                }
            ]
        )
        drsk = pd.DataFrame(
            [
                {
                    "Ticker": "ABC-R TB Equity",
                    "Thai Local Pricing Ticker": "ABC-R TB Equity",
                }
            ]
        )
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "ABC-R TB Equity",
                    "Name": "ABC NVDR",
                    "Market Status": "ACTV",
                }
            ]
        )
        result = _apply_helpdesk_drsk(selected, drsk, cache).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "")
        self.assertEqual(result["Thai Price Mapping"], "Unresolved")

    def test_selector_validates_strip_or_fails_closed(self):
        matching_cache = pd.DataFrame(
            [
                {
                    "Ticker": "ABC/F TB Equity",
                    "Fundamental Ticker": "PARENT US Equity",
                    "Name": "ABC Foreign",
                },
                {
                    "Ticker": "ABC TB Equity",
                    "Fundamental Ticker": "PARENT US Equity",
                    "Name": "ABC Local",
                },
            ]
        )
        accepted = _select_thai_pricing_tickers(
            ["ABC/F TB Equity"],
            matching_cache,
        ).iloc[0]
        mismatch_cache = matching_cache.copy()
        mismatch_cache.loc[
            mismatch_cache["Ticker"].eq("ABC TB Equity"),
            "Fundamental Ticker",
        ] = "OTHER US Equity"
        rejected = _select_thai_pricing_tickers(
            ["ABC/F TB Equity"],
            mismatch_cache,
        ).iloc[0]

        self.assertEqual(accepted["Thai Local Pricing Ticker"], "ABC TB Equity")
        self.assertEqual(accepted["Thai Price Mapping"], "Validated /F Strip")
        self.assertEqual(rejected["Thai Local Pricing Ticker"], "")
        self.assertEqual(rejected["Thai Price Mapping"], "Unresolved")

    def test_selector_requires_name_or_market_status(self):
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "ABC/F TB Equity",
                    "Fundamental Ticker": "PARENT US Equity",
                    "Name": "ABC Foreign",
                },
                {
                    "Ticker": "ABC TB Equity",
                    "Fundamental Ticker": "PARENT US Equity",
                    "Security Type": "Common Stock",
                },
            ]
        )
        result = _select_thai_pricing_tickers(
            ["ABC/F TB Equity"],
            cache,
        ).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "")
        self.assertEqual(result["Thai Price Mapping"], "Unresolved")

    def test_selector_rejects_na_reference_sentinel(self):
        cache = pd.DataFrame(
            [
                {
                    "Ticker": "ABC/F TB Equity",
                    "Fundamental Ticker": "PARENT US Equity",
                    "Name": "ABC Foreign",
                },
                {
                    "Ticker": "ABC TB Equity",
                    "Fundamental Ticker": "PARENT US Equity",
                    "Name": "N/A",
                    "Market Status": "#N/A Field Not Applicable",
                },
            ]
        )
        result = _select_thai_pricing_tickers(
            ["ABC/F TB Equity"],
            cache,
        ).iloc[0]

        self.assertEqual(result["Thai Local Pricing Ticker"], "")
        self.assertEqual(result["Thai Price Mapping"], "Unresolved")


class ResponseParserTests(unittest.TestCase):
    def test_non_response_container_is_rejected(self):
        self.assertFalse(_is_response({"Position": []}))
        self.assertFalse(_is_response([]))
        self.assertFalse(_is_response((RuntimeError("x"), "message", None)))

    def test_arrow_execute_response_name_is_accepted(self):
        class ArrowExecuteResponse:
            pass

        self.assertTrue(_is_response(ArrowExecuteResponse()))

    def test_named_item_missing_named_value_fails_closed(self):
        class FakeItem:
            name = "Unexpected"

            @staticmethod
            def df():
                return pd.DataFrame(
                    {"Unexpected Value": [100]},
                    index=pd.Index(["ABC US Equity"], name="ID"),
                )

        result = _item_frame(FakeItem(), output_name="Position")

        self.assertTrue(result.empty)


class ProductionSafetyTests(unittest.TestCase):
    def test_production_bql_calls_are_allowlisted(self):
        package = PROJECT_ROOT / "etf_capping"
        forbidden_data_call = re.compile(
            r"bq\.data\.(?:"
            r"esg|ghg|climate|sustainab|eu_tax|carbon|emission|"
            r"temp_score|green_bond|fossil_fuel|pct_women|"
            r"cast_parent|id_bb_company"
            r")",
            flags=re.IGNORECASE,
        )
        forbidden_cast_universe = re.compile(
            r"bq\.univ\.parent\s*\([^)]*CAST",
            flags=re.IGNORECASE | re.DOTALL,
        )
        allowed_data_calls = {
            "bb_default_risk_obligor_ticker",
            "id",
            "market_status",
            "name",
            "pending_position",
            "position_without_pending",
            "px_last",
        }
        allowed_universe_calls = {
            "fundamentalticker",
            "members",
        }

        paths = [*package.glob("*.py"), PROJECT_ROOT / "MAIN.ipynb"]
        for path in paths:
            source = path.read_text(encoding="utf-8")
            self.assertIsNone(
                forbidden_data_call.search(source),
                f"Forbidden BQL data request in {path.name}",
            )
            self.assertIsNone(
                forbidden_cast_universe.search(source),
                f"Forbidden CAST universe request in {path.name}",
            )
            data_calls = set(re.findall(r"\bbq\.data\.([A-Za-z_]\w*)", source))
            universe_calls = set(re.findall(r"\bbq\.univ\.([A-Za-z_]\w*)", source))
            self.assertEqual(
                data_calls - allowed_data_calls,
                set(),
                f"Unreviewed BQL data call in {path.name}",
            )
            self.assertEqual(
                universe_calls - allowed_universe_calls,
                set(),
                f"Unreviewed BQL universe call in {path.name}",
            )


if __name__ == "__main__":
    unittest.main()
