#!/usr/bin/env python3
"""Build a selectable-text PDF of the BQuant paste files."""

from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, "/tmp/etf_pdf_libs")

from fpdf import FPDF  # noqa: E402

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "ETF_Capping_BQuant_Paste.pdf"
MPL_TTF = Path(
    "/Library/Frameworks/Python.framework/Versions/3.12/lib/python3.12/"
    "site-packages/matplotlib/mpl-data/fonts/ttf"
)
MONO = MPL_TTF / "DejaVuSansMono.ttf"
SANS = MPL_TTF / "DejaVuSans.ttf"
SANS_BOLD = MPL_TTF / "DejaVuSans-Bold.ttf"

FILES = [
    ("MAIN.ipynb", ROOT / "MAIN.ipynb"),
    ("README.md", ROOT / "README.md"),
    ("etf_capping/__init__.py", ROOT / "etf_capping" / "__init__.py"),
    ("etf_capping/app.py", ROOT / "etf_capping" / "app.py"),
    ("etf_capping/config_redacted.py", ROOT / "etf_capping" / "config_redacted.py"),
    ("etf_capping/data.py", ROOT / "etf_capping" / "data.py"),
    ("etf_capping/engine.py", ROOT / "etf_capping" / "engine.py"),
]

# A4 landscape millimetres
PAGE_W, PAGE_H = 297.0, 210.0
MARGIN_L = 8.0
MARGIN_R = 8.0
HEADER_H = 14.0
FOOTER_H = 9.0
LINES_PER_PAGE = 54
WRAP_AT = 148
NAVY = (27, 42, 74)
GOLD = (201, 162, 39)
INK = (26, 26, 26)
MUTED = (90, 100, 114)
LINENUM = (138, 147, 160)
CODE_BG = (247, 248, 250)
GUTTER_BG = (236, 239, 243)
FOOTER_BG = (238, 241, 245)
RULE = (215, 220, 227)


def notebook_text(path: Path) -> str:
    nb = json.loads(path.read_text(encoding="utf-8"))
    chunks = [
        "# MAIN.ipynb — notebook cell source to paste into BQuant Desktop.",
        "# Recreate one code cell with the body below (exclude these comment lines).",
        "",
    ]
    for i, cell in enumerate(nb.get("cells", [])):
        ctype = cell.get("cell_type", "code")
        src = cell.get("source", "")
        if isinstance(src, list):
            src = "".join(src)
        chunks.append(f"# === Cell {i} ({ctype}) ===")
        chunks.append(src.rstrip("\n"))
        chunks.append("")
    return "\n".join(chunks).rstrip() + "\n"


def load_text(path: Path) -> str:
    if path.suffix == ".ipynb":
        return notebook_text(path)
    return path.read_text(encoding="utf-8")


def physical_lines(text: str) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for i, raw in enumerate(text.splitlines(), start=1):
        line = raw.replace("\t", "    ").replace("\r", "")
        if not line:
            rows.append((f"{i:4d}", ""))
            continue
        first = True
        while True:
            chunk, line = line[:WRAP_AT], line[WRAP_AT:]
            rows.append((f"{i:4d}" if first else "  ..", chunk))
            first = False
            if not line:
                break
    if not rows:
        rows.append(("   1", ""))
    return rows


def chunked(rows: list[tuple[str, str]], size: int):
    for start in range(0, len(rows), size):
        yield rows[start : start + size]


class PastePDF(FPDF):
    def __init__(self) -> None:
        super().__init__(orientation="L", unit="mm", format="A4")
        self.set_auto_page_break(auto=False, margin=0)
        self.add_font("Mono", fname=str(MONO))
        self.add_font("Sans", fname=str(SANS))
        self.add_font("SansB", fname=str(SANS_BOLD))
        self.set_title("ETF Capping Monitoring — BQuant paste pack")
        self.set_author("ETF Capping Monitoring")
        self.set_subject("Source files to copy into a BQuant Desktop project")
        self.set_creator("ETF Capping Monitoring paste-pack builder")
        self.file_name = ""
        self.file_page = 0
        self.file_pages = 0
        self.line_start = 0
        self.line_end = 0
        self.source_lines = 0
        self.total_pages = 0

    def header(self) -> None:
        return

    def footer(self) -> None:
        return

    def _draw_code_chrome(self) -> None:
        self.set_fill_color(*NAVY)
        self.rect(0, 0, PAGE_W, HEADER_H, "F")
        self.set_fill_color(*GOLD)
        self.rect(0, 0, 3.2, HEADER_H, "F")
        self.set_text_color(255, 255, 255)
        self.set_font("SansB", size=11)
        self.set_xy(8, 2.2)
        self.cell(0, 5.5, self.file_name, new_x="LMARGIN", new_y="NEXT")
        self.set_text_color(213, 220, 232)
        self.set_font("Sans", size=8)
        self.set_x(8)
        self.cell(
            0,
            4.5,
            f"Lines {self.line_start}\u2013{self.line_end} of {self.source_lines}   |   "
            f"file page {self.file_page} of {self.file_pages}   |   "
            "copy the source below; indentation is real spaces",
        )
        self.set_fill_color(*FOOTER_BG)
        self.rect(0, PAGE_H - FOOTER_H, PAGE_W, FOOTER_H, "F")
        self.set_text_color(*MUTED)
        self.set_font("Sans", size=7.5)
        self.set_xy(8, PAGE_H - 6.6)
        self.cell(
            220,
            4,
            "ETF Capping Monitoring  |  paste into BQuant Desktop  |  do not run BQL from this PDF",
        )
        self.set_text_color(*NAVY)
        self.set_font("SansB", size=8)
        self.set_xy(PAGE_W - 40, PAGE_H - 6.6)
        self.cell(32, 4, f"{self.page_no()} / {self.total_pages}", align="R")

    def draw_cover(self, toc: list[tuple[str, int, int, int]], today: str) -> None:
        self.add_page()
        self.set_fill_color(*NAVY)
        self.rect(0, 0, PAGE_W, 46, "F")
        self.set_fill_color(*GOLD)
        self.rect(0, 0, 3.2, 46, "F")
        self.set_text_color(255, 255, 255)
        self.set_font("SansB", size=26)
        self.set_xy(16, 10)
        self.cell(0, 12, "ETF Capping Monitoring")
        self.set_font("Sans", size=14)
        self.set_xy(16, 23)
        self.set_text_color(228, 233, 242)
        self.cell(0, 8, "BQuant Desktop paste pack")
        self.set_font("Sans", size=10)
        self.set_xy(16, 33)
        self.set_text_color(183, 194, 214)
        self.cell(0, 6, f"Seven source files appended in copy order   |   {today}")

        self.set_text_color(*NAVY)
        self.set_font("SansB", size=13)
        self.set_xy(16, 54)
        self.cell(0, 7, "How to use")
        notes = [
            "Copy these files into one BQuant project. Open MAIN.ipynb, restart the kernel, and run the cell.",
            "The app does not query BQL until Update is clicked.",
            "This pack uses etf_capping/config_redacted.py (shareable output). Production still uses config.py.",
            "Rename the redacted file to config.py only when sharing a desensitized project, never as the live book.",
            "Do not copy tests/, RAG KB, or ETF Capping Formula.xlsx into BQuant.",
            "Each file starts on a new page. Copy the source body; indentation is ordinary spaces.",
        ]
        self.set_font("Sans", size=9.5)
        self.set_text_color(*INK)
        y = 63
        for note in notes:
            self.set_xy(16, y)
            self.cell(4, 5.6, "\u2022")
            self.set_xy(22, y)
            self.cell(0, 5.6, note)
            y += 6.2

        self.set_text_color(*NAVY)
        self.set_font("SansB", size=13)
        self.set_xy(16, y + 4)
        self.cell(0, 7, "Contents")
        y += 14
        self.set_fill_color(*RULE)
        self.rect(16, y, PAGE_W - 32, 0.4, "F")
        y += 3
        self.set_font("SansB", size=8.5)
        self.set_text_color(*MUTED)
        self.set_xy(18, y)
        self.cell(12, 6, "#")
        self.cell(120, 6, "File")
        self.cell(28, 6, "Lines")
        self.cell(40, 6, "PDF pages")
        y += 8
        for i, (name, n_lines, start, n_pages) in enumerate(toc, start=1):
            if i % 2:
                self.set_fill_color(*CODE_BG)
                self.rect(16, y - 1.2, PAGE_W - 32, 7.4, "F")
            self.set_font("Mono", size=9)
            self.set_text_color(*NAVY)
            self.set_xy(18, y)
            self.cell(12, 5.4, f"{i:02d}")
            self.set_text_color(*INK)
            self.cell(120, 5.4, name)
            self.cell(28, 5.4, str(n_lines))
            self.cell(40, 5.4, f"{start}\u2013{start + n_pages - 1}")
            y += 7.4

        self.set_font("Sans", size=8.5)
        self.set_text_color(*MUTED)
        self.set_xy(16, PAGE_H - 16)
        self.cell(
            0,
            5,
            "Selectable DejaVu Sans Mono. Landscape A4. Indentation is preserved as ordinary spaces.",
        )

    def draw_code_page(self, rows: list[tuple[str, str]]) -> None:
        self.add_page()
        self._draw_code_chrome()
        top = HEADER_H + 2.0
        bottom = PAGE_H - FOOTER_H - 2.0
        left = MARGIN_L
        right = PAGE_W - MARGIN_R
        width = right - left
        height = bottom - top
        self.set_fill_color(*CODE_BG)
        self.rect(left, top, width, height, "F")

        line_h = height / LINES_PER_PAGE
        self.set_font("Mono", size=7.2)
        code_x = left + 3.0
        y = top + 0.4
        for _num, body in rows:
            baseline = y + line_h - 1.05
            self.set_text_color(*INK)
            # A single space keeps blank source lines copyable.
            self.text(code_x, baseline, body if body else " ")
            y += line_h


def main() -> None:
    payloads: list[tuple[str, list[tuple[str, str]]]] = []
    for name, path in FILES:
        if not path.exists():
            raise FileNotFoundError(path)
        payloads.append((name, physical_lines(load_text(path))))

    page_counts = [
        max(1, (len(rows) + LINES_PER_PAGE - 1) // LINES_PER_PAGE) for _, rows in payloads
    ]
    total_pages = 1 + sum(page_counts)
    toc: list[tuple[str, int, int, int]] = []
    cursor = 2
    for (name, rows), n_pages in zip(payloads, page_counts):
        n_source = sum(1 for label, _ in rows if label.strip()[:1].isdigit())
        toc.append((name, n_source, cursor, n_pages))
        cursor += n_pages

    pdf = PastePDF()
    pdf.total_pages = total_pages
    pdf.draw_cover(toc, date.today().isoformat())
    for (name, rows), file_pages in zip(payloads, page_counts):
        pdf.file_name = name
        pdf.file_pages = file_pages
        pdf.source_lines = sum(1 for label, _ in rows if label.strip()[:1].isdigit())
        offset = 0
        for page_in_file, chunk in enumerate(chunked(rows, LINES_PER_PAGE), start=1):
            pdf.file_page = page_in_file
            pdf.line_start = offset + 1
            pdf.line_end = offset + len(chunk)
            offset += len(chunk)
            pdf.draw_code_page(chunk)

    pdf.output(str(OUT))
    print(f"wrote {OUT}")
    print(f"pages={total_pages} bytes={OUT.stat().st_size}")


if __name__ == "__main__":
    main()
