T="6166 HK Equity"
pos=app._result.positions
row=pos[pos.Ticker.eq(T)]
print("CACHE")
print(row.T.to_string())
print("STATUS REPR", list(row["Market Status"].map(repr).unique()))
print("DIAG")
print(app._result.diagnostics[app._result.diagnostics.Ticker.eq(T)].to_string())
import bql
from datetime import date,timedelta
bq=bql.Service()
r=bq.execute(bql.Request(T,{"N":bq.data.name(),"S":bq.data.market_status()}))
print("BQL NAME"); print(r.get("N").df())
print("BQL STATUS"); print(r.get("S").df())
d=date.today()-timedelta(days=[3,1,1,1,1,1,2][date.today().weekday()])
print("BQL PX", d)
print(bq.execute(bql.Request(T,{"P":bq.data.px_last(dates=d.isoformat(),currency="USD",fill="prev")},with_params={"mode":"cached"})).get("P").df())
