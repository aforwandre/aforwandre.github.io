# ETF Capping Monitoring

> **CRITICAL ACCOUNT-SAFETY STOP:** never request, probe, test, generate, or
> use ESG, GHG, climate, or sustainable-finance data items. A violation can
> cause the Bloomberg account to be suspended or deleted. Avoid unreviewed
> separately licensed data; if no core alternative exists, obtain Bloomberg
> HelpDesk confirmation before changing any BQL call.

BQuant Desktop application that converts Current or Projected AIM positions
into company-level portfolio weights and monitors account-specific capping
limits.

## Files to copy into BQuant

Create this structure in one BQuant project:

```text
MAIN.ipynb
etf_capping/
  __init__.py
  config.py
  engine.py
  data.py
  app.py
```

Copy the Python files in the order shown above. Open `MAIN.ipynb`, restart the
kernel, and run the notebook cell. The app does not query BQL until **Update**
is clicked.

The formula source of truth is `ETF Capping Formula.xlsx` in this folder (same
workbook as the retired `.numbers` file; format only). Do not copy it into
BQuant.

## Monitoring rules

- **Highest-priority safety rule:** never request, probe, test, generate, or
  use ESG, GHG, climate, or sustainable-finance data items for any purpose.
  A violation can cause the Bloomberg account to be suspended or deleted.
  Avoid separately licensed or entitlement-unknown fields. If no confirmed
  core-data alternative exists, stop and obtain Bloomberg HelpDesk evidence
  for semantics, entitlement, and safe request breadth.
- Calculation order is fixed:
  1. preserve the exact AIM `Ticker` and `Quantity`;
  2. obtain that held security's approved `Pricing Ticker` and USD price;
  3. calculate position MV and security-level `Weight`;
  4. attach the separate company key; and
  5. sum position MVs/weights by company only for the final capping test.
  A parent/fundamental ticker must never replace the held ticker, quantity, or
  price. The only approved pricing-identity exception is the documented Thai
  `/F TB Equity` and `-R TB Equity` (N-NDVR) local-line rule below.
- Current uses `position_without_pending()` and Projected uses Current plus
  `pending_position()`. This AIM request is frozen from the 2026-08-28
  Desktop tests: `pending_position()` alone returned zeros; the sum returned
  the non-zero book. `accounts`, `pxnum=1377`, and `profile="DEFAULT_PROFILE"`
  stay on `with_params` and must not move onto `members()`.
- The header, log, and CSV filename stamps use UK time (`Europe/London`).
  AIM positions and `px_last` still use the live request calendar: Real Time
  is today, Last Close is the previous weekday (through yesterday;
  `fill="prev"` walks back through an exchange holiday). Do not pass the UK clock into
  `fetch_monitor_payload(today=...)`.
- Company mapping: hard Exception override, then
  `bq.data.id().value(bq.univ.fundamentalticker(), mapby="lineage")`, then
  the original ticker. This is the BQL replacement for both DT110 and DT679.
  The mapping is used only after position MV/Weight calculation. The workbook
  branched between DT110 and DT679 by Runbook `Level`, but Bloomberg HelpDesk
  confirmed their content is the same for this use case.
- Thai foreign lines ending in `/F TB Equity` or `-R TB Equity` retain their
  AIM ticker and quantity. Local pricing follows a fail-closed hierarchy:
  approved `THAI_PRICING_RULES`, then a deterministically stripped local
  candidate (`/F` or `-R` removed) accepted only when it returns ordinary
  reference data (`Name` or `Market Status`), ends in `TB Equity`, contains no
  `/F` or `-R`, and both securities resolve to the same company-level
  fundamental ticker. Leftover unresolved Thai foreign lines may then request
  HelpDesk-confirmed `bb_default_risk_obligor_ticker()` on that leftover
  universe only. Accept the DRSK value only when it is a cleaned local
  `TB Equity` with `Name` or `Market Status`. `fundamentalticker()` and DRSK
  are never the position identity; DRSK is pricing identity only.
  Unverified candidates remain unpriced and produce a diagnostic instead of
  reusing the sparse foreign-line price. Official 2026-09-01 BQL tabs confirm
  `cast_parent_equity_ticker()` and `id_bb_company()` are not premium, but
  they are the wrong identity here (CAST parent ticker / integer company ID)
  and are not requested. Original, strip-candidate, and leftover
  DRSK local IDs share batched reference-data caches.
- Using the liquid local Thai line exclusively for daily MV is a
  user-confirmed business override to the xlsx's literal original-ticker price
  formula. The foreign AIM ticker and quantity remain the legal position
  identity. The workbook/app differences in direct-USD pricing, missing-price
  scope, and Rank policy remain separate decisions and are not silently
  changed by this rule.
- `market_status()` supplies the listing status. Do not request it with
  Request `mode=cached`: Desktop 2026-09-02 returned stale `Delisted` for
  `6166 HK Equity` while the live item and FLDS BQL PR286 returned `Active`.
  Official empty-market statuses do not skip `px_last(..., fill="prev")`.
  A returned last price is carried, including `SUSP`/`Suspended`. Last Close
  is as-of the previous weekday; a holiday on that weekday still uses the
  last print before it. If the request is empty or non-numeric, that
  holding's price and MV fall back to zero so sibling weights still
  calculate. Official empty-market statuses are not a missing-price error;
  an Active name in this fallback remains a data issue. Acquired/ACQU is
  not overwritten to zero when a last print exists.
  Thai positions use the local Pricing Ticker's status for this price rule,
  while the original AIM status remains visible separately.
- The Runbook `Level` is displayed but does not change grouping.
- The detail table's `Position Wgt` is the real security-level weight. The
  monitor's `Company Key`, `Agg Wgt (incl cash)`, and `Agg Wgt (ex cash)` are
  company-level values used only for capping.
- Clicking a company-level Monitor row opens its actual AIM Fund Position rows
  in the right Detail pane. The table is extracted from the exact same cached
  Full Positions DataFrame and intentionally displays only `Ticker`, `NAME`,
  `Quantity`, `MV(USD)`, `Agg Wgt (incl cash)`, and
  `Agg Wgt (ex cash)`. It includes only the selected AIM account and selected
  Parent/Issuer Ticker, with one row per real holding sorted by `MV(USD)`
  descending. The two horizontal bars are stacked by held ticker: the upper
  bar reconciles each position's contribution to
  `Agg Wgt (incl cash)`, and the lower bar reconciles contributions to
  `Agg Wgt (ex cash)`. The chart is derived only from those six displayed
  columns: each position's MV share allocates the displayed aggregate totals,
  with any floating-point residual assigned to the largest-MV first row so
  both stacked bars reconcile exactly. Hover shows ticker, name, quantity, MV,
  the displayed aggregate totals, and the calculated segment contribution.
  This exposes whether a company aggregate comes from one holding or several
  grouped holdings, including hard-coded groups such as SK Inc.
- Rank is based on company weight including cash.
- Rank 1 uses `Largest`; all later ranks use `Capping`.
- The default Monitor Alerts view lists Breach and Near Limit names, plus the
  Rank 1 equity name of those funds so the largest holding can be compared
  when it sits between Largest and Capping. Rank 1 is unflagged unless it
  itself is Breach or Near Limit versus Largest. Incl Cash and Ex Cash use
  the same red/amber Status colours when that weight exceeds Capping or the
  98% near-limit threshold.
- Incomplete-account names that are still Breach or Near Limit stay on the
  default Monitor Alerts view with Status `Breach` or `Near Limit`. Other
  within-limit names of that account are not dumped onto Alerts; they remain
  on Diagnostics and the Data Issue filter. The Data Issues card still counts
  Data Quality, not Monitor Status.
- A Breach starts at 100% of the dynamic limit.
- Near Limit starts at 98% of the dynamic limit.
- Either including-cash or excluding-cash weight can trigger an alert.
- Index futures and FFX contribute zero market value, matching
  `ETF Capping Formula.xlsx`.
- Missing AIM-account responses, missing required reference data, unresolved
  Thai mappings, missing prices/quantities, and zero account MV are surfaced
  as data issues; they must not silently produce an OK capping result.

## Full Positions, documentation, and CSV export

- `Full Positions` is the second tab. Its dropdown defaults to `All Funds`
  and includes every AIM account in the 54-account Runbook, including an
  account that returned no position rows.
- The table follows the Position worksheet order with one approved adjustment:
  Column L is `USD Price`, and workbook Column M (`FX`) is omitted because the
  app requests USD prices directly. The resulting audit table has 21 columns
  and does not add a local-currency or FX BQL request.
- Its top filter row contains only the Fund dropdown and a Column E (`NAME`)
  keyword search. NAME uses case-insensitive partial matching and refreshes the
  grid live while the user types; it does not require a complete name or an
  Apply button.
- Its default row order is `Fund Name` ascending, followed by
  `Agg Wgt (incl cash)` descending. AIM Code and Ticker provide deterministic
  tie-breaks.
- The collapsed `Advanced Column Filters` panel covers the remaining 20
  columns. Text values use case-insensitive contains matching; numeric values
  support `=`, `!=`, `>`, `>=`, `<`, and `<=`; percentage columns accept `%`.
  Multiple filters are combined with AND and run only on the cached downloaded
  DataFrame.
- `Documentation` is the final tab. It gives a dependency-free visual flow,
  Mermaid-compatible source, formulas, valuation and identity rules, capping
  thresholds, data-quality behavior, and a guide to every output tab. Opening
  it does not run BQL.
- Every tabular result/configuration tab has an `Export CSV` button. It writes
  the tab's current table to the BQuant project working directory as
  UTF-8-with-BOM CSV so it opens cleanly in Excel. The Monitor and Full
  Positions exports respect their current local filters, including Fund, live
  NAME keyword, and all active advanced filters. The Exceptions tab writes
  separate exception and Thai-pricing-override files.
- The captured Desktop corpus confirms Pandas CSV file generation and access
  through the project Files pane. It does not confirm a direct browser
  download callback inside a published Launchpad app. Native `.xlsx` export
  is therefore not enabled and no extra package is installed.

## First Desktop validation

Validate one account from each combination before relying on the full run:

1. Current and Projected AIM positions.
2. Last Close and Real Time pricing.
3. An SK hard-override security.
4. Multiple listings mapped to one `fundamentalticker()`.
5. A security where `fundamentalticker()` is unavailable and falls back to
   its own ticker.
6. A Thai `/F TB Equity` or `-R TB Equity` position whose displayed Price
   Ticker is the local `TB Equity` line and whose Price Mapping shows
   `Approved Override`, `Validated /F Strip`, `Validated -R Strip`, or
   `HelpDesk DRSK`; specifically confirm `CPNREI/F TB Equity` uses
   `CPNREIT TB Equity` with `Approved Override`.
7. A `SUSP` name carrying `px_last(..., fill="prev")`, and an official
   empty-market status with no Bloomberg last price showing zero without a
   missing-price error.
8. An Active name whose last-price request is empty or `N/A` showing Price
   and MV 0, while a sibling holding in the same AIM still has a numeric
   weight.
8. An unresolved leftover Thai mapping failing closed after override, strip,
   and leftover DRSK, without reusing the foreign-line price and without CAST
   or company-ID mappers.

The `Members(Type=AIM), Accounts=[...]` translation from
`ETF Capping Formula.xlsx` is isolated in `data.py::_aim_request` and frozen
from the 2026-08-28 Desktop tests. Do not change item names, dates, or
`with_params` placement. Projected is Current plus Pending.

## Local validation

`tests/test_engine.py` uses synthetic Pandas data and never imports or executes
BQL.
