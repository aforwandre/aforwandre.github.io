"""Refresh everything local after a change to the app: one command, no arguments.

Steps, in this order, stopping at the first hard failure:

1. unittest suite (synthetic data only; no BQL, no Bloomberg, no network)
2. preview/build_preview.py      regenerates preview/interface.html
3. preview/check_preview.js      headless checks on the generated page
4. preview/serve_preview.py      restarts the local server on 127.0.0.1:8770
5. Upload sync                   every runtime file, bytes compared afterwards

The preview and the Upload folder are derived artifacts, so this script is the
only supported way to update them. Run it from anywhere; paths are resolved
from this file.

Use the interpreter that has pandas (the system ``python3`` here). The project
``.venv`` is Python 3.11 with syntax tooling only, so running this script with
``.venv/bin/python`` fails at step 1 with ``ModuleNotFoundError: pandas``.

Exit code 0 means every step passed. A non-zero exit names the failed step.
"""

from __future__ import annotations

import filecmp
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGE = HERE / "fi_index_change"
UPLOAD = HERE / "Upload"
PREVIEW = HERE / "preview"

PORT = 8770

# Every file the Desktop project needs, in copy order. Tests, the cache, the
# preview, and the markdown stay off the Desktop copy.
RUNTIME_FILES = (
    "__init__.py",
    "config.py",
    "field_library.py",
    "data.py",
    "engine.py",
    "cache.py",
    "app.py",
)
NOTEBOOK = "MAIN.ipynb"


class StepFailed(RuntimeError):
    """A refresh step returned a non-zero status."""


def run(label: str, command: list[str], cwd: Path | None = None) -> None:
    print(f"\n== {label} ==", flush=True)
    result = subprocess.run(command, cwd=str(cwd or HERE))
    if result.returncode != 0:
        raise StepFailed(f"{label} exited {result.returncode}")


def wait_for_server(url: str, attempts: int = 40, delay: float = 0.25) -> None:
    """Poll the page until it answers. A bind failure only reaches the log.

    ``Popen`` succeeds even when the port is taken, so the server start is not
    proven until the page is actually served.
    """
    for _ in range(attempts):
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                if response.status == 200:
                    return
        except (urllib.error.URLError, OSError):
            time.sleep(delay)
    raise StepFailed(f"preview server did not answer {url}")


def sync_upload() -> list[str]:
    """Copy each runtime file next to its `.txt` twin, then compare bytes."""
    if not PACKAGE.is_dir():
        raise StepFailed(f"package folder is missing: {PACKAGE}")
    target = UPLOAD / PACKAGE.name
    target.mkdir(parents=True, exist_ok=True)

    pairs: list[tuple[Path, Path]] = []
    for name in RUNTIME_FILES:
        source = PACKAGE / name
        if not source.is_file():
            raise StepFailed(f"runtime file is missing: {source}")
        pairs.append((source, target / f"{name}.txt"))

    notebook = HERE / NOTEBOOK
    if not notebook.is_file():
        raise StepFailed(f"notebook is missing: {notebook}")
    pairs.append((notebook, UPLOAD / f"{NOTEBOOK}.txt"))

    for source, destination in pairs:
        shutil.copyfile(source, destination)

    mismatched = [
        str(destination)
        for source, destination in pairs
        if not filecmp.cmp(source, destination, shallow=False)
    ]
    if mismatched:
        raise StepFailed("Upload copy differs after write: " + ", ".join(mismatched))

    expected = {destination for _source, destination in pairs}
    strays = sorted(
        str(path.relative_to(HERE))
        for path in UPLOAD.rglob("*.txt")
        if path not in expected
    )
    for stray in strays:
        print(f"note: not managed by this script, left alone: {stray}")
    # Upload is one folder that gets dragged onto the Desktop project, so any
    # editor or Finder droppings travel with it. ``.DS_Store`` is macOS
    # metadata with no source and no purpose on the Desktop, and it was
    # surviving every refresh because the copy step only writes files.
    for junk in UPLOAD.rglob(".DS_Store"):
        junk.unlink()
        print(f"removed stray: {junk.relative_to(HERE)}")
    return [f"{source.name} -> {destination.relative_to(HERE)}" for source, destination in pairs]


def main() -> int:
    node = shutil.which("node")
    if node is None:
        print("node is missing, so preview/check_preview.js cannot run", file=sys.stderr)
        return 2
    if not (PREVIEW / "build_preview.py").is_file():
        print("preview/build_preview.py is missing", file=sys.stderr)
        return 2

    try:
        run("tests", [sys.executable, "-m", "unittest", "discover", "-s", "tests"])
        run("preview build", [sys.executable, "preview/build_preview.py"])
        run("preview check", [node, "preview/check_preview.js"])
        run(
            "preview serve",
            [sys.executable, "preview/serve_preview.py", str(PORT), "preview"],
        )
        wait_for_server(f"http://127.0.0.1:{PORT}/interface.html")
        print("\n== Upload sync ==")
        for line in sync_upload():
            print(f"copied {line}")
    except StepFailed as exc:
        print(f"\nrefresh stopped: {exc}", file=sys.stderr)
        return 1

    print(
        f"\nrefresh ok: preview at http://127.0.0.1:{PORT}/interface.html, "
        f"Upload holds {len(RUNTIME_FILES)} runtime files plus {NOTEBOOK}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
