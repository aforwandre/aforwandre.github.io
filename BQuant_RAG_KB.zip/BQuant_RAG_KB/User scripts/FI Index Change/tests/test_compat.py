"""Desktop runs Python 3.11, where an f-string expression cannot contain a backslash.

PEP 701 relaxed this in Python 3.12, so a 3.12 authoring Mac compiles code that
Desktop rejects with ``SyntaxError: f-string expression part cannot include a
backslash``. This scan keeps the uploaded files 3.11-clean.
"""

from __future__ import annotations

import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULES = sorted((ROOT / "fi_index_change").glob("*.py")) + sorted((ROOT / "preview").glob("*.py"))


class DesktopPython311Tests(unittest.TestCase):
    def test_no_backslash_inside_f_string_expressions(self):
        offenders = []
        for path in MODULES:
            source = path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(path))
            for node in ast.walk(tree):
                if not isinstance(node, ast.FormattedValue):
                    continue
                segment = ast.get_source_segment(source, node.value) or ""
                if "\\" in segment:
                    offenders.append(f"{path.name}:{node.lineno}: {segment}")
        self.assertEqual(offenders, [], "Move the backslash outside the f-string expression.")

    def test_upload_files_compile_under_311(self):
        """The runtime tree must be 3.11 syntax. ``py_compile`` catches it locally."""
        import py_compile
        import tempfile

        with tempfile.TemporaryDirectory() as folder:
            for path in sorted((ROOT / "fi_index_change").glob("*.py")):
                py_compile.compile(
                    str(path),
                    cfile=str(Path(folder) / (path.stem + ".pyc")),
                    doraise=True,
                )


if __name__ == "__main__":
    unittest.main()
