"""One widget-stub installer for the whole test suite.

``plotly``, ``ipywidgets`` and ``ipydatagrid`` exist on BQuant Desktop and not
on an authoring machine. The stubs used to live inside ``test_app_runtime``,
which meant the full run passed only because that file sorts before
``test_engine``: running ``test_engine`` on its own failed on a missing
``plotly``. Keeping the installer here lets ``conftest`` apply it once for every
entry point, and a genuinely installed package still wins because nothing that
already exists in ``sys.modules`` is replaced.
"""

from __future__ import annotations

import sys
import types


class _Node:
    """Permissive stand-in for one widget or Plotly object."""

    def __init__(self, *args, **kwargs):
        for index, arg in enumerate(args):
            if index == 0 and isinstance(arg, (list, tuple)):
                self.children = list(arg)
            elif index == 0 and isinstance(arg, str):
                self.value = arg
        for key, value in kwargs.items():
            setattr(self, key, list(value) if key == "children" else value)

    def __getattr__(self, name):
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        child = _Node()
        object.__setattr__(self, name, child)
        return child

    def __call__(self, *args, **kwargs):
        return self

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        return False

    def observe(self, handler, names="value"):
        return None

    def unobserve(self, handler, names="value"):
        return None

    def clear_output(self, wait=False):
        return None

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0


_WIDGET_NAMES = (
    "Accordion",
    "Button",
    "Checkbox",
    "Dropdown",
    "HBox",
    "HTML",
    "HTMLStyle",
    "ButtonStyle",
    "IntSlider",
    "Label",
    "Layout",
    "Output",
    "SelectMultiple",
    "Tab",
    "Text",
    "ToggleButtons",
    "VBox",
    "Widget",
)

_PLOTLY_NAMES = ("Bar", "Figure", "FigureWidget", "Layout", "Scatter")


def install() -> None:
    """Install the missing ``plotly`` and ``ipywidgets`` stubs.

    ``ipydatagrid`` is deliberately not stubbed: when it is absent the app is
    supposed to fall back to its own HTML table, and that fallback has its own
    tests. Faking the grid would hide the fallback path instead of exercising
    it.
    """
    if "plotly.graph_objects" not in sys.modules:
        graph_objects = types.ModuleType("plotly.graph_objects")
        for name in _PLOTLY_NAMES:
            setattr(graph_objects, name, _Node)
        plotly = sys.modules.get("plotly") or types.ModuleType("plotly")
        plotly.graph_objects = graph_objects
        sys.modules.setdefault("plotly", plotly)
        sys.modules.setdefault("plotly.graph_objects", graph_objects)

    if "ipywidgets" not in sys.modules:
        widgets = types.ModuleType("ipywidgets")
        for name in _WIDGET_NAMES:
            setattr(widgets, name, _Node)
        sys.modules.setdefault("ipywidgets", widgets)
