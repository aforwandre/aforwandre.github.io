"""Local checks for dates, diffs, and cache. No BQL."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fi_index_change import data as data_module
from fi_index_change import engine as engine_module
from fi_index_change.cache import export_paths, load_historical, save_historical
from fi_index_change.data import _merge_item_frames
from fi_index_change.field_library import DURATION_FIELDS, YIELD_FIELDS
from fi_index_change.engine import (
    Comparison,
    Transition,
    book_unchanged,
    bucket_chart_rows,
    build_transition,
    change_export_frame,
    comparison_for,
    default_month_end,
    diff_members,
    align_snapshot_labels,
    export_display_frame,
    grid_display_frame,
    top_add_exit_rows,
    currency_choices,
    membership_access_failure,
    month_end_choices,
    prepare_members,
    rating_bucket,
    selection_status,
    signed_change_frame,
    summarize,
    validate_index_ticker,
    weighted_mean,
)


def _members(rows: list[dict]) -> pd.DataFrame:
    frame = pd.DataFrame(rows)
    notes: list[str] = []
    return prepare_members(frame, notes)


def _complete_members(rows: list[dict]) -> pd.DataFrame:
    """A prepared snapshot carrying every requested item column.

    The CSV cache refuses a partially parsed month, so a round-trip test has
    to satisfy the full item contract.
    """
    from fi_index_change.cache import required_columns

    frame = _members(rows)
    for name in required_columns():
        if name not in frame.columns:
            frame[name] = None
    return frame


class ScheduleTests(unittest.TestCase):
    def test_october_22_defaults_to_the_open_month(self):
        today = pd.Timestamp("2026-10-22")
        self.assertEqual(default_month_end(today), "2026-10-30")
        labels = dict(month_end_choices(today, 4))
        self.assertEqual(labels["2026-10-30 (Projected)"], "2026-10-30")
        self.assertNotIn("2026-11-30 (Projected)", labels)
        comparison = comparison_for("2026-10-30", today, list(labels.values()))
        self.assertEqual(comparison.previous_date, "2026-09-30")
        self.assertEqual(comparison.kind, "projected")

    def test_locked_month_defaults_to_itself_and_offers_next(self):
        today = pd.Timestamp("2026-10-30")
        self.assertEqual(default_month_end(today), "2026-10-30")
        labels = dict(month_end_choices(today, 4))
        self.assertEqual(labels["2026-11-30 (Projected)"], "2026-11-30")
        self.assertIn("2026-10-30", labels)
        locked = comparison_for("2026-10-30", today, list(labels.values()))
        self.assertEqual(locked.previous_date, "2026-09-30")
        self.assertEqual(locked.kind, "historical")
        projected = comparison_for("2026-11-30", today, list(labels.values()))
        self.assertEqual(projected.previous_date, "2026-10-30")
        self.assertEqual(projected.kind, "projected")

    def test_sunday_month_end_rolls_back(self):
        today = pd.Timestamp("2026-06-15")
        comparison = comparison_for("2026-06-30", today, ["2026-06-30"])
        self.assertEqual(comparison.previous_date, "2026-05-29")
        self.assertEqual(comparison.kind, "projected")

    def test_index_yellow_key_and_unknown_date(self):
        self.assertEqual(validate_index_ticker("  LEGATRUU   Index "), "LEGATRUU Index")
        with self.assertRaises(ValueError):
            validate_index_ticker("LEGATRUU")
        with self.assertRaises(ValueError):
            comparison_for("2026-10-31", pd.Timestamp("2026-10-22"), ["2026-10-30"])


class ConfigTests(unittest.TestCase):
    def test_default_book_is_all(self):
        """The operator set All on 2026-10-31. Standard must stay pickable."""
        from fi_index_change.config import DEFAULT_BOOK

        self.assertEqual(DEFAULT_BOOK, "All")
        self.assertIn(DEFAULT_BOOK, {"Standard", "MBS/TBA", "All"})

    def test_chart_width_stops_at_eighty_percent_of_fhd(self):
        """Charts must not run to the right edge of the nine filter boxes.

        The operator asked for a cap at 80% of a 1920 px full-screen view on
        2026-11-01. The filter row is wider, so the cap decides the width.
        """
        from fi_index_change.config import (
            CHART_MAX_SCREEN_RATIO,
            CHART_WIDTH_PX,
            FILTER_GAP_PX,
            FILTER_ROW_WIDTH_PX,
            FILTER_WIDTHS,
            SCREEN_WIDTH_PX,
        )

        row = sum(FILTER_WIDTHS.values()) + FILTER_GAP_PX * (len(FILTER_WIDTHS) - 1)
        self.assertEqual(FILTER_ROW_WIDTH_PX, row)
        self.assertEqual(SCREEN_WIDTH_PX, 1920)
        self.assertAlmostEqual(CHART_MAX_SCREEN_RATIO, 0.8)
        self.assertEqual(CHART_WIDTH_PX, int(SCREEN_WIDTH_PX * CHART_MAX_SCREEN_RATIO))
        self.assertLessEqual(CHART_WIDTH_PX, SCREEN_WIDTH_PX * CHART_MAX_SCREEN_RATIO)
        self.assertLess(CHART_WIDTH_PX, row)

    def test_no_manual_version_stamp(self):
        """Cache invalidation is automatic; the operator does not maintain a stamp."""
        from fi_index_change import config

        self.assertFalse(hasattr(config, "REQUEST_STAMP"))
        self.assertFalse(hasattr(config, "PARSER_VERSION"))


class FootnoteTests(unittest.TestCase):
    def test_caption_names_both_weight_asof_dates(self):
        from fi_index_change.engine import caption_html

        html = caption_html("2026-09-30", "2026-10-30")
        self.assertIn("Add/End weight is as of 2026-10-30", html)
        self.assertIn("Exit/Begin weight is as of 2026-09-30", html)

    def test_caption_defines_ig_and_hy(self):
        from fi_index_change.engine import caption_html

        html = caption_html()
        self.assertIn("IG = investment grade", html)
        self.assertIn("HY = high yield", html)
        self.assertIn("NR = no usable letter grade", html)
        self.assertIn("MBS/TBA", html)
        # The three-value classification is the whole contract.
        self.assertNotIn("NR/Missing", html)
        self.assertNotIn("Numeric (unmapped)", html)
        self.assertIn("Turnover:", html)
        self.assertIn("ending index MV / beginning index MV", html)
        self.assertIn("Turnover Rate divides it by Begin Weight", html)
        self.assertIn("selected month-end", html)
        self.assertNotIn("No Data Access License", html)
        self.assertNotIn("403", html)
        self.assertNotIn("Export keeps positive weights", html)
        self.assertNotIn("Filters start on", html)
        self.assertLess(len(html), 900)


class ChartOrderTests(unittest.TestCase):
    """Horizontal charts: Add positive, Exit negative, largest Add on top."""

    def test_signed_changes_put_largest_add_first_and_largest_exit_last(self):
        frame = pd.DataFrame([
            {"Action": "Add", "Weight": 2.0, "ID": "A"},
            {"Action": "Exit", "Weight": 5.0, "ID": "B"},
            {"Action": "Add", "Weight": 4.0, "ID": "C"},
            {"Action": "Exit", "Weight": 1.0, "ID": "D"},
        ])
        out = signed_change_frame(frame)
        self.assertEqual(out["ID"].tolist(), ["C", "A", "D", "B"])
        self.assertEqual(out["Weight"].tolist(), [4.0, 2.0, -1.0, -5.0])

    def test_bucket_chart_rows_follow_add_plus_exit_order(self):
        previous = _members([
            {"ID": "AA keep", "Weight": 5.0, "Country": "AUSTRIA", "Security Type": "GLOBAL"},
            {"ID": "BB old", "Weight": 3.0, "Country": "BELGIUM", "Security Type": "GLOBAL"},
            {"ID": "CC old", "Weight": 6.0, "Country": "CANADA", "Security Type": "GLOBAL"},
        ])
        latest = _members([
            {"ID": "AA keep", "Weight": 5.0, "Country": "AUSTRIA", "Security Type": "GLOBAL"},
            {"ID": "AA new", "Weight": 4.0, "Country": "AUSTRIA", "Security Type": "GLOBAL"},
            {"ID": "BB keep", "Weight": 5.0, "Country": "BELGIUM", "Security Type": "GLOBAL"},
            {"ID": "BB new", "Weight": 1.0, "Country": "BELGIUM", "Security Type": "GLOBAL"},
            {"ID": "CC keep", "Weight": 2.0, "Country": "CANADA", "Security Type": "GLOBAL"},
        ])
        transition = Transition(
            label="t",
            previous_date="2026-08-31",
            latest_date="2026-09-30",
            kind="historical",
            status="ok",
            previous=previous,
            latest=latest,
        )
        summary, _headline = summarize(transition, "Country", "Standard", None)
        labels, adds, exits = bucket_chart_rows(summary, "Country")
        # Add + Exit total: Belgium 9, Canada 8, Austria 4.
        self.assertEqual(labels, ["Belgium", "Canada", "Austria"])
        self.assertEqual(adds, [6.0, 2.0, 4.0])
        self.assertEqual(exits, [-3.0, -6.0, 0.0])
        self.assertTrue(all(value <= 0 for value in exits))
        self.assertTrue(all(value >= 0 for value in adds))

    def test_bucket_chart_keeps_top_twenty_plus_others(self):
        summary = pd.DataFrame([
            {"Country": f"C{index:02d}", "Add Weight": float(25 - index), "Exit Weight": 0.0}
            for index in range(25)
        ])
        labels, adds, exits = bucket_chart_rows(summary, "Country")
        self.assertEqual(len(labels), 21)
        self.assertEqual(labels[:20], [f"C{index:02d}" for index in range(20)])
        self.assertEqual(labels[-1], "Others")
        self.assertEqual(float(adds[-1]), sum(float(value) for value in range(5, 0, -1)))
        self.assertEqual(float(exits[-1]), 0.0)

    def test_bucket_chart_keeps_offsetting_add_and_exit(self):
        summary = pd.DataFrame([
            {"Country": "Offset", "Add Weight": 2.0, "Exit Weight": 2.0},
            {"Country": "Zero", "Add Weight": 0.0, "Exit Weight": 0.0},
        ])
        labels, adds, exits = bucket_chart_rows(summary, "Country")
        self.assertEqual(labels, ["Offset"])
        self.assertEqual(adds, [2.0])
        self.assertEqual(exits, [-2.0])

    def test_bucket_chart_skips_zero_change_buckets(self):
        summary = pd.DataFrame([
            {"Country": "Keep", "Add Weight": 2.0, "Exit Weight": 0.0},
            {"Country": "Zero A", "Add Weight": 0.0, "Exit Weight": 0.0},
            {"Country": "Zero B", "Add Weight": 0.0, "Exit Weight": 0.0},
            {"Country": "Exit", "Add Weight": 0.0, "Exit Weight": 1.0},
        ])
        labels, adds, exits = bucket_chart_rows(summary, "Country")
        self.assertEqual(labels, ["Keep", "Exit"])
        self.assertEqual(adds, [2.0, 0.0])
        self.assertEqual(exits, [0.0, -1.0])

    def test_bucket_chart_has_no_others_when_it_fits(self):
        summary = pd.DataFrame([
            {"Country": "Only", "Add Weight": 1.0, "Exit Weight": 0.5},
        ])
        labels, _adds, _exits = bucket_chart_rows(summary, "Country")
        self.assertEqual(labels, ["Only"])


class DiffTests(unittest.TestCase):
    def test_add_and_exit_on_id(self):
        previous = _members([
            {"ID": "A Corp", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "US"},
            {"ID": "B Corp", "Weight": 2.0, "Security Type": "GLOBAL", "Country": "DE"},
        ])
        latest = _members([
            {"ID": "B Corp", "Weight": 2.5, "Security Type": "GLOBAL", "Country": "US"},
            {"ID": "C Corp", "Weight": 3.0, "Security Type": "GLOBAL", "Country": "US"},
        ])
        _previous, _latest, added, exited = diff_members(previous, latest, "Standard")
        self.assertEqual(added["ID"].tolist(), ["C Corp"])
        self.assertEqual(exited["ID"].tolist(), ["A Corp"])

    def test_country_change_is_not_an_add(self):
        previous = _members([
            {"ID": "B Corp", "Weight": 2.0, "Security Type": "GLOBAL", "Country": "GERMANY"},
        ])
        latest = _members([
            {"ID": "B Corp", "Weight": 2.0, "Security Type": "GLOBAL", "Country": "UNITED STATES"},
        ])
        transition_previous, transition_latest, added, exited = diff_members(previous, latest, "All")
        self.assertTrue(added.empty)
        self.assertTrue(exited.empty)
        self.assertEqual(transition_previous["Country"].tolist(), ["Germany"])
        self.assertEqual(transition_latest["Country"].tolist(), ["United States"])

    def test_empty_side_is_unavailable(self):
        schedule = Comparison("2026-08-31", "2026-09-30", "historical")
        good = _members([{"ID": "A Corp", "Weight": 10.0, "Security Type": "GLOBAL"}])
        transition = build_transition(
            {"2026-08-31": good, "2026-09-30": pd.DataFrame()},
            schedule,
            {"2026-08-31": "ok", "2026-09-30": "unavailable"},
        )
        self.assertEqual(transition.status, "unavailable")

    def test_tba_is_separated(self):
        frame = _members([
            {"ID": "A Corp", "Weight": 5.0, "Security Type": "GLOBAL"},
            {"ID": "FN 30 Mtge", "Weight": 9.0, "Security Type": "MBS 30yr"},
        ])
        _previous, latest, added, _exited = diff_members(pd.DataFrame(columns=frame.columns), frame, "Standard")
        self.assertEqual(latest["ID"].tolist(), ["A Corp"])
        self.assertEqual(added["ID"].tolist(), ["A Corp"])

    def test_same_book_ignores_another_book(self):
        previous = _members([
            {"ID": "A Corp", "Weight": 5.0, "Security Type": "GLOBAL"},
            {"ID": "FN 30 Mtge", "Weight": 9.0, "Security Type": "MBS 30yr"},
        ])
        latest = _members([
            {"ID": "A Corp", "Weight": 5.0, "Security Type": "GLOBAL"},
            {"ID": "FN 15 Mtge", "Weight": 9.0, "Security Type": "MBS 15yr"},
        ])
        self.assertTrue(book_unchanged(previous, latest, "Standard"))
        self.assertFalse(book_unchanged(previous, latest, "MBS/TBA"))

    def test_fraction_weights_scale_once(self):
        notes: list[str] = []
        frame = prepare_members(pd.DataFrame([
            {"ID": "A Corp", "Weight": 0.4, "Security Type": "GLOBAL"},
            {"ID": "B Corp", "Weight": 0.6, "Security Type": "GLOBAL"},
        ]), notes)
        self.assertAlmostEqual(float(frame["Weight"].sum()), 100.0)
        self.assertTrue(any("fractions" in note for note in notes))


class MetricTests(unittest.TestCase):
    def test_oas_sentinel_is_excluded_and_zero_coupon_stays(self):
        frame = _members([
            {"ID": "A Corp", "Weight": 50.0, "OAS": 100.0, "Coupon": 0.0, "Security Type": "GLOBAL"},
            {"ID": "B Corp", "Weight": 50.0, "OAS": 9999.0, "Coupon": 4.0, "Security Type": "GLOBAL"},
        ])
        self.assertAlmostEqual(weighted_mean(frame, "OAS"), 100.0)
        self.assertAlmostEqual(weighted_mean(frame, "Coupon"), 2.0)
        at_cutoff = _members([
            {"ID": "A Corp", "Weight": 50.0, "OAS": 100.0, "Security Type": "GLOBAL"},
            {"ID": "B Corp", "Weight": 50.0, "OAS": 9000.0, "Security Type": "GLOBAL"},
        ])
        self.assertAlmostEqual(weighted_mean(at_cutoff, "OAS"), 100.0)

    def test_rating_buckets(self):
        self.assertEqual(rating_bucket("BBB+"), "IG")
        self.assertEqual(rating_bucket("Ba1"), "HY")
        self.assertEqual(rating_bucket("Aaa"), "IG")
        # A numeric scale has no letter grade, so it is NR. The raw number is
        # still visible in the Rating column; it is never mapped to a letter.
        self.assertEqual(rating_bucket("24"), "NR")
        self.assertEqual(rating_bucket(None), "NR")

    def test_tenor_buckets(self):
        frame = _members([
            {"ID": "A Corp", "Weight": 1.0, "Tenor": 0.5, "Security Type": "GLOBAL"},
            {"ID": "B Corp", "Weight": 1.0, "Tenor": 1.0, "Security Type": "GLOBAL"},
            {"ID": "C Corp", "Weight": 1.0, "Tenor": 20.0, "Security Type": "GLOBAL"},
            {"ID": "D Corp", "Weight": 1.0, "Tenor": None, "Security Type": "GLOBAL"},
        ])
        buckets = dict(zip(frame["ID"], frame["Tenor Bucket"]))
        self.assertEqual(buckets["A Corp"], "0-1Y")
        self.assertEqual(buckets["B Corp"], "1-3Y")
        self.assertEqual(buckets["C Corp"], "20Y+")
        self.assertEqual(buckets["D Corp"], "Missing")

    def test_mbs_missing_tenor_is_not_applicable(self):
        frame = _members([
            {"ID": "FNMA TBA 30YR", "Weight": 1.0, "Tenor": None, "Security Type": "MBS 30yr"},
            {"ID": "FNMA TBA 15YR", "Weight": 1.0, "Tenor": 15.0, "Security Type": "MBS 30yr"},
        ])
        buckets = dict(zip(frame["ID"], frame["Tenor Bucket"]))
        self.assertEqual(buckets["FNMA TBA 30YR"], "N.A.")
        self.assertEqual(buckets["FNMA TBA 15YR"], "10-20Y")

    def test_alignment_latest_value_wins_when_both_present(self):
        previous = pd.DataFrame({
            "ID": ["A"], "Book": ["Standard"], "Country": ["Germany"],
            "Sector": ["Corporate"], "Tenor Bucket": ["1-3Y"], "Currency": ["EUR"],
            "Rating": ["HY"], "Rating Bucket": ["HY"],
        })
        latest = pd.DataFrame({
            "ID": ["A"], "Book": ["Standard"], "Country": ["United States"],
            "Sector": ["Corporate"], "Tenor Bucket": ["3-5Y"], "Currency": ["USD"],
            "Rating": ["IG"], "Rating Bucket": ["IG"],
        })
        align_snapshot_labels(previous, latest)
        for frame in (previous, latest):
            row = frame.iloc[0]
            self.assertEqual(row["Country"], "United States")
            self.assertEqual(row["Tenor Bucket"], "3-5Y")
            self.assertEqual(row["Currency"], "USD")
            self.assertEqual(row["Rating"], "IG")
            self.assertEqual(row["Rating Bucket"], "IG")

    def test_alignment_fills_missing_latest_from_previous(self):
        previous = pd.DataFrame({
            "ID": ["A"], "Book": ["Standard"], "Country": ["United States"],
            "Sector": ["Corporate"], "Tenor Bucket": ["1-3Y"], "Currency": ["USD"],
            "Rating": ["AA+"], "Rating Bucket": ["IG"],
        })
        latest = pd.DataFrame({
            "ID": ["A"], "Book": ["Standard"], "Country": ["(blank)"],
            "Sector": ["(blank)"], "Tenor Bucket": ["Missing"], "Currency": ["(blank)"],
            "Rating": ["NR"], "Rating Bucket": ["NR"],
        })
        align_snapshot_labels(previous, latest)
        for frame in (previous, latest):
            row = frame.iloc[0]
            self.assertEqual(row["Country"], "United States")
            self.assertEqual(row["Sector"], "Corporate")
            self.assertEqual(row["Tenor Bucket"], "1-3Y")
            self.assertEqual(row["Currency"], "USD")
            # A stated NR is a classification, not a blank, so it wins and the
            # bond sits in NR on both month-ends. Never two selections.
            self.assertEqual(row["Rating"], "NR")
            self.assertEqual(row["Rating Bucket"], "NR")

    def test_alignment_keeps_latest_not_applicable_label(self):
        previous = pd.DataFrame({
            "ID": ["MBS1"], "Book": ["Standard"], "Tenor Bucket": ["10-20Y"],
            "Rating": ["AA+"], "Rating Bucket": ["IG"],
        })
        latest = pd.DataFrame({
            "ID": ["MBS1"], "Book": ["MBS/TBA"], "Tenor Bucket": ["N.A."],
            "Rating": ["NR"], "Rating Bucket": ["NR"],
        })
        align_snapshot_labels(previous, latest)
        self.assertEqual(previous.iloc[0]["Book"], "MBS/TBA")
        self.assertEqual(previous.iloc[0]["Tenor Bucket"], "N.A.")
        # The MBS/TBA row is NR, and it does not inherit last month's IG.
        self.assertEqual(previous.iloc[0]["Rating Bucket"], "NR")

    def test_summary_before_after(self):
        previous = _members([
            {"ID": "A Corp", "Weight": 10.0, "Country": "UNITED STATES", "OAS": 80.0, "Security Type": "GLOBAL"},
            {"ID": "B Corp", "Weight": 10.0, "Country": "GERMANY", "OAS": 120.0, "Security Type": "GLOBAL"},
        ])
        latest = _members([
            {"ID": "B Corp", "Weight": 10.0, "Country": "GERMANY", "OAS": 120.0, "Security Type": "GLOBAL"},
            {"ID": "C Corp", "Weight": 30.0, "Country": "UNITED STATES", "OAS": 90.0, "Security Type": "GLOBAL"},
        ])
        from fi_index_change.engine import Transition
        transition = Transition(
            label="t",
            previous_date="2026-08-31",
            latest_date="2026-09-30",
            kind="historical",
            status="ok",
            previous=previous,
            latest=latest,
        )
        summary, headline = summarize(transition, "Country", "Standard", None)
        us = summary.loc[summary["Country"] == "United States"].iloc[0]
        self.assertEqual(int(us["Begin Count"]), 1)
        self.assertEqual(int(us["End Count"]), 1)
        self.assertEqual(int(us["Add Count"]), 1)
        self.assertEqual(int(us["Exit Count"]), 1)
        self.assertEqual(float(us["+/- Count"]), 0.0)
        self.assertEqual(float(us["+/- Weight"]), 20.0)
        self.assertEqual(list(summary["Country"]), ["United States", "Germany"])
        self.assertEqual(
            list(summary.columns[1:5]),
            ["Begin Count", "End Count", "+/- Count", "Begin Weight"],
        )
        self.assertEqual(list(summary.columns[-4:]), ["Add Count", "Exit Count", "Add Weight", "Exit Weight"])
        self.assertEqual(headline["added"]["Count"], 1)
        self.assertEqual(headline["exited"]["Count"], 1)
        from fi_index_change.engine import change_export_frame
        exported = change_export_frame(transition, "Standard")
        self.assertEqual(set(exported["Action"]), {"Add", "Exit"})
        self.assertIn("Weight", exported.columns)
        self.assertFalse(exported["Weight"].isna().any())
        self.assertEqual(float(exported.loc[exported["Action"] == "Add", "Weight"].iloc[0]), 30.0)
        self.assertEqual(float(exported.loc[exported["Action"] == "Exit", "Weight"].iloc[0]), 10.0)

    def test_summary_orders_by_add_plus_exit_weight(self):
        """A big exit outranks a smaller add. Add-only order would flip these."""
        previous = _members([
            {"ID": "KEEP Corp", "Weight": 10.0, "Country": "UNITED STATES", "Security Type": "GLOBAL"},
            {"ID": "EXIT Corp", "Weight": 30.0, "Country": "GERMANY", "Security Type": "GLOBAL"},
            {"ID": "STAY Corp", "Weight": 10.0, "Country": "JAPAN", "Security Type": "GLOBAL"},
        ])
        latest = _members([
            {"ID": "KEEP Corp", "Weight": 10.0, "Country": "UNITED STATES", "Security Type": "GLOBAL"},
            {"ID": "STAY Corp", "Weight": 10.0, "Country": "JAPAN", "Security Type": "GLOBAL"},
            {"ID": "ADD Corp", "Weight": 20.0, "Country": "JAPAN", "Security Type": "GLOBAL"},
        ])
        transition = Transition(
            label="t",
            previous_date="2026-08-31",
            latest_date="2026-09-30",
            kind="historical",
            status="ok",
            previous=previous,
            latest=latest,
        )
        summary, _headline = summarize(transition, "Country", "Standard", None)
        # DE only exits (30), JP adds 20 plus exits 0, US is unchanged.
        self.assertEqual(list(summary["Country"]), ["Germany", "Japan", "United States"])
        self.assertEqual(float(summary.loc[0, "Exit Weight"]), 30.0)
        self.assertEqual(float(summary.loc[1, "Add Weight"]), 20.0)
        self.assertEqual(
            list(summary.columns),
            [
                "Country",
                "Begin Count",
                "End Count",
                "+/- Count",
                "Begin Weight",
                "End Weight",
                "+/- Weight",
                "Turnover (index %)",
                "Turnover Rate (%)",
                *[
                    f"{side} {field}"
                    for field in ("OAS", "Z-Spread", "I-Spread", *DURATION_FIELDS, *YIELD_FIELDS)
                    for side in ("Begin", "End", "+/-")
                ],
                "Begin Tenor",
                "End Tenor",
                "+/- Tenor",
                "Add Count",
                "Exit Count",
                "Add Weight",
                "Exit Weight",
            ],
        )

    def test_summary_carries_all_three_spread_blocks(self):
        previous = _members([
            {"ID": "A", "Weight": 50.0, "Country": "UNITED STATES", "Security Type": "GLOBAL",
             "OAS": 100.0, "Z-Spread": 110.0, "I-Spread": 90.0},
            {"ID": "B", "Weight": 50.0, "Country": "GERMANY", "Security Type": "GLOBAL",
             "OAS": 50.0, "Z-Spread": 60.0, "I-Spread": 40.0},
        ])
        latest = _members([
            {"ID": "A", "Weight": 60.0, "Country": "UNITED STATES", "Security Type": "GLOBAL",
             "OAS": 120.0, "Z-Spread": 130.0, "I-Spread": 110.0},
            {"ID": "C", "Weight": 40.0, "Country": "UNITED STATES", "Security Type": "GLOBAL",
             "OAS": 80.0, "Z-Spread": 85.0, "I-Spread": 75.0},
        ])
        transition = Transition(
            label="t", previous_date="2026-08-31", latest_date="2026-09-30",
            kind="historical", status="ok", previous=previous, latest=latest,
        )
        summary, headline = summarize(transition, "Country", "Standard", None)
        row = summary.loc[summary["Country"] == "United States"].iloc[0]
        for field in ("OAS", "Z-Spread", "I-Spread"):
            self.assertIn(f"Begin {field}", summary.columns)
            self.assertIn(f"End {field}", summary.columns)
            self.assertIn(f"+/- {field}", summary.columns)
        self.assertIn("OAS", headline["before"])
        self.assertIn("Z-Spread", headline["before"])
        self.assertIn("I-Spread", headline["before"])
        exported = change_export_frame(transition, "Standard")
        for field in ("OAS", "Z-Spread", "I-Spread"):
            self.assertIn(field, exported.columns)

    def test_turnover_uses_index_mv_ratio(self):
        previous = _members([
            {"ID": "EXIT Corp", "Weight": 10.0, "Country": "GERMANY", "Security Type": "GLOBAL"},
            {"ID": "KEEP Corp", "Weight": 90.0, "Country": "UNITED STATES", "Security Type": "GLOBAL"},
        ])
        latest = _members([
            {"ID": "ADD Corp", "Weight": 20.0, "Country": "JAPAN", "Security Type": "GLOBAL"},
            {"ID": "KEEP Corp", "Weight": 80.0, "Country": "UNITED STATES", "Security Type": "GLOBAL"},
        ])
        transition = Transition(
            label="t", previous_date="2026-08-31", latest_date="2026-09-30",
            kind="historical", status="ok", previous=previous, latest=latest,
            index_mv_ratio=1.05, turnover_basis="official",
        )
        summary, headline = summarize(transition, "Country", "Standard", None)
        germany = summary.loc[summary["Country"] == "Germany"].iloc[0]
        japan = summary.loc[summary["Country"] == "Japan"].iloc[0]
        self.assertEqual(float(germany["Turnover (index %)"]), 10.0)
        self.assertEqual(float(japan["Turnover (index %)"]), 21.0)
        self.assertEqual(float(germany["Turnover Rate (%)"]), 100.0)
        self.assertTrue(pd.isna(japan["Turnover Rate (%)"]))
        self.assertEqual(headline["turnover_basis"], "official")
        self.assertAlmostEqual(float(headline["turnover"]), 31.0)

    def test_turnover_falls_back_without_index_mv(self):
        previous = _members([
            {"ID": "EXIT Corp", "Weight": 10.0, "Country": "GERMANY", "Security Type": "GLOBAL"},
            {"ID": "KEEP Corp", "Weight": 90.0, "Country": "UNITED STATES", "Security Type": "GLOBAL"},
        ])
        latest = _members([
            {"ID": "ADD Corp", "Weight": 20.0, "Country": "JAPAN", "Security Type": "GLOBAL"},
            {"ID": "KEEP Corp", "Weight": 80.0, "Country": "UNITED STATES", "Security Type": "GLOBAL"},
        ])
        transition = Transition(
            label="t", previous_date="2026-08-31", latest_date="2026-09-30",
            kind="historical", status="ok", previous=previous, latest=latest,
        )
        summary, headline = summarize(transition, "Country", "Standard", None)
        japan = summary.loc[summary["Country"] == "Japan"].iloc[0]
        self.assertEqual(float(japan["Turnover (index %)"]), 20.0)
        self.assertEqual(headline["turnover_basis"], "approx")


class DetailChartTests(unittest.TestCase):
    def test_top_add_exit_rows_limits_each_side_to_ten(self):
        frame = pd.DataFrame(
            [{"Action": "Add", "Weight": float(value), "ID": f"A{value}"} for value in range(1, 16)]
            + [{"Action": "Exit", "Weight": float(value), "ID": f"E{value}"} for value in range(1, 16)]
        )
        top = top_add_exit_rows(frame)
        self.assertEqual(len(top), 20)
        self.assertEqual(top["Action"].tolist()[:10], ["Add"] * 10)
        self.assertEqual(top["Action"].tolist()[10:], ["Exit"] * 10)
        self.assertEqual(top["ID"].tolist()[:10], [f"A{value}" for value in range(15, 5, -1)])
        # Smallest of the selected exits first, largest exit last.
        self.assertEqual(float(top["Weight"].iloc[10]), -6.0)
        self.assertEqual(float(top["Weight"].iloc[-1]), -15.0)

    def test_top_add_exit_rows_keeps_small_buckets_whole(self):
        frame = pd.DataFrame([
            {"Action": "Add", "Weight": 2.0, "ID": "A"},
            {"Action": "Exit", "Weight": 5.0, "ID": "B"},
        ])
        top = top_add_exit_rows(frame)
        self.assertEqual(top["ID"].tolist(), ["A", "B"])
        self.assertEqual(top["Weight"].tolist(), [2.0, -5.0])


class PrunedItemTests(unittest.TestCase):
    def test_market_value_is_not_a_member_item(self):
        """Guard against a silent re-add of the discarded field.

        It was removed on 2026-11-02: the only consumer published an index-MV
        ratio behind an unconfirmed currency basis, so the field was fetched
        on every Update and then thrown away, while costing one item on a
        request already fighting the two-minute limit.
        """
        from fi_index_change.field_library import ITEM_NAMES, OPTIONAL_ITEMS
        self.assertNotIn("Market Value", ITEM_NAMES)
        self.assertEqual(OPTIONAL_ITEMS, ())


class ExportTableTests(unittest.TestCase):
    def test_first_data_row_repeats_the_header(self):
        frame = pd.DataFrame({
            "Action": ["Add"], "Weight": [1.2345],
            "Maturity": [pd.Timestamp("2034-11-15")],
        })
        out = export_display_frame(frame, ("Action", "Weight", "Maturity"))
        self.assertEqual(list(out.columns), ["Action", "Weight", "Maturity"])
        self.assertEqual(out.iloc[0].tolist(), ["Action", "Weight", "Maturity"])
        self.assertEqual(out.iloc[1].tolist(), ["Add", "1.2345%", "2034-11-15"])

    def test_weight_is_printed_as_a_percent_without_rounding(self):
        frame = pd.DataFrame({"Weight": [0.957183, 0.0012, 1.0, float("nan")]})
        out = export_display_frame(frame, ("Weight",))
        self.assertEqual(
            out.iloc[1:].iloc[:, 0].tolist(),
            ["0.957183%", "0.0012%", "1%", ""],
        )

    def test_other_numeric_columns_keep_no_percent_sign(self):
        frame = pd.DataFrame({"Weight": [1.5], "Coupon": [4.25], "OAS": [118.5]})
        out = export_display_frame(frame, ("Weight", "Coupon", "OAS"))
        self.assertEqual(out.iloc[1].tolist(), ["1.5%", "4.25", "118.5"])

    def test_weight_sits_after_sector_in_both_copy_tables(self):
        from fi_index_change.app import POSITION_COLUMNS
        from fi_index_change.engine import EXPORT_COLUMNS

        for order in (EXPORT_COLUMNS, POSITION_COLUMNS):
            columns = list(order)
            self.assertIn("Sector", columns)
            self.assertIn("Weight", columns)
            self.assertEqual(columns.index("Weight"), columns.index("Sector") + 1, order)
            self.assertNotEqual(columns[0], "Weight")

    def test_empty_frame_still_has_the_header_row(self):
        out = export_display_frame(pd.DataFrame(), ("Action", "Weight"))
        self.assertEqual(len(out), 1)
        self.assertEqual(out.iloc[0].tolist(), ["Action", "Weight"])

    def test_frame_with_none_of_the_columns_keeps_the_header_instead_of_raising(self):
        """A mismatch must not raise: the header row is the whole contract."""
        frame = pd.DataFrame({"Something": [1.0, 2.0]})
        out = export_display_frame(frame, ("Action", "Weight"))
        self.assertEqual(list(out.columns), ["Action", "Weight"])
        self.assertEqual(len(out), 1)
        self.assertEqual(out.iloc[0].tolist(), ["Action", "Weight"])


class GridFrameTests(unittest.TestCase):
    """ipydatagrid must never see hidden or NaT date columns."""

    def test_grid_frame_keeps_only_requested_columns(self):
        frame = pd.DataFrame({
            "Action": ["Add"], "ID": ["TBA 6.0"], "Name": ["FNMA TBA"],
            "Weight": [1.23456], "Maturity": [pd.NaT], "AS_OF_DATE": ["2026-10-30"],
        })
        view = grid_display_frame(frame, ("Action", "ID", "Name", "Weight"))
        self.assertEqual(list(view.columns), ["Action", "ID", "Name", "Weight"])
        self.assertNotIn("Maturity", view.columns)
        self.assertNotIn("AS_OF_DATE", view.columns)
        self.assertEqual(float(view.loc[0, "Weight"]), 1.2346)

    def test_grid_frame_turns_nat_and_timestamps_into_text(self):
        frame = pd.DataFrame({
            "ID": ["A", "B"],
            "Maturity": [pd.NaT, pd.Timestamp("2034-11-15")],
        })
        view = grid_display_frame(frame, ("ID", "Maturity"))
        self.assertEqual(view["Maturity"].tolist(), ["", "2034-11-15"])

    def test_grid_frame_handles_empty_and_missing_columns(self):
        empty = grid_display_frame(pd.DataFrame(), ("ID", "Weight"))
        self.assertTrue(empty.empty)
        self.assertEqual(list(empty.columns), ["ID", "Weight"])
        frame = pd.DataFrame({"ID": ["A"]})
        view = grid_display_frame(frame, ("ID", "Maturity"))
        self.assertEqual(list(view.columns), ["ID"])


class ParserTests(unittest.TestCase):
    def test_unnamed_security_index_becomes_id(self):
        from fi_index_change.data import _item_frame

        class Item:
            name = "Weight"

            def df(self):
                frame = pd.DataFrame({"Weight": [0.1, 0.2]})
                frame.index = pd.Index(["A Corp", "B Corp"])
                return frame

        out = _item_frame(Item(), "Weight")
        self.assertEqual(out["ID"].tolist(), ["A Corp", "B Corp"])
        self.assertEqual(out["Weight"].tolist(), [0.1, 0.2])

    def test_row_number_index_is_not_an_id(self):
        from fi_index_change.data import _item_frame

        class Item:
            name = "Weight"

            def df(self):
                return pd.DataFrame({"Weight": [0.1, 0.2]})

        out = _item_frame(Item(), "Weight")
        self.assertTrue(out.empty)

    def test_multi_column_rating_uses_the_base_rating_field(self):
        from fi_index_change.data import _item_frame

        # rating() exposes BASE_RATING and NORMALIZED_SCALE, so the
        # "exactly one leftover column" guess returns nothing and every
        # Standard bond silently becomes NR/Missing. Observed on Desktop.
        class Item:
            name = "Rating"

            def df(self):
                return pd.DataFrame({
                    "ID": ["A Corp", "B Corp"],
                    "BASE_RATING": ["AA-", "BB+"],
                    "NORMALIZED_SCALE": [4, 14],
                })

        out = _item_frame(Item(), "Rating")
        self.assertEqual(out["ID"].tolist(), ["A Corp", "B Corp"])
        self.assertEqual(out["Rating"].tolist(), ["AA-", "BB+"])

    def test_multi_column_rating_reaches_ig_and_hy_buckets(self):
        from fi_index_change.data import _item_frame

        class Item:
            name = "Rating"

            def df(self):
                return pd.DataFrame({
                    "ID": ["A Corp", "B Corp"],
                    "BASE_RATING": ["AA-", "BB+"],
                    "NORMALIZED_SCALE": [4, 14],
                })

        members = _item_frame(Item(), "Rating")
        members["Weight"] = [50.0, 50.0]
        members["Security Type"] = ["GLOBAL", "GLOBAL"]
        frame = engine_module.prepare_members(members)
        self.assertEqual(frame["Rating Bucket"].tolist(), ["IG", "HY"])

    def test_a_two_column_item_without_a_mapping_stays_empty(self):
        from fi_index_change.data import _item_frame

        # No mapping means no safe choice: returning the wrong column would
        # put an unknown number into a displayed field.
        class Item:
            name = "Unknown"

            def df(self):
                return pd.DataFrame({"ID": ["A"], "LEFT": [1], "RIGHT": [2]})

        self.assertTrue(_item_frame(Item(), "Unknown").empty)


class CacheTests(unittest.TestCase):
    def test_round_trip_and_refuse_empty(self):
        frame = _complete_members([
            {"ID": "A Corp", "Weight": 10.0, "Security Type": "GLOBAL", "Name": "Example"},
        ])
        frame["AS_OF_DATE"] = "2026-09-30"
        frame["SNAPSHOT_KIND"] = "historical"
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            save_historical("LEGATRUU Index", "2026-09-30", frame, root)
            loaded = load_historical("LEGATRUU Index", "2026-09-30", root)
            self.assertIsNotNone(loaded)
            self.assertEqual(loaded["ID"].tolist(), ["A Corp"])
            with self.assertRaises(ValueError):
                save_historical("LEGATRUU Index", "2026-08-31", pd.DataFrame(), root)

    def test_cache_entry_follows_the_field_contract(self):
        """Changing the item list invalidates old cache entries with no manual bump."""
        from fi_index_change import cache as cache_module

        frame = _complete_members([
            {"ID": "A Corp", "Weight": 10.0, "Security Type": "GLOBAL", "Name": "Example"},
        ])
        frame["AS_OF_DATE"] = "2026-09-30"
        frame["SNAPSHOT_KIND"] = "historical"
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            save_historical("LEGATRUU Index", "2026-09-30", frame, root)
            self.assertIsNotNone(load_historical("LEGATRUU Index", "2026-09-30", root))
            with patch.object(cache_module, "FIELD_CONTRACT", "a|different|contract"):
                self.assertIsNone(load_historical("LEGATRUU Index", "2026-09-30", root))


class HardeningTests(unittest.TestCase):
    """Regression checks for the 2026-10-24 audit fixes."""

    def test_mbs_tba_export_paths_stay_inside_the_cache_folder(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            # cache_dir no longer creates the folder, because creating it on
            # the read path made a read-only project folder fail an Update
            # before any cached month was read. The writer creates it.
            (root / "cache").mkdir(parents=True, exist_ok=True)
            change_path, summary_path = export_paths(
                "LEGATRUU Index", "2026-09-30", "2026-10-30", "MBS/TBA", root
            )
            self.assertEqual(change_path.parent.name, "cache")
            self.assertEqual(summary_path.parent, change_path.parent)
            self.assertNotIn("/", change_path.name)
            self.assertNotIn("/", summary_path.name)
            frame = pd.DataFrame([{"Action": "Add", "Weight": 1.0}])
            frame.to_csv(change_path, index=False)
            frame.to_csv(summary_path, index=False)
            self.assertTrue(change_path.exists())
            self.assertTrue(summary_path.exists())

    def test_merge_item_frames_reports_duplicate_ids(self):
        notes: list[str] = []
        merged = _merge_item_frames(
            [
                pd.DataFrame({"ID": ["A", "A"], "Weight": [0.4, 0.9]}),
                pd.DataFrame({"ID": ["A", "A"], "Name": ["old", "new"]}),
            ],
            notes,
        )
        self.assertEqual(len(merged), 1)
        self.assertEqual(merged.iloc[0]["Weight"], 0.9)
        self.assertTrue(any("duplicate" in note.lower() for note in notes))

    def test_out_of_range_tenor_is_missing_and_tenor_summary_survives(self):
        frame = _members([
            {"ID": "OK Corp", "Weight": 10.0, "Tenor": 2.0, "Security Type": "GLOBAL"},
            {"ID": "NEG Corp", "Weight": 10.0, "Tenor": -2.0, "Security Type": "GLOBAL"},
            {"ID": "HUGE Corp", "Weight": 10.0, "Tenor": 2000.0, "Security Type": "GLOBAL"},
            {"ID": "NULL Corp", "Weight": 10.0, "Tenor": None, "Security Type": "GLOBAL"},
        ])
        buckets = dict(zip(frame["ID"], frame["Tenor Bucket"]))
        self.assertEqual(buckets["OK Corp"], "1-3Y")
        self.assertEqual(buckets["NEG Corp"], "Missing")
        self.assertEqual(buckets["HUGE Corp"], "20Y+")
        self.assertEqual(buckets["NULL Corp"], "Missing")
        transition = Transition(
            label="t",
            previous_date="2026-08-31",
            latest_date="2026-09-30",
            kind="historical",
            status="ok",
            previous=frame,
            latest=frame,
        )
        summary, _headline = summarize(transition, "Tenor", "Standard", None)
        self.assertFalse(summary.empty)
        self.assertIn("20Y+", summary["Tenor Bucket"].astype(str).tolist())

    def test_missing_ids_are_dropped(self):
        frame = pd.DataFrame({
            "ID": ["A Corp", None, float("nan")],
            "Weight": [10.0, 20.0, 30.0],
            "Security Type": ["GLOBAL", "GLOBAL", "GLOBAL"],
        })
        out = prepare_members(frame)
        self.assertEqual(out["ID"].tolist(), ["A Corp"])

    def test_comparison_default_dropdown_uses_config_count(self):
        today = pd.Timestamp("2026-10-22")
        short = month_end_choices(today, 4)
        with patch.object(engine_module, "MONTH_END_CHOICES", 4):
            comparison = comparison_for(short[-1][1], today)
            self.assertIn(comparison.selected_date, [value for _label, value in short])
            wider = month_end_choices(today, 18)
            with self.assertRaises(ValueError):
                comparison_for(wider[10][1], today)

    def test_incomplete_split_snapshot_is_not_cached(self):
        frame = pd.DataFrame({
            "ID": ["A Corp", "B Corp"],
            "Weight": [10.0, 20.0],
            "Security Type": ["GLOBAL", "GLOBAL"],
        })
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with patch.object(data_module, "_fetch_live", return_value=(frame, False)), \
                 patch.object(data_module, "_require_bql", return_value=object()), \
                 patch.object(data_module, "load_historical", return_value=None), \
                 patch.object(data_module, "save_historical") as save_mock:
                payload = data_module.fetch_index_payload(
                    "LEGATRUU Index",
                    "2026-10-30",
                    today=pd.Timestamp("2026-10-22"),
                    cache_root=root,
                )
            save_mock.assert_not_called()
            self.assertTrue(
                any("identity item did not parse" in note for note in payload.notes)
            )
            self.assertEqual(payload.statuses.get("2026-10-30"), "partial")

    def test_fetch_aligns_both_snapshots_automatically(self):
        previous_frame = pd.DataFrame({
            "ID": ["A Corp", "B Corp"],
            "Weight": [10.0, 20.0],
            "Security Type": ["GLOBAL", "GLOBAL"],
            "Country": ["GERMANY", "FRANCE"],
            "Sector": ["Corporate", "Corporate"],
            "Rating": ["BB+", "BB+"],
        })
        latest_frame = pd.DataFrame({
            "ID": ["A Corp", "B Corp"],
            "Weight": [11.0, 21.0],
            "Security Type": ["GLOBAL", "GLOBAL"],
            "Country": ["UNITED STATES", "FRANCE"],
            "Sector": ["Corporate", "Corporate"],
            "Rating": ["AA+", ""],
        })
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with patch.object(
                data_module, "_fetch_live", side_effect=[(previous_frame, True), (latest_frame, True)]
            ), patch.object(data_module, "_require_bql", return_value=object()), \
               patch.object(data_module, "load_historical", return_value=None), \
               patch.object(data_module, "save_historical"):
                payload = data_module.fetch_index_payload(
                    "LEGATRUU Index",
                    "2026-10-30",
                    today=pd.Timestamp("2026-10-22"),
                    cache_root=root,
                )
        previous = payload.snapshots[payload.previous_date].set_index("ID")
        latest = payload.snapshots[payload.selected_date].set_index("ID")
        # A changed: latest wins on both sides. B has no rating text this month,
        # so it is classified NR on both sides; a blank is never inherited from
        # last month, and one bond never answers to two selections.
        self.assertEqual(previous.loc["A Corp", "Rating"], "AA+")
        self.assertEqual(latest.loc["A Corp", "Rating"], "AA+")
        self.assertEqual(previous.loc["A Corp", "Country"], "United States")
        self.assertEqual(latest.loc["A Corp", "Country"], "United States")
        self.assertEqual(previous.loc["B Corp", "Rating"], "(blank)")
        self.assertEqual(latest.loc["B Corp", "Rating"], "(blank)")
        self.assertEqual(latest.loc["B Corp", "Rating Bucket"], "NR")
        self.assertEqual(previous.loc["B Corp", "Rating Bucket"], "NR")
        self.assertEqual(
            engine_module.rating_class_conflicts(
                payload.snapshots[payload.previous_date],
                payload.snapshots[payload.selected_date],
            ),
            (),
        )

    def test_cache_write_failure_keeps_the_snapshot(self):
        frame = pd.DataFrame({
            "ID": ["A Corp"],
            "Weight": [10.0],
            "Security Type": ["GLOBAL"],
        })
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with patch.object(data_module, "_fetch_live", return_value=(frame, True)), \
                 patch.object(data_module, "_require_bql", return_value=object()), \
                 patch.object(data_module, "load_historical", return_value=None), \
                 patch.object(data_module, "save_historical", side_effect=OSError("read only")):
                payload = data_module.fetch_index_payload(
                    "LEGATRUU Index",
                    "2026-10-30",
                    today=pd.Timestamp("2026-10-22"),
                    cache_root=root,
                )
            self.assertTrue(any("cache write skipped" in note for note in payload.notes))
            # The snapshot survives a failed cache write. Its status is read
            # from the frame, not from the mocked ``cache_ok`` flag, so a
            # two-column frame is reported as partial even here.
            self.assertIn("2026-09-30", payload.snapshots)
            self.assertEqual(payload.statuses.get("2026-09-30"), "partial")


class IndexBoxTests(unittest.TestCase):
    def test_any_yellow_key_is_accepted(self):
        self.assertEqual(validate_index_ticker("  LF98TRUU   Index "), "LF98TRUU Index")
        self.assertEqual(validate_index_ticker("NOTANINDEX Index"), "NOTANINDEX Index")
        with self.assertRaises(ValueError):
            validate_index_ticker("aggregate")

    def test_selection_line_marks_pending_without_a_request(self):
        unloaded = selection_status("LEGATRUU Index", "2026-10-30", None)
        self.assertTrue(unloaded["pending"])
        self.assertIn("Nothing loaded", unloaded["text"])
        loaded = {
            "index": "LEGATRUU Index",
            "previous": "2026-09-30",
            "selected": "2026-10-30",
            "kind": "historical",
            "status": "ok",
        }
        matched = selection_status("LEGATRUU Index", "2026-10-30", loaded)
        self.assertFalse(matched["pending"])
        self.assertIn("match the loaded comparison", matched["text"])
        moved = selection_status("LF98TRUU Index", "2026-08-31", loaded)
        self.assertTrue(moved["pending"])
        self.assertIn("index LF98TRUU Index", moved["text"])
        self.assertIn("month-end 2026-08-31", moved["text"])
        unavailable = dict(loaded, status="unavailable")
        self.assertIn("Comparison unavailable", selection_status("LEGATRUU Index", "2026-10-30", unavailable)["text"])

    def test_britain_displays_as_united_kingdom_and_currency_follows_the_book(self):
        frame = _members([
            {"ID": "GB1", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "BRITAIN", "Currency": "GBP"},
            {"ID": "GB2", "Weight": 1.0, "Security Type": "GLOBAL", "Country": " Britain ", "Currency": "GBP"},
            {"ID": "DE1", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "Germany", "Currency": "EUR"},
            {"ID": "MB1", "Weight": 1.0, "Security Type": "MBS 30yr", "Country": "(blank)", "Currency": "USD"},
        ])
        shown = set(frame["Country"])
        self.assertEqual(shown, {"United Kingdom", "Germany", "MBS/TBA"})
        self.assertEqual(currency_choices([frame], "Standard"), ["EUR", "GBP"])
        self.assertEqual(currency_choices([frame], "MBS/TBA"), ["USD"])
        self.assertEqual(currency_choices([frame], "All"), ["EUR", "GBP", "USD"])
        self.assertEqual(currency_choices([], "Standard"), [])

    def test_snat_displays_as_supranational(self):
        frame = _members([
            {"ID": "SNAT1", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "SNAT", "Currency": "EUR"},
        ])
        self.assertEqual(frame.loc[0, "Country"], "Supranational")

    def test_blank_mbs_fields_default_to_the_book_and_usd(self):
        frame = _members([
            {"ID": "TBA Mtge", "Weight": 1.0, "Security Type": "TBA",
             "Country": "", "Sector": "", "Rating": "", "Currency": ""},
            {"ID": "STD Corp", "Weight": 1.0, "Security Type": "GLOBAL",
             "Country": "", "Sector": "", "Rating": "", "Currency": ""},
        ])
        tba = frame.loc[frame["ID"] == "TBA Mtge"].iloc[0]
        self.assertEqual(tba["Book"], "MBS/TBA")
        self.assertEqual(tba["Country"], "MBS/TBA")
        self.assertEqual(tba["Sector"], "MBS/TBA")
        self.assertEqual(tba["Rating"], "NR")
        self.assertEqual(tba["Rating Bucket"], "NR")
        self.assertEqual(tba["Currency"], "USD")
        standard = frame.loc[frame["ID"] == "STD Corp"].iloc[0]
        self.assertEqual(standard["Book"], "Standard")
        self.assertEqual(standard["Country"], "(blank)")
        self.assertEqual(standard["Sector"], "(blank)")
        self.assertEqual(standard["Rating Bucket"], "NR")
        self.assertEqual(standard["Currency"], "(blank)")

    def test_municipal_ids_are_tagged_with_usd_and_na_rating(self):
        frame = _members([
            {"ID": "NYC 5 08/01/35 Muni", "Weight": 1.0, "Security Type": "GLOBAL",
             "Country": "", "Sector": "", "Rating": "AA+", "Currency": ""},
            {"ID": "STD Corp", "Weight": 1.0, "Security Type": "GLOBAL",
             "Country": "UNITED STATES", "Sector": "Corporate", "Rating": "A", "Currency": "USD"},
        ])
        municipal = frame.loc[frame["ID"] == "NYC 5 08/01/35 Muni"].iloc[0]
        self.assertEqual(municipal["Book"], "Standard")
        self.assertEqual(municipal["Country"], "Municipal")
        self.assertEqual(municipal["Sector"], "Municipal")
        self.assertEqual(municipal["Currency"], "USD")
        self.assertEqual(municipal["Rating"], "NR")
        self.assertEqual(municipal["Rating Bucket"], "NR")
        standard = frame.loc[frame["ID"] == "STD Corp"].iloc[0]
        self.assertEqual(standard["Country"], "United States")
        self.assertEqual(standard["Rating Bucket"], "IG")

    def test_country_full_names_use_proper_case(self):
        """Bloomberg returns upper case; the screen uses Excel PROPER style."""
        frame = _members([
            {"ID": "A", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "UNITED STATES", "Currency": "USD"},
            {"ID": "B", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "REPUBLIC OF KOREA", "Currency": "KRW"},
            {"ID": "C", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "SUPRANATIONAL", "Currency": "EUR"},
            {"ID": "D", "Weight": 1.0, "Security Type": "GLOBAL", "Country": "COTE D'IVOIRE", "Currency": "XOF"},
        ])
        self.assertEqual(
            set(frame["Country"]),
            {"United States", "Republic Of Korea", "Supranational", "Cote D'Ivoire"},
        )

    def test_membership_license_is_not_a_session_or_empty_book(self):
        self.assertTrue(membership_access_failure("Request failed: not entitled for this index"))
        self.assertTrue(membership_access_failure("permission denied"))
        self.assertFalse(membership_access_failure("403 queries do not execute"))
        self.assertFalse(membership_access_failure(""))
        self.assertFalse(membership_access_failure("response parsed as empty"))
        with self.assertRaises(RuntimeError):
            data_module.fetch_index_long_name("LEGATRUU Index")
        with self.assertRaises(ValueError):
            data_module.fetch_index_long_name("LEGATRUU")


class CacheabilityGateTests(unittest.TestCase):
    """A snapshot that cannot be verified later must not become the answer."""

    def _frame(self):
        return pd.DataFrame({
            "ID": ["A Corp", "B Corp"],
            "Weight": [10.0, 20.0],
            "Security Type": ["GLOBAL", "GLOBAL"],
        })

    def test_effective_date_snapshot_is_not_cached_on_that_day(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(data_module, "_fetch_live", return_value=(self._frame(), True)), \
                 patch.object(data_module, "_require_bql", return_value=object()), \
                 patch.object(data_module, "load_historical", return_value=None), \
                 patch.object(data_module, "save_historical") as save_mock:
                payload = data_module.fetch_index_payload(
                    "LEGATRUU Index",
                    "2026-10-30",
                    today=pd.Timestamp("2026-10-30"),
                    cache_root=Path(folder),
                )
            # 2026-10-30 is this month's effective date. Whatever members()
            # returns on that day may still be the previous locked set. The
            # previous month-end is still cacheable, so only that date is
            # checked here.
            self.assertEqual(payload.kind, "historical")
            cached_dates = [call.args[1] for call in save_mock.call_args_list]
            self.assertNotIn("2026-10-30", cached_dates)
            self.assertIn("2026-09-30", cached_dates)
            self.assertTrue(
                any("not written to the cache" in note for note in payload.notes)
            )

    def test_older_historical_month_is_still_cached(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(data_module, "_fetch_live", return_value=(self._frame(), True)), \
                 patch.object(data_module, "_require_bql", return_value=object()), \
                 patch.object(data_module, "load_historical", return_value=None), \
                 patch.object(data_module, "save_historical") as save_mock:
                data_module.fetch_index_payload(
                    "LEGATRUU Index",
                    "2026-09-30",
                    today=pd.Timestamp("2026-10-30"),
                    cache_root=Path(folder),
                )
            cached_dates = [call.args[1] for call in save_mock.call_args_list]
            self.assertIn("2026-09-30", cached_dates)


class LabelContractTests(unittest.TestCase):
    """A cached month-end carries its labels, so the rule must be in the key."""

    def test_label_contract_follows_the_country_overrides(self):
        from fi_index_change import cache as cache_module

        original = cache_module.FIELD_CONTRACT
        try:
            with patch.object(cache_module, "LABEL_CONTRACT", "CHANGED"):
                changed = "|".join(cache_module.ITEM_NAMES) + "||CHANGED"
                self.assertNotEqual(changed, original)
        finally:
            self.assertEqual(cache_module.FIELD_CONTRACT, original)

    def test_field_contract_contains_the_label_rules(self):
        from fi_index_change import cache as cache_module
        from fi_index_change.config import MBS_TBA_LABEL, MUNICIPAL_LABEL, RATING_MISSING

        for token in (MBS_TBA_LABEL, MUNICIPAL_LABEL, RATING_MISSING):
            self.assertIn(token, cache_module.FIELD_CONTRACT)


class WeightUnitTests(unittest.TestCase):
    """Only a fraction snapshot is scaled. A small percent set is not."""

    def test_fraction_snapshot_is_scaled_to_percent(self):
        frame = engine_module.prepare_members(
            pd.DataFrame({"ID": ["A", "B"], "Weight": [0.4, 0.6], "Security Type": ["GLOBAL", "GLOBAL"]}),
        )
        self.assertEqual(list(frame["Weight"]), [40.0, 60.0])

    def test_small_percent_snapshot_is_not_scaled(self):
        frame = engine_module.prepare_members(
            pd.DataFrame({"ID": ["A", "B"], "Weight": [1.2, 1.0], "Security Type": ["GLOBAL", "GLOBAL"]}),
        )
        # A sum of 2.2 is not a fraction and not a full percent index.
        # Guessing a x100 here would have invented 220 percent.
        self.assertEqual(list(frame["Weight"]), [1.2, 1.0])


class RatingBucketTests(unittest.TestCase):
    """Exactly three classifications: IG, HY, NR.

    Team convention: everything without a usable letter grade is NR, whether
    the cause is a blank, a stated NR, N.A. on an MBS/TBA or Municipal row, or
    a vendor numeric scale.
    """

    def _prepare(self, security_types, ratings):
        return engine_module.prepare_members(pd.DataFrame({
            "ID": ["A", "B"],
            "Weight": [50.0, 50.0],
            "Security Type": security_types,
            "Rating": ratings,
        }))

    def test_unrated_standard_bond_is_nr(self):
        frame = self._prepare(["GLOBAL", "GLOBAL"], ["N.A.", "AA"])
        self.assertEqual(list(frame["Rating Bucket"]), ["NR", "IG"])

    def test_mbs_and_municipal_rows_are_nr(self):
        frame = engine_module.prepare_members(pd.DataFrame({
            "ID": ["A", "B Muni"],
            "Weight": [50.0, 50.0],
            "Security Type": ["MBS", "GLOBAL"],
            "Rating": ["AA", "AA"],
        }))
        # Municipal rows are identified by their yellow-key suffix, not by
        # Security Type. Neither carries a letter grade in this classification.
        self.assertEqual(list(frame["Rating Bucket"]), ["NR", "NR"])

    def test_vendor_nr_spellings_land_in_nr(self):
        for spelling in ("N.R.", "NR.", "N/R", "Not Rated", "UNRATED", "-", "N.A."):
            self.assertEqual(engine_module.rating_bucket(spelling), "NR", spelling)

    def test_only_three_classifications_are_ever_produced(self):
        window = [
            "", "NR", "N.A.", "N/A", "-", "24", "0", "AA+", "aa-", "AAA",
            "BBB-", "BB+", "CCC", "C", "D", "Aaa", "Baa3", "Ba1", "Caa2",
            "AA-(EXP)", "A+(P)", "NR/Missing", "Something", "(blank)",
        ]
        produced = {engine_module.rating_bucket(value) for value in window}
        self.assertEqual(produced, {"IG", "HY", "NR"})


class OneRatingPerBondTests(unittest.TestCase):
    """No bond may answer to two Rating selections.

    The alignment step writes one classification per ID into BOTH month-ends.
    These tests pin that contract so a later edit cannot split a bond again.
    """

    def _frame(self, rating, bucket):
        return pd.DataFrame({
            "ID": ["SAME"], "Book": ["Standard"], "Country": ["United States"],
            "Sector": ["Corporate"], "Tenor Bucket": ["3-5Y"], "Currency": ["USD"],
            "Rating": [rating], "Rating Bucket": [bucket],
        })

    def test_a_changed_rating_lands_on_one_classification(self):
        previous = self._frame("AA+", "IG")
        latest = self._frame("BB+", "HY")
        engine_module.align_snapshot_labels(previous, latest)
        self.assertEqual(previous.iloc[0]["Rating"], "BB+")
        self.assertEqual(latest.iloc[0]["Rating"], "BB+")
        self.assertEqual(
            engine_module.rating_class_conflicts(previous, latest), ()
        )

    def test_a_downgrade_to_nr_is_not_hidden(self):
        previous = self._frame("AAA", "IG")
        latest = self._frame("NR", "NR")
        engine_module.align_snapshot_labels(previous, latest)
        self.assertEqual(previous.iloc[0]["Rating Bucket"], "NR")
        self.assertEqual(latest.iloc[0]["Rating Bucket"], "NR")
        self.assertEqual(
            engine_module.rating_class_conflicts(previous, latest), ()
        )

    def test_an_mbs_row_does_not_inherit_a_previous_ig_value(self):
        previous = self._frame("AA+", "IG")
        latest = self._frame("NR", "NR")
        engine_module.align_snapshot_labels(previous, latest)
        self.assertNotEqual(previous.iloc[0]["Rating Bucket"], "IG")

    def test_conflicts_are_reported_when_alignment_is_skipped(self):
        # A guard, not a fix: if someone stops calling alignment, the check has
        # to say so instead of returning a clean result.
        previous = self._frame("AA+", "IG")
        latest = self._frame("BB+", "HY")
        self.assertEqual(
            engine_module.rating_class_conflicts(previous, latest), ("SAME",)
        )

    def test_vendor_text_survives_a_blank_only_within_the_same_class(self):
        # A numeric scale is still NR next month when the vendor blanks it, so
        # the number stays visible instead of showing (blank).
        previous = self._frame("24", "NR")
        latest = self._frame("(blank)", "NR")
        engine_module.align_snapshot_labels(previous, latest)
        self.assertEqual(latest.iloc[0]["Rating"], "24")
        self.assertEqual(latest.iloc[0]["Rating Bucket"], "NR")

    def test_an_ig_letter_is_never_borrowed_across_classifications(self):
        # Latest is NR, previous is IG: the text must not come back as AAA,
        # which would put an investment-grade letter beside an NR bucket.
        previous = self._frame("AAA", "IG")
        latest = self._frame("(blank)", "NR")
        engine_module.align_snapshot_labels(previous, latest)
        self.assertEqual(latest.iloc[0]["Rating Bucket"], "NR")
        self.assertNotEqual(latest.iloc[0]["Rating"], "AAA")
        self.assertNotEqual(previous.iloc[0]["Rating"], "AAA")


if __name__ == "__main__":
    unittest.main()
