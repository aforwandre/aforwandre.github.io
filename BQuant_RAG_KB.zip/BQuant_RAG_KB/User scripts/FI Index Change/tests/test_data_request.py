"""Request-semantics tests with a fake BQL service. No live BQL is executed.

These pin what the app actually asks Bloomberg for: one ``members()`` call per
effective date, ``id()['weights']`` as the weight source, cached mode, and no
cache write for the projected month. A silent change to any of those used to
pass the whole suite.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fi_index_change import data as data_module
from fi_index_change.data import _fetch_live, fetch_index_payload
from fi_index_change.field_library import ANALYTICS_NAMES, DURATION_FIELDS, ITEM_NAMES

BOND_ID = "B1 Corp"
WEIGHT = 7.5


class _Item:
    def __init__(self, name: str, frame: pd.DataFrame):
        self.name = name
        self._frame = frame

    def df(self) -> pd.DataFrame:
        return self._frame.copy()


class _FakeResponse:
    def __init__(self, items: list[_Item]):
        self._items = items

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, key):
        if isinstance(key, int):
            return self._items[key]
        for item in self._items:
            if item.name == key:
                return item
        raise KeyError(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default


def _item(name: str, value) -> _Item:
    frame = pd.DataFrame({name: [value]}, index=pd.Index([BOND_ID], name="ID"))
    return _Item(name, frame)


class _FakeData:
    """Every ``bq.data.<field>()`` returns one row for BOND_ID."""

    def __init__(self):
        self.fields: list[str] = []

    def __getattr__(self, name):
        if name == "id":
            return lambda: {"weights": _item("Weight", WEIGHT)}
        if name == "id_isin":
            return lambda: {"value": _item("ISIN", "US0000000001")}
        if name == "id_sedol1":
            return lambda: {"value": _item("SEDOL", "0000001")}

        def call(*args, **kwargs):
            self.fields.append(name)
            value = 1.0
            return _item(name, value)

        return call


class _DatedData(_FakeData):
    """``_FakeData`` whose analytics items each answer with their own ``DATE``.

    A live Desktop response attaches the price date to an analytics item and the
    dates are not guaranteed to agree. The older fake never produced a DATE
    column at all, so ``assertNotIn("DATE", frame.columns)`` in the split test
    could not fail and the 2026-11-02 merge defect was untested on that path.
    """

    def __init__(self):
        super().__init__()
        self.dates: list[pd.Timestamp] = []

    def __getattr__(self, name):
        call = super().__getattr__(name)
        if name in ("id", "id_isin", "id_sedol1"):
            return call

        def dated(*args, **kwargs):
            item = call(*args, **kwargs)
            real_df = item.df

            def df() -> pd.DataFrame:
                frame = real_df()
                offset = len(self.fields)  # a different date per item
                stamp = pd.Timestamp("2026-09-30") + pd.Timedelta(days=offset)
                frame["DATE"] = stamp
                self.dates.append(stamp)
                return frame

            item.df = df
            return item

        return dated


class _FakeUniverse:
    def __init__(self):
        self.calls: list[tuple] = []

    def members(self, ticker, dates=None):
        self.calls.append((ticker, dates))
        return f"members({ticker}, {dates})"

class _FakeService:
    def __init__(self):
        self.data = _FakeData()
        self.univ = _FakeUniverse()
        self.executed: list[dict] = []

    def execute(self, request):
        self.executed.append(request)
        # ``bql.Request`` names each response item after its dict key, so the
        # fake does the same instead of exposing the field method name.
        items = []
        for output_name, item in request["items"].items():
            frame = item.df()
            if len(frame.columns) == 1:
                frame.columns = [output_name]
            items.append(_Item(output_name, frame))
        return _FakeResponse(items)


class _FakeBqlModule:
    def __init__(self):
        self.service = _FakeService()

    def Service(self):
        return self.service

    @staticmethod
    def Request(universe, items, with_params=None):
        return {"universe": universe, "items": items, "with_params": with_params}


class RequestSemanticsTests(unittest.TestCase):
    def setUp(self):
        self.bql_module = _FakeBqlModule()
        self._original_bql = data_module.bql
        data_module.bql = self.bql_module

    def tearDown(self):
        data_module.bql = self._original_bql

    def test_one_members_call_per_date_with_the_cached_request(self):
        bql_module = self.bql_module
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            bql_module.service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        # One universe per request, and a split date sends one identity request
        # plus one per analytics group. Every call names the same ticker and
        # the same date, and none of them reaches the network twice for the
        # same group.
        self.assertTrue(bql_module.service.univ.calls)
        self.assertEqual(
            set(bql_module.service.univ.calls),
            {("LEGATRUU Index", "2026-09-30")},
        )
        self.assertEqual(len(bql_module.service.executed), 3)
        requests = bql_module.service.executed
        self.assertTrue(all(value["with_params"] == {"mode": "cached"} for value in requests))
        # The three requests partition the item set: identity, spreads+yields,
        # durations. Nothing is requested twice and nothing is left out.
        sent = [set(value["items"]) for value in requests]
        self.assertEqual(len(set().union(*sent)), len(ITEM_NAMES))
        self.assertEqual(sum(len(part) for part in sent), len(ITEM_NAMES))
        self.assertEqual(errors, [])
        self.assertEqual(frame["Weight"].tolist(), [WEIGHT])
        self.assertTrue(cache_ok)
        self.assertFalse(any("did not parse" in note for note in notes), notes)

    def test_weight_comes_from_the_id_weights_accessor(self):
        frame, _cache_ok = _fetch_live(
            self.bql_module.service, "LEGATRUU Index", "2026-09-30", [], []
        )
        self.assertEqual(frame["Weight"].tolist(), [WEIGHT])

    def test_projected_month_is_not_written_to_the_cache(self):
        bql_module = self.bql_module
        with patch.object(data_module, "load_historical", return_value=None), patch.object(
            data_module, "save_historical"
        ) as save_mock:
            payload = fetch_index_payload(
                "LEGATRUU Index",
                "2026-10-30",
                today=pd.Timestamp("2026-10-15"),
            )
        self.assertEqual(payload.kind, "projected")
        self.assertEqual(payload.previous_date, "2026-09-30")
        self.assertEqual(payload.selected_date, "2026-10-30")
        self.assertEqual(payload.statuses["2026-09-30"], "ok")
        self.assertEqual(payload.statuses["2026-10-30"], "ok")
        save_mock.assert_called_once()
        self.assertEqual(save_mock.call_args.args[1], "2026-09-30")
        # A split date sends one identity request plus one per analytics group,
        # so the count is no longer one per date. What must hold is that every
        # universe call names one of the two dates and that both were asked
        # for: the projected month is requested, just never written to cache.
        dates = [date for _ticker, date in bql_module.service.univ.calls]
        self.assertEqual(set(dates), {"2026-09-30", "2026-10-30"})
        self.assertTrue(
            all(ticker == "LEGATRUU Index" for ticker, _date in bql_module.service.univ.calls)
        )


class _DropItemService(_FakeService):
    """A response that silently leaves one requested item out."""

    def __init__(self, drop: str):
        super().__init__()
        self.drop = drop

    def execute(self, request):
        self.executed.append(request)
        items = []
        for output_name, item in request["items"].items():
            if output_name == self.drop:
                continue
            frame = item.df()
            if len(frame.columns) == 1:
                frame.columns = [output_name]
            items.append(_Item(output_name, frame))
        return _FakeResponse(items)


class BuildFailureTests(unittest.TestCase):
    """A rejected item is reported once, with no automatic retry.

    ``Market Value`` used to be optional, and any failure retried the same
    request without it. It was removed on 2026-11-02, so nothing is optional:
    the retry only bought a second timed-out query.
    """

    def setUp(self):
        self.bql_module = _FakeBqlModule()
        self._original_bql = data_module.bql
        data_module.bql = self.bql_module

    def tearDown(self):
        data_module.bql = self._original_bql

    def test_item_build_failure_reports_once_and_never_executes(self):
        class _NoRatingData(_FakeData):
            def __getattr__(self, name):
                if name == "rating":
                    raise RuntimeError("not entitled")
                return super().__getattr__(name)

        service = self.bql_module.service
        service.data = _NoRatingData()
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        self.assertTrue(frame.empty)
        self.assertFalse(cache_ok)
        self.assertEqual(len(errors), 1)
        self.assertIn("Rating", errors[0])
        self.assertEqual(notes, [])
        # A build failure never reaches the two-minute query.
        self.assertEqual(service.executed, [])

    def test_a_timeout_is_retried_once_and_succeeds_on_the_warm_cache(self):
        """The operator's recovery is the default, not a manual second click."""

        class _WarmAfterTimeout(_FakeService):
            attempts = 0

            def execute(self, request):
                type(self).attempts += 1
                if type(self).attempts == 1:
                    raise RuntimeError(
                        "[BQLTimeoutError] - The query took too long to complete."
                    )
                return super().execute(request)

        _WarmAfterTimeout.attempts = 0
        service = _WarmAfterTimeout()
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        self.assertFalse(frame.empty)
        self.assertTrue(cache_ok)
        for name in ITEM_NAMES:
            self.assertIn(name, frame.columns)
        # The first request times out and is retried unchanged, then the two
        # analytics groups follow: 4 executes, not 2. What matters is that the
        # timeout cost exactly one retry and dropped nothing, so the frame is
        # complete and cacheable.
        self.assertEqual(_WarmAfterTimeout.attempts, 4)
        self.assertEqual(errors, [])
        self.assertTrue(any("answered on attempt 2" in note for note in notes))
        self.assertTrue(any("Retrying the same" in note for note in notes))

    def test_every_attempt_failing_is_reported_once_with_both_timings(self):
        class _AlwaysTimeout(_FakeService):
            attempts = 0

            def execute(self, request):
                type(self).attempts += 1
                raise RuntimeError("[BQLTimeoutError] - The query took too long to complete.")

        _AlwaysTimeout.attempts = 0
        service = _AlwaysTimeout()
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        self.assertTrue(frame.empty)
        self.assertFalse(cache_ok)
        self.assertEqual(_AlwaysTimeout.attempts, 2)
        self.assertTrue(any("BQLTimeoutError" in message for message in errors))
        self.assertTrue(any("all 2 attempts failed" in message for message in errors))

    def test_a_deterministic_failure_is_not_retried(self):
        """A refused request can never answer, so a second attempt is waste."""

        class _RefusedService(_FakeService):
            attempts = 0

            def execute(self, request):
                type(self).attempts += 1
                raise RuntimeError("ItemBuilderError: No BQL data item named 'nope'")

        _RefusedService.attempts = 0
        service = _RefusedService()
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        self.assertTrue(frame.empty)
        self.assertFalse(cache_ok)
        self.assertEqual(_RefusedService.attempts, 1)
        self.assertEqual(len(errors), 1)
        self.assertEqual(notes, [])

    def test_split_identity_request_does_not_build_analytics_items(self):
        class _NoSpreadData(_FakeData):
            def __getattr__(self, name):
                if name == "spread":
                    raise RuntimeError("not entitled")
                return super().__getattr__(name)

        service = self.bql_module.service
        service.data = _NoSpreadData()
        errors: list[str] = []
        notes: list[str] = []
        with patch.object(data_module, "SPLIT_REQUESTS", True):
            frame, cache_ok = _fetch_live(
                service, "LEGATRUU Index", "2026-09-30", errors, notes
            )
        self.assertFalse(frame.empty)
        self.assertFalse(cache_ok)
        # Identity still goes out, and the group whose builder is missing is
        # skipped without taking the other group down with it: 2 executes, the
        # identity one plus the duration group.
        self.assertEqual(len(service.executed), 2)
        self.assertIn("Weight", service.executed[0]["items"])
        self.assertNotIn("OAS", service.executed[0]["items"])
        self.assertTrue(any("analytics 1" in error for error in errors), errors)
        # The refusal is reported, so it can never be mistaken for a blank field.
        self.assertTrue(any("measure group" in note for note in notes), notes)

    def test_a_failed_group_keeps_the_rest_and_refuses_the_cache(self):
        """A timed-out duration request must not cost the whole month."""

        class _DurationTimeout(_FakeService):
            def execute(self, request):
                if "OASD" in request["items"]:
                    raise RuntimeError(
                        "[BQLTimeoutError] - The query took too long to complete."
                    )
                return super().execute(request)

        service = _DurationTimeout()
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        # The month is usable: identity, spreads and yields all arrived.
        self.assertFalse(frame.empty)
        self.assertEqual(frame["Weight"].tolist(), [WEIGHT])
        for name in ("OAS", "Z-Spread", "I-Spread", "Yield", "YTM", "YTW"):
            self.assertIn(name, frame.columns)
        # The duration family is absent, and that absence is stated, not blank.
        for name in DURATION_FIELDS:
            self.assertNotIn(name, frame.columns)
        self.assertTrue(any("measure group" in note for note in notes), notes)
        self.assertTrue(any("OASD" in note for note in notes), notes)
        # Above all: the incomplete month is never cached, or the next Update
        # would read it back and never retry the family that timed out.
        self.assertFalse(cache_ok)

    def test_split_happy_path_sends_two_requests_and_merges_on_id(self):
        """Two executes per date, merged on ``ID`` alone.

        Identity arrives first (it carries Weight and no analytics), analytics
        second, and the merged frame is cacheable because every identity column
        and Weight survived.

        The analytics items here each carry a different ``DATE``, which is what
        a live response does. Merging on ``["ID", "DATE"]`` turned one row per
        security into one row per security per date and blanked every column
        that arrived without a date, so the DATE column has to be present in
        this test for the assertion to mean anything.
        """
        service = self.bql_module.service
        service.data = _DatedData()
        errors: list[str] = []
        notes: list[str] = []
        with patch.object(data_module, "SPLIT_REQUESTS", True):
            frame, cache_ok = _fetch_live(
                service, "LEGATRUU Index", "2026-09-30", errors, notes
            )
        self.assertEqual(errors, [])
        self.assertEqual(len(service.executed), 3)
        identity_items = service.executed[0]["items"]
        # The two analytics groups in ``ANALYTICS_GROUPS`` order, after the
        # identity request. Their union is exactly the analytics set.
        analytics_items = [set(value["items"]) for value in service.executed[1:]]
        self.assertIn("Weight", identity_items)
        self.assertNotIn("OAS", identity_items)
        self.assertEqual(set().union(*analytics_items), set(ANALYTICS_NAMES))
        self.assertEqual(
            sum(len(part) for part in analytics_items), len(ANALYTICS_NAMES)
        )
        # The fake really did deliver DATE columns, so the next assertion tests
        # the merge instead of passing on an empty set.
        self.assertGreater(len(service.data.dates), 1)
        self.assertGreater(len(set(service.data.dates)), 1)
        # One row per security, not one per item, and no DATE key survived.
        self.assertFalse(frame["ID"].duplicated().any())
        self.assertNotIn("DATE", frame.columns)
        for name in ITEM_NAMES:
            self.assertIn(name, frame.columns)
        # A column that arrived only on the identity request must not be
        # blanked by the merge, and an analytics column must keep its value.
        self.assertEqual(frame["Country"].nunique(), 1)
        self.assertEqual(str(frame["Country"].iloc[0]), "1.0")
        self.assertTrue(frame["OAS"].notna().all())
        self.assertTrue(frame["Weight"].notna().any())
        self.assertTrue(cache_ok)

    def test_split_does_not_drop_a_value_when_the_analytics_repeat_an_id(self):
        """``keep="last"`` used to be able to keep the row where the value is null."""
        service = self.bql_module.service
        errors: list[str] = []
        notes: list[str] = []
        original_spread = service.data.spread

        def repeated(*args, **kwargs):
            item = original_spread(*args, **kwargs)
            real_df = item.df
            # Two rows for the same security, as an item can answer with when
            # it reports one row per revision date.
            item.df = lambda: pd.concat([real_df(), real_df()])
            # No ``ignore_index``: the ID is the index, so resetting it would
            # destroy the security identity instead of repeating it.
            return item

        service.data.spread = repeated
        with patch.object(data_module, "SPLIT_REQUESTS", True):
            frame, _cache_ok = _fetch_live(
                service, "LEGATRUU Index", "2026-09-30", errors, notes
            )
        self.assertFalse(frame["ID"].duplicated().any())
        self.assertFalse(frame["OAS"].isna().all(), "OAS values were blanked by the collapse")


class PartialResponseCacheTests(unittest.TestCase):
    """A response that dropped a required item must not be cached."""

    def setUp(self):
        self.bql_module = _FakeBqlModule()
        self._original_bql = data_module.bql
        data_module.bql = self.bql_module

    def tearDown(self):
        data_module.bql = self._original_bql

    def test_missing_required_item_reports_cache_unsafe(self):
        self.bql_module.service = _DropItemService("Rating")
        errors: list[str] = []
        notes: list[str] = []
        frame, cache_ok = _fetch_live(
            self.bql_module.service, "LEGATRUU Index", "2026-09-30", errors, notes
        )
        self.assertFalse(frame.empty)
        self.assertFalse(cache_ok)
        self.assertTrue(
            any("Rating" in note for note in notes),
            f"the dropped item is not named in any note: {notes}",
        )
        self.assertEqual(errors, [])

    def test_payload_refuses_to_cache_the_partial_month(self):
        self.bql_module.service = _DropItemService("Rating")
        with patch.object(data_module, "load_historical", return_value=None), patch.object(
            data_module, "save_historical"
        ) as save_mock:
            payload = fetch_index_payload(
                "LEGATRUU Index",
                "2026-10-30",
                today=pd.Timestamp("2026-10-15"),
            )
        save_mock.assert_not_called()
        self.assertTrue(
            any("was not written to the cache" in note for note in payload.notes),
            payload.notes,
        )


if __name__ == "__main__":
    unittest.main()
