"""Local widget-stub tests for FIIndexChangeApp. No BQL is executed.

``ipywidgets`` and ``plotly`` do not exist on the authoring machine, so this
module installs permissive stand-ins and then imports the real app. The point
is not pixel output: it is the controller lifecycle that the static grep tests
cannot see (construction, a successful Update, and a failed Update).
"""

from __future__ import annotations

import io
import sys
import types
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch

import pandas as pd

ROOT = __import__("pathlib").Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


from widget_stubs import install as _install_widget_stubs, _Node  # noqa: E402

_install_widget_stubs()


from fi_index_change import app as app_module  # noqa: E402
from fi_index_change.data import IndexPayload  # noqa: E402
from fi_index_change.engine import Comparison, prepare_members  # noqa: E402


def _snapshot(rows: list[dict]) -> pd.DataFrame:
    frame = prepare_members(pd.DataFrame(rows), [])
    frame["AS_OF_DATE"] = "2026-09-30"
    frame["SNAPSHOT_KIND"] = "historical"
    return frame


def _payload() -> IndexPayload:
    previous = _snapshot(
        [
            {"ID": "OLD Corp", "Weight": 60.0, "Name": "Old", "Country": "UNITED STATES",
             "Sector": "GOVT", "Rating": "AA", "Currency": "USD", "Tenor": 5.0},
        ]
    )
    latest = _snapshot(
        [
            {"ID": "NEW Corp", "Weight": 40.0, "Name": "New", "Country": "JAPAN",
             "Sector": "GOVT", "Rating": "A", "Currency": "JPY", "Tenor": 7.0},
        ]
    )
    payload = IndexPayload(
        index_ticker="LEGATRUU Index",
        previous_date="2026-08-31",
        selected_date="2026-09-30",
        kind="historical",
    )
    payload.snapshots = {"2026-08-31": previous, "2026-09-30": latest}
    payload.statuses = {"2026-08-31": "ok", "2026-09-30": "ok"}
    return payload


class PinnedFirstColumnTests(unittest.TestCase):
    """The Main tab keeps its first column visible while scrolling sideways."""

    def _view(self):
        return pd.DataFrame(
            {
                "Country": ["United States", "Japan", "(blank)"],
                "Begin Weight": [1.0, 2.0, 3.0],
                "End Weight": [1.5, 2.0, 2.5],
            }
        )

    def _detail_view(self):
        return pd.DataFrame(
            {
                "Action": ["Add", "Exit"],
                "ID": ["A1", "B2"],
                "Name": ["Alpha", "Beta"],
                "Weight": [1.0, 2.0],
            }
        )

    def test_first_column_moves_into_the_row_header(self):
        body, gutter = app_module._pinned_view(self._view())
        self.assertIsNotNone(gutter)
        self.assertEqual(body.index.name, "Country")
        self.assertEqual(list(body.index), ["United States", "Japan", "(blank)"])
        self.assertEqual(list(body.columns), ["Begin Weight", "End Weight"])

    def test_a_named_column_can_be_pinned_instead_of_the_first(self):
        view = pd.DataFrame(
            {
                "Action": ["Add", "Exit", "Add"],
                "ID": ["AB123Mtge", "US912828ZZZ", "XS1234567890"],
                "Name": ["A", "B", "C"],
                "Weight": [1.0, 2.0, 3.0],
            }
        )
        body, gutter = app_module._pinned_view(view, "ID", 300)
        self.assertIsNotNone(gutter)
        self.assertEqual(body.index.name, "ID")
        self.assertEqual(list(body.index), ["AB123Mtge", "US912828ZZZ", "XS1234567890"])
        # Column order is preserved, only the pinned column is removed.
        self.assertEqual(list(body.columns), ["Action", "Name", "Weight"])
        self.assertGreater(gutter, 0)

    def test_unknown_pin_column_falls_back_to_the_first(self):
        body, _gutter = app_module._pinned_view(self._view(), "NotAColumn")
        self.assertEqual(body.index.name, "Country")

    def test_duplicate_labels_are_allowed_but_not_chosen(self):
        """Action repeats, so it identifies nothing: the detail table pins ID."""
        view = pd.DataFrame(
            {"Action": ["Add", "Exit", "Add"], "ID": ["A1", "B2", "C3"], "Weight": [1.0, 2.0, 3.0]}
        )
        _body, _gutter = app_module._pinned_view(view, "Action", 220)
        body, _gutter = app_module._pinned_view(view, "ID", 300)
        self.assertEqual(list(body.index), ["A1", "B2", "C3"])
        self.assertEqual(len(set(body.index)), 3)

    def test_gutter_is_wide_enough_for_the_labels(self):
        _body, gutter = app_module._pinned_view(self._view())
        self.assertGreaterEqual(gutter, 80)
        self.assertLessEqual(gutter, 220)
        narrow, narrow_gutter = app_module._pinned_view(
            pd.DataFrame({"Tenor Bucket": ["<1Y", "1-3Y"], "Begin Weight": [1.0, 2.0]})
        )
        self.assertLess(narrow_gutter, gutter)
        self.assertEqual(narrow.index.name, "Tenor Bucket")

    def test_detail_gutter_allows_a_long_yellow_key(self):
        """A 29-character ID needs 260 px, which the summary cap would cut."""
        long_id = "XS123456789012345678901234567"
        view = pd.DataFrame({"Action": ["Add"], "ID": [long_id], "Weight": [1.0]})
        _body, summary_cap = app_module._pinned_view(view, "ID", 220)
        _body, detail_cap = app_module._pinned_view(view, "ID", 300)
        self.assertEqual(len(long_id), 29)
        self.assertEqual(summary_cap, 220)
        self.assertEqual(detail_cap, 260)
        self.assertGreater(detail_cap, summary_cap)

    def test_single_column_and_empty_frames_are_not_pinned(self):
        for view in (
            pd.DataFrame({"Message": ["No rows"]}),
            pd.DataFrame({"Only": []}),
            pd.DataFrame(),
        ):
            body, gutter = app_module._pinned_view(view)
            self.assertIsNone(gutter)
            self.assertEqual(list(body.columns), list(view.columns))

    def test_blank_labels_do_not_become_nan_index_entries(self):
        body, _gutter = app_module._pinned_view(
            pd.DataFrame({"Sector": [None, "GOVT"], "Begin Weight": [1.0, 2.0]})
        )
        self.assertEqual(list(body.index), ["", "GOVT"])

    def test_pin_switch_off_restores_the_scrolling_column(self):
        with patch.object(app_module, "PIN_FIRST_COLUMN", False):
            body, gutter = app_module._pinned_view(self._view())
        self.assertIsNone(gutter)
        self.assertEqual(list(body.columns), ["Country", "Begin Weight", "End Weight"])

    def test_grid_gets_the_pinned_frame_and_a_wide_gutter(self):
        """DataGrid must receive the pinned frame, body widths only, and a gutter."""
        captured = {}

        class _Grid:
            base_row_header_size = 64
            header_visibility = "all"

            def __init__(self, frame, **kwargs):
                captured["frame"] = frame
                captured["kwargs"] = kwargs

            def observe(self, *args, **kwargs):
                return None

        box = _Node()
        with patch.object(app_module, "DataGrid", _Grid):
            app_module.FIIndexChangeApp._put_grid(
                object(),
                box,
                self._view(),
                ("Country", "Begin Weight", "End Weight"),
                "summary",
            )
        frame = captured["frame"]
        self.assertEqual(frame.index.name, "Country")
        self.assertEqual(list(frame.columns), ["Begin Weight", "End Weight"])
        self.assertEqual(
            set(captured["kwargs"]["column_widths"]), {"Begin Weight", "End Weight"}
        )
        # "United States" is 13 characters: 13 * 8 + 28 = 132 px.
        self.assertEqual(captured["kwargs"]["base_row_header_size"], 132)
        # The pinned column lives in the row header, so it must stay visible.
        self.assertEqual(captured["kwargs"]["header_visibility"], "all")
        self.assertIs(box.children[0].__class__, _Grid)

    def test_detail_grid_pins_the_id_column(self):
        captured = {}

        class _Grid:
            base_row_header_size = 64
            header_visibility = "all"

            def __init__(self, frame, **kwargs):
                captured["frame"] = frame
                captured["kwargs"] = kwargs

            def observe(self, *args, **kwargs):
                return None

        box = _Node()
        columns = ("Action", "ID", "Name", "Weight")
        with patch.object(app_module, "DataGrid", _Grid):
            app_module.FIIndexChangeApp._put_grid(
                object(), box, self._detail_view(), columns, "detail"
            )
        frame = captured["frame"]
        self.assertEqual(frame.index.name, "ID")
        self.assertEqual(list(frame.index), ["A1", "B2"])
        self.assertEqual(list(frame.columns), ["Action", "Name", "Weight"])
        self.assertEqual(
            set(captured["kwargs"]["column_widths"]), {"Action", "Name", "Weight"}
        )

    def test_a_library_without_the_gutter_trait_is_not_half_pinned(self):
        """Silently ignoring the gutter would cut the label, so keep all columns."""
        captured = {}

        class _OldGrid:
            def __init__(self, frame, **kwargs):
                captured["frame"] = frame
                captured["kwargs"] = kwargs

            def observe(self, *args, **kwargs):
                return None

        box = _Node()
        with patch.object(app_module, "DataGrid", _OldGrid):
            app_module.FIIndexChangeApp._put_grid(
                object(),
                box,
                self._view(),
                ("Country", "Begin Weight", "End Weight"),
                "summary",
            )
        frame = captured["frame"]
        self.assertEqual(
            list(frame.columns), ["Country", "Begin Weight", "End Weight"]
        )
        self.assertNotIn("base_row_header_size", captured["kwargs"])
        self.assertNotIn("header_visibility", captured["kwargs"])
        self.assertEqual(
            set(captured["kwargs"]["column_widths"]),
            {"Country", "Begin Weight", "End Weight"},
        )

    def _column_owner(self, spreads=("OAS",), durations=("Modified Duration",), yields=("YTM",)):
        class _Owner:
            def _current_spreads(self):
                return list(spreads)

            def _current_durations(self):
                return list(durations)

            def _current_yields(self):
                return list(yields)

        return _Owner()

    def test_detail_columns_derived_from_the_constant(self):
        """One list drives both the app and the preview."""
        from fi_index_change.app import DETAIL_LIST_COLUMNS

        columns = app_module.FIIndexChangeApp._detail_list_columns(self._column_owner())
        self.assertEqual(columns[:4], tuple(DETAIL_LIST_COLUMNS[:4]))
        self.assertEqual(columns[-4:], tuple(DETAIL_LIST_COLUMNS[4:]))
        # The analytics blocks sit after Weight, the same anchor the page uses.
        self.assertEqual(columns[3], "Weight")
        self.assertEqual(columns[4], "OAS")
        self.assertIn("Country", columns)

    def test_detail_columns_follow_the_constant_when_it_changes(self):
        with patch.object(
            app_module, "DETAIL_LIST_COLUMNS", ("Action", "ID", "Weight", "Issuer", "Country")
        ):
            columns = app_module.FIIndexChangeApp._detail_list_columns(self._column_owner())
        self.assertEqual(columns[0], "Action")
        self.assertEqual(columns[2], "Weight")
        self.assertIn("Issuer", columns)
        self.assertIn("Country", columns)
        # Issuer sits after the analytics block, still after Weight.
        self.assertLess(columns.index("Weight"), columns.index("Issuer"))

    def test_row_header_click_opens_the_row(self):
        """The pinned column is the row header, so clicking it must work."""
        captured = {}

        class _Grid:
            base_row_header_size = 64
            header_visibility = "all"

            def __init__(self, frame, **kwargs):
                captured["frame"] = frame

            def on_cell_click(self, handler):
                captured["handler"] = handler

            def observe(self, *args, **kwargs):
                return None

        picked = []

        class _Owner:
            def _show_picked_row(self, row_index, role, source):
                picked.append((row_index, role, len(source)))

        box = _Node()
        with patch.object(app_module, "DataGrid", _Grid):
            app_module.FIIndexChangeApp._put_grid(
                _Owner(), box, self._view(), ("Country", "Begin Weight", "End Weight"), "summary"
            )
        handler = captured["handler"]
        handler({"region": "row-header", "primary_key_row": 2, "row": 0})
        self.assertEqual(picked, [(2, "summary", 3)])
        handler({"region": "column-header", "primary_key_row": 0})
        handler({"region": "corner-header", "primary_key_row": 0})
        self.assertEqual(len(picked), 1)

    def test_html_fallback_table_freezes_the_first_column(self):
        """Without ipydatagrid the table is HTML, so the pin is CSS."""
        box = _Node()
        app_module.FIIndexChangeApp._put_grid(
            object(), box, self._view(), ("Country", "Begin Weight", "End Weight"), "summary"
        )
        markup = box.children[0].value
        self.assertIn("table.fit td:first-child{position:sticky;left:0", markup)
        self.assertIn("background:#fff", markup)
        self.assertIn("United States</td>", markup)


class AppLifecycleTests(unittest.TestCase):
    def _build(self):
        with patch.object(app_module, "fetch_index_payload") as payload_mock, patch.object(
            app_module, "fetch_index_long_name", return_value="LEGATRUU Index"
        ) as name_mock:
            app = app_module.FIIndexChangeApp()
        return app, payload_mock, name_mock

    def test_construction_issues_no_membership_request(self):
        """The default yellow key may look its title up; members must wait for Update."""
        _app, payload_mock, name_mock = self._build()
        payload_mock.assert_not_called()
        name_mock.assert_called_once_with("LEGATRUU Index")

    def test_first_successful_update_renders(self):
        """Catches the uninitialised _export_key that broke the first Update."""
        app, _payload_mock, _name_mock = self._build()
        with patch.object(app_module, "fetch_index_payload", return_value=_payload()), patch.object(
            app_module,
            "comparison_for",
            return_value=Comparison("2026-08-31", "2026-09-30", "historical"),
        ), redirect_stdout(io.StringIO()):
            app._on_update(None)
        self.assertEqual(app.transition.status, "ok")
        self.assertIn("Updated", app.status.value)
        self.assertNotIn("Error", app.status.value)

    def test_first_successful_update_fills_the_export_tabs(self):
        """A render that forgets _refresh_export_tables leaves both tabs empty."""
        app, _payload_mock, _name_mock = self._build()
        with patch.object(app_module, "fetch_index_payload", return_value=_payload()), patch.object(
            app_module,
            "comparison_for",
            return_value=Comparison("2026-08-31", "2026-09-30", "historical"),
        ), redirect_stdout(io.StringIO()):
            app._on_update(None)
        self.assertEqual(set(app._export_frames), {"changes", "summary"})
        changes = app._export_frames["changes"]
        summary = app._export_frames["summary"]
        self.assertFalse(changes.empty)
        self.assertFalse(summary.empty)
        self.assertIn("Weight", changes.columns)
        self.assertEqual(
            list(changes.columns).index("Weight"),
            list(changes.columns).index("Sector") + 1,
            "Weight must sit right after Sector in the changes export",
        )
        self.assertIn("Add Weight", summary.columns)
        self.assertIn("Exit Weight", summary.columns)

    def test_failed_update_clears_the_previous_screen(self):
        app, _payload_mock, _name_mock = self._build()
        with patch.object(app_module, "fetch_index_payload", side_effect=RuntimeError("boom")), redirect_stdout(
            io.StringIO()
        ):
            app._on_update(None)
        self.assertIsNone(app.payload)
        self.assertIsNone(app.transition)
        self.assertIn("Error", app.status.value)


if __name__ == "__main__":
    unittest.main()
