"""Static contract checks for app.py. The widget runtime only exists on Desktop.

These are regression guards for three operator requests:
1. A status refresh must never leave the lower panels unbound.
2. The bond detail fields render below the bond table, not above it.
3. The footnotes carry the loaded as-of dates instead of a static blob.
"""

from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "fi_index_change" / "app.py").read_text(encoding="utf-8")


def method_body(name: str) -> str:
    """Return one method source block, from ``def name(`` to the next method."""
    start = SOURCE.index(f"    def {name}(")
    following = SOURCE.find("\n    def ", start + 1)
    return SOURCE[start:] if following < 0 else SOURCE[start:following]


class AppContractTests(unittest.TestCase):
    def test_render_rebinds_events(self):
        body = method_body("render")
        self.assertIn("self._bind_events()", body)
        self.assertLess(body.index("self._bind_events()"), body.index("widgets.HBox("))

    def test_bond_detail_sits_below_the_bond_table(self):
        body = method_body("render")
        table_at = body.index("self.detail_bonds_box")
        fields_at = body.index("self.detail_fields")
        self.assertLess(table_at, fields_at)
        self.assertGreater(fields_at, body.index("self.detail_chart"))

    def test_bucket_click_clears_the_bond_fields(self):
        self.assertIn('self.detail_fields.value = ""', method_body("_show_bucket"))

    def test_bond_click_fills_the_fields_below(self):
        body = method_body("_show_bond")
        self.assertIn("self._field_table(", body)
        self.assertIn("self._current_spreads(),", body)
        # The short note stays above the table so the grid does not move.
        self.assertIn("self.detail_table.value = f\"Bond detail is below the table:", body)

    def test_status_refresh_never_disables_widgets(self):
        body = method_body("_set_status")
        self.assertNotIn("disabled", body)
        self.assertNotIn("children", body)
        self.assertIn("self.status.value", body)

    def test_footnotes_are_dynamic(self):
        self.assertNotIn("CAPTION_TEXT", SOURCE)
        self.assertIn("from .engine import (", SOURCE)
        self.assertIn("caption_html(", SOURCE)
        update = method_body("_on_update")
        self.assertIn("self._refresh_caption()", update)
        self.assertLess(update.index("self.payload = fetch_index_payload("), update.index("self._refresh_caption()"))

    def test_detail_summary_and_top10_chart(self):
        body = method_body("_show_bucket")
        self.assertIn("top_add_exit_rows(", body)
        self.assertIn('add_word = "add" if add_count == 1 else "adds"', body)
        self.assertIn("Add weight", body)
        self.assertIn("Exit weight", body)
        self.assertIn("Net weight", body)
        chart = method_body("_chart_weights")
        self.assertIn("self.detail_figure.layout.height", chart)
        self.assertNotIn('f"{action} {name}"', chart)
        self.assertIn('for name in ordered.get("Name"', chart)

    def test_section_titles_are_larger_but_below_the_app_title(self):
        self.assertIn("font-size:16px", SOURCE)
        self.assertIn("<b style='font-size:16px'>Bucket summary</b>", SOURCE)
        self.assertIn("TITLE_HTML", SOURCE)
        self.assertNotIn("font-size:20px", SOURCE.split("TITLE_HTML", 1)[1].split("</p>", 1)[1])

    def test_spread_dropdown_drives_lower_tables_and_keeps_all_exports(self):
        self.assertIn('SPREAD_OPTIONS = ("OAS", "Z-Spread", "I-Spread")', SOURCE)
        build = method_body("_build_widgets")
        self.assertIn("SPREAD_LABELS.get(option, option)", build)
        self.assertIn('description="Spread"', build)
        self.assertIn("self.spread_select.observe", SOURCE)
        render = method_body("_render")
        self.assertIn("self._summary_columns(summary, spreads, durations, yields)", render)
        self.assertIn("self._headline_html(\n                transition, headline, book, filters, spreads, durations, yields\n            )", render)
        self.assertIn('"Z-Spread",\n    "I-Spread"', SOURCE)
        self.assertIn("self._detail_list_columns()", method_body("_show_bucket"))
        for field in ("OAS", "Z-Spread", "I-Spread"):
            self.assertIn(field, SOURCE)
        self.assertIn("f\"Begin {field}\"", method_body("_summary_columns"))

    def test_duration_and_yield_selection_boxes(self):
        self.assertIn("DURATION_FIELDS = (", SOURCE)
        self.assertIn("YIELD_FIELDS = (", SOURCE)
        self.assertIn('"OASD": "Option adjusted spread duration"', SOURCE)
        self.assertIn('"YTM": "Yield to maturity"', SOURCE)
        build = method_body("_build_widgets")
        self.assertIn("self.duration_select = widgets.SelectMultiple(", build)
        self.assertIn("self.yield_select = widgets.SelectMultiple(", build)
        self.assertIn("DURATION_LABELS.get(option, option)", build)
        self.assertIn("YIELD_LABELS.get(option, option)", build)
        self.assertIn("self.duration_select.observe", SOURCE)
        self.assertIn("self.yield_select.observe", SOURCE)
        render = method_body("_render")
        self.assertIn("durations = self._current_durations()", render)
        self.assertIn("yields = self._current_yields()", render)
        self.assertIn("self._summary_columns(summary, spreads, durations, yields)", render)
        self.assertIn("def _current_durations(self)", SOURCE)
        self.assertIn("def _current_yields(self)", SOURCE)
        self.assertIn("self._detail_list_columns()", method_body("_show_bucket"))

    def test_charts_use_the_filter_row_width(self):
        self.assertIn('CHART_WIDTH = f"{CHART_WIDTH_PX}px"', SOURCE)
        body = method_body("_build_widgets")
        self.assertEqual(body.count("width=CHART_WIDTH_PX"), 2)
        self.assertEqual(body.count("autosize=False"), 2)
        self.assertEqual(body.count("layout=widgets.Layout(width=CHART_WIDTH)"), 2)
        render = method_body("render")
        self.assertIn("self.dimension_chart", render)
        self.assertIn("self.detail_chart", render)

    def test_charts_are_transparent_with_light_text(self):
        body = method_body("_build_widgets")
        self.assertIn('paper_bgcolor="rgba(0,0,0,0)"', body)
        self.assertIn('plot_bgcolor="rgba(0,0,0,0)"', body)
        self.assertIn("CHART_FONT_COLOR", body)
        self.assertIn(".title.text", method_body("_render_dimension_chart"))
        self.assertIn(".title.text", method_body("_chart_weights"))

    def test_grid_only_receives_display_columns(self):
        body = method_body("_put_grid")
        self.assertIn("grid_display_frame(source, tuple(columns))", body)
        self.assertNotIn("view = _display_frame", body)

    def test_export_is_a_copy_table_tab(self):
        self.assertNotIn("export_button", SOURCE)
        self.assertNotIn("Export CSV", SOURCE)
        self.assertNotIn("to_csv", SOURCE)
        self.assertNotIn("Accordion", SOURCE)
        build = method_body("_build_widgets")
        self.assertIn("widgets.Tab(", build)
        self.assertIn('titles=("Main", "Export", "Full Position")', build)
        self.assertIn("POSITION_COLUMNS", SOURCE)
        self.assertIn("self._refresh_positions()", SOURCE)
        self.assertIn('description="Data"', build)
        self.assertIn('description="Date"', build)
        self.assertIn("_show_export_view", SOURCE)
        self.assertIn("_show_position_view", SOURCE)
        self.assertIn("export_display_frame", method_body("_put_export_grid"))
        render = method_body("render")
        self.assertIn("self.tabs.children = (main_tab, self.export_body, self.positions_body)", render)
        self.assertIn("widgets.VBox([widgets.HTML(TITLE_HTML), self.tabs])", render)

    def test_detail_list_applies_every_active_filter(self):
        body = method_body("_bucket_changes")
        self.assertIn("apply_dimension_filters", method_body("_filtered_changes"))
        self.assertIn("self._filtered_changes()", body)
        self.assertIn("apply_dimension_filters", SOURCE)
        self.assertIn("self._filtered_changes()", method_body("_show_bond"))

    def test_bucket_summary_defines_turnover_columns(self):
        render = method_body("render")
        self.assertIn("Turnover (index %)</b> = Exit Weight", render)
        self.assertIn("Turnover Rate (%)</b> = Turnover", render)
        self.assertIn("beginning index MV).<br>", render)
        self.assertIn("<b>Begin</b> = previous", render)
        self.assertIn("<b>End</b> = selected", render)
        self.assertIn("Begin Weight", render)

    def test_headline_states_its_interactive_scope(self):
        render = method_body("_render")
        self.assertIn("spreads, durations, yields", render)
        headline = method_body("_headline_html")
        self.assertIn("self._scope_line(book, filters)", headline)
        self.assertIn("The figures, Bucket summary, and charts below follow this scope", headline)
        scope = method_body("_scope_line")
        self.assertIn("FILTER_LABELS.get", scope)

    def test_full_book_lines_start_on_a_new_line(self):
        headline = method_body("_headline_html")
        self.assertIn(".<br>", headline)
        self.assertIn("Full book: Standard", headline)
        self.assertIn("As of ", headline)
        self.assertIn("<br>", headline)

    def test_turnover_is_wired_into_headline_and_transition(self):
        update = method_body("_on_update")
        self.assertIn("index_mv_ratio=self.payload.index_mv_ratio", update)
        self.assertIn("turnover_basis=self.payload.turnover_basis", update)
        self.assertIn("Monthly turnover", method_body("_headline_html"))

    def test_headline_is_a_bold_info_box(self):
        body = method_body("_headline_html")
        self.assertIn("_info_box(", body)
        self.assertIn('"ok"', body)
        self.assertIn('"warn"', body)
        self.assertIn("font-weight:700", SOURCE)
        self.assertIn("_info_box(", method_body("_show_failed_update"))
        self.assertIn("_info_box(", method_body("_show_license_failure"))

    def test_book_is_a_selection_box_after_currency(self):
        self.assertNotIn("book_input", SOURCE)
        build = method_body("_build_widgets")
        self.assertIn("self.book_select = widgets.SelectMultiple(", build)
        self.assertIn('options=[ALL_FILTER_LABEL, "Standard", "MBS/TBA"]', build)
        self.assertIn("[*self.filters.values(), self.spread_select, self.duration_select, self.yield_select, self.book_select]", method_body("render"))
        self.assertIn("def _current_book(self)", SOURCE)
        self.assertIn("self.book_select.value", method_body("_current_book"))

    def test_filter_boxes_use_the_shared_layout(self):
        body = method_body("_build_widgets")
        self.assertIn("rows=10", body)
        self.assertIn("FILTER_WIDTHS.get(label, 220)", body)
        self.assertIn('margin=f"0 {FILTER_GAP_PX}px 0 0"', body)

    def test_secondary_notes_live_near_their_controls(self):
        # Chart order on the axes, Begin/End under the bucket table,
        # export sign on the Export tooltip. None of it belongs in the caption.
        self.assertIn("Bucket summary order", SOURCE)
        self.assertIn("largest Add at top", SOURCE)
        self.assertIn("<b>Begin</b> = previous", SOURCE)
        self.assertEqual(SOURCE.count("Bucket summary order"), 1)
        self.assertEqual(SOURCE.count("largest Add at top"), 1)


if __name__ == "__main__":
    unittest.main()
