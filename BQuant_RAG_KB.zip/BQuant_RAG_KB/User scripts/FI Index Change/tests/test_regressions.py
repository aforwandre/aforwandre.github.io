"""Regression checks for the 2026-11-01 review findings.

Every case here failed before the fix. None of them touches BQL: the parser
tests use a fake response object and the cache tests use a temporary folder.
"""

from __future__ import annotations

import sys
import tempfile
import types
import unittest
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fi_index_change import data as data_module
from fi_index_change.cache import (
    CACHE_GENERATION,
    FIELD_CONTRACT,
    cache_dir,
    safe_name,
    load_historical,
    required_columns,
    save_historical,
)
from fi_index_change.data import (
    _item_frame,
    _merge_item_frames,
    _parse_response,
    _response_to_frame,
)
from fi_index_change.engine import prepare_members
from fi_index_change.field_library import DURATION_FIELDS, build_member_items


def _members(rows: list[dict]) -> pd.DataFrame:
    frame = pd.DataFrame(rows)
    return prepare_members(frame)


def _complete(rows: list[dict]) -> pd.DataFrame:
    """A prepared snapshot that carries every requested item column."""
    frame = _members(rows)
    for name in required_columns():
        if name not in frame.columns:
            frame[name] = None
    frame["AS_OF_DATE"] = "2026-09-30"
    frame["SNAPSHOT_KIND"] = "historical"
    return frame


def _mbs_frame() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "ID": ["AB123Mtge", "US912828ZZZ"],
            "Weight": [1.0, 2.0],
            "Security Type": ["MBS", "GOVT"],
            "Country": ["(blank)", "UNITED STATES"],
            "Sector": ["(blank)", "GOVT"],
            "Currency": ["(blank)", "USD"],
            "Rating": ["AAA", "AA"],
            "Tenor": [None, 5.0],
        }
    )


class PrepareIdempotencyTests(unittest.TestCase):
    def test_prepare_members_is_idempotent(self):
        """A second pass over its own output must not change any label."""
        first = prepare_members(_mbs_frame(), [])
        second = prepare_members(first.copy(), [])
        for column in ("Book", "Country", "Sector", "Rating", "Rating Bucket", "Tenor Bucket"):
            self.assertEqual(
                first[column].tolist(),
                second[column].tolist(),
                f"{column} changed on a second prepare_members pass",
            )

    def test_prepare_members_without_a_rating_column_is_idempotent(self):
        """No Rating column means NR stays NR, never a second bucket.

        The first pass fills Rating with RATING_MISSING, so the second pass
        reads it as a real value. NR_TOKENS has to accept it, or every cached
        reload would move those rows into another bucket.
        """
        frame = _mbs_frame().iloc[[1]].drop(columns=["Rating"])
        first = prepare_members(frame, [])
        self.assertEqual(set(first["Rating"]), {"NR"})
        self.assertEqual(set(first["Rating Bucket"]), {"NR"})
        second = prepare_members(first.copy(), [])
        self.assertEqual(set(second["Rating Bucket"]), {"NR"})
        self.assertEqual(
            first["Rating Bucket"].tolist(), second["Rating Bucket"].tolist()
        )

    def test_prepare_members_without_a_rating_column_keeps_mbs_nr(self):
        """The MBS/TBA row stays NR across a second prepare pass."""
        frame = _mbs_frame().drop(columns=["Rating"])
        first = prepare_members(frame, [])
        second = prepare_members(first.copy(), [])
        self.assertEqual(first["Rating"].tolist(), ["NR", "NR"])
        self.assertEqual(first["Rating"].tolist(), second["Rating"].tolist())
        self.assertEqual(first["Rating Bucket"].tolist(), ["NR", "NR"])
        self.assertEqual(
            first["Rating Bucket"].tolist(), second["Rating Bucket"].tolist()
        )

    def test_cached_reload_keeps_the_mbs_tba_label(self):
        """save -> load -> prepare must not turn MBS/TBA into Mbs/Tba."""
        frame = _complete(
            [
                {
                    "ID": "AB123Mtge",
                    "Weight": 1.0,
                    "Security Type": "MBS",
                    "Country": "(blank)",
                    "Sector": "(blank)",
                    "Currency": "(blank)",
                    "Rating": "AAA",
                }
            ]
        )
        self.assertEqual(frame.loc[0, "Country"], "MBS/TBA")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            save_historical("LEGATRUU Index", "2026-09-30", frame, root)
            loaded = load_historical("LEGATRUU Index", "2026-09-30", root)
            self.assertIsNotNone(loaded)
            reloaded = prepare_members(loaded, [])
        self.assertEqual(reloaded.loc[0, "Country"], "MBS/TBA")
        self.assertEqual(reloaded.loc[0, "Sector"], "MBS/TBA")
        self.assertEqual(reloaded.loc[0, "Book"], "MBS/TBA")


class MissingRatingTests(unittest.TestCase):
    def test_no_rating_column_classifies_every_row_nr(self):
        """IG, HY, NR only: an absent field and an MBS row are both NR."""
        frame = pd.DataFrame(
            {
                "ID": ["US912828ZZZ", "AB123Mtge"],
                "Weight": [10.0, 1.0],
                "Security Type": ["GOVT", "MBS"],
                "Country": ["UNITED STATES", "(blank)"],
                "Sector": ["GOVT", "(blank)"],
                "Currency": ["USD", "(blank)"],
            }
        )
        notes: list[str] = []
        out = prepare_members(frame, notes).set_index("ID")
        self.assertEqual(out.loc["US912828ZZZ", "Rating"], "NR")
        self.assertEqual(out.loc["US912828ZZZ", "Rating Bucket"], "NR")
        self.assertEqual(out.loc["AB123Mtge", "Rating"], "NR")
        self.assertEqual(out.loc["AB123Mtge", "Rating Bucket"], "NR")
        self.assertTrue(any("Rating column" in note for note in notes))


class BlankIdTests(unittest.TestCase):
    def test_blank_ids_are_reported(self):
        frame = pd.DataFrame(
            {
                "ID": ["A Corp", "", None],
                "Weight": [1.0, 2.0, 3.0],
                "Rating": ["AA", "AA", "AA"],
            }
        )
        notes: list[str] = []
        out = prepare_members(frame, notes)
        self.assertEqual(out["ID"].tolist(), ["A Corp"])
        self.assertTrue(any("blank ID" in note for note in notes))


class _Item:
    def __init__(self, name: str, frame: pd.DataFrame):
        self.name = name
        self._frame = frame

    def df(self) -> pd.DataFrame:
        return self._frame


class _FakeResponse:
    """Duck-types an ArrowExecuteResponse for the parser only."""

    def __init__(self, items: list[_Item]):
        self._items = items

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, key):
        if isinstance(key, int):
            return self._items[key]
        for item in self._items:
            if item.name == key:
                return item
        raise KeyError(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default


def _named_item(name: str, values: list, ids: list[str]) -> _Item:
    frame = pd.DataFrame({name: values}, index=pd.Index(ids, name="ID"))
    return _Item(name, frame)


class PartialParseTests(unittest.TestCase):
    def test_partial_parse_names_the_missing_items(self):
        response = _FakeResponse(
            [
                _named_item("Name", ["Bond A"], ["A1"]),
                _named_item("Weight", [1.0], ["A1"]),
            ]
        )
        errors: list[str] = []
        notes: list[str] = []
        frame = _parse_response(response, "LEGATRUU Index 2026-09-30", ("Name", "Weight", "Sector"), errors, notes)
        self.assertFalse(frame.empty)
        self.assertEqual(list(frame.columns), ["ID", "Name", "Weight"])
        self.assertEqual(errors, [])
        self.assertTrue(any("Sector" in note for note in notes), notes)

    def test_complete_parse_adds_no_missing_item_note(self):
        response = _FakeResponse(
            [
                _named_item("Name", ["Bond A"], ["A1"]),
                _named_item("Weight", [1.0], ["A1"]),
            ]
        )
        errors: list[str] = []
        notes: list[str] = []
        _parse_response(response, "label", ("Name", "Weight"), errors, notes)
        self.assertEqual(notes, [])

    def test_rows_without_a_weight_are_reported(self):
        response = _FakeResponse(
            [
                _named_item("Name", ["Bond A", "Bond B"], ["A1", "A2"]),
                _named_item("Weight", [1.0, None], ["A1", "A2"]),
            ]
        )
        errors: list[str] = []
        notes: list[str] = []
        frame = _parse_response(response, "label", ("Name", "Weight"), errors, notes)
        self.assertEqual(len(frame), 2)
        self.assertTrue(any("no membership weight" in note for note in notes), notes)


class ArrowFallbackTests(unittest.TestCase):
    def test_non_iterable_response_uses_the_single_item(self):
        class _ArrowExecuteResponse:
            def __init__(self, item):
                self._item = item

            def single(self):
                return self._item

        item = _named_item("Name", ["Bond A"], ["A1"])
        frame = _response_to_frame(_ArrowExecuteResponse(item), ("Name",))
        self.assertEqual(frame["ID"].tolist(), ["A1"])
        self.assertEqual(frame["Name"].tolist(), ["Bond A"])

    def test_combined_df_fallback_keeps_the_id_column(self):
        class _ArrowExecuteResponse:
            pass

        combined = pd.DataFrame({"Value": [1.0]}, index=pd.Index(["A1"], name="ID"))
        fake_bql = types.SimpleNamespace(combined_df=lambda response: combined)
        original = data_module.bql
        data_module.bql = fake_bql
        try:
            frame = _response_to_frame(_ArrowExecuteResponse(), ("Name",))
        finally:
            data_module.bql = original
        self.assertEqual(frame["ID"].tolist(), ["A1"])


class PartialCacheTests(unittest.TestCase):
    def test_cache_refuses_a_partially_parsed_snapshot(self):
        frame = pd.DataFrame({"ID": ["A"], "Weight": [1.0]})
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):
                save_historical("LEGATRUU Index", "2026-09-30", frame, Path(folder))

    def test_cache_ignores_an_entry_without_every_item_column(self):
        """A stale entry written before the guard must not be reused."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cache = root / "cache"
            cache.mkdir(parents=True, exist_ok=True)
            path = cache / "LEGATRUU Index_2026-09-30.csv"
            pd.DataFrame({"ID": ["A"], "Weight": [1.0]}).to_csv(path, index=False)
            manifest = {
                "LEGATRUU Index|2026-09-30": {
                    "fields": FIELD_CONTRACT,
                    "file": path.name,
                    "rows": 1,
                    "has_weight": True,
                    "columns": ["ID", "Weight"],
                }
            }
            import json

            (cache / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            self.assertIsNone(load_historical("LEGATRUU Index", "2026-09-30", root))

    def test_a_month_missing_only_an_analytics_column_is_still_cached(self):
        """A blank measure must not cost the only cheap recovery from a timeout."""
        from fi_index_change.field_library import ANALYTICS_NAMES

        frame = _complete([
            {"ID": "A Corp", "Weight": 10.0, "Security Type": "GLOBAL", "Country": "US",
             "Sector": "CORP", "Currency": "USD", "Rating": "AA", "Tenor": 5.0},
            {"ID": "B Corp", "Weight": 20.0, "Security Type": "GLOBAL", "Country": "US",
             "Sector": "CORP", "Currency": "USD", "Rating": "AA", "Tenor": 7.0},
        ])
        for name in ANALYTICS_NAMES:
            if name in frame.columns:
                frame = frame.drop(columns=name)
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            save_historical("LEGATRUU Index", "2026-09-30", frame, root)
            loaded = load_historical("LEGATRUU Index", "2026-09-30", root)
        self.assertIsNotNone(loaded)
        self.assertEqual(list(loaded["ID"]), ["A Corp", "B Corp"])
        self.assertNotIn("Modified Duration", loaded.columns)

    def test_cache_requirement_excludes_the_analytics_block(self):
        """Identity and Weight gate the cache; a measure does not."""
        from fi_index_change.field_library import ANALYTICS_NAMES, ITEM_NAMES

        columns = set(required_columns())
        self.assertIn("Weight", columns)
        self.assertFalse(columns & set(ANALYTICS_NAMES))
        self.assertEqual(columns, {"ID", *(n for n in ITEM_NAMES if n not in ANALYTICS_NAMES)})

    def test_items_with_different_dates_do_not_multiply_the_rows(self):
        """The 2026-11-02 blank-sheet defect: DATE was a merge key.

        Every item reporting its own as-of turned one row per bond into one
        row per (bond, item), the outer join multiplied the frame, and each
        bond survived with a single populated column — which showed up as an
        all-"(blank)" Country and Sector, a "Missing" tenor, an "NR" rating
        and a "(blank)" currency, with only the ID-driven MBS/TBA and
        Municipal labels still working.
        """
        ids = [f"B{index}" for index in range(4)]

        def item(column, date, value):
            return pd.DataFrame({"ID": ids, "DATE": [date] * 4, column: [value] * 4})

        notes: list[str] = []
        merged = _merge_item_frames(
            [
                item("Name", "2026-10-01", "Bond A"),
                item("Country", "2026-10-02", "UNITED STATES"),
                item("Sector", "2026-10-03", "CORPORATE"),
                item("Tenor", "2026-10-04", 5.0),
                item("Rating", "2026-10-05", "AA"),
                item("Currency", "2026-10-06", "USD"),
                item("Weight", "2026-10-07", 1.0),
            ],
            notes,
        )
        self.assertEqual(len(merged), 4)
        prepared = prepare_members(merged, notes)
        self.assertEqual(sorted(prepared["Country"].unique()), ["United States"])
        self.assertEqual(sorted(prepared["Sector"].unique()), ["CORPORATE"])
        self.assertEqual(sorted(prepared["Tenor Bucket"].unique()), ["5-7Y"])
        self.assertEqual(sorted(prepared["Rating Bucket"].unique()), ["IG"])
        self.assertEqual(sorted(prepared["Currency"].astype(str).unique()), ["USD"])
        self.assertTrue(any("different DATE values" in note for note in notes))

    def test_reading_the_cache_does_not_create_the_folder(self):
        """A read-only project folder must not fail the Update before any read.

        ``cache_dir`` used to ``mkdir`` on the read path, so every Update
        started with a write. A month that was already cached then failed with
        ``PermissionError`` even though nothing needed writing.
        """
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self.assertIsNone(load_historical("LEGATRUU Index", "2026-10-30", root=root))
            self.assertFalse(
                cache_dir(root).exists(),
                "load_historical created the cache folder",
            )

    def test_an_all_blank_cached_month_is_not_reloaded(self):
        """An older build could write a blank month; it must not be served back."""
        import json

        frame = pd.DataFrame(
            {
                "ID": ["A", "B"],
                "Country": ["", ""],
                "Sector": ["", ""],
                "Name": ["", ""],
                "Weight": [1.0, 2.0],
            }
        )
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            folder_path = cache_dir(root)
            # cache_dir no longer creates the folder; a writer does.
            folder_path.mkdir(parents=True, exist_ok=True)
            csv_path = folder_path / f"{safe_name('LEGATRUU Index')}_2026-10-30.csv"
            frame.to_csv(csv_path, index=False)
            manifest_path = folder_path / "manifest.json"
            manifest_path.write_text(
                json.dumps(
                    {
                        "LEGATRUU Index|2026-10-30": {
                            "fields": FIELD_CONTRACT,
                            "file": csv_path.name,
                            "rows": 2,
                            "has_weight": True,
                            "columns": ["ID", "Country", "Sector", "Name", "Weight"],
                        }
                    }
                ),
                encoding="utf-8",
            )
            self.assertIsNone(load_historical("LEGATRUU Index", "2026-10-30", root=root))

    def test_a_duplicate_never_prefers_the_null(self):
        after = _merge_item_frames(
            [pd.DataFrame({"ID": ["A", "A"], "Country": [None, "UNITED STATES"]})]
        )
        before = _merge_item_frames(
            [pd.DataFrame({"ID": ["A", "A"], "Country": ["UNITED STATES", None]})]
        )
        self.assertEqual(after.iloc[0]["Country"], "UNITED STATES")
        self.assertEqual(before.iloc[0]["Country"], "UNITED STATES")


class CacheSentinelTests(unittest.TestCase):
    """The blank-guard has to see ``(blank)``, which is what the cache stores.

    ``prepare_members`` rewrites an empty label to the literal ``"(blank)"``.
    The guard used to test for a literal empty string, so a month where every
    identity column was empty still passed it, was written, and was replayed on
    the next Update with ``status="ok"`` and no warning.
    """

    def _blank_sheet(self, populated: set[str]) -> pd.DataFrame:
        """Every required column present; only ``populated`` carries a value."""
        frame = pd.DataFrame({"ID": ["A", "B"]})
        for name in required_columns():
            if name == "ID":
                continue
            if name == "Weight":
                frame[name] = [1.0, 2.0]
            elif name in populated:
                frame[name] = ["UNITED STATES", "UNITED STATES"]
            else:
                # The exact value ``prepare_members`` stores for an empty cell.
                frame[name] = ["(blank)", "(blank)"]
        return frame

    def _write(self, frame: pd.DataFrame, root: Path) -> Path:
        import json

        folder = cache_dir(root)
        folder.mkdir(parents=True, exist_ok=True)
        csv_path = folder / f"{safe_name('LEGATRUU Index')}_2026-10-30.csv"
        frame.to_csv(csv_path, index=False)
        (folder / "manifest.json").write_text(
            json.dumps(
                {
                    "LEGATRUU Index|2026-10-30": {
                        "fields": FIELD_CONTRACT,
                        "generation": CACHE_GENERATION,
                        "file": csv_path.name,
                        "rows": len(frame),
                        "has_weight": True,
                        "columns": list(frame.columns),
                    }
                }
            ),
            encoding="utf-8",
        )
        return csv_path

    def test_a_cached_month_of_blank_sentinels_is_not_reloaded(self):
        """The shape an all-null response produces after ``prepare_members``."""
        frame = self._blank_sheet(populated=set())
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._write(frame, root)
            self.assertIsNone(
                load_historical("LEGATRUU Index", "2026-10-30", root=root),
                "a month whose every identity value is a blank sentinel was served",
            )

    def test_one_populated_identity_column_still_caches(self):
        """The guard must not start rejecting a usable month."""
        frame = self._blank_sheet(populated={"Country"})
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._write(frame, root)
            loaded = load_historical("LEGATRUU Index", "2026-10-30", root=root)
        self.assertIsNotNone(loaded)
        self.assertEqual(list(loaded["ID"]), ["A", "B"])

    def test_column_has_usable_value_agrees_with_the_alignment_rule(self):
        from fi_index_change.engine import column_has_usable_value

        blank = pd.Series(["(blank)", "", None, float("nan")])
        self.assertFalse(column_has_usable_value(blank))
        self.assertFalse(column_has_usable_value(blank, "Country"))
        self.assertFalse(column_has_usable_value(pd.Series(["Missing"]), "Tenor Bucket"))
        self.assertTrue(column_has_usable_value(pd.Series(["Missing"]), "Country"))
        self.assertTrue(column_has_usable_value(pd.Series(["NR"]), "Rating Bucket"))
        self.assertFalse(column_has_usable_value(pd.Series([], dtype=object)))


class StaleCacheGenerationTests(unittest.TestCase):
    """A month written before the ID-only merge must not be served.

    This is the defect that survived the merge fix. The old build cached months
    where 194 of 200 bonds had a "(blank)" Country, and only the ID-driven
    MBS/TBA and Municipal rows were classified. The merge was fixed, but the
    item list did not change, so ``FIELD_CONTRACT`` still matched, the poisoned
    month was loaded, and the corrected merge never ran.
    """

    def _old_cache(self, root: Path, *, generation: str | None) -> None:
        """Write the exact shape the 2026-11-02 build left behind."""
        import json

        rows = []
        for index in range(200):
            if index < 3:
                country, sector, tenor, rating, currency = (
                    "MBS/TBA", "MBS/TBA", "N.A.", "NR", "USD",
                )
            elif index < 6:
                country, sector, tenor, rating, currency = (
                    "Municipal", "Municipal", "N.A.", "NR", "USD",
                )
            else:
                country, sector, tenor, rating, currency = (
                    "(blank)", "(blank)", "Missing", "(blank)", "(blank)",
                )
            rows.append(
                {
                    "ID": f"B{index}",
                    "Weight": 0.5297,
                    "Country": country,
                    "Sector": sector,
                    "Tenor Bucket": tenor,
                    "Rating": rating,
                    "Currency": currency,
                }
            )
        frame = pd.DataFrame(rows)
        for name in required_columns():
            if name not in frame.columns:
                frame[name] = "(blank)"
        folder = cache_dir(root)
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{safe_name('LEGATRUU Index')}_2026-09-30.csv"
        frame.to_csv(path, index=False)
        entry = {
            "fields": FIELD_CONTRACT,
            "file": path.name,
            "rows": len(frame),
            "has_weight": True,
            "columns": list(frame.columns),
        }
        if generation is not None:
            entry["generation"] = generation
        (folder / "manifest.json").write_text(
            json.dumps({"LEGATRUU Index|2026-09-30": entry}), encoding="utf-8"
        )

    def test_a_month_from_the_old_build_is_re_requested(self):
        """Partially blank is the real symptom, so the blank guard cannot help."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._old_cache(root, generation=None)
            self.assertIsNone(
                load_historical("LEGATRUU Index", "2026-09-30", root=root),
                "a pre-fix cache entry was served; the corrected merge never ran",
            )

    def test_a_month_from_a_superseded_generation_is_re_requested(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._old_cache(root, generation="id-only-merge-1")
            self.assertIsNone(load_historical("LEGATRUU Index", "2026-09-30", root=root))

    def test_a_month_written_by_this_build_is_served(self):
        """Invalidation must be one-time, not a permanent cache miss."""
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            self._old_cache(root, generation=CACHE_GENERATION)
            loaded = load_historical("LEGATRUU Index", "2026-09-30", root=root)
        self.assertIsNotNone(loaded)
        self.assertEqual(len(loaded), 200)

    def test_a_round_trip_stamps_the_current_generation(self):
        frame = _complete([
            {"ID": "A Corp", "Weight": 10.0, "Security Type": "GLOBAL", "Country": "US",
             "Sector": "CORP", "Currency": "USD", "Rating": "AA", "Tenor": 5.0},
        ])
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            save_historical("LEGATRUU Index", "2026-09-30", frame, root)
            import json

            manifest = json.loads((cache_dir(root) / "manifest.json").read_text())
            entry = manifest["LEGATRUU Index|2026-09-30"]
            self.assertEqual(entry["generation"], CACHE_GENERATION)
            self.assertIsNotNone(load_historical("LEGATRUU Index", "2026-09-30", root=root))


class ValueColumnChoiceTests(unittest.TestCase):
    """An item can deliver its values under a name this app did not expect.

    The 2026-11-02 sheet had Country and Sector entirely blank although the
    request was fine. The item answered with the expected column present and
    empty, and the values sat in a sibling column. Preferring the candidate with
    the most rows only helps when the sibling is also a candidate, so a
    differently-named sibling still lost its data.
    """

    class _Item:
        def __init__(self, name, frame):
            self.name = name
            self._frame = frame

        def df(self):
            return self._frame.copy()

    def _frame(self, **columns):
        return pd.DataFrame(columns, index=pd.Index(["B1", "B2"], name="ID"))

    def test_a_named_but_empty_column_yields_to_a_populated_sibling(self):
        item = self._Item(
            "OAD",
            self._frame(OAD=[None, None], OPTION_ADJ_DURATION_SOV_CRV=[4.1, 5.2]),
        )
        out = _item_frame(item, "OAD")
        self.assertEqual(list(out["OAD"]), [4.1, 5.2])

    def test_a_populated_named_column_is_kept(self):
        item = self._Item(
            "OAD",
            self._frame(OAD=[1.1, 2.2], SOMETHING_ELSE=[9.9, 9.9]),
        )
        out = _item_frame(item, "OAD")
        self.assertEqual(list(out["OAD"]), [1.1, 2.2])

    def test_two_populated_siblings_are_not_guessed_between(self):
        """Ambiguity is reported, never resolved by picking one at random."""
        item = self._Item(
            "OAD",
            self._frame(OAD=[None, None], FIRST=[1.0, 1.0], SECOND=[2.0, 2.0]),
        )
        out = _item_frame(item, "OAD")
        if out.empty:
            return  # reported as an absent item, which is the other valid answer
        self.assertTrue(out["OAD"].isna().all())

    def test_the_all_null_note_names_the_columns_the_item_carried(self):
        """The log has to say which case it is, or it cannot be acted on."""
        response = _FakeResponse([
            _Item("OAD", self._frame(OAD=[None, None], OPTION_ADJ_DURATION_SOV_CRV=[None, None])),
            _Item("Weight", self._frame(Weight=[1.0, 2.0])),
        ])
        notes: list[str] = []
        _parse_response(response, "LEGATRUU Index 2026-09-30", ("OAD", "Weight"), [], notes)
        text = " ".join(notes)
        self.assertIn("arrived with a column but every value null", text)
        self.assertIn("OPTION_ADJ_DURATION_SOV_CRV", text)

    def test_a_yield_type_item_keeps_the_column_the_response_actually_uses(self):
        """``yield_(yield_type='YTM')`` answers under its own column name.

        The request key is ``YTM`` but the response names the column after the
        underlying item, so a name-only picker found nothing. This is the shape
        that produced the 2026-11-02 "every value null" line for YTM.
        """
        item = self._Item("YTM", self._frame(YIELDTM=[3.1, 3.4]))
        out = _item_frame(item, "YTM")
        self.assertEqual(list(out["YTM"]), [3.1, 3.4])

    def test_a_rating_alias_still_wins_when_it_carries_values(self):
        item = self._Item(
            "Rating",
            self._frame(RATING=["NR", "NR"], BASE_RATING=["AA", "A"]),
        )
        out = _item_frame(item, "Rating")
        self.assertEqual(list(out["Rating"]), ["AA", "A"])


class TimeoutClassificationTests(unittest.TestCase):
    """A retry costs two minutes, so only a real timeout may trigger one."""

    def test_a_timeout_is_retried(self):
        for text in (
            "ResponseError: [BQLTimeoutError] - The query took too long to complete.",
            "BQLTimeoutError",
            "The query timed out",
        ):
            self.assertTrue(data_module.is_timeout(Exception(text)), text)

    def test_an_item_name_containing_timeout_is_not_a_timeout(self):
        """``No BQL data item named 'timeout_field'`` can never succeed on retry."""
        for text in (
            "No BQL data item named 'timeout_field'",
            "No BQL data item named 'mtge_modified_duration'",
            "Invalid ticker 'TIMEOUT Index'",
            "403 Forbidden",
            "No Data Access License under this BBG ID",
            "entitlement denied",
            "connection reset by peer",
        ):
            self.assertFalse(data_module.is_timeout(Exception(text)), text)


class WeightScaleTests(unittest.TestCase):
    """The unit test must read the net sum, which is what "sums to 1" means."""

    def _prepare(self, weights):
        frame = pd.DataFrame(
            {
                "ID": [f"B{index}" for index in range(len(weights))],
                "Weight": weights,
                "Country": ["UNITED STATES"] * len(weights),
                "Sector": ["GOVT"] * len(weights),
                "Currency": ["USD"] * len(weights),
                "Rating": ["AA"] * len(weights),
                "Tenor": [5.0] * len(weights),
            }
        )
        return prepare_members(frame, [])

    def test_a_fraction_book_with_one_short_is_still_scaled(self):
        """Net 1.0, absolute 1.4: the old ``abs().sum()`` read it as neither."""
        out = self._prepare([1.2, -0.2])
        self.assertAlmostEqual(float(out["Weight"].sum()), 100.0, places=6)

    def test_a_percent_book_is_left_alone(self):
        out = self._prepare([60.0, -20.0, 60.0])
        self.assertAlmostEqual(float(out["Weight"].sum()), 100.0, places=6)

    def test_a_book_of_all_zeros_is_left_alone(self):
        out = self._prepare([0.0, 0.0])
        self.assertAlmostEqual(float(out["Weight"].sum()), 0.0, places=6)


class DurationTypeFamilyTests(unittest.TestCase):
    """The four duration columns are one frozen builder with four parameters.

    ``duration_type`` is the only evidence-backed form this project has for an
    option-adjusted spread duration. These tests pin the two things that can go
    wrong silently: a wrong parameter value, and a response that hands the same
    measure back under several names.
    """

    def _bq(self):
        calls: list[dict] = []

        class _Data:
            def duration(self, **kwargs):
                calls.append(kwargs)
                return _Item("DURATION", pd.DataFrame({"ID": ["A"], "VALUE": [1.0]}))

        class _Service:
            data = _Data()

        return _Service(), calls

    def test_each_duration_item_passes_its_own_type(self):
        bq, calls = self._bq()
        build_member_items(bq, DURATION_FIELDS)
        self.assertEqual(
            calls,
            [
                {},
                {"duration_type": "MODIFIED"},
                {"duration_type": "EFFECTIVE"},
                {"duration_type": "SPREAD"},
            ],
        )

    def test_the_duration_block_is_the_operators_four(self):
        self.assertEqual(
            DURATION_FIELDS,
            ("Duration", "Modified Duration", "Effective Duration", "OASD"),
        )

    def test_analytics_groups_partition_the_analytics_set(self):
        """Every analytics item is sent once, in exactly one group.

        A duplicate would spend a slot twice; an omission would drop a measure
        the app still displays. Durations must form their own group, because
        they are the model-priced family and a timeout has to be attributable
        to it.
        """
        from fi_index_change.field_library import ANALYTICS_GROUPS, ANALYTICS_NAMES

        flat = [name for group in ANALYTICS_GROUPS for name in group]
        self.assertEqual(sorted(flat), sorted(ANALYTICS_NAMES))
        self.assertEqual(len(flat), len(set(flat)))
        self.assertIn(DURATION_FIELDS, ANALYTICS_GROUPS)
        self.assertEqual(ANALYTICS_GROUPS[-1], DURATION_FIELDS)

    def _response(self, values: dict, weights=(10.0, 20.0)):
        ids = [f"B{index}" for index in range(len(weights))]
        items = [
            _Item(name, pd.DataFrame({"ID": ids, name: list(column)}))
            for name, column in values.items()
        ]
        items.append(_Item("Weight", pd.DataFrame({"ID": ids, "Weight": list(weights)})))
        return _FakeResponse(items)

    def _notes_for(self, values):
        notes: list[str] = []
        _parse_response(
            self._response(values),
            "LEGATRUU Index 2026-09-30",
            (*values, "Weight"),
            [],
            notes,
        )
        return notes

    def test_identical_duration_columns_are_reported(self):
        notes = self._notes_for({name: [2.5, 3.5] for name in DURATION_FIELDS})
        self.assertTrue(
            any("identical values" in note for note in notes),
            f"a response that repeats one measure was not reported: {notes}",
        )

    def test_distinct_duration_columns_are_not_reported(self):
        notes = self._notes_for(
            {
                "Duration": [2.5, 3.5],
                "Modified Duration": [2.1, 3.1],
                "Effective Duration": [2.3, 3.3],
                "OASD": [1.9, 2.9],
            }
        )
        self.assertFalse(
            any("identical values" in note for note in notes),
            f"four genuinely different measures were reported as one: {notes}",
        )


if __name__ == "__main__":
    unittest.main()
