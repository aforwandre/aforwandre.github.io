"""Apply the widget stubs before any test module imports the app.

Without this, ``pytest tests`` passed only because ``test_app_runtime`` sorts
before ``test_engine``; ``pytest tests/test_engine.py`` on its own failed on a
missing ``plotly``. A real installed package is never replaced.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

import widget_stubs  # noqa: E402

widget_stubs.install()
