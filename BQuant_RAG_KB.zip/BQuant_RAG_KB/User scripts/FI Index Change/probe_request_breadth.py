"""Desktop-only probe: which item group crosses the two-minute limit.

Paste this module's body as one notebook cell on BQuant Desktop, beside the
app package, and run it once. It sends one request per group instead of a
whole Update, so a timeout names the group responsible instead of leaving the
answer to guesswork. It writes nothing to the app cache and changes no app
file.

Do not run this on a local machine: it hands work to Bloomberg BQL.

Reading the result: group 2 is the control. It is the 16-item set that is
known to answer on LEGATRUU Index. If group 2 also times out in this session,
the cause is not the extra analytics and the app code must be examined
instead. If only groups 3 to 5 fail, the cost is in the items those groups
add, and the first failure names them.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pandas as pd

try:
    import bql

    import bq
except ImportError:  # Local authoring never executes BQL.
    bql = None
    bq = None

from fi_index_change.config import MONTH_END_CHOICES
from fi_index_change.engine import month_end_choices
from fi_index_change.field_library import ANALYTICS_NAMES, ITEM_NAMES, build_member_items

INDEX_TICKER = "LEGATRUU Index"
# One month-end only: two would double the wall clock for no extra signal.
# The second entry is the most recent month that has already locked, so the
# probe measures request cost and not the projected-date publication rule. Set
# AS_OF by hand to compare another month.
AS_OF = month_end_choices(pd.Timestamp.today(), MONTH_END_CHOICES)[1][1]

IDENTITY = tuple(name for name in ITEM_NAMES if name not in ANALYTICS_NAMES)
PROVEN = ("OAS", "Duration", "Yield")

GROUPS = (
    ("1 identity", IDENTITY),
    ("2 identity + OAS/Duration/Yield (the 16-item set)", (*IDENTITY, *PROVEN)),
    ("3 + Z-Spread, I-Spread", (*IDENTITY, *PROVEN, "Z-Spread", "I-Spread")),
    # The three parameterised duration items, added one family at a time. If
    # this group is the first to fail, the cost is in ``duration()`` evaluation
    # and not in the item count, because group 2 already proves plain
    # ``duration()`` answers on this index.
    ("4 + Modified/Effective/OASD duration", (
        *IDENTITY, *PROVEN, "Z-Spread", "I-Spread",
        "Modified Duration", "Effective Duration", "OASD",
    )),
    ("5 + YTM, YTW (the full request)", ITEM_NAMES),
)


def _rows(response) -> int:
    try:
        return int(len(bql.combined_df(response)))
    except Exception:
        return -1


def _run(bq_service, label: str, names: tuple[str, ...]) -> dict:
    record = {"group": label, "items": len(names), "seconds": None, "rows": None, "error": ""}
    started = time.perf_counter()
    try:
        items = build_member_items(bq_service, names)
        request = bql.Request(
            bq_service.univ.members(INDEX_TICKER, dates=AS_OF),
            items,
            with_params={"mode": "cached"},
        )
        response = bq_service.execute(request)
    except Exception as exc:  # a build or query failure is the measurement
        record["seconds"] = round(time.perf_counter() - started, 1)
        record["error"] = f"{type(exc).__name__}: {exc}"
        return record
    record["seconds"] = round(time.perf_counter() - started, 1)
    record["rows"] = _rows(response)
    return record


def main() -> None:
    if bql is None or bq is None:
        raise RuntimeError("bql is unavailable. Run this on BQuant Desktop only.")
    print(f"{INDEX_TICKER} {AS_OF}: {len(GROUPS)} requests, one at a time.")
    service = bq.Service()
    results = []
    for label, names in GROUPS:
        print(f"  {label} — {len(names)} items ...", end=" ", flush=True)
        record = _run(service, label, names)
        results.append(record)
        if record["error"]:
            print(f"FAILED after {record['seconds']}s: {record['error']}")
        else:
            print(f"ok in {record['seconds']}s, {record['rows']} rows")
    out = Path.cwd() / "probe_request_breadth_result.json"
    out.write_text(json.dumps({"index": INDEX_TICKER, "as_of": AS_OF, "results": results}, indent=2))
    print(f"wrote {out.name}")


if __name__ == "__main__":
    main()
