"""Sequential fixed-income index membership requests.

One ``bq.execute`` per effective date. Historical successes are cached.
The projected date is requested on every Update and is not cached.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import pandas as pd

from .cache import load_historical, required_columns, save_historical
from .config import MONTH_END_CHOICES, QUERY_ATTEMPTS, SPLIT_REQUESTS
from .engine import (
    align_snapshot_labels,
    collapse_duplicate_ids,
    column_has_usable_value,
    rating_class_conflicts,
    comparison_for,
    month_end_choices,
    prepare_members,
    validate_index_ticker,
)
from .field_library import (
    ANALYTICS_GROUPS,
    ANALYTICS_NAMES,
    DURATION_FIELDS,
    ITEM_NAMES,
    NUMERIC_COLUMNS,
    build_member_items,
)

try:
    import bql
except ImportError:  # Local authoring never executes BQL.
    bql = None


@dataclass
class IndexPayload:
    index_ticker: str
    previous_date: str
    selected_date: str
    kind: str
    snapshots: dict[str, pd.DataFrame] = field(default_factory=dict)
    statuses: dict[str, str] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    # Never populated now that ``Market Value`` is out of the request, so
    # turnover is always approximate. The fields stay as the seam where a
    # confirmed index-MV source would plug in without touching ``engine``.
    index_mv_previous: float | None = None
    index_mv_latest: float | None = None
    index_mv_ratio: float | None = None
    turnover_basis: str = "approx"


def _require_bql():
    if bql is None:
        raise RuntimeError("bql is unavailable. Run this app on Bloomberg BQuant Desktop.")
    return bql.Service()


def _is_response(value) -> bool:
    """ArrowExecuteResponse is a success even when it is not iterable."""
    if value is None or isinstance(value, (tuple, list, dict, str, bytes, pd.DataFrame, Exception)):
        return False
    return "response" in type(value).__name__.lower()


def _response_items(response) -> list:
    try:
        count = len(response)
    except Exception:
        count = None
    if count is not None and 0 < count <= 64:
        try:
            items = [response[index] for index in range(count)]
            if items and hasattr(items[0], "df"):
                return items
        except Exception:
            pass
    try:
        items = list(response)
        if items and hasattr(items[0], "df"):
            return items
    except TypeError:
        pass
    if hasattr(response, "single"):
        try:
            item = response.single()
            return [item] if hasattr(item, "df") else []
        except Exception:
            pass
    return []


def _lookup_item(response, name: str):
    candidates = (name, name.upper(), name.lower(), f"{name}()")
    if hasattr(response, "get"):
        for candidate in candidates:
            try:
                item = response.get(candidate)
            except Exception:
                item = None
            if item is not None and hasattr(item, "df"):
                return item
    for candidate in candidates:
        try:
            item = response[candidate]
        except Exception:
            item = None
        if item is not None and hasattr(item, "df"):
            return item
    return None


def _find_column(frame: pd.DataFrame, name: str):
    lookup = {str(column).strip().upper(): column for column in frame.columns}
    return lookup.get(name.upper())


# Data items whose frame carries more than one value column, keyed by the
# request name. The extra columns are not discarded data: the frozen request
# asks for one field of the item, and the rest are other fields of the same
# item (a numeric scale, a source label) that this app does not display.
PREFERRED_VALUE_COLUMNS = {
    "Rating": "BASE_RATING",
}


def _pick_value_column(
    raw: pd.DataFrame,
    item_name,
    output_name,
    metadata: set[str],
) -> str | None:
    """Which column of one item frame holds that item's value.

    One definition, because getting this wrong is silent: a name match that is
    entirely null looks like "the field did not arrive", and the sheet shows
    every bond as blank while the request was fine. That is exactly how the
    2026-11-02 Country / Sector sheet was produced.

    Order of preference:
    1. A named alias the frozen request means (``Rating`` -> ``BASE_RATING``).
    2. The candidate that carries the most rows, among names that could mean
       this item (its response key, its request name, or ``VALUE``).
    3. The remaining non-metadata column, when only one is left.
    4. Any single column that actually carries values.

    Returns None when the frame is ambiguous: two different populated columns
    with no name evidence is a case to report, not to guess.
    """
    preferred = PREFERRED_VALUE_COLUMNS.get(str(output_name or item_name or ""))
    if preferred is not None:
        column = _find_column(raw, preferred)
        if column is not None and raw[column].notna().sum() > 0:
            return column

    candidates: list[str] = []
    for candidate in (item_name, output_name, "VALUE"):
        if candidate is None:
            continue
        column = _find_column(raw, str(candidate))
        if column is not None and column not in candidates:
            candidates.append(column)
    if candidates:
        best = max(candidates, key=lambda column: int(raw[column].notna().sum()))
        if raw[best].notna().sum() > 0:
            return best

    remaining = [
        column for column in raw.columns if str(column).upper() not in metadata
    ]
    if not remaining:
        return None

    # An item can answer with the expected column present and empty while the
    # values sit under a sibling name. Two populated siblings are ambiguous, so
    # they stay unresolved instead of one being picked at random.
    populated = [column for column in remaining if raw[column].notna().sum() > 0]
    if len(populated) == 1:
        return populated[0]
    if len(remaining) == 1:
        return remaining[0]
    # ``yield_(yield_type=...)`` is the documented form for YTM and YTW, and its
    # response names the column after the underlying item rather than after the
    # request key, so the named candidates above can all miss. When several
    # columns remain and every one is empty, the first is as good as any: the
    # field is genuinely blank and the caller reports it by name.
    if not populated:
        return remaining[0]
    return None


def _promote_id_index(frame: pd.DataFrame) -> pd.DataFrame:
    """Name a security-id index so reset_index yields an ID column.

    ``18`` treats a BQL id index as ``ID`` even when the index name is
    missing. A default RangeIndex is a row number, so it stays unnamed.
    """
    if isinstance(frame.index, pd.RangeIndex):
        return frame
    if isinstance(frame.index, pd.MultiIndex):
        names = list(frame.index.names)
        has_id = any(str(name).upper() == "ID" for name in names if name is not None)
        if not has_id:
            for level, name in enumerate(names):
                if name is None:
                    names[level] = "ID"
                    break
            frame.index.names = names
        return frame
    if frame.index.name is None:
        frame.index.name = "ID"
    return frame


def _item_frame(item, output_name: str | None = None) -> pd.DataFrame:
    raw = _promote_id_index(item.df().copy())
    index_names = list(raw.index.names)
    if any(name is not None for name in index_names):
        safe_names = []
        for level, name in enumerate(index_names):
            safe_names.append(f"__INDEX_{name}_{level}" if name in raw.columns else name)
        raw.index.names = safe_names
        raw = raw.reset_index()
    elif "ID" not in raw.columns:
        raw = raw.reset_index()
    item_name = getattr(item, "name", None)
    value_name = output_name or item_name
    id_column = _find_column(raw, "ID")
    date_column = _find_column(raw, "DATE")
    metadata = {"ID", "DATE", "CURRENCY", "ORIG_IDS", "REVISION_DATE"}
    value_column = _pick_value_column(raw, item_name, output_name, metadata)
    if value_column is None:
        return pd.DataFrame()
    if id_column is None:
        return pd.DataFrame()
    keep = [id_column]
    if date_column is not None:
        keep.append(date_column)
    keep.append(value_column)
    out = raw.loc[:, list(dict.fromkeys(keep))].copy()
    rename = {id_column: "ID", value_column: value_name or str(value_column)}
    if date_column is not None:
        rename[date_column] = "DATE"
    out = out.rename(columns=rename)
    out["ID"] = out["ID"].astype(str)
    return out.loc[:, ~out.columns.duplicated()]


def _collapse_ids(frame: pd.DataFrame) -> pd.DataFrame:
    """Delegate to the engine's single implementation.

    Kept as a module-level name because every call site in this module reads
    as "collapse this item frame before merging it".
    """
    return collapse_duplicate_ids(frame)


def _merge_item_frames(frames: list[pd.DataFrame], notes: list[str] | None = None) -> pd.DataFrame:
    notes = notes if notes is not None else []
    frames = [frame for frame in frames if frame is not None and not frame.empty]
    if not frames:
        return pd.DataFrame()
    # Every frame is collapsed, including the first one. Leaving the first
    # uncollapsed meant a duplicate in the first item decided the row count
    # for the whole merge. Duplicates are counted here, before the collapse,
    # so the log still reports them.
    duplicate_count = sum(
        int(frame["ID"].duplicated().sum()) for frame in frames if "ID" in frame.columns
    )
    # Items that disagree about their own as-of are worth one sentence: it
    # proves DATE cannot be an identity key here and it dates the frame.
    item_dates = sorted(
        {
            str(value)
            for frame in frames
            if "DATE" in frame.columns
            for value in pd.Series(frame["DATE"]).dropna().unique()
        }
    )
    frames = [_collapse_ids(frame) for frame in frames]
    merged = frames[0]
    for extra in frames[1:]:
        # The row identity of an undated snapshot is the security ID alone.
        # Keying on DATE as well was a defect found on 2026-11-02: items that
        # each report their own as-of turned one row per bond into one row per
        # (bond, item), so the outer join multiplied the frame and then
        # ``prepare_members`` kept a single row per ID whose only non-null
        # column was the one from the last date. The symptom was a dashboard
        # where Country and Sector were entirely "(blank)", Tenor was
        # "Missing", Rating was "NR" and Currency was "(blank)", while the
        # MBS/TBA and Municipal overrides still worked because they are driven
        # by ID. DATE is not part of this app's identity: the snapshot's date
        # is set from the request as ``AS_OF_DATE``.
        keys = ["ID"]
        value_columns = [
            column for column in extra.columns if column not in keys and column != "DATE"
        ]
        if not value_columns:
            continue
        merged = merged.merge(extra[keys + value_columns], on=keys, how="outer")
    if duplicate_count:
        notes.append(
            f"Dropped {duplicate_count} duplicate IDs while merging response items "
            "(kept the last non-null value per item)."
        )
    if len(item_dates) > 1:
        notes.append(
            f"Response items carried {len(item_dates)} different DATE values "
            f"({', '.join(item_dates[:4])}); the merged frame uses ID only and the "
            "snapshot date comes from the request."
        )
    if "DATE" in merged.columns:
        merged = merged.drop(columns="DATE")
    return merged.loc[:, ~merged.columns.duplicated()]


def _response_to_frame(
    response, item_names: tuple[str, ...], notes: list[str] | None = None
) -> pd.DataFrame:
    frames = []
    for name in item_names:
        item = _lookup_item(response, name)
        if item is not None:
            frames.append(_item_frame(item, output_name=name))
    if frames:
        return _merge_item_frames(frames, notes)
    items = _response_items(response)
    if items:
        return _merge_item_frames([_item_frame(item) for item in items], notes)
    if bql is not None:
        try:
            combined = _promote_id_index(bql.combined_df(response)).reset_index()
            id_column = _find_column(combined, "ID")
            if id_column is not None and id_column != "ID":
                combined = combined.rename(columns={id_column: "ID"})
            if "ID" in combined.columns:
                combined["ID"] = combined["ID"].astype(str)
            return combined
        except Exception:
            pass
    return pd.DataFrame()


def _shape_note(response, item_names: tuple[str, ...]) -> str:
    """Column names only. Row values stay out of the log."""
    parts = []
    for name in item_names:
        item = _lookup_item(response, name)
        if item is None:
            continue
        try:
            raw = item.df()
        except Exception as exc:
            parts.append(f"{name}: {type(exc).__name__}")
            continue
        parts.append(f"{name} columns={list(raw.columns)} index={list(raw.index.names)}")
    if parts:
        return " ".join(parts)
    items = _response_items(response)
    if not items:
        return "no items"
    try:
        raw = items[0].df()
        return f"item0 columns={list(raw.columns)} index={list(raw.index.names)}"
    except Exception as exc:
        return f"item0: {type(exc).__name__}"


def _missing_items(frame: pd.DataFrame, item_names: tuple[str, ...]) -> tuple[str, ...]:
    """Item output names that the parsed frame does not carry.

    A missing column means that item's response did not parse. It is not the
    same as an item that parsed but returned blank values.
    """
    if frame is None or frame.empty:
        return tuple(item_names)
    return tuple(name for name in item_names if name not in frame.columns)


def _returned_shape(response, name: str) -> str:
    """Column names the response carries for one requested item.

    Only names are reported, never row values. This is what tells a reader
    apart "the field was blank" from "the item arrived with columns this app
    did not know how to pick".
    """
    parts = []
    for item in _response_items(response):
        item_name = str(getattr(item, "name", "") or "")
        if item_name.casefold() != name.casefold():
            continue
        try:
            columns = [str(column) for column in item.df().columns]
        except Exception as exc:
            parts.append(f"{item_name}: {type(exc).__name__}")
            continue
        parts.append(f"{item_name}: columns={columns}")
    return "; ".join(parts)


def _parse_response(
    response,
    label: str,
    item_names: tuple[str, ...],
    errors: list[str],
    notes: list[str] | None = None,
) -> pd.DataFrame:
    if not _is_response(response):
        errors.append(f"{label}: request failed ({type(response).__name__}: {response})")
        return pd.DataFrame()
    try:
        frame = _response_to_frame(response, item_names, notes)
    except Exception as exc:
        errors.append(f"{label}: {type(exc).__name__}: {exc}")
        return pd.DataFrame()
    if frame is None or frame.empty:
        errors.append(f"{label}: response parsed as empty. {_shape_note(response, item_names)}")
        return pd.DataFrame()
    weights = pd.to_numeric(frame["Weight"], errors="coerce") if "Weight" in frame.columns else None
    if weights is None or weights.notna().sum() == 0:
        errors.append(f"{label}: Weight column missing or entirely null. Snapshot was not used.")
        return pd.DataFrame()
    missing = _missing_items(frame, item_names)
    if missing and notes is not None:
        detail = [
            f"{name} ({_returned_shape(response, name) or 'no item with that name'})"
            for name in missing
        ]
        notes.append(
            f"{label}: {len(missing)} item(s) did not parse and are absent: "
            + ", ".join(detail)
            + "."
        )
    if weights.isna().any() and notes is not None:
        notes.append(
            f"{label}: {int(weights.isna().sum())} row(s) have no membership weight. "
            "They stay in the comparison as unweighted rows."
        )
    # A column can arrive without its values. That is not the same as an item
    # that did not parse, so it needs its own sentence: otherwise the sheet
    # shows every bond as "(blank)" and nothing in the log explains it.
    if notes is not None:
        empty = [
            name
            for name in item_names
            if name in frame.columns
            and name != "Weight"
            and frame[name].notna().sum() == 0
        ]
        if empty:
            # The column names are the difference between two very different
            # problems: "this item returned null for every bond" and "this item
            # returned the values under a column name this app did not pick".
            # Without them the log cannot be acted on.
            detail = [
                f"{name} ({_returned_shape(response, name) or 'no item with that name'})"
                for name in empty
            ]
            notes.append(
                f"{label}: {len(empty)} item(s) arrived with a column but every value "
                "null: " + "; ".join(detail) + "."
            )
    # The four duration items share one builder, ``duration()``, and differ only
    # by ``duration_type``. If the response ever keys two of them to the same
    # underlying item, nothing else would say so: every value is present, in
    # range, and plausible, and the sheet would show one measure several times.
    # Two measures can legitimately agree on a single bond (an uncallable bond
    # has YTM = YTW), so only a whole-column match is reported.
    if notes is not None:
        present = [name for name in DURATION_FIELDS if name in frame.columns]
        duplicates = []
        for index, name in enumerate(present):
            for other in present[:index]:
                pair = frame[[name, other]].dropna()
                if not pair.empty and bool((pair[name] == pair[other]).all()):
                    duplicates.append(f"{name} = {other}")
        if duplicates:
            notes.append(
                f"{label}: duration items returned identical values ("
                + ", ".join(duplicates)
                + ") on every row that carried both. One builder may be "
                "ignoring duration_type, so treat those columns as one measure."
            )
    return frame


def _member_request(bq, index_ticker: str, as_of: str, items: dict):
    universe = bq.univ.members(index_ticker, dates=as_of)
    return bql.Request(universe, items, with_params={"mode": "cached"})


# A timeout is the only failure a second identical attempt can recover from.
# Everything else (a rejected item name, an unentitled field, a malformed
# ticker) is deterministic, so retrying it only spends another two minutes.
_TIMEOUT_MARKERS = (
    "bqltimeouterror",
    "took too long",
    "query timed out",
    "timed out",
    "timeout",
)

# Text that can only mean a deterministic failure, whatever else the message
# says. A bare ``"timeout"`` marker used to classify
# ``No BQL data item named 'timeout_field'`` as a timeout, which paid a second
# two-minute wait for an item name that could never succeed on a retry.
# Checked first, so these always win.
_DETERMINISTIC_MARKERS = (
    "no bql data item",
    "not entitled",
    "entitlement",
    "not authorized",
    "unauthorized",
    "403",
    "license",
    "invalid ticker",
    "does not exist",
    "unknown field",
)


def is_timeout(exc: BaseException) -> bool:
    """True when ``exc`` is the Desktop two-minute query limit.

    A message that names a deterministic failure is never a timeout, even when
    the item or ticker name happens to contain the word.
    """
    text = f"{type(exc).__name__}: {exc}".casefold()
    if any(marker in text for marker in _DETERMINISTIC_MARKERS):
        return False
    return any(marker in text for marker in _TIMEOUT_MARKERS)


def _execute_attempts(
    bq,
    index_ticker: str,
    as_of: str,
    items: dict,
    label: str,
    errors: list[str],
    notes: list[str] | None = None,
) -> tuple[object | None, int]:
    """Execute one month-end request, retrying only a timeout.

    The second attempt sends the same items to the same date. It is not a
    narrower request and it drops nothing: the operator's evidence is that a
    repeat Update answers in seconds, which means the first attempt warmed the
    Bloomberg-side cache rather than that the request was wrong. Returns
    ``(response or None, attempts_made)``.
    """
    notes = notes if notes is not None else []
    attempts = max(1, int(QUERY_ATTEMPTS))
    seconds: list[float] = []
    last: BaseException | None = None
    for attempt in range(1, attempts + 1):
        started = time.perf_counter()
        try:
            # Rebuilt per attempt so no state from a failed execute is reused;
            # the item dict itself is built once by the caller.
            response = bq.execute(_member_request(bq, index_ticker, as_of, items))
        except Exception as exc:
            elapsed = time.perf_counter() - started
            seconds.append(elapsed)
            last = exc
            if not is_timeout(exc) or attempt == attempts:
                break
            notes.append(
                f"{label}: attempt {attempt} of {attempts} timed out after "
                f"{elapsed:.0f}s. Retrying the same {len(items)} items unchanged "
                "against the same date; only the warm cache can make this faster."
            )
            continue
        elapsed = time.perf_counter() - started
        seconds.append(elapsed)
        if attempt > 1:
            notes.append(
                f"{label}: answered on attempt {attempt} of {attempts} in "
                f"{elapsed:.0f}s after a first attempt of {seconds[0]:.0f}s."
            )
        return response, attempt
    if last is not None:
        errors.append(f"{label}: {type(last).__name__}: {last}")
        if len(seconds) > 1:
            errors.append(
                f"{label}: all {len(seconds)} attempts failed "
                f"({', '.join(f'{value:.0f}s' for value in seconds)})."
            )
    return None, len(seconds)


def _group_name(group: tuple[str, ...]) -> str:
    """A readable label for one analytics group, for the note and the log."""
    names = ", ".join(group)
    return f"[{names}]"


def _fetch_live(
    bq,
    index_ticker: str,
    as_of: str,
    errors: list[str],
    notes: list[str],
) -> tuple[pd.DataFrame, bool]:
    """Fetch one effective date. The boolean says whether caching is safe."""
    label = f"{index_ticker} {as_of}"
    if not SPLIT_REQUESTS:
        item_names = ITEM_NAMES
        try:
            items = build_member_items(bq, item_names)
        except Exception as exc:
            errors.append(f"{label}: {type(exc).__name__}: {exc}")
            return pd.DataFrame(), False
        # A timeout is retried unchanged, on the operator's evidence that a
        # repeat Update answers in seconds. The old retry here was different
        # and is not coming back: it dropped ``Market Value`` on any failure,
        # so it could never shorten a request that was too wide and it paid a
        # second two-minute timeout for nothing. This one drops nothing.
        response, _attempts = _execute_attempts(
            bq, index_ticker, as_of, items, label, errors, notes
        )
        if response is None:
            return pd.DataFrame(), False
        frame = _parse_response(response, label, item_names, errors, notes)
        # Cache safety is about identity, not about every measure. The notes
        # already name any analytics column that did not parse, and refusing
        # the cache for one blank measure removed the only cheap recovery from
        # a timeout.
        return frame, not _missing_items(frame, required_columns())

    identity_names = tuple(name for name in ITEM_NAMES if name not in ANALYTICS_NAMES)
    try:
        identity_items = build_member_items(bq, identity_names)
    except Exception as exc:
        errors.append(f"{label} identity: {type(exc).__name__}: {exc}")
        return pd.DataFrame(), False
    identity_response, _attempts = _execute_attempts(
        bq, index_ticker, as_of, identity_items, f"{label} identity", errors, notes
    )
    if identity_response is None:
        return pd.DataFrame(), False
    identity = _parse_response(
        identity_response, f"{label} identity", identity_names, errors, notes
    )
    if identity.empty:
        return identity, False
    # One request per measure family, in ``ANALYTICS_GROUPS`` order. A family
    # that fails is recorded and skipped so the rest of the month survives: a
    # table with securities, weights and spreads and a note naming the missing
    # duration measures is more useful than an empty table. What must not
    # happen is that failure being cached, so ``failed`` also refuses the cache
    # -- otherwise the next Update reads the incomplete month back and never
    # retries the family that failed.
    merged = identity
    failed: list[str] = []
    for index, group in enumerate(ANALYTICS_GROUPS, start=1):
        group_label = f"{label} analytics {index}"
        try:
            group_items = build_member_items(bq, group)
        except Exception as exc:
            errors.append(f"{group_label}: {type(exc).__name__}: {exc}")
            failed.append(_group_name(group))
            continue
        group_response, _attempts = _execute_attempts(
            bq, index_ticker, as_of, group_items, group_label, errors, notes
        )
        if group_response is None:
            failed.append(_group_name(group))
            continue
        part = (
            _response_to_frame(group_response, group, notes)
            if _is_response(group_response)
            else pd.DataFrame()
        )
        if part.empty or "ID" not in part.columns:
            errors.append(f"{group_label}: empty. The rest of the month is kept.")
            failed.append(_group_name(group))
            continue
        # Same trap as the unsplit merge: ``keep="last"`` picks by position and
        # can keep the row where a measure is null. Collapse by value instead.
        part = _collapse_ids(part)
        keep = ["ID", *[column for column in group if column in part.columns]]
        merged = merged.merge(part.loc[:, keep], on="ID", how="left")
    if failed and notes is not None:
        notes.append(
            f"{label}: {len(failed)} measure group(s) did not arrive ("
            + ", ".join(failed)
            + "). The month is shown without them and will be requested again "
            "rather than cached incomplete."
        )
    cache_ok = not failed and not _missing_items(merged, required_columns())
    return merged, cache_ok


def _finalize_snapshot(frame: pd.DataFrame, as_of: str, kind: str, notes: list[str]) -> pd.DataFrame:
    prepared = prepare_members(frame, notes)
    if prepared.empty:
        return prepared
    prepared["AS_OF_DATE"] = as_of
    prepared["SNAPSHOT_KIND"] = kind
    for column in NUMERIC_COLUMNS:
        if column in prepared.columns:
            prepared[column] = pd.to_numeric(prepared[column], errors="coerce")
    return prepared


def fetch_index_payload(index_ticker: str, selected_date: str, progress=None, today=None, cache_root=None) -> IndexPayload:
    """Request the selected month-end and the previous month-end only."""
    ticker = validate_index_ticker(index_ticker)
    as_of_today = pd.Timestamp.today().normalize() if today is None else today
    allowed = [value for _label, value in month_end_choices(as_of_today, MONTH_END_CHOICES)]
    comparison = comparison_for(selected_date, as_of_today, allowed)
    payload = IndexPayload(
        index_ticker=ticker,
        previous_date=comparison.previous_date,
        selected_date=comparison.selected_date,
        kind=comparison.kind,
    )

    def note(message: str) -> None:
        if progress is not None:
            progress(message)

    jobs = [
        (comparison.previous_date, "historical"),
        (comparison.selected_date, comparison.kind),
    ]
    bq = None
    seen = set()
    for as_of, kind in jobs:
        if as_of in seen:
            continue
        seen.add(as_of)
        if kind == "historical":
            cached = load_historical(ticker, as_of, cache_root)
            if cached is not None:
                prepared = _finalize_snapshot(cached, as_of, kind, payload.notes)
                if not prepared.empty and prepared["Weight"].notna().any():
                    absent = _missing_items(prepared, ITEM_NAMES)
                    payload.snapshots[as_of] = prepared
                    payload.statuses[as_of] = "ok" if not absent else "partial"
                    note(f"Cache hit {as_of}: {len(prepared)} bonds.")
                    if absent:
                        payload.notes.append(
                            f"{as_of}: cached month was stored without "
                            + ", ".join(absent)
                            + "."
                        )
                    continue
        if bq is None:
            bq = _require_bql()
        note(f"Requesting {kind} members for {as_of}...")
        live, cache_ok = _fetch_live(bq, ticker, as_of, payload.errors, payload.notes)
        prepared = _finalize_snapshot(live, as_of, kind, payload.notes)
        if prepared.empty or not prepared["Weight"].notna().any():
            payload.statuses[as_of] = "unavailable"
            payload.snapshots[as_of] = pd.DataFrame()
            note(f"{as_of} unavailable.")
            continue
        payload.snapshots[as_of] = prepared
        # A response that lost a required item is still usable, but it must not
        # be presented as a clean "ok". The transition keeps the numbers and
        # carries a warning, so the screen never shows a green update while a
        # column is fabricated downstream.
        #
        # A column that is present but has no value anywhere is the same kind of
        # defect as a missing column, and worse: it survives to the cache as the
        # "(blank)" sentinel and is replayed on every later Update with no note.
        # The audit on 2026-11-02 showed exactly that happening with
        # ``status="ok"``. Both cases now report "partial", and the cache
        # refuses the frame.
        absent = _missing_items(prepared, ITEM_NAMES)
        empty_identity = [
            column
            for column in required_columns()
            if column not in ("ID", "Weight")
            and column in prepared.columns
            and not column_has_usable_value(prepared[column], column)
        ]
        payload.statuses[as_of] = "ok" if not absent and not empty_identity else "partial"
        if empty_identity:
            payload.notes.append(
                f"{as_of}: {len(empty_identity)} identity column(s) arrived with every "
                "value empty (" + ", ".join(empty_identity) + "). "
                "The month is marked partial and is not written to the cache."
            )
        if kind == "historical":
            today_iso = as_of_today.strftime("%Y-%m-%d")
            if empty_identity:
                # Refuse the cache outright. A blank sentinel frame would be
                # replayed by the next Update as a clean answer. The note was
                # already written with the status above.
                continue
            if not cache_ok:
                payload.notes.append(
                    f"{as_of}: an identity item did not parse and the snapshot "
                    "was not written to the cache."
                )
            elif as_of >= today_iso:
                # The effective date may not be published yet. Whatever
                # members() returned then cannot be verified later, so it must
                # never become the permanent answer for that month-end.
                payload.notes.append(
                    f"{as_of}: snapshot is not older than today and was not "
                    "written to the cache."
                )
            else:
                try:
                    save_historical(ticker, as_of, prepared, cache_root)
                except Exception as exc:
                    payload.notes.append(
                        f"{as_of}: cache write skipped ({type(exc).__name__}: {exc})."
                    )
        note(f"{as_of}: {len(prepared)} bonds.")
    align_snapshot_labels(
        payload.snapshots.get(payload.previous_date),
        payload.snapshots.get(payload.selected_date),
    )
    conflicts = rating_class_conflicts(
        payload.snapshots.get(payload.previous_date),
        payload.snapshots.get(payload.selected_date),
    )
    if conflicts:
        # Should be impossible after alignment. If it ever happens, say so
        # instead of letting one bond answer to two Rating selections.
        payload.notes.append(
            f"{len(conflicts)} bond(s) carry two Rating classifications: "
            + ", ".join(conflicts[:5])
            + ("..." if len(conflicts) > 5 else "")
            + "."
        )
    return payload


def fetch_index_long_name(index_ticker: str) -> str:
    """long_comp_name for one Index yellow key. Empty means the field was blank.

    This is not a security search and not the bond Issuer column. The
    operator confirmed on 2026-10-30 that this item is the index title.
    """
    ticker = validate_index_ticker(index_ticker)
    bq = _require_bql()
    request = bql.Request(
        ticker,
        {"Index Name": bq.data.long_comp_name()},
        with_params={"mode": "cached"},
    )
    response = bq.execute(request)
    frame = _response_to_frame(response, ("Index Name",))
    if frame is None or frame.empty:
        return ""
    column = "Index Name" if "Index Name" in frame.columns else None
    if column is None:
        others = [name for name in frame.columns if str(name).upper() not in {"ID", "DATE"}]
        if len(others) != 1:
            return ""
        column = others[0]
    values = frame[column].dropna().astype(str).str.strip()
    values = values[~values.str.casefold().isin({"", "nan", "none", "nat"})]
    if values.empty:
        return ""
    return str(values.iloc[0])
