"""CSV snapshot cache. Historical months are immutable for one field contract.

The projected month is not written here. pyarrow is not required.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .config import (
    CACHE_DIR_NAME,
    COUNTRY_NAME_OVERRIDES,
    MBS_TBA_LABEL,
    MUNICIPAL_LABEL,
    RATING_MISSING,
)
from .engine import column_has_usable_value
from .field_library import (
    ANALYTICS_NAMES,
    ITEM_NAMES,
    NUMERIC_COLUMNS,
    STRING_COLUMNS,
)

# Labels are written into the cache already classified. If a label rule changes
# and this token did not, one month-end keeps the old label while a fresh one
# uses the new one, and a single country splits into two buckets.
LABEL_CONTRACT = "|".join(
    [
        *(f"{source}>{target}" for source, target in COUNTRY_NAME_OVERRIDES),
        MBS_TBA_LABEL,
        MUNICIPAL_LABEL,
        RATING_MISSING,
    ]
)

# Derived from the frozen item list. Adding, removing, or renaming an item
# changes this token, so stale cache entries are ignored on the next load.
FIELD_CONTRACT = "|".join(ITEM_NAMES) + "||" + LABEL_CONTRACT

# What the stored frame *means*, not which items it holds. A change to the
# pipeline that changes the shape of a saved snapshot has to move this token,
# because the item list and the labels look identical either way.
#
# The 2026-11-02 defect is the reason this exists. Merging response items on
# ``["ID", "DATE"]`` blanked every column that arrived without a date, and the
# old build wrote those months to this cache. Fixing the merge did not change
# the item list, so ``FIELD_CONTRACT`` stayed equal and every poisoned month
# was still loaded and displayed: Country came back as 194 of 200 "(blank)"
# with only the ID-driven MBS/TBA and Municipal rows classified. The fix could
# not run because the month was never re-requested.
#
# Bump this whenever a stored snapshot would be wrong under the new code.
CACHE_GENERATION = "id-only-merge-2"


def required_columns() -> tuple[str, ...]:
    """Columns a reusable snapshot must carry.

    The identity block and Weight, not the analytics block. An identity
    column that did not parse changes who the row is and makes the month
    unusable, so it blocks the cache. An analytics column that did not parse
    leaves the book intact and only one measure blank, and the reload path
    reports it by name; blocking the cache for that case was a regression on
    2026-11-02, because it made a month that answered once re-request every
    time and removed the only cheap recovery from a timeout.
    """
    return ("ID", *[name for name in ITEM_NAMES if name not in ANALYTICS_NAMES])


def cache_dir(root: Path | None = None) -> Path:
    """Where cached month-ends live. Does not create it.

    Creating it here meant every Update started with a ``mkdir`` even when the
    month was already cached and nothing would be written, so a project folder
    that the Desktop made read-only failed the whole Update with
    ``PermissionError`` before any data was read. Only the write path creates
    the folder now; a missing folder simply reads as "no cached month".
    """
    base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    return base / CACHE_DIR_NAME


def _manifest_path(root: Path | None) -> Path:
    return cache_dir(root) / "manifest.json"


def _read_manifest(root: Path | None) -> dict:
    path = _manifest_path(root)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_manifest(payload: dict, root: Path | None) -> None:
    path = _manifest_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def safe_name(text: str) -> str:
    """Return a file-name-safe token. Book labels such as ``MBS/TBA`` need it."""
    token = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(text))
    return token or "unnamed"


def _cache_key(index_ticker: str, as_of: str) -> str:
    return f"{index_ticker}|{as_of}"


def _file_name(index_ticker: str, as_of: str) -> str:
    return f"{safe_name(index_ticker)}_{as_of}.csv"


def export_paths(
    index_ticker: str,
    previous_date: str,
    latest_date: str,
    book: str,
    root: Path | None = None,
) -> tuple[Path, Path]:
    """Return the changes CSV path and the summary CSV path for one export.

    Every component is sanitized: the book label ``MBS/TBA`` contains a path
    separator when it is not escaped.
    """
    folder = cache_dir(root)
    stem = "_".join(
        (
            safe_name(index_ticker),
            safe_name(previous_date),
            safe_name(latest_date),
            safe_name(book),
        )
    )
    return folder / f"{stem}_changes.csv", folder / f"{stem}_summary.csv"


def load_historical(index_ticker: str, as_of: str, root: Path | None = None):
    """Return a cached frame, or None when the field contract or Weight misses."""
    manifest = _read_manifest(root)
    entry = manifest.get(_cache_key(index_ticker, as_of))
    if not isinstance(entry, dict):
        return None
    if entry.get("fields") != FIELD_CONTRACT or not entry.get("has_weight"):
        return None
    # A month written before the merge key became ID-only holds a frame where
    # most bonds are "(blank)". It passes every other check, so without this
    # token it would keep being served and the fix would never run.
    if entry.get("generation") != CACHE_GENERATION:
        return None
    recorded = entry.get("columns")
    if not isinstance(recorded, list):
        return None
    if any(name not in recorded for name in required_columns()):
        return None
    path = cache_dir(root) / str(entry.get("file", ""))
    if not path.exists():
        return None
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    if "ID" not in frame.columns or "Weight" not in frame.columns:
        return None
    for column in NUMERIC_COLUMNS:
        if column in frame.columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
    if frame["Weight"].notna().sum() == 0:
        return None
    # A cached frame can carry identity columns that are all empty. The
    # manifest only records which columns existed, so such a month used to be
    # reloaded from cache as a sheet where every bond was "(blank)" and there
    # was no way to recover by pressing Update. Refuse it and re-request.
    # The test is "no identity value at all": one column may be legitimately
    # empty for the whole book (a perpetual-only set has no tenor), but a real
    # snapshot never has every single one of them empty.
    # ``column_has_usable_value`` is used rather than a literal "" test because
    # ``prepare_members`` stores "(blank)" as the sentinel: a plain
    # ``replace("", pd.NA)`` check reads that sentinel as a real value and never
    # fires on a frame that this app actually wrote.
    identity = [
        column
        for column in required_columns()
        if column not in ("ID", "Weight") and column in frame.columns
    ]
    if identity and not any(
        column_has_usable_value(frame[column], column) for column in identity
    ):
        return None
    frame["ID"] = frame["ID"].astype(str)
    return frame


def save_historical(index_ticker: str, as_of: str, frame: pd.DataFrame, root: Path | None = None) -> None:
    """Persist one successful historical snapshot. Empty frames are refused."""
    if frame is None or frame.empty or "Weight" not in frame.columns:
        raise ValueError(f"Refusing to cache an unusable snapshot: {index_ticker} {as_of}")
    if frame["Weight"].notna().sum() == 0:
        raise ValueError(f"Refusing to cache a snapshot without weights: {index_ticker} {as_of}")
    missing = [name for name in required_columns() if name not in frame.columns]
    if missing:
        raise ValueError(
            f"Refusing to cache a partially parsed snapshot: {index_ticker} {as_of} "
            f"missing {', '.join(missing)}"
        )
    name = _file_name(index_ticker, as_of)
    folder = cache_dir(root)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    stored = frame.copy()
    for column in STRING_COLUMNS:
        if column in stored.columns:
            stored[column] = stored[column].fillna("").astype(str)
    stored.to_csv(path, index=False, encoding="utf-8")
    manifest = _read_manifest(root)
    manifest[_cache_key(index_ticker, as_of)] = {
        "fields": FIELD_CONTRACT,
        "generation": CACHE_GENERATION,
        "file": name,
        "rows": int(len(stored)),
        "has_weight": True,
        "columns": [column for column in ("ID", *ITEM_NAMES, "AS_OF_DATE", "SNAPSHOT_KIND") if column in stored.columns],
    }
    _write_manifest(manifest, root)
