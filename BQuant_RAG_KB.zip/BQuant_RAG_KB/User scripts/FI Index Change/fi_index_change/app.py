"""Update-only dashboard for fixed-income index adds and exits."""

from __future__ import annotations

from html import escape

import pandas as pd
import plotly.graph_objects as go
import ipywidgets as widgets

from .config import (
    CHART_WIDTH_PX,
    DEFAULT_BOOK,
    DEFAULT_INDEX,
    DISPLAY_ROW_CAP,
    FILTER_GAP_PX,
    FILTER_WIDTHS,
    MONTH_END_CHOICES,
    PIN_DETAIL_COLUMN,
    PIN_DETAIL_ROW_HEADER_MAX_PX,
    PIN_FIRST_COLUMN,
    PIN_ROW_HEADER_MAX_PX,
    PIN_ROW_HEADER_MIN_PX,
)
from .data import fetch_index_long_name, fetch_index_payload
from .engine import (
    DIMENSIONS,
    MEMBERSHIP_LICENSE_MESSAGE,
    apply_dimension_filters,
    book_counts,
    book_unchanged,
    bucket_chart_rows,
    build_transition,
    caption_html,
    comparison_for,
    currency_choices,
    export_display_frame,
    default_month_end,
    filter_choices,
    grid_display_frame,
    membership_access_failure,
    month_end_choices,
    selection_status,
    signed_change_frame,
    top_add_exit_rows,
    summarize,
    change_export_frame,
    validate_index_ticker,
)

try:
    from ipydatagrid import DataGrid
except ImportError:
    DataGrid = None


# The app header. Kept as two plain literals because the local preview reads
# them with ast, so no version stamp and no build step can creep back in.
APP_TITLE = "Fixed Income Index Constituent Change"
TITLE_HTML = "<p style='font-size:20px;font-weight:700;margin:0 0 8px 0'>Fixed Income Index Constituent Change</p>"

# Bloomberg Desktop runs a dark theme. Charts stay transparent so they inherit
# that background; text is light and the bar colours stay as they were.
CHART_FONT_COLOR = "#f5f5f5"
CHART_MUTED_COLOR = "#b8b8b8"
CHART_GRID_COLOR = "#3a3a3a"
CHART_ZERO_COLOR = "#9a9a9a"
# Widest the chart may be: 80% of a 1,920 px full-screen view. It is narrower
# than the filter row on purpose, so it does not run to the last filter box.
CHART_WIDTH = f"{CHART_WIDTH_PX}px"


BOND_COLUMNS = (
    "Action",
    "ID",
    "Name",
    "Issuer",
    "ISIN",
    "Weight",
    "Country",
    "Sector",
    "Tenor Bucket",
    "Tenor",
    "Rating",
    "Rating Bucket",
    "Currency",
    "Coupon",
    "OAS",
    "Z-Spread",
    "I-Spread",
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
    "Yield",
    "YTM",
    "YTW",
    "Maturity",
    "Book",
    "Security Type",
    "AS_OF_DATE",
)

# Order of the vertical bond field table under the detail chart. The two copy
# tables (Export, Full Position) do not use this order; they take theirs from
# `engine.EXPORT_COLUMNS` and `POSITION_COLUMNS`.
DETAIL_FIELDS = (
    "Action",
    "Weight",
    "ID",
    "Name",
    "Issuer",
    "ISIN",
    "SEDOL",
    "Country",
    "Sector",
    "Tenor Bucket",
    "Tenor",
    "Rating",
    "Rating Bucket",
    "Currency",
    "Coupon",
    "OAS",
    "Z-Spread",
    "I-Spread",
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
    "Yield",
    "YTM",
    "YTW",
    "Maturity",
    "Book",
    "Security Type",
    "AS_OF_DATE",
)

DETAIL_LIST_COLUMNS = ("Action", "ID", "Name", "Weight", "Country", "Sector", "Rating", "Currency")
# Pruned on 2026-11-02 to match the request in field_library.py. The filter
# boxes only offer a field the Update request still fetches.
SPREAD_OPTIONS = ("OAS", "Z-Spread", "I-Spread")
# Kept as a plain constant even though it is now empty: build_preview.py reads
# it with ast, and a label map can be added again without changing the reader.
SPREAD_LABELS = {}

DURATION_FIELDS = (
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
)
YIELD_FIELDS = (
    "Yield",
    "YTM",
    "YTW",
)

DURATION_LABELS = {
    "Duration": "Duration",
    "Modified Duration": "Modified duration",
    "Effective Duration": "Effective duration",
    "OASD": "Option adjusted spread duration",
}
YIELD_LABELS = {
    "Yield": "Yield",
    "YTM": "Yield to maturity",
    "YTW": "Yield to worst",
}

# Full constituent table. Same columns as the CSV export minus Action (which
# only makes sense for a change row); AS_OF_DATE identifies the month-end.
POSITION_COLUMNS = (
    "ID",
    "Name",
    "Issuer",
    "ISIN",
    "SEDOL",
    "Country",
    "Sector",
    # Same order as the changes table: Weight after Sector, printed as a percent.
    "Weight",
    "Tenor Bucket",
    "Tenor",
    "Rating",
    "Rating Bucket",
    "Currency",
    "Coupon",
    "OAS",
    "Z-Spread",
    "I-Spread",
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
    "Yield",
    "YTM",
    "YTW",
    "Maturity",
    "Book",
    "Security Type",
    "AS_OF_DATE",
)

FILTER_COLUMNS = (
    ("Country", "Country"),
    ("Sector", "Sector"),
    ("Tenor", "Tenor Bucket"),
    ("Rating", "Rating Bucket"),
    ("Currency", "Currency"),
)
FILTER_LABELS = {column: label for label, column in FILTER_COLUMNS}

# First option in every dimension filter, and the value the widget starts on.
# A picked value always wins over it, so "(All)" plus "US" still means US.
ALL_FILTER_LABEL = "(All)"

def _phase_markup(phase: str) -> str:
    """First status word. Idle and Please Click Update are red. Updated is green."""
    if phase in {"Idle", "Please Click Update"}:
        color = "#c62828"
    elif phase == "Updated":
        color = "#1b7f37"
    else:
        return f"<b>{escape(phase)}</b>"
    return f"<b style=\"color:{color}\">{escape(phase)}</b>"


def _environment_markup(activity: str) -> str:
    """Second status line. Processing is red. Idle is green."""
    color = "#c62828" if activity == "Processing" else "#1b7f37"
    return f"<p style=\"margin:2px 0;color:{color}\">Environment: {escape(activity)}</p>"


def _fit_column_widths(frame: pd.DataFrame) -> dict[str, int]:
    """Pixel width from the header and the longest cell. The grid scrolls past the chart width."""
    widths = {}
    for column in frame.columns:
        header = len(str(column))
        if frame.empty:
            longest = 0
        else:
            longest = int(frame[column].map(lambda value: len("" if value is None else str(value))).max())
        widths[str(column)] = min(420, max(72, max(header, longest) * 8 + 28))
    return widths


GRID_UNAVAILABLE_TEXT = (
    "<p style='margin:4px 0;color:#b00'><b>ipydatagrid is unavailable:</b> "
    "the click-to-detail panel is disabled in this kernel.</p>"
)


def _pinned_view(
    view: pd.DataFrame,
    pin_column: str | None = None,
    max_px: int | None = None,
) -> tuple[pd.DataFrame, int | None]:
    """Move ``pin_column`` into the row-header gutter so it stays visible.

    ipydatagrid 1.4.0 has no frozen-column trait, and the row-header gutter is
    the only part of the grid that does not scroll sideways. The column is not
    lost: its labels become the index, and the body keeps every other column in
    its original order. ``pin_column=None`` pins the first column.
    Returns the frame plus the gutter width, or ``(view, None)`` when the pin is
    off, the frame is empty, or only one column would be left.
    """
    body = view.reset_index(drop=True)
    limit = PIN_ROW_HEADER_MAX_PX if max_px is None else int(max_px)
    if not PIN_FIRST_COLUMN or view.empty or len(view.columns) < 2:
        return body, None
    columns = [str(name) for name in view.columns]
    wanted = columns[0] if pin_column is None else str(pin_column)
    position = columns.index(wanted) if wanted in columns else 0
    first = columns[position]
    labels = ["" if pd.isna(value) else str(value) for value in view.iloc[:, position]]
    longest = max([len(first), *(len(label) for label in labels)] or [len(first)])
    gutter = max(PIN_ROW_HEADER_MIN_PX, min(limit, longest * 8 + 28))
    keep = [index for index in range(len(columns)) if index != position]
    body = view.iloc[:, keep].copy()
    body.index = pd.Index(labels, name=first)
    return body, int(gutter)


def _fmt(value, digits=2) -> str:
    if value is None or pd.isna(value):
        return "—"
    return f"{float(value):,.{digits}f}"


def _info_box(content: str, tone: str = "ok") -> str:
    """Bold summary box. Same visual language as the selection line."""
    palettes = {
        "ok": ("#e8f5e9", "#c8e6c9", "#1b5e20"),
        "warn": ("#fff8e1", "#ffe082", "#8a5a00"),
        "error": ("#ffebee", "#ffcdd2", "#b71c1c"),
        "neutral": ("#f5f5f5", "#e0e0e0", "#333333"),
    }
    background, border, color = palettes.get(tone, palettes["neutral"])
    return (
        f"<div style='margin:4px 0;padding:6px 10px;background:{background};"
        f"border:1px solid {border};color:{color};font-weight:700'>"
        f"{content}</div>"
    )


class FIIndexChangeApp:
    """Thin controller. BQL runs only from the Update button."""

    def __init__(self):
        self._events_bound = False
        self._running = False
        self._rendering = False
        self.payload = None
        self.transition = None
        self._index_name_cache = {}
        self._looking_up_name = False
        self._build_widgets()
        self._refresh_index_chrome()
        self._refresh_selection_line()
        self._bind_events()

    def _build_widgets(self):
        style = {"description_width": "90px"}
        self.index_input = widgets.Text(
            value=DEFAULT_INDEX,
            placeholder="Index ticker",
            continuous_update=True,
            layout=widgets.Layout(width="280px"),
        )
        self.index_name = widgets.HTML()
        self.index_stack = widgets.HBox(
            [
                widgets.Label("Index", layout=widgets.Layout(width="90px")),
                widgets.VBox(
                    [self.index_input, self.index_name],
                    layout=widgets.Layout(align_items="flex-start", overflow="visible"),
                ),
            ],
            layout=widgets.Layout(align_items="flex-start", overflow="visible"),
        )
        self.selection_line = widgets.HTML()
        self.update_button = widgets.Button(description="Update", button_style="primary", icon="refresh")
        self.status = widgets.HTML()
        self.log = widgets.Output(layout=widgets.Layout(max_height="140px", overflow_y="auto"))
        today = pd.Timestamp.today().normalize()
        self.month_end_input = widgets.Dropdown(
            description="Month-end",
            options=month_end_choices(today, MONTH_END_CHOICES),
            value=default_month_end(today),
            style=style,
            layout=widgets.Layout(width="280px"),
        )
        self.dimension_input = widgets.Dropdown(
            description="Dimension",
            options=list(DIMENSIONS),
            value="Country",
            style=style,
            layout=widgets.Layout(width="240px"),
        )
        self.action_input = widgets.Dropdown(
            description="Bonds",
            options=["Add", "Exit", "Add and Exit"],
            value="Add and Exit",
            style=style,
            layout=widgets.Layout(width="240px"),
        )
        self.filters = {}
        for label, _column in FILTER_COLUMNS:
            # Country/Sector are wider; the chart width is their total plus gaps.
            width = FILTER_WIDTHS.get(label, 220)
            self.filters[label] = widgets.SelectMultiple(
                description=label,
                options=[ALL_FILTER_LABEL],
                value=(ALL_FILTER_LABEL,),
                rows=10,
                style=style,
                layout=widgets.Layout(width=f"{width}px", margin=f"0 {FILTER_GAP_PX}px 0 0"),
            )
        self.spread_select = widgets.SelectMultiple(
            description="Spread",
            options=[
                (SPREAD_LABELS.get(option, option), option)
                for option in (ALL_FILTER_LABEL, *SPREAD_OPTIONS)
            ],
            value=("OAS",),
            rows=10,
            style=style,
            layout=widgets.Layout(
                width=f"{FILTER_WIDTHS.get('Spread', 220)}px",
                margin=f"0 {FILTER_GAP_PX}px 0 0",
            ),
        )
        self.duration_select = widgets.SelectMultiple(
            description="Duration",
            options=[
                (DURATION_LABELS.get(option, option), option)
                for option in (ALL_FILTER_LABEL, *DURATION_FIELDS)
            ],
            value=("Duration",),
            rows=10,
            style=style,
            layout=widgets.Layout(
                width=f"{FILTER_WIDTHS.get('Duration', 260)}px",
                margin=f"0 {FILTER_GAP_PX}px 0 0",
            ),
        )
        self.yield_select = widgets.SelectMultiple(
            description="Yield",
            options=[
                (YIELD_LABELS.get(option, option), option)
                for option in (ALL_FILTER_LABEL, *YIELD_FIELDS)
            ],
            value=("Yield",),
            rows=10,
            style=style,
            layout=widgets.Layout(
                width=f"{FILTER_WIDTHS.get('Yield', 260)}px",
                margin=f"0 {FILTER_GAP_PX}px 0 0",
            ),
        )
        self.book_select = widgets.SelectMultiple(
            description="Book",
            options=[ALL_FILTER_LABEL, "Standard", "MBS/TBA"],
            value=(ALL_FILTER_LABEL,),
            rows=10,
            style=style,
            layout=widgets.Layout(
                width=f"{FILTER_WIDTHS.get('Book', 220)}px",
                margin=f"0 {FILTER_GAP_PX}px 0 0",
            ),
        )
        self.headline = widgets.HTML()
        self.caption = widgets.HTML(value=caption_html())
        self.dimension_figure = go.FigureWidget(
            data=[
                go.Bar(name="Add weight", orientation="h", marker_color="#2a9d8f"),
                go.Bar(name="Exit weight", orientation="h", marker_color="#e76f51"),
            ]
        )
        self.dimension_figure.update_layout(
            barmode="relative",
            width=CHART_WIDTH_PX,
            autosize=False,
            height=360,
            margin=dict(l=140, r=16, t=48, b=64),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color=CHART_FONT_COLOR),
            title=dict(
                text="Add (right) and Exit (left) weight by dimension",
                font=dict(color=CHART_FONT_COLOR),
            ),
            xaxis=dict(
                title=dict(
                    text="Weight (percent points) \u2014 Add right, Exit left, Bucket summary order",
                    font=dict(color=CHART_MUTED_COLOR),
                ),
                tickfont=dict(color=CHART_MUTED_COLOR),
                gridcolor=CHART_GRID_COLOR,
                zeroline=True,
                zerolinecolor=CHART_ZERO_COLOR,
            ),
            yaxis=dict(
                autorange="reversed",
                tickfont=dict(color=CHART_FONT_COLOR),
                gridcolor=CHART_GRID_COLOR,
            ),
            legend=dict(
                orientation="h",
                yanchor="top",
                y=-0.12,
                x=0,
                xanchor="left",
                font=dict(color=CHART_MUTED_COLOR),
                bgcolor="rgba(0,0,0,0)",
            ),
        )
        self.dimension_chart = widgets.HBox(
            [self.dimension_figure],
            layout=widgets.Layout(width=CHART_WIDTH),
        )
        self.summary_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.detail_title = widgets.HTML("<b style='font-size:16px'>Detail</b><br>Click an add, an exit, or a bucket.")
        self.detail_table = widgets.HTML("")
        self.detail_fields = widgets.HTML("")
        self.detail_figure = go.FigureWidget(data=[go.Bar(orientation="h", marker_color="#2a9d8f")])
        self.detail_figure.update_layout(
            width=CHART_WIDTH_PX,
            autosize=False,
            height=300,
            margin=dict(l=140, r=16, t=40, b=48),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color=CHART_FONT_COLOR),
            xaxis=dict(
                title=dict(
                    text="Weight (percent points) \u2014 Add right, Exit left, largest Add at top",
                    font=dict(color=CHART_MUTED_COLOR),
                ),
                tickfont=dict(color=CHART_MUTED_COLOR),
                gridcolor=CHART_GRID_COLOR,
                zeroline=True,
                zerolinecolor=CHART_ZERO_COLOR,
            ),
            yaxis=dict(
                autorange="reversed",
                tickfont=dict(color=CHART_FONT_COLOR),
                gridcolor=CHART_GRID_COLOR,
            ),
            title=dict(
                text="Weight (Add right / Exit left)",
                font=dict(color=CHART_FONT_COLOR),
            ),
        )
        self.detail_chart = widgets.HBox(
            [self.detail_figure],
            layout=widgets.Layout(width=CHART_WIDTH),
        )
        self.detail_bonds_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.export_view = widgets.Dropdown(
            description="Data",
            options=[("Changes", "changes"), ("Summary", "summary")],
            value="changes",
            layout=widgets.Layout(width="260px"),
        )
        self.export_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.export_box.children = (widgets.HTML("<p>No comparison loaded.</p>"),)
        self.export_body = widgets.VBox(
            [
                widgets.HTML(
                    "<p style='margin:4px 0;color:#666'>Pick Changes or Summary, then select "
                    "the whole table, copy it, and paste it into Excel. The first data row "
                    "repeats the column names so the header is kept. No file is written.</p>"
                ),
                self.export_view,
                self.export_box,
            ],
            layout=widgets.Layout(width="100%"),
        )
        self.position_view = widgets.Dropdown(
            description="Date",
            options=[("Start date", "start"), ("End date", "end")],
            value="start",
            layout=widgets.Layout(width="320px"),
        )
        self.positions_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.positions_box.children = (widgets.HTML("<p>No comparison loaded.</p>"),)
        self.positions_body = widgets.VBox(
            [
                widgets.HTML(
                    "<p style='margin:4px 0;color:#666'>Pick Start date or End date to list "
                    "every constituent of the full index at that month-end, including "
                    "Standard and MBS/TBA. Same columns as the CSV export (minus the "
                    "changes-only Action); AS_OF_DATE is the month-end. The first data row "
                    "repeats the column names so a copy/paste keeps the header. No file is "
                    "written.</p>"
                ),
                self.position_view,
                self.positions_box,
            ],
            layout=widgets.Layout(width="100%"),
        )
        self._export_frames = {}
        self._export_columns = {}
        self._export_key = None
        self._export_source = None
        self._position_frames = {}
        self._positions_key = None
        self._payload_source = None
        self.tabs = widgets.Tab(
            children=[widgets.VBox(), self.export_body, self.positions_body],
            titles=("Main", "Export", "Full Position"),
            layout=widgets.Layout(width="100%"),
        )
        self.tabs.selected_index = 0
        self._set_status("Idle", "Click Update to request data.", "Idle")

    def _bind_events(self):
        if self._events_bound:
            return
        self.update_button.on_click(self._on_update)
        self.index_input.observe(self._on_index_edit, names="value")
        self.month_end_input.observe(self._on_month_end_change, names="value")
        self.dimension_input.observe(self._on_view_change, names="value")
        self.book_select.observe(self._on_view_change, names="value")
        self.action_input.observe(self._on_view_change, names="value")
        self.spread_select.observe(self._on_view_change, names="value")
        self.duration_select.observe(self._on_view_change, names="value")
        self.yield_select.observe(self._on_view_change, names="value")
        self.export_view.observe(self._on_export_view_change, names="value")
        self.position_view.observe(self._on_position_view_change, names="value")
        for widget in self.filters.values():
            widget.observe(self._on_view_change, names="value")
        self._events_bound = True

    def render(self):
        # Idempotent re-bind. A status refresh or a partial rebuild must never
        # leave the bucket table and the bond table without click handlers.
        self._bind_events()
        self._refresh_caption()
        header = widgets.HBox(
            [self.index_stack, self.month_end_input, self.update_button],
            layout=widgets.Layout(flex_flow="row wrap", align_items="flex-start"),
        )
        controls = widgets.HBox(
            [self.dimension_input, self.action_input],
            layout=widgets.Layout(flex_flow="row wrap"),
        )
        filters = widgets.HBox(
            [*self.filters.values(), self.spread_select, self.duration_select, self.yield_select, self.book_select],
            layout=widgets.Layout(flex_flow="row wrap"),
        )
        detail = widgets.VBox(
            [
                self.detail_title,
                self.detail_table,
                self.detail_chart,
                self.detail_bonds_box,
                self.detail_fields,
            ],
            layout=widgets.Layout(width="100%", border="1px solid #ddd", padding="8px"),
        )
        body = widgets.VBox(
            [
                self.headline,
                self.dimension_chart,
                widgets.HTML(
                    "<b style='font-size:16px'>Bucket summary</b><br>"
                    "<span style='color:#666;font-size:12px'><b>Begin</b> = previous "
                    "month-end, <b>End</b> = selected month-end. Add/Exit are ID "
                    "membership changes.<br>"
                    "<b>Turnover (index %)</b> = Exit Weight (prior month-end) + "
                    "Add Weight (selected month-end) &times; (ending index MV / "
                    "beginning index MV).<br>"
                    "<b>Turnover Rate (%)</b> = Turnover (index %) / Begin "
                    "Weight &times; 100; blank when Begin Weight is 0.</span>"
                ),
                self.summary_box,
                detail,
            ],
            layout=widgets.Layout(width="100%"),
        )
        main_tab = widgets.VBox([
            header,
            self.selection_line,
            self.status,
            self.log,
            controls,
            filters,
            self.caption,
            body,
        ])
        selected = self.tabs.selected_index if self.tabs.selected_index in (0, 1, 2) else 0
        self.tabs.children = (main_tab, self.export_body, self.positions_body)
        self.tabs.set_title(0, "Main")
        self.tabs.set_title(1, "Export")
        self.tabs.set_title(2, "Full Position")
        self.tabs.selected_index = selected
        return widgets.VBox([widgets.HTML(TITLE_HTML), self.tabs])

    def _refresh_caption(self) -> None:
        """Footnotes carry the loaded as-of dates once a comparison exists."""
        previous = self.payload.previous_date if self.payload is not None else None
        selected = self.payload.selected_date if self.payload is not None else None
        text = caption_html(previous, selected)
        if DataGrid is None:
            text = text + GRID_UNAVAILABLE_TEXT
        self.caption.value = text

    def _set_status(self, phase: str, detail: str = "", activity: str | None = None) -> None:
        if activity is None:
            activity = "Processing" if self._running else "Idle"
        detail_text = f" {escape(detail)}" if detail else ""
        self.status.value = (
            f"<p style='margin:2px 0'>{_phase_markup(phase)}{detail_text}</p>"
            + _environment_markup(activity)
        )

    def _progress(self, message: str) -> None:
        self._set_status("Loading", message, "Processing")
        with self.log:
            print(message)

    def _on_update(self, _event) -> None:
        if self._running:
            return
        self._running = True
        self.update_button.disabled = True
        self.log.clear_output()
        try:
            self._set_status("Loading", "Checking the index and the month-end.", "Processing")
            self._refresh_month_end_options()
            self.payload = fetch_index_payload(
                self.index_input.value,
                self.month_end_input.value,
                progress=self._progress,
            )
            self._refresh_caption()
            comparison = comparison_for(
                self.payload.selected_date,
                pd.Timestamp.today().normalize(),
                [self.payload.previous_date, self.payload.selected_date],
            )
            self.transition = build_transition(
                self.payload.snapshots,
                comparison,
                self.payload.statuses,
                index_mv_ratio=self.payload.index_mv_ratio,
                turnover_basis=self.payload.turnover_basis,
            )
            self._refresh_filter_options()
            self._set_status("Loading", "Building the comparison.", "Processing")
            for line in self.payload.errors:
                self._progress(line)
            for line in self.payload.notes:
                self._progress(line)
            license_hit = any(membership_access_failure(line) for line in self.payload.errors)
            self._refresh_selection_line()
            self._render()
            self._show_license_failure()
            if not license_hit:
                self._set_status(
                    "Updated",
                    (
                        f"Loaded {self.payload.previous_date} → {self.payload.selected_date} "
                        f"({self.payload.kind})."
                    ),
                    "Idle",
                )
        except Exception as exc:
            self._show_failed_update(exc)
            with self.log:
                print(f"{type(exc).__name__}: {exc}")
        finally:
            self._running = False
            self.update_button.disabled = False
            self._maybe_lookup_index_name(self.index_input.value)

    def _show_license_failure(self) -> None:
        if self.payload is None:
            return
        if not any(membership_access_failure(line) for line in self.payload.errors):
            return
        self._set_status(
            "No access",
            f"{MEMBERSHIP_LICENSE_MESSAGE} for {self.payload.index_ticker}. The original error is in the log.",
            "Idle",
        )
        self.headline.value = _info_box(
            f"<b>{escape(MEMBERSHIP_LICENSE_MESSAGE)}</b><br>"
            f"{escape(self.payload.index_ticker)} membership was refused. "
            "This is not an empty add/exit list.",
            "error",
        )

    def _show_failed_update(self, exc: Exception) -> None:
        """Drop stale state so an error cannot sit above an old success screen."""
        self.payload = None
        self.transition = None
        self._export_key = None
        self._refresh_caption()
        self._refresh_export_tables()
        self.headline.value = _info_box("<b>No comparison loaded.</b>", "error")
        with self.dimension_figure.batch_update():
            self.dimension_figure.data[0].x = []
            self.dimension_figure.data[0].y = []
            self.dimension_figure.data[1].x = []
            self.dimension_figure.data[1].y = []
        self.summary_box.children = (widgets.HTML("<p>No comparison loaded.</p>"),)
        self._clear_detail()
        self._set_status("Error", f"{type(exc).__name__}: {exc}", "Idle")
        self._refresh_selection_line()

    def _on_index_edit(self, _change) -> None:
        self._refresh_index_chrome()
        self._refresh_selection_line()

    def _refresh_index_chrome(self) -> None:
        typed = self.index_input.value
        self._render_index_name(typed)
        self._maybe_lookup_index_name(typed)

    def _render_index_name(self, typed: str) -> None:
        lines = []
        try:
            key = validate_index_ticker(typed)
        except ValueError:
            key = ""
        record = self._index_name_cache.get(key) if key else None
        if record and record.get("name"):
            lines.append(
                f"<div style='display:inline-block;white-space:nowrap'><b>{escape(record['name'])}</b></div>"
            )
        elif record and record.get("error"):
            lines.append(f"<span style='color:#666'>{escape(record['error'])}</span>")
        elif key:
            lines.append("<span style='color:#666'>Looking up long_comp_name...</span>")
        self.index_name.value = "<br>".join(lines)

    def _maybe_lookup_index_name(self, typed: str) -> None:
        if self._looking_up_name or self._running:
            return
        try:
            ticker = validate_index_ticker(typed)
        except ValueError:
            return
        if ticker in self._index_name_cache:
            return
        self._looking_up_name = True
        try:
            try:
                name = fetch_index_long_name(ticker)
            except Exception as exc:
                detail = f"{type(exc).__name__}: {exc}"
                if membership_access_failure(detail):
                    detail = f"{MEMBERSHIP_LICENSE_MESSAGE} ({detail})"
                self._index_name_cache[ticker] = {"name": "", "error": f"long_comp_name: {detail}"}
            else:
                if name:
                    self._index_name_cache[ticker] = {"name": name, "error": ""}
                else:
                    self._index_name_cache[ticker] = {
                        "name": "",
                        "error": "long_comp_name returned no name for this ticker.",
                    }
        finally:
            self._looking_up_name = False
        try:
            still_same = validate_index_ticker(self.index_input.value) == ticker
        except ValueError:
            still_same = False
        if still_same:
            self._render_index_name(self.index_input.value)

    def _loaded_selection(self) -> dict | None:
        if self.payload is None:
            return None
        status = self.transition.status if self.transition is not None else "unavailable"
        return {
            "index": self.payload.index_ticker,
            "previous": self.payload.previous_date,
            "selected": self.payload.selected_date,
            "kind": self.payload.kind,
            "status": status,
        }

    def _refresh_selection_line(self) -> None:
        info = selection_status(
            self.index_input.value,
            self.month_end_input.value,
            self._loaded_selection(),
        )
        color = "#8a5a00" if info["pending"] else "#1b5e20"
        background = "#fff8e1" if info["pending"] else "#e8f5e9"
        self.selection_line.value = (
            f"<div style='margin:4px 0;padding:4px 8px;background:{background};"
            f"border:1px solid #e0e0e0;color:{color}'>{escape(info['text'])}</div>"
        )
        if self._running or self.payload is None:
            return
        if info["pending"]:
            self._set_status("Please Click Update", "Index or month-end changed.", "Idle")

    def _on_month_end_change(self, _change) -> None:
        self._refresh_selection_line()

    def _refresh_month_end_options(self) -> None:
        """Recompute the dropdown from today so a kernel left open across a month rollover updates."""
        today = pd.Timestamp.today().normalize()
        choices = month_end_choices(today, MONTH_END_CHOICES)
        values = [value for _label, value in choices]
        current = self.month_end_input.value
        self.month_end_input.unobserve(self._on_month_end_change, names="value")
        try:
            self.month_end_input.options = choices
            self.month_end_input.value = current if current in values else default_month_end(today)
        finally:
            self.month_end_input.observe(self._on_month_end_change, names="value")

    def _loaded_frames(self) -> list:
        return list(self.payload.snapshots.values()) if self.payload is not None else []

    def _set_currency_options(self) -> None:
        """Rebuild Currency from the extracted rows in the selected book.

        A pick that is still in that book stays selected.
        """
        book = self._current_book()
        choices = currency_choices(self._loaded_frames(), book)
        widget = self.filters["Currency"]
        widget.unobserve(self._on_view_change, names="value")
        try:
            current = tuple(widget.value or ())
            widget.value = ()
            widget.options = [ALL_FILTER_LABEL, *choices]
            kept = tuple(item for item in current if item in widget.options)
            widget.value = kept or (ALL_FILTER_LABEL,)
        finally:
            widget.observe(self._on_view_change, names="value")

    def _refresh_filter_options(self) -> None:
        frames = self._loaded_frames()
        choices = filter_choices(frames)
        book = self._current_book()
        choices["Currency"] = currency_choices(frames, book)
        for label, column in FILTER_COLUMNS:
            widget = self.filters[label]
            widget.unobserve(self._on_view_change, names="value")
            try:
                # Clear first: the old pick may not exist in the new month, and
                # assigning options while it is still selected raises a TraitError.
                widget.value = ()
                widget.options = [ALL_FILTER_LABEL, *choices.get(column, [])]
                widget.value = (ALL_FILTER_LABEL,)
            finally:
                widget.observe(self._on_view_change, names="value")

    def _on_view_change(self, change) -> None:
        if self._running or self._rendering:
            return
        if getattr(change, "owner", None) is self.book_select and self.payload is not None:
            self._set_currency_options()
        self._render()

    def _current_spreads(self) -> list[str]:
        selected = {str(value) for value in (self.spread_select.value or ())}
        spreads = [spread for spread in SPREAD_OPTIONS if spread in selected]
        return spreads or list(SPREAD_OPTIONS)

    def _current_durations(self) -> list[str]:
        selected = {str(value) for value in (self.duration_select.value or ())}
        fields = [field for field in DURATION_FIELDS if field in selected]
        return fields or list(DURATION_FIELDS)

    def _current_yields(self) -> list[str]:
        selected = {str(value) for value in (self.yield_select.value or ())}
        fields = [field for field in YIELD_FIELDS if field in selected]
        return fields or list(YIELD_FIELDS)

    def _current_book(self) -> str:
        selected = {
            str(value)
            for value in (self.book_select.value or ())
            if str(value) != ALL_FILTER_LABEL
        }
        if len(selected) == 1:
            return next(iter(selected))
        return DEFAULT_BOOK

    def _current_filters(self) -> dict[str, set[str]]:
        filters = {}
        for label, column in FILTER_COLUMNS:
            # "(All)" is the widget's rest state, not a value in the data. A
            # pick alongside it still filters, so only drop the marker itself.
            selected = set(self.filters[label].value or ()) - {ALL_FILTER_LABEL}
            if selected:
                filters[column] = selected
        return filters

    def _summary_columns(
        self,
        summary: pd.DataFrame,
        spreads: list[str],
        durations: list[str],
        yields: list[str],
    ) -> list[str]:
        if summary is None or summary.empty:
            return ["Message"]
        ordered = [
            summary.columns[0],
            "Begin Count", "End Count", "+/- Count",
            "Begin Weight", "End Weight", "+/- Weight",
            "Turnover (index %)", "Turnover Rate (%)",
        ]
        for field in spreads:
            ordered.extend([f"Begin {field}", f"End {field}", f"+/- {field}"])
        for field in durations:
            ordered.extend([f"Begin {field}", f"End {field}", f"+/- {field}"])
        for field in yields:
            ordered.extend([f"Begin {field}", f"End {field}", f"+/- {field}"])
        ordered.extend([
            "Begin Tenor", "End Tenor", "+/- Tenor",
            "Add Count", "Exit Count", "Add Weight", "Exit Weight",
        ])
        return [column for column in ordered if column in summary.columns]

    def _detail_list_columns(self) -> tuple[str, ...]:
        """Detail grid columns, derived from the one list the preview also reads.

        `DETAIL_LIST_COLUMNS` is the base order; the three analytics blocks are
        spliced in after `Weight`, which is the same anchor the preview page
        uses. Keeping one tuple means a column added there reaches both.
        """
        base = list(DETAIL_LIST_COLUMNS)
        anchor = base.index("Weight") + 1 if "Weight" in base else len(base)
        middle = [*self._current_spreads(), *self._current_durations(), *self._current_yields()]
        return tuple([*base[:anchor], *middle, *base[anchor:]])

    def _render(self) -> None:
        if self._rendering or self.transition is None:
            return
        self._rendering = True
        try:
            self._clear_detail()
            book = self._current_book()
            dimension = self.dimension_input.value or "Country"
            spreads = self._current_spreads()
            durations = self._current_durations()
            yields = self._current_yields()
            filters = self._current_filters()
            transition = self.transition
            summary, headline = summarize(transition, dimension, book, filters)
            self._render_dimension_chart(summary, dimension)
            self.headline.value = self._headline_html(
                transition, headline, book, filters, spreads, durations, yields
            )
            columns = self._summary_columns(summary, spreads, durations, yields)
            self._put_grid(self.summary_box, summary, columns, "summary")
            self._refresh_export_tables()
        finally:
            self._rendering = False

    def _render_dimension_chart(self, summary: pd.DataFrame, dimension: str) -> None:
        labels, add_weights, exit_weights = bucket_chart_rows(summary, dimension)
        longest = max((len(label) for label in labels), default=0)
        left = min(360, max(120, longest * 7 + 28))
        height = max(220, 96 + len(labels) * 24)
        with self.dimension_figure.batch_update():
            self.dimension_figure.data[0].x = add_weights
            self.dimension_figure.data[0].y = labels
            self.dimension_figure.data[1].x = exit_weights
            self.dimension_figure.data[1].y = labels
            self.dimension_figure.layout.title.text = f"{dimension}: Add (right) / Exit (left) weight"
            self.dimension_figure.layout.height = height
            self.dimension_figure.layout.margin.l = left
            self.dimension_figure.layout.yaxis.autorange = "reversed"
            self.dimension_figure.layout.xaxis.zeroline = True

    def _scope_line(self, book: str, filters: dict[str, set[str]] | None) -> str:
        parts = []
        for column in sorted(filters or {}):
            values = sorted(str(value) for value in filters[column] if value)
            if values:
                label = FILTER_LABELS.get(column, column)
                parts.append(f"{label}: {', '.join(values)}")
        filter_text = "; ".join(parts) if parts else "none"
        return (
            f"<b>Scope:</b> Book = {escape(book)}; filters = {escape(filter_text)}.<br>"
        )

    def _headline_html(
        self,
        transition,
        headline: dict,
        book: str,
        filters: dict[str, set[str]] | None = None,
        spreads: list[str] | None = None,
        durations: list[str] | None = None,
        yields: list[str] | None = None,
    ) -> str:
        spreads = spreads or ["OAS"]
        durations = durations or ["Duration"]
        yields = yields or ["Yield"]
        if transition is None:
            return _info_box("No comparison loaded.", "warn")
        if transition.status != "ok" or headline.get("status") != "ok":
            return _info_box(
                f"<b>{escape(transition.label)}</b> "
                f"({escape(book)}) unavailable. {escape(transition.message)}",
                "warn",
            )
        before = headline["before"]
        after = headline["after"]
        added = headline["added"]
        exited = headline["exited"]
        previous_counts = book_counts(transition.previous)
        latest_counts = book_counts(transition.latest)
        same_set = ""
        if transition.kind == "projected" and book_unchanged(transition.previous, transition.latest, book):
            same_set = (
                "<br>This book contains the same bonds on both dates. "
                "Before the provider publishes this month's list, "
                "members() on the upcoming date still returns the locked set."
            )
        content = (
            "".join(
                _info_box(warning, "warn") for warning in getattr(transition, "warnings", ())
            )
            + f"<b>{escape(transition.label)}</b> ({escape(book)}). "
            "The figures, Bucket summary, and charts below follow this scope; "
            "Full book lines are all books.<br>"
            f"{self._scope_line(book, filters)}"
            f"As of {escape(transition.previous_date)}: {before['Count']} bonds, "
            f"weight {_fmt(before['Weight'])}, "
            + ", ".join(f"{field} {_fmt(before.get(field))}" for field in (*spreads, *durations, *yields))
            + f", tenor {_fmt(before['Tenor'])}.<br>"
            f"As of {escape(transition.latest_date)}: {after['Count']} bonds, "
            f"weight {_fmt(after['Weight'])}, "
            + ", ".join(f"{field} {_fmt(after.get(field))}" for field in (*spreads, *durations, *yields))
            + f", tenor {_fmt(after['Tenor'])}.<br>"
            f"Add {added['Count']} / weight {_fmt(added['Weight'])}. "
            f"Exit {exited['Count']} / weight {_fmt(exited['Weight'])}. "
            f"Monthly turnover {_fmt(headline.get('turnover'))}"
            f"{'' if pd.isna(headline.get('turnover')) else '%'}"
            f"{' (approx)' if headline.get('turnover_basis') != 'official' else ''}"
            f"{' (filtered)' if headline.get('filtered') else ''}"
            f"{' (book)' if book != 'All' else ''}.<br>"
            f"Full book: Standard bonds latest {latest_counts['Standard']} "
            f"(previous {previous_counts['Standard']}). "
            f"Full book: MBS/TBA latest {latest_counts['MBS/TBA']} "
            f"(previous {previous_counts['MBS/TBA']})."
            f"{same_set}"
        )
        return _info_box(content, "ok")

    def _visible_changes(self, frame: pd.DataFrame) -> pd.DataFrame:
        """The Bonds control narrows the detail list. Add and Exit keeps both."""
        action = self.action_input.value
        if frame is None or frame.empty or action == "Add and Exit" or "Action" not in frame.columns:
            return frame if frame is not None else pd.DataFrame()
        return frame.loc[frame["Action"].astype(str) == action].copy()

    def _put_grid(self, box, frame: pd.DataFrame, columns, role: str) -> None:
        source = frame.copy() if frame is not None else pd.DataFrame()
        view = grid_display_frame(source, tuple(columns))
        if len(view) > DISPLAY_ROW_CAP:
            view = view.head(DISPLAY_ROW_CAP).copy()
            source = source.head(DISPLAY_ROW_CAP).copy()
        if view.empty:
            view = pd.DataFrame({"Message": ["No rows"]})
            source = view.copy()
        if DataGrid is None:
            table = view.to_html(index=False, border=0)
            # Desktop runs Python 3.11: no backslash inside an f-string expression.
            fit_table = table.replace("<table", '<table class="fit"', 1)
            # A light table block, like the DataGrid. The Desktop shell is dark,
            # so transparent cells would be unreadable as well as inconsistent.
            grid = widgets.HTML(
                "<div style='overflow:auto;max-width:100%'>"
                "<style>table.fit{width:max-content;border-collapse:collapse;background:#fff;color:#111}"
                "table.fit th,table.fit td{white-space:nowrap;padding:2px 8px;text-align:left}"
                "table.fit th:first-child,table.fit td:first-child{position:sticky;left:0;"
                "background:#fff;z-index:1;border-right:1px solid #ddd}"
                "table.fit th:first-child{background:#f2f2f2;z-index:2}</style>"
                f"{fit_table}</div>"
            )
            box.children = (grid,)
            return
        widths = _fit_column_widths(view)
        layout = widgets.Layout(width="100%", height="320px")
        frame = view.reset_index(drop=True)
        pin_column = PIN_DETAIL_COLUMN if role == "detail" else None
        pin_max = PIN_DETAIL_ROW_HEADER_MAX_PX if role == "detail" else PIN_ROW_HEADER_MAX_PX
        pinned, gutter = _pinned_view(view, pin_column, pin_max)
        if gutter is not None and not hasattr(DataGrid, "base_row_header_size"):
            # Too old to size the gutter: a 64 px default would cut the label,
            # so keep every column in the scrolling body instead of half-pinning.
            pinned, gutter = frame, None
        body_columns = {str(name) for name in pinned.columns}
        body_widths = (
            {name: width for name, width in widths.items() if name in body_columns}
            if gutter is not None
            else widths
        )
        kwargs = {
            "layout": layout,
            "selection_mode": "row",
            "column_widths": body_widths,
        }
        if gutter is not None:
            kwargs["base_row_header_size"] = gutter
        if hasattr(DataGrid, "header_visibility"):
            # The pinned column lives in the row header, so it must stay shown.
            kwargs["header_visibility"] = "all"
        grid = DataGrid(pinned if gutter is not None else frame, **kwargs)
        source = source.reset_index(drop=True)
        if hasattr(grid, "on_cell_click"):
            # RAG KB/09 documents on_cell_click, and primary_key_row ignores
            # grid sorting. This is the path every sibling app uses.
            def _on_click(event, role=role, source=source):
                if not isinstance(event, dict):
                    return
                region = event.get("region")
                if region in {"column-header", "corner-header"}:
                    return
                row_index = event.get("primary_key_row")
                if row_index is None:
                    # Do not fall back to "row". That value is the viewport
                    # row, so after the user sorts the grid it points at a
                    # different bond. Opening nothing is better than opening
                    # the wrong bond.
                    return
                # A row-header click is the pinned first column, so it must open
                # that row exactly like a body click does.
                self._show_picked_row(row_index, role, source)

            grid.on_cell_click(_on_click)
        else:
            grid.observe(
                lambda change, role=role, source=source: self._on_grid_picked(change, role, source),
                names="selections",
            )
        box.children = (grid,)

    def _selected_row_index(self, grid, change=None):
        selected = list(getattr(grid, "selections", []) or [])
        if not selected and change is not None:
            new_value = change.get("new")
            if new_value:
                selected = list(new_value)
        if not selected:
            return None
        first = selected[0]
        if isinstance(first, dict):
            for key in ("r1", "row", "r"):
                if first.get(key) is not None:
                    return int(first[key])
        if isinstance(first, (list, tuple)) and first:
            return int(first[0])
        row_index = getattr(first, "r1", None)
        if row_index is None:
            row_index = getattr(first, "row", None)
        return None if row_index is None else int(row_index)

    def _show_picked_row(self, row_index, role: str, source: pd.DataFrame) -> None:
        try:
            if source is None or row_index is None:
                return
            row_index = int(row_index)
            if row_index < 0 or row_index >= len(source):
                return
            row = source.iloc[row_index]
            if "Message" in source.columns and "ID" not in source.columns and "Add Count" not in source.columns:
                return
            if role == "summary":
                self._show_bucket(row)
            elif role == "detail":
                self._show_bond(row)
        except Exception:
            self.detail_title.value = "<b style='font-size:16px'>Detail</b><br>Could not read that row."

    def _on_grid_picked(self, change, role: str, source: pd.DataFrame) -> None:
        """Selection-trait fallback for kernels without on_cell_click."""
        row_index = self._selected_row_index(change.get("owner"), change)
        self._show_picked_row(row_index, role, source)

    def _clear_detail(self) -> None:
        self.detail_title.value = "<b style='font-size:16px'>Detail</b><br>Click an add, an exit, or a bucket."
        self.detail_table.value = ""
        self.detail_fields.value = ""
        with self.detail_figure.batch_update():
            self.detail_figure.data[0].x = []
            self.detail_figure.data[0].y = []
            self.detail_figure.data[0].marker.color = "#2a9d8f"
            self.detail_figure.layout.title.text = "Weight (Add right / Exit left)"
            self.detail_figure.layout.height = 260
        self.detail_bonds_box.children = ()

    def _changes(self) -> pd.DataFrame:
        if self.transition is None:
            return pd.DataFrame(columns=["Action", "Weight", "ID"])
        return change_export_frame(self.transition, self._current_book())

    def _filtered_changes(self) -> pd.DataFrame:
        """Changes under every active filter, not only the current dimension."""
        return apply_dimension_filters(self._changes(), self._current_filters())

    def _bucket_key(self, row) -> tuple[str, str]:
        column = DIMENSIONS.get(self.dimension_input.value or "Country", "Country")
        if column not in row.index:
            return column, ""
        return column, str(row[column])

    def _bucket_changes(self, column: str, key: str) -> pd.DataFrame:
        changes = self._filtered_changes()
        if changes.empty or column not in changes.columns:
            return changes.iloc[0:0]
        return changes.loc[changes[column].astype(str) == key].copy()

    def _chart_weights(self, frame: pd.DataFrame, title: str) -> None:
        if frame is None or frame.empty or "Weight" not in frame.columns:
            labels, values, colors = [], [], []
        else:
            ordered = frame.sort_values("Weight", ascending=False, na_position="last").head(20)
            labels = [
                name
                for name in ordered.get("Name", ordered.get("ID", pd.Series("", index=ordered.index))).astype(str)
            ]
            values = [
                None if pd.isna(value) else float(value)
                for value in pd.to_numeric(ordered["Weight"], errors="coerce")
            ]
            colors = ["#e76f51" if action == "Exit" else "#2a9d8f" for action in ordered.get("Action", pd.Series("", index=ordered.index))]
        longest = max((len(label) for label in labels), default=0)
        left = min(360, max(120, longest * 7 + 28))
        height = max(260, 96 + len(labels) * 26)
        with self.detail_figure.batch_update():
            self.detail_figure.data[0].y = labels
            self.detail_figure.data[0].x = values
            self.detail_figure.data[0].marker.color = colors or "#2a9d8f"
            self.detail_figure.layout.title.text = title
            self.detail_figure.layout.margin.l = left
            self.detail_figure.layout.height = height
            self.detail_figure.layout.yaxis.autorange = "reversed"
            self.detail_figure.layout.xaxis.zeroline = True

    def _field_table(
        self,
        row,
        spreads: list[str] | None = None,
        durations: list[str] | None = None,
        yields: list[str] | None = None,
    ) -> str:
        spreads = spreads or ["OAS"]
        durations = durations or ["Duration"]
        yields = yields or ["Yield"]
        selected = set(spreads) | set(durations) | set(yields)
        body = []
        fields = [
            field
            for field in DETAIL_FIELDS
            if field not in (*SPREAD_OPTIONS, *DURATION_FIELDS, *YIELD_FIELDS) or field in selected
        ]
        for field in fields:
            if field not in row.index:
                continue
            value = row[field]
            if field == "Weight" or field in {
                "Tenor", "Coupon", *SPREAD_OPTIONS, *DURATION_FIELDS, *YIELD_FIELDS,
            }:
                text = _fmt(value, 4 if field == "Weight" else 2)
            elif field in {"Maturity", "AS_OF_DATE"} and value is not None and not pd.isna(value):
                try:
                    text = pd.Timestamp(value).strftime("%Y-%m-%d")
                except (TypeError, ValueError):
                    text = str(value)
            else:
                text = "" if value is None or pd.isna(value) else str(value)
            body.append(f"<tr><th style='text-align:left;padding-right:8px'>{escape(field)}</th><td>{escape(text)}</td></tr>")
        return "<table>" + "".join(body) + "</table>"

    def _show_bucket(self, row) -> None:
        column, key = self._bucket_key(row)
        subset = signed_change_frame(self._visible_changes(self._bucket_changes(column, key)))
        action = subset.get("Action", pd.Series("", index=subset.index)).astype(str)
        add_mask = action == "Add"
        exit_mask = action == "Exit"
        if "Weight" in subset.columns:
            add_weight = float(pd.to_numeric(subset.loc[add_mask, "Weight"], errors="coerce").sum(skipna=True))
            # Negating a zero sum yields -0.0, which formats as "-0.00%".
            # Adding 0.0 normalises the sign before formatting.
            exit_weight = -float(pd.to_numeric(subset.loc[exit_mask, "Weight"], errors="coerce").sum(skipna=True)) + 0.0
        else:
            add_weight, exit_weight = float("nan"), float("nan")
        net_weight = add_weight - exit_weight
        self.detail_title.value = f"<b style='font-size:16px'>{escape(column)}</b><br>{escape(key)}"
        add_count, exit_count = int(add_mask.sum()), int(exit_mask.sum())
        add_word = "add" if add_count == 1 else "adds"
        exit_word = "exit" if exit_count == 1 else "exits"
        self.detail_table.value = (
            f"{add_count} {add_word} and {exit_count} {exit_word}. "
            f"Add weight {_fmt(add_weight, 2)}%, Exit weight {_fmt(exit_weight, 2)}%, "
            f"Net weight {_fmt(net_weight, 2)}%."
        )
        self.detail_fields.value = ""
        self._chart_weights(top_add_exit_rows(subset), f"{column}: {key} — Top 10 Add / Top 10 Exit")
        self._put_grid(self.detail_bonds_box, subset, self._detail_list_columns(), "detail")

    def _show_bond(self, row) -> None:
        action = str(row["Action"]) if "Action" in row.index else ""
        name = str(row["Name"]) if "Name" in row.index else str(row.get("ID", ""))
        weight = pd.to_numeric(pd.Series([row.get("Weight")]), errors="coerce").iloc[0]
        if not pd.isna(weight):
            weight = -abs(float(weight)) if action == "Exit" else abs(float(weight))
        changes = signed_change_frame(self._filtered_changes())
        others = 0.0
        if not changes.empty and "Action" in changes.columns and "Weight" in changes.columns:
            same = changes.loc[changes["Action"].astype(str) == action]
            if "ID" in same.columns and "ID" in row.index:
                same = same.loc[same["ID"].astype(str) != str(row["ID"])]
            others = float(pd.to_numeric(same["Weight"], errors="coerce").sum(skipna=True))
        self.detail_title.value = f"<b style='font-size:16px'>{escape(action)}</b><br>{escape(name)}"
        self.detail_table.value = f"Bond detail is below the table: {escape(action)} {escape(name)}."
        self.detail_fields.value = self._field_table(
            row,
            self._current_spreads(),
            self._current_durations(),
            self._current_yields(),
        )
        with self.detail_figure.batch_update():
            self.detail_figure.data[0].y = ["This bond", f"Other {action or 'changes'}"]
            self.detail_figure.data[0].x = [None if pd.isna(weight) else float(weight), others]
            self.detail_figure.data[0].marker.color = ["#2a9d8f" if action != "Exit" else "#e76f51", "#bbbbbb"]
            self.detail_figure.layout.title.text = "Index weight (Add right / Exit left)"
            self.detail_figure.layout.height = 260

    def _put_export_grid(self, box, frame: pd.DataFrame, columns, label: str) -> None:
        view = export_display_frame(frame, tuple(columns))
        if view.empty:
            box.children = (widgets.HTML("<p>No rows.</p>"),)
            return
        if DataGrid is None:
            table = view.to_html(index=False, border=0)
            fit_table = table.replace("<table", '<table class="fit"', 1)
            box.children = (
                widgets.HTML(
                    "<div style='overflow:auto;max-width:100%'>"
                    "<style>table.fit{width:max-content;border-collapse:collapse}"
                    "table.fit th,table.fit td{white-space:nowrap;padding:2px 8px;text-align:left}</style>"
                    f"{fit_table}</div>"
                ),
            )
            return
        widths = _fit_column_widths(view)
        layout = widgets.Layout(width="100%", height="300px")
        try:
            grid = DataGrid(view, layout=layout, selection_mode="cell", column_widths=widths)
        except TypeError:
            grid = DataGrid(view, layout=layout)
        box.children = (grid,)

    def _refresh_export_tables(self) -> None:
        transition = self.transition
        book = self._current_book()
        dimension = self.dimension_input.value or "Country"
        key = (id(transition), book, dimension)
        if key == self._export_key:
            return
        self._export_key = key
        # An id() is only unique while its object is alive. Pinning the frame
        # here stops Python from reusing the id for the next comparison, which
        # would silently skip the export refresh.
        self._export_source = transition
        if transition is None or transition.status != "ok":
            self._export_frames = {}
            self._export_columns = {}
            self._show_export_view()
            self._refresh_positions()
            return
        changes = change_export_frame(transition, book)
        summary, _headline = summarize(transition, dimension, book, None)
        self._export_frames = {"changes": changes, "summary": summary}
        self._export_columns = {
            "changes": list(changes.columns),
            "summary": list(summary.columns),
        }
        self._show_export_view()
        self._refresh_positions()

    def _on_export_view_change(self, _change) -> None:
        self._show_export_view()

    def _show_export_view(self) -> None:
        key = self.export_view.value
        frame = self._export_frames.get(key)
        if frame is None:
            self.export_box.children = (widgets.HTML("<p>No comparison loaded.</p>"),)
            return
        self._put_export_grid(self.export_box, frame, self._export_columns[key], key)

    def _refresh_positions(self) -> None:
        key = id(self.payload) if self.payload is not None else None
        if key == self._positions_key:
            return
        self._positions_key = key
        self._payload_source = self.payload
        if self.payload is None or self.transition is None or self.transition.status != "ok":
            self._position_frames = {}
            self.position_view.options = [("Start date", "start"), ("End date", "end")]
            self._show_position_view()
            return
        previous_date = self.payload.previous_date
        selected_date = self.payload.selected_date
        self._position_frames = {
            "start": self.payload.snapshots.get(previous_date),
            "end": self.payload.snapshots.get(selected_date),
        }
        self.position_view.options = [
            (f"Start date — {previous_date}", "start"),
            (f"End date — {selected_date}", "end"),
        ]
        self._show_position_view()

    def _on_position_view_change(self, _change) -> None:
        self._show_position_view()

    def _show_position_view(self) -> None:
        frame = self._position_frames.get(self.position_view.value)
        if frame is None:
            self.positions_box.children = (widgets.HTML("<p>No comparison loaded.</p>"),)
            return
        self._put_export_grid(self.positions_box, frame, POSITION_COLUMNS, "positions")
