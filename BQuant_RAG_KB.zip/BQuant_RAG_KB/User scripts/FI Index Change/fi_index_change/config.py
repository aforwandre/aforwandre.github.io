"""Constants for the FI Index Change Desktop app.

The operator confirmed these defaults on 2026-10-22. Live BQL still runs
only after Update on BQuant Desktop.

There is deliberately no version stamp here. Cache reuse is keyed to
``FIELD_CONTRACT`` in ``cache.py``, which is derived from the frozen item
list in ``field_library.py``. Editing that list invalidates old cache
entries automatically, so nothing has to be bumped by hand.
"""

DEFAULT_INDEX = "LEGATRUU Index"
# All shows both books at once. The operator asked for this default on
# 2026-10-31; Standard still isolates the MBS/TBA roll codes on demand.
DEFAULT_BOOK = "All"

# country_full_name() replacements. The match ignores case and extra spaces.
# The second value is the display source; every name is title-cased Excel
# PROPER style afterwards (UNITED KINGDOM -> United Kingdom). Add a row
# here to override another name.
COUNTRY_NAME_OVERRIDES = (
    ("BRITAIN", "UNITED KINGDOM"),
    ("SNAT", "SUPRANATIONAL"),
)

# An ID ending with this token is a US municipal bond: Country and Sector show
# Municipal, Currency is USD, and Rating is RATING_NOT_APPLICABLE.
MUNICIPAL_ID_SUFFIX = "Muni"
MUNICIPAL_LABEL = "Municipal"
# Team convention: the Rating classification has exactly three values, IG, HY,
# and NR. Everything without a usable letter grade is NR, including N.A. on
# MBS/TBA and Municipal rows, an unrated bond, and a vendor numeric scale.
# The raw Rating text is still shown as the vendor returned it, so no detail is
# hidden; only the classification is collapsed.
RATING_NO_GRADE = "NR"
RATING_NOT_APPLICABLE = RATING_NO_GRADE
# The frozen MBS/TBA display label. proper_country_name() returns it and
# MUNICIPAL_LABEL unchanged, so a cached reload cannot title-case it into
# "Mbs/Tba" and split one book into two buckets.
MBS_TBA_LABEL = "MBS/TBA"
# Written into the Rating column when the response carried no Rating column at
# all, and used as the classification for every row without a letter grade.
RATING_MISSING = RATING_NO_GRADE

# MBS/TBA settle forward and have no Tenor Bucket value; label it instead of
# leaving a blank option in the Tenor filter.
TENOR_NOT_APPLICABLE = "N.A."

# Filter widgets are fixed width and separated by FILTER_GAP_PX. Book is the
# last selection box after Currency. FILTER_ROW_WIDTH_PX is the width of that
# whole row; the charts are narrower than it on purpose (see below).
FILTER_WIDTHS = {"Country": 300, "Sector": 300, "Tenor": 220, "Rating": 220, "Currency": 220, "Spread": 220, "Duration": 260, "Yield": 260, "Book": 220}
FILTER_GAP_PX = 8
FILTER_ROW_WIDTH_PX = sum(FILTER_WIDTHS.values()) + FILTER_GAP_PX * (len(FILTER_WIDTHS) - 1)

# The operator asked on 2026-11-01 for the bar charts to stop at 80% of the
# screen width on a full-screen FHD monitor, instead of running to the right
# edge of the nine filter boxes. Assumed viewport: 1920 px wide. The cap wins
# when the filter row is wider than the cap, which it currently is
# (2,284 px vs 1,536 px), so the charts deliberately end short of the row.
SCREEN_WIDTH_PX = 1920
CHART_MAX_SCREEN_RATIO = 0.80
CHART_WIDTH_PX = min(
    FILTER_ROW_WIDTH_PX, int(SCREEN_WIDTH_PX * CHART_MAX_SCREEN_RATIO)
)

# Bucket chart shows this many buckets, then one aggregated Others row.
BUCKET_CHART_TOP = 20

# Keep the Main tab's first table column visible while scrolling sideways.
# ipydatagrid 1.4.0 has no frozen-column trait, so the pinned column is moved
# into the row-header gutter, which stays pinned at the left. Set False to put
# every column back into the scrolling body.
PIN_FIRST_COLUMN = True
# Row-header gutter width for the pinned column: never narrower than the
# library default, never wide enough to crowd out the body columns.
PIN_ROW_HEADER_MIN_PX = 80
PIN_ROW_HEADER_MAX_PX = 220
# The detail bond table pins the ISIN-side yellow key instead of the first
# column: Action repeats (Add/Exit), so it identifies nothing while scrolling
# to the analytics columns. ID is unique and is the key the diff uses.
PIN_DETAIL_COLUMN = "ID"
PIN_DETAIL_ROW_HEADER_MAX_PX = 300

# Dropdown length only. Update still requests the selected month and the one before it.
MONTH_END_CHOICES = 18

# Keep True. On 2026-11-02 a single 23-item request answered with
# "#N/A Query Timed out", after a 22-item request had already answered one
# month-end and timed out on the next. A split sends one request per measure
# family (see ``ANALYTICS_GROUPS``) so no request carries more than six
# analytics. Set this back to False only on a dated Desktop timing that shows a
# single request of this width completes inside the limit.
SPLIT_REQUESTS = True

# A timed-out month-end is attempted again, unchanged, on the operator's
# 2026-11-02 evidence that pressing Update a second time succeeds in seconds
# while the first attempt ran close to the limit. Nothing is dropped from the
# request and no item is substituted: the retry re-sends the same items against
# the same date, so a warm Bloomberg-side cache is the only thing that can make
# it faster. Only a timeout is retried. A rejected item, a missing entitlement,
# or a bad universe can never succeed on a second try, so retrying those would
# spend another two minutes for nothing.
QUERY_ATTEMPTS = 2
# A month-end that already failed on every attempt is not retried again in the
# same Update; the second month-end is requested instead, so one bad date
# cannot consume the whole upload window.
# Total worst case per Update grows with the number of groups, because each
# date sends one identity request plus one request per ``ANALYTICS_GROUPS``
# entry, and a timed-out request is retried by ``QUERY_ATTEMPTS``. A group that
# failed outright also refuses the cache, so it is re-requested on the next
# Update instead of being baked in as permanently blank. The budget is spent on
# the first date before the second is attempted, so a timeout on the previous
# month-end does not silently consume the selected month-end's window.

OAS_EXCLUDE_AT_OR_ABOVE = 9000
# A fraction snapshot sums to about 1.0. A percent snapshot sums to about 100.
# Anything in between is not a unit we can infer, so it is left unscaled rather
# than multiplied by 100 on a guess.
WEIGHT_FRACTION_SUM_MAX = 1.05
DISPLAY_ROW_CAP = 5000
CACHE_DIR_NAME = "cache"

# There is no Market Value setting here any more. ``market_value()`` was
# dropped from the request on 2026-11-02: per-bond values are only additive
# across a multi-currency index when every member reports the same currency,
# that basis was never confirmed for this account, and the code therefore
# fetched the field on every Update and then refused to publish the ratio.
# Turnover keeps the approximate definition it always showed, so no displayed
# number changed. Turning the official basis back on needs the field restored
# in ``field_library.py`` plus a dated Desktop check of one multi-currency
# index month-end (see RAG KB 28).
