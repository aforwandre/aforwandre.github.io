"""Verified Phase 1 items for one fixed-income index membership snapshot.

Names and calls are frozen in RAG KB/28-fi-index-change.md. Views must
select from this table. They must not build BQL items from widget text.
"""

# MBSM was removed on 2026-11-02. Desktop answered
# "No BQL data item named 'mtge_modified_duration'", so the frozen call in
# RAG KB/28 does not exist in this account's BQL surface. Dropping it keeps the
# membership request buildable; it was not tradeable as an optional item
# because a rejected required item made every month unavailable.
# The analytics block was cut on 2026-11-02 after Desktop answered every
# month with "[BQLTimeoutError] - The query took too long to complete" on a
# request that had grown to 36 items (22 analytics). The operator chose these
# nine and no others. The previous build carried DMAT and MACM instead of OAD
# and ESPD. Every listed item is requested on every Update, so this table is
# also the request width: adding a name here costs query time on every run.
SPREAD_FIELDS = (
    "OAS",
    "Z-Spread",
    "I-Spread",
)

# All four come from one builder, ``duration()``. ``duration_type`` is the only
# difference, which is the same shape as ``spread(spread_type=...)`` above and
# ``yield_(yield_type=...)`` below, and three ``spread()`` items returning
# distinct real values on this index is in-project evidence that one builder can
# carry several parameter values inside a single request.
#
# Provenance: operator-supplied FLDS BQL tab text on 2026-11-02 listed
# 'MODIFIED', 'EFFECTIVE' and 'SPREAD' as accepted values, with 'SPREAD'
# described as "Spread Duration (OAS Duration)". That text is the only evidence
# in this project -- a search of the whole corpus for ``duration_type`` returns
# no page that uses it, only this project's own note that it is absent. Re-check
# the FLDS tab rather than trusting this comment if a call is rejected.
#
# ``OAD`` (``option_adj_duration_sov_crv()``) and ``ESPD``
# (``spread_duration_effective()``) were replaced here on 2026-11-02. Neither
# had a call site anywhere in the corpus, and on that month both returned a
# column with every value null on this index while the neighbouring measures
# returned real values. 'SPREAD' is the option-adjusted spread duration the
# operator asked for and 'EFFECTIVE' is the measure ``OAD`` was reaching for.
# The block is one item wider than before (four against three), so it costs one
# more slot on a request that was already exceeding the two-minute limit.
DURATION_FIELDS = (
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
)

YIELD_FIELDS = (
    "Yield",
    "YTM",
    "YTW",
)

ITEM_NAMES = (
    "Name",
    "Issuer",
    "Sector",
    "Country",
    "Currency",
    "Security Type",
    "Maturity",
    "Tenor",
    "Rating",
    "Coupon",
    *SPREAD_FIELDS,
    *DURATION_FIELDS,
    *YIELD_FIELDS,
    "Weight",
    "ISIN",
    "SEDOL",
)

# No item is optional any more. ``Market Value`` was removed on 2026-11-02:
# its only consumer reads the summed per-bond value to publish an index-MV
# ratio, and that publish is gated on ``MARKET_VALUE_CURRENCY_CONFIRMED``,
# which has never been confirmed for this account. The field was therefore
# fetched on every Update and then discarded, while costing one more item on
# a request that already runs against the two-minute limit. Turnover keeps
# the approximate definition it has always shown (ratio 1.0), so removing it
# changes no displayed number. Re-adding it means restoring the builder, the
# optional retry, and a dated Desktop confirmation of the currency basis.
OPTIONAL_ITEMS: tuple[str, ...] = ()


class ItemBuildError(RuntimeError):
    """One frozen item could not be built.

    ``item`` is the request name, so a caller can tell an optional item from a
    required one instead of assuming every failure is ``Market Value``.
    """

    def __init__(self, item: str, cause: BaseException) -> None:
        super().__init__(f"{item}: {type(cause).__name__}: {cause}")
        self.item = item
        self.cause = cause

# Moved to the second request only when config.SPLIT_REQUESTS is True.
ANALYTICS_NAMES = (*SPREAD_FIELDS, *DURATION_FIELDS, *YIELD_FIELDS)

# When ``config.SPLIT_REQUESTS`` is True, each tuple here is its own
# ``bq.execute``. The split is by measure family, not by count: the spreads and
# yields are reference-curve lookups, while every duration is evaluated by a
# model per bond, so a timeout should name which family it happened in.
#
# Durations are last for a reason. If the duration request is the one that
# times out, the identity request and the spread/yield request have already
# returned, so the month still shows its securities, weights, spreads and
# yields with a note naming the missing measures, instead of an empty table.
#
# This replaced a two-way split (identity, then all ten analytics in one
# request) on 2026-11-02: nine analytics inside a 22-item request answered on
# one month-end and timed out on the next, so a ten-analytics request is not a
# width worth betting a run on.
ANALYTICS_GROUPS = (
    (*SPREAD_FIELDS, *YIELD_FIELDS),
    DURATION_FIELDS,
)

NUMERIC_COLUMNS = (
    "Weight", "Tenor", "Coupon",
    *SPREAD_FIELDS, *DURATION_FIELDS, *YIELD_FIELDS,
)

STRING_COLUMNS = (
    "ID",
    "Name",
    "Issuer",
    "Sector",
    "Country",
    "Currency",
    "Security Type",
    "Maturity",
    "Rating",
    "ISIN",
    "SEDOL",
    "AS_OF_DATE",
    "SNAPSHOT_KIND",
)


# One entry per frozen item. Built lazily so a rejected item reports its own
# name instead of a bare exception type.
_ITEM_CALLS = (
    ("Name", lambda bq: bq.data.name()),
    ("Issuer", lambda bq: bq.data.long_comp_name()),
    ("Sector", lambda bq: bq.data.classification_name()),
    ("Country", lambda bq: bq.data.country_full_name()),
    ("Currency", lambda bq: bq.data.crncy()),
    ("Security Type", lambda bq: bq.data.security_typ()),
    ("Maturity", lambda bq: bq.data.maturity()),
    ("Tenor", lambda bq: bq.data.mty_years_tdy()),
    ("Rating", lambda bq: bq.data.rating()),
    ("Coupon", lambda bq: bq.data.cpn()),
    ("OAS", lambda bq: bq.data.spread(spread_type="OAS")),
    ("Z-Spread", lambda bq: bq.data.spread(spread_type="Z")),
    ("I-Spread", lambda bq: bq.data.spread(spread_type="I")),
    ("Duration", lambda bq: bq.data.duration()),
    # One builder, three parameter values. Plain ``duration()`` keeps its
    # argument-free call because that is the form the official recipes use
    # (``RAG KB/02`` calls ``duration()``, ``duration(fill='prev')`` and
    # ``duration(dates=date_range)``). Nothing in the corpus states which
    # measure the default is, so if it turns out to be Modified then
    # ``Modified Duration`` is the same number under a second request name --
    # compare both columns on one batch of IDs on Desktop before trusting both.
    ("Modified Duration", lambda bq: bq.data.duration(duration_type="MODIFIED")),
    ("Effective Duration", lambda bq: bq.data.duration(duration_type="EFFECTIVE")),
    ("OASD", lambda bq: bq.data.duration(duration_type="SPREAD")),
    ("Yield", lambda bq: bq.data.yield_()),
    # ``yield_type`` is a parameter on ``yield_()``, not a separate item. Two
    # official Desktop apps use exactly this form:
    #   "Yield to Maturity": bq.data.yield_(yield_type="YTM"),
    #   "Yield to Worst":    bq.data.yield_(yield_type="YTW"),
    #   "Yield to Call":     bq.data.yield_(yield_type="YTC"),
    # (RAG KB/Raw source, "Bond Pair Relative Value" and "TOMS Relative
    # Value"). No official page uses ``yield_to_maturity()`` or
    # ``yield_to_worst()``; those two exist only as catalog spellings in
    # ``22``, and on 2026-11-02 both returned a column with every value null.
    ("YTM", lambda bq: bq.data.yield_(yield_type="YTM")),
    ("YTW", lambda bq: bq.data.yield_(yield_type="YTW")),
    ("Weight", lambda bq: bq.data.id()["weights"]),
    ("ISIN", lambda bq: bq.data.id_isin()["value"]),
    ("SEDOL", lambda bq: bq.data.id_sedol1()["value"]),
)


def _calls(bq, names=None) -> dict:
    """Build one call per requested frozen item, naming the item that failed.

    Only the requested items are built. Building all 37 and filtering
    afterwards would re-raise an optional item on every retry that removed it,
    so dropping ``Market Value`` could never succeed, and a split identity
    request would still fail on an analytics item.
    """
    selected = ITEM_NAMES if names is None else tuple(names)
    known = {name for name, _build in _ITEM_CALLS}
    unknown = [name for name in selected if name not in known]
    if unknown:
        raise KeyError(f"Unknown membership items: {unknown}")
    builders = dict(_ITEM_CALLS)
    calls = {}
    for name in selected:
        try:
            calls[name] = builders[name](bq)
        except Exception as exc:
            raise ItemBuildError(name, exc) from exc
    return calls


def build_member_items(bq, names=None) -> dict:
    """Return the Phase 1 item dict for ``names`` (all items when omitted)."""
    return _calls(bq, names)
