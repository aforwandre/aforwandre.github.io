"""Month-end schedule, membership diff, and dashboard aggregates.

No BQL calls live here. Add and Exit are ID differences. Begin and End
are the full selected book.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .field_library import DURATION_FIELDS, SPREAD_FIELDS, YIELD_FIELDS
from .config import (
    BUCKET_CHART_TOP,
    COUNTRY_NAME_OVERRIDES,
    MBS_TBA_LABEL,
    MONTH_END_CHOICES,
    MUNICIPAL_ID_SUFFIX,
    MUNICIPAL_LABEL,
    RATING_MISSING,
    RATING_NO_GRADE,
    RATING_NOT_APPLICABLE,
    TENOR_NOT_APPLICABLE,
    OAS_EXCLUDE_AT_OR_ABOVE,
    WEIGHT_FRACTION_SUM_MAX,
)


# Card 28 buckets: 0-1Y, 1-3Y, 3-5Y, 5-7Y, 7-10Y, 10-20Y, 20Y+. The last
# label is open-ended. Tenors below zero are bad data and stay Missing.
TENOR_BINS = (0.0, 1.0, 3.0, 5.0, 7.0, 10.0, 20.0)
TENOR_LABELS = ("0-1Y", "1-3Y", "3-5Y", "5-7Y", "7-10Y", "10-20Y", "20Y+")

SP_IG = {
    "AAA", "AA+", "AA", "AA-", "A+", "A", "A-", "BBB+", "BBB", "BBB-",
}
SP_HY = {
    "BB+", "BB", "BB-", "B+", "B", "B-",
    "CCC+", "CCC", "CCC-", "CC", "C", "D", "SD", "RD",
}
MOODY_IG = {
    "AAA", "AA1", "AA2", "AA3", "A1", "A2", "A3", "BAA1", "BAA2", "BAA3",
}
MOODY_HY = {
    "BA1", "BA2", "BA3", "B1", "B2", "B3",
    "CAA1", "CAA2", "CAA3", "CA", "C",
}
# There is no explicit "no usable letter grade" token list here any more, and
# none is needed. ``rating_bucket()`` returns NR for everything that is not a
# recognised IG or HY grade, so a blank, a stated NR, N.A. on an MBS/TBA or
# Municipal row, a vendor numeric scale, and a second pass over a frame that
# was already labelled all fall through to the same bucket. A list here would
# have been dead code that read as if it were enforcing that outcome.

DIMENSIONS = {
    "Country": "Country",
    "Sector": "Sector",
    "Tenor": "Tenor Bucket",
    "Rating": "Rating Bucket",
    "Currency": "Currency",
}


@dataclass
class Comparison:
    previous_date: str
    selected_date: str
    kind: str


@dataclass
class Transition:
    label: str
    previous_date: str
    latest_date: str
    kind: str
    status: str
    message: str = ""
    # Adds and exits are NOT stored on the transition. They depend on the
    # selected Book and the active dimension filters, so every consumer derives
    # them with ``diff_members(transition.previous, transition.latest, book)``.
    # Two fields used to sit here and were never populated by
    # ``build_transition``; anything reading them got an empty frame that
    # looked like a real answer of "no changes".
    previous: pd.DataFrame = field(default_factory=pd.DataFrame)
    latest: pd.DataFrame = field(default_factory=pd.DataFrame)
    # Ending / beginning index market value. None means the BQL index value
    # was unavailable and turnover falls back to the approximate definition.
    index_mv_ratio: float | None = None
    turnover_basis: str = "approx"
    # Non-fatal defects in the two snapshots (a required item that did not
    # parse, a snapshot that is not cacheable). The comparison still computes;
    # the screen shows these so a partial response never looks clean.
    warnings: tuple[str, ...] = ()


# Shown when members() is refused for this login. A 403 is a session
# problem (05), not this message. An empty book is not this message.
MEMBERSHIP_LICENSE_MESSAGE = "No Data Access License under this BBG ID"


def membership_access_failure(text: str) -> bool:
    """True when a request error says this login cannot read the index."""
    folded = " ".join(str(text or "").split()).casefold()
    if not folded or "403" in folded:
        return False
    markers = (
        "entitlement",
        "entitled",
        "permission",
        "license",
        "licence",
        "not authorized",
        "unauthorized",
        "unauthorised",
    )
    return any(marker in folded for marker in markers)


def validate_index_ticker(text: str) -> str:
    ticker = " ".join(str(text or "").split())
    if not ticker.endswith(" Index"):
        raise ValueError(
            "Index must be a Bloomberg index yellow key ending in ' Index'."
        )
    return ticker


def selection_status(typed_index: str, typed_month: str, loaded: dict | None) -> dict:
    """Say what the screen is showing, and which upper selectors still need Update."""
    index_text = " ".join(str(typed_index or "").split()) or "(blank)"
    month_text = " ".join(str(typed_month or "").split()) or "(blank)"
    if not loaded:
        return {
            "pending": True,
            "text": (
                f"Nothing loaded. Index {index_text}. Month-end {month_text}. "
                "Click Update to request this comparison."
            ),
        }
    loaded_index = " ".join(str(loaded.get("index") or "").split()) or "(blank)"
    previous = loaded.get("previous") or ""
    selected = " ".join(str(loaded.get("selected") or "").split())
    kind = loaded.get("kind") or ""
    pending = []
    if index_text != loaded_index:
        pending.append(f"index {index_text} (loaded {loaded_index})")
    if month_text != selected:
        pending.append(f"month-end {month_text} (loaded {selected or '(blank)'})")
    showing = f"Showing {loaded_index} · {previous} → {selected} ({kind})."
    if loaded.get("status") not in (None, "ok"):
        showing += " Comparison unavailable."
    if not pending:
        return {
            "pending": False,
            "text": showing + " Index and month-end match the loaded comparison.",
        }
    joined = "; ".join(pending)
    return {
        "pending": True,
        "text": showing + f" Pending: {joined}. Click Update to load the change.",
    }


def _weekday_month_end(calendar_month_end: pd.Timestamp) -> pd.Timestamp:
    """Last weekday on or before a calendar month-end. Weekends only."""
    end = pd.Timestamp(calendar_month_end).normalize()
    if pd.isna(end):
        raise ValueError("Calendar month-end is missing.")
    days = pd.bdate_range(end=end, periods=1)
    if len(days) == 0:
        raise ValueError(f"No weekday on or before {end.date()}.")
    return pd.Timestamp(days[0]).normalize()


def _require_today(today) -> pd.Timestamp:
    stamp = pd.Timestamp.today().normalize() if today is None else pd.Timestamp(today).normalize()
    if pd.isna(stamp):
        raise ValueError("Today is missing.")
    return stamp


def effective_dates(today) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Return this month's effective weekday and the projected effective weekday."""
    today = _require_today(today)
    this_calendar_end = today + pd.offsets.MonthEnd(0)
    this_effective = _weekday_month_end(this_calendar_end)
    if today < this_effective:
        return this_effective, this_effective
    projected = _weekday_month_end(this_calendar_end + pd.offsets.MonthEnd(1))
    return this_effective, projected


def default_month_end(today) -> str:
    """The effective date of today's calendar month, whether or not it has locked."""
    this_effective, _projected = effective_dates(today)
    return this_effective.strftime("%Y-%m-%d")


def month_end_choices(today, count: int) -> list[tuple[str, str]]:
    """Dropdown pairs ``(label, YYYY-MM-DD)``, newest first.

    The list is local. It does not request BQL. The newest row is the
    projected effective date when that date is still ahead of the locked month.
    """
    if count < 1:
        raise ValueError("Month-end choice count must be at least 1.")
    today = _require_today(today)
    this_effective, projected = effective_dates(today)
    this_calendar_end = today + pd.offsets.MonthEnd(0)
    ordered: list[tuple[pd.Timestamp, str]] = []
    if projected != this_effective:
        ordered.append((projected, "projected"))
    ordered.append((this_effective, "projected" if projected == this_effective else "historical"))
    cursor = this_calendar_end - pd.offsets.MonthEnd(1)
    while len(ordered) < count:
        ordered.append((_weekday_month_end(cursor), "historical"))
        cursor = cursor - pd.offsets.MonthEnd(1)
    choices = []
    seen = set()
    for day, kind in ordered:
        iso = day.strftime("%Y-%m-%d")
        if iso in seen:
            continue
        seen.add(iso)
        label = f"{iso} (Projected)" if kind == "projected" else iso
        choices.append((label, iso))
        if len(choices) >= count:
            break
    return choices


def comparison_for(selected: str, today, allowed: list[str] | None = None) -> Comparison:
    """One month-end versus the previous month-end. Rejects dates outside the dropdown."""
    iso = " ".join(str(selected or "").split())
    today = _require_today(today)
    allowed_dates = (
        list(allowed)
        if allowed is not None
        else [value for _label, value in month_end_choices(today, MONTH_END_CHOICES)]
    )
    if iso not in allowed_dates:
        raise ValueError(f"Month-end {iso} is not in the dropdown.")
    selected_day = pd.Timestamp(iso)
    calendar_end = selected_day + pd.offsets.MonthEnd(0)
    previous = _weekday_month_end(calendar_end - pd.offsets.MonthEnd(1)).strftime("%Y-%m-%d")
    _this_effective, projected = effective_dates(today)
    kind = "projected" if iso == projected.strftime("%Y-%m-%d") else "historical"
    return Comparison(previous_date=previous, selected_date=iso, kind=kind)


def apply_country_name_overrides(series: pd.Series, overrides=None) -> pd.Series:
    """Replace configured country_full_name() values. Other names stay as returned."""
    rows = COUNTRY_NAME_OVERRIDES if overrides is None else overrides
    mapping = {}
    for source, target in rows:
        key = " ".join(str(source or "").split()).casefold()
        shown = " ".join(str(target or "").split())
        if key and shown:
            mapping[key] = shown
    if not mapping:
        return series

    def replace(value):
        text = " ".join(str(value).split())
        return mapping.get(text.casefold(), value)

    return series.map(replace)


# Values that are display labels, not country names. Keyed lower case so the
# match ignores spacing and case; the value is the frozen label to show.
_DISPLAY_LABELS = {
    "(blank)": "(blank)",
    MBS_TBA_LABEL.casefold(): MBS_TBA_LABEL,
    MUNICIPAL_LABEL.casefold(): MUNICIPAL_LABEL,
}


def proper_country_name(value: str) -> str:
    """Excel PROPER-style display: first letter of each word upper, rest lower.

    ``(blank)`` and the two frozen display labels ``MBS/TBA`` and
    ``Municipal`` come back unchanged. They are not country names, and
    title-casing ``MBS/TBA`` would turn a cached reload into ``Mbs/Tba``,
    which no longer matches the Book label or the blank fill below.
    """
    text = " ".join(str(value or "").split())
    if not text:
        return text
    if text.casefold() in {"nan", "none", "nat"}:
        return text
    label = _DISPLAY_LABELS.get(text.casefold())
    if label is not None:
        return label
    return text.title()


def _blank_text(series: pd.Series) -> pd.Series:
    text = series.fillna("").astype(str).str.strip()
    return text.replace({"": "(blank)", "nan": "(blank)", "None": "(blank)", "NaT": "(blank)"})


def rating_bucket(value) -> str:
    """Exactly three classifications: IG, HY, NR.

    Team convention: anything without a usable letter grade is NR. That
    includes a blank, a stated NR, N.A. on an MBS/TBA or Municipal row, and a
    vendor numeric scale. The raw Rating text still shows what the vendor
    returned, so a number is visible without being mapped onto a letter.
    """
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return RATING_NO_GRADE
    text = str(value).strip()
    if text.casefold() in {"nan", "none", "nat"}:
        return RATING_NO_GRADE
    compact = text.upper().replace(" ", "")
    try:
        float(compact)
        # A numeric scale is not mapped onto a letter (card 28), and it has no
        # letter grade, so it is NR rather than a fourth bucket.
        return RATING_NO_GRADE
    except ValueError:
        pass
    token = compact.replace("(P)", "").replace("(EXP)", "")
    if token in SP_IG or token in MOODY_IG:
        return "IG"
    if token in SP_HY or token in MOODY_HY:
        return "HY"
    return RATING_NO_GRADE


def _tenor_bucket_series(tenor: pd.Series) -> pd.Series:
    """Map tenor years to card-28 buckets without leaving a NaN bucket behind.

    Negative and non-finite tenors are bad data, so they stay ``Missing``.
    Values at or above the last edge are ``20Y+``.
    """
    bucket = pd.Series("Missing", index=tenor.index, dtype="object")
    for index, label in enumerate(TENOR_LABELS):
        lower = TENOR_BINS[index]
        upper = TENOR_BINS[index + 1] if index + 1 < len(TENOR_BINS) else None
        if upper is None:
            mask = tenor.ge(lower)
        else:
            mask = tenor.ge(lower) & tenor.lt(upper)
        bucket = bucket.mask(mask, label)
    return bucket


def collapse_duplicate_ids(frame: pd.DataFrame) -> pd.DataFrame:
    """One row per ID, keeping the last non-null value in each column.

    An item that answers with more than one row per security carries the same
    value on every row, or a value on one row and null on the others.
    ``drop_duplicates(keep="last")`` decides that by position, so it can keep
    the row where a column is empty and silently blank a value that did
    arrive. Forward-filling first preserves "the last value wins" for two real
    conflicting values while never preferring a null over a value.
    """
    if "ID" not in frame.columns or not frame["ID"].duplicated().any():
        return frame
    ordered = frame.loc[:, [column for column in frame.columns if column != "ID"] + ["ID"]]
    ordered = ordered.ffill()
    collapsed = ordered.groupby("ID", sort=False, as_index=False).last()
    return collapsed.loc[:, [column for column in frame.columns if column in collapsed.columns]]


def prepare_members(frame: pd.DataFrame, notes: list[str] | None = None) -> pd.DataFrame:
    """Normalize one snapshot. Does not invent weights."""
    notes = notes if notes is not None else []
    if frame is None or frame.empty:
        return pd.DataFrame(columns=["ID", "Weight", "Book"])
    out = frame.copy()
    if "ID" not in out.columns:
        notes.append("Snapshot has no ID column.")
        return pd.DataFrame(columns=["ID", "Weight", "Book"])
    out["ID"] = out["ID"].fillna("").astype(str).str.strip()
    blank_ids = out["ID"].isin(["", "nan", "None", "NaT"])
    blank_count = int(blank_ids.sum())
    if blank_count:
        notes.append(f"Dropped {blank_count} rows with a blank ID.")
    out = out.loc[~blank_ids].copy()
    duplicate_count = int(out["ID"].duplicated().sum())
    if duplicate_count:
        notes.append(f"Dropped {duplicate_count} duplicate IDs (kept last non-null).")
        out = collapse_duplicate_ids(out)
    if "Weight" in out.columns:
        out["Weight"] = pd.to_numeric(out["Weight"], errors="coerce")
        # The unit question is "does this book sum to 1 or to 100", so it is the
        # net sum that answers it. Using the absolute sum meant a snapshot with
        # one negative weight ([1.2, -0.2]: net 1.0, absolute 1.4) was read as
        # neither unit and left unscaled, printing a whole book 100 times too
        # small. A net sum that is not positive carries no unit information, so
        # the absolute sum is used as the fallback.
        weight_net = float(out["Weight"].sum(skipna=True))
        weight_abs = float(out["Weight"].abs().sum(skipna=True))
        weight_basis = weight_net if weight_net > 0 else weight_abs
        if 0 < weight_basis <= WEIGHT_FRACTION_SUM_MAX:
            out["Weight"] = out["Weight"] * 100.0
            notes.append("Weights arrived as fractions and were scaled to percent points.")
    for column in ("Tenor", "Coupon", *SPREAD_FIELDS, *DURATION_FIELDS, *YIELD_FIELDS):
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce")
            out[column] = out[column].replace([np.inf, -np.inf], np.nan)
    for column in ("Sector", "Country", "Currency", "Security Type", "Rating", "Name", "Issuer"):
        if column in out.columns:
            out[column] = _blank_text(out[column])
    if "Country" in out.columns:
        out["Country"] = apply_country_name_overrides(out["Country"]).map(proper_country_name)
    security = out["Security Type"] if "Security Type" in out.columns else pd.Series("", index=out.index)
    tba = security.astype(str).str.contains(r"MBS|TBA|Pool", case=False, na=False)
    tba = tba | out["ID"].astype(str).str.contains("Mtge", case=False, na=False)
    out["Book"] = np.where(tba, MBS_TBA_LABEL, "Standard")

    # A blank country / sector / rating on an MBS or TBA row is the book label,
    # not missing data. Those bonds settle in USD, so a blank currency is USD.
    blank = {"", "(blank)", "nan", "none", "nat"}
    mbs = out["Book"] == MBS_TBA_LABEL
    for column in ("Country", "Sector"):
        if column in out.columns:
            fill = mbs & out[column].astype(str).str.strip().str.casefold().isin(blank)
            out.loc[fill, column] = MBS_TBA_LABEL
    if "Currency" in out.columns:
        fill = mbs & out["Currency"].astype(str).str.strip().str.casefold().isin(blank)
        out.loc[fill, "Currency"] = "USD"

    # US municipal bonds end their yellow key with Muni. They are Standard
    # bonds, always USD, and carry no applicable rating.
    municipal = out["ID"].astype(str).str.casefold().str.endswith(MUNICIPAL_ID_SUFFIX.casefold())
    if municipal.any():
        out.loc[municipal, "Country"] = MUNICIPAL_LABEL
        out.loc[municipal, "Sector"] = MUNICIPAL_LABEL
        out.loc[municipal, "Currency"] = "USD"
    rated_category = mbs | municipal
    has_rating = "Rating" in out.columns
    if not has_rating:
        # A field that never arrived is NR, the same classification as an
        # unrated bond. The log names the item, so the missing request is not
        # hidden by the label.
        notes.append(
            "Snapshot has no Rating column; every bond is classified NR."
        )
        out["Rating"] = RATING_MISSING
    out.loc[rated_category, "Rating"] = RATING_NOT_APPLICABLE

    if "Tenor" in out.columns:
        out["Tenor Bucket"] = _tenor_bucket_series(pd.to_numeric(out["Tenor"], errors="coerce"))
    else:
        out["Tenor Bucket"] = "Missing"
    # MBS/TBA settle forward; a missing tenor is not bad data but "not
    # applicable". Keep a real numeric tenor bucket when the field is present.
    mbs_missing = mbs & out["Tenor Bucket"].eq("Missing")
    out.loc[mbs_missing, "Tenor Bucket"] = TENOR_NOT_APPLICABLE
    if has_rating:
        out["Rating Bucket"] = out["Rating"].map(rating_bucket)
    else:
        out["Rating Bucket"] = RATING_MISSING
    out.loc[rated_category, "Rating Bucket"] = RATING_NOT_APPLICABLE
    return out.reset_index(drop=True)


# Classification labels that must agree across the Start and End snapshot.
# Weights and analytics stay date-specific; only these display categories are
# aligned by ID.
ALIGNED_LABEL_COLUMNS = ("Book", "Country", "Sector", "Tenor Bucket", "Currency")
_MISSING_LABELS = {"", "(blank)", "nan", "none", "nat"}
# ``prepare_members`` rewrites an empty text value to "(blank)" before the frame
# ever reaches the cache, so anything asking "did this column actually arrive?"
# has to treat that sentinel as empty. Tests that write a literal "" CSV miss
# it, which is how a cache guard can pass its own test and never fire in
# production.
BLANK_SENTINEL = "(blank)"
# Tenor uses its own word for "no maturity", because a perpetual has no tenor
# but is a real bond with real attributes.
TENOR_MISSING = "Missing"


def column_has_usable_value(series: pd.Series, column: str = "") -> bool:
    """True when at least one row of ``column`` carries a real value.

    The one definition of "this identity column is populated", shared by the
    cache guard and the per-month status, so the two can never disagree about
    whether a month is usable.
    """
    if series is None or len(series) == 0:
        return False
    text = series.fillna("").astype(str).str.strip()
    mask = ~text.str.casefold().isin(_MISSING_LABELS)
    if column == "Tenor Bucket":
        mask &= text.ne(TENOR_MISSING)
    return bool(mask.any())


def _usable_label(value, column: str) -> bool:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return False
    text = str(value).strip()
    if text.casefold() in _MISSING_LABELS:
        return False
    # NR is a real classification now, not a "missing" marker, so it wins like
    # IG and HY do. That keeps one ID on one classification and stops an
    # MBS/TBA or unrated row from inheriting an old investment-grade value.
    if column == "Tenor Bucket" and text == "Missing":
        return False
    return True


def align_snapshot_labels(previous: pd.DataFrame, latest: pd.DataFrame) -> None:
    """One classification per ID, using the latest non-missing value.

    If the latest snapshot has a usable value it wins, even when it differs
    from the previous month-end. If the latest value is missing, the previous
    value fills both snapshots. IDs that exist on only one date keep that
    date's values. Weights and analytics are never copied.
    """
    if previous is None or latest is None or previous.empty or latest.empty:
        return
    if "ID" not in previous.columns or "ID" not in latest.columns:
        return

    # A duplicate ID makes ``reindex`` below raise, which would abort the whole
    # Update over two rows for one security. The normal path already collapsed
    # duplicates, but this function is called directly too, so it normalizes a
    # shape it can handle rather than throwing. With unique IDs these are the
    # same objects, so the guard costs nothing.
    prev_view = collapse_duplicate_ids(previous)
    lat_view = collapse_duplicate_ids(latest)

    # The membership mask depends only on the frame and the common ID set, not
    # on the column being aligned. Computing it inside the per-column loop made
    # ``isin`` run over the whole frame twelve times per Update for the same
    # answer; the masks below are the same expression, hoisted.
    common_ids = pd.Index(prev_view["ID"]).intersection(pd.Index(lat_view["ID"]))
    mask_previous = previous["ID"].isin(common_ids)
    mask_latest = latest["ID"].isin(common_ids)
    sides = ((previous, mask_previous), (latest, mask_latest))

    for column in ALIGNED_LABEL_COLUMNS:
        if column not in previous.columns or column not in latest.columns:
            continue
        prev = prev_view.set_index("ID")[column]
        lat = lat_view.set_index("ID")[column]
        common = prev.index.intersection(lat.index)
        if common.empty:
            continue
        prev_values = prev.reindex(common)
        lat_values = lat.reindex(common)
        latest_ok = lat_values.map(lambda value: _usable_label(value, column))
        previous_ok = prev_values.map(lambda value: _usable_label(value, column))
        chosen = lat_values.where(latest_ok, prev_values.where(previous_ok, lat_values))
        mapping = chosen.to_dict()
        for frame, mask in sides:
            frame.loc[mask, column] = frame.loc[mask, "ID"].map(mapping)

    if "Rating Bucket" not in previous.columns or "Rating Bucket" not in latest.columns:
        return
    prev_bucket = prev_view.set_index("ID")["Rating Bucket"]
    lat_bucket = lat_view.set_index("ID")["Rating Bucket"]
    common = prev_bucket.index.intersection(lat_bucket.index)
    if common.empty:
        return
    prev_values = prev_bucket.reindex(common)
    lat_values = lat_bucket.reindex(common)
    # NR is a real classification now, so it wins like IG and HY. The only
    # value that may be filled from the previous month-end is a genuinely
    # absent one (blank), which _usable_label already rejects.
    latest_ok = lat_values.map(lambda value: _usable_label(value, "Rating Bucket"))
    previous_ok = prev_values.map(lambda value: _usable_label(value, "Rating Bucket"))
    use_previous = (~latest_ok) & previous_ok
    chosen_bucket = lat_values.where(latest_ok, prev_values.where(previous_ok, lat_values))
    bucket_mapping = chosen_bucket.to_dict()

    rating_mapping = {}
    if "Rating" in previous.columns and "Rating" in latest.columns:
        prev_rating = prev_view.set_index("ID")["Rating"]
        lat_rating = lat_view.set_index("ID")["Rating"]
        for bond_id in common:
            chosen = bucket_mapping.get(bond_id)
            latest_text = lat_rating.get(bond_id, "")
            previous_text = prev_rating.get(bond_id, "")
            if use_previous.get(bond_id, False):
                rating_mapping[bond_id] = previous_text
            elif _usable_label(latest_text, "Rating"):
                rating_mapping[bond_id] = latest_text
            elif (
                _usable_label(previous_text, "Rating")
                and prev_values.get(bond_id) == chosen
            ):
                # The display text is blank this month but last month's text
                # belongs to the same classification, so keep the vendor value
                # (a numeric scale, for example) instead of showing (blank).
                # It is never taken across classifications, which would show
                # an IG letter beside an NR bucket.
                rating_mapping[bond_id] = previous_text
            else:
                rating_mapping[bond_id] = latest_text

    for frame, mask in sides:
        frame.loc[mask, "Rating Bucket"] = frame.loc[mask, "ID"].map(bucket_mapping)
        if rating_mapping:
            frame.loc[mask, "Rating"] = frame.loc[mask, "ID"].map(rating_mapping)


def rating_class_conflicts(previous: pd.DataFrame, latest: pd.DataFrame) -> tuple[str, ...]:
    """IDs classified differently on the two month-ends.

    A bond must sit in exactly one Rating selection. alignment above is
    supposed to make that impossible for a common ID; this function is the
    check that proves it, not the fix. It exists so a later edit that stops
    writing one side cannot silently bring back a bond that appears under two
    Rating selections.
    """
    if previous is None or latest is None or previous.empty or latest.empty:
        return ()
    if "ID" not in previous.columns or "ID" not in latest.columns:
        return ()
    if "Rating Bucket" not in previous.columns or "Rating Bucket" not in latest.columns:
        return ()
    prev_bucket = previous.drop_duplicates("ID").set_index("ID")["Rating Bucket"]
    lat_bucket = latest.drop_duplicates("ID").set_index("ID")["Rating Bucket"]
    common = prev_bucket.index.intersection(lat_bucket.index)
    if common.empty:
        return ()
    prev_values = prev_bucket.reindex(common).astype(str)
    lat_values = lat_bucket.reindex(common).astype(str)
    conflicting = common[prev_values.ne(lat_values).to_numpy()]
    return tuple(str(bond_id) for bond_id in conflicting)


def _usable(frame: pd.DataFrame) -> bool:
    return (
        frame is not None
        and not frame.empty
        and "ID" in frame.columns
        and "Weight" in frame.columns
        and frame["Weight"].notna().any()
    )


def diff_members(previous: pd.DataFrame, latest: pd.DataFrame, book: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """ID diff inside one book. ``All`` keeps both books."""
    def _book(frame: pd.DataFrame) -> pd.DataFrame:
        if frame is None or frame.empty:
            return pd.DataFrame(columns=["ID", "Weight", "Book"])
        if book == "All" or "Book" not in frame.columns:
            return frame.copy()
        return frame.loc[frame["Book"] == book].copy()

    previous_book = _book(previous)
    latest_book = _book(latest)
    previous_ids = set(previous_book["ID"].astype(str)) if "ID" in previous_book.columns else set()
    latest_ids = set(latest_book["ID"].astype(str)) if "ID" in latest_book.columns else set()
    added = latest_book.loc[~latest_book["ID"].astype(str).isin(previous_ids)].copy()
    exited = previous_book.loc[~previous_book["ID"].astype(str).isin(latest_ids)].copy()
    if "Weight" in added.columns and not added.empty:
        added = added.sort_values("Weight", ascending=False)
    if "Weight" in exited.columns and not exited.empty:
        exited = exited.sort_values("Weight", ascending=False)
    return previous_book, latest_book, added, exited


def book_unchanged(previous: pd.DataFrame, latest: pd.DataFrame, book: str) -> bool:
    """True when the selected book has the same IDs on both dates."""
    _previous, _latest, added, exited = diff_members(previous, latest, book)
    return added.empty and exited.empty


# Columns printed with a percent sign in the copy tables. The stored value is
# already in percent points (prepare_members scales a fraction sum to 100), so
# this is a display suffix, not a multiplication.
PERCENT_COLUMNS = ("Weight",)

EXPORT_COLUMNS = (
    "Action",
    "ID",
    "Name",
    "Issuer",
    "ISIN",
    "SEDOL",
    "Country",
    "Sector",
    # Weight follows the identity and classification columns so the two copy
    # tables read left to right: what it is, where it sits, then how big.
    "Weight",
    "Tenor Bucket",
    "Tenor",
    "Rating",
    "Rating Bucket",
    "Currency",
    "Coupon",
    *SPREAD_FIELDS,
    *DURATION_FIELDS,
    *YIELD_FIELDS,
    "Maturity",
    "Book",
    "Security Type",
    "AS_OF_DATE",
)


def change_export_frame(transition: Transition, book: str) -> pd.DataFrame:
    """Every add and exit in the book, with Weight. Filters are not applied."""
    empty = pd.DataFrame(columns=list(EXPORT_COLUMNS))
    if transition is None or transition.status != "ok":
        return empty
    _previous, _latest, added, exited = diff_members(transition.previous, transition.latest, book)
    frames = []
    if added is not None and not added.empty:
        add_rows = added.copy()
        add_rows["Action"] = "Add"
        frames.append(add_rows)
    if exited is not None and not exited.empty:
        exit_rows = exited.copy()
        exit_rows["Action"] = "Exit"
        frames.append(exit_rows)
    if not frames:
        return empty
    combined = pd.concat(frames, ignore_index=True, sort=False)
    if "Weight" not in combined.columns:
        raise ValueError("Change export requires Weight on every add and exit.")
    combined["Weight"] = pd.to_numeric(combined["Weight"], errors="coerce")
    keep = [column for column in EXPORT_COLUMNS if column in combined.columns]
    if "Weight" not in keep or "Action" not in keep:
        raise ValueError("Change export requires Action and Weight.")
    combined = combined.loc[:, keep].sort_values(["Action", "Weight"], ascending=[True, False])
    return combined.reset_index(drop=True)


def _export_cell(value, column: str = "") -> str:
    """One copy-friendly cell string. Dates become ISO text, NaN becomes blank."""
    if value is None:
        return ""
    if isinstance(value, float) and pd.isna(value):
        return ""
    if isinstance(value, (pd.Timestamp, np.datetime64)) or hasattr(value, "strftime"):
        try:
            if pd.isna(value):
                return ""
            return pd.Timestamp(value).strftime("%Y-%m-%d")
        except (TypeError, ValueError):
            return str(value)
    if isinstance(value, (float, np.floating)):
        if pd.isna(value):
            return ""
        text = f"{value:.6f}".rstrip("0").rstrip(".")
        text = text or "0"
        if column in PERCENT_COLUMNS:
            # Weight already arrived in percent points, so the sign is the only
            # change: 0.95 stays 0.95 and reads 0.95%. Rounding is not applied,
            # because a small MBS slice would otherwise print as 0.00%.
            return f"{text}%"
        return text
    return str(value)


def export_display_frame(frame: pd.DataFrame, columns: tuple[str, ...]) -> pd.DataFrame:
    """Copy-to-Excel frame: a repeated header row first, then the data as text.

    A widget DataGrid copy does not carry the column header. Repeating the
    column names in the first data row keeps the header when the whole table is
    pasted into Excel.
    """
    keep = [column for column in columns if frame is not None and column in frame.columns]
    if not keep:
        # Nothing to copy. The header row is still required, because the whole
        # point of this frame is that a copy keeps its column names. Returning
        # the header alone also avoids a KeyError on frame.loc[:, keep] for a
        # non-empty frame that carries none of the requested columns.
        header = [str(column) for column in columns]
        return pd.DataFrame([header], columns=header)
    header = [str(column) for column in keep]
    rows = []
    if frame is not None and not frame.empty:
        rows = [
            [_export_cell(value, column) for column, value in zip(keep, row)]
            for row in frame.loc[:, keep].itertuples(index=False, name=None)
        ]
    return pd.DataFrame([header] + rows, columns=keep)


def build_transition(
    snapshots: dict[str, pd.DataFrame],
    comparison: Comparison,
    statuses: dict[str, str],
    index_mv_ratio: float | None = None,
    turnover_basis: str = "approx",
) -> Transition:
    """One selected month-end against the previous month-end."""
    previous_date = comparison.previous_date
    latest_date = comparison.selected_date
    kind = comparison.kind
    label = f"{previous_date} → {latest_date}"
    if kind == "projected":
        label = f"Projected {label}"
    previous_status = statuses.get(previous_date, "missing")
    latest_status = statuses.get(latest_date, "missing")
    previous = snapshots.get(previous_date, pd.DataFrame())
    latest = snapshots.get(latest_date, pd.DataFrame())
    # "partial" reached the screen as a complete answer before. It is still
    # usable, but it must travel with the reason instead of a clean "ok".
    usable_statuses = ("ok", "partial")
    if (
        previous_status not in usable_statuses
        or latest_status not in usable_statuses
        or not _usable(previous)
        or not _usable(latest)
    ):
        return Transition(
            label=label,
            previous_date=previous_date,
            latest_date=latest_date,
            kind=kind,
            status="unavailable",
            message=(
                f"{previous_date}={previous_status}; {latest_date}={latest_status}. "
                "This comparison was not calculated."
            ),
        )
    warnings: list[str] = []
    for day, status in ((previous_date, previous_status), (latest_date, latest_status)):
        if status == "partial":
            warnings.append(
                f"{day}: at least one required item did not parse. "
                "Affected dimensions may be blank or classified NR."
            )
    return Transition(
        label=label,
        previous_date=previous_date,
        latest_date=latest_date,
        kind=kind,
        status="ok",
        previous=previous,
        latest=latest,
        index_mv_ratio=index_mv_ratio,
        turnover_basis=turnover_basis,
        warnings=tuple(warnings),
    )


def apply_dimension_filters(frame: pd.DataFrame, filters: dict[str, set[str]] | None) -> pd.DataFrame:
    """Empty or missing selections keep every row."""
    if frame is None or frame.empty or not filters:
        return frame if frame is not None else pd.DataFrame()
    mask = pd.Series(True, index=frame.index)
    for column, selected in filters.items():
        if not selected or column not in frame.columns:
            continue
        mask = mask & frame[column].astype(str).isin(selected)
    return frame.loc[mask].copy()


def weighted_mean(frame: pd.DataFrame, column: str) -> float:
    """Weight-average one column. Skips nulls, bad weights, and the OAS sentinel."""
    if frame is None or frame.empty or column not in frame.columns or "Weight" not in frame.columns:
        return float("nan")
    values = pd.to_numeric(frame[column], errors="coerce").replace([np.inf, -np.inf], np.nan)
    weights = pd.to_numeric(frame["Weight"], errors="coerce").replace([np.inf, -np.inf], np.nan)
    if column == "OAS":
        values = values.where(values < OAS_EXCLUDE_AT_OR_ABOVE)
    valid = values.notna() & weights.notna() & weights.gt(0)
    if not bool(valid.any()):
        return float("nan")
    denominator = float(weights.loc[valid].sum())
    if denominator == 0:
        return float("nan")
    return float((values.loc[valid] * weights.loc[valid]).sum() / denominator)


def _side_metrics(frame: pd.DataFrame) -> dict:
    weight = pd.to_numeric(frame["Weight"], errors="coerce") if frame is not None and not frame.empty and "Weight" in frame.columns else pd.Series(dtype=float)
    return {
        "Count": int(frame["ID"].nunique()) if frame is not None and not frame.empty and "ID" in frame.columns else 0,
        "Weight": float(weight.sum(skipna=True)) if not weight.empty else 0.0,
        **{field: weighted_mean(frame, field) for field in SPREAD_FIELDS},
        **{field: weighted_mean(frame, field) for field in DURATION_FIELDS},
        **{field: weighted_mean(frame, field) for field in YIELD_FIELDS},
        "Tenor": weighted_mean(frame, "Tenor"),
        "Coupon": weighted_mean(frame, "Coupon"),
    }


def summarize(transition: Transition, dimension: str, book: str, filters: dict[str, set[str]] | None) -> tuple[pd.DataFrame, dict]:
    """Bucket metrics for one transition. Unavailable transitions return an empty table."""
    column = DIMENSIONS.get(dimension, dimension)
    if transition.status != "ok":
        return pd.DataFrame(), {"status": transition.status, "message": transition.message}
    previous, latest, added, exited = diff_members(transition.previous, transition.latest, book)
    previous = apply_dimension_filters(previous, filters)
    latest = apply_dimension_filters(latest, filters)
    added = apply_dimension_filters(added, filters)
    exited = apply_dimension_filters(exited, filters)
    keys = set()
    for frame in (previous, latest, added, exited):
        if column in frame.columns and not frame.empty:
            keys.update(frame[column].astype(str).tolist())
    rows = []
    ratio = transition.index_mv_ratio
    usable_ratio = (
        float(ratio)
        if ratio is not None and np.isfinite(float(ratio)) and float(ratio) > 0
        else None
    )
    effective_ratio = usable_ratio if usable_ratio is not None else 1.0
    turnover_basis = "official" if usable_ratio is not None else "approx"
    for key in sorted(keys, key=str):
        def _slice(frame: pd.DataFrame) -> pd.DataFrame:
            if frame.empty or column not in frame.columns:
                return frame.iloc[0:0]
            return frame.loc[frame[column].astype(str) == key]

        before = _side_metrics(_slice(previous))
        after = _side_metrics(_slice(latest))
        add_metrics = _side_metrics(_slice(added))
        exit_metrics = _side_metrics(_slice(exited))
        bucket_turnover = exit_metrics["Weight"] + add_metrics["Weight"] * effective_ratio
        bucket_rate = (
            bucket_turnover / before["Weight"] * 100.0
            if before["Weight"] > 0
            else float("nan")
        )
        row = {
            column: key,
            "Begin Count": before["Count"],
            "End Count": after["Count"],
            "+/- Count": after["Count"] - before["Count"],
            "Begin Weight": before["Weight"],
            "End Weight": after["Weight"],
            "+/- Weight": after["Weight"] - before["Weight"],
            "Turnover (index %)": bucket_turnover,
            "Turnover Rate (%)": bucket_rate,
        }
        for field in SPREAD_FIELDS:
            row[f"Begin {field}"] = before[field]
            row[f"End {field}"] = after[field]
            row[f"+/- {field}"] = after[field] - before[field]
        for field in (*DURATION_FIELDS, *YIELD_FIELDS):
            row[f"Begin {field}"] = before[field]
            row[f"End {field}"] = after[field]
            row[f"+/- {field}"] = after[field] - before[field]
        row["Begin Tenor"] = before["Tenor"]
        row["End Tenor"] = after["Tenor"]
        row["+/- Tenor"] = after["Tenor"] - before["Tenor"]
        row["Add Count"] = add_metrics["Count"]
        row["Exit Count"] = exit_metrics["Count"]
        row["Add Weight"] = add_metrics["Weight"]
        row["Exit Weight"] = exit_metrics["Weight"]
        rows.append(row)
    summary = pd.DataFrame(rows)
    if not summary.empty:
        turnover = summary["Add Weight"].fillna(0) + summary["Exit Weight"].fillna(0)
        summary = summary.assign(_turnover=turnover).sort_values("_turnover", ascending=False).drop(columns="_turnover")
    headline = {
        "status": "ok",
        "message": "",
        "before": _side_metrics(previous),
        "after": _side_metrics(latest),
        "added": _side_metrics(added),
        "exited": _side_metrics(exited),
        "added_frame": added,
        "exited_frame": exited,
        "turnover": float("nan"),
        "turnover_rate": float("nan"),
        "turnover_basis": turnover_basis,
        "filtered": bool(filters),
    }
    headline["turnover"] = (
        headline["exited"]["Weight"]
        + headline["added"]["Weight"] * effective_ratio
    )
    if headline["before"]["Weight"] > 0:
        headline["turnover_rate"] = (
            headline["turnover"] / headline["before"]["Weight"] * 100.0
        )
    return summary, headline


def grid_display_frame(frame: pd.DataFrame, columns: tuple[str, ...]) -> pd.DataFrame:
    """Exact frame for ipydatagrid: requested columns only, dates as strings.

    ipydatagrid serializes datetime columns with ``Date.toISOString()``. A NaT
    (common on MBS/TBA maturity) raises ``RangeError: Invalid time value`` and
    the whole grid fails to instantiate. The grid also must not receive hidden
    helper columns such as ``Maturity`` or ``AS_OF_DATE``.
    """
    if frame is None:
        return pd.DataFrame(columns=list(columns))
    keep = [column for column in columns if column in frame.columns]
    if not keep:
        return pd.DataFrame(columns=list(columns))
    out = frame.loc[:, keep].copy()
    for column in out.columns:
        series = out[column]
        if pd.api.types.is_float_dtype(series):
            out[column] = series.round(4)
        elif pd.api.types.is_datetime64_any_dtype(series):
            out[column] = series.dt.strftime("%Y-%m-%d").fillna("")
        elif series.dtype == object:
            out[column] = series.map(_grid_cell)
    return out.reset_index(drop=True)


def _grid_cell(value):
    """Plain text for one grid cell. NaT, NaN, and Timestamps become safe strings."""
    if value is None:
        return ""
    if isinstance(value, (pd.Timestamp, np.datetime64)) or hasattr(value, "strftime"):
        try:
            if pd.isna(value):
                return ""
            return pd.Timestamp(value).strftime("%Y-%m-%d")
        except (TypeError, ValueError):
            return str(value)
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return value


def book_counts(frame: pd.DataFrame) -> dict[str, int]:
    if frame is None or frame.empty or "Book" not in frame.columns:
        return {"Standard": 0, "MBS/TBA": 0}
    counts = frame["Book"].value_counts()
    return {
        "Standard": int(counts.get("Standard", 0)),
        "MBS/TBA": int(counts.get("MBS/TBA", 0)),
    }


def filter_choices(frames: list[pd.DataFrame]) -> dict[str, list[str]]:
    choices = {}
    for column in DIMENSIONS.values():
        values = []
        for frame in frames:
            if frame is None or frame.empty or column not in frame.columns:
                continue
            values.extend(frame[column].dropna().astype(str).tolist())
        choices[column] = sorted(set(values))
    return choices


def currency_choices(frames: list[pd.DataFrame], book: str | None = None) -> list[str]:
    """Distinct currencies on the extracted constituents.

    ``book`` of ``All`` or empty keeps every book. Any other book keeps only
    that book's rows. An empty list means nothing has been extracted yet.
    """
    values = []
    for frame in frames:
        if frame is None or frame.empty or "Currency" not in frame.columns:
            continue
        rows = frame
        if book and book != "All" and "Book" in frame.columns:
            rows = frame.loc[frame["Book"].astype(str) == book]
        if rows.empty:
            continue
        values.extend(rows["Currency"].dropna().astype(str).tolist())
    return sorted({text for text in values if text and text not in {"nan", "None", "NaT"}})


def caption_html(previous_date: str | None = None, selected_date: str | None = None) -> str:
    """Footnotes: as-of weight dates, rating buckets, and the turnover formula.

    The chart order lives on the chart axis, the Begin/End definition sits
    under the Bucket summary, and the export sign is on the Export tooltip.
    Request and license errors stay in the live status line.
    """
    add_date = selected_date or "the selected month-end"
    exit_date = previous_date or "the previous month-end"
    return (
        f"<p style='margin:4px 0;color:#444'><b>As-of weights:</b> Add/End weight "
        f"is as of {add_date}; Exit/Begin weight is as of {exit_date}.</p>"
        "<p style='margin:4px 0;color:#444'><b>Rating buckets:</b> IG = investment "
        "grade (BBB- / Baa3 and above); HY = high yield (BB+ / Ba1 and below); "
        "NR = no usable letter grade, which covers an unrated bond, a blank, "
        "N.A. on an MBS/TBA or Municipal row, and a vendor numeric scale. The "
        "Rating column still shows the text the vendor returned.</p>"
        "<p style='margin:4px 0;color:#444'><b>Turnover:</b> Exit weight at the "
        "previous month-end + Add weight at the selected month-end &times; "
        "(ending index MV / beginning index MV). Bucket rows show the contribution "
        "to beginning index; Turnover Rate divides it by Begin Weight. "
        "<b>(approx)</b> means no index-MV item is requested, so the ratio "
        "is 1.0.</p>"
    )


def signed_change_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Screen rows for the horizontal charts.

    An Add keeps a positive weight and an Exit becomes negative, so the bars
    sit on opposite sides of the zero axis. Descending order on the signed
    weight puts the largest Add at the top and the largest Exit at the bottom.
    This is display only; the exported file keeps positive weights.
    """
    if frame is None:
        return pd.DataFrame()
    if frame.empty or "Weight" not in frame.columns:
        return frame.copy()
    out = frame.copy()
    out["Weight"] = pd.to_numeric(out["Weight"], errors="coerce")
    if "Action" in out.columns:
        action = out["Action"].astype(str)
        out["Weight"] = out["Weight"].abs()
        out.loc[action == "Exit", "Weight"] = -out.loc[action == "Exit", "Weight"]
    return out.sort_values("Weight", ascending=False, na_position="last").reset_index(drop=True)


def top_add_exit_rows(frame: pd.DataFrame, limit_each: int = 10) -> pd.DataFrame:
    """Top Adds and top Exits for the bond detail chart.

    A large index can add or exit hundreds of bonds in one bucket, so the chart
    shows at most ``limit_each`` Adds and ``limit_each`` Exits. Adds stay first
    (largest first) and the selected Exits end with the largest Exit, matching
    the top-to-bottom order of the whole detail table.
    """
    signed = signed_change_frame(frame)
    if signed.empty or "Action" not in signed.columns:
        return signed.head(limit_each)
    is_exit = signed["Action"].astype(str) == "Exit"
    adds = signed.loc[~is_exit].head(limit_each)
    exits = (
        signed.loc[is_exit]
        .sort_values("Weight", ascending=True)
        .head(limit_each)
        .sort_values("Weight", ascending=False)
    )
    return pd.concat([adds, exits], ignore_index=True)


def bucket_chart_rows(summary: pd.DataFrame, dimension: str, limit: int = BUCKET_CHART_TOP) -> tuple[list[str], list[float], list[float]]:
    """Horizontal bucket-chart rows in the Bucket summary order.

    Sort key is Add Weight plus Exit Weight, largest first, the same order as
    the table. A bucket is omitted only when BOTH Add and Exit weight are zero;
    an Add/Exit pair that offsets still counts as a change. Only the top
    ``limit`` of the remaining buckets are drawn; the rest is aggregated into
    one ``Others`` row (at most ``limit`` + 1 lines).
    Add weights stay positive and Exit weights become negative, so the two bars
    sit on opposite sides of the zero axis.
    """
    column = DIMENSIONS.get(dimension, dimension)
    if summary is None or summary.empty or column not in summary.columns:
        return [], [], []
    chart = summary.copy()
    adds = (
        pd.to_numeric(chart["Add Weight"], errors="coerce").fillna(0.0)
        if "Add Weight" in chart.columns
        else pd.Series(0.0, index=chart.index)
    )
    exits = (
        pd.to_numeric(chart["Exit Weight"], errors="coerce").fillna(0.0)
        if "Exit Weight" in chart.columns
        else pd.Series(0.0, index=chart.index)
    )
    chart = chart.assign(_add=adds, _exit=exits, _total=adds + exits)
    # Keep one leg even when the net is zero; only a fully unchanged bucket goes.
    chart = chart.loc[(chart["_add"] != 0) | (chart["_exit"] != 0)].copy()
    chart = chart.sort_values("_total", ascending=False)
    top = chart.head(limit)
    rest = chart.iloc[limit:]
    labels = [str(value) for value in top[column]]
    add_values = [float(value) for value in top["_add"]]
    exit_values = [-float(value) if value else 0.0 for value in top["_exit"]]
    if not rest.empty:
        rest_add = float(rest["_add"].sum())
        rest_exit = float(rest["_exit"].sum())
        if rest_add or rest_exit:
            labels.append("Others")
            add_values.append(rest_add)
            exit_values.append(-rest_exit if rest_exit else 0.0)
    return labels, add_values, exit_values
