"""Build the local layout preview for FI Index Change.

The preview is generated from the app code, not hand-copied:

- ``config.py`` and ``engine.py`` are imported, so the month-end rule, the
  bucket rules, the ID diff, and the weighted averages are the real ones.
- ``app.py`` is read with ``ast`` instead of imported, because it needs
  plotly and ipywidgets, which the authoring machine does not have. The
  column tuples, the filter map, and the caption come from that file.
- ``data.py`` is not used. It needs ``bql``. The preview feeds two synthetic
  snapshots straight into ``prepare_members``.

Every number in the output comes from a local pandas run over synthetic
bonds. It is not a Bloomberg result. Nothing here is uploaded to BQuant.

Run after any change to the app:

    python3 "User scripts/FI Index Change/preview/build_preview.py"
"""

from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))

from fi_index_change.config import (  # noqa: E402
    BUCKET_CHART_TOP,
    CHART_MAX_SCREEN_RATIO,
    CHART_WIDTH_PX,
    DEFAULT_BOOK,
    DEFAULT_INDEX,
    DISPLAY_ROW_CAP,
    FILTER_GAP_PX,
    FILTER_ROW_WIDTH_PX,
    FILTER_WIDTHS,
    MONTH_END_CHOICES,
    SCREEN_WIDTH_PX,
)
from fi_index_change.engine import (  # noqa: E402
    DIMENSIONS,
    EXPORT_COLUMNS,
    caption_html,
    comparison_for,
    align_snapshot_labels,
    default_month_end,
    month_end_choices,
    prepare_members,
)

OUTPUT = HERE / "interface.html"
TEMPLATE = HERE / "template.html"
APP_SOURCE = PROJECT / "fi_index_change" / "app.py"

# Constants the preview needs from app.py. Read, never imported.
WANTED = (
    "APP_TITLE",
    "TITLE_HTML",
    "BOND_COLUMNS",
    "DETAIL_FIELDS",
    "POSITION_COLUMNS",
    "DETAIL_LIST_COLUMNS",
    "SPREAD_OPTIONS",
    "SPREAD_LABELS",
    "DURATION_FIELDS",
    "DURATION_LABELS",
    "YIELD_FIELDS",
    "YIELD_LABELS",
    "FILTER_COLUMNS",
    "ALL_FILTER_LABEL",
)


def app_constants() -> dict:
    """Read the layout constants out of app.py without importing it."""
    tree = ast.parse(APP_SOURCE.read_text(encoding="utf-8"))
    found = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in WANTED:
                found[target.id] = ast.literal_eval(node.value)
    missing = [name for name in WANTED if name not in found]
    if missing:
        raise RuntimeError(f"app.py no longer defines {missing}")
    return found


# Synthetic stand-ins so the preview shows a full country name. Desktop
# returns whatever country_full_name() actually sends; these words are not that.
# GB is the source spelling BRITAIN so COUNTRY_NAME_OVERRIDES can rewrite it.
_PREVIEW_COUNTRY = {
    "US": "United States",
    "DE": "Germany",
    "JP": "Japan",
    "GB": "BRITAIN",
    "IT": "Italy",
    "ES": "Spain",
    "BE": "Belgium",
    "BR": "Brazil",
    "CA": "Canada",
    "XS": "Supranational",
    "(blank)": "(blank)",
}


def _bond(
    bond_id,
    name,
    issuer,
    sector,
    country,
    currency,
    security_type,
    maturity,
    tenor,
    rating,
    coupon,
    oas,
    duration,
    bond_yield,
    weight,
    isin,
    sedol,
) -> dict:
    return {
        "ID": bond_id,
        "Name": name,
        "Issuer": issuer,
        "Sector": sector,
        "Country": _PREVIEW_COUNTRY.get(country, country),
        "Currency": currency,
        "Security Type": security_type,
        "Maturity": maturity,
        "Tenor": tenor,
        "Rating": rating,
        "Coupon": coupon,
        "OAS": oas,
        "Duration": duration,
        "Yield": bond_yield,
        "Weight": weight,
        "ISIN": isin,
        "SEDOL": sedol,
    }


def sample_snapshots() -> tuple[pd.DataFrame, pd.DataFrame, str, str]:
    """Two synthetic month-ends. Adds, exits, a numeric rating, and a TBA roll."""
    previous_rows = [
        _bond("T 4 1/4 11/15/34 Govt", "US TREASURY N/B 4.25% 11/15/2034", "US TREASURY", "Treasury", "US", "USD", "GLOBAL", "2034-11-15", 8.05, "AA+", 4.25, 32.0, 6.90, 4.35, 3.10, "US91282CXX11", "BQ1T34A"),
        _bond("T 4 5/8 02/15/55 Govt", "US TREASURY N/B 4.625% 02/15/2055", "US TREASURY", "Treasury", "US", "USD", "GLOBAL", "2055-02-15", 28.30, "AA+", 4.625, 48.0, 14.20, 4.72, 2.05, "US91282CYY22", "BQ2T55B"),
        _bond("T 3 7/8 08/15/33 Govt", "US TREASURY N/B 3.875% 08/15/2033", "US TREASURY", "Treasury", "US", "USD", "GLOBAL", "2033-08-15", 6.80, "AA+", 3.875, 28.0, 6.10, 4.18, 1.80, "US91282CZZ33", "BQ3T33C"),
        _bond("T 1 3/4 11/15/29 Govt", "US TREASURY N/B 1.75% 11/15/2029", "US TREASURY", "Treasury", "US", "USD", "GLOBAL", "2029-11-15", 3.05, "AA+", 1.75, 18.0, 3.40, 3.85, 1.25, "US91282CAA44", "BQ4T29D"),
        _bond("DBR 2.6 05/15/41 Govt", "GERMANY 2.6% 05/15/2041", "GERMANY", "Sovereign", "DE", "EUR", "GLOBAL", "2041-05-15", 14.55, "AAA", 2.6, 96.0, 11.10, 2.95, 2.60, "DE000110XX55", "BQ5DE41E"),
        _bond("DBR 0 08/15/30 Govt", "GERMANY 0% 08/15/2030", "GERMANY", "Sovereign", "DE", "EUR", "GLOBAL", "2030-08-15", 3.80, "AAA", 0.0, 74.0, 3.55, 2.42, 2.20, "DE000110YY66", "BQ6DE30F"),
        _bond("JGB 1.5 06/20/35 Govt", "JAPAN 1.5% 06/20/2035", "JAPAN", "Sovereign", "JP", "JPY", "GLOBAL", "2035-06-20", 8.65, "A+", 1.5, 42.0, 7.60, 1.62, 1.95, "JP110XXX1234", "BQ7JP35G"),
        _bond("UKT 4.25 06/07/32 Govt", "UK GILT 4.25% 06/07/2032", "UK", "Sovereign", "GB", "GBP", "GLOBAL", "2032-06-07", 5.60, "AA", 4.25, 68.0, 5.20, 4.28, 1.70, "GB00BXX12345", "BQ8GB32H"),
        _bond("BTP 4.0 02/01/37 Govt", "ITALY 4% 02/01/2037", "ITALY", "Sovereign", "IT", "EUR", "GLOBAL", "2037-02-01", 10.25, "BBB", 4.0, 155.0, 8.40, 3.62, 1.15, "IT000XXX4455", "BQ9IT37J"),
        _bond("SPGB 3.45 10/31/34 Govt", "SPAIN 3.45% 10/31/2034", "SPAIN", "Sovereign", "ES", "EUR", "GLOBAL", "2034-10-31", 7.95, "A", 3.45, 118.0, 6.40, 3.18, 0.95, "ES000XXX6677", "BQASP34K"),
        _bond("EIB 3.0 09/15/38 Govt", "EUROPEAN INVT BANK 3% 09/15/2038", "EUROPEAN INVESTMENT BANK", "Government Related", "XS", "EUR", "GLOBAL", "2038-09-15", 11.90, "AAA", 3.0, 88.0, 9.30, 3.02, 0.85, "XS000XXX8899", "BQAEI38L"),
        _bond("IADB 2.75 03/10/32 Govt", "INTER-AMERICAN DEV BK 2.75% 03/10/2032", "INTER-AMERICAN DEVELOPMENT BANK", "Government Related", "XS", "USD", "GLOBAL", "2032-03-10", 5.35, "AAA", 2.75, 62.0, 4.85, 4.05, 0.70, "XS000YYY1122", "BQAIA32M"),
        _bond("AAPL 3.85 08/04/46 Corp", "APPLE INC 3.85% 08/04/2046", "APPLE INC", "Corporate", "US", "USD", "GLOBAL", "2046-08-04", 19.70, "AA+", 3.85, 92.0, 13.40, 4.62, 0.55, "US037833XX46", "BQAPL46N"),
        _bond("MSFT 4.5 02/06/47 Corp", "MICROSOFT CORP 4.5% 02/06/2047", "MICROSOFT CORP", "Corporate", "US", "USD", "GLOBAL", "2047-02-06", 20.25, "AAA", 4.5, 86.0, 13.75, 4.58, 0.45, "US594918XX47", "BQMSF47P"),
        _bond("JPM 5.6 07/15/41 Corp", "JPMORGAN CHASE 5.6% 07/15/2041", "JPMORGAN CHASE & CO", "Corporate", "US", "USD", "GLOBAL", "2041-07-15", 14.60, "A-", 5.6, 168.0, 10.90, 5.32, 0.40, "US46647XXX41", "BQJPM41Q"),
        _bond("BAYN 4.25 06/15/39 Corp", "BAYER AG 4.25% 06/15/2039", "BAYER AG", "Corporate", "DE", "EUR", "GLOBAL", "2039-06-15", 12.60, "BBB", 4.25, 212.0, 9.80, 4.05, 0.30, "XS000ZZZ3344", "BQBAY39R"),
        _bond("SHEL 3.25 05/15/38 Corp", "SHELL INTL FIN 3.25% 05/15/2038", "SHELL INTERNATIONAL FINANCE", "Corporate", "GB", "GBP", "GLOBAL", "2038-05-15", 11.50, "AA-", 3.25, 118.0, 8.95, 4.42, 0.28, "XS000AAA4455", "BQSHL38S"),
        _bond("TOYOTA 2.35 03/05/34 Corp", "TOYOTA MOTOR CREDIT 2.35% 03/05/2034", "TOYOTA MOTOR CREDIT CORP", "Corporate", "JP", "JPY", "GLOBAL", "2034-03-05", 7.30, "A+", 2.35, 76.0, 5.95, 1.95, 0.22, "JP000BBB5566", "BQTOY34T"),
        _bond("ENEL 4.0 11/20/37 Corp", "ENEL FINANCE INTL 4% 11/20/2037", "ENEL FINANCE INTERNATIONAL", "Corporate", "IT", "EUR", "GLOBAL", "2037-11-20", 11.05, "BBB+", 4.0, 178.0, 8.70, 3.92, 0.20, "XS000CCC6677", "BQENL37U"),
        _bond("VW 3.5 04/12/36 Corp", "VOLKSWAGEN INTL 3.5% 04/12/2036", "VOLKSWAGEN INTERNATIONAL FIN", "Corporate", "DE", "EUR", "GLOBAL", "2036-04-12", 9.40, "A-", 3.5, 142.0, 7.85, 3.88, 0.18, "XS000DDD7788", "BQVW36V"),
        _bond("PETRO 5.5 06/20/45 Corp", "PETROBRAS GLOBAL 5.5% 06/20/2045", "PETROBRAS GLOBAL FINANCE", "Corporate", "BR", "USD", "GLOBAL", "2045-06-20", 18.60, "BB-", 5.5, 285.0, 11.60, 6.15, 0.15, "US71647NXX45", "BQPBR45W"),
        _bond("TELUS 4.6 11/15/43 Corp", "TELUS CORP 4.6% 11/15/2043", "TELUS CORP", "Corporate", "CA", "CAD", "GLOBAL", "2043-11-15", 17.05, "BBB+", 4.6, 156.0, 11.20, 4.88, 0.12, "CA87971MXX43", "BQTLU43X"),
        _bond("FHLMC 5.5 09/01/53 Mtge", "FHLMC GOLD 5.5% 09/01/2053", "FHLMC GOLD POOL", "Securitized", "(blank)", "USD", "MBS 30yr", "2053-09-01", 27.00, "AA+", 5.5, 78.0, 6.05, 6.15, 12.50, "US3134GXXX53", "BQFM53A"),
        _bond("FNMA 6.0 10/01/56 Mtge", "FNMA 30YR 6% 10/01/2056", "FNMA 30YR POOL", "Securitized", "(blank)", "USD", "MBS 30yr", "2056-10-01", 30.00, "AA+", 6.0, 64.0, 5.60, 6.02, 14.20, "US3140XXXX56", "BQFN56B"),
        _bond("GNMA 5.0 11/20/54 Mtge", "GNMA II 5% 11/20/2054", "GNMA II POOL", "Securitized", "(blank)", "USD", "MBS 30yr", "2054-11-20", 28.05, "AA+", 5.0, 82.0, 6.40, 5.85, 3.40, "US3617XXXX54", "BQGN54C"),
        _bond("FNMA TBA 30 6.0 Mtge", "FNMA TBA 30YR 6% NOV", "FNMA TBA", "Securitized", "(blank)", "USD", "TBA", "2056-11-01", 30.05, "AA+", 6.0, 70.0, 5.55, 6.05, 6.80, "US3140TBA056", "BQTB56D"),
    ]

    latest_rows = [dict(row) for row in previous_rows]

    # Two exits: one corporate and one sovereign.
    latest_rows = [
        row
        for row in latest_rows
        if row["ID"] not in {"PETRO 5.5 06/20/45 Corp", "SPGB 3.45 10/31/34 Govt"}
    ]

    for row in latest_rows:
        bond_id = row["ID"]
        if bond_id == "FNMA TBA 30 6.0 Mtge":
            # The TBA position rolls to the next settlement month.
            row["ID"] = "FNMA TBA 30 6.5 Mtge"
            row["Name"] = "FNMA TBA 30YR 6.5% DEC"
            row["Coupon"] = 6.5
            row["Weight"] = 6.35
        elif bond_id == "T 4 1/4 11/15/34 Govt":
            row["Weight"] = 3.35
        elif bond_id == "AAPL 3.85 08/04/46 Corp":
            row["Weight"] = 0.62
            row["Rating"] = "A+"
        elif bond_id == "BAYN 4.25 06/15/39 Corp":
            row["Weight"] = 0.34
            row["Rating"] = "24"
        elif bond_id == "JGB 1.5 06/20/35 Govt":
            row["OAS"] = 9999.0
        elif bond_id == "GNMA 5.0 11/20/54 Mtge":
            row["OAS"] = None
            row["Duration"] = None
            row["Yield"] = None

    latest_rows.extend([
        _bond("MS 5.75 09/10/42 Corp", "MORGAN STANLEY 5.75% 09/10/2042", "MORGAN STANLEY", "Corporate", "US", "USD", "GLOBAL", "2042-09-10", 15.85, "A-", 5.75, 172.0, 11.30, 5.38, 0.42, "US6174AXXX42", "BQMS42M"),
        _bond("ABIBB 4.9 02/01/46 Corp", "ANHEUSER-BUSCH 4.9% 02/01/2046", "ANHEUSER-BUSCH INBEV", "Corporate", "BE", "EUR", "GLOBAL", "2046-02-01", 19.30, "BBB+", 4.9, 148.0, 12.60, 4.35, 0.26, "XS000EEE8899", "BQABI46N"),
        _bond("KFW 2.75 01/15/35 Govt", "KFW 2.75% 01/15/2035", "KFW", "Government Related", "DE", "EUR", "GLOBAL", "2035-01-15", 8.20, "AAA", 2.75, 58.0, 6.65, 2.72, 0.68, "DE000XXX9900", "BQKFW35P"),
        _bond("FHLMC 5.0 11/01/55 Mtge", "FHLMC GOLD 5% 11/01/2055", "FHLMC GOLD POOL", "Securitized", "(blank)", "USD", "MBS 30yr", "2055-11-01", 29.05, "AA+", 5.0, 80.0, 5.85, 5.92, 2.15, "US3134HXXX55", "BQFM55Q"),
    ])

    def _add_spread_variants(rows):
        for row in rows:
            oas = row.get("OAS")
            if oas is None:
                row["Z-Spread"] = None
                row["I-Spread"] = None
            else:
                row["Z-Spread"] = float(oas) + 7.5
                row["I-Spread"] = float(oas) - 3.25
            duration = row.get("Duration")
            if duration is None:
                for field in ("Modified Duration", "Effective Duration", "OASD"):
                    row[field] = None
            else:
                duration = float(duration)
                row["Modified Duration"] = duration
                row["Effective Duration"] = duration + 0.8
                row["OASD"] = duration + 0.4
            bond_yield = row.get("Yield")
            if bond_yield is None:
                for field in ("YTM", "YTW"):
                    row[field] = None
            else:
                bond_yield = float(bond_yield)
                row["YTM"] = bond_yield
                row["YTW"] = bond_yield - 0.15

    _add_spread_variants(previous_rows)
    _add_spread_variants(latest_rows)
    notes: list[str] = []
    previous = prepare_members(pd.DataFrame(previous_rows), notes)
    latest = prepare_members(pd.DataFrame(latest_rows), notes)

    today = pd.Timestamp.today().normalize()
    choices = month_end_choices(today, MONTH_END_CHOICES)
    comparison = comparison_for(default_month_end(today), today, [value for _label, value in choices])
    align_snapshot_labels(previous, latest)

    for frame, as_of in ((previous, comparison.previous_date), (latest, comparison.selected_date)):
        frame["AS_OF_DATE"] = as_of

    return previous, latest, comparison.previous_date, comparison.selected_date


def _records(frame: pd.DataFrame) -> list[dict]:
    rows = []
    for record in frame.to_dict(orient="records"):
        clean = {}
        for key, value in record.items():
            if value is None or (isinstance(value, float) and pd.isna(value)):
                clean[key] = None
            elif isinstance(value, bool):
                clean[key] = bool(value)
            elif isinstance(value, (int, float)):
                clean[key] = float(value)
            else:
                clean[key] = str(value)
        rows.append(clean)
    return rows


def build_payload() -> dict:
    constants = app_constants()
    previous, latest, previous_date, selected_date = sample_snapshots()
    today = pd.Timestamp.today().normalize()
    choices = month_end_choices(today, MONTH_END_CHOICES)
    comparison = comparison_for(default_month_end(today), today, [value for _label, value in choices])
    return {
        "title_html": constants["TITLE_HTML"],
        "app_title": constants["APP_TITLE"],
        "default_index": DEFAULT_INDEX,
        "default_book": DEFAULT_BOOK,
        "row_cap": DISPLAY_ROW_CAP,
        "bucket_chart_top": BUCKET_CHART_TOP,
        "index_mv_ratio": 1.01,
        "turnover_basis": "sample",
        "chart_width_px": CHART_WIDTH_PX,
        "screen_width_px": SCREEN_WIDTH_PX,
        "chart_max_screen_ratio": CHART_MAX_SCREEN_RATIO,
        "filter_row_width_px": FILTER_ROW_WIDTH_PX,
        "filter_widths": dict(FILTER_WIDTHS),
        "filter_gap_px": FILTER_GAP_PX,
        "month_ends": [{"label": label, "value": value} for label, value in choices],
        "default_month_end": default_month_end(today),
        "previous_date": previous_date,
        "selected_date": selected_date,
        "kind": comparison.kind,
        "dimensions": list(DIMENSIONS),
        "dimension_columns": dict(DIMENSIONS),
        "filter_columns": [list(pair) for pair in constants["FILTER_COLUMNS"]],
        "all_filter_label": constants["ALL_FILTER_LABEL"],
        "bond_columns": list(constants["BOND_COLUMNS"]),
        "detail_fields": list(constants["DETAIL_FIELDS"]),
        "export_columns": list(EXPORT_COLUMNS),
        "position_columns": list(constants["POSITION_COLUMNS"]),
        "spread_options": list(constants["SPREAD_OPTIONS"]),
        "spread_labels": dict(constants["SPREAD_LABELS"]),
        "duration_fields": list(constants["DURATION_FIELDS"]),
        "duration_labels": dict(constants["DURATION_LABELS"]),
        "yield_fields": list(constants["YIELD_FIELDS"]),
        "yield_labels": dict(constants["YIELD_LABELS"]),
        "detail_list_columns": list(constants["DETAIL_LIST_COLUMNS"]),
        "caption": caption_html(previous_date, selected_date),
        "previous": _records(previous),
        "latest": _records(latest),
    }


def main() -> None:
    payload = build_payload()
    template = TEMPLATE.read_text(encoding="utf-8")
    if "__PAYLOAD__" not in template:
        raise RuntimeError("template.html has no __PAYLOAD__ placeholder")
    rendered = template.replace("__PAYLOAD__", json.dumps(payload, ensure_ascii=False))
    summary = (
        f"{len(payload['previous'])} previous rows, "
        f"{len(payload['latest'])} latest rows, "
        f"{payload['previous_date']} -> {payload['selected_date']} ({payload['kind']}), "
        f"{len(payload['bond_columns'])} grid columns"
    )
    # Skip an identical write: rewriting unchanged bytes moves the mtime, and
    # anything watching this folder reads that as an edit. A rebuild that
    # changes nothing must leave the file alone.
    if OUTPUT.is_file() and OUTPUT.read_text(encoding="utf-8") == rendered:
        print(f"{OUTPUT.name} already current; not rewritten ({summary})")
        return
    OUTPUT.write_text(rendered, encoding="utf-8")
    print(f"wrote {OUTPUT.name}: {summary}")


if __name__ == "__main__":
    main()
