# Local layout preview

A browser page that mirrors the FI Index Change app so the layout and the
click behaviour can be judged on the authoring Mac, without BQuant, plotly,
ipywidgets, or a Bloomberg request.

```text
preview/
  build_preview.py     generates interface.html from the real app code
  template.html        the page shell; the generated data is injected into it
  interface.html       generated. Open this in a browser.
  interface-sample.png main-tab screenshot of the generated page
  interface-export-sample.png export-tab screenshot of the generated page
  interface-positions-sample.png full-position-tab screenshot of the generated page
  serve_preview.py     starts a detached local server for the Cursor browser tab
  check_preview.js     headless check of the generated page
```

`preview/` is **not** part of the BQuant upload. Only `Upload/` is.

## Viewing it inside Cursor

`8765` already belongs to the ETF Spread preview, so this app uses `8770`.

```bash
cd "User scripts/FI Index Change"
python3 preview/serve_preview.py 8770 preview
```

Then open `http://127.0.0.1:8770/interface.html` in the Cursor browser tab.
The helper survives the shell that started it, writes a PID file to
`/tmp/fi_preview_8770.pid`, and stops the previous server on that port before
starting a new one, so a rebuild only needs a page reload.

Do not reuse another project's port. Two projects on one port means one of
them silently serves the wrong page.

## What is real and what is not

| Part | Source |
|---|---|
| Month-end dropdown, default date, projected label | `fi_index_change.engine.month_end_choices` / `default_month_end` imported from the app |
| Tenor buckets, rating buckets, MBS/TBA mask, weight scaling | `fi_index_change.engine.prepare_members` imported from the app |
| Weighted averages, OAS >= 9000 exclusion, zero weight skip | The preview repeats `weighted_mean` in JavaScript; it is a mirror, not the imported function |
| Spread control and all-three exports | The preview mirrors the Spread multi-select (`OAS` default, then `(All)` / OAS / Z-Spread / I-Spread); lower tables show the selected spread blocks, while Export Summary and Full Position carry all three |
| Duration and Yield controls | The preview mirrors both multi-selects (`Duration` / `Yield` defaults, then `(All)` and every duration/yield item); lower tables show the selected short-label blocks while Export Summary/Changes/Full Position carry every field |
| Bucket row order and grouped columns | The preview repeats the engine's Add Weight plus Exit Weight sort and its Begin/End column grouping in JavaScript |
| Signed horizontal charts | The preview repeats the engine's signed order (Add right, Exit left, largest Add to largest Exit) in JavaScript |
| Dark chart panel | The preview draws the charts on `#0d1117` at 2,284 px with light text; the right edge meets the Book filter box |
| App title | `TITLE_HTML` read out of `app.py` with `ast`; the line carries no version stamp |
| Grid columns, detail fields, filter list, caption, index default, book default, row cap | Read out of `app.py` and `config.py` with `ast` |
| Name under the index box | Desktop requests `long_comp_name` for one completed yellow key. The preview leaves that line blank and only shows the note |
| The 54 bonds | Synthetic rows written in `build_preview.py`. Not an index, not a Bloomberg result |

The JavaScript engines are a second implementation, so a change to
`engine.py` needs the matching change in `template.html`. `check_preview.js`
catches a broken page; it cannot prove the two implementations still agree.

## Rebuild after a code change

One command does everything local, from the project folder:

```bash
cd "User scripts/FI Index Change"
python3 refresh_local.py
```

It runs the test suite, regenerates `interface.html`, runs `check_preview.js`,
restarts the page on `http://127.0.0.1:8770/interface.html`, and re-copies the
seven runtime files plus `MAIN.ipynb` into `Upload/`, comparing the bytes
afterwards. Exit code 0 means every step passed; a non-zero exit names the
step that failed.

The individual steps, if one of them needs to be run alone:

```bash
python3 preview/build_preview.py      # regenerate interface.html
node preview/check_preview.js         # headless checks
python3 preview/serve_preview.py 8770 preview
open preview/interface.html           # view it without a server
```

`build_preview.py` fails loudly when `app.py` loses one of the layout
constants it reads, so a rename cannot silently leave a stale preview.

## Using it

Update loads the sample comparison. Then:

- Dimension and Bonds redraw from memory. Spread, Duration, Yield, and Book are multi-select boxes after Currency; selecting them does not re-request.
- Book starts on All (set by `DEFAULT_BOOK` in `config.py`) and is a selection box after Yield. Standard keeps
  the MBS/TBA roll codes out of the list.
- A dimension multi-select filters the display only.
- Click a bucket row: the detail summary names the add/exit counts and the
  Add / Exit / Net weights; the signed chart shows the Top 10 Adds and
  Top 10 Exits, while the bond table lists every row of the bucket. The
  bucket chart above shows the bucket table order, skips a bucket only when
  both Add and Exit are zero (an offsetting pair stays), then top 20 + Others.
- Click a bond row: its field table appears BELOW the bond table, so the
  grid does not move; the short note above names the selected bond. The
  weight chart compares it with the other changes of the same action.
- The headline shows Monthly turnover; Bucket summary adds
  `Turnover (index %)` and `Turnover Rate (%)`, with both definitions printed
  under the Begin/End note. The preview still carries a synthetic sample
  index-MV ratio so the ratio column can be laid out, but the shipped app no
  longer requests any index-MV item: it always computes turnover with a ratio
  of 1.0 and always shows `(approx)`. Treat the preview's turnover number as a
  layout sample, not as the number the app will print.
- Footnotes under the controls name the Add / Exit as-of dates once a
  comparison is loaded, define the IG and HY rating buckets, and state the
  turnover formula (Exit + Add x MV ratio, bucket rate, `(approx)`, which the
  app now always shows because no index-MV item is requested).
  The chart order sits on the chart subtitle and the Begin/End note under
  Bucket summary.
- The Export tab has a Data dropdown (Changes / Summary); the Full Position
  tab has a Date dropdown (Start / End) and shows every constituent of that
  month-end (CSV columns minus `Action`, keyed by `AS_OF_DATE`). Weight is not
  the first column: it follows `Sector` in both tables and prints with a
  percent sign. Every copy table repeats its column names as the first data
  row, so a whole-table copy keeps the header. Classification labels are
  standardized by ID across both snapshots (latest usable value wins). No file
  is written by the preview.
- Any month-end other than the sample date is refused, because only one
  synthetic pair exists.

## Limits

- One synthetic month-end pair, so the projected month, a cache hit, a
  timeout, and a failed side cannot be previewed here.
- No `ipydatagrid`. The app falls back to an HTML table in that case; the
  preview is an HTML table, so it looks like that fallback, not like the
  DataGrid.
- The plotly figures are drawn as inline SVG with plain JavaScript. Axis
  ticks and tooltips will differ from the real widget.
