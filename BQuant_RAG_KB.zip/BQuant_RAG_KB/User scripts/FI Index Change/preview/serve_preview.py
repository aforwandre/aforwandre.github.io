"""Start a static preview server that outlives the shell that launched it.

The sandboxed shell tears down its child processes when the command ends, so
the server is spawned in a new session with stdin/stdout detached. A PID file
lets a later run stop the previous server instead of fighting over the port.
"""

import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SERVE_DIR = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else HERE
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8770
PID_FILE = Path("/tmp") / f"fi_preview_{PORT}.pid"
LOG_FILE = Path("/tmp") / f"fi_preview_{PORT}.log"


def _is_our_server(pid: int) -> bool:
    """True only when ``pid`` is an http.server bound to this port.

    A reused PID after a reboot must never be killed, so the command line is
    checked for both ``http.server`` and the port before any signal is sent.
    An unreadable command line counts as "not ours": leaving one stale server
    running is cheaper than killing an unrelated process.
    """
    try:
        result = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    command = (result.stdout or "").strip()
    return result.returncode == 0 and "http.server" in command and str(PORT) in command


def stop_previous() -> None:
    if not PID_FILE.exists():
        return
    try:
        pid = int(PID_FILE.read_text().strip())
    except (OSError, ValueError):
        PID_FILE.unlink(missing_ok=True)
        return
    if not _is_our_server(pid):
        print(f"ignored stale pid={pid}: not an http.server on port {PORT}")
        PID_FILE.unlink(missing_ok=True)
        return
    try:
        os.kill(pid, 15)
        print(f"stopped previous server pid={pid}")
    except ProcessLookupError:
        pass
    except OSError as exc:
        print(f"could not stop pid={pid}: {exc}")
    PID_FILE.unlink(missing_ok=True)


def main() -> None:
    stop_previous()
    log = open(LOG_FILE, "wb")
    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "http.server",
            str(PORT),
            "--bind",
            "127.0.0.1",
            "--directory",
            str(SERVE_DIR),
        ],
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        start_new_session=True,
        close_fds=True,
    )
    PID_FILE.write_text(str(process.pid), encoding="utf-8")
    print(f"started pid={process.pid} port={PORT} dir={SERVE_DIR}")


if __name__ == "__main__":
    main()
