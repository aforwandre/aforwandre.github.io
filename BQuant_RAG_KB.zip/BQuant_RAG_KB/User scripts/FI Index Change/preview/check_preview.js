// Headless check for preview/interface.html. No browser, no BQL.
//
//   node "User scripts/FI Index Change/preview/check_preview.js"
//
// It stubs enough of the DOM to run the page script, then exercises Update,
// the Book switch, the dimension switch, a bucket click, a bond click, and
// the export message. Use it after build_preview.py to catch a broken page
// before opening it.
const fs = require("fs");
const path = require("path");

const HREF = path.join(__dirname, "interface.html");
const html = fs.readFileSync(HREF, "utf8");
const match = html.match(/<script>([\s\S]*?)<\/script>/);
if (!match) throw new Error("interface.html has no script block");

const nodes = new Map();
// The filter container is filled with markup, so its selects are parsed back
// out of innerHTML. A box missing from this list is a box the page never
// bound, which is the failure these checks exist to catch.
function selectStubs(container) {
  const markup = container.innerHTML || "";
  if (container._stubMarkup === markup && container._stubs) return container._stubs;
  const list = [];
  for (const hit of markup.matchAll(/<select([^>]*)>([\s\S]*?)<\/select>/g)) {
    const attrs = hit[1];
    const body = hit[2];
    const column = (attrs.match(/data-column="([^"]*)"/) || [])[1];
    if (column === undefined) continue;
    const node = makeNode((attrs.match(/id="([^"]*)"/) || [])[1] || column);
    node.dataset = { column };
    node.options = [...body.matchAll(/<option([^>]*)>([^<]*)<\/option>/g)].map((option) => ({
      value: (option[1].match(/value="([^"]*)"/) || [])[1] || option[2],
      label: option[2],
      selected: /\sselected/.test(option[1])
    }));
    node.selectedOptions = node.options.filter((option) => option.selected);
    list.push(node);
  }
  container._stubMarkup = markup;
  container._stubs = list;
  return list;
}
function makeNode(id) {
  const node = {
    id,
    innerHTML: "",
    textContent: "",
    value: "",
    disabled: false,
    selectedOptions: [],
    style: {},
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    handlers: {},
    rowHandlers: {},
    addEventListener(type, fn) {
      (this.handlers[type] = this.handlers[type] || []).push(fn);
    },
    querySelectorAll(selector) {
      if (/data-column/.test(selector)) return selectStubs(this);
      if (selector !== "tbody tr" && selector !== "tr") return [];
      const indices = [...(this.innerHTML || "").matchAll(/<tr data-i="(\d+)"/g)].map((match) => Number(match[1]));
      return indices.map((index) => {
        const row = {
          dataset: { i: String(index) },
          classList: { add() {}, remove() {}, contains() { return false; } },
          addEventListener(type, fn) {
            if (type === "click") node.rowHandlers[index] = fn;
          },
          fire(type) {
            const fn = node.rowHandlers[index];
            if (fn) fn({ target: row });
          },
          querySelectorAll() {
            return [];
          }
        };
        return row;
      });
    },
    fire(type, event) {
      (this.handlers[type] || []).forEach((fn) => fn(event || { target: node }));
    }
  };
  return node;
}
const document = {
  getElementById(id) {
    if (!nodes.has(id)) nodes.set(id, makeNode(id));
    return nodes.get(id);
  },
  querySelectorAll() {
    return [];
  }
};

let code = match[1].replace(/\ninitialise\(\);\s*$/, "\n");
const factory = new Function(
  "document",
  "console",
  `${code}\n;return {initialise, render, showBucket, showBond, state, summarize, diff, changeRows, signedChangeRows, topAddExitRows, bucketChartRows, bucketChartSeries, selectionStatus, currencyValues, isCompleteIndex, P};`
);
const api = factory(document, console);

const fail = [];
function check(name, condition, detail) {
  if (!condition) fail.push(`${name}${detail ? `: ${detail}` : ""}`);
  console.log(`${condition ? "ok  " : "FAIL"} ${name}${detail ? ` - ${detail}` : ""}`);
}
function rowsIn(id) {
  return (document.getElementById(id).innerHTML.match(/<tr data-i=/g) || []).length;
}
function barsIn(id) {
  return (document.getElementById(id).innerHTML.match(/<rect /g) || []).length;
}

api.initialise();

check("completed yellow key notes long_comp_name", document.getElementById("indexNameNote").textContent.includes("long_comp_name"));
check("name line stays blank in the preview", document.getElementById("indexName").textContent === "");
check("status starts idle", document.getElementById("status").innerHTML.includes("Idle") && document.getElementById("status").innerHTML.includes("Environment: Idle") && document.getElementById("status").innerHTML.includes("#c62828") && document.getElementById("status").innerHTML.includes("#1b7f37"));
check("status carries no version stamp", !document.getElementById("status").innerHTML.includes("Stamp"));
check("title shows without a version stamp", (() => {
  const title = document.getElementById("appTitle").innerHTML;
  return title.includes(api.P.app_title)
    && title.includes("font-size:20px")
    && title.includes("font-weight:700")
    && !/20\d\d-\d\d-\d\d/.test(title)
    && !title.includes("Stamp");
})());
check(
  "book defaults to All",
  api.P.default_book === "All"
    && api.state.book === "All"
    && document.getElementById("filters").innerHTML.includes("Book"),
  api.P.default_book
);
check("a partial ticker is not a completed yellow key", api.isCompleteIndex("aggregate") === false);
document.getElementById("indexInput").value = "aggregate";
document.getElementById("indexInput").fire("input");
check("a partial ticker does not request a name", document.getElementById("indexNameNote").textContent === "");
document.getElementById("indexInput").value = api.P.default_index;
document.getElementById("indexInput").fire("input");

check("country display uses a full name", api.P.previous.some((row) => row.Country === "United States"));
check("country display drops the ISO code", api.P.previous.every((row) => row.Country !== "US" && row.Country !== "DE"));
check("Britain displays as United Kingdom", api.P.previous.concat(api.P.latest).some((row) => row.Country === "United Kingdom"));
check("Britain is not left as the source spelling", api.P.previous.concat(api.P.latest).every((row) => String(row.Country).toUpperCase() !== "BRITAIN"));
check("country names use Excel PROPER style", api.P.previous.concat(api.P.latest).every((row) => {
  const country = String(row.Country);
  if (country === "(blank)" || country === "MBS/TBA") return true;
  return country === country.replace(/\w+/g, (word) => word[0].toUpperCase() + word.slice(1).toLowerCase());
}));
check("blank MBS country becomes the book label", api.P.previous.concat(api.P.latest).some((row) => row.Country === "MBS/TBA"));
const loadedRows = api.P.previous.concat(api.P.latest);
check("currency is empty before a load", api.currencyValues([], "Standard").length === 0);
check(
  "currency follows the extracted book",
  api.currencyValues(loadedRows, "Standard").includes("EUR")
    && api.currencyValues(loadedRows, "MBS/TBA").length === 1
    && api.currencyValues(loadedRows, "MBS/TBA")[0] === "USD"
);
check("footnotes name Add and Exit as-of dates", api.P.caption.includes(`Add/End weight is as of ${api.P.selected_date}`) && api.P.caption.includes(`Exit/Begin weight is as of ${api.P.previous_date}`));
check("rating footnote defines IG, HY, and NR", api.P.caption.includes("IG = investment grade") && api.P.caption.includes("HY = high yield") && api.P.caption.includes("NR = no usable letter grade"));
check("turnover footnote defines the formula", api.P.caption.includes("Turnover:") && api.P.caption.includes("ending index MV / beginning index MV") && api.P.caption.includes("Turnover Rate divides it by Begin Weight"));
check("footnotes stay short and leave errors to the status line", (() => {
  const caption = api.P.caption;
  return caption.length < 900
    && !caption.includes("No Data Access License")
    && !caption.includes("403")
    && !caption.includes("country_full_name")
    && !caption.includes("Export keeps positive weights")
    && !caption.includes("Filters start on");
})());
check("Before/After note sits under Bucket summary", html.includes("<b>Begin</b> = previous month-end") && html.includes("<b>End</b> = selected month-end"));
check("Bucket summary defines both turnover columns", html.includes("Turnover (index %)</b> = Exit Weight") && html.includes("Turnover Rate (%)</b> = Turnover") && html.includes("blank when Begin Weight is 0"));
check("section titles are 16px and the app title stays 20px", html.includes("h4.section-title { font-size: 16px;") && html.includes("#detailTitle b { font-size: 16px;") && api.P.title_html.includes("font-size:20px"));
check("Bucket summary puts each turnover definition on its own line", /beginning index MV\)\.<br>\s*<b>Turnover Rate/.test(html));
check("month-end list is the dropdown length", api.P.month_ends.length >= 12, `${api.P.month_ends.length} rows`);
check("filter widths come from config", api.P.filter_widths.Country === 300 && api.P.filter_widths.Sector === 300 && api.P.filter_widths.Currency === 220);
check("filter boxes show more rows", html.includes("select.multi { height: 150px"));
check("filter widgets default to (All)", api.P.filter_columns.every(([, column]) => {
  const selection = api.state.filters[column];
  return Array.isArray(selection) && selection.length === 1 && selection[0] === api.P.all_filter_label;
}), JSON.stringify(api.state.filters));
check("(All) matches every row", api.summarize("Country", "Standard", api.state.filters).rows.length
  === api.summarize("Country", "Standard", {}).rows.length);
check("(All) plus a pick still filters", (() => {
  const column = "Tenor Bucket";
  const picked = api.P.previous.concat(api.P.latest).map((row) => String(row[column]))[0];
  const narrow = Object.assign({}, api.state.filters, { [column]: [api.P.all_filter_label, picked] });
  const wide = Object.assign({}, api.state.filters, { [column]: [picked] });
  return JSON.stringify(api.summarize("Country", "Standard", narrow)) === JSON.stringify(api.summarize("Country", "Standard", wide));
})());
check("grid columns come from app.py", api.P.bond_columns.length > 15, `${api.P.bond_columns.length} columns`);
check("detail fields come from app.py", api.P.detail_fields.length > 15, `${api.P.detail_fields.length} fields`);
check("every bond row carries Weight", api.P.previous.concat(api.P.latest).every((row) => "Weight" in row));
check("Weight is numeric on every row", api.P.previous.concat(api.P.latest).every((row) => typeof row.Weight === "number"));

for (const book of ["Standard", "MBS/TBA", "All"]) {
  const parts = api.diff(book);
  check(
    `diff ${book}`,
    parts.added.length + parts.exited.length > 0,
    `adds ${parts.added.length}, exits ${parts.exited.length}`
  );
  check(
    `adds and exits are disjoint in ${book}`,
    parts.added.every((row) => !parts.exited.some((other) => other.ID === row.ID))
  );
}
check("TBA roll stays in the MBS book", api.diff("Standard").exited.every((row) => !row.ID.includes("TBA")));

api.state.loaded = true;
api.state.monthEnd = api.P.selected_date;
document.getElementById("update").fire("click");
check("Update fills the headline", document.getElementById("headline").innerHTML.includes("As of "));
check("headline states its scope", document.getElementById("headline").innerHTML.includes("Scope:</b> Book = All; filters = none"));
check("Book is a selection box after Currency", (() => {
  const filters = document.getElementById("filters");
  const book = document.getElementById("bookFilter");
  return filters.innerHTML.includes("Standard") && filters.innerHTML.includes("MBS/TBA")
    && filters.innerHTML.indexOf("Currency") < filters.innerHTML.indexOf("Book");
})());
check("scope description sits on the headline title line", document.getElementById("headline").innerHTML.includes("(All). The figures, Bucket summary, and charts below follow this scope"));
check("scope line uses the headline box font and colour", !document.getElementById("headline").innerHTML.includes("font-size:12px") && !document.getElementById("headline").innerHTML.includes("color:#555"));
check("headline has one as-of line per date", document.getElementById("headline").innerHTML.includes(`As of ${api.P.previous_date}:`) && document.getElementById("headline").innerHTML.includes(`<br>As of ${api.P.selected_date}:`));
check("Full book lines start on a new line", document.getElementById("headline").innerHTML.includes("<br>Full book: Standard"));
check("headline is bold inside a coloured box", document.getElementById("headline").innerHTML.includes("font-weight:700") && document.getElementById("headline").innerHTML.includes("background:#e8f5e9"));
check("loaded selectors match", document.getElementById("selection").textContent.includes("match the loaded comparison"));
check("updated status is green and idle", document.getElementById("status").innerHTML.includes(">Updated<") && document.getElementById("status").innerHTML.includes("Environment: Idle") && document.getElementById("status").innerHTML.includes("#1b7f37"));

// Regression guard: the Environment status line must never freeze the lower
// tables. Fire real row clicks after Update and after a re-render, and require
// the detail panel to keep responding.
const liveRows = document.getElementById("summaryBox").querySelectorAll("tbody tr");
check("status update leaves bucket rows clickable", liveRows.length > 1, `${liveRows.length} rows`);
if (liveRows.length > 1) {
  liveRows[0].fire("click");
  const firstTitle = document.getElementById("detailTitle").innerHTML;
  liveRows[1].fire("click");
  check("second bucket click after a status update still responds", document.getElementById("detailTitle").innerHTML !== firstTitle);
  const bondRows = document.getElementById("detailBox").querySelectorAll("tbody tr");
  check("bond rows are clickable after a status update", bondRows.length > 0, `${bondRows.length} rows`);
  // Both Main tab tables must keep a column visible while the body scrolls
  // sideways. The summary pins its first column; the detail table pins ID, so
  // the pinned cell is never the repeated Action value.
  check("Main tab tables freeze a column", (() => {
    const rule = /table\.grid th:first-child,\s*table\.grid td:first-child\s*\{[^}]*position:\s*sticky[^}]*left:\s*0/;
    const pinRule = /table\.grid td\.pin\s*\{[^}]*position:\s*sticky[^}]*left:\s*0/;
    const summary = document.getElementById("summaryBox").innerHTML;
    const detail = document.getElementById("detailBox").innerHTML;
    return rule.test(html)
      && pinRule.test(html)
      && summary.includes('<table class="grid">')
      && detail.includes('<table class="grid pinned">')
      && detail.includes('<th class="pin">ID</th>')
      && !detail.includes('<th class="pin">Action</th>');
  })());
  if (bondRows.length) {
    bondRows[0].fire("click");
    check("bond row click after a status update fills the detail fields", document.getElementById("detailFields").innerHTML.includes("<tr>"));
    liveRows[0].fire("click");
    check("a later bucket click clears the previous bond detail", document.getElementById("detailFields").innerHTML === "");
  }
  api.render();
  const redrawnRows = document.getElementById("summaryBox").querySelectorAll("tbody tr");
  if (redrawnRows.length) redrawnRows[0].fire("click");
  check("re-rendered rows keep their click handlers", document.getElementById("detailTitle").innerHTML.includes("Country"));
}

document.getElementById("monthEnd").value = "2026-08-31";
document.getElementById("monthEnd").fire("change");
check("month-end edit is pending", document.getElementById("selection").textContent.includes("Pending"));
check("pending edit asks for Update", document.getElementById("status").innerHTML.includes("Please Click Update") && document.getElementById("status").innerHTML.includes("#c62828"));
document.getElementById("indexInput").value = "LF98TRUU Index";
document.getElementById("indexInput").fire("input");
check("index edit is pending", document.getElementById("selection").textContent.includes("LF98TRUU Index"));
check("pasted ticker still notes long_comp_name", document.getElementById("indexNameNote").textContent.includes("long_comp_name"));
document.getElementById("monthEnd").value = api.P.selected_date;
document.getElementById("monthEnd").fire("change");
document.getElementById("indexInput").value = api.P.default_index;
document.getElementById("indexInput").fire("input");
check("bucket summary renders rows", rowsIn("summaryBox") > 1, `${rowsIn("summaryBox")} rows`);
check("summary keeps each measure together", (() => {
  const head = document.getElementById("summaryBox").innerHTML;
  const expected = [
    "Begin Count", "End Count", "+/- Count",
    "Begin Weight", "End Weight", "+/- Weight",
    "Begin OAS", "End OAS", "+/- OAS",
    "Begin Duration", "End Duration", "+/- Duration",
    "Begin Yield", "End Yield", "+/- Yield",
    "Begin Tenor", "End Tenor", "+/- Tenor",
    "Add Count", "Exit Count", "Add Weight", "Exit Weight"
  ];
  let cursor = head.indexOf("Country");
  for (const name of expected) {
    const at = head.indexOf(name, cursor);
    if (at < 0) return false;
    cursor = at;
  }
  return true;
})());
check("every measure has a +/- value", (() => {
  const row = api.summarize("Country", "All", {}).rows[0];
  return ["Count", "Weight", "OAS", "Duration", "Yield", "Tenor"]
    .every((name) => Object.prototype.hasOwnProperty.call(row, `+/- ${name}`));
})());
check("bucket rows sort by Add plus Exit weight", (() => {
  const rows = api.summarize("Country", "Standard", {}).rows;
  for (let i = 1; i < rows.length; i += 1) {
    const previous = (rows[i - 1]["Add Weight"] || 0) + (rows[i - 1]["Exit Weight"] || 0);
    const current = (rows[i]["Add Weight"] || 0) + (rows[i]["Exit Weight"] || 0);
    if (current > previous) return false;
  }
  return rows.length > 1;
})());
check("bucket chart is horizontal with signed exits", (() => {
  const markup = document.getElementById("dimensionChart").innerHTML;
  if (!markup.includes("Add right / Exit left")) return false;
  // Geometry, not colour: a negative bar must END at or before the zero line
  // and a positive bar must START at or after it. A chart that draws exits to
  // the right of zero fails here, which a bare `includes("-")` never did.
  const zero = markup.match(/<line x1="([0-9.]+)"[^>]*stroke="#9a9a9a"/);
  if (!zero) return false;
  const zeroX = Number(zero[1]);
  const bars = [...markup.matchAll(
    /<rect x="([0-9.]+)" y="[0-9.]+" width="([0-9.]+)" height="([0-9.]+)" fill="(#[0-9a-f]{6})"/g
  )]
    .map((m) => ({ x: Number(m[1]), w: Number(m[2]), h: Number(m[3]), fill: m[4] }))
    // The legend draws 10x10 swatches in the same colours; they are not bars.
    .filter((bar) => bar.w > 12 || bar.h > 12);
  const exits = bars.filter((bar) => bar.fill === "#e76f51");
  const adds = bars.filter((bar) => bar.fill === "#2a9d8f");
  if (!exits.length || !adds.length) return false;
  const exitsLeft = exits.every((bar) => bar.x + bar.w <= zeroX + 1);
  const addsRight = adds.every((bar) => bar.x >= zeroX - 1);
  return exitsLeft && addsRight;
})());
check("bucket chart follows the Bucket summary Add plus Exit order", (() => {
  const rows = api.summarize("Country", "All", {}).rows
    .filter((row) => (row["Add Weight"] || 0) !== 0 || (row["Exit Weight"] || 0) !== 0)
    .slice(0, 20);
  const chart = api.bucketChartRows("Country", "All", {});
  return rows.length > 1
    && chart.labels.join("|") === rows.map((row) => String(row.Country)).join("|")
    && chart.adds.every((value) => value >= 0)
    && chart.exits.every((value) => value <= 0);
})());
check("bucket chart keeps offsetting Add and Exit", (() => {
  const series = api.bucketChartSeries([
    { label: "Offset", add: 2, exit: 2 },
    { label: "Zero", add: 0, exit: 0 }
  ], 20);
  return series.labels.join("|") === "Offset"
    && series.adds[0] === 2
    && series.exits[0] === -2;
})());
check("bucket chart skips zero-change rows", (() => {
  const rows = [
    { label: "Zero A", add: 0, exit: 0 },
    { label: "Keep", add: 2, exit: 0 },
    { label: "Zero B", add: 0, exit: 0 },
    { label: "Exit", add: 0, exit: 1 }
  ];
  const series = api.bucketChartSeries(rows, 20);
  return series.labels.join("|") === "Keep|Exit";
})());
check("bucket chart caps at Top 20 plus Others", (() => {
  const rows = [];
  for (let index = 0; index < 25; index += 1) {
    rows.push({ label: `C${index}`, add: 25 - index, exit: 0 });
  }
  const series = api.bucketChartSeries(rows, 20);
  return series.labels.length === 21
    && series.labels[20] === "Others"
    && series.adds[20] === 15;
})());
check("dimension chart draws bars", barsIn("dimensionChart") > 0, `${barsIn("dimensionChart")} bars`);
check("chart legend sits inside the figure", document.getElementById("dimensionChart").innerHTML.includes("Add weight") && document.getElementById("dimensionChart").innerHTML.includes("Exit weight"));
check("bucket chart subtitle names the table order", document.getElementById("dimensionChart").innerHTML.includes("Bucket summary order"));
check("chart panel is dark with light text", html.includes("background: #0d1117") && document.getElementById("dimensionChart").innerHTML.includes('fill="#f5f5f5"') && document.getElementById("dimensionChart").innerHTML.includes('fill="#e8e8e8"'));
check("charts stop at 80% of a 1920 px view", (() => {
  const widths = api.P.filter_widths;
  const row = Object.keys(widths).reduce((sum, key) => sum + widths[key], 0)
    + api.P.filter_gap_px * (Object.keys(widths).length - 1);
  const cap = Math.floor(api.P.screen_width_px * api.P.chart_max_screen_ratio);
  const expected = `min(${api.P.chart_width_px}px, 100%)`;
  return api.P.screen_width_px === 1920
    && Math.abs(api.P.chart_max_screen_ratio - 0.8) < 1e-9
    && api.P.chart_width_px === cap
    && api.P.chart_width_px < row
    && document.getElementById("dimensionChart").style.width === expected
    && document.getElementById("detailChart").style.width === expected;
})());

const result = api.summarize("Country", "Standard", {});
api.showBucket(result.rows[0], "Country");
check("bucket click sets the detail title", document.getElementById("detailTitle").innerHTML.includes("<b>Country</b>"));
check("bucket detail lists the bucket bonds", rowsIn("detailBox") >= 1, `${rowsIn("detailBox")} rows`);
check("detail summary names adds, exits, and three weights", (() => {
  const text = document.getElementById("detailTable").innerHTML;
  return /^\d+ adds? and \d+ exits?\. Add weight [-\d,.]+%, Exit weight [-\d,.]+%, Net weight [-\d,.]+%\.$/.test(text);
})(), document.getElementById("detailTable").innerHTML);
check("detail chart selects top 10 adds and top 10 exits", (() => {
  const fake = [];
  for (let value = 1; value <= 15; value += 1) fake.push({ Action: "Add", Weight: value, ID: `A${value}` });
  for (let value = 1; value <= 15; value += 1) fake.push({ Action: "Exit", Weight: value, ID: `E${value}` });
  const top = api.topAddExitRows(fake);
  return top.length === 20
    && top.filter((row) => row.Action === "Add").length === 10
    && top.filter((row) => row.Action === "Exit").length === 10
    && top[10].Weight === -6
    && top[19].Weight === -15;
})());
check("bucket detail chart draws", barsIn("detailChart") >= 1, `${barsIn("detailChart")} bars`);
check("detail bar labels omit the Add/Exit prefix", (() => {
  const text = document.getElementById("detailChart").innerHTML;
  const labels = Array.from(text.matchAll(/<text[^>]*>([^<]+)<\/text>/g)).map((match) => match[1]);
  return labels.length > 0 && labels.every((label) => !/^(Add|Exit)\s/.test(label));
})());
check("detail rows run from largest Add to largest Exit", (() => {
  const signed = api.signedChangeRows(api.changeRows("All"));
  return signed.length > 0
    && signed.some((row) => row.Weight < 0)
    && signed.every((row, index) => index === 0 || (signed[index - 1].Weight || 0) >= (row.Weight || 0));
})());
check("detail table shows Exit weight as a negative number", (() => {
  const bucket = api.summarize("Country", "All", {}).rows.find((row) => (row["Exit Weight"] || 0) > 0);
  if (!bucket) return false;
  api.showBucket(bucket, "Country");
  return />-\d/.test(document.getElementById("detailBox").innerHTML);
})());
check("detail chart uses the same signed axis", document.getElementById("detailChart").innerHTML.includes("Add right / Exit left"));

const changes = api.changeRows("Standard");
api.showBond(changes[0], true);
check("bond detail sits below the bond table", html.indexOf('id="detailBox"') < html.indexOf('id="detailFields"'));
check("bond click shows the selected spread and other detail fields", (document.getElementById("detailFields").innerHTML.match(/<tr>/g) || []).length === api.P.detail_fields.length - (api.P.spread_options.length + api.P.duration_fields.length + api.P.yield_fields.length - 3));
check("bond click draws the weight chart", barsIn("detailChart") >= 1);

api.state.dimension = "Tenor";
api.state.filters = { "Tenor Bucket": ["7-10Y"] };
api.render();
check("dimension switch with a filter still renders", rowsIn("summaryBox") >= 1);

api.state.dimension = "Sector";
api.state.filters = {};
api.state.book = "MBS/TBA";
api.render();
check("MBS/TBA book renders", rowsIn("summaryBox") >= 1, `${rowsIn("summaryBox")} rows`);

api.state.book = "All";
api.render();
check("export button is gone", !html.includes('id="export"') && !html.includes('getElementById("export")'));
check("Main/Export/Full Position tabs exist", html.includes('id="tabMain"') && html.includes('id="tabExport"') && html.includes('id="tabPositions"'));
check("Export and Full Position tabs start hidden", document.getElementById("exportTab").style.display === "none" && document.getElementById("positionsTab").style.display === "none" && document.getElementById("mainTab").style.display !== "none");
document.getElementById("tabExport").fire("click");
check("Export tab opens on click", document.getElementById("exportTab").style.display === "" && document.getElementById("mainTab").style.display === "none" && document.getElementById("positionsTab").style.display === "none");
document.getElementById("tabPositions").fire("click");
check("Full Position tab opens on click", document.getElementById("positionsTab").style.display === "" && document.getElementById("exportTab").style.display === "none");
check("Full Position has a date dropdown", document.getElementById("positionView").value === "start"
  && document.getElementById("positionView").innerHTML.includes(api.P.previous_date)
  && document.getElementById("positionView").innerHTML.includes(api.P.selected_date));
check("Full Position start table repeats the header row", (() => {
  const start = document.getElementById("positionsTable").innerHTML;
  return start.includes('class="export-header-row"')
    && start.includes("<td>ID</td><td>Name</td>")
    && (start.match(/<tr/g) || []).length === api.P.previous.length + 2;
})());
check("Full Position puts Weight after Sector", (() => {
  const start = document.getElementById("positionsTable").innerHTML;
  return start.includes("<td>Sector</td><td>Weight</td>")
    && !start.includes("<td>Weight</td><td>ID</td>");
})());
check("Full Position prints Weight as a percent", (() => {
  const start = document.getElementById("positionsTable").innerHTML;
  return /<td>-?\d+(\.\d+)?%<\/td>/.test(start);
})());
document.getElementById("positionView").value = "end";
document.getElementById("positionView").fire("change");
check("Full Position end table follows the dropdown", (() => {
  const end = document.getElementById("positionsTable").innerHTML;
  return end.includes('class="export-header-row"')
    && (end.match(/<tr/g) || []).length === api.P.latest.length + 2;
})());
document.getElementById("tabMain").fire("click");
check("Main tab returns on click", document.getElementById("mainTab").style.display === "" && document.getElementById("exportTab").style.display === "none" && document.getElementById("positionsTab").style.display === "none");

check("Export has a data dropdown", document.getElementById("exportView").value === "changes");
check("export changes table repeats the header row", (() => {
  const changes = document.getElementById("exportTable").innerHTML;
  return changes.includes('class="export-header-row"')
    && changes.includes("<td>Action</td><td>ID</td>")
    && (changes.match(/<tr/g) || []).length === api.changeRows("All").length + 2;
})());
check("export changes puts Weight after Sector as a percent", (() => {
  const changes = document.getElementById("exportTable").innerHTML;
  return changes.includes("<td>Sector</td><td>Weight</td>")
    && !changes.includes("<td>Action</td><td>Weight</td>")
    && /<td>-?\d+(\.\d+)?%<\/td>/.test(changes);
})());
document.getElementById("exportView").value = "summary";
document.getElementById("exportView").fire("change");
check("export summary table follows the dropdown", (() => {
  const summary = document.getElementById("exportTable").innerHTML;
  const dimension = api.state.dimension;
  const column = api.P.dimension_columns[dimension] || dimension;
  const rows = api.summarize(dimension, "All", {}).rows;
  return summary.includes('class="export-header-row"')
    && summary.includes(`<td>${column}</td><td>Begin Count</td><td>End Count</td>`)
    && (summary.match(/<tr/g) || []).length === rows.length + 2;
})());
check("export tables format long floats", !/\.\d{8,}/.test(document.getElementById("exportTable").innerHTML));

api.state.dimension = "Country";
api.state.action = "Add and Exit";
api.state.filters = { "Rating Bucket": ["NR"] };
api.render();
const naSummary = api.summarize("Country", "All", { "Rating Bucket": ["NR"] });
check("NR rating filter has rows", naSummary.rows.length >= 1, `${naSummary.rows.length} rows`);
check("headline scope follows active filters", document.getElementById("headline").innerHTML.includes("filters = Rating: NR"));
api.showBucket(naSummary.rows[0], "Country");
const naDetail = document.getElementById("detailBox").innerHTML;
check("detail list inherits the Rating filter", naDetail.includes("NR") && !naDetail.includes("AAA") && !naDetail.includes("AA+"));
api.state.filters = {};
api.render();

const turnoverSummary = api.summarize("Country", "All", {});
const turnoverRow = turnoverSummary.rows.find((row) => (row["Add Weight"] || 0) + (row["Exit Weight"] || 0) > 0);
const turnoverRatio = Number(api.P.index_mv_ratio);
check("summary carries bucket turnover", Boolean(turnoverRow)
  && "Turnover (index %)" in turnoverRow
  && "Turnover Rate (%)" in turnoverRow);
check("bucket turnover uses the index MV ratio", (() => {
  if (!turnoverRow) return false;
  const expected = (turnoverRow["Exit Weight"] || 0) + (turnoverRow["Add Weight"] || 0) * turnoverRatio;
  return Math.abs(turnoverRow["Turnover (index %)"] - expected) < 1e-9;
})());
check("headline carries monthly turnover", document.getElementById("headline").innerHTML.includes("Monthly turnover"));

api.state.filters = {};
api.state.dimension = "Country";
api.render();
check("Spread is a multi-select box after Currency and before Book", (() => {
  const options = api.P.spread_options || [];
  const filters = document.getElementById("filters");
  return options.join("|") === "OAS|Z-Spread|I-Spread"
    && filters.innerHTML.includes("Spread")
    && filters.innerHTML.includes("(All)")
    && filters.innerHTML.includes("Z-Spread")
    && filters.innerHTML.includes("I-Spread")
    && !filters.innerHTML.includes('value="ASW"')
    && filters.innerHTML.indexOf("Currency") < filters.innerHTML.indexOf("Spread")
    && filters.innerHTML.indexOf("Spread") < filters.innerHTML.indexOf("Book");
})());
check("Spread and Book use the same multi-select height", !html.includes("height:70px"));
check("default Spread OAS shows the OAS block", document.getElementById("summaryBox").innerHTML.includes("Begin OAS") && !document.getElementById("summaryBox").innerHTML.includes("Begin Z-Spread"));
const spreadFilter = document.getElementById("spreadFilter");
spreadFilter.selectedOptions = [{ value: "Z-Spread" }];
spreadFilter.fire("change");
check("Z-Spread selection redraws summary and headline", document.getElementById("summaryBox").innerHTML.includes("Begin Z-Spread")
  && !document.getElementById("summaryBox").innerHTML.includes("Begin OAS")
  && document.getElementById("headline").innerHTML.includes("Z-Spread"));
check("Duration and Yield boxes expose all items after Spread", (() => {
  const filters = document.getElementById("filters");
  return filters.innerHTML.includes("Duration")
    && filters.innerHTML.includes("Modified duration")
    && filters.innerHTML.includes("Effective duration")
    && filters.innerHTML.includes("Option adjusted spread duration")
    && filters.innerHTML.includes("Yield to maturity")
    && filters.innerHTML.includes("Yield to worst")
    && !filters.innerHTML.includes("Net yield to worst")
    && !filters.innerHTML.includes("Duration to maturity")
    && !filters.innerHTML.includes("Macaulay duration mid")
    && filters.innerHTML.indexOf("Spread") < filters.innerHTML.indexOf("Duration")
    && filters.innerHTML.indexOf("Duration") < filters.innerHTML.indexOf("Yield")
    && filters.innerHTML.indexOf("Yield") < filters.innerHTML.indexOf("Book");
})());
const durationFilter = document.getElementById("durationFilter");
const yieldFilter = document.getElementById("yieldFilter");
durationFilter.selectedOptions = [{ value: "OASD" }];
durationFilter.fire("change");
yieldFilter.selectedOptions = [{ value: "YTM" }];
yieldFilter.fire("change");
check("Duration and Yield selections expand their blocks", document.getElementById("summaryBox").innerHTML.includes("Begin OASD")
  && document.getElementById("summaryBox").innerHTML.includes("Begin YTM")
  && document.getElementById("headline").innerHTML.includes("OASD")
  && document.getElementById("headline").innerHTML.includes("YTM"));
api.showBond(api.changeRows("All")[0], true);
check("bond fields show only the selected spread", document.getElementById("detailFields").innerHTML.includes("<th>Z-Spread</th>")
  && !document.getElementById("detailFields").innerHTML.includes("<th>OAS</th>")
  && !document.getElementById("detailFields").innerHTML.includes("<th>I-Spread</th>"));
document.getElementById("exportView").value = "summary";
document.getElementById("exportView").fire("change");
check("Export Summary carries all three spread types", (() => {
  const table = document.getElementById("exportTable").innerHTML;
  return table.includes("Begin OAS") && table.includes("Begin Z-Spread") && table.includes("Begin I-Spread")
    && !table.includes("Begin ASW")
    && table.includes("Begin OASD") && table.includes("Begin YTM")
    && table.includes("End OAS") && table.includes("End Z-Spread") && table.includes("End I-Spread");
})());
check("Changes and Full Position carry every spread, duration, and yield item", [...(api.P.spread_options || []), ...api.P.duration_fields, ...api.P.yield_fields]
  .every((field) => api.P.detail_fields.includes(field) && api.P.position_columns.includes(field)));
spreadFilter.selectedOptions = [{ value: "OAS" }];
spreadFilter.fire("change");
durationFilter.selectedOptions = [{ value: "Duration" }];
durationFilter.fire("change");
yieldFilter.selectedOptions = [{ value: "Yield" }];
yieldFilter.fire("change");

const bookFilter = document.getElementById("bookFilter");
bookFilter.selectedOptions = [{ value: "Standard" }];
bookFilter.fire("change");
check("Book selection redraws and updates scope", api.state.book === "Standard"
  && document.getElementById("headline").innerHTML.includes("Scope:</b> Book = Standard"));
bookFilter.selectedOptions = [{ value: api.P.all_filter_label }];
bookFilter.fire("change");
api.render();

// Regression guard: an innerHTML += on the filter container re-creates the
// boxes above it, which silently drops their listeners. All five dimension
// boxes must stay bound and must redraw the panels below.
check("filter boxes are built in one assignment", !/filters\.innerHTML\s*\+=/.test(code));
check("every dimension filter box is bound", (() => {
  const boxes = document.getElementById("filters").querySelectorAll("select[data-column]");
  return boxes.length === api.P.filter_columns.length
    && boxes.every((box) => (box.handlers.change || []).length === 1);
})());
const filterProblems = [];
(() => {
  const boxes = document.getElementById("filters").querySelectorAll("select[data-column]");
  const labels = Object.fromEntries(api.P.filter_columns.map(([label, column]) => [column, label]));
  const cleared = () => Object.fromEntries(api.P.filter_columns.map(([, column]) => [column, [api.P.all_filter_label]]));
  const rows = api.P.previous.concat(api.P.latest);
  for (const box of boxes) {
    const column = box.dataset.column;
    const value = [...new Set(rows.map((row) => String(row[column])))].sort()[0];
    api.state.filters = cleared();
    box.selectedOptions = [{ value }];
    box.fire("change");
    if (JSON.stringify(api.state.filters[column]) !== JSON.stringify([value])) {
      filterProblems.push(`${column} not stored (${JSON.stringify(api.state.filters[column])})`);
      continue;
    }
    if (!document.getElementById("headline").innerHTML.includes(`${labels[column] || column}: ${value}`)) {
      filterProblems.push(`${column} missing from the headline scope (${value} vs ${labels[column] || column})`);
      continue;
    }
    if (rowsIn("summaryBox") < 1) filterProblems.push(`${column} left the summary empty`);
  }
  api.state.filters = cleared();
  api.render();
})();
check("each dimension filter box redraws the panels below", filterProblems.length === 0, filterProblems.join("; "));

if (fail.length) {
  console.error(`\n${fail.length} check(s) failed`);
  process.exit(1);
}
console.log("\nall preview checks passed");
