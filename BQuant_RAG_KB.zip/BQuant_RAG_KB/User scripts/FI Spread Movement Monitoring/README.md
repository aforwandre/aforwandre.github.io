# FI Spread Movement Monitoring

> **CRITICAL ACCOUNT-SAFETY STOP:** never request, probe, test, generate, or
> use ESG, GHG, climate, or sustainable-finance data items. A violation can
> cause the Bloomberg account to be suspended or deleted. Avoid unreviewed
> separately licensed data; if no core alternative exists, obtain Bloomberg
> HelpDesk confirmation before changing any BQL call.

BQuant Desktop app for ranking the Top 10 spread increases and
10 decreases on a universe the operator names. The Universe dropdown offers four
sources: `Index` (a typed Bloomberg index ticker), `AIM account` (a typed AIM
code whose holdings become the universe), `AIM vs Index` (AIM code then Index,
both fields at once, ranked separately), and `Bond` (one typed bond ticker). `LEGATRUU Index`
(Global Aggregate) is the recorded Index example; every field starts empty and
the example is not submitted unless it is typed.
The highway is `RAG KB/29-fi-spread-movement-monitoring.md`; the AIM request
shape is the frozen contract in `RAG KB/25`; the decision evidence is in
`DECISION_RECORD.md`.

The operator confirmed on 2026-10-23 and again on 2026-10-24: universe
`LEGATRUU Index`, spread choices OAS/Z/I, custom start/end dates, and the
descriptor list `id`, `name`, `rating`, `crncy`, `maturity`, `duration`
(the `id` column is the ranking response key; the other five are requested).
`Asset swap spread` was offered from 2026-11-02 and **withdrawn the same day**
at the operator's request, because a swap-curve measure is the heaviest of the
four to ask for across a multi-currency index and the Desktop run has to stay
inside the two-minute timeout (DR-26). The dropdown offers exactly `OAS`,
`Z-Spread`, `I-Spread`; `data.py` refuses the withdrawn value instead of
silently mapping it.
On 2026-10-30 the operator asked for a typed Index field, empty on launch,
with `LEGATRUU Index` kept as the placeholder example. On 2026-10-31 the
operator added the Universe dropdown so the same ranking can run on an AIM
account instead of an index, and added `country_full_name` and
`classification_name` so `Country` and `Sector` are available as dimensions
(decision record DR-13).
This build has not been reconciled against Terminal, so it is **not proof of
entitlement, units, or field semantics**, and a successful index run says
nothing about AIM entitlement.
Review the returned values in Terminal before production use.
There is no version stamp, V1 label, or build number anywhere in this project.
A dated string had to be hand-edited after every change, so it drifted and told
the reader nothing the request log does not already date; it is removed rather
than hidden, and `tests/test_app.py` fails if one is reintroduced.

## Files to copy into BQuant

Create this structure in one BQuant project (runtime files only):

```text
MAIN.ipynb
fi_spread_movement/
  __init__.py
  config.py
  data.py
  engine.py
  charts.py
  cache.py
  app.py
```

Copy the Python files in the order shown above, then `MAIN.ipynb`. Both come
from `Upload/`: `Upload/MAIN.ipynb.txt` renamed, and the seven modules with the
`.txt` suffix removed. `cache.py` is required, not optional: `app.py` imports it
at module load, so leaving it out fails the first notebook cell with
`ModuleNotFoundError: No module named 'fi_spread_movement.cache'`.
`python3 sync_upload.py` writes them together, so the
notebook can never ship importing a name the package no longer defines. Open
`MAIN.ipynb`, restart the kernel, and run the single notebook cell. The cell
prints nothing: the header on the page is the only title, and it carries no
version label. The app does
not query Bloomberg until **Update** is clicked. Do not copy `tests/`,
`preview/`, `Upload/`, `__pycache__/`, or the markdown files into the Desktop
project.

`Upload/` holds `.txt` copies of the runtime files for hand-copying to the
Desktop machine. Copy each file, then remove the `.txt` suffix. The mirror is
generated: run `python3 sync_upload.py` after any code change, and
`python3 sync_upload.py --check` to see whether it drifted. The test suite runs
that check, so a forgotten mirror fails locally instead of reaching Desktop
stale.

## What the app does

- One request run per Update, and nothing is sent before the button is clicked.
  A one-book run is 10 Bloomberg requests (2 ranking, 6 descriptor, 1 duration
  measure family, 1 series); a two-book `AIM vs Index` run is 12 (4 ranking, 6
  descriptor, 1 duration family, 1 series). The four duration measures share the
  single request that `Duration` used to occupy alone, so the three extra
  columns cost **no additional call**. Choose
  the Universe source first; the field(s) beside it then take the universe and
  start empty (the Index placeholder shows `LEGATRUU Index` and is not
  submitted). Defaults otherwise: OAS, last seven calendar days.
- Four sources, one dropdown:

| Source | Field(s) on screen | Universe sent |
|---|---|---|
| `Index` | Index | `bq.univ.members(index, dates=end_date)` |
| `AIM account` | AIM code | `bq.univ.members(type="AIM")` + `with_params` |
| `AIM vs Index` | AIM code **then** Index, both at once | both of the above, ranked separately |
| `Bond` | Bond | `bq.univ.list([one ticker])` |

- Index path: `bq.univ.members(index, dates=end_date)` — membership as of the
  end date.
- AIM path: the frozen contract from `RAG KB/25`. `bq.univ.members(type="AIM")`
  with `accounts=[one code]`, `pxnum`, and `profile="DEFAULT_PROFILE"` on
  `bql.Request(..., with_params=...)`; no dates and no `ts_position()`. The
  block is attached to the two ranking requests only, because the descriptor
  and series requests run on an explicit `bq.univ.list()` of candidate IDs.
  A blank code, a code containing whitespace, or an unknown source is refused
  before any request is built. `AIM_PXNUM` defaults to the frozen `1377`.
- `AIM vs Index` path: both fields are required; a blank on either side is a
  refusal, never a one-book run. The AIM code box is drawn first, because it is
  the account the index is compared against; the AIM field is validated first
  for the same reason, so with both boxes blank the refusal names the left-hand
  box. Each book keeps its own ranking and its own
  top 10, and every row carries `Universe`. Descriptors, the duration measure
  family, and the candidate series are requested once on the union of both
  candidate lists (four ranking + six descriptor + one duration family + one
  series request). A bond that is both an index member
  and an account holding appears twice, once per book: identity here is
  `(Universe, ID)`. See `DECISION_RECORD.md` DR-14.
- `Bond` path: one typed security in `bq.univ.list([...])` (`RAG KB/06`), the
  same change ranking on it, so a one-row screen is the expected shape. A list
  separator or an index ticker is refused rather than widened. See DR-15.
- Both new sources are **validation-only** (`DECISION_RECORD.md` DR-18): the
  corpus documents `net_chg()`, `grouprank()`, and `groupsort()` only on
  `members()` universes, and has no `bq.univ.list` signature row, so `RAG KB/23`
  `G4` (universe compatibility) is open until a Desktop run returns rows on a
  one-security `list` universe and on the AIM side beside an index book. No
  `BUNDLE_EXAMPLES.md` card pairs two books side by side.
- Rankings are change-based on every path: the AIM holding size never widens,
  narrows, or re-weights the lists. An AIM holding list can also contain cash
  and equity lines; those return no spread and are excluded with a diagnostic,
  not by an unverified security-type filter.
- Two ranking requests (top 10 increases / top 10 decreases) per book, seven
  descriptor requests, and one small candidate-series request used only to
  validate the effective observation dates. In a two-book comparison the two
  rankings become four and the descriptor/series requests still run **once**, on
  the union of both candidate lists: at most 20 IDs in a one-book run and at
  most 40 in a comparison, because the cut is per book (DR-14).
- The tables show the candidate ID, name, country, sector, rating, currency,
  maturity, duration, the **start and end spread levels**, and the source-unit
  change. Start and end are the first and last observation of the bounded
  candidate series this app already requests for the change check, so they cost
  no extra request, no extra data item, and no wider universe. Their headings
  name the loaded spread type (`Start OAS` / `End OAS` / `OAS Change`), because
  OAS, Z and I are three different numbers on the same bond. A ranked ID the
  series did not cover keeps a blank level rather than a zero or a carried
  forward value. Each ranked `Change` is still
  checked against `Last Spread - First Spread` from a bounded second series
  request, and the effective start/end dates are still read; the table that used
  to show the result was retired on 2026-11-01, so a mismatch, a shifted
  effective date, or a missing series prints in the step log. The check proves
  the arithmetic and the effective window, not the units.
- Every request is logged with elapsed time, row count, and returned columns.
  That log is request metadata: it lives in the `Export Excel` tab, not on
  `Main`.
- One descriptor failure does not hide the other fields; the step log carries
  each failed field independently. The successful per-field receipt is request
  metadata, not data, so it is **not** a table at the top of the layout: it sits
  in the `Export Excel` tab under `Request detail`, and only a `FAILED` field is
  written to the step log (DR-16).
- Missing values stay missing. There is no fill, interpolation, zero substitution,
  universe widening, or silent spread-type fallback.
- Changes are shown in **source spread units**; they are not labelled as bps or
  percentages until Terminal evidence establishes units.

## Filters and interactive charts

Everything in this section is computed in pandas over the frames the last
**Update** already returned. A filter, a grouping change, or a click never
builds a request and never reaches `data.py`, so the status bar stays on
`Updated` rather than flipping to `Please Click Update`.

| Control | Values | What it does |
|---|---|---|
| Group by | `Country`, `Sector`, `Tenor`, `Rating`, `Currency` | The bucket chart's split. Sits at the far left of its own row, above the five boxes |
| Country | `(All)` + the countries actually returned | Narrows both ranked tables and every chart |
| Sector | `(All)` + the sectors actually returned | Narrows both ranked tables and every chart |
| Tenor | `(All)` + the tenor buckets present | Bucket of `Maturity` measured from the end date |
| Rating | `(All)`, `IG`, `HY`, `NR/Missing`, `Numeric (unmapped)`, `Other` | Bucket of the returned `rating()`, letter grades only |
| Currency | `(All)` + the currencies actually returned | Narrows both ranked tables and every chart |

The five pick lists run in the order `Country`, `Sector`, `Tenor`, `Rating`,
`Currency`, with the same fixed widths (300 / 300 / 220 / 220 / 220 px), the
same `90px` label width, the same `rows=10`, and the same 8 px gap as the
Dimension list in FI Index Change, so the two screens line up when read side by
side. The chart width is exactly their total plus the four gaps (1,292 px).

`(All)` is the rest state and is ignored when another value is picked. A
picked value that no row carries empties the view instead of falling back to
everything, so a wrong filter is visible rather than silently ignored. A blank
`Country` or `Sector` from Bloomberg is shown as `(blank)` and can be filtered
on; `(unavailable)` instead means that descriptor request failed, and the step
log names the failure. The two labels never share a value.

Three charts follow those controls:

1. **Movers by bucket** — horizontal grouped bars, increases and decreases
   counted separately. Counts are charted rather than a summed spread, because
   one bucket with two 40-unit moves and one bucket with a single 80-unit move
   are different pictures. The net and absolute sums stay in the table beside
   it. Past 20 buckets the tail collapses into one `Others (n)` row, the same
   top-N as FI Index Change.
2. **Signed change per mover, then its Top 10 table** — one bar per security,
   blue for a widening and orange for a tightening, ordered by magnitude. The
   change keeps its sign, so widening and tightening never cancel into a false
   zero. The `Top 10 increases` table sits directly under this chart and
   `Top 10 decreases` directly under the next one; nothing is placed between a
   chart and its table. In a two-book run each chart is grouped AIM first and
   then Index, and the table under it repeats the same order under a book
   heading, so the bars and the rows read top to bottom as one pair.

   Above each of those two charts sits its own **Display Top** row: a whole
   number box (default `10`, i.e. `config.TOP_N`) and a **Refresh** button.
   Refresh redraws that panel only, from the frames already in memory — it is
   not Update and builds no request. The two panels are independent: an
   increase panel can be shortened without touching the decreases. In
   `AIM vs Index` the number is **per book**, so `Display Top 3` draws three AIM
   rows *and* three Index rows; a single `head(n)` on the stacked frame would
   drop Index entirely. A value above `config.TOP_N` cannot invent rows, because
   the ranking request already capped what was fetched: the panel draws what it
   has and says so, as it does when a bucket simply holds fewer rows. `0`, a
   negative number, or text is refused with a red note and the panel keeps its
   last applied count, rather than being clamped silently. A new Update resets
   both boxes to `10`, so a count sized for a previous run never narrows a fresh
   one unannounced. `Export Excel` copies the filtered run, not this displayed
   slice, in the same way it ignores a bucket pick.
3. **Spread path** — one line: the spread of the security the operator selected,
   across the returned observation dates. It uses the real `DATE` values, not
   row positions, and a gap stays a gap rather than being forward-filled. With
   nothing selected the chart says so (`Select a bond to view its spread path`)
   instead of drawing every candidate, and a selected ID that the series request
   did not cover is named in the message rather than left blank.

The rating bucket is a display grouping only. An unrecognised letter is
`Other` and a numeric rating is `Numeric (unmapped)`, because the numeric scale
is not established for this app; no rating is converted. Tenor is computed from
the returned `Maturity` and the end date — it is **not**
`mty_years_tdy()` and no new field is requested. A blank or already-past
maturity lands in `Missing`.

Clicking a bar or a line selects that security and shows its ranked row plus
its returned series in the detail panel. Clicking an identifier that is not in
the loaded run says so instead of raising. In the `AIM vs Index` run every
matching row is shown, each under its book heading.

On a two-book run a fourth panel appears between the bucket chart and the
signed-change charts: **Movers by bucket — AIM vs Index**, a diverging bar
chart with one row per bucket per book (AIM above Index inside every bucket).
Increases are the positive side, decreases the negative side, the zero line is
centred, and both halves share one symmetric scale
(`comparison_spec()['limit']`), so a decrease bar and an increase bar of the
same count are the same length. It is followed by the **AIM vs Index
comparison** table (movers, increases, decreases, net and mean change, mean
duration, widest change, top bucket, one line per book, AIM first). Counts are
charted because summing two books produces a number that belongs to neither;
the signed sums stay in the table. A single-universe run shows no such panel,
and its charts keep the increase/decrease colours and the magnitude ordering.

Both diverging bucket charts read the colour as the **direction**: an increase
is blue (`CHART_DIRECTION_COLORS[0]`), a decrease orange
(`CHART_DIRECTION_COLORS[1]`), so the two halves of the zero line are told
apart without the legend. A two-book run keeps that hue meaning and separates
the books by depth instead — AIM `#0d47a1` / `#e65100`, Index `#64b5f6` /
`#ffb74d`. The two Top 10 charts are the opposite case: both books sit on one
side of the axis there, so colour names the book (`CHART_BOOK_COLORS`). An
earlier build drew a one-book run in that book's comparison pair, which was two
shades of one hue and made an increase and a decrease look alike; the renderer
now draws the colour the specification publishes, so the Plotly and SVG paths
cannot disagree.

On BQuant Desktop the charts are Plotly `FigureWidget` objects created once and
updated with `batch_update()`, so a filter change does not rebuild the widget.
Their layout is copied from FI Index Change: the same fixed width
(`CHART_WIDTH_PX` = 1,292 px, the sum of the five filter widths plus the gaps),
the same 360 px height (300 px for the path chart, with that app's 40/48 px
top and bottom margins through `charts._detail_layout`), a transparent paper
and plot background on the dark chart card, light `#f5f5f5` title text,
`#b8b8b8` axis labels, `#3a3a3a` grid lines, `#9a9a9a` zero line, a 140 px left
margin, and the legend under the plot. Each figure is wrapped in a same-width
`HBox` AND its
layout carries `width=CHART_WIDTH_PX` with `autosize=False`, because the HBox
alone does not size a `FigureWidget` on Desktop. If Plotly or `ipywidgets` is
unavailable in the kernel, `charts.py` renders the same specification as an
HTML table and the numbers stay visible. The local preview draws the same
specification as inline SVG, so the design can be reviewed on this machine
without Plotly.

## Tabs and Export Excel

The screen is a `Tab` with two titled pages, as in FI Index Change:

| Tab | Contents |
|---|---|
| `Main` | Header controls, status bar, Group by + the five boxes, the two diverging bucket charts and the full bucket table under them, the two ranked panels (a Display Top row, then the chart, then its table), the selected-security panel, and the single-bond path chart followed by its daily observation list |
| `Export Excel` | A `Data` dropdown (Top 10 increases, Top 10 decreases, Request log) and the selected table |

Every export table repeats its column names as the **first data row**, so
selecting the whole table, copying it, and pasting into Excel keeps the header.
The two ranked tables copy what `Main` shows under the current filters, so a
filter is not silently undone on the way to Excel. The request log is not
filterable and is copied whole. The validation table was retired from the
screen on 2026-11-01: its findings print in the step log instead. A one-book run has no `Universe`
column: the book label only exists when two books were requested.

The heading of every spread column names the spread type the loaded run used:
`Start OAS` / `End OAS` / `OAS Change` on the ranked tables, `Increase OAS` /
`Decrease OAS` / `Net OAS Change` on the bucket table, and `OAS` on the daily
observation list. The rename happens at the drawing edge only, so the frames
behind the charts and the click handlers keep their canonical column names
(`fi_spread_movement/app.py`, `_spread_headers`).

The request log is request metadata, not data: it is not on `Main`. Two
surfaces carry the receipt instead — the per-field `Request detail` block on
this tab (DR-16), and the `Request log` table in the `Data` dropdown (the
request-level count, elapsed time, rows, and columns). No file is written.

## What the bounded series check still does

The bounded series request and its arithmetic check both stay; only the table
that used to show them is gone. The check answers one question: **does the
ranking arithmetic match the spreads this same window actually returned, and
did the window really start and end where it was asked to?** It is built in
`engine.validate_candidate_changes()` (`fi_spread_movement/engine.py`) from the
second, bounded `spread(..., dates=range(start, end))` request
(`fi_spread_movement/data.py`), never from the ranking response.

The frame below is no longer rendered as a panel. It powers the daily
observations table and the spread path of the selected bond, and any finding is
written to the step log: a note when an effective date shifted, a note naming
the IDs with no series, and one line stating the arithmetic check ran. Read the
log, not the page, for this diagnostic.

| Column | Meaning | Source |
|---|---|---|
| `ID` | The ranked security | ranking response key |
| `Side` | `increases` or `decreases` side that carried the row | `engine._prepare_side` |
| `BQL Change` | The signed change BQL ranked on (`net_chg`) | ranking response, `Change` column |
| `First Spread` / `Last Spread` | First and last non-null spread in the returned series | series request, grouped per ID (`engine.py:325-341`) |
| `Effective Start` / `Effective End` | The `DATE` of those two observations | series request `DATE` |
| `Series Change` | `Last Spread - First Spread` | computed (`engine.py:344`) |
| `Matches BQL` | `True` when `BQL Change` ≈ `Series Change` (`rtol=1e-6`, `atol` from the caller) | computed (`engine.py:346-349`) |

`Matches BQL = False` means the two numbers disagree; it does not say which one
is right. Three causes are distinguishable in practice:

1. **Different endpoints.** `BQL Change` comes from `net_chg()` on the ranking
   range; the series is the dated `spread` item. If the requested start or end
   is not an observation date (weekend, holiday, sparse series), the effective
   dates shift. `engine.py:353-377` writes a note naming how many IDs shifted.
2. **A stale or missing observation.** `net_chg()` may carry the last value
   forward where the dated series has a gap, so the two first/last values are
   not the same pair. Rows with no series at all are counted and named
   (`engine.py:378-382`) and left with a blank `Series Change`.
3. **A real unit or item difference.** If neither endpoint shifted and a gap
   does not explain it, the ranking item and the series item are not the same
   measure. That is a data/entitlement question, not a display question.

What to do with an anomaly row: do not widen the window or add `fill` to make
it match. Copy the row's dates and values into `DECISION_RECORD.md`, and compare
the two endpoint spreads in Terminal for that bond. A `False` row is a
`Incomplete`-grade finding for that bond until the cause is named.

## Timeout protection: cache, retry, and the cached fallback

Desktop kills a query at two minutes. This app cannot make Bloomberg answer
faster, so it does three things so a timeout no longer leaves an empty screen.
The error is still reported — these are guard rails, not a way to hide it.

**1. A retry of the identical request.** A timed-out request is sent once more,
unchanged. Nothing is dropped and no field is substituted: the evidence from the
sibling project is that a second attempt answers in seconds because the first one
warmed the Bloomberg-side cache. Only a timeout is retried; a rejected item, a
missing entitlement or a bad ticker can never succeed on a second try, so those
are reported immediately instead of spending another two minutes. The request log
records how many attempts each request took.

**2. A result cache.** Every clean run is written to `cache/` under the project
folder, keyed on the universe, the spread type, both dates, `TOP_N` and a
generation token. A changed window or a changed spread is a different key, so one
run's numbers can never be served for another. `CACHE_KEEP_RUNS` (12) old runs
are kept and the rest pruned. A run with a failed field is not cached, because
replaying it would turn `Incomplete` into a clean-looking cached answer.

**3. The automatic fallback.** When a run fails **on a timeout** and a clean run
is saved for the same key, the saved run is shown instead of an empty screen. The
status word is `Cached` in amber — never `Updated` — the detail box says why, and
the live error is kept on screen and in the step log. A deterministic failure
never falls back: showing old numbers for a rejected item would hide a real
problem behind a table that looks current. `Load saved` does the same on request,
without a request and without waiting for a failure.

Two switches in `config.py`: `CACHE_READ_FIRST` (off) makes Update read the cache
before asking Bloomberg, and `CACHE_KEEP_RUNS` controls how many runs are kept.

## Reading a failure message

The banner separates two different facts, because they need different reactions.

- **`Requesting the data failed — …`** The failure happened while the request
  was being built or sent. A `ValueError: BQL response has no item named …` now
  prints the response type, how many items it exposed, and their names, so a
  naming problem can be told apart from an empty answer. The lookup order is the
  one documented in `RAG KB/07`: `response.get(name)`, then index access with a
  name match, then `bql.combined_df(response)` as the last resort. The combined
  frame is used only when it carries exactly one value column; several value
  columns are refused rather than guessed, because picking one would label a
  measure with another measure's numbers.
- **`Preparing the ranked tables failed — …`, `Drawing the figures failed — …`**
  The data arrived; a local step then failed. The request receipts still print
  under the banner, so the run is not a total loss. The change-arithmetic check
  and the label consistency check are diagnostics: their failure is a note in
  the detail box or the step log and never blanks the tables, so they never
  produce this banner at all.
- **`0 row(s)`** A request that answered with no rows is reported as zero rows
  with a note, not as a rejected field: a quiet week or a short window is not a
  broken data item.

`Load saved` reads the saved run for the exact inputs on screen and never sends a
request; see the cached fallback above.

## First Desktop validation run

1. Pick one bond that Terminal shows the selected spread measure for; record its
   two endpoint values and the currency.
2. Choose two **business days** (start earlier than end, end not in the future).
   Start with the last five business days; the build blocks windows over 31 days
   until request timing is measured.
3. Click **Update** once and record the request log (count, elapsed seconds,
   rows, columns) and the per-field step-log lines.
4. Read the **step log** for the bounded series check: the effective dates
   should be the selected endpoints and `Change` should equal `Last - First`.
   The check has no panel any more, so a finding appears there as a line. A
   mismatch or a missing line must be reported before widening the window.
5. Compare the Top-10 changes and units against Terminal for at least two bonds.
6. Record the outcome (timing, units, coverage, anomalies) in `DECISION_RECORD.md`
   and `VersionLog.md` before changing the request, adding fill, or promoting to
   production.

## Still unresolved until the Desktop run

- Units of OAS/Z/I values and of `Change` (do not assume bps).
- `Asset swap spread` is **not** in the app: it was offered for part of
  2026-11-02 and withdrawn the same day (DR-26). No `ASW` item is requested, so
  its entitlement, sign convention, and cost are no longer open questions here;
  they stay open in the sibling `FI Index Change` record where a decision on
  `ASW` was taken separately.
- `net_chg()` endpoint behaviour with no `fill`: the KB defines it as the change
  between the first and last values in the range, so weekend/holiday endpoints can
  shift the effective dates (the step log reports this).
- Z-spread parameters/coverage on multi-currency Global Aggregate members.
- `duration()` definition (the catalog also has separate modified-duration and
  duration-to-maturity items).
- `rating()` letter/number scale (display only; never interpreted numerically).
- Entitlement confirmation and request breadth/timeout on the work account.
- Membership as of the end date (survivorship, not point-in-time at both ends).

## Local checks

From this folder, run:

```bash
python3 -m unittest discover -s tests -v
```

The suite uses synthetic pandas frames and a fake `bql` module only. It never
executes BQL or a Bloomberg request. BQuant Desktop runs Python 3.11; the code
avoids newer-only syntax and the local suite verified the 3.11 grammar. The local
run used Python 3.12 / pandas 3.0.5; the Desktop pandas version is not pinned in
the KB, so the first Desktop run is the real environment check.

## Layout preview (local only)

Three ways to look at the layout without BQuant Desktop. None of them is part of
the upload.

**1. Interactive preview (default).** Runs the real `app.py` and `engine.py` in
this Mac's Python and returns their panels to the browser:

```bash
python3 preview/server.py          # http://localhost:8775/
```

Open `http://localhost:8775/` or `http://127.0.0.1:8775/interface.html`. Both
reach the same page. Use `localhost` in the in-IDE browser, because it resolves
only the hostname. Click **Update** and the tables come
from the real controller: date validation, the 31-day cap, the disable-while-
running behaviour, the ranked tables, the arithmetic check, the per-field
receipt lines, and the request log. A preview-only checkbox beside the notebook
simulates a failure after the request so the diagnostics path can be reviewed.

**The server always runs the code on disk.** Every request compares the mtimes
of `preview/*.py` and `fi_spread_movement/*.py`; when any of them changed, those
modules are reloaded before the page is built, so an edit appears on the next
browser refresh and the server does not need restarting. A reload that raises is
shown on the page instead of the previous version being served; fix the file and
refresh. `--no-reload` pins the code imported at startup.

The page is also supervised by the `com.bqnt.fi-spread-preview` LaunchAgent,
which keeps it listening on 8775 and logs to `/tmp/bqnt-fi-spread-preview.err`.
Restart it with `launchctl kickstart -k gui/$(id -u)/com.bqnt.fi-spread-preview`
after editing `server.py` itself, since the server cannot reload its own entry
point.

### Status bar

The bar is the same two-line shape used by FI Index Change, rewritten for this
app:

| Line | What it shows |
|---|---|
| 1 | The phase: `Idle` (red), `Loading`, `Updated` (green), `Please Click Update` (red), `Refused` (red), `Incomplete`, `Error` |
| 2 | `Environment: Processing` (red) while a request is in flight, `Environment: Idle` (green) otherwise |

- `Refused` means the input failed a local check — empty or whitespace-bearing
  AIM code, empty Index, a ticker without the `Index` token, a reversed or
  over-wide date window, or an unknown universe source. Nothing was sent, and the
  previous run's figures are cleared rather than left on screen under the red
  bar.
- `Error` keeps the diagnostics already collected: request count and total time
  and the messages, with the per-field receipt in the Export Excel tab. The
  previous run's tables and charts are cleared for the same reason.
- `Incomplete` is a completed run where at least one request failed, so the
  tables on screen are partial. The per-field receipt in the Export Excel tab is
  still shown, because it records what did arrive.
- `Please Click Update` appears only after a successful load, when an Index,
  Spread, or date edit no longer matches the run that produced the tables. The
  edit itself never sends a request; putting the controls back on the loaded
  values restores `Updated`.
- The bar carries no version stamp; the stamp lives in the detail box.
- Long text (run summary, request totals) fills the detail box under the bar.
  Only a **FAILED** field writes a line in the step log (DR-16); the successful
  per-field receipt is not repeated there.

Port **8775** is reserved for this project. 8765 is the ETF Spread preview and
8770 is FI Index Change; do not reuse them here.

The Universe dropdown drives the label and the placeholder of the value field:
`Index` → `Index` / `LEGATRUU Index`, `AIM account` → `AIM code` / `ABC123`.
The page asks the server for that wording, so the preview cannot drift from
`app.py`.

**2. Static page.** `preview/interface.html` opens with no process behind it. It
ships no script, so it cannot run an Update **and no row or bucket on it reacts
to a click**; the page says both in a visible note. It is for reading the layout
offline. A bucket pick, a security pick, and the filters only exist on the
served page (`python3 preview/server.py`).

```bash
python3 preview/build_preview.py           # regenerate after any app change
python3 preview/build_preview.py --check   # exit 1 when the file is stale
```

This project's builder has no dry-run switch: `--check` only compares, and the
plain run rewrites the file.

**Upload mirror.** The seven runtime modules plus `MAIN.ipynb` are staged into
`Upload/` as `.txt` copies for the Desktop hand-copy step. The mirror is
generated, never edited, and it also prunes stray macOS metadata, so the
delivery folder holds only what ships:

```bash
python3 sync_upload.py           # refresh every mirror, prune orphans
python3 sync_upload.py --check   # exit 1 when a mirror drifted
```

`tests/test_upload_sync.py` runs the `--check` path, so a module that changed
without its mirror being refreshed fails the suite instead of reaching Desktop
stale.

**3. Terminal sample.** `preview/sample_run.py` calls the same two engine
functions with synthetic frames and prints the tables and notes:

```bash
python3 preview/sample_run.py
```

Both front ends share `preview/preview_core.py`, which imports the real
`fi_spread_movement` package with stubbed `ipywidgets` / `IPython.display` and
drives the real `FISpreadMovementApp._on_update`. Nothing re-implements app or
engine logic in HTML or JavaScript, so the preview cannot drift from the code
that ships. Control order, descriptions, headings, table columns, and status
wording all come from `app.py` / `config.py` / `engine.py`.

Every identifier and number is a placeholder (`DUMMYBOND…`) that varies with the
spread type and dates, so a control change is visibly reflected without
pretending to be market data. No `bql` import exists on any preview path, so no
Bloomberg request can run locally. `tests/test_preview.py` starts the server,
drives it over HTTP, and fails when `interface.html` is stale.

To run the preview in the background across reboots, a LaunchAgent is enough:

```bash
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.bqnt.fi-spread-preview.plist
launchctl kickstart -k gui/$(id -u)/com.bqnt.fi-spread-preview   # after editing server.py
launchctl bootout gui/$(id -u)/com.bqnt.fi-spread-preview        # stop
```

The page is re-rendered per request and the app/engine modules are reloaded when
their files change, so editing `app.py`, `engine.py`, `data.py`, `charts.py`,
`config.py`, `svg_charts.py`, or `preview_core.py` needs only a browser refresh.
Editing `server.py` itself is the one change that needs the `kickstart` line,
because the server cannot reload its own entry point.

## Files in this folder

- `MAIN.ipynb` — thin import-and-display bootstrap; no startup request.
- `fi_spread_movement/` — `config`, `data`, `engine`, `charts`, `app`,
  `__init__`.
- `preview/` — `server.py` (interactive), `preview_core.py` (shared),
  `build_preview.py` + `interface.html` (static), `svg_charts.py` (the same
  chart specification as inline SVG), `sample_run.py` (local only).
- `tests/` — synthetic engine/data/app/notebook/preview checks (local only).
- `sync_upload.py` — writes and checks the `Upload/` mirrors.
- `Upload/` — generated `.txt` staging copies for the Desktop hand-machine.
- `DECISION_RECORD.md` — dated user confirmation and `23` decision records.
- `VERIFICATION_REPORT.md` — audit of the earlier Copilot draft plus the V1 rewrite.
