"""Mirror the runtime package into ``Upload/`` so the Desktop copy step is exact.

Desktop gets one file per module, each with a ``.txt`` suffix so the BQuant
project can hold them without the notebook picking them up as importable code.
The mirror is generated, never hand-edited: this script is the only writer.

Usage:
    python3 sync_upload.py            # write the mirrors
    python3 sync_upload.py --check    # exit 1 when a mirror drifted

``--check`` is what the test suite runs, so a module that changed without its
mirror being refreshed fails the suite instead of reaching Desktop stale.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGE_DIR = ROOT / "fi_spread_movement"
UPLOAD_DIR = ROOT / "Upload" / "fi_spread_movement"
SUFFIX = ".txt"

# The notebook is part of what Desktop receives, so it is mirrored too. It used
# to be copied by hand and went stale: the mirror still imported a config name
# the package no longer had, which would have failed at the first Desktop cell
# with ImportError rather than at the copy step.
NOTEBOOK = ROOT / "MAIN.ipynb"
NOTEBOOK_TARGET = ROOT / "Upload" / "MAIN.ipynb.txt"


def runtime_modules() -> list[Path]:
    """Every module Desktop must receive, in import order."""
    order = (
        "__init__.py",
        "config.py",
        "data.py",
        "engine.py",
        "charts.py",
        "cache.py",
        "app.py",
    )
    present = {path.name: path for path in PACKAGE_DIR.glob("*.py")}
    ranked = [present[name] for name in order if name in present]
    ranked += [path for name, path in sorted(present.items()) if name not in order]
    return ranked


def target_for(source: Path) -> Path:
    return UPLOAD_DIR / (source.name + SUFFIX)


def mirrored_files() -> list[tuple[Path, Path]]:
    """(source, mirror) pairs: every runtime module plus the notebook."""
    pairs = [(source, target_for(source)) for source in runtime_modules()]
    if NOTEBOOK.is_file():
        pairs.append((NOTEBOOK, NOTEBOOK_TARGET))
    return pairs


# Files a folder copy would carry that must never reach Desktop. macOS writes
# ``.DS_Store`` into any folder Finder has opened, and Python writes
# ``__pycache__`` beside an imported module; neither is pruned by the ``*.txt``
# rule, so a ``.DS_Store`` sat in ``Upload/`` and survived every sync.
JUNK_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}
JUNK_DIRS = {"__pycache__", ".pytest_cache"}


def junk_files() -> list[Path]:
    """Every stray metadata, cache or dotfile currently under ``Upload/``."""
    found: list[Path] = []
    if not ROOT.joinpath("Upload").is_dir():
        return found
    for path in ROOT.joinpath("Upload").rglob("*"):
        if path.name in JUNK_NAMES:
            found.append(path)
        elif path.is_dir() and path.name in JUNK_DIRS:
            found.extend(child for child in path.rglob("*") if child.is_file())
    return found


def plan() -> tuple[list[Path], list[Path], list[Path]]:
    """Return (write, prune, missing) without touching the disk."""
    pairs = mirrored_files()
    write: list[Path] = []
    missing: list[Path] = []
    for source, target in pairs:
        if not target.is_file() or target.read_bytes() != source.read_bytes():
            write.append(target)
        if not target.is_file():
            missing.append(target)
    expected = {target for _source, target in pairs}
    prune = sorted(path for path in UPLOAD_DIR.glob("*" + SUFFIX) if path not in expected)
    # Junk is pruned too, so the delivery folder holds only what ships.
    prune += [path for path in junk_files() if path not in prune]
    return write, prune, missing


def sync() -> int:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    write, prune, _missing = plan()
    by_target = {target: source for source, target in mirrored_files()}
    for target in write:
        target.write_bytes(by_target[target].read_bytes())
    for stale in prune:
        stale.unlink()
    for target in write:
        print(f"wrote {target.relative_to(ROOT)}")
    for stale in prune:
        print(f"pruned {stale.relative_to(ROOT)}")
    if not write and not prune:
        print("Upload mirrors are already in sync")
    return 0


def check() -> int:
    if not UPLOAD_DIR.is_dir():
        print("Upload/fi_spread_movement is missing; run python3 sync_upload.py")
        return 1
    write, prune, missing = plan()
    if not write and not prune:
        print("Upload mirrors are in sync")
        return 0
    for target in write:
        state = "missing" if target in missing else "out of date"
        print(f"{target.relative_to(ROOT)} is {state}")
    for stale in prune:
        print(f"{stale.relative_to(ROOT)} has no source module")
    print("Run python3 sync_upload.py to refresh the mirrors.")
    return 1


def main(argv: list[str]) -> int:
    return check() if "--check" in argv else sync()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
