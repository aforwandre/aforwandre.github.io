# FI Spread Movement Monitoring — Decision Record

Status: **validation-first build (V1), not production approval.**
Record format: `RAG KB/23-bql-substitution-due-diligence.md` § Decision record.
Unresolved fields stay visible in the app and in `VERIFICATION_REPORT.md`.

## User confirmation (dated evidence)

- **2026-10-23:** the operator selected the universe `LEGATRUU Index`
  (Global Aggregate), spread choices `OAS` / `Z` / `I`, custom start/end dates,
  and descriptors `id`, `name`, `rating`, `crncy`, `maturity`, `duration`.
  Recorded in `RAG KB/29` and `.cursor/rules/project-fi-spread-movement-monitoring.mdc`.
  The `id` descriptor is displayed from the ranking response `ID` key; the other
  five descriptors are requested from BQL (see GD-5).
- **2026-10-24 (chat):** the operator re-confirmed those selections and asked for
  a first version followed by a Desktop production/validation test, then iterative
  fixes. The operator also confirmed BQuant Python 3.11.
- **2026-10-30 (chat):** the operator asked for an Index field to the left of
  Spread. It starts empty. `LEGATRUU Index` remains the example placeholder.
  The request uses only the typed ticker.
- **2026-10-31 (chat):** the operator asked for a Universe dropdown to the left
  of the input, offering `Index` or `AIM account`, followed by the AIM code or
  the index ticker. Both sources spend the same OAS/Z/I ranking. The AIM shape
  is the frozen contract from `RAG KB/25`, re-used rather than re-derived.
- **2026-10-31 (chat, second request):** the operator asked for filtering like
  `FI Index Change` plus interactive charts. The implemented filters are limited
  to descriptors this app already requests (`Currency`, `Rating`, `Maturity`),
  so no filter becomes a new Bloomberg request. At that point Country and sector
  were deliberately **not** added: they are `country_full_name()` and
  `classification_name()`, which `FI Index Change` requests as part of its
  frozen membership list and which would be a new request on a bond book here.
  **Superseded on the same day:** the operator then asked for the five-filter
  row, and `DR-13` records the `RAG KB/23` review that admitted both fields as
  display dimensions. `DR-13` is the current state; this paragraph is the
  history that led to it.
- **2026-11-02 (chat):** the operator asked for the layout of DR-23 (two
  diverging charts, one full bucket table, a daily list under the path chart,
  Bond mode reduced to those two panels, the effective-date table retired,
  click-to-scope on bucket rows, click-to-select on any security row) and for
  `Asset swap spread` as the fourth spread choice, re-using the choice added to
  `FI Index Change`. `DR-22` and `DR-23` record both.
  `OAS` / `Z` / `I` remain the recorded choices and `ASW` is added, not
  substituted.
- **2026-11-02 (chat, later the same day):** the operator asked to **remove**
  `Asset swap spread`, because a swap-curve measure would make the Desktop
  request too heavy and risk the timeout. `DR-26` supersedes `DR-22`: the
  dropdown is back to the three confirmed choices, and the withdrawn value is
  refused rather than mapped.

This confirmation is **not** proof of entitlement, units, or field semantics.
The first Desktop run is a validation run.

## Global decisions

| ID | Decision | Status |
|---|---|---|
| GD-1 | Universe is the ticker typed into the Index field, passed to `bq.univ.members(index, dates=end)`. The field starts empty. `LEGATRUU Index` is the recorded example and the placeholder, never an automatic submission. A ticker that does not end with `Index` is refused | Guarded — validation run |
| GD-2 | Comparison is the documented `spread(dates=range(start,end)).net_chg()` over the selected dates; **no `fill`** is added | Guarded — endpoint behaviour to verify on Desktop |
| GD-3 | Ranking is BQL-side (`universe.filter(condition).filter(grouprank(order=...) <= TOP_N)` plus `groupsort()`), re-validated and capped in pandas | Guarded — composition not verbatim in KB |
| GD-4 | Descriptor and series requests are bounded to the ranked candidate IDs, never sliced positionally: at most `2 * TOP_N` (20) in a one-book run and `4 * TOP_N` (40) in the two-book comparison, because each book keeps its own top-N per direction. The cut is made by `grouprank`, not by taking the first rows of the stacked frame | Guarded — breadth/timeout to measure |
| GD-5 | "Bloomberg ID" is the ranking response `ID` key; no `bq.data.id()["value"]` request (that accessor is undocumented for index members) | Resolved for V1 |
| GD-6 | Fail-visible: per-field failures, invalid input, parser mismatches, ties, duplicates, and dropped rows are reported; no silent substitution | Resolved for V1 |
| GD-7 | Units are not labelled bps/% until verified in Terminal | Resolved for V1 |
| GD-8 | The universe source is the Universe dropdown (`Index` / `AIM account`); the value field is then an index ticker or an AIM code. The input starts empty on both paths. The AIM code is upper-cased and trimmed on the outside; a blank code, inner whitespace, or an unknown source is refused before a request | Guarded — AIM path unverified on Desktop |
| GD-9 | The AIM path uses the frozen `RAG KB/25` contract: `members(type="AIM")`, `accounts=[one code]`, `pxnum=1377`, `profile="DEFAULT_PROFILE"` on `with_params`. No dates, no `ts_position()`, no whole book in one list. `AIM_PXNUM` is the only switch | Guarded — frozen block copied verbatim; single-account scope to verify |
| GD-10 | Rankings stay change-based on the AIM path: holding size never filters, widens, or re-weights. Cash/equity holdings are excluded by having no spread, not by an unverified security-type filter | Resolved for V1 |
| GD-11 | The Currency / Rating / Tenor filters, the Group by dimension, and the three charts are **local views over frames already fetched**. They build no request, add no data item, and never move the status bar to `Please Click Update`. Only the confirmed descriptors are used: `Currency` as returned, `Rating` bucketed from `rating()` letter grades, and `Maturity` measured against the end date. Nothing is requested to populate a filter | Resolved for V1 |
| GD-12 | The rating bucket is display-only: letter grades map to IG/HY, an unrecognised letter is `Other`, and a numeric rating is `Numeric (unmapped)` because the numeric scale is not established here. Tenor is **derived** from `Maturity` and the end date, not `mty_years_tdy()`; a blank or past maturity is `Missing`. No rating or tenor is rescaled, filled, or inferred | Resolved for V1 |
| GD-13 | A picked filter value with no matching row yields an empty view rather than falling back to everything, so a wrong filter cannot masquerade as "no change". The charts and the headline count read the same filtered frames | Resolved for V1 |
| GD-14 | The screen shows one state at a time: a `Refused` input or a failed Update clears the previous headline, charts, tables, and comparison flag instead of leaving them under a red bar, while the per-field receipt survives in `Export Excel`. The two ranked export tables copy the filtered view, and a one-book run carries no constant `Universe` column (DR-19) | Resolved for V1 |

## Due-diligence records

### DR-01 — Universe / membership

- Source/role: BQL universe for the spread screen; security identity is the member bond.
- Candidate: `bq.univ.members(<typed index>, dates='YYYY-MM-DD')` (class U).
  `LEGATRUU Index` is the recorded example, not a default submission.
- Evidence: `RAG KB/02:200-206` (dated `members(..., dates='-1m')`), `RAG KB/28:77-78`
  (approved FI pattern), `RAG KB/02:690-704` (Global Aggregate tracker recipe using
  `LEGATRUU Index`), user confirmation 2026-10-24, typed-field confirmation 2026-10-30.
- Entitlement/batch scope: screen over full index membership; Desktop timeout unmeasured.
- Identity layers: security identity = member bond; no company/issuer mapping is displayed.
- Fallback: fail closed with a visible error; never widen or substitute the index.
- Required tests: member date argument recorded (tests/test_data.py); empty ranking path.
- Decision: **Guarded** — validation run; production only after breadth/timeout evidence.

### DR-01b — AIM account universe (second source)

- Source/role: an AIM account's holdings replace the index membership as the
  spread-screen universe. Security identity is still the held bond.
- Candidate: `bq.univ.members(type="AIM")` with `accounts=[one AIM code]`,
  `pxnum`, and `profile="DEFAULT_PROFILE"` on `bql.Request(..., with_params=...)`.
- Evidence: `RAG KB/25` § AIM request shape (frozen 2026-08-28 Desktop tests,
  IMG_6673/6674), `RAG KB/11` § BQL for AIM (tutorial shape plus the same
  user-confirmed freeze), `RAG KB/BUNDLE_EXAMPLES.md` `aim_one_account_positions`,
  `User scripts/ETF Capping Monitoring/etf_capping/data.py::_aim_request`.
- Entitlement: the user confirmed an AIM Enterprise licence is present while the
  runtime stays Desktop (`RAG KB/11`). That is licence evidence, not proof that
  every bond in the book returns a spread.
- Identity layers: AIM holding ticker is the request identity; no position
  quantity is requested, so holding size cannot alter the ranking.
- Batch scope: one account per Request; no whole-book `accounts` list; no
  `execute_many`. Two ranking requests carry the `with_params` block; the
  descriptor and series requests run on `bq.univ.list()` of candidate IDs.
- Failure behaviour: a blank code, inner whitespace, or an unknown source is
  refused before any request; a request failure is visible per side; no fallback
  to the recorded index example.
- Required tests: `tests/test_data.py::FetchMoversTests::test_aim_*`,
  `tests/test_app.py` source-switch cases, `tests/test_preview.py` AIM cases.
- Decision: **Guarded** — the request shape is frozen, but no Desktop run has yet
  confirmed account resolve, bond coverage, or AIM position breadth for this app.
  Do not describe the AIM path as production-ready until that run is recorded here.

### DR-02 — OAS spread (spread_type='OAS')

- Candidate: `bq.data.spread(spread_type='OAS', dates=func.range(start, end))` (class D).
- Evidence: `RAG KB/08:152`, `RAG KB/02:285` (verified quickstart spread types include OAS),
  `RAG KB/28:96` (OAS item used by the FI index app).
- Unresolved: units (bp vs percent not stated locally); OAS is used by the KB for
  "rich/cheap vs curve" while I-spread is the recipes' "Movers" field — the operator
  explicitly selected OAS as a mover measure, so this is a selected-but-unverified use.
- Fallback: source units displayed; no conversion; no `replacena`/zero substitution.
- Decision: **Guarded** — validation run.

### DR-03 — Z-spread (spread_type='Z')

- Candidate: `bq.data.spread(spread_type='Z', dates=func.range(start, end))` (class D).
- Evidence: `RAG KB/02:932-940`, `RAG KB/02:1969-1970`, `RAG KB/12:380-382`.
- Unresolved: Z is recipe-documented but absent from the verified quickstart spread-type
  list (`RAG KB/02:285`); some Z recipes pass `pricing_source='BVAL'` and
  `RAG KB/08:175-177` marks `pricing_source` as signature-confirmation-required.
- Fallback: visible failure; no silent fallback to another spread type.
- Decision: **Guarded** — validation run; confirm parameters/coverage in Terminal.

### DR-04 — I-spread (spread_type='I')

- Candidate: `bq.data.spread(spread_type='I', dates=func.range(start, end))` (class D).
- Evidence: `RAG KB/02:285` (verified), `RAG KB/12:76` (I-spread assigned to "Movers"),
  `RAG KB/02:390-391` / `12:116` (mover recipe uses `fill='prev'`; this build deliberately
  omits fill per `RAG KB/29:77` and exposes the effective dates instead).
- Fallback: visible failure; no fill.
- Decision: **Guarded** — validation run; compare no-fill endpoint behaviour with Terminal.

### DR-05 — Descriptor `name`

- Candidate: `bq.data.name()` (class M). Evidence: `RAG KB/08:145`, `RAG KB/28:86`.
- Fallback: blank column + per-field FAILED status.
- Decision: **Guarded** — display only.

### DR-06 — Descriptor `rating`

- Candidate: `bq.data.rating()` (class M). Evidence: `RAG KB/08:156`,
  `RAG KB/28:272` (letter-vs-number shape unresolved), `RAG KB/18:48-50`
  (hidden `NORMALIZED_SCALE` metadata).
- Bucket mapping is letter-only: S&P and Moody's investment-grade and
  high-yield letters map to `IG` / `HY`, an unrecognised letter is `Other`, a
  numeric value is `Numeric (unmapped)`, and `NR`/blank is `NR/Missing`.
  Bloomberg's own `N.A.` token maps to `N.A.`, and `MBS/TBA` is folded into
  `N.A.` because a pass-through has no issuer letter grade: `N.A.` says that,
  while `Other` would imply a rating this app does not have. No rating is
  rescaled, filled, or inferred.
- Fallback: blank column + status; never parsed numerically.
- Decision: **Guarded** — display only; confirm scale in Terminal.

### DR-07 — Descriptor `crncy`

- Candidate: `bq.data.crncy()` (class M). Evidence: `RAG KB/08:125-128`
  (pricing/settlement currency, production-verified FI), `RAG KB/28:103-105`.
- Decision: **Guarded** — display only.

### DR-08 — Descriptor `maturity`

- Candidate: `bq.data.maturity()` (class M). Evidence: `RAG KB/08:155`,
  `RAG KB/28:92`. The parser accepts a DATE-valued response for this item only.
- Decision: **Guarded** — display only.

### DR-09 — Descriptor `duration`

- Candidate: `bq.data.duration()` (class M). Evidence: catalog `22:7701` and
  `RAG KB/28:97`; **no canonical definition in `08`**. Separate items exist:
  `dur_adj_mid_semi_ann()` (mid modified duration) and `duration_maturity()`.
- Fallback: blank column + status if the response shape is unexpected.
- Decision: **Guarded** — display only; confirm the measure in the FLDS BQL tab.

### DR-10 — Candidate-series validation request

- Candidate: `bql.Request(bq.univ.list(candidate_ids), {'Spread': spread_item})`
  (class D + U; bounded to ≤20 IDs).
- Purpose: expose effective observation dates and verify
  `Change == Last Spread - First Spread` and the source units.
- Fallback: diagnostic only; failure never hides the ranked tables.
- Evidence: `RAG KB/02:1966-1978` and `RAG KB/12:682-694` (dated spread item inside a
  `bq.univ.list` universe Request), `RAG KB/06:144` (wrap literal IDs in
  `bq.univ.list`), `RAG KB/07:386-390` (net_chg definition), `RAG KB/18:104-144`
  (Arrow ID/DATE handling), `RAG KB/23:173-174` (isolated guarded validation
  request). The V1 adapter builds a fresh dated item for this request and never
  reuses the `net_chg()` expression.
- Decision: **Guarded** — validation aid; if it fails, record the failure and continue.

### DR-11 — Request shape and breadth

- Per Update: 2 ranking requests, 7 descriptor requests (≤ the candidate union
  each), 1 series request (same IDs). No `execute_many`. The descriptor count rose
  from 5 to 7 on 2026-10-31 when `Country` and `Sector` were added (DR-13). In the
  two-book comparison the two rankings double to 4, so a comparison Update is 12
  requests and the candidate union is at most 4 * `TOP_N` (40) IDs.
- Measured on Desktop? **No.** Desktop limits: two-minute timeout, 256 MB file,
  two concurrent workloads (`RAG KB/00-bquant-hard-stops.mdc:43-45`); `RAG KB/28:273`
  records LEGATRUU timeout pressure for 16 undated items. An AIM book may be
  larger than an index membership, and its universe expression is not dated, so
  the first AIM run must record the same log before any window change.
- Mitigation: default window 7 days, hard cap 31 days, request log with per-request
  elapsed time; the window is widened only after a measured run. Each descriptor
  rides on its own request over at most the candidate union, which in a one-book
  run is narrower than the sixteen-item membership request that `RAG KB/28`
  records as timeout-prone. The comparison union (40) is untested on Desktop and
  is the first thing the comparison log has to answer.
- Decision: **Guarded** — first run narrow; revisit cached mode / single combined
  ranking request after measurement.

### DR-12 — Failure and fallback policy

- Invalid input, missing `bql`, request build failure, per-request failure, parser
  ambiguity, and `Change`/series mismatch are all surfaced; no fill, interpolation,
  zero substitution, universe widening, or spread-type fallback.
- Decision: **Resolved for V1**.

### DR-13 — Descriptors `country_full_name` and `classification_name`

- Requested by the operator on 2026-10-31: `Country` and `Sector` must be
  available as dimensions and filters, in the same sequence as the Dimension
  list in FI Index Change (`Country`, `Sector`, `Tenor`, `Rating`, `Currency`).
- Source requirement: two display classifications on a **bond** universe, at the
  security identity level, undated, on the at-most-20 candidate IDs the ranking
  already returned. Entitlement family: core `bq.data` classification items, the
  same family as `rating()` and `crncy()` already in this app.
- Candidates and evidence: `bq.data.country_full_name()` and
  `bq.data.classification_name()`. Both are already frozen for this exact index
  universe in `RAG KB/28` (`Membership request`, rows `Country` and `Sector`;
  `RAG KB/28:521-522` keeps `classification_name()` and rejects
  `market_sector_des()` as an equity-universe filter), and both are implemented
  in `fi_index_change/field_library.py` on the same `bq.univ.members()` bond
  universe this app also reads. `CONCEPT_INDEX.md` `## country_full_name` and
  `## classification_name` both cite that freeze as the authority for this
  universe. Not a cross-product proxy: no equity field is used, and the catalog
  was not the evidence.
- Identity: `security_classification` for Sector; Country is the issuer's
  country of risk as Bloomberg returns it. Neither is used as a security key:
  `ID` remains the only join and ranking key.
- Batch breadth: one descriptor request each, over the same `bq.univ.list()` of
  the candidate union (at most 20 IDs one-book, at most 40 in the two-book
  comparison). No widening of the universe and no second pass.
- Fallback: **fail closed with a diagnostic**. A failed request leaves the column
  absent in the descriptor table, `enrich_ranked` writes `(unavailable)` rather
  than another field's values, and `field_status` records the failure. A blank
  value Bloomberg returned is shown as `(blank)` and stays filterable; the two
  labels are deliberately different. An ID the descriptor response did not cover
  at all is `(unavailable)` too, and the ranked frame carries a note saying how
  many IDs that was.
- Idempotence: no `with_params`, no dates, no `replacena`. `country_iso()` is not
  used as a fallback (`RAG KB/28:522`).
- Unresolved until the first Desktop run: the exact `classification_name()`
  vocabulary on this index (SBI scheme) and whether any bond returns no country.
  Both are display-only here, so neither blocks the ranking.
- Decision: **Guarded** — display dimensions only; no BQL filtering, no
  re-weighting, no change to the ranking request.

### DR-14 — Universe source `AIM vs Index` (two books in one Update)

- Requested by the operator on 2026-11-01: a universe source that enters an AIM
  account and an index ticker at the same time, shows both input boxes at once,
  and reports the two books side by side in the existing charts and tables.
- Composition, not a new data item: both halves are the two request shapes
  already frozen for this app (`RAG KB/29` `Membership request` and
  `RAG KB/25` § AIM request shape). No new BQL field, no new universe function,
  no cross-product proxy.
- Request shape: each side keeps its own universe (`members(index, dates=end)`
  and `members(type="AIM")` + `accounts`/`pxnum`/`profile` on `with_params`),
  its own two ranking requests, and its own change-based top-N. The descriptor
  set and the candidate-series request run **once** on the union of both
  candidate lists, which keeps the run at twelve small requests instead of
  twenty. The two books are never merged into one ranking: the AIM holding size
  does not re-weight the index book, and vice versa.
- Identity: a bond can be an index member and an account holding at the same
  time, so in this mode a row identity is `(Universe, ID)`. Duplicate detection
  and the top-N cut are per book, and every row carries `Universe`. Dropping a
  repeated ID as a "duplicate" would delete one book's row and is a bug.
- Comparison metrics: counts, increases, decreases, net and mean change, mean
  duration, widest change, top bucket, one line per book, computed in pandas
  from frames already loaded. The comparison chart is counts per bucket, one
  increase and one decrease series per book; the signed sums stay in the table
  because summing two books produces a number that belongs to neither.
- Fallback: **fail closed with a diagnostic**. A blank on either side is a
  refusal before any request, never a one-book run that reads as a comparison.
  A failed side does not blank the other: its error is recorded, its rows are
  absent, and the status says `Incomplete`.
- Entitlement: **not implied**. A successful index ranking proves nothing about
  AIM (`RAG KB/29` AIM caveat). The first comparison run must show the AIM
  side returning rows; if it fails, the cause is an AIM entitlement or account
  problem, not this app.
- Request budget: four ranking + six descriptor + one duration family + one
  series request per Update, spent sequentially (Desktop allows at most two
  concurrent workloads). The two-minute timeout is measured on the first run,
  not assumed.
- Decision: **Guarded** — first run narrow; revisit a shared ranking request
  after measurement.

### DR-15 — Universe source `Bond` (one typed bond ticker)

- Requested by the operator on 2026-11-01: a source that takes one typed bond
  ticker for targeted spread/movement analysis.
- Universe: `bq.univ.list([one_ticker])`. `RAG KB/06` requires a private
  literal universe to be wrapped in `bq.univ.list([...])`, and `RAG KB/02`
  § Project Practice Notes already spends `spread().value(bq.univ.list(bond))`
  on a single bond. Not a new data item and not an index proxy.
- Breadth: exactly one security. A list separator (`,`, `;`, newline) is
  refused rather than split, and a value naming an index is refused (that is
  what the Index source is for), so the universe can never widen silently.
- Ranking: the same `net_chg()` + `grouprank()` request shape, so a one-row
  screen is the expected shape for a bond that moved. No `fill`, no widening to
  the issuer or the parent index.
- Descriptors and series: unchanged; they run on the returned candidate ID.
- Entitlement: the bond must be entitled for this account and priced for the
  selected spread. A blank price is a diagnostic, never a substitute field.
- Decision: **Guarded** — single security, no fallback, no widening.

### DR-16 — The descriptor/series receipt leaves the page body

- Operator instruction 2026-11-01: remove the `Descriptor and series status`
  table from the top of the layout, because it is static request metadata and
  not data.
- What it was for: the per-field receipt (`Country: returned 19 row(s), 17
  non-null`) and the series receipt (`Spread Series: returned 38
  observation(s) across 19 ID(s)`). It existed to answer "did each descriptor
  request actually return rows?" during the validation build. It is about the
  request, not about any bond, so it never changes when a filter changes.
- Where it went: the receipt is recorded on the result and shown in the
  **Export Excel** tab under `Request detail`, where a copy/paste table belongs.
  The step log keeps only a `FAILED` field line, so a broken descriptor is
  still visible in the run that hit it.
- Also removed: the two-cell `Descriptor` / `Series` status block that used to
  sit beside the ranking tables for the same reason.
- Decision: **Resolved** — no metadata table above the numbers; failures stay
  visible; the full receipt stays available for hand-checking.

### DR-17 — Two measured layout gaps closed

- `CHART_DETAIL_HEIGHT_PX` (300) was declared and asserted but never applied,
  so the path chart was drawn at the bar-chart height (360). `FI Index Change`
  draws its lower chart at 300 with a 40 px top and 48 px bottom margin, so
  `charts._detail_layout` now carries that card and `path_figure` applies it.
  The two new margin constants live in `config.py` beside the shared ones.
  A test now pins the constant to the builder, so it cannot go dead again.
- In the static preview the filter row was 1,308 px wide (the CSS gap was
  12 px, the Desktop widgets use an 8 px right margin), and the chart cards
  collapsed to their intrinsic minimum inside a flex row. With `gap: 8px` and
  a fixed-width chart card, the row measures 1,292 px and the card does too,
  which is the same edge the notebook shows.
- Measured in the preview at a 1,440 px viewport: boxes 300/300/220/220/220 at
  left 27/335/643/871/1,099, row width 1,292, all four chart cards 1,292.
- Decision: **Resolved** — the height and width constants are now the ones the
  figures actually use, not a second set that only the tests read.

### DR-18 — Evidence status of DR-14, DR-15, and the layout parity claims

Recorded after a read-only audit of `RAG KB/` on 2026-11-01. The point of this
entry is that the app must not be described as more RAG-backed than it is.

- **`AIM vs Index`: no corpus card.** `BUNDLE_EXAMPLES.md` has no composition
  that pairs an AIM book with an index book, and `RAG KB/29` froze the universe
  as a two-way choice before this change. What *is* documented is each half
  separately (`29` Membership request, `25` AIM request shape) and the
  technique of spending one Request in more than one universe
  (`02` § Project Practice Notes pairs a bond list with a single bond;
  `BUNDLE_EXAMPLES` `official_index_value_injection` injects an index series).
  So DR-14 composes documented parts; the composition itself is unproven.
- **`Bond`: the request shape is documented, the ranking over it is not.**
  `02:66` uses a single `'… Corp'` universe and `02`/`12` call
  `spread().value(bq.univ.list(bond))` on one bond, so the universe half has
  evidence. `net_chg()`, `grouprank()`, and `groupsort()` appear in the corpus
  only on `members()` universes; `bq.univ.list` also has no signature row in
  `07`. `RAG KB/23` `G4` (signature, parameters, universe compatibility) is
  therefore **unresolved** for a one-row `list` universe.
- **Consequence:** both sources stay **Guarded / validation-only**. A Desktop
  run must show that the ranking expression returns rows on a `list` universe
  (Bond) and that the AIM side returns rows next to an index book
  (`AIM vs Index`) before either is described as validated. A failure there is
  a universe-compatibility finding, not a bug to paper over with a fallback.
- **Chart numbers are code-side, not RAG-verified.** `RAG KB/28` states only
  "transparent paper and plot backgrounds, light text and grid" and gives the
  `CHART_WIDTH_PX` arithmetic for *its own nine* boxes. The hex values
  (`#0d1117`, `#f5f5f5`, `#b8b8b8`, `#3a3a3a`, `#9a9a9a`), the heights
  (360 / 300), the margins (140 / 16 / 48 / 64, and 40 / 48 for the lower
  card), and the 1,292 px width for five boxes come from reading
  `User scripts/FI Index Change/fi_index_change/`. They match that app; they
  are not numbers the RAG KB froze.
- **Two tabs have no corpus precedent for this app.** `RAG KB/28:441` freezes
  Main / Export / Full Position for FI Index Change. This app's `Main` +
  `Export Excel` is an operator instruction with no card behind it. It does not
  conflict with `28:441` because nothing is written to disk: `Export Excel`
  only prepares a copy/paste table, so the "a packaged App user cannot reach
  the filesystem" rule is respected. The name promises a file it does not
  create; it is kept because the operator asked for that label.
- Decision: **Recorded** — behaviour unchanged, claims narrowed.

### DR-19 — Display contract after a refusal, a failure, and a filter

Two display-only decisions, taken on 2026-11-01 after a read-only review found
the screen could show two different states at once. Neither changes a request.

- **A refusal or a failed Update clears the rendered result.** `Refused` and
  `Error` used to leave the previous run's headline, charts, and tables in place
  under a red status bar, while the `Export Excel` tab was emptied. Three
  surfaces disagreed and the oldest number was the most convincing one. The
  figures, the comparison flag, the click selection, and the visible frames are
  now dropped together, and the headline states that no result is loaded. This
  is fail closed: a wrong input cannot borrow the authority of the run before it.
  The per-field receipt is request metadata and survives, in the tab where DR-16
  put it.
- **`Export Excel` copies the filtered view.** The two ranked tables export the
  frames currently shown on `Main`; `Validation` and the request log are not
  filterable and are copied whole. Copying a 3-row filtered view into Excel used
  to produce 20 rows with no warning. A filter that matches nothing says so
  instead of falling back to `No run loaded`.
- **A one-book run carries no `Universe` column.** A column whose every cell
  reads `Universe` is noise in the table and in the copy; the universe is already
  in the status bar and the detail panel. In the two-book comparison the column
  is the row identity and stays.
- Decision: **Resolved for V1** — display only, no request shape, no data item,
  no universe change.

### DR-20 — `AIM vs Index` draws the AIM code first

- Operator instruction 2026-11-01: in the `AIM vs Index` source, put the AIM
  code box **before** the Index box. Previously the row read `Index` then
  `AIM code`.
- What changed: `_visible_inputs()` returns `[aim_input, index_input]` for the
  comparison source. The dropdown stays first, so the row is `Universe | AIM
  code | Index`. No other source changes order.
- What did **not** change: each box keeps its own field and its own value. The
  request still reads `index_input.value` as the index ticker and
  `aim_input.value` as the account code, so the reorder cannot swap which
  universe is sent. A test pins both values across a re-render to prove it.
- One follow-on for consistency: `normalize_comparison()` now validates the AIM
  code first, so with both boxes blank the refusal names the left-hand box
  (`AIM account is empty.`) instead of the Index box. Returning a blank on one
  side is still a refusal; the returned pair order is unchanged, so every
  caller still receives `(index, aim)`.
- Decision: **Resolved for V1** — layout and refusal wording only. No request
  shape, no data item, no universe change.

### DR-21 — The comparison chart plots both books; the path chart plots one bond

- Operator observation 2026-11-01: in `AIM vs Index` the screen showed only the
  comparison *table*; the bar chart above it collapsed the two books into one
  aggregate, so the comparison was readable only as numbers. The path chart drew
  every ranked candidate at once, which answered no question after a click.
- What changed, display only:
  - **Title.** `AIM vs Index comparison`, from the single source
    `config.COMPARISON_TITLE`. No template or test spells the string twice.
  - **Diverging comparison chart.** `charts.comparison_spec()` now emits one row
    per `(bucket, book)`, ordered by `config.COMPARISON_BOOK_ORDER`
    (`AIM`, `Index`), and two traces per book: increases as positive values,
    decreases as negative. One symmetric `limit` (`max(|count|)`) is published
    with the spec so both renderers scale the left and right halves identically;
    neither side fits its own maximum. The chart counts movers; signed sums stay
    in the table, because summing two books' spread changes would produce a
    number belonging to neither.
  - **Top 10 tables.** `change_box` is now `(increase chart, increase table,
    decrease chart, decrease table)`, so each table is the next widget after the
    bars it lists. In a comparison each table splits into `AIM (n row(s))` then
    `Index (n row(s))`, the same order as the chart.
  - **Path chart.** `charts.path_spec()` takes `selected`; `app._render_path_chart()`
    filters the series to that one ID. Nothing selected is its own state with a
    sentence, and a selected ID the series request did not cover names itself.
    At most one line is drawn, in both renderers.
  - **Request log.** Not deleted. The raw table left `Main`; the data remains in
    `Export Excel` under `Request log`, together with the DR-16 receipt, which
    is where `29` already puts both.
- What did **not** change: no `bql.Request` shape, field list, `with_params`, or
  request count; no change to `data.py` / `engine.py` semantics, units, fill
  direction, or the `(unavailable)` / `(blank)` rule. Single-book charts keep
  their existing spec keys and appearance; the shared `change_spec()` gained a
  book sort and `customdata`, and a one-book frame passes through one block.
- Decision: **Resolved for V1** — display only. The Desktop rendering of the
  diverging axis and the series coverage behind a selected ID are still
  **unverified** until the first `AIM vs Index` run on Desktop.

### DR-22 — `Asset swap spread` becomes the fourth spread choice

- Operator instruction 2026-11-02: the same fourth choice added yesterday to
  `FI Index Change` is to be added here. Both projects select it through
  `bq.data.spread(spread_type="ASW")`.
- Evidence: `RAG KB/02` lists `ASW` among the verified fixed-income spread types
  and `RAG KB/28` records the identical call for the sibling project. This is a
  parameter value on an existing, already-frozen request — not a new data item
  and not a new product family. Nothing in the ESG/GHG/climate/DRSK/CAST set is
  touched.
- What changed: `config.SPREAD_TYPES` gained `"Asset swap spread": "ASW"` as the
  fourth entry. `data.py` already passed `SPREAD_TYPES[label]` into
  `spread_type=`, so no request shape, field list, or call site changed.
- What did **not** change: the frozen `OAS` / `Z` / `I` choices stay, and a run
  still sends exactly one spread type.
- **Unresolved, needs the first Desktop run:** whether `ASW` is entitled for the
  same IDs as `OAS` under this account, and whether its sign convention matches
  `OAS` (widening positive). `RAG KB` states neither. The UI therefore says
  `Increase` / `Decrease` and never claims a direction in bps. Do not probe the
  field to discover entitlement; confirm in Terminal on the same small ID set.
- Decision: **Approved for the UI, unresolved for entitlement and sign.**
  **Superseded on 2026-11-02 by `DR-26`:** the choice was withdrawn, so this
  entry is the history of a decision that no longer holds. Nothing listed above
  should be re-applied without a new dated instruction.

### DR-23 — One bucket table, two diverging charts, and a daily list per bond

- Operator instruction 2026-11-02: four layout changes across the three universe
  modes, the retirement of the effective-date table, click-to-scope on the
  bucket rows, click-to-select on any security row, and the fourth spread.
- What changed, display only:
  - **Two diverging charts per screen.** `charts.comparison_spec()` is called
    twice in one-book modes as well: mover counts, then the signed spread sum.
    Both cut to `config.BUCKET_CHART_TOP` (10) with the remainder collapsed into
    one `Others (n)` bar, both put increases right of a shared zero line and
    decreases left, and both publish one symmetric `limit`.
  - **One full bucket table.** `engine.bucket_table()` merges the counts and the
    two spread sums into one row per bucket, in the charts' own bucket order.
    The table is never cut. `Increase Spread` and `Decrease Spread` sit before
    `Net Change`, and `Increase Spread + Decrease Spread = Net Change`.
  - **Daily observations.** `engine.daily_spread_rows()` lists one row per date
    the window request actually returned, with the difference from the previous
    observation. A weekend, a holiday, or a no-quote day has no row and is never
    forward-filled.
  - **Bond mode.** Only the path chart and its daily list remain; the bucket
    charts, the bucket table, and both Top 10 panels are hidden by
    `layout.display = "none"`.
  - **Interactivity.** A click on any bucket row narrows both Top 10 charts and
    their tables to that bucket and a second click clears it; a click on any
    security row or bar selects it for the path chart. Both are local redraws of
    frames already in memory and never build a request.
  - **Effective-date table retired.** The bounded series check still runs and
    still writes to the step log; only the on-screen table is gone.
- **Multi-currency caveat, stated on screen.** A bucket in `LEGATRUU Index`
  spans several currencies, so `Increase Spread` and `Decrease Spread` add
  spread changes that are not currency-neutral. The column names are the
  operator's own words; the note under the table says what the sum is and is
  not. `RAG KB` does not authorise summing across currencies, so nothing in the
  UI calls the sum a total or a bps figure.
- **Label normalisation.** `(blank)` was reachable from the bucket table but not
  from the filter boxes, because three call sites used three different
  sentinels. `filter_choices()` and `apply_dimension_filters()` now use
  `config.DESCRIPTOR_BLANK` on both sides, so a null `classification_name` —
  common for US MBS/TBA in a global aggregate per `RAG KB/08` — is offered as
  `(blank)`, matches when picked, and forms a clickable bucket.
- What did **not** change: no `bql.Request` shape, field list, `with_params`,
  request count, fill direction, or unit conversion.
- Decision: **Resolved for V1** — display and local view only. The Desktop
  rendering of two diverging SVGs and the `ipydatagrid` click callbacks are
  **unverified** until the first run on Desktop.

### DR-24 — Direction is the colour in the two diverging bucket charts

- Operator instruction 2026-11-02: distinguish Increase from Decrease in
  `Movers by <Group by>` and `Spread Change by <Group by>` with two contrasting
  colours, and explain why a bucket-row click does not move the panels below.
- **Defect found.** `charts.comparison_spec()` published a colour per trace, and
  the Plotly path read it, but `preview/svg_charts.comparison()` looked the
  colour up in `CHART_COMPARE_COLORS` again. A one-book run was therefore drawn
  in that book's comparison pair — teal `#2a9d8f` and light teal `#8fd3c9` for
  `Index` — two shades of one hue, so the two sides of the zero line looked the
  same. The preview and the Desktop figure could disagree about what a colour
  meant.
- What changed: `config.CHART_DIRECTION_COLORS` is the single direction pair
  (blue increase, orange decrease); `config.CHART_COMPARE_COLORS` keeps that hue
  meaning and separates the two books by depth (AIM `#0d47a1` / `#e65100`,
  Index `#64b5f6` / `#ffb74d`); `CHART_BOOK_COLORS` is now explicit, because the
  two Top 10 charts encode the book and not the sign. `svg_charts` renders the
  colour the specification published and nothing else.
- **Bucket click.** No defect: `tests/test_preview.py` and a live `POST
  /api/view {"bucket": "Germany"}` both narrow the two Top 10 panels (19 → 2
  movers, 57 → 6 rows) and a second click restores them. The reported symptom
  is the **static** `preview/interface.html`: it ships no script, so no row on
  it can act. The page now says so next to the sample result and names the
  served preview. `_PickTable` additionally resolves a grid click by position
  first and by index label second, so a build that reports the label still
  picks the row instead of silently doing nothing.
- What did **not** change: no `bql.Request`, field, `with_params`, request
  count, or number. Colour and click wiring only.
- Decision: **Resolved for V1.**

### DR-25 — A Display Top box and a Refresh per ranked panel

- Operator instruction 2026-11-02: give `Top 10 increases` and `Top 10
  decreases` each its own **Display Top** box above the chart plus a **Refresh**
  button to its right, default `10`, any number allowed. In `AIM vs Index` the
  number means **Top X rows of each book**, not X rows in total.
- What changed, display only:
  - `config.DISPLAY_TOP_LABEL`, `DEFAULT_DISPLAY_TOP` (= `TOP_N`), and
    `DISPLAY_TOP_MAX` (50) name the control. `charts.change_spec()` takes
    `top_n` for its title only.
  - Two `widgets.IntText` boxes and two `widgets.Button` objects, each drawn in
    an HBox directly above its own chart (`app._display_top_bar`), so the
    control belongs to one panel. `app._display_top` holds the applied count per
    side; `app._display_top_rows()` slices the frame **per book** with
    `head(count)`, because one `head(n)` on the stacked frame dropped the second
    book entirely — the same defect the candidate-ID builder was fixed for.
  - `app._apply_display_top()` validates instead of using a widget bound, which
    would clamp silently: `0`, a negative number, or text is refused with a red
    note and the panel keeps its last applied count. A count above `TOP_N` is
    not an error; the run simply cannot fetch more, so the panel draws what it
    has and says so. A note also explains a short bucket.
  - A new run and a cleared screen call `_reset_display_top()`, so a count
    sized for one run never narrows the next one unannounced.
  - Preview: `StubIntText` renders a number input, and `HtmlRenderer.fields`
    assigns `data-field` **by widget identity**. Before this, every stub button
    was rendered with `data-field="update"`, so a Refresh would have run a full
    Update. The page now posts only the side whose Refresh was clicked.
- What did **not** change: no `bql.Request`, field, `with_params`, request
  count, or `TOP_N`. `Export Excel` still copies the filtered run, not the
  displayed slice, exactly as it ignores a bucket pick.
- Decision: **Resolved for V1** — display only. The `IntText` widget and the
  identity-keyed `data-field` mapping are **unverified on Desktop** until the
  first run there; the preview exercises the same controller code paths.

#### Addendum 2026-11-02 — a reported "Refresh does nothing" was a stale page, and is now detectable

- Reported: change the number, press `Refresh`, and the box goes back to `10`
  with both panels still showing `10`. Reproduced on this Mac, and the cause is
  **not** in `app.py`: the tab was rendered by the code from before the
  identity-keyed `data-field` fix, so its `Refresh` button still carried
  `data-field="update"`. Clicking it ran a full **Update**, and an Update
  deliberately calls `_reset_display_top()` — box back to `10`, charts back to
  `10`, and nothing on screen to explain it. Confirmed by rebuilding the same
  symptom on demand: with the attribute reverted to `update`, the box read `10`
  and the headline returned to `19 mover(s) charted`.
- On the current page the same sequence keeps `3`: the box stays `3`, the
  increase panel draws three bars and `Top 3 increases`, the decrease panel is
  untouched, and the headline reads `12 mover(s) charted · … Display Top 3 per
  book (3 of 10 row(s) drawn)`.
- **Why Desktop cannot show this.** There is no page HTML, no `data-field`, and
  no `/api/view` there. A Desktop `Refresh` is a real `ipywidgets.Button`
  whose `on_click` closure carries its own `side`, so it cannot be confused with
  Update, and the only paths that reset the count are a new Update and a cleared
  screen. A test now fires the registered handler itself, so a missing or
  swapped binding fails locally instead of at the Desktop run.
- **The count still resets on Update by design.** Setting `3` and pressing
  *Update* (not Refresh) will put both boxes back to `10`, because the new
  ranking has different rows. That is the intended behaviour, not this defect.
- **New guard, so a stale page can no longer be silent.** `preview_core.build_id()`
  hashes the content of the nine files a page is rendered from, the page carries
  it in `<meta name="preview-build">`, and `/api/meta` publishes the current one.
  The page compares them at load, on return to the tab, and on a 10-second poll,
  and prepends a red line to the status panel when they differ: reload with
  Cmd+Shift+R before using the controls. Verified by editing `config.py` while a
  page was open: the banner appeared, naming both ids.
- Files touched: `preview/preview_core.py`, `preview/server.py`,
  `tests/test_app.py` (the button-binding test), `tests/test_preview.py` (the
  build-id test), and the regenerated `preview/interface.html`. No `bql.Request`,
  field, `with_params`, row count, or `TOP_N` changed. `pytest` → 319 passed.

### DR-26 — `Asset swap spread` withdrawn; the dropdown returns to OAS / Z / I

- Operator instruction 2026-11-02 (later the same day as `DR-22`): remove
  `Asset swap spread`, because a swap-curve measure makes the Desktop request
  too heavy and would risk the two-minute timeout. **This supersedes `DR-22`**;
  the earlier entry stays as history and is not a live decision.
- What the evidence does and does not say. A run sends **exactly one** spread
  type, so this removal does not shrink a returned frame: the ranking request
  was never four spreads wide. What it removes is the ability to select the
  heaviest measure in the list, whose cost on this account was never measured —
  `DR-22` recorded `ASW` entitlement and sign as unconfirmed. The instruction is
  therefore accepted as risk reduction, and the record does not claim a measured
  timeout was avoided.
- What changed:
  - `config.SPREAD_TYPES` is back to `OAS` / `Z` / `I`. The comment states why,
    and that re-adding `ASW` is a dated decision rather than a typo fix.
  - `data._validated_window()` already resolves a label through
    `SPREAD_TYPES` and then checks the mapped codes, so with the entry gone both
    `"Asset swap spread"` and `"ASW"` now raise `ValueError` instead of being
    sent. No new guard was needed; a test pins the refusal so it cannot regress
    into a silent pass-through.
  - `preview/preview_core._SPREAD_FACTORS` lost its `Asset swap spread` factor.
    It is read through `.get(..., 1.0)`, so no dangling key can raise.
- What did **not** change: the frozen request, the field list, `TOP_N`, the
  ranking/descriptor/series request count, and the three remaining spread codes
  `OAS` / `Z` / `I`. No substitute measure was introduced in place of `ASW`,
  because none was asked for and a near-sounding item would need the `RAG KB/23`
  review.
- The sibling `FI Index Change` project no longer offers `ASW` either; that was
  decided and recorded there, and nothing in this entry reopens it.
- Decision: **Resolved for V1 — the option is withdrawn, and the value is
  refused.** Re-adding it needs a new dated instruction plus the Terminal check
  `DR-22` already described.

### DR-27 — Three duration measures as reference columns, and five defects closed

- Operator instruction 2026-11-02: the FI Index Change build just ran on Desktop
  and raised several problems (a run-time ceiling, the correct duration
  reference, and smaller issues). Two things were asked of this app: check
  whether it has the same faults, and add several duration measures to every
  output table as extra reference data in the shape that project now uses.
- **The run-time ceiling is structurally absent here, and that is stated, not
  assumed.** FI Index Change hit `BQLTimeoutError` because one `Request` carried
  22 analytics. This app has never sent a wide request: every `bq.execute` goes
  through `data._request_frame`, which builds a dict of exactly one entry, so a
  one-book Update is ten one-item requests and the comparison is twelve. The
  residual timeout risk is universe breadth (a whole index, a whole AIM book),
  which `DR-11` already records as unmeasured; it is not request width. The
  duration family below is the one place where a request carries more than one
  item, and it is bounded to the ranked candidate IDs.
- **What was added.** `config.DURATION_FIELDS` carries four measures from one
  builder: `Duration` (bare `duration()`), `Modified Duration`
  (`duration_type="MODIFIED"`), `Effective Duration` (`"EFFECTIVE"`) and `OASD`
  (`"SPREAD"`), fetched by `data._fetch_duration_family()` as **one** Request on
  the same bounded candidate universe the descriptors use. Evidence is
  `RAG KB/28` and `RAG KB/08`: those three value strings come from
  operator-supplied FLDS BQL tab text dated 2026-11-02, and the calls completed
  inside a live Request on `LEGATRUU Index`. `22` has one `duration()` row and no
  `modified_duration()` / `effective_duration()` item, so this is a parameter
  value on a builder this app already calls, not a new data item and not a new
  product family. `RAG KB/23`'s "parameter form instead of a same-named item"
  rule is what this follows.
- **The extra columns cost zero requests, and that took a second pass to get
  right.** The first implementation left `Duration` in `DESCRIPTOR_FIELDS` and
  added a separate three-item family, which took a one-book Update from 10
  requests to 11 and the comparison from 12 to 13. `RAG KB/23` says appending a
  measure buys a slot and merging into an existing request buys nothing, so the
  correct shape was to move `Duration` out of the descriptor list and into the
  family, making the family **replace** the request `Duration` already owned.
  Counted against the test fake, one book is **10** `bq.execute` calls and
  `AIM vs Index` is **12** — identical to before the extra measures existed —
  and the live page reports `Requests: 10`. Four measures now ride in the request
  that used to return one.
- **Why one grouped request, and why it is free.** Every
  `config.DESCRIPTOR_FIELDS` entry is its own one-item Request, and `Duration`
  was one of them. Adding three more descriptors would have cost three more
  `bq.execute` calls. Instead `Duration` moved into a single measure-family
  Request that now carries all four items, so the family **replaced** the request
  that already existed. The Update spends exactly what it spent before the extra
  measures were asked for: **10** requests for one book, **12** for `AIM vs
  Index`. Both figures are in `RAG KB/29`, the README, `instruction.md` and the
  project rule. This is `RAG KB/23`'s costing rule read correctly — appending a
  measure buys a slot, merging into an existing request buys nothing.
- **Display only, and fail-visible.** No filter, chart, ranking or bucket reads
  the four columns. A failed family leaves the ranked rows intact, leaves the
  columns absent rather than zero-filled, and names itself in the step log and
  the receipt. A rejected `duration_type` drops that one item and keeps the other
  three, because they share a request.
- **Two silent-failure guards.** A duration family whose column arrives with
  every value null is recorded as `FAILED: all values null` when more than one
  row came back; a single row (the Bond path) is noted without failing the run,
  because one security with no duration is a per-bond gap and not a broken
  field. And because one builder carrying several parameter values can ignore
  the parameter, `_note_duplicate_duration()` compares the parsed columns and
  names any pair that is identical on every row carrying both — the failure mode
  `28` records.
- **Not claimed.** The run completing proves the calls exist, not their
  semantics. Which measure the bare `duration()` returns, and whether `'SPREAD'`
  shifts the OAS curve or the benchmark curve, are open and are settled by
  comparing columns on one Desktop batch. If `duration()` is already Modified
  then `Duration` and `Modified Duration` are one number under two names, and
  the extra column has bought nothing.
- **Five defects closed in the same pass** (found by a read-only audit of this
  app against the FI Index Change findings):
  - **A-1, high — a run where every descriptor failed reported a green
    `Updated`.** Descriptor failures do not append to `FetchResult.errors`, so
    the status word never saw them while the screen showed seven
    `(unavailable)` columns. `app._failed_field_labels()` now feeds the status
    word: any failed field makes it `Incomplete` and the reason is written on
    the status bar, not only in the step log.
  - **A-2, medium — a failed Rating request was reported as an unrated bond.**
    `(unavailable)` was collapsed into `NR/Missing` by `rating_bucket()`, and an
    absent Rating column stamped every row `NR/Missing`. Both are now
    `(unavailable)`. A genuine blank is still `NR/Missing`; the two stay
    distinguishable, which is the same rule `(blank)` versus `(unavailable)`
    already followed everywhere else.
  - **A-3, medium — a refusal left the selected bond on screen.** `_reset_view()`
    cleared the frames, headline and export but not `detail_title` /
    `detail_view`, so the previous run's row and spread numbers stayed rendered
    under a red bar. `_reset_detail_panel()` now returns the panel to its
    prompt.
  - **A-5, low — an all-null descriptor column read as a success.** The receipt
    said `returned N row(s), 0 non-null` and emitted no note, so `(blank)` on
    every row could not be told apart from a working field with genuinely empty
    values.
  - **A-7, low — a filter pick survived a refusal.** `_reset_filter_picks()`
    returns the five boxes to `(All)` and empties their options, so
    `_current_filters()` cannot report a value applied to an empty table.
  - Also closed: `data._validate_candidates()` accepted a `source_key` argument
    and never read it (A-4). The parameter and its two call sites are gone; the
    docstring now says why no per-source parameter exists, so a future guard
    cannot be wired to a name that does nothing.
  - The export cache key used `id(frame)` (A-6). CPython reuses addresses, so a
    new filtered view could in principle collide with a retired one and be
    skipped. The key is now a per-run token plus the row counts and the filter
    signature. No stale view was reproducible on the current path, so this is a
    latent-hazard fix rather than a bug the operator hit.
- **AIM assigned benchmark: asked for conditionally, and declined.** The
  operator asked whether the knowledge base supports reading an AIM account's
  assigned benchmark so `AIM vs Index` could prefill the Index box. It does not.
  A corpus-wide search for `benchmark` / `assigned` / `bmark` / `bench` / `BMK`
  finds no AIM accessor, and the one official AIM tutorial in the corpus
  contains zero occurrences of those words. The closest candidates are each a
  different identity: `fund_benchmark_prim()` is a fund/ETF security field,
  `port_info()` is a PORT PREP report row keyed on a required `report_name`,
  `benchmark_for_pricing()` is the reference bond a security prices against, and
  `reference_benchmark_most_recent()` is a bare catalog row with no description,
  no signature and no call site. Per `RAG KB/23` § 4 this stops before
  implementation: what is needed is FLDS BQL tab text naming the accessor, its
  argument names, and its universe, plus a dated Desktop run showing a non-null
  value for a real account code. A prefill would also contradict the current UI
  freeze that both fields start empty. **Not implemented.**
- **One documentation defect found in the sibling project's card, not fixed
  here.** `RAG KB/28` contradicts itself on `SPLIT_REQUESTS`: three passages say
  `True`, one stale paragraph says it "stays `False`" and describes a two-way
  split while forbidding the three-way split the shipped code uses. The code
  (`fi_index_change/config.py`) says `True`. That paragraph needs a correction in
  the next pass that touches `28`.
- Files touched: `fi_spread_movement/{config,data,engine,app}.py`,
  `preview/preview_core.py`, the regenerated `preview/interface.html`,
  `tests/{test_data,test_app,test_view}.py`, `README.md`,
  `RAG KB/29-fi-spread-movement-monitoring.md`, this record, and the `Upload`
  mirror.
- Verified locally, not on Desktop, at 15:38: `python3 -m pytest -q` → **342
  passed** (320 before these two passes), `sync_upload.py --check` in sync,
  `preview/build_preview.py --check` in sync, `.qoder/sync_rules.py --check` →
  `rule-sync=ok`. Request counts were counted against the test fake rather than
  read off the page's own log: one book **10** `bq.execute` calls, `AIM vs Index`
  **12**, with the duration family as the only multi-item request (4 items) and
  every other request one item. Live page at port 8775: Update reports
  `Requests: 10` and returns
  `Updated OAS · index LEGATRUU Index · 2026-10-26 → 2026-11-02`, and both ranked
  table headers read `ID, Name, Country, Sector, Rating, Currency, Maturity,
  Duration, Modified Duration, Effective Duration, OASD, Change`. The Export tab
  carries the same column order. No BQL executed.
- **Still unverified:** whether the ten requests finish inside the two-minute
  limit on Desktop, whether `'SPREAD'` and the bare `duration()` differ on this
  index, and whether `ipydatagrid` renders the longer table without horizontal
  scrolling problems. The request log records per-request elapsed time, so the
  first Desktop run answers the first of these.

### DR-28 — Timeout protection: a result cache, a bounded retry, and a cached fallback

- Operator instruction 2026-11-02: the only remaining worry is data-extraction
  time. Introduce the same three protections the sibling project uses — a cache,
  computation splitting, and an automatic second attempt from cached data when a
  run times out — so the operator does not meet a timeout error. The error must
  still be reported; these are preventive measures on top of it.
- **Splitting was already in place and was not re-litigated.** Every
  `bq.execute` here has always carried one item (the duration family carries
  four), so a one-book Update is 10 requests and the comparison is 12. There is no
  wide request to split. What was missing was the other two: a cache and a retry.
- **The retry (`data._execute_attempts`, `QUERY_ATTEMPTS = 2`).** A timed-out
  request is re-sent identical, rebuilt per attempt so no state from the failed
  execute is reused. Only a timeout is retried: `is_timeout()` checks the
  deterministic markers first (`no bql data item`, `not entitled`, `invalid
  ticker`, `license`, …) because the sibling project once classified
  `No BQL data item named 'timeout_field'` as a timeout and paid a second
  two-minute wait for something that could never succeed. The attempt count is
  written into every request-log entry, so a retry that answered is visible as
  its own fact rather than looking like a slow single answer.
- **The cache (`cache.py`, `CACHE_KEEP_RUNS = 12`).** One CSV per table (ranked,
  descriptors, series) plus a JSON manifest. The key is
  `run_key(source, universe, aim, spread, start, end, TOP_N)` hashed with a
  readable prefix, so a cached run can only be served to the exact question that
  produced it; a changed window or spread is a different file. A
  `CACHE_GENERATION` token invalidates every entry when a stored result would be
  wrong under new code — the sibling project shipped a poisoned month by leaving
  that token out. An empty run is refused, and so is a run with a failed field,
  because replaying it would present `Incomplete` as a clean cached answer.
- **The fallback (`app._load_from_cache`).** Fires only when the failure was a
  timeout **and** a clean run exists for the same key. Status word `Cached` in
  amber, never `Updated`; the detail box states the reason and the live error
  stays on screen; the step log names the cache generation and the files. A
  deterministic failure never falls back, and a mixed set (one timeout plus one
  rejected item) is treated as deterministic, because showing old numbers for a
  broken field would hide the real problem. `Load saved` is the manual door to
  the same cache.
- **Nothing is relabelled.** The inputs that produced a run are captured before
  the request (`FetchResult.cache_request`) and stored in the manifest, and a
  cached screen is captioned from those, never from the live widgets. Without
  that, editing a date while a request was running would caption one window's
  numbers with another window's dates.
- **A cache failure never fails a run.** `_save_to_cache` wraps the write and the
  prune together and only logs, so a read-only Desktop project folder or a full
  disk cannot turn a good Update into a failed one. Reading never creates the
  folder for the same reason.
- **Six defects found by the pre-deployment review and fixed in this pass:**
  `README` copy list omitted `cache.py` (would fail cell 1 with
  `ModuleNotFoundError`); `prune` deleted by key order because the manifest is
  written sorted, so it could remove the run it had just saved; the fallback
  fired on a mixed failure; a partial run was cached; `_parse_response` raised
  `MergeError` on a duplicated first item, abandoning the whole Update after the
  ranking had succeeded; and the cached screen was labelled from live widgets.
  Each has a regression test.
- **`Upload/` audited.** Eight files: `MAIN.ipynb.txt` plus the seven modules,
  byte-identical, no orphans, and `sync_upload.py` now prunes `.DS_Store` and
  `__pycache__` so a folder copy cannot ship macOS metadata.
- Decision: **Guarded** — the retry and the cache are exercised locally against a
  fake `bql`; the timings and the real Desktop cache behaviour are measured on
  the first Desktop run.

### DR-29 — Two Desktop failures diagnosed: an Arrow item that had no name, and a grid that owned the row index

- Operator report 2026-11-02, from two real Desktop runs on `LEGATRUU Index`,
  OAS. **Run A** completed all ten requests in 61.92 s and then failed with
  `KeyError: "None of [Int64Index([-1, -1, … 24 times], dtype='int64')] are in
  the [index]"`. **Run B**, on a seven-day window ending today, spent two
  requests and both ranking requests failed with `ValueError: BQL response has
  no item named 'Spread Change' (response type: ArrowExecuteResponse)`.
- **What the two messages prove, and what they do not.** They are not the same
  bug and they are not both about Bloomberg:
  - Run B's two requests both *answered*: an `ArrowExecuteResponse` exists only
    when `bq.execute` returned. There is no timeout text, no "not entitled", no
    rejected field. The failure is in this app's lookup, not in the request.
  - Run A's ten requests all answered and were logged *before* the exception, so
    the failure happened after the data arrived, in the local reshape or render
    step. A `-1`-filled integer index is the signature of an indexer that
    matched nothing (`get_indexer`'s "not found"), i.e. rows were looked up
    against labels that were not there — not a refused query.
- **Root cause of Run B.** `_response_item()` accepted only `.get(name)` and an
  item whose `.name` equals the request's dictionary key. `RAG KB/07` records
  that Desktop's `ArrowExecuteResponse` may expose neither, and names
  `bql.combined_df(response)` as the documented last resort. So a response that
  arrived with data was thrown away as "no item named …". That also made an
  empty answer indistinguishable from a naming mismatch: both printed the same
  sentence. Fixed in `data._item_frame()`:
  - lookup order is now `.get(name)` → index access with a name match → a single
    item response → `bql.combined_df(response)`;
  - the combined frame is used only when it carries exactly one value column;
    two or more are refused, because choosing one would label a measure with
    another measure's numbers;
  - the failure message now prints the response type, the item count, and the
    names that *did* arrive, so the next occurrence is diagnosable in one line;
  - a direction that answers with no rows is reported as `0 row(s)` with a note
    instead of a column error (`_rank_movers`, `_change_frame`).
- **Root cause path for Run A.** This app set a *custom row index* on the frame
  handed to `ipydatagrid` (`shown.index = pd.Index(keys, name=key_column)`), and
  the bucket table repeats one bucket per book in a two-book run, so that index
  could be non-unique. No consumer needed it: `_pick_row_key()` resolves a click
  by row position and the keys already live in `labels`. The grid now receives a
  plain `RangeIndex`, so no third-party code aligns rows against a label index
  this app invented. The `-1` index had length 24 in Run A, which is a plausible
  bucket-table row count (buckets × books), but that match is *consistent*, not
  proven; the entry does not claim the mechanism is confirmed.
- **What was hardened regardless of the mechanism**, because a lost run is the
  real damage:
  - every Update failure now names its local stage (`Requesting the data` /
    `Preparing the ranked tables` / `Drawing the figures`), so a reshape error
    can never again read like a refused query;
  - the change-arithmetic check and the label consistency check are diagnostics
    and now fail as a note (detail box / step log) instead of ending the Update —
    Run A's ten paid-for requests would have reached the screen;
  - a `DataGrid` that refuses the frame falls back to the same HTML table with
    the reason printed, costing the click instead of the run.
- Files touched: `fi_spread_movement/data.py`, `fi_spread_movement/app.py`,
  `README.md`, `tests/test_data.py`, `tests/test_app.py`, and the regenerated
  `Upload/` mirror. No `bql.Request`, data item, `with_params`, date rule,
  `TOP_N`, or request count changed. `pytest` → 381 passed.
- Decision: **Resolved for the Arrow lookup; guarded for the row index.** The
  next Desktop run either passes or prints a stage, which pins the remaining
  line without another guess.

## Second Desktop run: the stage named `prepare`, and today's end date

- Evidence supplied: two runs of the same pasted build.
  - `2026-10-26 -> 2026-11-02`, `OAS`, `LEGATRUU Index`: **2 requests, 51.58 s**,
    both directions failed with `ValueError: BQL response has no item named
    'Spread Change' (response type: ArrowExecuteResponse, 0 item(s) exposed,
    names=not exposed)`; no descriptor or series request was sent.
  - `2026-10-26 -> 2026-10-30`: **10 requests, 58.21 s**, then
    `Preparing the ranked tables failed - KeyError: "None of [Int64Index([-1,
    -1, ... (12)])] are in the [index]"`.
- **What the Arrow message settles.** `0 item(s) exposed` is now printed by this
  app's own diagnostic, and it means `len(response) == 0` on a response object
  whose type name contains `response`: the response itself states it holds no
  item. `bql.combined_df` then had nothing to combine either. The previous build
  still raised `ValueError` on that path, so an **empty answer** was reported in
  the language of a **misspelt data item**. Decided:
  - `0` items is an empty answer: `_item_frame` raises `EmptyResponseError`,
    `_request_frame` records `0 row(s)` with the reason and the run continues.
    Nothing is invented, and no fallback field is used.
  - a response whose item count cannot be read at all keeps the `ValueError`
    (`names=not exposed`), because "unreadable" is not evidence of "empty".
    Turning one into a zero-row table would be a silent wrong answer.
  - when both directions come back empty and the typed end date is today or
    later, `_note_empty_universe` says so and names the next step: index
    membership keyed on an unpublished date. That is the likely cause here —
    Run A ends on the current day, Run B on the last completed Friday — and it
    is stated as the likely cause, not as a proven one.
- **The `KeyError` and what was actually changed.** The stage label proves the
  fault is local to `prepare_ranked_movers()`: the ten requests had answered.
  `-1` is the value `get_indexer` returns for "not found", so the array reached
  `.loc` as *labels*, not as a mask. In that path the only row-label *write* was
  the descriptor assignment `merged.loc[not_described, column] = ...`; it is now
  a **positional** `numpy` assignment, and every mask in `_prepare_side` is cast
  to a positional `bool` array, so no label indexer is built at all.
  - This is a class fix, not a proven line: the local suite runs **pandas
    3.0.5** while the Desktop build is **pandas 1.x** (evidence: the error text
    prints `Int64Index`, which pandas 2.0 removed), so a green local run cannot
    reproduce that build's `.loc` behaviour. The `-1` length (12) matches the
    ranked rows of that run, and that match is *consistent*, not proven.
  - Because a wrong guess has already cost two cycles, the fault is now
    **contained** instead of only explained: `_prepare_side_safely` and
    `_merge_descriptors_safely` keep the other direction and the `ID`/`Change`
    rows when one side or the descriptor join fails, and name the failure in the
    notes. Display columns are decoration; losing them must not cost ten paid
    requests.
  - The banner now appends `[file.py:line in function()]` from the innermost
    traceback frame (`_exception_site`), so any remaining reshape fault names
    its own statement on the first run.
- Files touched: `fi_spread_movement/data.py`, `fi_spread_movement/engine.py`,
  `fi_spread_movement/app.py`, `tests/test_data.py`, `tests/test_engine.py`,
  `DECISION_RECORD.md`, and the regenerated `Upload/` mirror and `preview/`.
  No `bql.Request`, data item, `with_params`, date rule, `TOP_N`, field list, or
  request count changed. `pytest` → 387 passed.
- Decision: **empty response resolved with evidence; the `prepare` `KeyError`
  contained and instrumented, not yet proven to its statement.** The next
  Desktop run either passes, or its banner names the exact line.

## Third Desktop run: the index path works, and the two other universes do not

- Evidence supplied 2026-11-02, three runs of the same build. **The index path is
  now proven end to end**: `2026-10-26 -> 2026-10-30`, `OAS`, `LEGATRUU Index`
  returned ranked rows and drew the screen. Everything below is about what that
  first success exposed.

### The bucket table had no bucket names — a display defect, not a data one

- Reported: with `Group by = Country` the bucket table "showed numbers but no
  country names", and because the names were missing the row could not be
  clicked, so the bucket could not be carried into the two Top 10 charts.
- Cause, in `app._PickTable._block_widgets`: the column named by `key_column`
  was **dropped from the grid** (`shown = view.drop(columns=[key_column])`). For
  the ranked tables the key is `ID`, which is also a displayed identifier, so
  dropping it was invisible. The bucket table's key is `Bucket` — the country
  name itself — so the grid received `Increases`, `Decreases`, both spread sums
  and `Net Change` with no label column at all. The engine was never at fault:
  `engine.bucket_table()` returns `Bucket` as its first column, verified locally
  on a two-frame fixture.
- Fixed by keeping every column and using `key_column` only to build the click
  labels. The click still resolves by row position, so nothing depends on the
  column being hidden. Pinned by two tests: the rendered block contains
  `Bucket` with the real names, and the grid receives the column.
- The chart specs were checked in the same pass: `comparison_spec` carries
  `labels`/`row_labels` and the HTML fallback prints the bucket name in its first
  column, so the charts were not affected. A test now pins both.

### Column widths: the grid's narrow default, not a broken table

- Reported: columns did not auto-fit. `ipydatagrid` assigns one narrow default to
  every column, so `Decrease Spread` truncated while numeric columns wasted the
  same width.
- Fixed with the two documented sizing arguments from `RAG KB/09`:
  `column_widths` (pixels per column) and `base_column_size`. The dictionary is
  computed by `app._grid_column_widths()` from the text the grid will draw — a
  numeric column is measured at four decimals plus a sign rather than at full
  binary precision — clamped to 70–260 px. A build that does not accept the
  arguments still draws the grid (the call is retried without them), so a sizing
  preference can never cost the table.

### `AIM account`: BQL refused the filter expression, and the app blamed the book

- Evidence: `2026-10-26 -> 2026-10-30`, `OAS`, `AIM account SAMPLEAIM`, **2
  requests, 4.24 s**. Both directions returned
  `ResponseError: [BQLInternalExecutionError] ... Error encountered while
  processing FILTER(MEMBERS(type='AIM'),(NET_CHG(SPREAD(dates=RANGE(...),
  spread_type='OAS'))>0)) clause. Predicate must be a Boolean expression.`
- **This is a query-shape refusal, not an empty book.** The message names the
  `FILTER` clause and says the predicate was not Boolean, so BQL rejected the
  expression *before* evaluating any holding. Nothing in that run describes what
  the account holds.
- The app's wording was wrong and is now impossible: `_note_empty_universe()` used
  to say "AIM account … returned no ranked holding" for any empty result. Errors
  now win first — a failed run says it was **not ranked because the request
  failed** and that nothing is evidence about the book. `_explain_ranking_error()`
  adds the reading in place: the filter was refused on the account universe and
  this is a `RAG KB 23` `G4` (universe-compatibility) finding, not a data-item
  spelling and not a holdings fact.
- **Left unfixed on purpose.** The knowledge base has no evidence for a filtered
  ranking on a `members(type="AIM")` universe: `29` freezes the account block on
  `with_params` and its ranking section documents the filter form only on
  `members(index, dates=…)`. Writing an alternative shape — `matches()` instead of
  `filter()`, a pre-resolved `bq.univ.list` of the book, or a two-step fetch that
  ranks in pandas — is a new request shape nobody has proven on Desktop, and the
  hard rules forbid substituting one. The honest state is: **the AIM path is
  blocked on BQL support for the filter, and one dated HelpDesk confirmation (or a
  proven composition from an official card) is what unblocks it.**

### `Bond`: a completed request with no row, and the right advice was missing

- Evidence: `2026-10-26 -> 2026-10-30`, `OAS`, `AAPL 4 % 05/12/35 Corp`, **2
  requests, 0.90 s**, both directions an empty `ArrowExecuteResponse` with no
  error. The request ran; it matched nothing.
- Two causes fit that evidence and the screen could not tell them apart: a ticker
  that does not resolve in a private one-security universe, and a bond that simply
  had no change in that window. The note said "widen the window or check the
  universe for the end date", which is index-shaped advice and unhelpful for one
  security.
- Fixed: `_note_empty_universe()` now has a `bond` branch that says to confirm the
  ticker on Terminal first and to try the last completed business day before
  changing it. **Not resolved**: whether that ticker is valid. That needs one
  Terminal check, and it is recorded in `ToDoList` row 37 rather than guessed.
- Note for the record: the ticker arrived as `AAPL 4 % 05/12/35 Corp`, which
  reads like a Bloomberg corporate-ticker description rather than a security
  identifier. No code change was made for that, because the field accepts any
  single ticker and refusing a shape the operator has not confirmed as wrong
  would be inventing a rule.

- Files touched: `fi_spread_movement/app.py`, `fi_spread_movement/data.py`,
  `tests/test_app.py`, `tests/test_data.py`, `DECISION_RECORD.md`, and the
  regenerated `Upload/` mirror and `preview/interface.html`. **No `bql.Request`,
  data item, `with_params`, date rule, `TOP_N`, field list, or request count
  changed.** `pytest` → 398 passed (was 387). Eleven new cases: two pin the bucket
  column and its chart labels, three pin the column-width estimate (fitted
  numeric precision, and no raise on an unreadable column), three pin the
  empty-versus-failed wording on all three universe sources, and three pin the
  ranking-error classification.
- Decision: **the index path and the three display defects are resolved with
  evidence. `AIM account` is blocked on a BQL filter support question and is
  recorded as unresolved, not patched. `Bond` now gives correct advice; whether
  the ticker resolves needs one Terminal check.**

## Fourth Desktop run: the tables were right and three charts were blank

- Operator report 2026-11-02, `Universe = Index`, `OAS`, `2026-10-26 -> 2026-10-30`:
  the ranked tables and the two Top 10 charts drew correctly, and **both bucket
  charts and the bond path chart came back blank** while the tables under them
  carried every number. The second message narrowed it further: *“only the
  charts are blank, but related tables are with data.”*
- **That split is the whole diagnosis.** The tables are ordinary widget output
  built from the frames; the charts are `plotly` `FigureWidget`s. Two of the four
  figures drew and two did not, and the difference between them was not the data
  (all four read the same frames) and not the spec (all four carried their
  points): it was **how the figure was updated**.
  - `apply_change()` — the two Top 10 charts — assigned
    `figure.data[0].x` / `.y` / `.text`, mutating a trace that already existed.
  - `apply_comparison()` and `apply_paths()` — the bucket charts and the path
    chart — rebuilt the trace list and assigned `figure.data = series`.
- **Why the rebuild is invisible in a notebook and blank on Desktop.** A
  `FigureWidget` is a live front-end view. Replacing its whole `data` tuple is a
  valid construction call, and at build time the figure is not yet displayed, so
  nothing is lost. Once the figure sits inside an `ipywidgets` container on a
  Desktop page and a later Update replaces `data`, the front end kept drawing the
  figure it had already been handed. `RAG KB/09` documents the in-place form
  (`fig.data[0].x = …` inside `batch_update()`) and contains no example that
  reassigns `data` on a displayed figure; that absence was the hint, and the two
  working charts were the control.
- **A second, independent defect on the same two cards.** `app._chart_slot()`
  built a **new `HBox` around the same figure** on every render, and
  `bucket_box.children` / `path_box.children` were reassigned with those new
  containers each time. Re-parenting a displayed widget is its own way to get an
  empty card, and it applied to exactly the same two charts, because the two Top
  10 slots are created once in `_render_chart_shell()` and only ever mutated.
- Fixed, in both places, because either one alone reproduces the report:
  - `charts.apply_comparison()` and `charts.apply_paths()` now `add_traces()` what
    is missing and then mutate each trace's `x`/`y`/`name`/`marker`/`hovertemplate`.
    Traces beyond the current spec are **emptied** rather than deleted, so a book
    that returned nothing this run cannot leave yesterday's bar under today's
    title.
  - `app._bucket_slots()` creates the two bucket slots once and returns the same
    objects afterwards; `_render_bucket_panel()` updates the figures and only
    reassigns `bucket_box.children` when a child is genuinely different. The path
    chart follows the same rule through `_path_chart_slot` and `_slot_reuse()`.
  - `_render_bucket_panel()` also refuses an empty `books` tuple: `comparison_spec`
    builds one trace per book, so an empty tuple is a chart with no traces at all,
    not a blank chart with axes.
- **What this does not prove.** The report is from Desktop; these tests run on a
  Mac with stand-in figures, so the mechanism above is the strongest reading of
  the evidence, not a reproduction of the Desktop rendering. What the tests do
  establish is the invariant that was violated: the trace objects a figure was
  built with must survive an update, and a displayed figure must not be
  re-parented. Both are now asserted, and both assertions fail against the old
  code — checked by reverting each fix locally and watching the new cases go red.
- Files touched: `fi_spread_movement/charts.py`, `fi_spread_movement/app.py`,
  `tests/test_charts.py` (new, eight cases with fake `plotly` figures),
  `tests/test_app.py` (two cases: the spec carries drawable traces and a book
  label, and a re-render keeps the same slot objects), and the regenerated
  `Upload/` mirror and `preview/interface.html`. **No `bql.Request`, data item,
  `with_params`, date rule, `TOP_N`, field list, or request count changed.**
  `pytest` → 408 passed (was 398).
- **`Upload/fi_spread_movement/charts.py.txt` must be re-copied for this fix.**
  `charts.py` is the fifth of the seven runtime modules; a Desktop that receives
  only `app.py` keeps the old update path and the cards stay blank.
- Decision: **resolved by mechanism, with the invariant pinned.** If a card is
  still blank after `charts.py` is re-pasted and the kernel restarted, the next
  measurement is whether `plotly` on that build reports the trace objects
  surviving the batch — that would put the fault in this fix rather than in the
  original code, and it would be recorded here rather than patched again blind.

## Fifth Desktop run: Index and Bond work, AIM does not; start and end spread requested

- Operator report 2026-11-02, after the fourth-run fix. `Universe = Index` and
  `Universe = Bond` both complete and the tables, Top 10 charts, bucket charts,
  and path chart all draw. `Universe = AIM account` still fails inside
  `FILTER(MEMBERS(type='AIM'), …)` with
  `BQLInternalExecutionError - Predicate must be a Boolean expression`, which is
  a universe-compatibility fault rather than an empty holding list; it is
  unchanged by this pass and stays recorded as open in the AIM entry below.
- Operator request, same message: show **Start OAS** and **End OAS** in the
  tables instead of only the change, and **name the spread type in the
  headings** so a table cannot be read back as the wrong spread.
- **Where the two levels come from.** Not a new data item and not a new request.
  The bounded `spread(..., dates=range(start, end))` series already sent for the
  change check contains every observation the ranking was measured on, so its
  first and last rows per ID *are* the two endpoints:
  - `engine.spread_levels()` groups that frame to one row per ID with the first
    and last usable `Spread` value (blank ID, bad date, non-numeric value
    dropped; duplicate `(ID, DATE)` keeps the first, the same rule the check
    uses so start/end and change can never be read off two different series);
  - `engine.attach_spread_levels()` left-joins them onto each ranked side and
    places both columns immediately before `Change`, so a row reads start → end
    → change. A ranked ID with no series row keeps **NaN**, never a zero, never
    a neighbouring observation, and the ranked change is left exactly as
    Bloomberg returned it.
  - This runs in `app._render()`, so a **cached** screen gets the same two
    columns from its saved series without a request.
- **Why the headings are renamed only at the edge.** The frames behind the
  charts, the click handlers, the filters, and the ranking use `Change`,
  `Start Spread`, `End Spread`, and the bucket names `Increase Spread` /
  `Decrease Spread` / `Net Change`. `app._spread_headers()` renames a **copy** at
  the moment a table is drawn, copied to Excel, or written into the selected
  security panel, and the new headings carry the run's own label:
  `Start OAS` / `End OAS` / `OAS Change`, `Increase OAS` / `Decrease OAS` /
  `Net OAS Change`, and `OAS` for the daily observation column. Renaming the
  frame itself would have made a label into a data contract that the next reader
  of `charts.change_spec()` or the export has to know about.
- **Scope.** Three choices remain OAS / Z / I (`DR-26`); the heading follows the
  loaded run, not the current dropdown, so a stale screen cannot relabel the
  numbers of the previous spread type.
- **Not changed.** No `bql.Request`, data item, `with_params`, date rule,
  universe, `TOP_N`, or request count. A one-book run and a comparison both get
  the two columns; the export header row, the request detail, and the step log
  keep their existing shape.
- Files touched: `fi_spread_movement/engine.py`, `fi_spread_movement/app.py`,
  `README.md`, `tests/test_engine.py` (new `SpreadLevelTests`, eight cases),
  `tests/test_app.py` (four cases: headings, the Z label, the export headings,
  the blank level for an uncovered ID), and the regenerated `Upload/` mirror and
  `preview/interface.html`. `pytest` → 423 passed (was 408).
- **`Upload/fi_spread_movement/engine.py.txt` and `app.py.txt` must both be
  re-copied for this change.** `engine.py` supplies the two new columns and
  `app.py` draws the headings; a Desktop that receives only one of them either
  loses the columns or shows them under the old names.
- Decision: **approved, with the missing-level rule as fail-blank.** If a
  Desktop run shows an empty `Start OAS` / `End OAS` pair for a ranked bond,
  that bond had no usable observation in the series window; the cell must stay
  blank rather than be filled from a later run or an assumed value.

## Sign-off after the first Desktop run

- Date/operator:
- Universe source (Index / AIM account / AIM vs Index / Bond) and value(s):
- Spread type(s) used:
- Request log (count, per-request elapsed, rows, columns):
- Units observed in Terminal (OAS / Z / I / change):
- Effective-date check result (all match / mismatches):
- Coverage notes (multi-currency, nulls, short lists):
- AIM-only: account resolved? holding count returned? how many holdings had no
  spread? any cash/equity lines ranked?
- AIM vs Index only: did the AIM side return rows? how many per book? any bond
  in both books? did the comparison table match the two ranked tables?
- Bond only: did the single ticker resolve? one ranked row, or none, and why?
- Decision: widen window? add fill? change universe? proceed to production? requires:
