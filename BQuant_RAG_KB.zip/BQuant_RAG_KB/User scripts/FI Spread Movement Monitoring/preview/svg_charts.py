"""Inline-SVG renderer for the chart specifications in ``fi_spread_movement.charts``.

The local preview cannot import Plotly, so it draws the same specification as
SVG. Nothing is recomputed here: the spec already carries every label and
value, which is what keeps the preview and the Desktop figure honest about the
same numbers.

The output is deliberately plain: no JavaScript, no external asset, and
``viewBox`` scaling so the chart fits the page width.
"""

from __future__ import annotations

from html import escape

from fi_spread_movement import config

# The same fixed width as the Desktop figure, so a chart is never redrawn at a
# different aspect ratio between the preview and the notebook.
WIDTH = config.CHART_WIDTH_PX
FALLBACK_COLORS = (config.CHART_INCREASE_COLOR, config.CHART_DECREASE_COLOR)

# Same palette as ``fi_spread_movement.charts``: light text and muted axis
# labels on the dark chart card, dark grid lines.
GRID = config.CHART_GRID_COLOR
ZERO = config.CHART_ZERO_COLOR
TEXT = config.CHART_FONT_COLOR
MUTED = config.CHART_MUTED_COLOR
CARD = config.CHART_BACKGROUND_COLOR


def _empty(message: str) -> str:
    return (
        f"<div class='preview-chart' style='width:{WIDTH}px;max-width:100%'>"
        f"<p style='color:{MUTED};margin:10px 0'>{escape(message)}</p></div>"
    )


def _number(value: float) -> str:
    """Axis labels stay short; four decimals are noise on a tick."""
    if value == int(value):
        return str(int(value))
    return f"{value:.2f}"


def _nice_max(value: float) -> float:
    """Round an axis maximum up to a readable step so ticks are not 0.0371."""
    if value <= 0:
        return 1.0
    magnitude = 10 ** (len(str(int(value))) - 1) if value >= 1 else 10 ** -1
    for factor in (1, 2, 2.5, 5, 10):
        candidate = magnitude * factor
        if candidate >= value:
            return float(candidate)
    return float(value)


def buckets(spec: dict) -> str:
    """Grouped horizontal bars: increases right, decreases beside them."""
    labels = spec.get("labels") or []
    if spec.get("empty") or not labels:
        return _empty("No bucket to chart: no ranked mover passed the filters.")

    increases = spec.get("increases") or []
    decreases = spec.get("decreases") or []
    most = max([*(increases or [0]), *(decreases or [0]), 1])
    peak = _nice_max(float(most))

    row_height = 30
    top = 52
    bottom = 44
    left = 150
    right = 24
    plot = WIDTH - left - right
    height = top + row_height * len(labels) + bottom

    parts = [
        f"<svg class='preview-chart-svg' viewBox='0 0 {WIDTH} {height}' "
        f"xmlns='http://www.w3.org/2000/svg' role='img' "
        f"aria-label=\"{escape(spec.get('title', 'Movers by bucket'))}\">",
        f"<text x='{left}' y='22' font-size='13' font-weight='600' "
        f"fill='{TEXT}'>{escape(spec.get('title', ''))}</text>",
    ]

    # Grid and the value axis, drawn behind the bars.
    steps = 4
    for step in range(steps + 1):
        value = peak * step / steps
        x = left + plot * step / steps
        parts.append(
            f"<line x1='{x:.1f}' y1='{top}' x2='{x:.1f}' "
            f"y2='{top + row_height * len(labels)}' stroke='{GRID}'/>"
        )
        parts.append(
            f"<text x='{x:.1f}' y='{top + row_height * len(labels) + 18}' "
            f"font-size='11' fill='{MUTED}' text-anchor='middle'>{_number(value)}</text>"
        )
    parts.append(
        f"<text x='{left + plot / 2:.1f}' y='{top + row_height * len(labels) + 36}' "
        f"font-size='11' fill='{MUTED}' text-anchor='middle'>"
        f"{escape(spec.get('x_title', ''))}</text>"
    )

    bar = 11
    for position, label in enumerate(labels):
        centre = top + row_height * position + row_height / 2
        up = float(increases[position]) if position < len(increases) else 0.0
        down = float(decreases[position]) if position < len(decreases) else 0.0
        parts.append(
            f"<text x='{left - 10}' y='{centre + 4:.1f}' font-size='11' "
            f"fill='{TEXT}' text-anchor='end'>{escape(str(label))}</text>"
        )
        if up > 0:
            width = plot * up / peak
            parts.append(
                f"<rect x='{left}' y='{centre - bar / 2:.1f}' width='{width:.1f}' "
                f"height='{bar / 2}' fill='{FALLBACK_COLORS[0]}'/>"
                f"<text x='{left + width + 4:.1f}' y='{centre - 1:.1f}' "
                f"font-size='10' fill='{MUTED}'>{int(up)}</text>"
            )
        if down > 0:
            width = plot * down / peak
            parts.append(
                f"<rect x='{left}' y='{centre:.1f}' width='{width:.1f}' "
                f"height='{bar / 2}' fill='{FALLBACK_COLORS[1]}'/>"
                f"<text x='{left + width + 4:.1f}' y='{centre + 10:.1f}' "
                f"font-size='10' fill='{MUTED}'>{int(down)}</text>"
            )

    legend_y = height - 8
    for position, (text, color) in enumerate(
        (("Increases", FALLBACK_COLORS[0]), ("Decreases", FALLBACK_COLORS[1]))
    ):
        x = left + position * 110
        parts.append(
            f"<rect x='{x}' y='{legend_y - 9}' width='10' height='10' fill='{color}'/>"
            f"<text x='{x + 15}' y='{legend_y}' font-size='11' "
            f"fill='{MUTED}'>{text}</text>"
        )

    parts.append("</svg>")
    return (
        f"<div class='preview-chart' style='width:{WIDTH}px;max-width:100%'>"
        + "".join(parts)
        + "</div>"
    )


def comparison(spec: dict) -> str:
    """Diverging bars: decreases left of zero, increases right, one row per book.

    Every bucket contributes one row per book, AIM above Index, and both sides
    are drawn on the same symmetric scale (``spec['limit']``) so a decrease bar
    and an increase bar of the same count are the same length.
    """
    rows = spec.get("rows") or []
    if spec.get("empty") or not rows:
        return _empty(
            str(spec.get("note", "") or "")
            or "No bucket to chart: no ranked mover passed the filters."
        )

    # A count axis needs a floor of one mover. A spread axis must not get one:
    # a summed change of a few basis points would be squashed into the middle.
    raw_limit = abs(float(spec.get("limit") or 0.0))
    is_count_axis = str(spec.get("value_format", "count")) == "count"
    limit = max(raw_limit, 1.0) if is_count_axis else (raw_limit or 1.0)
    row_height = 26
    top = 52
    bottom = 48
    left = 210
    right = 24
    plot = WIDTH - left - right
    half = plot / 2
    middle = left + half
    bottom_y = top + row_height * len(rows)
    height = bottom_y + bottom

    parts = [
        f"<svg class='preview-chart-svg' viewBox='0 0 {WIDTH} {height}' "
        f"xmlns='http://www.w3.org/2000/svg' role='img' "
        f"aria-label=\"{escape(spec.get('title', 'Movers by bucket'))}\">",
        f"<text x='{left}' y='22' font-size='13' font-weight='600' "
        f"fill='{TEXT}'>{escape(spec.get('title', ''))}</text>",
    ]
    for fraction in (-1, -0.5, 0, 0.5, 1):
        value = limit * fraction
        x = middle + half * fraction
        parts.append(
            f"<line x1='{x:.1f}' y1='{top}' x2='{x:.1f}' y2='{bottom_y}' "
            f"stroke='{GRID}'/>"
            f"<text x='{x:.1f}' y='{bottom_y + 18}' font-size='11' "
            f"fill='{MUTED}' text-anchor='middle'>{_number(value)}</text>"
        )
    parts.append(
        f"<line x1='{middle:.1f}' y1='{top}' x2='{middle:.1f}' y2='{bottom_y}' "
        f"stroke='{ZERO}'/>"
    )
    parts.append(
        f"<text x='{middle:.1f}' y='{bottom_y + 36}' font-size='11' "
        f"fill='{MUTED}' text-anchor='middle'>"
        f"{escape(spec.get('x_title', ''))}</text>"
    )

    # A count chart rounds to a whole mover; a spread chart keeps two decimals,
    # because a summed change of 0.1269 would round to 0 and draw no bar at all.
    is_count = str(spec.get("value_format", "count")) == "count"

    def bar_label(value: float) -> str:
        return f"{value:.0f}" if is_count else f"{value:+.4f}"

    # The colour of a bar comes from the specification, exactly as the Desktop
    # figure reads it, so the two renderers cannot disagree about what a colour
    # means. Deriving it again here is how a one-book run was drawn in the
    # comparison book palette instead of the blue/orange direction pair.
    trace_colors = {
        (str(trace.get("book", "")), str(trace.get("direction", ""))): trace.get("color")
        for trace in spec.get("traces") or []
    }

    def pair_for(book: str) -> tuple[str, str]:
        fallback = config.CHART_DIRECTION_COLORS
        up = trace_colors.get((book, "Increase")) or fallback[0]
        down = trace_colors.get((book, "Decrease")) or fallback[1]
        return (up, down)

    bar = 14
    for position, row in enumerate(rows):
        centre = top + row_height * position + row_height / 2
        book = str(row.get("book", ""))
        pair = pair_for(book)
        parts.append(
            f"<text x='{left - 10}' y='{centre + 4:.1f}' font-size='11' "
            f"fill='{TEXT}' text-anchor='end'>{escape(str(row.get('label', '')))}</text>"
        )
        # A decrease is stored negative so the two halves share one axis; the
        # bar is drawn left of zero, so its length is the magnitude.
        up = max(float(row.get("increase") or 0.0), 0.0)
        down = abs(float(row.get("decrease") or 0.0))
        if up > 0:
            width = half * up / limit
            parts.append(
                f"<rect x='{middle:.1f}' y='{centre - bar / 2:.1f}' "
                f"width='{width:.1f}' height='{bar}' fill='{pair[0]}'/>"
                f"<text x='{middle + width + 4:.1f}' y='{centre + 4:.1f}' "
                f"font-size='10' fill='{MUTED}'>{bar_label(up)}</text>"
            )
        if down > 0:
            width = half * down / limit
            parts.append(
                f"<rect x='{middle - width:.1f}' y='{centre - bar / 2:.1f}' "
                f"width='{width:.1f}' height='{bar}' fill='{pair[1]}'/>"
                f"<text x='{middle - width - 4:.1f}' y='{centre + 4:.1f}' "
                f"font-size='10' fill='{MUTED}' text-anchor='end'>{bar_label(-down)}</text>"
            )

    legend_y = height - 8
    x = left
    for book in spec.get("books") or []:
        pair = pair_for(str(book))
        parts.append(
            f"<rect x='{x}' y='{legend_y - 9}' width='10' height='10' "
            f"fill='{pair[0]}'/>"
            f"<text x='{x + 14}' y='{legend_y}' font-size='11' fill='{MUTED}'>"
            f"{escape(str(book))} increase</text>"
            f"<rect x='{x + 96}' y='{legend_y - 9}' width='10' height='10' "
            f"fill='{pair[1]}'/>"
            f"<text x='{x + 110}' y='{legend_y}' font-size='11' fill='{MUTED}'>"
            f"decrease</text>"
        )
        x += 210

    parts.append("</svg>")
    return (
        f"<div class='preview-chart' style='width:{WIDTH}px;max-width:100%'>"
        + "".join(parts)
        + "</div>"
    )


def changes(spec: dict) -> str:
    """Signed bars for one ranked side, centred on zero."""
    rows = spec.get("rows") or []
    if spec.get("empty") or not rows:
        return _empty(f"No {str(spec.get('side', '')).lower()} rows passed the filters.")

    peak = _nice_max(max(abs(row["value"]) for row in rows))
    row_height = 26
    top = 52
    bottom = 44
    left = 190
    right = 24
    plot = WIDTH - left - right
    height = top + row_height * len(rows) + bottom
    middle = left + plot / 2

    parts = [
        f"<svg class='preview-chart-svg' viewBox='0 0 {WIDTH} {height}' "
        f"xmlns='http://www.w3.org/2000/svg' role='img' "
        f"aria-label=\"{escape(spec.get('title', 'Ranked changes'))}\">",
        f"<text x='{left}' y='22' font-size='13' font-weight='600' "
        f"fill='{TEXT}'>{escape(spec.get('title', ''))}</text>",
    ]
    half = plot / 2
    for fraction in (-1, -0.5, 0, 0.5, 1):
        value = peak * fraction
        x = middle + half * fraction
        parts.append(
            f"<line x1='{x:.1f}' y1='{top}' x2='{x:.1f}' "
            f"y2='{top + row_height * len(rows)}' stroke='{GRID}'/>"
        )
        parts.append(
            f"<text x='{x:.1f}' y='{top + row_height * len(rows) + 18}' "
            f"font-size='11' fill='{MUTED}' text-anchor='middle'>{_number(value)}</text>"
        )
    parts.append(
        f"<line x1='{middle:.1f}' y1='{top}' x2='{middle:.1f}' "
        f"y2='{top + row_height * len(rows)}' stroke='{ZERO}'/>"
    )
    parts.append(
        f"<text x='{middle:.1f}' y='{top + row_height * len(rows) + 36}' "
        f"font-size='11' fill='{MUTED}' text-anchor='middle'>"
        f"{escape(spec.get('x_title', ''))}</text>"
    )

    colors = spec.get("colors") or []
    bar = 13
    for position, row in enumerate(rows):
        centre = top + row_height * position + row_height / 2
        value = float(row["value"])
        width = half * abs(value) / peak
        x = middle if value >= 0 else middle - width
        color = colors[position] if position < len(colors) else FALLBACK_COLORS[0]
        label = row["label"]
        shown = label if len(label) <= 26 else label[:25] + "\u2026"
        parts.append(
            f"<text x='{left - 10}' y='{centre + 4:.1f}' font-size='11' "
            f"fill='{TEXT}' text-anchor='end' data-security=\"{escape(row['ID'])}\" "
            f"style='cursor:pointer'>{escape(shown)}</text>"
            f"<rect x='{x:.1f}' y='{centre - bar / 2:.1f}' width='{max(width, 1):.1f}' "
            f"height='{bar}' fill='{color}' data-security=\"{escape(row['ID'])}\" "
            f"style='cursor:pointer'/>"
            f"<text x='{(x + width + 4) if value >= 0 else (x - 4):.1f}' "
            f"y='{centre + 4:.1f}' font-size='10' fill='{MUTED}' "
            f"text-anchor='{'start' if value >= 0 else 'end'}'>{escape(row['text'])}</text>"
        )

    parts.append("</svg>")
    return (
        f"<div class='preview-chart' style='width:{WIDTH}px;max-width:100%'>"
        + "".join(parts)
        + "</div>"
    )


def paths(spec: dict) -> str:
    """One polyline per security; x is the real observation date."""
    traces = spec.get("traces") or []
    if spec.get("empty") or not traces:
        return _empty(
            str(spec.get("note", "") or "")
            or "No spread series was returned for the selected bond."
        )

    values = [value for trace in traces for value in trace["values"]]
    low = min(values)
    high = max(values)
    if high == low:
        high = low + 1.0
    dates = sorted({day for trace in traces for day in trace["dates"]})

    top = 52
    bottom = 56
    left = 70
    right = 24
    width = WIDTH
    plot_w = width - left - right
    plot_h = 200
    height = top + plot_h + bottom

    def x_of(day: str) -> float:
        if len(dates) == 1:
            return left + plot_w / 2
        return left + plot_w * dates.index(day) / (len(dates) - 1)

    def y_of(value: float) -> float:
        return top + plot_h * (high - value) / (high - low)

    parts = [
        f"<svg class='preview-chart-svg' viewBox='0 0 {width} {height}' "
        f"xmlns='http://www.w3.org/2000/svg' role='img' "
        f"aria-label=\"{escape(spec.get('title', 'Spread path'))}\">",
        f"<text x='{left}' y='22' font-size='13' font-weight='600' "
        f"fill='{TEXT}'>{escape(spec.get('title', ''))}</text>",
    ]
    for step in range(5):
        value = low + (high - low) * step / 4
        y = y_of(value)
        parts.append(
            f"<line x1='{left}' y1='{y:.1f}' x2='{left + plot_w}' y2='{y:.1f}' "
            f"stroke='{GRID}'/>"
            f"<text x='{left - 8}' y='{y + 4:.1f}' font-size='10' fill='{MUTED}' "
            f"text-anchor='end'>{value:.3f}</text>"
        )
    for day in dates:
        x = x_of(day)
        parts.append(
            f"<text x='{x:.1f}' y='{top + plot_h + 20}' font-size='10' "
            f"fill='{MUTED}' text-anchor='middle'>{escape(day)}</text>"
        )

    palette = (
        "#1565c0", "#ef6c00", "#2e7d32", "#6a1b9a", "#00838f",
        "#c62828", "#4e342e", "#37474f", "#ad1457", "#827717",
    )
    for position, trace in enumerate(traces):
        colour = palette[position % len(palette)]
        points = " ".join(
            f"{x_of(day):.1f},{y_of(value):.1f}"
            for day, value in zip(trace["dates"], trace["values"])
        )
        identifier = escape(str(trace["id"]))
        parts.append(
            f"<polyline points='{points}' fill='none' stroke='{colour}' "
            f"stroke-width='1.8' opacity='0.9' data-security=\"{identifier}\" "
            f"style='cursor:pointer'/>"
        )
        for day, value in zip(trace["dates"], trace["values"]):
            parts.append(
                f"<circle cx='{x_of(day):.1f}' cy='{y_of(value):.1f}' r='2.6' "
                f"fill='{colour}' data-security=\"{identifier}\" "
                f"style='cursor:pointer'/>"
            )
    parts.append(
        f"<text x='{left}' y='{height - 10}' font-size='10' fill='{MUTED}'>"
        f"{escape(spec.get('y_title', ''))} \u00b7 "
        f"{escape(str(traces[0]['id']))} (the selected bond)</text>"
    )
    parts.append("</svg>")
    return (
        f"<div class='preview-chart' style='width:{WIDTH}px;max-width:100%'>"
        + "".join(parts)
        + "</div>"
    )


RENDERERS = {
    "buckets": buckets,
    "changes": changes,
    "paths": paths,
    "comparison": comparison,
}


def render(spec: dict) -> str:
    """Dispatch on ``spec['kind']``; unknown kinds render nothing rather than raise."""
    return RENDERERS.get(str(spec.get("kind", "")), lambda _spec: "")(spec)
