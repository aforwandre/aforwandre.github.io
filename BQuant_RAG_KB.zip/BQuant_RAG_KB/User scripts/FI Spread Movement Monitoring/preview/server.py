"""Interactive local preview server for FI Spread Movement Monitoring.

Serves the layout page on ``http://localhost:8775/`` and answers each Update by
running the real ``app.py`` / ``engine.py`` in this Python process. The browser
never talks to Bloomberg, and ``bql`` is never imported: the data is a
placeholder ``FetchResult`` from ``preview_core.py``.

**The page always runs the code as it is on disk.** Every request checks the
mtimes of ``preview/*.py`` and ``fi_spread_movement/*.py`` and reloads those
modules when they changed, so an edit shows up on the next browser refresh
without stopping the server. A reload that fails is reported on the page
instead of being served from the previous version; fix the file and refresh.

Port 8775 is reserved for this project. 8765 is the ETF Spread preview and 8770
is FI Index Change, so neither is reused here.

Usage:
    python3 preview/server.py            # foreground, Ctrl-C to stop
    python3 preview/server.py --port 8776
    python3 preview/server.py --no-reload    # serve the code loaded at startup

Then open http://localhost:8775/ in a browser. ``127.0.0.1:8775/interface.html``
reaches the same page. Use ``localhost`` in the in-IDE browser, because it
resolves only the hostname.
"""

from __future__ import annotations

import argparse
import importlib
import json
import socketserver
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PREVIEW_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = PREVIEW_DIR.parent / "fi_spread_movement"
if str(PREVIEW_DIR) not in sys.path:
    sys.path.insert(0, str(PREVIEW_DIR))

import preview_core  # noqa: E402

DEFAULT_PORT = 8775
MAX_BODY_BYTES = 64 * 1024

# Reload in dependency order. ``preview_core`` comes first because it owns the
# stub widget classes: reloading it redefines them and re-binds the stub module,
# so the package modules reloaded after it bind the same classes the renderer
# compares against. A package module may import the one before it at module
# level.
RELOAD_ORDER = (
    "preview_core",
    "svg_charts",
    "fi_spread_movement.config",
    "fi_spread_movement.data",
    "fi_spread_movement.engine",
    "fi_spread_movement.charts",
    "fi_spread_movement.app",
)

_RELOAD_LOCK = threading.Lock()
_RELOAD_ENABLED = True
_RELOAD_ERROR: str | None = None


def _signature() -> tuple:
    """Names, mtimes and sizes of every source file this preview executes."""
    rows: list[tuple[str, int, int]] = []
    for folder in (PREVIEW_DIR, PACKAGE_DIR):
        for path in sorted(folder.glob("*.py")):
            try:
                stat = path.stat()
            except OSError:
                continue
            rows.append((str(path), stat.st_mtime_ns, stat.st_size))
    return tuple(rows)


_LAST_SIGNATURE = _signature()


def reload_if_changed() -> str | None:
    """Reload the preview and package modules when a source file changed.

    Returns ``None`` when the served code is current, or a diagnostic string
    when reloading raised. A failure is never hidden: the caller answers with
    that text, so the page cannot quietly show the previous version. The
    signature is left stale on failure, so the next request retries.
    """
    global _LAST_SIGNATURE, _RELOAD_ERROR
    if not _RELOAD_ENABLED:
        return None
    signature = _signature()
    if signature == _LAST_SIGNATURE:
        return _RELOAD_ERROR
    with _RELOAD_LOCK:
        signature = _signature()
        if signature == _LAST_SIGNATURE:
            return _RELOAD_ERROR
        changed = {name for name, _mtime, _size in signature} ^ {
            name for name, _mtime, _size in _LAST_SIGNATURE
        }
        try:
            for name in RELOAD_ORDER:
                module = sys.modules.get(name)
                if module is None:
                    continue
                importlib.reload(module)
            preview_core.reset_session()
        except Exception as exc:  # fail visible, keep serving what still loads
            _RELOAD_ERROR = (
                f"Preview reload failed: {type(exc).__name__}: {exc}. "
                "The page is holding the previous code until this is fixed. "
                f"Reloaded in order: {', '.join(RELOAD_ORDER)}."
            )
            sys.stderr.write("[preview] " + _RELOAD_ERROR + "\n")
            if changed:
                sys.stderr.write(f"[preview] changed: {sorted(changed)}\n")
            return _RELOAD_ERROR
        _RELOAD_ERROR = None
        _LAST_SIGNATURE = signature
        sys.stderr.write("[preview] reloaded: " + ", ".join(RELOAD_ORDER) + "\n")
    return None


class PreviewServer(ThreadingHTTPServer):
    """Loopback-only server that never performs a reverse-DNS lookup.


    ``http.server.HTTPServer.server_bind`` calls ``socket.getfqdn()``, which can
    block for a long time when the resolver is restricted (for example under
    launchd). The preview only needs the numeric host, so it is set directly.
    """

    daemon_threads = True
    allow_reuse_address = True

    def server_bind(self) -> None:
        socketserver.TCPServer.server_bind(self)
        self.server_name = self.server_address[0]
        self.server_port = self.server_address[1]


class PreviewHandler(BaseHTTPRequestHandler):
    server_version = "FIPreview/1.0"

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        failed = reload_if_changed()
        if failed:
            self._send(
                500,
                "text/html; charset=utf-8",
                "<!DOCTYPE html><html><body style='font:14px system-ui;padding:2rem'>"
                "<h2>Preview reload failed</h2><p>"
                + self._escape(failed)
                + "</p><p>Fix the file, then refresh this page. The server does not "
                "need to be restarted.</p></body></html>",
            )
            return
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html", "/interface.html"):
            self._send(200, "text/html; charset=utf-8", preview_core.page_html())
            return
        if path == "/api/meta":
            # ``build`` lets an open page notice that the code on disk has moved
            # on. Without it a stale tab silently routes a Display Top Refresh
            # to Update, which looks like "the control does nothing" (DR-25).
            self._send_json(
                200,
                {"app": "FI Spread Movement Monitoring", "build": preview_core.build_id()},
            )
            return
        if path == "/api/options":
            # Filter choices for the run already loaded. Reading them is local:
            # no request is built and nothing is fetched from Bloomberg.
            self._send_json(200, preview_core.current_options())
            return
        self._send(404, "text/plain; charset=utf-8", "Not found. Open / for the preview.\n")

    def do_POST(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        failed = reload_if_changed()
        if failed:
            self._send_json(
                500,
                {"status": f"<p><b>Error:</b> {self._escape(failed)}</p>", "detail": "", "log": "", "results": ""},
            )
            return
        path = self.path.split("?", 1)[0]
        if path not in ("/api/update", "/api/view"):
            self._send(404, "text/plain; charset=utf-8", "Not found.\n")
            return

        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            self._send_json(400, {"status": "<p><b>Error:</b> bad Content-Length</p>", "detail": "", "log": "", "results": ""})
            return
        if length <= 0 or length > MAX_BODY_BYTES:
            self._send_json(
                413,
                {"status": "<p><b>Error:</b> request body missing or too large.</p>", "detail": "", "log": "", "results": ""},
            )
            return

        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._send_json(
                400,
                {"status": "<p><b>Error:</b> request body is not JSON.</p>", "detail": "", "log": "", "results": ""},
            )
            return
        if not isinstance(payload, dict):
            self._send_json(
                400,
                {"status": "<p><b>Error:</b> request body must be a JSON object.</p>", "detail": "", "log": "", "results": ""},
            )
            return

        if path == "/api/view":
            # Local only: the filters narrow the frames already in memory.
            filters = payload.get("filters")
            if filters is not None and not isinstance(filters, dict):
                self._send_json(
                    400,
                    {"status": "<p><b>Error:</b> filters must be an object.</p>", "ok": False},
                )
                return
            group = payload.get("group")
            if group is not None and not isinstance(group, str):
                self._send_json(
                    400,
                    {"status": "<p><b>Error:</b> group must be text.</p>", "ok": False},
                )
                return
            selected = payload.get("selected")
            if selected is not None and not isinstance(selected, str):
                self._send_json(
                    400,
                    {"status": "<p><b>Error:</b> selected must be text.</p>", "ok": False},
                )
                return
            bucket = payload.get("bucket")
            if bucket is not None and not isinstance(bucket, str):
                self._send_json(
                    400,
                    {"status": "<p><b>Error:</b> bucket must be text.</p>", "ok": False},
                )
                return
            display_top = payload.get("display_top")
            if display_top is not None:
                if not isinstance(display_top, dict):
                    self._send_json(
                        400,
                        {
                            "status": "<p><b>Error:</b> display_top must be an object.</p>",
                            "ok": False,
                        },
                    )
                    return
                unknown = sorted(
                    key for key in display_top if key not in ("increases", "decreases")
                )
                if unknown:
                    self._send_json(
                        400,
                        {
                            "status": (
                                "<p><b>Error:</b> unknown display_top side: "
                                f"{self._escape(', '.join(str(key) for key in unknown))}</p>"
                            ),
                            "ok": False,
                        },
                    )
                    return
            try:
                result = preview_core.apply_view(
                    preview_core.session_app(),
                    filters=filters,
                    group=group,
                    selected=selected,
                    bucket=bucket,
                    display_top=display_top,
                )
            except Exception as exc:  # fail visible: the panel says what broke
                self._send_json(
                    500,
                    {
                        "ok": False,
                        "status": (
                            f"<p><b>Error:</b> {type(exc).__name__}: "
                            f"{self._escape(str(exc))}</p>"
                        ),
                    },
                )
                return
            self._send_json(200, result)
            return

        mode = payload.get("mode")
        if mode == "selection":
            # Local edit only: the bar is re-stated from the loaded run and no
            # request is built. Unknown keys are ignored rather than guessed.
            try:
                result = preview_core.set_selection(
                    index=payload.get("index"),
                    aim=payload.get("aim"),
                    bond=payload.get("bond"),
                    source=payload.get("source"),
                    spread=payload.get("spread"),
                    start=payload.get("start"),
                    end=payload.get("end"),
                )
            except ValueError as exc:
                self._send_json(
                    400, {"status": f"<p><b>Error:</b> {self._escape(str(exc))}</p>"}
                )
                return
            self._send_json(200, result)
            return
        if mode not in (None, "ok", "failure"):
            self._send_json(
                400,
                {"status": "<p><b>Error:</b> unknown preview mode.</p>", "detail": "", "log": "", "results": ""},
            )
            return

        try:
            result = preview_core.run_update(
                spread=payload.get("spread"),
                start=payload.get("start"),
                end=payload.get("end"),
                index=payload.get("index"),
                aim=payload.get("aim"),
                bond=payload.get("bond"),
                source=payload.get("source"),
                mode=mode or "ok",
                app=preview_core.session_app(),
            )
        except Exception as exc:  # fail visible: the page shows the message
            self._send_json(
                500,
                {
                    "status": (
                        f"<p><b>Error:</b> {type(exc).__name__}: "
                        f"{self._escape(str(exc))}</p>"
                    ),
                    "detail": "",
                    "log": "",
                    "results": "",
                },
            )
            return

        self._send_json(200, result)

    def _escape(self, text: str) -> str:
        from html import escape

        return escape(text)

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self._send(status, "application/json; charset=utf-8", body)

    def _send(self, status: int, content_type: str, body) -> None:
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args) -> None:
        sys.stderr.write("[preview] " + (fmt % args) + "\n")


def serve(port: int = DEFAULT_PORT, host: str = "127.0.0.1") -> int:
    try:
        httpd = PreviewServer((host, port), PreviewHandler)
    except OSError as exc:
        print(
            f"Could not listen on {host}:{port} ({exc}). "
            "Another process may already own that port; pick one with --port.",
            file=sys.stderr,
        )
        return 1
    print(f"FI Spread Movement Monitoring preview: http://localhost:{port}/")
    print("Ctrl-C stops it. bql is not imported; no Bloomberg request can run.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        httpd.server_close()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Bind address. Keep the loopback default; this preview is local only.",
    )
    parser.add_argument(
        "--no-reload",
        action="store_true",
        help="Serve the code imported at startup instead of reloading changed files.",
    )
    args = parser.parse_args(argv)
    global _RELOAD_ENABLED
    _RELOAD_ENABLED = not args.no_reload
    return serve(args.port, args.host)


if __name__ == "__main__":
    raise SystemExit(main())
