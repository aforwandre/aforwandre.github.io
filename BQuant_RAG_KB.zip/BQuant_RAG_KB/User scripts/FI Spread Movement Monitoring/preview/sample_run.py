"""Run the FI Spread Movement engine on synthetic input and print the results.

This is the local "sample function" view of the app: it calls the real
``prepare_ranked_movers`` and ``validate_candidate_changes`` with placeholder
frames and prints exactly the tables the app would display. Change the numbers
here, re-run, and see how the engine reacts without touching BQuant.

No ``bql`` is imported and no Bloomberg request can run. The data below is
synthetic and is not a market result.

Usage:
    python3 preview/sample_run.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fi_spread_movement import config  # noqa: E402
from fi_spread_movement.engine import (  # noqa: E402
    prepare_ranked_movers,
    validate_candidate_changes,
)

START = pd.Timestamp("2026-10-23")
END = pd.Timestamp("2026-10-30")

# Edit these to try a case: a wrong sign, a duplicate ID, a non-numeric change,
# a short list, or a series whose last-minus-first value does not match.
# (ID, Name, Rating, Currency, Maturity, Duration, Change)
INCREASES = [
    ("DUMMYBOND001", "Dummy Sovereign A 2032", "Aa2", "USD", "2032-03-15", 4.62, 0.0410),
    ("DUMMYBOND002", "Dummy Agency B 2030", "Aaa", "USD", "2030-09-01", 3.18, 0.0386),
    ("DUMMYBOND003", "Dummy Supranational C", "Aaa", "EUR", "2033-06-20", 5.41, 0.0352),
]
DECREASES = [
    ("DUMMYBOND011", "Dummy Sovereign K 2031", "Aa2", "USD", "2031-05-19", 4.11, -0.0362),
    ("DUMMYBOND012", "Dummy Agency L 2028", "Aaa", "USD", "2028-10-07", 1.88, -0.0331),
]


def _frames():
    rows = INCREASES + DECREASES
    increases = pd.DataFrame([{"ID": r[0], "Change": r[6]} for r in INCREASES])
    decreases = pd.DataFrame([{"ID": r[0], "Change": r[6]} for r in DECREASES])
    descriptors = pd.DataFrame(
        [
            {
                "ID": r[0],
                "Name": r[1],
                "Rating": r[2],
                "Currency": r[3],
                "Maturity": r[4],
                "Duration": r[5],
            }
            for r in rows
        ]
    )
    series = []
    for r in rows:
        first = 1.25
        series.append({"ID": r[0], "DATE": START, "Spread": first})
        series.append({"ID": r[0], "DATE": END, "Spread": first + r[6]})
    return increases, decreases, descriptors, pd.DataFrame(series)


def main() -> int:
    pd.set_option("display.width", 200)
    pd.set_option("display.max_columns", 20)

    increases, decreases, descriptors, series = _frames()

    movers = prepare_ranked_movers(
        increases,
        decreases,
        descriptors,
        top_n=config.TOP_N,
        descriptor_columns=tuple(label for label, _item in config.DESCRIPTOR_FIELDS),
    )
    validation = validate_candidate_changes(
        movers.increases,
        movers.decreases,
        series,
        requested_start=START,
        requested_end=END,
    )

    print(f"spread={config.DEFAULT_SPREAD_TYPE}  universe={config.DEFAULT_INDEX}")
    print(f"window={START.date()} -> {END.date()}  top_n={config.TOP_N}")

    print("Top increases")
    print(movers.increases.to_string(index=False) if not movers.increases.empty else "(empty)")
    print("\nTop decreases")
    print(movers.decreases.to_string(index=False) if not movers.decreases.empty else "(empty)")
    # The frame is printed as a diagnostic here; it has no panel on the page
    # since 2026-11-01, where its findings appear in the step log instead.
    print("\nBounded series check (log only, not on screen)")
    print(validation.frame.to_string(index=False) if not validation.frame.empty else "(empty)")

    notes = [*movers.notes, *validation.notes]
    print("\nNotes")
    for note in notes:
        print(f"  - {note}")
    if not notes:
        print("  (none)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
