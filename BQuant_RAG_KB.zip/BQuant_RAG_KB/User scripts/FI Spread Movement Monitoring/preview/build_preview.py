"""Render a static ``preview/interface.html`` from the live FI Spread app.

This is the offline companion to ``preview/server.py``: a single file for the case
where no Python process may run. Both front ends share ``preview_core.py``, so the
layout cannot differ between them. The interactive preview is the default; this
page cannot run an Update and says so.

Usage:
    python3 preview/build_preview.py            # rewrite interface.html if it changed
    python3 preview/build_preview.py --check     # exit 1 when it is out of date
"""

from __future__ import annotations

import sys
from pathlib import Path

PREVIEW_DIR = Path(__file__).resolve().parent
if str(PREVIEW_DIR) not in sys.path:
    sys.path.insert(0, str(PREVIEW_DIR))

import preview_core  # noqa: E402

OUTPUT = PREVIEW_DIR / "interface.html"


def build() -> str:
    app = preview_core.new_app()

    # The sample run uses the Index path, which is the default source. The AIM
    # path is exercised in the interactive preview by switching the dropdown.
    update = preview_core.run_update(
        spread=app.spread_type.value,
        start=app.start_date.value,
        end=app.end_date.value,
        index="LEGATRUU Index",
        source="Index",
        app=app,
    )

    # Rendered after the sample run so the input label and the status bar in the
    # page header match this page's source choice.
    initial = preview_core.initial_container_html(app)

    body = (
        '<div class="banner stop">\n'
        "  <b>Static copy — Update is disabled.</b> This file has no Python process behind\n"
        "  it. Start <code>python3 preview/server.py</code> and open\n"
        "  <code>http://localhost:8775/</code> for the interactive version.\n"
        "</div>\n"
        f"{preview_core.banner_html()}\n"
        f"{preview_core.notebook_html(initial)}\n"
        "<h3>Sample result of one Update</h3>\n"
        '<p class="preview-only">Rendered by the real controller and engine from a\n'
        "placeholder result; controls are shown above but cannot act here.</p>\n"
        '<p class="preview-only"><b>Row clicks and bucket picks do not work in this\n'
        "file.</b> This is a static snapshot with no script; the clickable page is the\n"
        "served preview, <code>python3 preview/server.py</code>.</p>\n"
        '<div class="notebook">'
        f'<div class="widget-html" id="status-panel">{update["status"]}</div>\n'
        f'<div class="widget-html" id="detail-panel">{update["detail"]}</div>\n'
        f'<div class="widget-output" id="log-panel">{update["log"]}</div></div>'
    )

    return preview_core.document(
        "FI Spread Movement Monitoring — interface preview (static)",
        body,
    )


def main(argv: list[str]) -> int:
    page = build()
    current = OUTPUT.read_text(encoding="utf-8") if OUTPUT.exists() else ""
    if "--check" in argv:
        if current != page:
            print(f"{OUTPUT.name} is out of date; run python3 preview/build_preview.py")
            return 1
        print(f"{OUTPUT.name} is in sync")
        return 0

    if current == page:
        # Rewriting identical bytes only moves the mtime. That looks like an
        # edit to anything watching this file (the deterministic rebuild test
        # runs this script), so a no-op build stays a no-op.
        print(f"{OUTPUT.name} is already current; not rewritten")
        return 0

    OUTPUT.write_text(page, encoding="utf-8")
    print(f"wrote {OUTPUT.relative_to(PREVIEW_DIR.parent)} ({len(page)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
