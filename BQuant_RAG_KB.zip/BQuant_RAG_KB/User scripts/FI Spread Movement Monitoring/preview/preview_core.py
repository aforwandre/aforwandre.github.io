"""Shared local-preview core for FI Spread Movement Monitoring.

One implementation, two front ends: ``build_preview.py`` writes a static shell and
``server.py`` answers each Update. Both go through this module, which imports the
real ``fi_spread_movement`` package with stubbed ``ipywidgets`` /
``IPython.display``. Nothing here re-implements app or engine logic, so the
preview cannot drift from the code that ships to BQuant.

What is real:
- ``FISpreadMovementApp`` construction, control order, descriptions, headings.
- ``_on_update``: date validation, the date-window cap, the button disable,
  error handling, and the diagnostic panels.
- ``prepare_ranked_movers`` and ``validate_candidate_changes``: ranking, tie
  handling, sign filtering, descriptor merge, and the arithmetic check.

What is not real: the ``FetchResult``. ``bql`` is never imported, so no Bloomberg
request can run. Every identifier and number is a placeholder that varies
deterministically with the selected spread type and dates, so changing a control
visibly changes the tables without pretending to be market data.
"""

from __future__ import annotations

import atexit
import hashlib
import shutil
import sys
import tempfile
import threading
import types
from datetime import date
from html import escape
from pathlib import Path

import pandas as pd

PREVIEW_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PREVIEW_DIR.parent

# The files a served page is rendered from. A page built by an older copy of
# these cannot be trusted to route its own controls: before the fix, every
# rendered button carried ``data-field="update"``, so a Display Top "Refresh"
# ran a full Update. That produced exactly the reported symptom — the box went
# back to 10 and the panels redrew at 10 — with nothing on screen to say why.
# Hashing the content (not the mtimes) keeps the static build deterministic.
_BUILD_FILES = (
    "fi_spread_movement/__init__.py",
    "fi_spread_movement/config.py",
    "fi_spread_movement/data.py",
    "fi_spread_movement/engine.py",
    "fi_spread_movement/charts.py",
    "fi_spread_movement/app.py",
    "preview/preview_core.py",
    "preview/svg_charts.py",
    "preview/server.py",
)

_BUILD_LOCK = threading.Lock()
_BUILD_CACHE: dict = {"key": None, "value": None}


def build_id() -> str:
    """A short id for the code that renders the page.

    The page carries its own id and compares it with the server's, so a tab
    left open across an edit says so instead of quietly driving the wrong
    control. Returned as ``unknown`` when a file is absent, which is what a
    partial copy on another machine looks like: no comparison, no claim.
    """
    key = []
    for relative in _BUILD_FILES:
        path = PROJECT_ROOT / relative
        try:
            stat = path.stat()
        except OSError:
            return "unknown"
        key.append((relative, stat.st_mtime_ns, stat.st_size))
    key = tuple(key)
    with _BUILD_LOCK:
        if _BUILD_CACHE["key"] == key:
            return _BUILD_CACHE["value"]
    digest = hashlib.sha256()
    for relative, _mtime, _size in key:
        digest.update(relative.encode("utf-8"))
        try:
            digest.update((PROJECT_ROOT / relative).read_bytes())
        except OSError:
            return "unknown"
    value = digest.hexdigest()[:12]
    with _BUILD_LOCK:
        _BUILD_CACHE.update({"key": key, "value": value})
    return value

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ---------------------------------------------------------------------------
# Widget stubs: the ipywidgets surface app.py actually uses.
# ---------------------------------------------------------------------------


class StubButton:
    def __init__(self, description="", button_style="", icon="", **kwargs):
        self.description = description
        self.button_style = button_style
        self.icon = icon
        self.disabled = False
        self.handlers = []

    def on_click(self, handler):
        self.handlers.append(handler)


class _Observed:
    """``observe`` / ``unobserve`` support.

    The preview assigns ``value`` directly, so these handlers are recorded but
    never fired: a preview edit is driven by the page, not by a trait event.
    """

    def __init__(self):
        self._observers = []

    def observe(self, handler, names="value"):
        self._observers.append((handler, names))

    def unobserve(self, handler, names="value"):
        self._observers = [item for item in self._observers if item[0] is not handler]


class StubHTML:
    def __init__(self, value="", **kwargs):
        self.value = value


class StubOutput:
    def __init__(self, **kwargs):
        self.entries = []

    def __enter__(self):
        _OUTPUT_STACK.append(self)
        return self

    def __exit__(self, *exc_info):
        if _OUTPUT_STACK and _OUTPUT_STACK[-1] is self:
            _OUTPUT_STACK.pop()
        return False

    def clear_output(self, wait=False):
        self.entries.clear()


class StubVBox:
    """A column widget. ``layout.display`` is honoured: "none" hides it.

    The app hides the bucket and change panels for the Bond source by setting
    ``layout.display``; a stub without a layout attribute would make the
    preview-only run raise where Desktop works.
    """

    def __init__(self, children=(), **kwargs):
        self.children = list(children)
        self.layout = kwargs.get("layout")

    def hidden(self) -> bool:
        layout = self.layout
        if layout is None:
            return False
        return str(getattr(layout, "kwargs", {}).get("display") or "") == "none"


def _option_pairs(options) -> list:
    """Normalise ipywidgets options for the static preview.

    A real ``Dropdown`` or ``SelectMultiple`` accepts either a bare value or a
    ``(label, value)`` pair, shows the label, and stores the value. The stub
    kept the pair as-is, so the preview used to print
    ``('Top 10 increases', 'increases')`` in a box where the notebook shows
    ``Top 10 increases``. Every option is reduced to ``(value, label)`` here so
    the selected test compares the value the widget would actually hold.
    """
    pairs = []
    for option in options or ():
        if isinstance(option, (tuple, list)) and len(option) == 2:
            label, value = option
        else:
            label, value = option, option
        pairs.append((value, label))
    return pairs


class StubHBox:
    def __init__(self, children=(), **kwargs):
        self.children = list(children)
        self.layout = kwargs.get("layout")


class StubDatePicker(_Observed):
    def __init__(self, description="", value=None, **kwargs):
        _Observed.__init__(self)
        self.description = description
        self.value = value


class StubText(_Observed):
    def __init__(self, description="", value="", placeholder="", **kwargs):
        _Observed.__init__(self)
        self.description = description
        self.value = value
        self.placeholder = placeholder


class StubIntText(_Observed):
    """``widgets.IntText``: a whole-number box, as the Display Top row uses.

    The real widget coerces a typed value to ``int`` and refuses a non-number,
    so the stub keeps the value as given and lets ``app._apply_display_top`` do
    the validation: the preview must exercise the same refusal path, not a
    second, more forgiving one.
    """

    def __init__(self, description="", value=0, **kwargs):
        _Observed.__init__(self)
        self.description = description
        self.value = value


class StubDropdown(_Observed):
    def __init__(self, description="", options=(), value=None, **kwargs):
        _Observed.__init__(self)
        self.description = description
        self.options = list(options)
        self.value = value


class StubSelectMultiple(_Observed):
    def __init__(self, description="", options=(), value=(), rows=6, style=None, layout=None, **kwargs):
        _Observed.__init__(self)
        self.description = description
        self.options = list(options)
        self.value = tuple(value or ())
        self.rows = rows
        self.style = style
        self.layout = layout

    def __setattr__(self, name, value):
        if name == "value":
            value = tuple(value or ())
        object.__setattr__(self, name, value)


class StubLayout:
    """``widgets.Layout`` stand-in that keeps an attribute write visible.

    The app hides a panel with ``layout.display = "none"`` after the widget is
    built, not only through the constructor. A stub holding just the constructor
    kwargs would miss that write and the preview would show a panel Desktop
    hides, so every attribute write is mirrored into ``kwargs``.
    """

    def __init__(self, **kwargs):
        object.__setattr__(self, "kwargs", dict(kwargs))

    def __setattr__(self, name, value):
        self.kwargs[name] = value

    def __getattr__(self, name):
        try:
            return self.kwargs[name]
        except KeyError:
            raise AttributeError(name) from None


class StubTab:
    """``widgets.Tab``: two named children and a selected index."""

    def __init__(self, children=(), titles=(), **kwargs):
        self.children = list(children)
        self.titles = list(titles)
        self.selected_index = 0
        self.layout = kwargs.get("layout")

    def set_title(self, index: int, title: str) -> None:
        while len(self.titles) <= index:
            self.titles.append("")
        self.titles[index] = title


_OUTPUT_STACK: list[StubOutput] = []
_LOOSE: list = []
_UPDATE_LOCK = threading.Lock()


def _display(obj):
    if _OUTPUT_STACK:
        _OUTPUT_STACK[-1].entries.append(obj)
    else:
        _LOOSE.append(obj)


_STUB_WIDGETS = {
    "Button": "StubButton",
    "HTML": "StubHTML",
    "Output": "StubOutput",
    "VBox": "StubVBox",
    "HBox": "StubHBox",
    "DatePicker": "StubDatePicker",
    "Text": "StubText",
    "IntText": "StubIntText",
    "Dropdown": "StubDropdown",
    "SelectMultiple": "StubSelectMultiple",
    "Tab": "StubTab",
    "Layout": "StubLayout",
}


def install_stubs() -> None:
    """Register the stub modules before ``fi_spread_movement`` is imported.

    A reload of this module redefines the stub classes. When the stub module is
    already installed, its attributes are rebound in place instead of the early
    return being taken: the renderer matches on ``isinstance(..., StubVBox)``,
    so a page built from one generation of classes and rendered by another
    turns every container into an unknown widget.
    """
    existing = sys.modules.get("ipywidgets")
    if existing is not None and getattr(existing, "_fi_preview_stub", False):
        for public, local in _STUB_WIDGETS.items():
            setattr(existing, public, globals()[local])
        builtin_display = sys.modules.get("IPython.display")
        if builtin_display is not None:
            builtin_display.display = _display
        return

    widgets = types.ModuleType("ipywidgets")
    for public, local in _STUB_WIDGETS.items():
        setattr(widgets, public, globals()[local])
    widgets._fi_preview_stub = True
    sys.modules["ipywidgets"] = widgets

    ipython = types.ModuleType("IPython")
    display_module = types.ModuleType("IPython.display")
    display_module.display = _display
    ipython.display = display_module
    sys.modules["IPython"] = ipython
    sys.modules["IPython.display"] = display_module


# ---------------------------------------------------------------------------
# Placeholder rows. Shapes follow the real FetchResult contract only.
# ---------------------------------------------------------------------------

# (ID, Name, Country, Sector, Rating, Currency, Maturity, Duration, base change)
_INCREASES = [
    ("DUMMYBOND001", "Dummy Sovereign A 2032", "United States", "Sovereign", "Aa2", "USD", "2032-03-15", 4.62, 0.0410),
    ("DUMMYBOND002", "Dummy Agency B 2030", "United States", "Agency", "Aaa", "USD", "2030-09-01", 3.18, 0.0386),
    ("DUMMYBOND003", "Dummy Supranational C", "Supranational", "Supranational", "Aaa", "EUR", "2033-06-20", 5.41, 0.0352),
    ("DUMMYBOND004", "Dummy Covered D 2031", "Germany", "Covered", "Aaa", "EUR", "2031-11-04", 4.05, 0.0329),
    ("DUMMYBOND005", "Dummy Sovereign E 2035", "United Kingdom", "Sovereign", "A1", "GBP", "2035-01-22", 6.87, 0.0305),
    ("DUMMYBOND006", "Dummy Corporate F 2029", "United States", "Corporate", "BB+", "USD", "2029-07-30", 2.44, 0.0271),
    ("DUMMYBOND007", "Dummy Local G 2034", "Japan", "Local Authority", "Aa3", "JPY", "2034-12-10", 5.92, 0.0244),
    ("DUMMYBOND008", "Dummy Bank H 2030", "United Kingdom", "Banking", "NR", "GBP", "2030-04-18", 3.31, 0.0212),
    ("DUMMYBOND009", "Dummy Sovereign I 2036", "United States", "Sovereign", "B1", "USD", "2036-08-25", 7.12, 0.0185),
    ("DUMMYBOND010", "Dummy Corporate J 2033", "France", "Corporate", "A3", "EUR", "2033-02-14", 5.07, 0.0154),
]

# Nine rows only, so the real engine contributes its short-list note.
_DECREASES = [
    ("DUMMYBOND011", "Dummy Sovereign K 2031", "United States", "Sovereign", "Aa2", "USD", "2031-05-19", 4.11, -0.0362),
    ("DUMMYBOND012", "Dummy Agency L 2028", "United States", "Agency", "Aaa", "USD", "2028-10-07", 1.88, -0.0331),
    ("DUMMYBOND013", "Dummy Supranational M", "Supranational", "Supranational", "Aaa", "EUR", "2032-01-28", 4.74, -0.0308),
    ("DUMMYBOND014", "Dummy Covered N 2030", "Germany", "Covered", "Aaa", "EUR", "2030-06-11", 3.52, -0.0277),
    ("DUMMYBOND015", "Dummy Sovereign O 2034", "United Kingdom", "Sovereign", "A1", "GBP", "2034-03-06", 6.05, -0.0251),
    ("DUMMYBOND016", "Dummy Corporate P 2029", "United States", "Corporate", "BB-", "USD", "2029-12-03", 2.91, -0.0219),
    ("DUMMYBOND017", "Dummy Local Q 2033", "Japan", "Local Authority", "Aa3", "JPY", "2033-09-16", 5.38, -0.0188),
    ("DUMMYBOND018", "Dummy Bank R 2031", "United Kingdom", "Banking", "Baa3", "GBP", "2031-07-21", 4.33, -0.0161),
    ("DUMMYBOND019", "Dummy Sovereign S 2037", "United States", "Sovereign", "NR", "USD", "2037-02-09", 7.66, -0.0129),
]

# Placeholder magnitudes differ by spread type so the choice is visible.
# Only the three offered types are listed; ``_change`` falls back to 1.0, so a
# type removed from ``config.SPREAD_TYPES`` cannot leave a dangling factor here.
_SPREAD_FACTORS = {
    "OAS": 1.0,
    "Z-Spread": 1.35,
    "I-Spread": 0.72,
}


def _seed(*parts) -> float:
    """Deterministic 0..1 value; the same inputs always give the same page."""
    digest = hashlib.sha256("|".join(str(part) for part in parts).encode()).digest()
    return int.from_bytes(digest[:4], "big") / 0xFFFFFFFF


def _change(row, spread_label, start, end, index) -> float:
    factor = _SPREAD_FACTORS.get(spread_label, 1.0)
    jitter = 0.80 + 0.40 * _seed(index, spread_label, start, end, row[0])
    return round(row[8] * factor * jitter, 4)


def _source_key(app) -> str:
    """The stored key (``index`` / ``aim`` / ``bond`` / ``aim_vs_index``)."""
    from fi_spread_movement import config

    return config.UNIVERSE_SOURCES.get(
        app.universe_source.value, config.DEFAULT_UNIVERSE_SOURCE
    )


def _route_single_value(app, index, aim, bond):
    """Send a lone ``index`` value to the field the chosen source actually reads.

    The page posts three named values; an older caller (or a test) posts one
    ``index`` string and a source. Routing it here keeps one meaning per field
    without the caller having to know which field the source shows.
    """
    if index is None or aim is not None or bond is not None:
        return index, aim, bond
    key = _source_key(app)
    if key == "aim":
        return None, index, bond
    if key == "bond":
        return None, aim, index
    return index, aim, bond


def placeholder_book(spread_label: str, start, end, seed_value: str, book: str | None = None):
    """One synthetic book: two ranked sides, descriptors, series, diagnostics.

    ``book`` labels the rows with the comparison column when it is given. Both
    books of a comparison keep the SAME security identifiers on purpose: one
    bond really can be an index member and an account holding, and the preview
    has to show that a row identity is (book, ID).
    """
    from fi_spread_movement import config
    from fi_spread_movement.data import FetchResult

    result = FetchResult()
    rows = _INCREASES + _DECREASES

    def key(row):
        identifier = str(row[0])
        if book is None and seed_value == "aim":
            identifier = "DUMMYHOLD" + identifier[len("DUMMYBOND"):]
        return identifier

    result.increases = pd.DataFrame(
        [
            {"ID": key(r), "Change": _change(r, spread_label, start, end, f"{seed_value}{book or ''}")}
            for r in _INCREASES
        ]
    )
    result.decreases = pd.DataFrame(
        [
            {"ID": key(r), "Change": _change(r, spread_label, start, end, f"{seed_value}{book or ''}")}
            for r in _DECREASES
        ]
    )
    if book is not None:
        result.increases[config.UNIVERSE_COLUMN] = book
        result.decreases[config.UNIVERSE_COLUMN] = book
    result.descriptors = pd.DataFrame(
        [
            {
                "ID": key(r),
                "Name": r[1],
                "Country": r[2],
                "Sector": r[3],
                "Rating": r[4],
                "Currency": r[5],
                "Maturity": r[6],
                "Duration": r[7],
                # The three extra measures, derived from the same row so the
                # preview shows the new columns without a second data source.
                # Modified sits just under ``Duration``; Effective and OASD
                # step away from it, which is the shape a plain-vanilla bond
                # produces and the shape an MBS/TBA would break.
                "Modified Duration": round(r[7] * 0.985, 2),
                "Effective Duration": round(r[7] * 0.955, 2),
                "OASD": round(r[7] * 0.910, 2),
            }
            for r in rows
        ]
    )

    series = []
    for r in rows:
        first = round(
            1.10 + 0.30 * _seed(seed_value, spread_label, start, end, r[0], "first"), 4
        )
        series.append({"ID": key(r), "DATE": pd.Timestamp(start), "Spread": first})
        series.append(
            {
                "ID": key(r),
                "DATE": pd.Timestamp(end),
                "Spread": round(
                    first
                    + _change(r, spread_label, start, end, f"{seed_value}{book or ''}"),
                    4,
                ),
            }
        )
    result.series = pd.DataFrame(series)

    result.field_status = {
        "Name": f"returned {len(rows)} row(s), {len(rows)} non-null; columns=['ID', 'Name']",
        "Country": f"returned {len(rows)} row(s), {len(rows)} non-null; columns=['ID', 'Country']",
        "Sector": f"returned {len(rows)} row(s), {len(rows)} non-null; columns=['ID', 'Sector']",
        "Rating": f"returned {len(rows)} row(s), {len(rows)} non-null; columns=['ID', 'Rating']",
        "Currency": f"returned {len(rows)} row(s), {len(rows)} non-null; columns=['ID', 'Currency']",
        "Maturity": f"returned {len(rows)} row(s), {len(rows)} non-null; columns=['ID', 'Maturity']",
        # The four measures come from one request, so their receipt lines share
        # one label and one elapsed time rather than pretending to be separate.
        "Duration": f"returned {len(rows)} row(s), {len(rows)} non-null",
        "Modified Duration": f"returned {len(rows)} row(s), {len(rows)} non-null",
        "Effective Duration": f"returned {len(rows)} row(s), {len(rows)} non-null",
        "OASD": f"returned {len(rows)} row(s), {len(rows)} non-null",
        "Spread Series": (
            f"returned {len(series)} observation(s) across {len(rows)} ID(s)."
        ),
    }
    result.request_log = [
        {"label": "Increases ranking", "elapsed_sec": 6.412, "rows": 10, "columns": "ID, Change"},
        {"label": "Decreases ranking", "elapsed_sec": 6.207, "rows": 9, "columns": "ID, Change"},
        {"label": "Descriptor Name", "elapsed_sec": 0.884, "rows": 19, "columns": "ID, Name"},
        {"label": "Descriptor Country", "elapsed_sec": 0.861, "rows": 19, "columns": "ID, Country"},
        {"label": "Descriptor Sector", "elapsed_sec": 0.879, "rows": 19, "columns": "ID, Sector"},
        {"label": "Descriptor Rating", "elapsed_sec": 0.911, "rows": 19, "columns": "ID, Rating"},
        {"label": "Descriptor Currency", "elapsed_sec": 0.876, "rows": 19, "columns": "ID, Currency"},
        {"label": "Descriptor Maturity", "elapsed_sec": 1.043, "rows": 19, "columns": "ID, Maturity"},
        # One request for the whole measure family, matching
        # ``data._fetch_duration_family``: four items in a single call, which is
        # the request ``Duration`` used to occupy alone.
        {"label": "Duration measures", "elapsed_sec": 1.874, "rows": 19, "columns": "ID, Duration, Modified Duration, Effective Duration, OASD"},
        {"label": "Spread Series", "elapsed_sec": 2.515, "rows": 38, "columns": "ID, DATE, Spread"},
    ]
    return result


def placeholder_bond(spread_label: str, start, end, identifier: str):
    """One security, for the Bond source: one ranked row and a daily series.

    A bond run has one security, so there is no ranking to cut and no bucket to
    group. The window is walked one business day at a time, which is what the
    daily table lists; a weekend simply has no row, the same way a holiday with
    no quote has none in a real run.
    """
    from fi_spread_movement import config
    from fi_spread_movement.data import FetchResult

    result = FetchResult()
    change = round(
        _change(_INCREASES[0], spread_label, start, end, identifier),
        4,
    )
    empty = pd.DataFrame(columns=["ID", "Change"])
    row = pd.DataFrame([{"ID": identifier, "Change": change}])
    result.increases = row if change >= 0 else empty
    result.decreases = empty if change >= 0 else row
    result.descriptors = pd.DataFrame(
        [
            {
                "ID": identifier,
                "Name": f"{identifier} (single security)",
                "Country": "Supranational",
                "Sector": "Supranational",
                "Rating": "Aaa",
                "Currency": "EUR",
                "Maturity": "2033-06-20",
                "Duration": 5.41,
                "Modified Duration": 5.33,
                "Effective Duration": 5.17,
                "OASD": 4.92,
            }
        ]
    )

    days = pd.bdate_range(pd.Timestamp(start), pd.Timestamp(end))
    step = change / max(len(days) - 1, 1)
    first = round(
        1.10 + 0.30 * _seed(identifier, spread_label, start, end, identifier, "bond"),
        4,
    )
    result.series = pd.DataFrame(
        [
            {
                "ID": identifier,
                "DATE": day,
                "Spread": round(first + step * position, 4),
            }
            for position, day in enumerate(days)
        ]
    )
    result.field_status = {
        "Name": "returned 1 row(s), 1 non-null; columns=['ID', 'Name']",
        "Modified Duration": "returned 1 row(s), 1 non-null",
        "Effective Duration": "returned 1 row(s), 1 non-null",
        "OASD": "returned 1 row(s), 1 non-null",
        "Spread Series": (
            f"returned {len(result.series)} observation(s) across 1 ID(s)."
        ),
    }
    result.request_log = [
        {"label": "Bond ranking", "elapsed_sec": 6.412, "rows": 1, "columns": "ID, Change"},
        {
            "label": "Duration measures",
            "elapsed_sec": 0.812,
            "rows": 1,
            "columns": "ID, Modified Duration, Effective Duration, OASD",
        },
        {
            "label": "Spread Series",
            "elapsed_sec": 2.515,
            "rows": len(result.series),
            "columns": "ID, DATE, Spread",
        },
    ]
    return result


def placeholder_result(
    spread_label: str,
    start,
    end,
    index: str = "",
    source: str = "index",
    aim: str = "",
):
    """Synthetic FetchResult shaped like the real adapter's return value.

    ``source`` changes the placeholder identifier prefix for the AIM path, so an
    AIM run is visibly different from an index run without pretending to be a
    real book. ``aim_vs_index`` returns the two-book comparison shape: every row
    carries its book, and the same identifiers appear in both books.
    """
    from fi_spread_movement import config

    if source == config.COMPARISON_SOURCE:
        index_book = config.COMPARISON_LABELS["index"]
        aim_book = config.COMPARISON_LABELS["aim"]
        first = placeholder_book(spread_label, start, end, index, index_book)
        second = placeholder_book(spread_label, start, end, aim or index, aim_book)
        combined = placeholder_book(spread_label, start, end, index)
        combined.increases = pd.concat(
            [first.increases, second.increases], ignore_index=True
        )
        combined.decreases = pd.concat(
            [first.decreases, second.decreases], ignore_index=True
        )
        combined.source = config.COMPARISON_SOURCE
        combined.comparison = True
        combined.universe = f"{index} vs {aim or index}"
        combined.request_log = [
            {**entry, "label": f"{index_book} {entry['label']}"}
            for entry in first.request_log
        ] + [
            {**entry, "label": f"{aim_book} {entry['label']}"}
            for entry in second.request_log
        ]
        combined.field_status = dict(first.field_status)
        return combined

    if source == "bond":
        # The Bond source is one security: the path chart and its daily table
        # are the whole screen, so the placeholder is that one security.
        result = placeholder_bond(spread_label, start, end, index)
        result.source = source
        result.universe = index
        return result

    result = placeholder_book(spread_label, start, end, source if source == "aim" else index)
    result.source = source
    result.universe = index
    return result


# ---------------------------------------------------------------------------
# Widget tree -> HTML
# ---------------------------------------------------------------------------

_ICONS = {"refresh": "\u21bb"}
_FIELD_BY_DESCRIPTION = {
    "Index": "index",
    "AIM code": "aim",
    "Bond": "bond",
    "Universe": "source",
    "Spread": "spread",
    "Start date": "start",
    "End date": "end",
    "Group by": "group",
    "Country": "filter-country",
    "Sector": "filter-sector",
    "Currency": "filter-currency",
    "Rating": "filter-rating",
    "Tenor": "filter-tenor",
    "Update": "update",
}


class HtmlRenderer:
    """Serialise the widget tree, marking the widgets the browser must drive."""

    def __init__(
        self,
        status_widget=None,
        detail_widget=None,
        log_widget=None,
        panels: dict | None = None,
        fields: dict | None = None,
    ):
        self.status_widget = status_widget
        self.detail_widget = detail_widget
        self.log_widget = log_widget
        # ``{element_id: widget}`` for the local-view panels. Identity keeps the
        # mapping honest: a widget is rendered as a named panel only when it is
        # the very object the controller holds.
        self.panels = dict(panels or {})
        # ``{widget: data-field}`` for widgets whose description is not unique.
        # The two Display Top rows both say "Refresh", so a description lookup
        # would give both buttons the same field and one of them would drive the
        # wrong panel. Identity is the only unambiguous key.
        self.fields = dict(fields or {})

    def _field(self, node, default: str = "") -> str:
        for widget, name in self.fields.items():
            if widget is node:
                return name
        return default

    def __call__(self, node) -> str:
        return self.render(node)

    def _panel_id(self, node) -> str | None:
        for element_id, widget in self.panels.items():
            if widget is node:
                return element_id
        return None

    def render(self, node) -> str:
        panel_id = self._panel_id(node)
        if panel_id is None:
            return self._render(node)
        # Wrap only the named panel itself; its children are rendered normally.
        return f'<div class="widget-panel" id="{panel_id}">{self._render(node)}</div>'

    def _render(self, node) -> str:
        if node is self.status_widget:
            return f'<div class="widget-html" id="status-panel">{node.value}</div>'
        if node is self.detail_widget:
            return f'<div class="widget-html" id="detail-panel">{node.value}</div>'
        if node is self.log_widget:
            body = "".join(self.render(entry) for entry in node.entries)
            return f'<div class="widget-output" id="log-panel">{body}</div>'

        if isinstance(node, StubHTML):
            return f'<div class="widget-html">{node.value}</div>'

        if isinstance(node, StubButton):
            icon = node.icon or ""
            glyph = (
                f'<span class="widget-icon">{escape(_ICONS.get(icon, icon))}</span>'
                if icon
                else ""
            )
            style = f" mod-{escape(node.button_style)}" if node.button_style else ""
            state = " disabled" if node.disabled else ""
            # Only the Update button is known by its description; every other
            # button must carry its own field, or clicking it would run Update.
            field = self._field(node, _FIELD_BY_DESCRIPTION.get(node.description, ""))
            attr = f' data-field="{field}"' if field else ""
            return (
                '<div class="widget-row">'
                f'<button type="button" class="widget-button{style}"{attr}{state}>'
                f"{glyph}{escape(node.description)}</button></div>"
            )

        if isinstance(node, StubIntText):
            field = self._field(
                node, _FIELD_BY_DESCRIPTION.get(node.description, "")
            )
            attr = f' data-field="{field}"' if field else ""
            return (
                '<div class="widget-row">'
                f'<label class="widget-label">{escape(node.description)}</label>'
                f'<input type="number" min="1" step="1" value="{escape(str(node.value))}"'
                f"{attr}></div>"
            )

        if isinstance(node, StubText):
            field = _FIELD_BY_DESCRIPTION.get(node.description, "")
            attr = f' data-field="{field}"' if field else ""
            placeholder = (
                f' placeholder="{escape(node.placeholder)}"' if node.placeholder else ""
            )
            return (
                '<div class="widget-row">'
                f'<label class="widget-label">{escape(node.description)}</label>'
                f'<input type="text" value="{escape(node.value)}"{placeholder}{attr}>'
                "</div>"
            )

        if isinstance(node, StubDatePicker):
            value = "" if node.value is None else node.value.isoformat()
            field = _FIELD_BY_DESCRIPTION.get(node.description, "")
            attr = f' data-field="{field}"' if field else ""
            return (
                '<div class="widget-row">'
                f'<label class="widget-label">{escape(node.description)}</label>'
                f'<input type="date" value="{escape(value)}"{attr}></div>'
            )

        if isinstance(node, StubDropdown):
            field = _FIELD_BY_DESCRIPTION.get(node.description, "")
            attr = f' data-field="{field}"' if field else ""
            options = "".join(
                f'<option{" selected" if value == node.value else ""} '
                f'value="{escape(str(value))}">{escape(str(label))}</option>'
                for value, label in _option_pairs(node.options)
            )
            return (
                '<div class="widget-row">'
                f'<label class="widget-label">{escape(node.description)}</label>'
                f"<select{attr}>{options}</select></div>"
            )

        if isinstance(node, StubSelectMultiple):
            field = _FIELD_BY_DESCRIPTION.get(node.description, "")
            attr = f' data-field="{field}"' if field else ""
            selected = {str(value) for value in (node.value or ())}
            options = "".join(
                f'<option{" selected" if str(value) in selected else ""} '
                f'value="{escape(str(value))}">{escape(str(label))}</option>'
                for value, label in _option_pairs(node.options)
            )
            # Same arrangement as the FI Index Change preview and as the real
            # widget: the description sits to the left, the box fills the rest of
            # the fixed layout width, and ``rows`` sets the visible row count.
            # Copying that layout is what makes the two screens' filter rows
            # line up instead of merely looking similar.
            rows = int(getattr(node, "rows", 6) or 6)
            layout = getattr(node, "layout", None)
            width = ""
            if layout is not None:
                width = str(getattr(layout, "kwargs", {}).get("width") or "")
            style = f' style="width:{width}"' if width.endswith("px") else ""
            return (
                f'<label class="widget-row widget-select-multiple"{style}>'
                f'<span class="widget-label">{escape(node.description)}</span>'
                f'<select multiple size="{max(4, min(rows, 20))}"{attr}>'
                f"{options}</select></label>"
            )

        if isinstance(node, StubOutput):
            return '<div class="widget-output">' + "".join(
                self.render(entry) for entry in node.entries
            ) + "</div>"

        if isinstance(node, StubTab):
            # Two named tabs, as on Desktop. Panel 0 is shown; the page script
            # switches panels, so the preview can reach Export Excel without a
            # second page. The panels are rendered from the real controller's
            # own widget tree, never rebuilt here.
            titles = list(node.titles) or [f"Tab {index}" for index in range(len(node.children))]
            bar = "".join(
                '<button type="button" class="widget-tab'
                + (" active" if index == 0 else "")
                + f'" data-tab="{index}">{escape(str(title))}</button>'
                for index, title in enumerate(titles)
            )
            panels = "".join(
                f'<div class="widget-tab-panel" data-tab-panel="{index}"'
                + ("" if index == 0 else " hidden")
                + ">"
                + self.render(child)
                + "</div>"
                for index, child in enumerate(node.children)
            )
            return (
                '<div class="widget-tabs"><div class="widget-tabbar">'
                + bar
                + "</div>"
                + panels
                + "</div>"
            )

        if isinstance(node, StubHBox):
            # A row that carries the dimension filters wraps into two lines on a
            # narrow notebook. Its boxes must line up at the top of the row, the
            # way a single-line row already looks; centring them would leave the
            # Group by dropdown straddling both lines.
            extra = ""
            if any(isinstance(child, StubSelectMultiple) for child in node.children):
                extra = " filters-row"
            return f'<div class="widget-hbox{extra}">' + "".join(
                self.render(child) for child in node.children
            ) + "</div>"

        if isinstance(node, StubVBox):
            if node.hidden():
                # Bond source: the bucket and Top 10 panels are hidden rather
                # than drawn empty, exactly as on Desktop.
                return '<div class="widget-vbox" hidden></div>'
            return '<div class="widget-vbox">' + "".join(
                self.render(child) for child in node.children
            ) + "</div>"

        return f'<div class="widget-unknown">{escape(type(node).__name__)}</div>'


# ---------------------------------------------------------------------------
# Driving the real controller
# ---------------------------------------------------------------------------


def _app_module():
    install_stubs()
    from fi_spread_movement import app as app_module
    from fi_spread_movement import charts

    # The preview has no Plotly, so the app's table fallback is replaced by the
    # SVG renderer. Both read the *same* specification dict, so the preview
    # draws the numbers the Desktop figure would draw; nothing is recomputed.
    if str(PREVIEW_DIR) not in sys.path:
        sys.path.insert(0, str(PREVIEW_DIR))
    import svg_charts

    charts.html_fallback = svg_charts.render
    return app_module


# One throwaway cache directory per preview process. Created lazily on first use
# so importing the module writes nothing, and removed when the process exits.
_PREVIEW_CACHE_ROOT = Path(tempfile.mkdtemp(prefix="fi-spread-preview-cache-"))
atexit.register(shutil.rmtree, _PREVIEW_CACHE_ROOT, True)


def new_app():
    """A preview app with its own throwaway cache.

    The preview must never read or write the operator's real ``cache/`` folder:
    its data is synthetic, and a cached synthetic run sitting in the real folder
    would be served later as if it were real. One temp directory per preview
    process is enough, because a preview session is one long-lived page.
    """
    return _app_module().FISpreadMovementApp(cache_root=_PREVIEW_CACHE_ROOT)


# One app instance for the live server, so a local control edit can see the
# previous run and raise "Please Click Update" without duplicating app logic in
# JavaScript. ``run_update`` still builds a fresh app by default, which is what
# the static builder and the tests use.
_SESSION: dict = {}
_SESSION_LOCK = threading.Lock()


def session_app():
    with _SESSION_LOCK:
        app = _SESSION.get("app")
        if app is None:
            app = new_app()
            _SESSION["app"] = app
        return app


def reset_session() -> None:
    """Drop the app kept between requests.

    The preview server reloads this module when app.py changes, so the object
    built from the previous classes must not answer the next request. Dropping
    it rebuilds the app from the code that is on disk now.
    """
    with _SESSION_LOCK:
        _SESSION.clear()


def set_selection(
    index: str | None = None,
    spread: str | None = None,
    start=None,
    end=None,
    source: str | None = None,
    aim: str | None = None,
    bond: str | None = None,
    app=None,
) -> dict:
    """Apply an edit to the controls and let the real controller re-state itself.

    No request is built: ``_refresh_selection_state`` only compares the visible
    controls with the loaded run and rewrites the status bar. ``index`` still
    means the Index field; ``aim`` and ``bond`` address their own fields, which
    are on screen only for the sources that read them.
    """
    app = app or session_app()
    if source is not None and source in app.universe_source.options:
        app.universe_source.value = source
        # The real controller rebuilds the header row for the chosen source.
        app._refresh_universe_row()
    # A one-value payload (an older caller, or a test that only knows the
    # source) addresses whichever field that source reads. The page itself
    # sends index / aim / bond separately.
    index, aim, bond = _route_single_value(app, index, aim, bond)
    if index is not None:
        app.index_input.value = index
    if aim is not None:
        app.aim_input.value = aim
    if bond is not None:
        app.bond_input.value = bond
    if spread is not None and spread in app.spread_type.options:
        app.spread_type.value = spread
    if start is not None:
        app.start_date.value = _coerce_date(start, "Start date")
    if end is not None:
        app.end_date.value = _coerce_date(end, "End date")
    with _UPDATE_LOCK:
        app._refresh_selection_state()
    return {
        "status": app.status.value,
        "source": app.universe_source.value,
        "label": app.universe_input.description,
        "placeholder": app.universe_input.placeholder,
        "fields": [widget.description for widget in app._visible_inputs()],
        "row": HtmlRenderer(panels=_panel_map(app)).render(app.universe_row),
        "ok": True,
    }


def initial_container_html(app=None) -> str:
    app = app or new_app()
    return HtmlRenderer(
        app.status,
        detail_widget=app.detail,
        log_widget=app.log,
        panels=_panel_map(app),
        fields=_field_map(app),
    ).render(app.container)


def _field_map(app) -> dict:
    """``{widget: data-field}`` for the widgets whose label is not unique.

    Both ranked panels carry a box labelled "Display Top" and a button labelled
    "Refresh", so the field names have to be assigned by identity. The side is in
    the name, which is what makes a refresh on one panel leave the other alone.
    """
    fields: dict = {}
    for side, suffix in (("increases", "increases"), ("decreases", "decreases")):
        widget = app.display_top_inputs.get(side)
        if widget is not None:
            fields[widget] = f"display-top-{suffix}"
        button = app.display_top_buttons.get(side)
        if button is not None:
            fields[button] = f"display-top-{suffix}-refresh"
    return fields


def _panel_map(app) -> dict:
    """Element ids for the local-view panels, keyed to the live widgets."""
    panels = {
        "headline-panel": app.headline,
        "bucket-panel": app.bucket_box,
        "change-panel": app.change_box,
        "path-panel": app.path_box,
        "detail-title-panel": app.detail_title,
        "detail-view-panel": app.detail_view,
        "export-panel": app.export_box,
        "export-note-panel": app.export_note,
    }
    panels["universe-row-panel"] = app.universe_row
    return panels


def view_html(app) -> dict:
    """The local-view panels: headline, the charts, and the click detail.

    Every panel is produced by the real controller from frames it already
    holds, so the preview cannot disagree with the Desktop layout about a
    filter, a bucket count, or a selected security.
    """
    renderer = HtmlRenderer(panels=_panel_map(app), fields=_field_map(app))
    return {
        "headline": renderer.render(app.headline),
        "buckets": renderer.render(app.bucket_box),
        "changes": renderer.render(app.change_box),
        "paths": renderer.render(app.path_box),
        "detail_title": renderer.render(app.detail_title),
        "detail_view": renderer.render(app.detail_view),
        "export": renderer.render(app.export_box),
        "export_note": renderer.render(app.export_note),
    }


def current_options(app=None) -> dict:
    """Filter options for the run currently loaded (``(All)`` excluded)."""
    app = app or session_app()
    from fi_spread_movement import config

    options: dict[str, list[str]] = {}
    for label, _column in config.FILTER_COLUMNS:
        widget = app.filters.get(label)
        values = []
        if widget is not None:
            values = [
                str(option)
                for option in widget.options
                if str(option) != config.ALL_FILTER_LABEL
            ]
        options[label] = values
    return options


def apply_view(
    app,
    filters: dict | None = None,
    group: str | None = None,
    selected: str | None = None,
    bucket: str | None = None,
    display_top: dict | None = None,
) -> dict:
    """Apply a local filter / grouping / selection change and redraw.

    ``filters`` maps a filter label (``Currency``, ``Rating``, ``Tenor``) to the
    picked values. An empty list means ``(All)``. ``display_top`` maps a side
    (``increases`` / ``decreases``) to the number of rows that panel draws. Every
    argument here is a view over frames already in memory: nothing reaches the
    request layer, because ``_render_view`` reads ``app._frames`` only.
    """
    from fi_spread_movement import config

    if not app._frames:
        return {"ok": False, "reason": "no run has been loaded yet"}

    for label, _column in config.FILTER_COLUMNS:
        widget = app.filters.get(label)
        if widget is None:
            continue
        picked = None
        if filters and label in filters:
            picked = [str(value) for value in filters[label] or []]
        if picked is None:
            continue
        if not picked:
            widget.value = (config.ALL_FILTER_LABEL,)
            continue
        # A requested value that the new run does not offer is kept as an
        # explicit filter, not dropped. Dropping it would silently turn a
        # narrowed view back into "show everything", which is the fail-open
        # behaviour this app must not have. The view then shows 0 rows, which
        # is visible and correct.
        known = {str(option) for option in widget.options}
        missing = [value for value in picked if value not in known]
        if missing:
            widget.options = [*widget.options, *missing]
        try:
            widget.value = tuple(picked)
        except Exception:
            widget.value = (config.ALL_FILTER_LABEL,)

    if group is not None and group in app.dimension_input.options:
        app.dimension_input.value = group

    if display_top:
        # The same validation the Desktop Refresh button runs, so the preview
        # cannot accept 0 or a non-number that the notebook would refuse.
        for side in ("increases", "decreases"):
            if side not in display_top:
                continue
            value = display_top[side]
            widget = app.display_top_inputs.get(side)
            if widget is not None:
                widget.value = value
            app._apply_display_top(side)

    if bucket is not None:
        # A bucket pick is the same local view the Desktop table click makes: it
        # narrows the two Top 10 charts and never narrows a request. Clicking the
        # bucket that is already picked clears it again, exactly like the grid.
        value = str(bucket).strip()
        app._selected_bucket = (
            None if (not value or value == app._selected_bucket) else value
        )

    with _UPDATE_LOCK:
        if selected is not None:
            # An empty string is an explicit clear: the path chart goes back to
            # its "select a bond" prompt instead of keeping the last line.
            if str(selected).strip():
                app._show_security(str(selected))
            else:
                app._clear_selection()
        app._render_view()
    return {"ok": True, **view_html(app)}


def _coerce_date(value, label: str):
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"{label} is empty.")
    try:
        return date.fromisoformat(text)
    except ValueError:
        raise ValueError(f"{label} is not a calendar date: {text!r}.") from None


def _refused_response(message: str) -> dict:
    """The same shape the app produces for an input it refuses before a request."""
    from fi_spread_movement.app import _environment_markup, _info_box, _phase_markup

    status = (
        f"<p style='margin:2px 0'>{_phase_markup('Refused')} {escape(message)}</p>"
        + _environment_markup("Idle")
    )
    detail = _info_box(
        f"<b>Request not sent.</b> {escape(message)}<br>"
        "Nothing was requested from Bloomberg; fix the input and click Update again.",
        "error",
    )
    return {
        "status": status,
        "detail": detail,
        "log": f'<div class="widget-html">{escape("Refused: " + message)}</div>',
        "ok": False,
    }


def run_update(
    spread: str | None = None,
    start=None,
    end=None,
    index: str | None = None,
    mode: str = "ok",
    app=None,
    source: str | None = None,
    aim: str | None = None,
    bond: str | None = None,
) -> dict:
    """Run one Update through the real controller and return every panel.

    ``mode="failure"`` keeps the request but raises during the merge, which is
    how the app shows attributable per-field diagnostics. ``source`` is the
    universe dropdown; ``index`` is then the typed ticker, and ``aim`` /
    ``bond`` fill the fields that only their own source reads.
    """
    app_module = _app_module()
    app = app or new_app()

    if source is not None:
        if source in app.universe_source.options:
            app.universe_source.value = source
            app._refresh_universe_row()
        else:
            return _refused_response("Unknown universe source: " + str(source))

    spread_label = (spread or app.spread_type.value).strip()
    options = list(app.spread_type.options)
    if spread_label not in options:
        return _refused_response("Unknown spread type: " + spread_label)

    try:
        start_date = _coerce_date(start if start is not None else app.start_date.value, "Start date")
        end_date = _coerce_date(end if end is not None else app.end_date.value, "End date")
    except ValueError as exc:
        return _refused_response(str(exc))

    app.spread_type.value = spread_label
    app.start_date.value = start_date
    app.end_date.value = end_date
    index, aim, bond = _route_single_value(app, index, aim, bond)
    app.index_input.value = "" if index is None else index
    app.aim_input.value = "" if aim is None else aim
    app.bond_input.value = "" if bond is None else bond

    source_key = _source_key(app)

    original_fetch = app_module.fetch_movers
    original_compare = getattr(app_module, "fetch_comparison", None)
    original_merge = app_module.prepare_ranked_movers

    def _fake_fetch(*_a, **_k):
        # The typed value of whichever field the chosen source reads: a Bond run
        # carries its identifier in the Bond box, not in the Index box.
        universe_value = " ".join(str(app.universe_input.value or "").split())
        return placeholder_result(
            spread_label,
            start_date,
            end_date,
            universe_value,
            source=source_key,
            aim=app.aim_input.value,
        )

    app_module.fetch_movers = _fake_fetch
    if original_compare is not None:
        app_module.fetch_comparison = _fake_fetch
    if mode == "failure":

        def _boom(*_a, **_k):
            raise ValueError("synthetic merge failure")

        app_module.prepare_ranked_movers = _boom

    with _UPDATE_LOCK:
        try:
            app._on_update(None)
        finally:
            app_module.fetch_movers = original_fetch
            if original_compare is not None:
                app_module.fetch_comparison = original_compare
            app_module.prepare_ranked_movers = original_merge

        log_html = "".join(
            HtmlRenderer().render(entry) for entry in app.log.entries
        )

    return {
        "status": app.status.value,
        "detail": app.detail.value,
        "log": log_html,
        "ok": True,
        **view_html(app),
    }


# ---------------------------------------------------------------------------
# Page template
# ---------------------------------------------------------------------------

PAGE_STYLE = """
  :root {
    --brand: #1976d2;
    --line: #d0d0d0;
    --label: #555;
    --muted: #666;
    --text: #111;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: #f7f7f7;
    color: var(--text);
    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 13px;
  }
  .banner {
    background: #fff8e1;
    border-bottom: 1px solid #ffe082;
    padding: 8px 16px;
    color: #5d4037;
    line-height: 1.55;
  }
  .banner b { color: #4e342e; }
  .banner.stop { background: #fdecea; border-bottom-color: #e57373; color: #8e2a20; }
  .banner.stop b { color: #7f1d1d; }
  .notebook {
    background: #fff;
    margin: 12px;
    border: 1px solid #e0e0e0;
    border-radius: 2px;
    padding: 10px 14px 16px;
  }
  .cell-prompt { color: #307fc1; font-family: monospace; font-size: 12px; margin-bottom: 10px; }
  .widget-vbox { display: flex; flex-direction: column; align-items: flex-start; gap: 6px; }
  .widget-hbox { display: flex; flex-wrap: wrap; align-items: center; gap: 14px; margin: 2px 0 4px; }
  .widget-row { display: flex; align-items: center; gap: 6px; min-height: 28px; }
  .widget-label { color: var(--label); min-width: 96px; text-align: right; }
  .widget-hbox .widget-label { min-width: 70px; }
  select, input[type="date"], input[type="text"] {
    height: 28px;
    border: 1px solid #ccc;
    border-radius: 2px;
    background: #fff;
    font: inherit;
    padding: 0 6px;
  }
  select { min-width: 110px; }
  input[type="text"] { min-width: 168px; }
  .widget-button {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    height: 28px;
    padding: 0 12px;
    border: 1px solid #ccc;
    border-radius: 2px;
    background: #fff;
    font: inherit;
    color: var(--text);
    cursor: pointer;
  }
  .widget-button.mod-primary { background: var(--brand); border-color: var(--brand); color: #fff; }
  .widget-button[disabled] { opacity: .65; cursor: progress; }
  .widget-icon { font-size: 14px; line-height: 1; }
  .widget-html h2 { font-size: 20px; margin: 4px 0 2px; }
  .widget-html h3 { font-size: 16px; margin: 14px 0 4px; font-weight: 700; }
  .widget-html h4 { font-size: 13px; margin: 12px 0 2px; }
  .widget-html p { margin: 4px 0; line-height: 1.55; max-width: 96ch; }
  #status-panel {
    width: 100%;
    margin: 4px 0 0;
    padding: 5px 10px;
    border: 1px solid var(--line);
    background: #fcfcfc;
  }
  #status-panel p { margin: 2px 0; }
  #detail-panel { width: 100%; }
  #log-panel {
    width: 100%;
    margin: 2px 0 0;
    font-family: "SFMono-Regular", Menlo, Consolas, monospace;
    font-size: 12px;
    color: #444;
  }
  .widget-output {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    width: 100%;
    margin-top: 8px;
  }
  .widget-output .widget-html { width: 100%; }
  /* Desktop Tab: a button bar, then one visible panel at a time. */
  .widget-tabs { width: 100%; }
  .widget-tabbar {
    display: flex;
    gap: 4px;
    border-bottom: 1px solid #d0d0d0;
    margin-bottom: 8px;
  }
  .widget-tab {
    appearance: none;
    border: 1px solid #d0d0d0;
    border-bottom: none;
    background: #f2f2f2;
    color: #444;
    padding: 6px 14px;
    font: inherit;
    cursor: pointer;
    border-radius: 2px 2px 0 0;
  }
  .widget-tab.active {
    background: #fff;
    color: #111;
    font-weight: 600;
    margin-bottom: -1px;
  }
  .widget-tab-panel { width: 100%; }
  table { border-collapse: collapse; font-size: 12px; margin: 0 0 10px; }
  table th, table td {
    height: 26px;
    padding: 0 10px;
    border-right: 1px solid #eee;
    border-bottom: 1px solid #eee;
    text-align: left;
    white-space: nowrap;
  }
  table th { background: #f5f5f5; font-weight: 600; border-bottom: 1px solid #ddd; }
  table tr:nth-child(even) td { background: #fafafa; }
  table.dataframe { border: 1px solid #e0e0e0; }
  .preview-only {
    margin: 0 12px 20px;
    padding: 8px 12px;
    border: 1px dashed var(--line);
    background: #fbfbfb;
    color: var(--muted);
    border-radius: 2px;
  }
  .preview-only label { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }
  .preview-only b { color: #444; }
  .widget-panel { width: 100%; }
  /* A chart panel must stretch: the notebook VBox aligns children to
     flex-start, which otherwise shrinks an SVG to its intrinsic minimum and
     squashes the whole chart with it. */
  .widget-panel .widget-vbox { align-items: stretch; width: 100%; }
  .widget-select-multiple select { min-width: 0; }
  /* Same arrangement as the Desktop widget and as the FI Index Change
     preview: the description sits to the left of a box that fills the fixed
     layout width (300 for Country/Sector, 220 for the other three), and
     ``rows`` sets the visible row count. The box height therefore follows the
     row count instead of a CSS height that would disagree with the widget. */
  .widget-select-multiple {
    display: inline-flex;
    align-items: flex-start;
    gap: 6px;
    box-sizing: border-box;
  }
  .widget-select-multiple .widget-label {
    min-width: 0;
    text-align: left;
    padding-top: 4px;
    flex: 0 0 auto;
    width: auto;
  }
  /* A row carrying the dimension filters is taller than one control line. Its
     children line up at the top, so the Group by dropdown sits level with the
     filter descriptions instead of floating in the middle of the row. The gap
     is the same 8 px the Desktop widgets carry as a right margin, so the row
     is exactly CHART_WIDTH_PX wide and lines up under the charts. */
  .widget-hbox.filters-row { align-items: flex-start; gap: 8px; }
  .widget-hbox.filters-row select { min-width: 0; }
  .widget-select-multiple select {
    flex: 1 1 auto;
    min-width: 0;
    width: 100%;
    height: auto;
    box-sizing: border-box;
    padding: 2px;
    font-size: 12px;
    line-height: 14px;
  }
  /* The chart card keeps the fixed chart width; the HBox that carries it is a
     plain flex row, so without this the card would shrink to the intrinsic SVG
     minimum and the preview would show a narrower chart than the notebook. */
  .widget-hbox > .widget-html { flex: 0 0 auto; }
  .preview-chart {
    width: 100%;
    max-width: 100%;
    margin: 6px 0 12px;
    padding: 6px 8px;
    background: #0d1117;
    border-radius: 4px;
  }
  .preview-chart-svg { width: 100%; height: auto; display: block; }
"""


def document(title: str, body: str, script: str = "") -> str:
    """Wrap page content in the shared shell so both front ends look identical."""
    return (
        "<!DOCTYPE html>\n"
        '<html lang="en">\n'
        "<head>\n"
        '<meta charset="utf-8">\n'
        # The page names the code it was rendered from. A tab open across an edit
        # is then detectable instead of silently reliable-looking.
        f'<meta name="preview-build" content="{escape(build_id())}">\n'
        f"<title>{escape(title)}</title>\n"
        f"<style>{PAGE_STYLE}</style>\n"
        "</head>\n"
        "<body>\n"
        f"{body}\n"
        f"{BUILD_CHECK_SCRIPT}\n"
        f"{script}\n"
        "</body>\n"
        "</html>\n"
    )


BUILD_CHECK_SCRIPT = """<script>
// A page that was rendered by older code must not pretend to be current.
// Before the identity-keyed data-field fix, every rendered button carried
// data-field="update", so a Display Top "Refresh" ran a full Update: the box
// went back to 10 and nothing appeared to happen. Say so instead of leaving an
// operator to guess. The static page has no server, so a failed fetch is silent.
(function () {
  var meta = document.querySelector('meta[name="preview-build"]');
  var mine = meta && meta.getAttribute('content');
  if (!mine || mine === 'unknown') return;
  var shown = false;
  function check() {
    if (shown) return;
    fetch('/api/meta', { cache: 'no-store' })
      .then(function (response) { return response.ok ? response.json() : null; })
      .then(function (data) {
        if (!data || !data.build || data.build === mine || shown) return;
        shown = true;
        var note = document.createElement('p');
        note.setAttribute('style', 'color:#c62828;font-weight:600;margin:4px 0');
        note.textContent = 'This page was rendered by older code (page ' + mine +
          ', server ' + data.build + '). Reload it with Cmd+Shift+R before ' +
          'using the controls: on this copy a Display Top Refresh would run Update.';
        var panel = document.getElementById('status-panel');
        if (panel) panel.prepend(note); else document.body.prepend(note);
      })
      .catch(function () { /* static copy: nothing to compare against */ });
  }
  // Once at load, then on return to the tab and on a slow poll, because the
  // case that matters is a page already open when the code changed.
  check();
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') check();
  });
  setInterval(check, 10000);
})();
</script>"""


def banner_html() -> str:
    """The placeholder notice every front end shows."""
    install_stubs()
    from fi_spread_movement import config

    return (
        '<div class="banner">\n'
        "  <b>Local layout preview only.</b> The panels are produced by the real\n"
        "  <code>app.py</code> and <code>engine.py</code> in this Mac's Python process.\n"
        "  <code>bql</code> is never imported, so no Bloomberg request can run. Every identifier\n"
        "  and number is a <b>placeholder</b> that varies with the index, spread type and dates;\n"
        "  it is not market data and this page is not part of the BQuant upload.\n"
        "  The Index field starts empty. The recorded example is\n"
        f"  <b>{escape(config.DEFAULT_INDEX)}</b>.\n"
        f"  Top <b>{config.TOP_N}</b>.\n"
        "</div>"
    )


def notebook_html(container: str) -> str:
    return (
        '<div class="notebook">\n'
        '  <div class="cell-prompt">In [1]:</div>\n'
        f"  {container}\n"
        "</div>"
    )


PAGE_SCRIPT = """<script>
  var MODE = "ok";

  function field(name) {
    return document.querySelector('[data-field="' + name + '"]');
  }

  function phaseMarkup(phase) {
    var color = "";
    if (phase === "Idle" || phase === "Please Click Update" || phase === "Refused") {
      color = "#c62828";
    } else if (phase === "Updated") {
      color = "#1b7f37";
    }
    if (!color) return "<b>" + phase + "</b>";
    return '<b style="color:' + color + '">' + phase + "</b>";
  }

  function environmentMarkup(activity) {
    var color = activity === "Processing" ? "#c62828" : "#1b7f37";
    return '<p style="margin:2px 0;color:' + color + '">Environment: ' +
      activity + "</p>";
  }

  function setStatus(phase, detail, activity) {
    document.getElementById("status-panel").innerHTML =
      '<p style="margin:2px 0">' + phaseMarkup(phase) + " " + (detail || "") +
      "</p>" + environmentMarkup(activity || "Idle");
  }

  function showError(text) {
    setStatus("Error", text, "Idle");
  }

  function refresh() {
    var button = field("update");
    var source = field("source");
    var index = field("index");
    var spread = field("spread");
    var start = field("start");
    var end = field("end");
    if (!button || !source || !spread || !start || !end) {
      showError("The controls were not found on this page.");
      return;
    }
    button.disabled = true;
    setStatus("Loading", "Running the preview Update&hellip;", "Processing");
    var payload = JSON.stringify({
      index: index ? index.value : "",
      aim: (field("aim") || {}).value || "",
      bond: (field("bond") || {}).value || "",
      source: source.value,
      spread: spread.value,
      start: start.value,
      end: end.value,
      mode: MODE
    });
    fetch("/api/update", {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
      body: payload
    })
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.json();
      })
      .then(function (data) {
        document.getElementById("status-panel").innerHTML = data.status;
        document.getElementById("detail-panel").innerHTML = data.detail || "";
        document.getElementById("log-panel").innerHTML = data.log || "";
        put("headline-panel", data.headline);
        put("bucket-panel", data.buckets);
        put("change-panel", data.changes);
        put("path-panel", data.paths);
        put("detail-title-panel", data.detail_title);
        put("detail-view-panel", data.detail_view);
        put("export-panel", data.export);
        put("export-note-panel", data.export_note);
        // The pick lists are rebuilt from the new run, so the page reloads its
        // options from the server rather than keeping the previous filters.
        return fetch("/api/options", { cache: "no-store" })
          .then(function (response) { return response.ok ? response.json() : null; })
          .then(function (options) {
            if (!options) return;
            putOptions("filter-country", options.Country);
            putOptions("filter-sector", options.Sector);
            putOptions("filter-tenor", options.Tenor);
            putOptions("filter-rating", options.Rating);
            putOptions("filter-currency", options.Currency);
          });
      })
      .catch(function (error) {
        showError(
          "The preview server did not answer: " + String(error.message) +
          ". Start it with python3 preview/server.py and open http://localhost:8775/."
        );
      })
      .then(function () {
        button.disabled = false;
      });
  }

  document.addEventListener("change", function (event) {
    var target = event.target;
    if (!target || !target.dataset || !target.dataset.field) return;
    if (target.dataset.field === "update") return;
    // A control edit is local: the server only re-states the status bar and
    // never builds a request.
    var body = {
      index: (field("index") || {}).value || "",
      aim: (field("aim") || {}).value || "",
      bond: (field("bond") || {}).value || "",
      source: (field("source") || {}).value || "",
      spread: (field("spread") || {}).value || "",
      start: (field("start") || {}).value || "",
      end: (field("end") || {}).value || "",
      mode: "selection"
    };
    fetch("/api/update", {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })
      .then(function (response) { return response.ok ? response.json() : null; })
      .then(function (data) {
        if (!data) return;
        // The real controller rebuilds the header row for the chosen source,
        // so the page swaps in the row the server rendered rather than
        // guessing which inputs that source reads.
        if (data.row) {
          put("universe-row-panel", data.row);
        } else if (data.label) {
          var input = field("index");
          var row = input && input.parentElement;
          var rowLabel = row && row.querySelector(".widget-label");
          if (rowLabel) rowLabel.textContent = data.label;
          if (input && data.placeholder != null) input.placeholder = data.placeholder;
        }
        if (data.status) {
          document.getElementById("status-panel").innerHTML = data.status;
        }
      })
      .catch(function () {
        /* The bar keeps its last state; Update still reports any real problem. */
      });
  });

  // --- Local view: filters, grouping, and click-to-inspect -----------------
  // This block posts to /api/view, which redraws from the frames the server
  // already holds. It never posts to /api/update, so a filter cannot request
  // anything from Bloomberg.

  function pickedValues(name) {
    var node = field(name);
    if (!node) return null;
    if (node.tagName !== "SELECT" || !node.multiple) {
      return node.value ? [node.value] : [];
    }
    var picked = [];
    for (var i = 0; i < node.options.length; i += 1) {
      if (node.options[i].selected && node.options[i].value !== "(All)") {
        picked.push(node.options[i].value);
      }
    }
    return picked;
  }

  function applyView(extra) {
    var body = {
      filters: {
        Country: pickedValues("filter-country"),
        Sector: pickedValues("filter-sector"),
        Tenor: pickedValues("filter-tenor"),
        Rating: pickedValues("filter-rating"),
        Currency: pickedValues("filter-currency")
      },
      group: (field("group") || {}).value || null
    };
    // The two Display Top boxes are sent unless the caller names its own side.
    // A Refresh sends only the panel it belongs to, so a value typed in the
    // other box but not refreshed there cannot be applied by this click.
    var displayTop = {};
    if (!(extra && extra.display_top)) {
      var sides = ["increases", "decreases"];
      for (var s = 0; s < sides.length; s += 1) {
        var box = field("display-top-" + sides[s]);
        if (box) displayTop[sides[s]] = box.value;
      }
      if (displayTop.increases != null || displayTop.decreases != null) {
        body.display_top = displayTop;
      }
    }
    if (extra) {
      for (var key in extra) {
        if (Object.prototype.hasOwnProperty.call(extra, key)) body[key] = extra[key];
      }
    }
    fetch("/api/view", {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })
      .then(function (response) {
        if (response.ok) return response.json();
        // A 400/500 carries no panels, but it must not read as "the box is
        // dead". The status bar is the only surface the page always has.
        throw new Error("HTTP " + response.status);
      })
      .then(function (data) {
        if (!data || data.ok === false) {
          // The view was refused: the server no longer holds the run, which is
          // what a module reload does. Say so and name the fix, because a
          // silent return here is indistinguishable from a broken page.
          var reason = (data && data.reason) ||
            "the preview server refused the view change.";
          setStatus(
            "Please Click Update",
            reason + " Click Update to load the run again; this page keeps the " +
            "panels from the previous run until then.",
            "Idle"
          );
          return;
        }
        put("headline-panel", data.headline);
        put("bucket-panel", data.buckets);
        put("change-panel", data.changes);
        put("path-panel", data.paths);
        put("detail-title-panel", data.detail_title);
        put("detail-view-panel", data.detail_view);
        put("export-panel", data.export);
        put("export-note-panel", data.export_note);
      })
      .catch(function (error) {
        // Reaching this means the view could not be drawn at all, so the reason
        // goes on the status bar instead of an empty panel with no explanation.
        showError(
          "The local view change could not be applied: " + String(error.message) +
          ". Nothing was requested from Bloomberg; click Update to reload the run."
        );
      });
  }

  function put(id, html) {
    var node = document.getElementById(id);
    if (node && html != null) node.innerHTML = html;
  }

  // Rebuild one filter's options from the run that just loaded. The empty
  // selection means "(All)": the controller always starts a filter there.
  function putOptions(name, values) {
    var node = field(name);
    if (!node || !values) return;
    while (node.options.length) node.remove(0);
    var all = document.createElement("option");
    all.value = "(All)";
    all.text = "(All)";
    all.selected = true;
    node.appendChild(all);
    for (var i = 0; i < values.length; i += 1) {
      var option = document.createElement("option");
      option.value = values[i];
      option.text = values[i];
      node.appendChild(option);
    }
  }

  document.addEventListener("change", function (event) {
    var target = event.target;
    if (!target || !target.dataset) return;
    var name = target.dataset.field || "";
    if (name.indexOf("filter-") === 0 || name === "group") applyView(null);
  });

  // Clicking a bar or a point selects that security in the detail panel. The
  // SVG carries data-value on each bar label, so the click needs no plotting
  // library on this page.
  document.addEventListener("click", function (event) {
    var node = event.target.closest("[data-security]");
    if (!node) return;
    var identifier = node.getAttribute("data-security");
    if (identifier) applyView({ selected: identifier });
  });

  // A bucket row narrows the two Top 10 charts and tables below to that bucket.
  document.addEventListener("click", function (event) {
    var node = event.target.closest("[data-bucket]");
    if (!node) return;
    var value = node.getAttribute("data-bucket");
    if (value) applyView({ bucket: value });
  });

  document.addEventListener("click", function (event) {
    if (event.target.closest('[data-field="update"]')) refresh();
  });

  // A Display Top Refresh redraws from the frames already in memory, with the
  // value currently typed in that panel's own box. It is not Update: no request
  // is built, and the other panel keeps both its own count and its own value.
  document.addEventListener("click", function (event) {
    var button = event.target.closest('[data-field$="-refresh"]');
    if (!button) return;
    var name = button.getAttribute("data-field") || "";
    var side = name.indexOf("display-top-decreases") === 0 ? "decreases" : "increases";
    var box = field("display-top-" + side);
    var sent = {};
    if (box) sent[side] = box.value;
    applyView({ display_top: sent });
  });

  // --- Tabs: Main / Export Excel ------------------------------------------
  // The panels are rendered by the real controller; this only switches which
  // one is visible, exactly as the Desktop Tab widget does.
  document.addEventListener("click", function (event) {
    var button = event.target.closest(".widget-tab");
    if (!button) return;
    var index = button.getAttribute("data-tab");
    var tabs = button.closest(".widget-tabs");
    if (!tabs) return;
    var buttons = tabs.querySelectorAll(".widget-tab");
    for (var i = 0; i < buttons.length; i += 1) {
      buttons[i].className = "widget-tab" +
        (buttons[i] === button ? " active" : "");
    }
    var panels = tabs.querySelectorAll("[data-tab-panel]");
    for (var j = 0; j < panels.length; j += 1) {
      panels[j].hidden = panels[j].getAttribute("data-tab-panel") !== index;
    }
  });

  var failure = document.getElementById("simulate-failure");
  if (failure) {
    failure.addEventListener("change", function (event) {
      MODE = event.target.checked ? "failure" : "ok";
    });
  }

  if (location.protocol === "file:") {
    var warning = document.getElementById("file-warning");
    if (warning) warning.hidden = false;
  }
</script>"""


def page_html() -> str:
    """The interactive page served by ``server.py``."""
    app = new_app()
    body = (
        '<div class="banner stop" id="file-warning" hidden>\n'
        "  <b>Update cannot run on this page.</b> It was opened as a local file, so there is no\n"
        "  Python process behind it. Run <code>python3 preview/server.py</code> and open\n"
        "  <code>http://localhost:8775/</code> instead.\n"
        "</div>\n"
        f"{banner_html()}\n"
        f"{notebook_html(initial_container_html(app))}\n"
        '<div class="preview-only">\n'
        "  <b>Preview only — not in the app.</b>\n"
        '  <label><input type="checkbox" id="simulate-failure">\n'
        "    Simulate a merge failure after the request (shows the diagnostics path)</label>\n"
        "</div>"
    )
    return document("FI Spread Movement Monitoring — interface preview", body, PAGE_SCRIPT)
