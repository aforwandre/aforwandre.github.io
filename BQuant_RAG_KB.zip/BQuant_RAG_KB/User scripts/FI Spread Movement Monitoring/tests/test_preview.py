"""Local checks for the preview front ends. No BQL is executed.

The preview installs its own ``ipywidgets`` / ``IPython.display`` stubs, so every
check that touches it runs in a subprocess. ``tests/test_app.py`` owns the stubs
in this interpreter and must not be disturbed.
"""

from __future__ import annotations

import json
import re
import socket
import subprocess
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PREVIEW_DIR = PROJECT_ROOT / "preview"
OUTPUT = PREVIEW_DIR / "interface.html"


def _python(*args: str, timeout: int = 180) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, *args],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


class StaticPreviewTests(unittest.TestCase):
    def test_preview_is_in_sync_with_the_app(self):
        result = _python(str(PREVIEW_DIR / "build_preview.py"), "--check")
        self.assertEqual(
            result.returncode,
            0,
            msg=(
                "preview/interface.html is stale. Run "
                f"python3 preview/build_preview.py\n{result.stdout}{result.stderr}"
            ),
        )

    def test_static_page_shows_the_real_panels(self):
        html = OUTPUT.read_text(encoding="utf-8")
        self.assertIn("Top 10 increases", html)
        self.assertIn("Top 10 decreases", html)
        # The validation table was removed from the layout: the bounded series
        # check still runs, but it reports to the step log instead of a panel.
        self.assertNotIn("Effective-date and change-arithmetic validation", html)
        self.assertIn("Daily spread observations", html)
        self.assertIn("Country buckets", html)
        self.assertIn("Request log", html)
        self.assertIn("Static copy", html)
        # The descriptor / series receipt is a log line now, not a table in the
        # layout: the top of the page carries data only.
        self.assertIn("Country: returned", html)
        self.assertNotIn("Descriptor and series status", html)

    def test_option_pairs_show_their_label_not_the_tuple(self):
        # The Export tab's Data box is built from (label, value) pairs. Printing
        # the pair put "('Top 10 increases', 'increases')" in the box while the
        # notebook shows "Top 10 increases", so the pair is reduced to its label
        # and the option value carries the key.
        html = OUTPUT.read_text(encoding="utf-8")
        self.assertNotIn("('Top 10 increases'", html)
        self.assertNotIn("&#x27;Top 10 increases&#x27;", html)
        self.assertIn('<option selected value="increases">Top 10 increases</option>', html)

    def test_static_page_states_that_values_are_placeholders(self):
        html = OUTPUT.read_text(encoding="utf-8")
        self.assertIn("Local layout preview only", html)
        self.assertIn("placeholder", html)
        self.assertIn("not part of the BQuant upload", html)

    def test_no_page_contains_a_bloomberg_request_path(self):
        for path in (OUTPUT, PREVIEW_DIR / "server.py", PREVIEW_DIR / "preview_core.py", PREVIEW_DIR / "build_preview.py"):
            text = path.read_text(encoding="utf-8")
            for token in ("import bql", "bq.execute", "bql.Request", "load_on_start"):
                self.assertNotIn(token, text, msg=f"{path.name} contains {token}")

    def test_rebuild_is_deterministic(self):
        html = OUTPUT.read_text(encoding="utf-8")
        result = _python(str(PREVIEW_DIR / "build_preview.py"))
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertEqual(OUTPUT.read_text(encoding="utf-8"), html)


class LiveServerTests(unittest.TestCase):
    """Start the real preview server on a spare port and drive it over HTTP."""

    @classmethod
    def setUpClass(cls):
        cls.port = _free_port()
        cls.process = subprocess.Popen(
            [sys.executable, str(PREVIEW_DIR / "server.py"), "--port", str(cls.port)],
            cwd=str(PROJECT_ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        cls.base = f"http://127.0.0.1:{cls.port}"
        deadline = time.time() + 60
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(cls.base + "/api/meta", timeout=2):
                    return
            except (urllib.error.URLError, ConnectionError, OSError):
                if cls.process.poll() is not None:
                    out, err = cls.process.communicate()
                    raise AssertionError(f"server exited early\n{out}\n{err}")
                time.sleep(0.25)
        raise AssertionError("preview server did not start")

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        try:
            cls.process.communicate(timeout=15)
        except subprocess.TimeoutExpired:
            cls.process.kill()
            cls.process.communicate()

    def _get(self, path: str):
        with urllib.request.urlopen(self.base + path, timeout=30) as response:
            return response.status, response.read().decode("utf-8")

    def _post(self, body: dict, path: str = "/api/update") -> dict:
        data = json.dumps(body).encode("utf-8")
        request = urllib.request.Request(
            self.base + path,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))

    def _view(self, body: dict) -> dict:
        return self._post(body, path="/api/view")

    def _update(self, payload: dict) -> dict:
        # ``source`` is always sent, exactly as the page does: the preview server
        # keeps one session app, so a payload that omitted it would silently reuse
        # the previous run's universe source.
        return self._post(
            {"source": "Index", "index": "LEGATRUU Index", "mode": "ok", **payload}
        )

    def test_page_carries_the_real_controls(self):
        status, html = self._get("/")
        self.assertEqual(status, 200)
        for marker in ("data-field=\"update\"", "data-field=\"index\"",
                       "data-field=\"source\"", "data-field=\"spread\"",
                       "data-field=\"start\"", "data-field=\"end\"",
                       "status-panel", "bucket-panel", "change-panel",
                       "path-panel"):
            self.assertIn(marker, html)
        self.assertIn('data-field="index"', html)
        self.assertIn('placeholder="LEGATRUU Index"', html)
        self.assertIn('value=""', html)
        self.assertIn("starts empty", html)

    def test_the_page_carries_no_version_label(self):
        html = OUTPUT.read_text(encoding="utf-8")
        for token in ("Validation run", "(V1)", "not production approval", "Stamp"):
            self.assertNotIn(token, html, msg=f"page still prints {token!r}")

    def test_update_returns_the_engine_tables(self):
        result = self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        self.assertIn(">Updated<", result["status"])
        self.assertIn("Environment: Idle", result["status"])
        self.assertIn("Spread: OAS", result["detail"])
        # The two ranked tables are panels under their own charts now.
        self.assertIn("Top 10 increases", result["changes"])
        self.assertIn("Top 10 decreases", result["changes"])
        # The two diverging bucket charts and the full bucket table are panels
        # now; the retired validation table is not rendered anywhere.
        self.assertIn("<svg", result["buckets"])
        self.assertIn("buckets</h4>", result["buckets"])
        self.assertIn("Increase OAS", result["buckets"])
        self.assertNotIn("Effective-date and change-arithmetic validation", result["buckets"])
        self.assertNotIn("Request log", result["changes"])
        # The daily table lives under the path chart.
        self.assertIn("Daily spread observations", result["paths"])

    def test_empty_index_is_refused(self):
        result = self._update(
            {"index": "", "spread": "OAS", "start": "2026-10-23", "end": "2026-10-30"}
        )
        self.assertIn("Refused", result["status"])
        self.assertIn("empty", result["status"])
        self.assertIn("Environment: Idle", result["status"])
        self.assertIn("Request not sent", result["detail"])
        self.assertIn("No rows to list", result["buckets"])

    def test_index_choice_changes_the_numbers(self):
        first = self._update(
            {"index": "LEGATRUU Index", "spread": "OAS", "start": "2026-10-23", "end": "2026-10-30"}
        )
        second = self._update(
            {"index": "LF98TRUU Index", "spread": "OAS", "start": "2026-10-23", "end": "2026-10-30"}
        )
        self.assertIn("Universe: LF98TRUU Index", second["detail"])
        self.assertIn("LF98TRUU Index", second["status"])
        self.assertNotEqual(first["buckets"], second["buckets"])

    def test_aim_account_is_a_second_universe_source(self):
        index_run = self._update(
            {"source": "Index", "index": "LEGATRUU Index", "spread": "OAS",
             "start": "2026-10-23", "end": "2026-10-30"}
        )
        aim_run = self._update(
            {"source": "AIM account", "index": "ABC123", "spread": "OAS",
             "start": "2026-10-23", "end": "2026-10-30"}
        )
        self.assertIn("AIM account ABC123", aim_run["status"])
        self.assertIn("whole-account holdings", aim_run["detail"])
        self.assertIn("with_params", aim_run["detail"])
        self.assertNotEqual(index_run["buckets"], aim_run["buckets"])

    def test_aim_blank_code_is_refused_before_the_fetch(self):
        result = self._update(
            {"source": "AIM account", "index": "", "spread": "OAS",
             "start": "2026-10-23", "end": "2026-10-30"}
        )
        self.assertIn("Refused", result["status"])
        self.assertIn("AIM account is empty", result["status"])
        self.assertIn("No rows to list", result["buckets"])

    def test_aim_code_with_a_space_is_refused(self):
        result = self._update(
            {"source": "AIM account", "index": "ABC 123", "spread": "OAS",
             "start": "2026-10-23", "end": "2026-10-30"}
        )
        self.assertIn("one account code", result["status"])

    def test_source_selection_relabels_the_input(self):
        result = self._post({"mode": "selection", "source": "AIM account", "index": ""})
        self.assertEqual(result["label"], "AIM code")
        self.assertEqual(result["placeholder"], "ABC123")

        result = self._post({"mode": "selection", "source": "Index", "index": ""})
        self.assertEqual(result["label"], "Index")
        self.assertEqual(result["placeholder"], "LEGATRUU Index")

    def test_spread_choice_changes_the_numbers(self):
        oas = self._update({"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30"})
        z = self._update({"spread": "Z-Spread", "start": "2026-10-23", "end": "2026-10-30"})
        self.assertIn("Spread: Z-Spread", z["detail"])
        self.assertIn("Z-Spread", z["status"])
        self.assertNotEqual(oas["buckets"], z["buckets"])

    def test_dates_change_the_numbers(self):
        first = self._update({"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30"})
        second = self._update({"spread": "OAS", "start": "2026-10-16", "end": "2026-10-30"})
        self.assertNotEqual(first["buckets"], second["buckets"])

    def test_invalid_window_is_blocked_before_the_fetch(self):
        result = self._update({"spread": "OAS", "start": "2026-10-30", "end": "2026-10-23"})
        self.assertIn("earlier than end date", result["status"])
        self.assertIn("No rows to list", result["buckets"])

    def test_window_cap_and_future_date_are_reported(self):
        wide = self._update({"spread": "OAS", "start": "2026-01-01", "end": "2026-10-30"})
        self.assertIn("capped at", wide["status"])
        future = self._update({"spread": "OAS", "start": "2026-10-20", "end": "2099-01-01"})
        self.assertIn("future", future["status"])

    def test_unknown_spread_is_refused(self):
        result = self._update({"spread": "BOGUS_SPREAD", "start": "2026-10-23", "end": "2026-10-30"})
        self.assertIn("Unknown spread type", result["status"])
        # A refused input answers with the status and the detail only: the
        # panels are not rebuilt from a run that never happened.
        self.assertNotIn("buckets", result)

    def test_failure_keeps_the_diagnostics(self):
        result = self._update(
            {"spread": "I-Spread", "start": "2026-10-23", "end": "2026-10-30", "mode": "failure"}
        )
        self.assertIn("synthetic merge failure", result["status"])
        self.assertIn("Environment: Idle", result["status"])
        self.assertIn("Requests executed before the error", result["detail"])
        # The successful per-field receipt is request metadata, so it stays off
        # the page body and is offered in the Export Excel tab instead.
        self.assertNotIn("Name: returned", result["log"])
        self.assertIn("Request detail", result["export_note"])
        self.assertNotIn("Descriptor and series status", result["detail"])

    def test_bad_payloads_are_rejected(self):
        request = urllib.request.Request(
            self.base + "/api/update",
            data=b"not json",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as caught:
            urllib.request.urlopen(request, timeout=30)
        self.assertEqual(caught.exception.code, 400)

    def test_control_edit_after_a_load_asks_for_update(self):
        loaded = self._update(
            {"spread": "Z-Spread", "start": "2026-10-23", "end": "2026-10-30"}
        )
        self.assertIn("Updated", loaded["status"])
        # A control edit is local: it re-states the bar and builds no request.
        edited = self._post(
            {
                "source": "Index",
                "index": "LF98TRUU Index",
                "spread": "OAS",
                "start": "2026-10-23",
                "end": "2026-10-30",
                "mode": "selection",
            }
        )
        self.assertIn("Please Click Update", edited["status"])
        self.assertIn("Environment: Idle", edited["status"])

    def test_control_edit_before_a_load_is_ignored_by_the_controller(self):
        # The no-load branch is covered in tests/test_app.py, where a fresh app is
        # cheap. Here only the ping-pong shape is checked: a selection call always
        # answers with a status bar and never with a results panel.
        edited = self._post(
            {"index": "", "spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "selection"}
        )
        self.assertIn("Environment:", edited["status"])
        self.assertNotIn("results", edited)

    def test_unknown_route_is_404(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            urllib.request.urlopen(self.base + "/nope", timeout=30)
        self.assertEqual(caught.exception.code, 404)

    def test_page_carries_the_filter_and_chart_panels(self):
        status, html = self._get("/")
        self.assertEqual(status, 200)
        for marker in ("filter-currency", "filter-rating", "filter-tenor",
                       "data-field=\"group\"", "headline-panel", "bucket-panel",
                       "change-panel", "path-panel", "detail-title-panel",
                       "detail-view-panel"):
            self.assertIn(marker, html, msg=marker)

    def test_update_returns_the_chart_panels(self):
        result = self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        for key in ("headline", "buckets", "changes", "paths", "detail_title", "detail_view"):
            self.assertIn(key, result, msg=key)
        self.assertIn("<svg", result["buckets"])
        # The path chart draws the selected bond only, so with nothing selected
        # it carries the prompt instead of a plot of every candidate.
        self.assertIn("Select a bond to view its spread path", result["paths"])
        self.assertIn("mover(s) charted", result["headline"])

    def test_selecting_a_bond_draws_one_path_and_clearing_restores_the_prompt(self):
        self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        identifier = "DUMMYBOND001"
        selected = self._view({"selected": identifier})
        self.assertTrue(selected["ok"])
        self.assertIn("<svg", selected["paths"])
        self.assertEqual(selected["paths"].count("<polyline"), 1)
        self.assertIn(identifier, selected["paths"])

        cleared = self._view({"selected": ""})
        self.assertTrue(cleared["ok"])
        self.assertNotIn("<polyline", cleared["paths"])
        self.assertIn("Select a bond to view its spread path", cleared["paths"])

    def test_options_lists_the_returned_values_without_the_all_marker(self):
        self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        status, body = self._get("/api/options")
        self.assertEqual(status, 200)
        options = json.loads(body)
        self.assertIn("Currency", options)
        self.assertNotIn("(All)", options["Currency"])
        self.assertTrue(options["Currency"])

    def test_a_filter_narrows_the_view_without_a_fetch(self):
        loaded = self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        self.assertIn("no filter", loaded["headline"])
        narrowed = self._view(
            {"filters": {"Currency": ["EUR"], "Rating": [], "Tenor": []}, "group": "Currency"}
        )
        self.assertTrue(narrowed["ok"])
        self.assertIn("1 filter(s) applied", narrowed["headline"])
        self.assertIn("grouped by <b>Currency</b>", narrowed["headline"])
        self.assertIn("<svg", narrowed["buckets"])

    def test_a_filter_that_matches_nothing_empties_the_charts(self):
        self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        narrowed = self._view({"filters": {"Currency": ["ZZZ"]}})
        self.assertTrue(narrowed["ok"])
        self.assertIn("<b>0</b> mover(s) charted", narrowed["headline"])
        self.assertIn("No bucket to chart", narrowed["buckets"])

    def test_selecting_a_security_shows_its_row(self):
        self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        selected = self._view({"selected": "DUMMYBOND003"})
        self.assertTrue(selected["ok"])
        self.assertIn("Selected security", selected["detail_title"])
        self.assertIn("DUMMYBOND003", selected["detail_view"])

    def test_a_bucket_click_scopes_the_ranked_tables_and_clicks_again_clears(self):
        loaded = self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        self.assertIn("<b>19</b> mover(s) charted", loaded["headline"])
        scoped = self._view({"bucket": "United States", "group": "Country"})
        self.assertTrue(scoped["ok"])
        self.assertIn("bucket <b>United States</b>", scoped["headline"])
        self.assertNotIn("<b>19</b> mover(s) charted", scoped["headline"])
        self.assertLess(
            scoped["changes"].count("data-security="),
            loaded["changes"].count("data-security="),
        )
        # Clicking the bucket that is already picked is a release, not a no-op.
        cleared = self._view({"bucket": "United States", "group": "Country"})
        self.assertNotIn("bucket <b>", cleared["headline"])
        self.assertIn("<b>19</b> mover(s) charted", cleared["headline"])

    def test_a_bucket_row_reaches_the_page_script(self):
        # The bucket table carries the attribute the page listens for, otherwise
        # the click would land on a table that looks clickable and does nothing.
        loaded = self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        self.assertIn('data-bucket="', loaded["buckets"])
        self.assertIn('data-security="', loaded["changes"])
        _, html = self._get("/")
        self.assertIn('closest("[data-bucket]")', html)
        self.assertIn('closest("[data-security]")', html)

    def test_a_view_before_any_load_is_refused_politely(self):
        # A fresh server has no frames; the answer says so instead of raising.
        result = self._view({"filters": {"Currency": ["EUR"]}})
        self.assertIn("ok", result)

    def test_a_view_with_a_bad_filters_shape_is_a_400(self):
        self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        data = json.dumps({"filters": "EUR"}).encode("utf-8")
        request = urllib.request.Request(
            self.base + "/api/view",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as caught:
            urllib.request.urlopen(request, timeout=30)
        self.assertEqual(caught.exception.code, 400)

    def test_a_display_top_refresh_narrows_only_that_panel(self):
        # The served page must honour the box and redraw locally, with the two
        # panels independent. A page that ignored the value would look wired and
        # change nothing.
        loaded = self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        narrowed = self._view({"display_top": {"increases": 2, "decreases": 9}})
        self.assertTrue(narrowed["ok"])
        self.assertLess(
            narrowed["changes"].count("data-security="),
            loaded["changes"].count("data-security="),
        )
        self.assertIn("Top 2 increases", narrowed["changes"])
        self.assertIn("Top 9 decreases", narrowed["changes"])
        # A refused value is refused here too, not clamped by the server.
        refused = self._view({"display_top": {"increases": 0}})
        self.assertTrue(refused["ok"])
        self.assertIn("must be a whole number", refused["changes"])

    def test_the_display_top_controls_reach_the_page_script(self):
        # Both boxes and both Refresh buttons need their own field, or the page
        # cannot tell one panel from the other and one Refresh would drive both.
        _, html = self._get("/")
        for field in (
            "display-top-increases",
            "display-top-decreases",
            "display-top-increases-refresh",
            "display-top-decreases-refresh",
        ):
            self.assertIn(f'data-field="{field}"', html)
        self.assertIn('closest(\'[data-field$="-refresh"]\')', html)
        self.assertIn("display_top", html)

    def test_a_single_side_display_top_leaves_the_other_side_alone(self):
        # A Refresh carries only its own panel. If it also sent the other box,
        # a value typed there but never refreshed would be applied by the wrong
        # button, which is not what "each panel has its own Refresh" means.
        self._update(
            {"spread": "OAS", "start": "2026-10-23", "end": "2026-10-30", "mode": "ok"}
        )
        both = self._view({"display_top": {"increases": 2, "decreases": 4}})
        self.assertTrue(both["ok"])
        only = self._view({"display_top": {"decreases": 6}})
        self.assertTrue(only["ok"])
        self.assertIn("Top 2 increases", only["changes"])
        self.assertIn("Top 6 decreases", only["changes"])
        _, html = self._get("/")
        self.assertIn("applyView({ display_top: sent })", html)

    def test_the_page_names_the_code_it_was_rendered_from(self):
        # A tab left open across an edit must be detectable. The page carries
        # its own build id and the server publishes the current one, so a stale
        # page can say "reload" instead of silently routing Refresh to Update.
        _, html = self._get("/")
        match = re.search(r'<meta name="preview-build" content="([0-9a-f]{12})">', html)
        self.assertIsNotNone(match, msg="the page carries no preview-build meta tag")
        with urllib.request.urlopen(self.base + "/api/meta", timeout=10) as reply:
            meta = json.loads(reply.read())
        self.assertEqual(meta.get("build"), match.group(1))
        # The page must actually compare the two, not merely carry an id.
        self.assertIn("preview-build", html)
        self.assertIn("Reload it with Cmd+Shift+R", html)

    def test_the_page_never_posts_a_filter_to_the_update_route(self):
        # The filter path must stay local: a filter that reached /api/update
        # would rebuild the request instead of narrowing the loaded frames.
        _, html = self._get("/")
        script = html[html.index("function applyView"):]
        block = script[: script.index("function put(")]
        self.assertIn("/api/view", block)
        self.assertNotIn("/api/update", block)

    def test_a_refused_view_says_why_instead_of_returning_silently(self):
        # A module reload drops the preview session, so /api/view answers
        # ``{"ok": false, "reason": ...}``. The page must print that on the
        # status bar; a silent return is indistinguishable from a dead control.
        _, html = self._get("/")
        script = html[html.index("function applyView"):]
        block = script[: script.index("function put(")]
        self.assertIn("data.ok === false", block)
        self.assertIn("data.reason", block)
        self.assertIn("setStatus(", block)
        # And the refusal the page has to explain is the shape the server
        # really returns before any run; a fresh app has no frames at all.
        probe = _python(
            "-c",
            "import sys; sys.path.insert(0, 'preview');"
            "import preview_core as pc;"
            "print(pc.apply_view(pc.new_app(), filters={'Currency': ['EUR']}))",
        )
        self.assertIn("no run has been loaded yet", probe.stdout)


class ServerSourceTests(unittest.TestCase):
    def test_default_port_does_not_collide_with_other_projects(self):
        source = (PREVIEW_DIR / "server.py").read_text(encoding="utf-8")
        self.assertIn("DEFAULT_PORT = 8775", source)
        # Other projects own 8765 (ETF Spread) and 8770 (FI Index Change).
        for other in ("8765", "8770"):
            self.assertNotIn(
                f"DEFAULT_PORT = {other}",
                source,
                msg=f"port {other} belongs to another preview server",
            )

    def test_reverse_dns_lookup_is_avoided(self):
        source = (PREVIEW_DIR / "server.py").read_text(encoding="utf-8")
        self.assertIn("socket.getfqdn", source)
        self.assertIn("def server_bind", source)

    def test_server_binds_loopback_only_by_default(self):
        source = (PREVIEW_DIR / "server.py").read_text(encoding="utf-8")
        self.assertIn('default="127.0.0.1"', source)


class SampleRunTests(unittest.TestCase):
    def test_sample_run_prints_engine_output_without_bql(self):
        result = _python(str(PREVIEW_DIR / "sample_run.py"))
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertIn("Top increases", result.stdout)
        self.assertIn("Top decreases", result.stdout)
        self.assertIn("Bounded series check (log only, not on screen)", result.stdout)
        self.assertIn("Matches BQL", result.stdout)
        self.assertIn("DUMMYBOND", result.stdout)
        self.assertIn("Notes", result.stdout)

    def test_sample_run_source_never_requests_data(self):
        source = (PREVIEW_DIR / "sample_run.py").read_text(encoding="utf-8")
        for token in ("import bql", "bq.execute", "fetch_movers", "load_on_start"):
            self.assertNotIn(token, source)


if __name__ == "__main__":
    unittest.main()
