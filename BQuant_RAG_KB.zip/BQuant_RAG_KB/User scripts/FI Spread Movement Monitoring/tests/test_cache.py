"""The three timeout protections: cache, retry, and the cached fallback.

These are the behaviours the operator asked for by name, so each one is pinned
separately and each test states what would go wrong without it. No BQL is
executed: the fake in ``test_data`` records every request, and the cache tests
write into a temporary directory.
"""

from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "tests")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

from fi_spread_movement import cache, config, data  # noqa: E402
from fi_spread_movement.data import FetchResult  # noqa: E402


def _result():
    """A run with one increase, one decrease, a descriptor and a series."""
    result = FetchResult()
    result.increases = pd.DataFrame(
        [{"ID": "A", "Change": 20.0, "Duration": 4.25, "OASD": 3.9}]
    )
    result.decreases = pd.DataFrame(
        [{"ID": "C", "Change": -10.0, "Duration": 2.75, "OASD": 2.4}]
    )
    result.descriptors = pd.DataFrame(
        [{"ID": "A", "Name": "Alpha", "Modified Duration": 4.25}]
    )
    result.series = pd.DataFrame(
        [
            {"ID": "A", "DATE": pd.Timestamp("2026-01-25"), "Spread": 100.0},
            {"ID": "A", "DATE": pd.Timestamp("2026-02-01"), "Spread": 120.0},
        ]
    )
    result.field_status = {"Name": "returned 1 row(s), 1 non-null"}
    result.request_log = [
        {"label": "Increases ranking", "elapsed_sec": 6.4, "attempts": 1, "rows": 1}
    ]
    result.universe = "LEGATRUU Index"
    result.source = "index"
    return result


class TimeoutClassifierTests(unittest.TestCase):
    def test_the_desktop_query_limit_is_recognised(self):
        for message in (
            "ResponseError: [BQLTimeoutError] - The query took too long to complete.",
            "Error: #N/A Query Timed Out.",
            "the request timed out",
        ):
            self.assertTrue(data.is_timeout(RuntimeError(message)), message)

    def test_a_deterministic_failure_is_never_treated_as_a_timeout(self):
        # The sibling project once paid a second two-minute wait because a field
        # name contained the word "timeout". Retrying these can never succeed.
        for message in (
            "ItemBuilderError: AttributeError: No BQL data item named 'mtge_modified_duration'",
            "not entitled for this account",
            "invalid ticker",
            "No BQL data item named 'timeout_field'",
        ):
            self.assertFalse(data.is_timeout(RuntimeError(message)), message)


class RetryTests(unittest.TestCase):
    def setUp(self):
        self.calls = []

    def _fake_bq(self, outcomes):
        """A ``bq`` whose ``execute`` raises or answers per ``outcomes``."""
        calls = self.calls

        class FakeBQ:
            def execute(self, request):
                calls.append(request)
                outcome = outcomes[min(len(calls) - 1, len(outcomes) - 1)]
                if isinstance(outcome, BaseException):
                    raise outcome
                return outcome

        return FakeBQ()

    def test_one_timeout_is_retried_unchanged_and_the_retry_wins(self):
        bq = self._fake_bq(
            [RuntimeError("BQLTimeoutError: the query took too long"), "answer"]
        )
        errors: list[str] = []
        notes: list[str] = []
        response, attempts = data._execute_attempts(
            bq, lambda: "request", "Label", errors, notes
        )
        self.assertEqual(response, "answer")
        self.assertEqual(attempts, 2)
        # The failure is reported as a fact, and the retry is reported too.
        self.assertEqual(errors, [])
        self.assertTrue(any("timed out after" in note for note in notes))
        self.assertTrue(any("answered on attempt 2" in note for note in notes))

    def test_a_deterministic_failure_is_not_retried(self):
        bq = self._fake_bq([RuntimeError("No BQL data item named 'x'")])
        errors: list[str] = []
        response, attempts = data._execute_attempts(
            bq, lambda: "request", "Label", errors, []
        )
        self.assertIsNone(response)
        self.assertEqual(attempts, 1)
        self.assertEqual(len(self.calls), 1)
        self.assertIn("No BQL data item", errors[0])

    def test_the_retry_is_bounded_and_reported_when_it_also_times_out(self):
        bq = self._fake_bq([RuntimeError("BQLTimeoutError: took too long")])
        errors: list[str] = []
        response, attempts = data._execute_attempts(
            bq, lambda: "request", "Label", errors, []
        )
        self.assertIsNone(response)
        self.assertEqual(attempts, config.QUERY_ATTEMPTS)
        self.assertEqual(len(self.calls), config.QUERY_ATTEMPTS)
        # Both failures are on record, with their durations.
        self.assertTrue(any("all" in message and "attempts failed" in message for message in errors))

    def test_the_request_is_rebuilt_per_attempt(self):
        # A reused Request object could carry state from the failed execute, so
        # the factory is called once per attempt rather than once per call.
        built: list[str] = []

        def factory():
            built.append("request")
            return built[-1]

        bq = self._fake_bq(
            [RuntimeError("timed out"), RuntimeError("timed out")]
        )
        data._execute_attempts(bq, factory, "Label", [], [])
        self.assertEqual(len(built), config.QUERY_ATTEMPTS)


class CacheRoundTripTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="fi-spread-cache-"))
        self.addCleanup(shutil.rmtree, self.root, True)

    def _key(self, **overrides):
        parts = {
            "source_key": "index",
            "universe_key": "LEGATRUU Index",
            "aim_value": "",
            "spread_code": "OAS",
            "start": "2026-01-25",
            "end": "2026-02-01",
            "top_n": config.TOP_N,
        }
        parts.update(overrides)
        return cache.run_key(**parts)

    def test_a_saved_run_reloads_with_its_rows_and_dtypes(self):
        key = self._key()
        cache.save_run(key, _result(), self.root)
        self.assertTrue(cache.has_run(key, self.root))

        loaded, info = cache.load_run(key, self.root)
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded.increases["ID"].tolist(), ["A"])
        self.assertEqual(loaded.decreases["ID"].tolist(), ["C"])
        # The numeric columns come back as numbers, not as the text CSV stores.
        self.assertEqual(float(loaded.increases["Change"].iloc[0]), 20.0)
        self.assertEqual(float(loaded.increases["Duration"].iloc[0]), 4.25)
        self.assertEqual(float(loaded.descriptors["Modified Duration"].iloc[0]), 4.25)
        self.assertEqual(len(loaded.series), 2)
        self.assertTrue(pd.api.types.is_datetime64_any_dtype(loaded.series["DATE"]))
        # The receipt and the original log travel with the run.
        self.assertEqual(loaded.field_status["Name"], "returned 1 row(s), 1 non-null")
        self.assertEqual(len(info["request_log"]), 1)

    def test_a_different_window_or_spread_is_a_different_key(self):
        # A cached spread change is only true for its own window. If the key
        # ignored a date, one window's numbers could be shown for another.
        base = self._key()
        for override in (
            {"start": "2026-01-26"},
            {"end": "2026-02-02"},
            {"spread_code": "Z-Spread"},
            {"universe_key": "LEGATRUU Index".replace("U", "X")},
            {"source_key": "aim"},
            {"top_n": config.TOP_N + 1},
        ):
            self.assertNotEqual(base, self._key(**override), override)

    def test_a_missing_key_reads_as_nothing_cached(self):
        loaded, info = cache.load_run(self._key(), self.root)
        self.assertIsNone(loaded)
        self.assertIsNone(info)
        self.assertFalse(cache.has_run(self._key(), self.root))

    def test_an_empty_run_is_refused_rather_than_cached(self):
        # Caching an empty result would replay as "nothing arrived" when the
        # truth is "nothing was asked", so the next Update must ask again.
        result = FetchResult()
        with self.assertRaises(ValueError):
            cache.save_run(self._key(), result, self.root)
        self.assertFalse(cache.has_run(self._key(), self.root))

    def test_an_old_generation_is_ignored(self):
        # A pipeline change must invalidate old files instead of replaying a
        # frame the current code would not have produced.
        key = self._key()
        cache.save_run(key, _result(), self.root)
        manifest = cache._read_manifest(self.root)
        manifest[key]["generation"] = "result-v0"
        cache._write_manifest(manifest, self.root)
        self.assertFalse(cache.has_run(key, self.root))
        self.assertEqual(cache.load_run(key, self.root), (None, None))

    def test_pruning_keeps_the_newest_and_removes_their_files(self):
        keys = []
        for index in range(5):
            key = self._key(start=f"2026-01-{index + 1:02d}")
            cache.save_run(key, _result(), self.root)
            keys.append(key)
        removed = cache.prune(2, self.root)
        self.assertEqual(len(removed), 3)
        self.assertTrue(cache.has_run(keys[-1], self.root))
        self.assertTrue(cache.has_run(keys[-2], self.root))
        self.assertFalse(cache.has_run(keys[0], self.root))
        # The files go with the entry, not only the manifest line: two runs kept,
        # three CSVs each (ranked, descriptors, series), never the pruned ones.
        leftovers = sorted(path.name for path in cache.cache_dir(self.root).glob("*.csv"))
        self.assertEqual(len(leftovers), 6)
        for removed_key in removed:
            for path in cache.files_for(removed_key, self.root).values():
                self.assertFalse(path.exists(), path.name)

    def test_an_orphaned_csv_is_removed(self):
        cache.save_run(self._key(), _result(), self.root)
        orphan = cache.cache_dir(self.root) / "orphan_ranked.csv"
        orphan.write_text("ID,Change\nX,1\n", encoding="utf-8")
        cache.prune(config.CACHE_KEEP_RUNS, self.root)
        self.assertFalse(orphan.exists())

    def test_a_read_only_project_folder_does_not_fail_a_read(self):
        # Reading must not create the folder: on a Desktop project the folder can
        # be read-only, and a mkdir during a read would fail the Update before any
        # data was used.
        missing = self.root / "not-created"
        self.assertFalse(cache.has_run(self._key(), missing))
        self.assertFalse(cache.cache_dir(missing).exists())

    def test_pruning_keeps_the_run_that_was_just_saved(self):
        # The manifest is written sorted by key, so ordering by position deletes
        # by name. A key sorting first was removed while older runs survived.
        for suffix in ("zzz_old", "yyy_old"):
            cache.save_run(self._key(start=f"2026-01-{suffix[:2]}"), _result(), self.root)
        newest = self._key(start="2026-01-01")  # sorts before the two above
        cache.save_run(newest, _result(), self.root)
        cache.prune(1, self.root)
        self.assertTrue(
            cache.has_run(newest, self.root),
            "prune removed the run it had just saved",
        )

    def test_a_truncated_file_is_not_served_as_a_cache_hit(self):
        # A write that crashed midway leaves a partial CSV. Serving it would show
        # fewer rows than the manifest claims, with no sign anything was missing.
        key = self._key()
        cache.save_run(key, _result(), self.root)
        ranked = cache.files_for(key, self.root)["ranked"]
        text = ranked.read_text(encoding="utf-8").splitlines()
        ranked.write_text("\n".join(text[:2]) + "\n", encoding="utf-8")
        self.assertFalse(cache.has_run(key, self.root))
        self.assertEqual(cache.load_run(key, self.root), (None, None))

    def test_the_saved_request_is_returned_so_the_screen_can_be_labelled(self):
        # The screen must show the dates the data was made with, not whatever the
        # widgets say now.
        key = self._key(start="2026-01-25", end="2026-02-01")
        result = _result()
        result.cache_request = {
            "source": "index",
            "index": "LEGATRUU Index",
            "aim": "",
            "spread": "OAS",
            "start": "2026-01-25",
            "end": "2026-02-01",
            "top_n": config.TOP_N,
        }
        cache.save_run(key, result, self.root)
        loaded, info = cache.load_run(key, self.root)
        self.assertEqual(info["request"]["start"], "2026-01-25")
        self.assertEqual(info["request"]["end"], "2026-02-01")
        self.assertEqual(info["request"]["spread"], "OAS")
        self.assertEqual(loaded.cache_request["index"], "LEGATRUU Index")


if __name__ == "__main__":
    unittest.main()
