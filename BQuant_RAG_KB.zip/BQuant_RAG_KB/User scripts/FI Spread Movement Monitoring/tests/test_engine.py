"""Local tests for the pure pandas validation engine. No BQL is executed."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd 

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fi_spread_movement import engine
from fi_spread_movement.engine import (
    BUCKET_TABLE_COLUMNS,
    COMPARISON_BUCKET_COLUMNS,
    DAILY_COLUMNS,
    VALIDATION_COLUMNS,
    apply_dimension_filters,
    attach_spread_levels,
    bucket_diverging_rows,
    bucket_table,
    comparison_bucket_rows,
    daily_spread_rows,
    export_display_frame,
    filter_choices,
    label_conflicts,
    label_key,
    prepare_ranked_movers,
    spread_levels,
    stack_by_book,
    summarize_by_dimension,
    summarize_comparison,
    validate_candidate_changes,
)


def side(rows):
    return pd.DataFrame(rows, columns=["ID", "Change"])


class PrepareRankedMoversTests(unittest.TestCase):
    def test_ranks_directions_and_merges_descriptors(self):
        increases = side([["A", 20], ["B", 5], ["C", -3]])
        decreases = side([["D", -10], ["E", -2], ["F", 4]])
        descriptors = pd.DataFrame(
            [
                {"ID": "A", "Name": "Alpha", "Rating": "AAA"},
                {"ID": "D", "Name": "Delta", "Rating": "A"},
            ]
        )

        result = prepare_ranked_movers(
            increases,
            decreases,
            descriptors,
            top_n=10,
            descriptor_columns=("Name", "Rating"),
        )

        self.assertEqual(result.increases["ID"].tolist(), ["A", "B"])
        self.assertEqual(result.decreases["ID"].tolist(), ["D", "E"])
        self.assertEqual(result.increases.columns.tolist(), ["ID", "Name", "Rating", "Change"])
        self.assertEqual(result.increases.iloc[0]["Name"], "Alpha")

    def test_deterministic_ties_cap_and_short_list_notes(self):
        rows = [[f"B{index:02d}", 5.0] for index in range(12)]
        padded = side(rows)
        result = prepare_ranked_movers(padded, side([]), top_n=10)
        self.assertEqual(len(result.increases), 10)
        self.assertEqual(result.increases["ID"].tolist(), [f"B{i:02d}" for i in range(10)])
        self.assertTrue(any("truncated" in note for note in result.notes))
        self.assertTrue(any("decreases: no rows" in note for note in result.notes))

    def test_short_list_and_wrong_sign_and_duplicates_are_reported(self):
        increases = side([["A", 4], ["A", 9], ["B", -2]])
        result = prepare_ranked_movers(increases, side([]), top_n=10)
        self.assertEqual(result.increases["ID"].tolist(), ["A"])
        self.assertTrue(any("wrong sign" in note for note in result.notes))
        self.assertTrue(any("duplicate" in note for note in result.notes))
        self.assertEqual(float(result.increases.iloc[0]["Change"]), 9.0)
        self.assertTrue(any("only 1 qualifying" in note for note in result.notes))

    def test_a_descriptor_fault_does_not_discard_the_ranked_rows(self):
        # Ten paid requests had already answered when the descriptor join
        # failed, and the whole Update was lost to it. Display columns are
        # decoration on ID/Change: the ranked answer must survive.
        increases = side([["A", 20], ["B", 5]])
        descriptors = pd.DataFrame([{"ID": "A", "Country": "United States"}])
        with patch.object(engine, "_merge_descriptors", side_effect=KeyError("boom")):
            result = prepare_ranked_movers(
                increases,
                side([]),
                descriptors,
                top_n=10,
                descriptor_columns=("Country", "Duration"),
            )
        self.assertEqual(result.increases["ID"].tolist(), ["A", "B"])
        self.assertEqual(result.increases["Change"].tolist(), [20.0, 5.0])
        self.assertEqual(
            result.increases["Country"].tolist(),
            ["(unavailable)", "(unavailable)"],
        )
        self.assertTrue(result.increases["Duration"].isna().all())
        self.assertTrue(
            any("display columns could not be attached" in note for note in result.notes)
        )
        self.assertTrue(
            any("local reshape fault" in note for note in result.notes)
        )

    def test_a_ranked_side_fault_leaves_the_other_side_and_its_notes(self):
        with patch.object(engine, "_prepare_side", side_effect=ValueError("bad shape")):
            result = prepare_ranked_movers(side([["A", 3]]), side([["B", -3]]), None, top_n=10)
        self.assertTrue(result.increases.empty)
        self.assertTrue(result.decreases.empty)
        self.assertEqual(
            result.increases.columns.tolist(),
            ["ID", "Change"],
        )
        self.assertEqual(
            sum("could not be prepared locally" in note for note in result.notes), 2
        )

    def test_non_numeric_and_blank_ids_are_excluded_with_notes(self):
        increases = side([["A", 5], ["", 3], ["B", "oops"], ["C", None]])
        result = prepare_ranked_movers(increases, side([]), top_n=10)
        self.assertEqual(result.increases["ID"].tolist(), ["A"])
        self.assertTrue(any("excluded 3 row" in note for note in result.notes))

    def test_missing_columns_and_empty_inputs(self):
        result = prepare_ranked_movers(pd.DataFrame({"ID": ["A"]}), None, top_n=10)
        self.assertTrue(result.increases.empty)
        self.assertTrue(result.decreases.empty)
        self.assertTrue(any("missing columns" in note for note in result.notes))

    def test_rejects_invalid_top_n(self):
        with self.assertRaisesRegex(ValueError, "positive integer"):
            prepare_ranked_movers(side([]), side([]), top_n=0)
        with self.assertRaisesRegex(ValueError, "positive integer"):
            prepare_ranked_movers(side([]), side([]), top_n=True)


class ValidateCandidateChangesTests(unittest.TestCase):
    def test_matching_series_reports_change_equals_last_minus_first(self):
        increases = side([["A", 20.0]])
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-01", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-02-01", "Spread": 120.0},
            ]
        )

        result = validate_candidate_changes(increases, side([]), series)

        self.assertFalse(result.frame.empty)
        row = result.frame.iloc[0]
        self.assertEqual(float(row["Series Change"]), 20.0)
        self.assertTrue(bool(row["Matches BQL"]))
        self.assertTrue(any("satisfy Change = Last Spread - First Spread" in note for note in result.notes))

    def test_effective_dates_use_first_and_last_observation(self):
        increases = side([["A", 20.0]])
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-02", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-01-03", "Spread": 105.0},
                {"ID": "A", "DATE": "2026-01-30", "Spread": 120.0},
            ]
        )

        result = validate_candidate_changes(increases, side([]), series)
        row = result.frame.iloc[0]
        self.assertEqual(pd.Timestamp(row["Effective Start"]).date().isoformat(), "2026-01-02")
        self.assertEqual(pd.Timestamp(row["Effective End"]).date().isoformat(), "2026-01-30")

    def test_mismatch_and_missing_series_are_reported(self):
        increases = side([["A", 20.0], ["B", 5.0]])
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-01", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-02-01", "Spread": 115.0},
            ]
        )

        result = validate_candidate_changes(increases, side([]), series)

        self.assertTrue(any("Series Change != BQL Change" in note for note in result.notes))
        self.assertTrue(any("no usable spread-series observation" in note for note in result.notes))

    def test_duplicate_series_rows_are_reported_and_first_kept(self):
        increases = side([["A", 20.0]])
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-01", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-02-01", "Spread": 120.0},
                {"ID": "A", "DATE": "2026-02-01", "Spread": 130.0},
            ]
        )
        result = validate_candidate_changes(increases, side([]), series)
        self.assertTrue(any("duplicate ID/DATE" in note for note in result.notes))

    def test_effective_date_mismatch_is_noted(self):
        increases = side([["A", 20.0]])
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-02", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-01-30", "Spread": 120.0},
            ]
        )
        result = validate_candidate_changes(
            increases,
            side([]),
            series,
            requested_start="2026-01-01",
            requested_end="2026-02-01",
        )
        self.assertTrue(any("effective start date" in note for note in result.notes))
        self.assertTrue(any("effective end date" in note for note in result.notes))

    def test_empty_series_returns_note_only(self):
        result = validate_candidate_changes(
            side([["A", 1.0]]),
            side([]),
            pd.DataFrame(columns=["ID", "DATE", "Spread"]),
        )
        self.assertTrue(result.frame.empty)
        self.assertTrue(any("returned no observations" in note for note in result.notes))

    def test_a_bond_in_both_books_keeps_one_validation_row_per_book(self):
        # A is an index member and an account holding, ranked with a different
        # Change per book. The series is fetched once for the ID, so the join
        # stays on ID, but the table must not collapse the two rows: a mismatch
        # has to name the book that has it, not a bare ID that exists twice.
        books = pd.DataFrame(
            [
                {"Universe": "Index", "ID": "A", "Change": 20.0},
                {"Universe": "AIM", "ID": "A", "Change": 15.0},
            ]
        )
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-01", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-02-01", "Spread": 120.0},
            ]
        )

        result = validate_candidate_changes(books, side([]), series)

        self.assertEqual(len(result.frame), 2)
        self.assertEqual(
            result.frame.columns[0:2].tolist(), ["ID", "Universe"]
        )
        self.assertEqual(sorted(result.frame["Universe"].tolist()), ["AIM", "Index"])
        matched = result.frame.set_index("Universe")["Matches BQL"]
        self.assertTrue(bool(matched["Index"]))
        self.assertFalse(bool(matched["AIM"]))
        self.assertTrue(any("1 ranked row(s)" in note for note in result.notes))

    def test_a_single_book_table_keeps_its_old_columns(self):
        # No Universe column means the one-book shape, which existing readers
        # and the export header row depend on; it must not gain a blank column.
        result = validate_candidate_changes(
            side([["A", 20.0]]),
            side([]),
            pd.DataFrame(
                [
                    {"ID": "A", "DATE": "2026-01-01", "Spread": 100.0},
                    {"ID": "A", "DATE": "2026-02-01", "Spread": 120.0},
                ]
            ),
        )
        self.assertNotIn("Universe", result.frame.columns)
        self.assertEqual(result.frame.columns.tolist(), list(VALIDATION_COLUMNS))


class SpreadLevelTests(unittest.TestCase):
    """Start/End spread come from the series already requested for the check."""

    def series(self):
        return pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-02", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-01-30", "Spread": 120.0},
                {"ID": "C", "DATE": "2026-01-03", "Spread": 90.0},
                {"ID": "C", "DATE": "2026-01-31", "Spread": 80.0},
            ]
        )

    def test_the_endpoints_are_the_first_and_last_observation(self):
        levels = spread_levels(self.series())
        row = levels.loc[levels["ID"] == "A"].iloc[0]
        self.assertEqual(float(row["Start Spread"]), 100.0)
        self.assertEqual(float(row["End Spread"]), 120.0)
        self.assertEqual(levels.columns.tolist(), ["ID", "Start Spread", "End Spread"])

    def test_a_missing_series_yields_no_levels_instead_of_zero(self):
        self.assertTrue(spread_levels(None).empty)
        self.assertTrue(spread_levels(pd.DataFrame()).empty)
        # A frame without the expected columns is not guessed at.
        self.assertTrue(spread_levels(pd.DataFrame({"ID": ["A"]})).empty)

    def test_unusable_rows_are_dropped_not_filled(self):
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": None, "Spread": 99.0},
                {"ID": "", "DATE": "2026-01-02", "Spread": 98.0},
                {"ID": "A", "DATE": "2026-01-02", "Spread": None},
                {"ID": "A", "DATE": "2026-01-05", "Spread": 120.0},
            ]
        )
        levels = spread_levels(series)
        self.assertEqual(len(levels), 1)
        row = levels.iloc[0]
        self.assertEqual(float(row["Start Spread"]), 120.0)
        self.assertEqual(float(row["End Spread"]), 120.0)

    def test_duplicate_series_rows_keep_the_first(self):
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-01-02", "Spread": 100.0},
                {"ID": "A", "DATE": "2026-01-02", "Spread": 130.0},
                {"ID": "A", "DATE": "2026-01-30", "Spread": 120.0},
            ]
        )
        row = spread_levels(series).iloc[0]
        self.assertEqual(float(row["Start Spread"]), 100.0)

    def test_the_levels_sit_immediately_before_the_change(self):
        frame = side([["A", 20.0], ["C", -10.0]])
        out = attach_spread_levels(frame, spread_levels(self.series()))
        self.assertEqual(
            out.columns.tolist(), ["ID", "Start Spread", "End Spread", "Change"]
        )
        first = out.loc[out["ID"] == "A"].iloc[0]
        self.assertEqual(float(first["Start Spread"]), 100.0)
        self.assertEqual(float(first["End Spread"]), 120.0)
        self.assertEqual(float(first["Change"]), 20.0)

    def test_an_id_the_series_did_not_cover_stays_blank(self):
        out = attach_spread_levels(side([["B", 5.0]]), spread_levels(self.series()))
        row = out.iloc[0]
        self.assertTrue(pd.isna(row["Start Spread"]))
        self.assertTrue(pd.isna(row["End Spread"]))
        # The ranked change is untouched: a missing level is not a zero.
        self.assertEqual(float(row["Change"]), 5.0)

    def test_attaching_twice_does_not_duplicate_the_columns(self):
        levels = spread_levels(self.series())
        once = attach_spread_levels(side([["A", 20.0]]), levels)
        twice = attach_spread_levels(once, levels)
        self.assertEqual(once.columns.tolist(), twice.columns.tolist())
        self.assertEqual(float(twice.iloc[0]["Start Spread"]), 100.0)

    def test_without_levels_the_columns_exist_and_are_blank(self):
        out = attach_spread_levels(side([["A", 20.0]]), None)
        self.assertEqual(
            out.columns.tolist(), ["ID", "Start Spread", "End Spread", "Change"]
        )
        self.assertTrue(pd.isna(out.iloc[0]["Start Spread"]))


class ComparisonTests(unittest.TestCase):
    """The two-book comparison: identity is (book, ID), top-N is per book."""

    def books(self):
        return pd.DataFrame(
            [
                {"Universe": "Index", "ID": "A", "Country": "US", "Duration": 4.0, "Change": 20.0},
                {"Universe": "Index", "ID": "B", "Country": "US", "Duration": 6.0, "Change": 5.0},
                {"Universe": "AIM", "ID": "A", "Country": "DE", "Duration": 2.0, "Change": -9.0},
                {"Universe": "AIM", "ID": "C", "Country": "DE", "Duration": 3.0, "Change": 7.0},
            ]
        )

    def test_the_same_id_survives_in_both_books(self):
        frame = self.books()
        increases = frame.loc[frame["Change"] > 0]
        decreases = frame.loc[frame["Change"] < 0]
        result = prepare_ranked_movers(
            increases,
            decreases,
            None,
            top_n=10,
            descriptor_columns=(),
            group_column="Universe",
        )
        # A is an index member and an account holding. Dropping it as a
        # "duplicate ID" would delete one book's row.
        self.assertEqual(
            result.increases["Universe"].tolist(), ["Index", "AIM", "Index"]
        )
        self.assertEqual(result.increases["ID"].tolist(), ["A", "C", "B"])
        self.assertEqual(result.decreases["Universe"].tolist(), ["AIM"])
        self.assertEqual(result.decreases["ID"].tolist(), ["A"])

    def test_top_n_is_applied_per_book(self):
        rows = [
            {"Universe": book, "ID": f"{book[:2]}{position}", "Change": 10.0 - position}
            for book in ("Index", "AIM")
            for position in range(5)
        ]
        frame = pd.DataFrame(rows)
        result = prepare_ranked_movers(
            frame,
            None,
            None,
            top_n=2,
            descriptor_columns=(),
            group_column="Universe",
        )
        self.assertEqual(len(result.increases), 4)
        for book in ("Index", "AIM"):
            picked = result.increases.loc[result.increases["Universe"] == book]
            self.assertEqual(len(picked), 2)

    def test_the_comparison_column_leads_the_ranked_frame(self):
        descriptors = pd.DataFrame(
            [
                {"ID": "A", "Country": "US", "Duration": 4.0},
                {"ID": "B", "Country": "US", "Duration": 6.0},
                {"ID": "C", "Country": "DE", "Duration": 3.0},
            ]
        )
        result = prepare_ranked_movers(
            self.books().loc[lambda frame: frame["Change"] > 0],
            None,
            descriptors,
            top_n=10,
            descriptor_columns=("Country", "Duration"),
            group_column="Universe",
        )
        self.assertEqual(
            result.increases.columns.tolist(),
            ["Universe", "ID", "Country", "Duration", "Change"],
        )

    def test_summary_gives_one_line_per_book(self):
        frame = self.books()
        summary = summarize_comparison([frame], "Country")
        self.assertEqual(summary["Universe"].tolist(), ["AIM", "Index"])
        index_rows = summary.loc[summary["Universe"] == "Index"].iloc[0]
        aim_rows = summary.loc[summary["Universe"] == "AIM"].iloc[0]
        self.assertEqual(int(index_rows["Increases"]), 2)
        self.assertEqual(int(index_rows["Decreases"]), 0)
        self.assertEqual(int(aim_rows["Decreases"]), 1)
        self.assertAlmostEqual(float(index_rows["Net Change"]), 25.0)
        self.assertAlmostEqual(float(aim_rows["Net Change"]), -2.0)
        self.assertEqual(index_rows["Top bucket"], "US")
        self.assertEqual(aim_rows["Top bucket"], "DE")

    def test_summary_is_empty_without_rows(self):
        self.assertTrue(summarize_comparison([]).empty)
        self.assertTrue(summarize_comparison([pd.DataFrame()]).empty)

    def test_bucket_chart_counts_each_book_separately(self):
        stacked = stack_by_book([self.books()], "Country")
        labels, increases, decreases = comparison_bucket_rows(
            stacked, "Country", ("Index", "AIM")
        )
        self.assertEqual(labels, ["US", "DE"])
        self.assertEqual(increases["Index"], [2, 0])
        self.assertEqual(increases["AIM"], [0, 1])
        self.assertEqual(decreases["AIM"], [0, 1])

    def test_bucket_chart_collapses_the_tail_into_others(self):
        rows = [
            {"Universe": "Index", "ID": str(index), "Country": f"C{index}", "Change": 1.0}
            for index in range(5)
        ]
        stacked = stack_by_book([pd.DataFrame(rows)], "Country")
        labels, increases, _ = comparison_bucket_rows(stacked, "Country", ("Index",), limit=2)
        self.assertEqual(labels[0], "C0")
        self.assertTrue(labels[-1].startswith("Others"))
        self.assertEqual(sum(increases["Index"]), 5)


class ExportDisplayFrameTests(unittest.TestCase):
    """The copy/paste contract: the header becomes the first data row."""

    def test_header_is_repeated_as_the_first_row(self):
        frame = pd.DataFrame([{"ID": "A", "Name": "Alpha", "Change": 1.5}])
        out = export_display_frame(frame, ("ID", "Name", "Change"))
        self.assertEqual(out.columns.tolist(), ["ID", "Name", "Change"])
        self.assertEqual(out.iloc[0].tolist(), ["ID", "Name", "Change"])
        self.assertEqual(out.iloc[1].tolist(), ["A", "Alpha", "1.5"])

    def test_blank_dates_and_nan_stay_empty(self):
        frame = pd.DataFrame([{"ID": "A", "Maturity": pd.NaT, "Duration": float("nan")}])
        out = export_display_frame(frame, ("ID", "Maturity", "Duration"))
        self.assertEqual(out.iloc[1].tolist(), ["A", "", ""])

    def test_a_missing_column_keeps_its_header_and_a_blank_cell(self):
        frame = pd.DataFrame([{"ID": "A"}])
        out = export_display_frame(frame, ("ID", "Country"))
        self.assertEqual(out.columns.tolist(), ["ID", "Country"])
        self.assertEqual(out.iloc[1].tolist(), ["A", ""])

    def test_an_empty_frame_still_carries_the_header(self):
        out = export_display_frame(pd.DataFrame(), ("ID", "Change"))
        self.assertEqual(out.columns.tolist(), ["ID", "Change"])
        self.assertEqual(len(out), 1)
        self.assertEqual(out.iloc[0].tolist(), ["ID", "Change"])


if __name__ == "__main__":
    unittest.main()


class LabelSpellingTests(unittest.TestCase):
    """One bond must not show up under two values of one selection box.

    The FI Index Change account hit this on Desktop: a bond appeared in more
    than one Rating option while its detail row showed a single rating. The
    causes are an invisible space, a null-like token, a split rating, and a
    spelling that differs only by letter case. Every one of them is folded to
    one key here, so the option list and the rows it filters on cannot disagree.
    """

    def _frame(self):
        return pd.DataFrame(
            [
                {"ID": "A", "Country": "Germany", "Rating Bucket": "IG", "Change": 1.0},
                {"ID": "B", "Country": "gerMANY", "Rating Bucket": "IG\u00a0", "Change": -1.0},
                {"ID": "C", "Country": "Germany\u200b", "Rating Bucket": "NR/Missing", "Change": 1.0},
                {"ID": "D", "Country": None, "Rating Bucket": None, "Change": 0.5},
            ]
        )

    def test_label_key_folds_case_and_invisible_space(self):
        self.assertEqual(label_key("Germany"), label_key("gerMANY"))
        self.assertEqual(label_key("Germany"), label_key("Germany\u00a0"))
        self.assertEqual(label_key("Germany"), label_key(" Germany\u200b "))

    def test_a_case_variant_is_one_filter_option(self):
        choices = filter_choices([self._frame()])["Country"]
        self.assertEqual([value for value in choices if value.lower() == "germany"], ["Germany"])

    def test_a_case_variant_is_one_bucket_in_the_chart_and_the_table(self):
        frame = self._frame()
        labels, up, down = bucket_diverging_rows([frame], "Country", ("Index",), metric="count")
        self.assertEqual(len(labels), len(set(labels)))
        self.assertEqual(labels.count("Germany"), 1)
        table = summarize_by_dimension(frame, "Country")
        self.assertEqual(int(table.loc[table["Country"] == "Germany", "Total"].iloc[0]), 3)

    def test_the_filter_matches_a_case_variant_row(self):
        frame = self._frame()
        for value in ("Germany", "GERMANY"):
            kept = apply_dimension_filters(frame, {"Country": {value}})
            self.assertEqual(len(kept), 3)

    def test_conflicts_are_counted_on_the_folded_key(self):
        # One ID, two spellings of one country: still one label, so no conflict.
        frame = pd.DataFrame(
            [
                {"ID": "A", "Country": "Germany", "Change": 1.0},
                {"ID": "A", "Country": "GERMANY", "Change": -1.0},
            ]
        )
        self.assertEqual(label_conflicts([frame]).get("Country", 0), 0)


class BlankLabelTests(unittest.TestCase):
    """A cell Bloomberg returns empty must stay reachable.

    ``classification_name`` returns nothing for a large part of the US MBS/TBA
    in a global bond index (``RAG KB/08``). The blank therefore is not an edge
    case: it must be offered as a filter option, match when picked, and form a
    bucket that can be clicked. Each of those used a different sentinel once,
    so a blank Sector was unreachable and a Sector filter silently deleted
    those rows.
    """

    def _frame(self):
        return pd.DataFrame(
            [
                {"ID": "A", "Sector": "Sovereign", "Change": 1.0},
                {"ID": "B", "Sector": None, "Change": -2.0},
                {"ID": "C", "Sector": "(blank)", "Change": 0.5},
            ]
        )

    def test_the_blank_is_offered_as_one_option(self):
        choices = filter_choices([self._frame()])["Sector"]
        self.assertEqual(choices.count("(blank)"), 1)
        self.assertEqual(len(choices), 2)

    def test_picking_the_blank_keeps_the_blank_rows(self):
        kept = apply_dimension_filters(self._frame(), {"Sector": {"(blank)"}})
        self.assertEqual(sorted(kept["ID"]), ["B", "C"])

    def test_the_blank_is_one_bucket_in_the_chart_and_the_table(self):
        labels, _up, _down = bucket_diverging_rows(
            [self._frame()], "Sector", ("Index",), metric="count"
        )
        self.assertEqual(labels.count("(blank)"), 1)
        table = bucket_table([self._frame()], "Sector")
        self.assertEqual(int(table.loc[table["Bucket"] == "(blank)", "Increases"].iloc[0]), 1)
        self.assertEqual(int(table.loc[table["Bucket"] == "(blank)", "Decreases"].iloc[0]), 1)


class BucketTableTests(unittest.TestCase):
    """The full table under the two diverging charts."""

    def _frame(self, buckets=12):
        rows = []
        for index in range(buckets):
            rows.append(
                {"ID": f"B{index}", "Country": f"C{index:02d}", "Change": 1.0 + index}
            )
        return pd.DataFrame(rows)

    def test_the_single_book_columns_are_in_the_requested_order(self):
        table = bucket_table([self._frame()], "Country")
        self.assertEqual(
            list(table.columns),
            [
                "Bucket",
                "Increases",
                "Decreases",
                "Increase Spread",
                "Decrease Spread",
                "Net Change",
            ],
        )
        # Every bucket has one mover here, so the stable alphabetical tie-break
        # decides the order; the point of this test is the column order.
        self.assertEqual(table["Bucket"].tolist()[0], "C00")

    def test_the_largest_bucket_is_first(self):
        frame = pd.DataFrame(
            [
                {"ID": "A", "Country": "France", "Change": 1.0},
                {"ID": "B", "Country": "Germany", "Change": 1.0},
                {"ID": "C", "Country": "Germany", "Change": 2.0},
                {"ID": "D", "Country": "Germany", "Change": 3.0},
                {"ID": "E", "Country": "Italy", "Change": 1.0},
                {"ID": "F", "Country": "Italy", "Change": 1.0},
            ]
        )
        table = bucket_table([frame], "Country")
        self.assertEqual(table["Bucket"].tolist(), ["Germany", "Italy", "France"])

    def test_the_spread_columns_precede_net_change(self):
        columns = list(BUCKET_TABLE_COLUMNS)
        self.assertLess(columns.index("Increase Spread"), columns.index("Net Change"))
        self.assertLess(columns.index("Decrease Spread"), columns.index("Net Change"))

    def test_the_charts_cut_to_ten_and_the_table_does_not(self):
        frame = self._frame()
        labels, _up, _down = bucket_diverging_rows(
            [frame], "Country", ("Index",), metric="count"
        )
        self.assertEqual(len(labels), 11)
        self.assertEqual(labels[-1], "Others (2)")
        self.assertNotIn("Others (2)", bucket_table([frame], "Country")["Bucket"].tolist())
        self.assertEqual(len(bucket_table([frame], "Country")), 12)

    def test_both_metrics_share_one_bucket_order(self):
        frame = self._frame()
        count_labels, _up, _down = bucket_diverging_rows(
            [frame], "Country", ("Index",), metric="count"
        )
        spread_labels, _up, _down = bucket_diverging_rows(
            [frame], "Country", ("Index",), metric="spread"
        )
        self.assertEqual(count_labels, spread_labels)

    def test_the_comparison_table_lists_aim_before_index_per_bucket(self):
        frame = pd.DataFrame(
            [
                {"ID": "A", "Country": "Germany", "Universe": "Index", "Change": 1.0},
                {"ID": "B", "Country": "Germany", "Universe": "AIM", "Change": 2.0},
                {"ID": "C", "Country": "France", "Universe": "AIM", "Change": 3.0},
            ]
        )
        table = bucket_table([frame], "Country", ("AIM", "Index"))
        self.assertEqual(list(table.columns), list(COMPARISON_BUCKET_COLUMNS))
        self.assertNotIn("Top bucket", table.columns)
        germany = table.loc[table["Bucket"] == "Germany", "Universe"].tolist()
        self.assertEqual(germany, ["AIM", "Index"])

    def test_a_bucket_missing_from_one_book_keeps_its_other_row(self):
        frame = pd.DataFrame(
            [
                {"ID": "A", "Country": "Germany", "Universe": "Index", "Change": 1.0},
                {"ID": "C", "Country": "France", "Universe": "AIM", "Change": 3.0},
            ]
        )
        table = bucket_table([frame], "Country", ("AIM", "Index"))
        self.assertEqual(sorted(table["Bucket"].unique()), ["France", "Germany"])


class DailySpreadRowsTests(unittest.TestCase):
    """The list under the spread path: observations, not a filled calendar."""

    def _series(self):
        return pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-10-23", "Spread": 1.10},
                {"ID": "A", "DATE": "2026-10-24", "Spread": None},   # Saturday, no quote
                {"ID": "A", "DATE": "2026-10-26", "Spread": 1.12},
                {"ID": "A", "DATE": "2026-10-27", "Spread": None},   # holiday
                {"ID": "A", "DATE": "2026-10-28", "Spread": 1.115},
                {"ID": "B", "DATE": "2026-10-28", "Spread": 9.99},
            ]
        )

    def test_only_real_observations_appear(self):
        table = daily_spread_rows(self._series(), "A")
        self.assertEqual(list(table.columns), list(DAILY_COLUMNS))
        self.assertEqual(table["Date"].tolist(), ["2026-10-23", "2026-10-26", "2026-10-28"])

    def test_a_gap_is_not_carried_forward(self):
        table = daily_spread_rows(self._series(), "A")
        self.assertEqual(table["Spread"].tolist(), [1.10, 1.12, 1.115])
        self.assertTrue(pd.isna(table["Change vs previous observation"].iloc[0]))
        self.assertEqual(table["Change vs previous observation"].iloc[1], 0.02)
        self.assertEqual(table["Change vs previous observation"].iloc[2], -0.005)

    def test_another_security_and_an_empty_input_return_nothing(self):
        self.assertTrue(daily_spread_rows(self._series(), "ZZ").empty)
        self.assertTrue(daily_spread_rows(None, "A").empty)
        self.assertTrue(daily_spread_rows(self._series(), "").empty)

    def test_a_series_without_the_date_column_is_refused_not_guessed(self):
        frame = self._series().drop(columns=["DATE"])
        self.assertTrue(daily_spread_rows(frame, "A").empty)


class SpreadChoiceTests(unittest.TestCase):
    def test_only_the_three_confirmed_spreads_are_offered(self):
        from fi_spread_movement import config

        labels = list(config.SPREAD_TYPES)
        self.assertEqual(labels, ["OAS", "Z-Spread", "I-Spread"])
        self.assertEqual(config.DEFAULT_SPREAD_TYPE, "OAS")
        # ``Asset swap spread`` was offered and then withdrawn on 2026-11-02
        # (DR-26). It must not come back through a label, and the code must not
        # survive as an accepted value, or a stale caller could still send it.
        self.assertNotIn("Asset swap spread", config.SPREAD_TYPES)
        self.assertNotIn("ASW", config.SPREAD_TYPES.values())

    def test_the_withdrawn_asset_swap_spread_is_refused_not_sent(self):
        from fi_spread_movement import data

        for value in ("Asset swap spread", "ASW"):
            with self.assertRaises(ValueError):
                data._validated_window(value, "2026-10-23", "2026-10-30")
