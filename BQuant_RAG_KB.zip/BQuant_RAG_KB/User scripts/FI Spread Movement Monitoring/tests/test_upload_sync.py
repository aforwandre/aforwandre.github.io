"""The Desktop mirror and the preview must track the package on disk.

Two silent drifts are possible and both ship a wrong build: ``Upload/`` holding
a module older than ``fi_spread_movement/``, and the preview page rendering code
the file no longer contains. Neither raises on its own, so both are pinned here.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "preview")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

import sync_upload


class UploadMirrorTests(unittest.TestCase):
    def test_every_module_has_a_mirror(self):
        for source in sync_upload.runtime_modules():
            target = sync_upload.target_for(source)
            self.assertTrue(target.is_file(), f"{target} is missing; run python3 sync_upload.py")

    def test_mirrors_are_byte_identical(self):
        for source in sync_upload.runtime_modules():
            target = sync_upload.target_for(source)
            if not target.is_file():
                self.fail(f"{target} is missing; run python3 sync_upload.py")
            self.assertEqual(
                source.read_bytes(),
                target.read_bytes(),
                f"{target} drifted from {source.name}; run python3 sync_upload.py",
            )

    def test_no_orphan_mirror(self):
        write, prune, _missing = sync_upload.plan()
        self.assertEqual([], prune, "a mirror has no source module; run python3 sync_upload.py")

    def test_the_six_runtime_files_are_listed(self):
        names = [path.name for path in sync_upload.runtime_modules()]
        for expected in ("__init__.py", "config.py", "data.py", "engine.py", "charts.py", "app.py"):
            self.assertIn(expected, names)

    def test_tests_and_preview_are_not_mirrored(self):
        names = {path.name for path in sync_upload.runtime_modules()}
        self.assertNotIn("build_preview.py", names)
        self.assertNotIn("server.py", names)
        self.assertNotIn("sync_upload.py", names)

    def test_the_notebook_is_mirrored_with_the_package(self):
        # MAIN.ipynb is copied to Desktop too, so it has to ship with the code it
        # imports. It was mirrored by hand and went stale: the copy still
        # imported a config name the package no longer defined, which would have
        # failed in the first Desktop cell instead of at the copy step.
        self.assertTrue(sync_upload.NOTEBOOK.is_file())
        self.assertTrue(
            sync_upload.NOTEBOOK_TARGET.is_file(),
            "Upload/MAIN.ipynb.txt is missing; run python3 sync_upload.py",
        )
        self.assertEqual(
            sync_upload.NOTEBOOK.read_bytes(),
            sync_upload.NOTEBOOK_TARGET.read_bytes(),
            "Upload/MAIN.ipynb.txt drifted from MAIN.ipynb; run python3 sync_upload.py",
        )

    def test_the_notebook_imports_only_names_the_package_defines(self):
        # Cheap guard against the specific drift above: every
        # `from fi_spread_movement.<module> import <name>` in the notebook must
        # resolve on the real package. The notebook is read as JSON, not as
        # lines of Python text, so cell escaping cannot confuse the check.
        import ast
        import importlib
        import json

        notebook = json.loads(sync_upload.NOTEBOOK.read_text(encoding="utf-8"))
        source = "\n".join(
            "".join(cell.get("source", ()))
            for cell in notebook.get("cells", ())
            if cell.get("cell_type") == "code"
        )
        self.assertIn("fi_spread_movement", source)
        checked = 0
        for node in ast.parse(source).body:
            if not isinstance(node, ast.ImportFrom) or not (node.module or "").startswith(
                "fi_spread_movement"
            ):
                continue
            module = importlib.import_module(node.module)
            for alias in node.names:
                checked += 1
                self.assertTrue(
                    hasattr(module, alias.name),
                    f"MAIN.ipynb imports {alias.name} from {node.module}, "
                    "which no longer defines it",
                )
        self.assertGreater(checked, 0, "the notebook no longer imports the package")


class ServerReloadTests(unittest.TestCase):
    def test_reload_is_a_no_op_when_nothing_changed(self):
        import server

        self.assertIsNone(server.reload_if_changed())

    def test_reload_error_is_reported_not_swallowed(self):
        import server

        original = server._LAST_SIGNATURE
        try:
            server._LAST_SIGNATURE = ()
            server.RELOAD_ORDER = ("fi_spread_movement.__missing_module__", "preview_core")
            # A module that is not imported is skipped, so this still succeeds.
            self.assertIsNone(server.reload_if_changed())
        finally:
            server._LAST_SIGNATURE = original
            server._RELOAD_ERROR = None

    def test_session_reset_drops_the_cached_app(self):
        import preview_core
        from fi_spread_movement import charts

        # Building the preview app repoints charts.html_fallback at the SVG
        # renderer. Restore it, or the table-fallback tests that share this
        # process would see a renderer this module installed.
        original = charts.html_fallback
        try:
            first = preview_core.session_app()
            self.assertIs(first, preview_core.session_app())
            preview_core.reset_session()
            self.assertIsNot(first, preview_core.session_app())
        finally:
            charts.html_fallback = original
            preview_core.reset_session()


if __name__ == "__main__":
    unittest.main()
