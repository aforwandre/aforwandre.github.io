"""The app-level timeout protection: save, fall back, and label it as cached.

The three pieces the operator asked for by name are tested against the real
``FISpreadMovementApp`` with a stub widget layer and a patched fetch, so this
covers the wiring rather than the cache module in isolation. The point of each
test is what the operator would see: a timeout must not leave an empty screen,
and a cached screen must never be mistakable for a fresh one.
"""

from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
for entry in (str(ROOT), str(ROOT / "tests")):
    if entry not in sys.path:
        sys.path.insert(0, entry)

import test_app as harness  # noqa: E402  (installs the widget stubs first)

app_module = harness.app_module
config = harness.config
cache = harness.cache_module
FetchResult = harness.FetchResult


class CacheFallbackTests(unittest.TestCase):
    def setUp(self):
        harness.displayed.clear()
        self.root = Path(tempfile.mkdtemp(prefix="fi-spread-app-cache-"))
        self.addCleanup(shutil.rmtree, self.root, True)
        self.app = harness.make_app(cache_root=self.root)
        self.app.index_input.value = "LEGATRUU Index"

    def _run(self, result):
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=harness.displayed.append):
                self.app._on_update(None)

    def _timeout_result(self):
        """What a run that hit the Desktop limit looks like from the adapter."""
        return FetchResult(errors=["Index Increases ranking: BQLTimeoutError: took too long"])

    def test_a_good_run_is_saved_so_a_timeout_can_fall_back_to_it(self):
        self._run(harness._fetch_result())
        key = self.app._cache_key(
            "index",
            self.app.start_date.value,
            self.app.end_date.value,
            "LEGATRUU Index",
            "",
            self.app.spread_type.value,
        )
        self.assertTrue(cache.has_run(key, self.root))

    def test_a_timeout_with_a_saved_run_shows_the_cached_tables_not_an_error(self):
        # This is the whole feature: the second press of Update is not needed.
        self._run(harness._fetch_result())
        self._run(self._timeout_result())

        self.assertIn("Cached", self.app.status.value)
        # Never "Updated": no request produced this screen.
        self.assertNotIn(">Updated<", self.app.status.value)
        self.assertIn("the live request timed out", self.app.detail.value)
        self.assertIn("BQLTimeoutError", self.app.detail.value)
        # The tables are populated from the cache, so the screen is usable.
        self.assertTrue(len(self.app._frames.get("increases", [])))

    def test_the_error_is_still_shown_when_no_saved_run_exists(self):
        # The fallback is an extra step, not a replacement: a timeout with
        # nothing cached must still be the plain, loud failure.
        self._run(self._timeout_result())
        self.assertIn("Incomplete", self.app.status.value)
        self.assertIn("BQLTimeoutError", self.app.detail.value)
        self.assertFalse(self.app._frames.get("increases") is not None and len(self.app._frames.get("increases")))

    def test_a_deterministic_failure_never_falls_back_to_the_cache(self):
        # A rejected item or a missing entitlement would look identical on a
        # retry, so showing a previous run for it would hide a real problem
        # behind a table that looks current.
        self._run(harness._fetch_result())
        failure = FetchResult(
            errors=["No BQL data item named 'mtge_modified_duration'"]
        )
        self._run(failure)
        self.assertIn("Incomplete", self.app.status.value)
        self.assertNotIn("Cached", self.app.status.value)

    def test_a_cached_screen_never_writes_a_new_cache_entry(self):
        # Reading the cache must not touch it, or a load would look like a run.
        self._run(harness._fetch_result())
        before = sorted(path.name for path in cache.cache_dir(self.root).iterdir())
        self._run(self._timeout_result())
        after = sorted(path.name for path in cache.cache_dir(self.root).iterdir())
        self.assertEqual(before, after)

    def test_load_saved_refuses_clearly_when_nothing_matches(self):
        self.app._on_load_cached(None)
        self.assertIn("Refused", self.app.status.value)
        self.assertIn("No saved run matches", self.app.detail.value)

    def test_load_saved_shows_the_saved_run_without_a_request(self):
        self._run(harness._fetch_result())
        with patch.object(
            app_module, "fetch_movers", side_effect=AssertionError("no request")
        ):
            self.app._on_load_cached(None)
        self.assertIn("Cached", self.app.status.value)
        self.assertIn("Load saved was clicked", self.app.detail.value)
        self.assertTrue(len(self.app._frames.get("increases", [])))

    def test_a_cached_screen_says_so_in_the_step_log(self):
        self._run(harness._fetch_result())
        harness.displayed.clear()
        self._run(self._timeout_result())
        # ``_log_line`` calls ``display`` inside the Output widget; the stub
        # redirects that to ``harness.displayed``, so the log text is there.
        log = " ".join(
            getattr(entry, "value", "") for entry in harness.displayed
        )
        self.assertIn("Cached run", log)
        self.assertIn("did not complete", log)

    def test_a_partial_run_is_not_cached(self):
        # A run that arrived with a FAILED field would replay as a clean
        # `Cached` screen with no receipt naming the missing column, turning
        # `Incomplete` into what looks like a good cached answer.
        partial = harness._fetch_result()
        partial.field_status = {"Country": "FAILED: RuntimeError: synthetic"}
        self._run(partial)
        self.assertIn("Incomplete", self.app.status.value)
        key = self.app._cache_key(
            "index",
            self.app.start_date.value,
            self.app.end_date.value,
            "LEGATRUU Index",
            "",
            self.app.spread_type.value,
        )
        self.assertFalse(cache.has_run(key, self.root))

    def test_a_mixed_failure_does_not_fall_back(self):
        # A deterministic error plus an unrelated timed-out field is not a
        # timeout: falling back there would hide the rejected item.
        self._run(harness._fetch_result())
        mixed = FetchResult(
            errors=["Increases ranking: No BQL data item named 'spread'"],
            field_status={"Duration measures": "FAILED: BqlTimeoutError: too long"},
        )
        self._run(mixed)
        self.assertNotIn("Cached", self.app.status.value)
        self.assertIn("Incomplete", self.app.status.value)

    def test_a_cached_screen_shows_the_stored_window_not_the_live_widgets(self):
        # An edit made while the request was running must not relabel the cached
        # data as a different window. A past date is used because the app refuses
        # a future end date before it ever reaches the request.
        saved_start = self.app.start_date.value
        saved_end = self.app.end_date.value
        self._run(harness._fetch_result())
        earlier = saved_start - timedelta(days=1)
        self.app.start_date.value = earlier
        self._run(self._timeout_result())
        # The live request now asks for a different window, so nothing matches
        # that key: this asserts the key is honest about the window rather than
        # silently serving the saved run for a window it was not made with.
        self.assertNotIn("Cached", self.app.status.value)
        # Put the window back and the same saved run is served, labelled with the
        # dates it was made with.
        self.app.start_date.value = saved_start
        self._run(self._timeout_result())
        self.assertIn("Cached", self.app.status.value)
        self.assertIn(saved_end.isoformat(), self.app.status.value)

    def test_the_original_request_times_travel_with_the_cached_run(self):
        # A cached load must not pretend the load itself was the request: the
        # per-request seconds shown are the ones the original run measured.
        self._run(harness._fetch_result())
        self._run(self._timeout_result())
        self.assertTrue(self.app._request_log)
        self.assertIn("elapsed_sec", self.app._request_log[0])


if __name__ == "__main__":
    unittest.main()
