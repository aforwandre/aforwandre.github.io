"""Local tests for the BQL adapter and response normalization. No BQL is executed."""

from __future__ import annotations

import sys
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fi_spread_movement import config, data
from fi_spread_movement.data import FetchResult
from fi_spread_movement.data import _normalize_frame
from fi_spread_movement.data import fetch_movers as _fetch_movers

SAMPLE_INDEX = "LEGATRUU Index"


def fetch_movers(spread, start, end, index=SAMPLE_INDEX, **kwargs):
    """Test helper: existing cases use the recorded example ticker."""
    return _fetch_movers(spread, start, end, index, **kwargs)


def rank_frame(ids, values):
    return pd.DataFrame(
        {"Spread Change": values}, index=pd.Index(ids, name="ID")
    )


def descriptor_frame(label):
    return pd.DataFrame(
        {label: [f"{label} 1", f"{label} 2"]},
        index=pd.Index(["A", "B"], name="ID"),
    )


def series_frame():
    return pd.DataFrame(
        {
            "ID": ["A", "A", "B", "B"],
            "DATE": ["2026-01-25", "2026-02-01", "2026-01-25", "2026-02-01"],
            "Spread": [100.0, 120.0, 50.0, 45.0],
        }
    )


def duration_frame(label):
    """A distinct number per measure, so a duplicate-value note cannot fire."""
    values = {
        "Modified Duration": [4.25, 2.75],
        "Effective Duration": [4.10, 2.60],
        "OASD": [3.90, 2.40],
    }.get(label, [5.0, 3.0])
    return pd.DataFrame(
        {label: values}, index=pd.Index(["A", "B"], name="ID")
    )


class FakeExpression:
    def __init__(self, label):
        self.label = label

    def net_chg(self):
        return FakeExpression(f"{self.label}.net_chg")

    def groupsort(self):
        return FakeExpression(f"{self.label}.groupsort")

    def grouprank(self, order):
        return FakeGroupRank(self.label, order)

    def __gt__(self, value):
        return ("gt", self.label, value)

    def __lt__(self, value):
        return ("lt", self.label, value)


class FakeGroupRank:
    def __init__(self, label, order):
        self.label = label
        self.order = order

    def __le__(self, value):
        return ("grouprank", self.label, self.order, value)


class FakeRequest:
    def __init__(self, universe, items, with_params=None):
        self.universe = universe
        self.items = items
        self.with_params = with_params


class FakeItem:
    def __init__(self, name, frame):
        self.name = name
        self._frame = frame

    def df(self):
        return self._frame


class FakeResponse:
    def __init__(self, item):
        self.item = item

    def get(self, name):
        return self.item if self.item.name == name else None


class FakeMultiResponse:
    """A response carrying several items, keyed and index-addressable."""

    def __init__(self, items):
        self._items = list(items)

    def get(self, name):
        for item in self._items:
            if item.name == name:
                return item
        return None

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        return self._items[index]


class IndexFallbackResponse:
    """A response that only supports len/index access, not .get()."""

    def __init__(self, item):
        self._item = item

    def __len__(self):
        return 1

    def __getitem__(self, index):
        if index != 0:
            raise IndexError(index)
        return self._item


class FakeUniverse:
    def __init__(self, label, owner, conditions=()):
        self.label = label
        self.owner = owner
        self.conditions = list(conditions)

    def filter(self, condition):
        self.owner.filters.append(condition)
        return FakeUniverse(self.label, self.owner, [*self.conditions, condition])


class FakeDataFactory:
    def __init__(self, owner):
        self.owner = owner

    def spread(self, spread_type, dates):
        self.owner.spread_args = (spread_type, dates)
        return FakeExpression("Spread")

    def name(self):
        return FakeExpression("Name")

    def country_full_name(self):
        return FakeExpression("Country")

    def classification_name(self):
        return FakeExpression("Sector")

    def rating(self):
        return FakeExpression("Rating")

    def crncy(self):
        return FakeExpression("Currency")

    def maturity(self):
        return FakeExpression("Maturity")

    def duration(self, duration_type=None):
        self.owner.duration_args.append(duration_type)
        return FakeExpression("Duration" if duration_type is None else duration_type)

class FakeFuncFactory:
    @staticmethod
    def range(start, end):
        return (start, end)


class FakeService:
    def __init__(self, owner):
        self.owner = owner
        self.univ = FakeUniverseFactory(owner)
        self.data = FakeDataFactory(owner)
        self.func = FakeFuncFactory()

    def execute(self, request):
        self.owner.requests.append(request)
        if len(request.items) > 1:
            # The duration family: one request, several items.
            names = list(request.items)
            if self.owner.failing_labels & set(names):
                failed = sorted(self.owner.failing_labels & set(names))[0]
                raise RuntimeError(f"synthetic {failed} failure")
            return FakeMultiResponse(
                [
                    FakeItem(name, duration_frame(name))
                    for name in names
                    if name not in self.owner.missing_items
                ]
            )
        label = next(iter(request.items))
        conditions = [
            condition
            for condition in getattr(request.universe, "conditions", ())
            if isinstance(condition, tuple)
        ]
        is_increases = any(condition[0] == "gt" for condition in conditions)
        if label == "Spread Change":
            if self.owner.bad_ranking_shape:
                frame = pd.DataFrame({"Spread Change": [1.0, -2.0]})
            elif self.owner.ranking_with_date:
                ids = ["A"] if is_increases else ["C"]
                frame = rank_frame(ids, [20.0] if is_increases else [-10.0])
                frame["DATE"] = pd.Timestamp("2026-02-01")
            elif self.owner.large_ties:
                ids = [f"T{index:02d}" for index in range(15)]
                values = [5.0] * 15 if is_increases else [-5.0] * 15
                frame = rank_frame(ids, values)
            elif self.owner.full_books:
                # Distinct IDs per book, TOP_N of them per direction, so the
                # union of the two books is larger than one ranked side.
                book = "AIM" if getattr(request.universe, "label", "") == "aim-members" else "IDX"
                ids = [f"{book}{index:02d}" for index in range(config.TOP_N)]
                if is_increases:
                    values = [float(20 - index) for index in range(config.TOP_N)]
                else:
                    values = [float(-10 - index) for index in range(config.TOP_N)]
                frame = rank_frame(ids, values)
            elif is_increases:
                frame = rank_frame(["A", "B"], [20.0, 7.0])
            else:
                frame = rank_frame(["C", "D"], [-10.0, -4.0])
        elif label == "Spread":
            frame = series_frame()
        elif label in self.owner.failing_labels:
            raise RuntimeError(f"synthetic {label} failure")
        elif label in self.owner.null_labels:
            frame = pd.DataFrame(
                {label: [None, None]}, index=pd.Index(["A", "B"], name="ID")
            )
        else:
            frame = descriptor_frame(label)
        item = FakeItem(label, frame)
        if self.owner.response_mode == "index":
            return IndexFallbackResponse(item)
        return FakeResponse(item)


class FakeUniverseFactory:
    def __init__(self, owner):
        self.owner = owner

    def members(self, index=None, dates=None, **kwargs):
        if kwargs.get("type") == "AIM":
            self.owner.aim_members_kwargs = dict(kwargs)
            self.owner.aim_members_args = (index, dates)
            self.owner.filters = []
            return FakeUniverse("aim-members", self.owner)
        self.owner.members_args = (index, dates)
        self.owner.filters = []
        return FakeUniverse("members", self.owner)

    def list(self, ids):
        self.owner.descriptor_ids = list(ids)
        return FakeUniverse("explicit-ids", self.owner)


class FakeBQL:
    Request = FakeRequest

    def __init__(self):
        self.requests = []
        self.filters = []
        self.members_args = None
        self.aim_members_kwargs = None
        self.aim_members_args = None
        self.spread_args = None
        self.duration_args = []
        self.descriptor_ids = None
        self.failing_labels = set()
        self.null_labels = set()
        # Items that build but are absent from the multi-item response, so a
        # single rejected measure inside the duration family can be exercised.
        self.missing_items = set()
        self.response_mode = "get"
        self.large_ties = False
        self.bad_ranking_shape = False
        self.ranking_with_date = False
        # A full book: each ranking returns TOP_N distinct IDs for the universe
        # it was sent on. The default fake returns two IDs per side, which is
        # below TOP_N and therefore cannot exercise a positional cut.
        self.full_books = False

    def Service(self):
        return FakeService(self)


class FetchMoversTests(unittest.TestCase):
    def setUp(self):
        self.fake = FakeBQL()
        patcher = patch.object(data, "bql", self.fake)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_empty_index_builds_no_request(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01", index="  ")
        self.assertIn("empty", result.errors[0])
        self.assertIsNone(self.fake.members_args)
        self.assertEqual(result.index, "")

    def test_ticker_without_the_index_suffix_is_refused(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01", index="LEGATRUU")
        self.assertIn("must end with", result.errors[0])
        self.assertIsNone(self.fake.members_args)

    def test_index_whitespace_is_collapsed_before_the_request(self):
        fetch_movers("OAS", "2026-01-25", "2026-02-01", index="  LEGATRUU   Index ")
        self.assertEqual(self.fake.members_args[0], "LEGATRUU Index")

    def test_a_different_typed_index_is_the_universe(self):
        fetch_movers("OAS", "2026-01-25", "2026-02-01", index="LF98TRUU Index")
        self.assertEqual(self.fake.members_args[0], "LF98TRUU Index")

    def test_index_source_is_recorded_separately_from_the_typed_value(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertEqual(result.source, "index")
        self.assertEqual(result.universe, "LEGATRUU Index")
        self.assertIsNone(self.fake.aim_members_kwargs)

    def test_aim_source_builds_the_frozen_request(self):
        result = fetch_movers(
            "OAS", "2026-01-25", "2026-02-01", index="abc123", source="AIM account"
        )

        # members() gets type="AIM" only: no account, no dates, no pxnum.
        self.assertEqual(self.fake.aim_members_kwargs, {"type": "AIM"})
        self.assertEqual(self.fake.aim_members_args, (None, None))
        self.assertIsNone(self.fake.members_args)

        # The account block stays on Request.with_params, one code in a list, and
        # only on the two ranking requests. The descriptor and series requests run
        # on an explicit bq.univ.list() of candidate IDs, so they must not carry
        # an account block: that would re-scope them to the whole book.
        ranking = [
            request
            for request in self.fake.requests
            if "Spread Change" in request.items
        ]
        self.assertEqual(len(ranking), 2)
        for request in ranking:
            self.assertEqual(
                request.with_params,
                {
                    "accounts": ["ABC123"],
                    "pxnum": config.AIM_PXNUM,
                    "profile": config.AIM_PROFILE,
                },
            )
        others = [
            request
            for request in self.fake.requests
            if "Spread Change" not in request.items
        ]
        self.assertTrue(others)
        for request in others:
            self.assertIsNone(request.with_params)

        self.assertEqual(result.source, "aim")
        self.assertEqual(result.universe, "ABC123")
        self.assertEqual(result.index, "ABC123")
        self.assertFalse(result.errors)

    def test_aim_blank_code_builds_no_request(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01", index="  ", source="aim")
        self.assertIn("AIM account is empty", result.errors[0])
        self.assertIsNone(self.fake.aim_members_kwargs)
        self.assertEqual(self.fake.requests, [])

    def test_aim_code_with_an_inner_space_is_refused(self):
        result = fetch_movers(
            "OAS", "2026-01-25", "2026-02-01", index="ABC 123", source="aim"
        )
        self.assertIn("one account code", result.errors[0])
        self.assertEqual(self.fake.requests, [])

    def test_aim_does_not_validate_the_index_suffix(self):
        # An AIM code is not a ticker, so the Index suffix rule must not apply.
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01", index="ABC123", source="aim")
        self.assertNotIn("must end with", " ".join(result.errors))

    def test_unknown_source_is_refused_before_any_request(self):
        result = fetch_movers(
            "OAS", "2026-01-25", "2026-02-01", index="ABC123", source="Portfolio"
        )
        self.assertIn("Unsupported universe source", result.errors[0])
        self.assertEqual(self.fake.requests, [])

    def test_configured_pxnum_overrides_the_frozen_default(self):
        with patch.object(config, "AIM_PXNUM", "3295"):
            fetch_movers("OAS", "2026-01-25", "2026-02-01", index="ABC123", source="aim")
        ranking = [
            request
            for request in self.fake.requests
            if "Spread Change" in request.items
        ]
        self.assertEqual(ranking[0].with_params["pxnum"], 3295)

    def test_aim_keeps_the_same_ranking_and_descriptors(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01", index="ABC123", source="aim")
        self.assertEqual(result.increases["ID"].tolist(), ["A", "B"])
        self.assertEqual(result.decreases["ID"].tolist(), ["C", "D"])
        self.assertEqual(self.fake.spread_args, ("OAS", ("2026-01-25", "2026-02-01")))
        self.assertEqual(self.fake.descriptor_ids, ["A", "B", "C", "D"])
        self.assertEqual(
            set(result.field_status),
            {label for label, _ in config.DESCRIPTOR_FIELDS}
            | {label for label, _ in config.DURATION_FIELDS}
            | {"Spread Series"},
        )
        # The AIM path spends the same three bounded requests as the index
        # path: descriptors, one duration family, one series. It adds nothing.
        self.assertEqual(
            self.fake.duration_args,
            [measure for _label, measure in config.DURATION_FIELDS],
        )

    def test_builds_documented_request_and_bounded_descriptors(self):
        result = fetch_movers("Z-Spread", "2026-01-25", "2026-02-01")

        self.assertEqual(self.fake.members_args, ("LEGATRUU Index", "2026-02-01"))
        self.assertEqual(result.index, "LEGATRUU Index")
        self.assertEqual(self.fake.spread_args, ("Z", ("2026-01-25", "2026-02-01")))
        self.assertEqual(self.fake.descriptor_ids, ["A", "B", "C", "D"])
        self.assertTrue(all(len(self.fake.descriptor_ids) <= 20 for _ in [0]))

        condition_texts = [str(condition) for condition in self.fake.filters]
        self.assertTrue(any("'gt'" in text for text in condition_texts))
        self.assertTrue(any("'lt'" in text for text in condition_texts))
        self.assertTrue(any("'desc'" in text for text in condition_texts))
        self.assertTrue(any("'asc'" in text for text in condition_texts))

        # 2 rankings + one request per descriptor + the duration measure family
        # + the spread series. The family REPLACES the request that used to
        # carry `Duration` alone, so four measures cost what one used to.
        expected_requests = (
            2 + len(config.DESCRIPTOR_FIELDS) + 1 + 1
        )
        self.assertEqual(len(self.fake.requests), expected_requests)
        self.assertEqual(result.increases["ID"].tolist(), ["A", "B"])
        self.assertEqual(result.decreases["ID"].tolist(), ["C", "D"])
        self.assertEqual(
            set(result.field_status),
            {label for label, _ in config.DESCRIPTOR_FIELDS}
            | {label for label, _ in config.DURATION_FIELDS}
            | {"Spread Series"},
        )
        self.assertFalse(result.errors)
        self.assertEqual(len(result.request_log), expected_requests)
        # The duration family really is one multi-item request, not three.
        duration_requests = [
            request for request in self.fake.requests if len(request.items) > 1
        ]
        self.assertEqual(len(duration_requests), 1)
        self.assertEqual(
            list(duration_requests[0].items),
            [label for label, _ in config.DURATION_FIELDS],
        )
        self.assertEqual(
            self.fake.duration_args,
            [measure for _label, measure in config.DURATION_FIELDS],
        )

    def test_series_validation_frame_is_normalized(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertEqual(result.series.columns.tolist(), ["ID", "DATE", "Spread"])
        self.assertEqual(len(result.series), 4)
        self.assertEqual(result.field_status["Spread Series"].split(" ")[0], "returned")

    def test_one_descriptor_failure_does_not_hide_other_fields(self):
        self.fake.failing_labels = {"Rating"}
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")

        self.assertIn("FAILED: RuntimeError", result.field_status["Rating"])
        self.assertIn("Name", result.descriptors.columns)
        self.assertIn("Country", result.descriptors.columns)
        self.assertNotIn("Rating", result.descriptors.columns)
        self.assertTrue(any("Rating descriptor request failed" in note for note in result.notes))

    def test_one_failed_duration_measure_does_not_hide_the_other_three(self):
        # The family is one request, so a rejected measure drops that item and
        # keeps the rest: four measures must not be all-or-nothing.
        self.fake.missing_items = {"OASD"}
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")

        self.assertIn("Duration", result.descriptors.columns)
        self.assertIn("Modified Duration", result.descriptors.columns)
        self.assertIn("Effective Duration", result.descriptors.columns)
        self.assertNotIn("OASD", result.descriptors.columns)
        self.assertIn("FAILED", result.field_status["OASD"])
        self.assertTrue(
            any("OASD did not parse" in note for note in result.notes)
        )

    def test_candidate_universe_is_capped_at_twenty_under_ties(self):
        self.fake.large_ties = True
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertIsNotNone(self.fake.descriptor_ids)
        self.assertLessEqual(len(self.fake.descriptor_ids), 20)
        self.assertEqual(len(self.fake.descriptor_ids), len(set(self.fake.descriptor_ids)))

    def test_change_frame_accepts_a_date_column(self):
        self.fake.ranking_with_date = True
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertEqual(result.increases["ID"].tolist(), ["A"])
        self.assertEqual(result.decreases["ID"].tolist(), ["C"])
        self.assertFalse(result.errors)

    def test_parse_failure_is_still_logged(self):
        self.fake.bad_ranking_shape = True
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertTrue(any("Increases request failed" in item for item in result.errors))
        self.assertEqual(len(result.request_log), 2)
        self.assertTrue(all(entry["rows"] == "parse-failed" for entry in result.request_log))

    def test_documented_spread_code_is_accepted(self):
        result = fetch_movers("Z", "2026-01-25", "2026-02-01")
        self.assertEqual(self.fake.spread_args, ("Z", ("2026-01-25", "2026-02-01")))
        self.assertFalse(result.errors)

    def test_index_only_response_is_supported(self):
        self.fake.response_mode = "index"
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertEqual(result.increases["ID"].tolist(), ["A", "B"])
        self.assertFalse(result.errors)

    def test_invalid_inputs_return_errors_instead_of_raising(self):
        self.assertIn("Invalid input", fetch_movers("OAS", None, "2026-02-01").errors[0])
        self.assertIn("Invalid input", fetch_movers("OAS", "2026-02-02", "2026-02-01").errors[0])
        self.assertIn("Invalid input", fetch_movers("BOGUS", "2026-01-25", "2026-02-01").errors[0])

    def test_future_end_date_is_rejected(self):
        result = fetch_movers("OAS", "2026-01-25", "2999-01-01")
        self.assertIn("future", result.errors[0])

    def test_window_cap_is_enforced(self):
        result = fetch_movers("OAS", "2025-01-01", "2026-01-30")
        self.assertIn("capped at", result.errors[0])

    def test_missing_bql_returns_runtime_error(self):
        with patch.object(data, "bql", None):
            result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertTrue(result.increases.empty)
        self.assertIn("BQuant Desktop", result.errors[0])


class BondUniverseTests(unittest.TestCase):
    """The Bond source: one typed security, never a widened list."""

    def setUp(self):
        self.fake = FakeBQL()
        patcher = patch.object(data, "bql", self.fake)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_one_bond_is_wrapped_in_an_explicit_list_universe(self):
        result = fetch_movers(
            "OAS",
            "2026-01-25",
            "2026-02-01",
            index="US91282CLW91 Govt",
            source="bond",
        )
        # RAG KB/06: a private literal universe is wrapped in bq.univ.list().
        self.assertEqual(self.fake.descriptor_ids, ["A", "B", "C", "D"])
        self.assertIsNone(self.fake.members_args)
        self.assertIsNone(self.fake.aim_members_kwargs)
        self.assertEqual(result.source, "bond")
        self.assertEqual(result.universe, "US91282CLW91 Govt")

    def test_bond_ranking_carries_no_account_block(self):
        fetch_movers(
            "OAS", "2026-01-25", "2026-02-01", index="XS123 Corp", source="bond"
        )
        for request in self.fake.requests:
            self.assertIsNone(request.with_params)

    def test_bond_with_a_list_separator_is_refused(self):
        result = fetch_movers(
            "OAS",
            "2026-01-25",
            "2026-02-01",
            index="XS123 Corp, XS456 Corp",
            source="bond",
        )
        self.assertIn("not a list", result.errors[0])
        self.assertEqual(self.fake.requests, [])

    def test_bond_that_names_an_index_is_refused(self):
        result = fetch_movers(
            "OAS", "2026-01-25", "2026-02-01", index="LEGATRUU Index", source="bond"
        )
        self.assertIn("names an index", result.errors[0])
        self.assertEqual(self.fake.requests, [])

    def test_blank_bond_is_refused(self):
        result = fetch_movers(
            "OAS", "2026-01-25", "2026-02-01", index="   ", source="bond"
        )
        self.assertIn("Bond is empty", result.errors[0])
        self.assertEqual(self.fake.requests, [])


class ComparisonTests(unittest.TestCase):
    """AIM vs Index: two books, ranked separately, labelled, merged by book."""

    def setUp(self):
        self.fake = FakeBQL()
        patcher = patch.object(data, "bql", self.fake)
        patcher.start()
        self.addCleanup(patcher.stop)

    def _compare(self, index="LEGATRUU Index", aim="ABC123"):
        return data.fetch_comparison(
            "OAS", "2026-01-25", "2026-02-01", index=index, aim=aim
        )

    def test_both_values_are_required(self):
        for index, aim in (("", "ABC123"), ("LEGATRUU Index", ""), (" ", " ")):
            result = self._compare(index, aim)
            self.assertIn("Invalid input", result.errors[0])
        self.assertEqual(self.fake.requests, [])

    def test_each_book_keeps_its_own_ranking_and_rows_are_labelled(self):
        result = self._compare()
        self.assertTrue(result.comparison)
        self.assertEqual(result.source, config.COMPARISON_SOURCE)
        self.assertIn(config.UNIVERSE_COLUMN, result.increases.columns)
        self.assertEqual(
            sorted(set(result.increases[config.UNIVERSE_COLUMN])),
            ["AIM", "Index"],
        )
        self.assertEqual(
            sorted(set(result.decreases[config.UNIVERSE_COLUMN])),
            ["AIM", "Index"],
        )

    def test_four_ranking_requests_and_only_the_aim_side_carries_with_params(self):
        self._compare()
        ranking = [
            request for request in self.fake.requests if "Spread Change" in request.items
        ]
        self.assertEqual(len(ranking), 4)
        scoped = [request for request in ranking if request.with_params]
        self.assertEqual(len(scoped), 2)
        for request in scoped:
            self.assertEqual(request.with_params["accounts"], ["ABC123"])
        for request in ranking:
            if request.with_params is None:
                self.assertIsNotNone(request.universe)

    def test_descriptors_and_series_are_requested_once_on_the_union(self):
        self._compare()
        # A, B (increases) and C, D (decreases), deduplicated across both books.
        self.assertEqual(self.fake.descriptor_ids, ["A", "B", "C", "D"])
        descriptor_requests = [
            request
            for request in self.fake.requests
            if "Spread Change" not in request.items
        ]
        self.assertTrue(descriptor_requests)
        for request in descriptor_requests:
            self.assertIsNone(request.with_params)

    def test_a_full_two_book_run_describes_both_books(self):
        # Regression: the union used to be built with [:TOP_N] per side. The
        # comparison frames are stacked book by book, so that cut kept only the
        # first book's IDs. The second book's descriptor rows then never
        # existed and its cells read (blank) -- "we did not ask" presented as
        # "Bloomberg returned nothing".
        self.fake.full_books = True
        result = self._compare()

        requested = self.fake.descriptor_ids
        self.assertEqual(len(requested), 2 * config.TOP_N)
        self.assertEqual(len(set(requested)), 2 * config.TOP_N)
        self.assertEqual(sum(1 for value in requested if value.startswith("IDX")), config.TOP_N)
        self.assertEqual(sum(1 for value in requested if value.startswith("AIM")), config.TOP_N)
        # Both books really did rank TOP_N rows, so this is not a short-book run.
        self.assertEqual(len(result.increases), 2 * config.TOP_N)

    def test_the_candidate_union_is_bounded_by_the_ranking_not_by_position(self):
        self.fake.full_books = True
        result = self._compare()
        ids = data._candidate_ids(result)
        self.assertEqual(len(ids), 2 * config.TOP_N)
        self.assertEqual(ids, list(dict.fromkeys(ids)))
        self.assertTrue(any(value.startswith("AIM") for value in ids))

    def test_a_failed_descriptor_does_not_blank_the_ranked_rows(self):
        self.fake.failing_labels = {"Name"}
        result = self._compare()
        self.assertTrue(str(result.field_status.get("Name", "")).startswith("FAILED"))
        self.assertFalse(result.increases.empty)
        self.assertEqual(
            sorted(set(result.increases[config.UNIVERSE_COLUMN])), ["AIM", "Index"]
        )

    def test_normalize_universe_refuses_the_comparison_source(self):
        # The comparison needs two values; the single-value helper must not
        # silently run one book.
        with self.assertRaises(ValueError):
            data.normalize_universe("AIM vs Index", "LEGATRUU Index")


class NormalizeFrameTests(unittest.TestCase):
    def test_named_id_index(self):
        frame = _normalize_frame(
            rank_frame(["A", "B"], [1.0, -2.0]), "Spread Change", "Spread Change"
        )
        self.assertEqual(frame.columns.tolist(), ["ID", "Spread Change"])
        self.assertEqual(frame["ID"].tolist(), ["A", "B"])

    def test_id_column_and_lowercase_id(self):
        frame = _normalize_frame(
            pd.DataFrame({"id": ["A"], "value": [3.0]}), "Change", "Change"
        )
        self.assertEqual(frame.columns.tolist(), ["ID", "Change"])

    def test_unnamed_object_index_is_promoted(self):
        raw = pd.DataFrame(
            {"Spread": [1.0]}, index=pd.Index(["A"])
        )
        frame = _normalize_frame(raw, "Spread", "Spread")
        self.assertEqual(frame["ID"].tolist(), ["A"])

    def test_row_number_and_datetime_indexes_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "row-number index"):
            _normalize_frame(
                pd.DataFrame({"Spread": [1.0]}), "Spread", "Spread"
            )
        with self.assertRaisesRegex(ValueError, "not a security-ID index"):
            _normalize_frame(
                pd.DataFrame(
                    {"Spread": [1.0]}, index=pd.DatetimeIndex(["2026-01-01"])
                ),
                "Spread",
                "Spread",
            )

    def test_id_date_multiindex_is_flattened(self):
        raw = pd.DataFrame(
            {"Spread": [1.0, 2.0]},
            index=pd.MultiIndex.from_tuples(
                [("A", "2026-01-01"), ("A", "2026-02-01")],
                names=["ID", "DATE"],
            ),
        )
        frame = _normalize_frame(raw, "Spread", "Spread")
        self.assertEqual(frame.columns.tolist(), ["ID", "DATE", "Spread"])
        self.assertEqual(len(frame), 2)

    def test_wide_date_columns_are_melted(self):
        raw = pd.DataFrame(
            {"2026-01-01": [10.0], "2026-02-01": [12.0]},
            index=pd.Index(["A"], name="ID"),
        )
        frame = _normalize_frame(raw, "Spread", "Spread")
        self.assertEqual(frame.columns.tolist(), ["ID", "DATE", "Spread"])
        self.assertEqual(len(frame), 2)
        self.assertEqual(frame["Spread"].tolist(), [10.0, 12.0])

    def test_maturity_can_use_the_date_column_as_value(self):
        raw = pd.DataFrame(
            {"DATE": pd.to_datetime(["2030-01-01", "2031-01-01"])},
            index=pd.Index(["A", "B"], name="ID"),
        )
        frame = _normalize_frame(raw, "Maturity", "maturity", allow_date_value=True)
        self.assertEqual(frame.columns.tolist(), ["ID", "Maturity"])
        self.assertEqual(len(frame), 2)

    def test_object_date_or_numeric_indexes_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "not a security-ID index"):
            _normalize_frame(
                pd.DataFrame(
                    {"Spread": [1.0]}, index=pd.Index([date(2026, 1, 25)])
                ),
                "Spread",
                "Spread",
            )
        with self.assertRaisesRegex(ValueError, "not a security-ID index"):
            _normalize_frame(
                pd.DataFrame({"Spread": [1.0]}, index=pd.Index(["0", "1"])),
                "Spread",
                "Spread",
            )

    def test_extra_index_levels_fail_with_diagnostics(self):
        raw = pd.DataFrame(
            {"Spread": [1.0]},
            index=pd.MultiIndex.from_tuples(
                [("A", "2026-01-01", "X")], names=["ID", "DATE", "Scenario"]
            ),
        )
        with self.assertRaisesRegex(ValueError, "extra index levels"):
            _normalize_frame(raw, "Spread", "Spread")

    def test_single_wide_date_column_is_melted(self):
        raw = pd.DataFrame(
            {"2026-02-01": [120.0]}, index=pd.Index(["A"], name="ID")
        )
        frame = _normalize_frame(raw, "Spread", "Spread")
        self.assertEqual(frame.columns.tolist(), ["ID", "DATE", "Spread"])
        self.assertEqual(len(frame), 1)

    def test_invalid_date_column_names_fail_visibly(self):
        raw = pd.DataFrame(
            {"2026-01-01": [1.0], "9999-99-99": [2.0]},
            index=pd.Index(["A"], name="ID"),
        )
        with self.assertRaisesRegex(ValueError, "cannot identify the value column"):
            _normalize_frame(raw, "Spread", "Spread")

    def test_ambiguous_value_columns_fail_with_diagnostics(self):
        raw = pd.DataFrame(
            {"one": [1], "two": [2]}, index=pd.Index(["A"], name="ID")
        )
        with self.assertRaisesRegex(ValueError, "cannot identify the value column"):
            _normalize_frame(raw, "Rating", "rating")

    def test_blank_ids_are_dropped_and_counted(self):
        raw = pd.DataFrame(
            {"Spread": [1.0, 2.0, 3.0]},
            index=pd.Index(["A", "", "nan"], name="ID"),
        )
        frame = _normalize_frame(raw, "Spread", "Spread")
        self.assertEqual(frame["ID"].tolist(), ["A"])
        self.assertEqual(frame.attrs["dropped_ids"], 2)


class DurationFamilyTests(unittest.TestCase):
    """One request carries the three extra measures; failures stay local."""

    def setUp(self):
        self.fake = FakeBQL()
        patcher = patch.object(data, "bql", self.fake)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_one_request_carries_all_four_measures(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        duration_requests = [
            request for request in self.fake.requests if len(request.items) > 1
        ]
        self.assertEqual(len(duration_requests), 1)
        self.assertEqual(
            list(duration_requests[0].items),
            [label for label, _measure in config.DURATION_FIELDS],
        )
        self.assertEqual(len(config.DURATION_FIELDS), 4)

    def test_the_family_adds_no_request_beyond_the_one_duration_used_to_cost(self):
        # This is the whole point of the grouped shape: before the three extra
        # measures existed, `Duration` was one descriptor and therefore one
        # request. Four measures now cost that same one request.
        fetch_movers("OAS", "2026-01-25", "2026-02-01")
        duration_requests = [
            request for request in self.fake.requests if len(request.items) > 1
        ]
        self.assertEqual(len(duration_requests), 1)
        # Everything else is still a one-item request, so the family replaced
        # the old `Duration` request instead of sitting beside it.
        singles = [
            list(request.items)[0]
            for request in self.fake.requests
            if len(request.items) == 1
        ]
        duration_labels = [label for label, _ in config.DURATION_FIELDS]
        for label in duration_labels:
            self.assertNotIn(label, singles)
        self.assertEqual(len(singles), 2 + len(config.DESCRIPTOR_FIELDS) + 1)

    def test_the_measures_are_joined_on_id_for_the_ranked_rows(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        for label, _measure in config.DURATION_FIELDS:
            self.assertIn(label, result.descriptors.columns)
        row = result.descriptors.loc[result.descriptors["ID"] == "A"].iloc[0]
        self.assertEqual(float(row["Modified Duration"]), 4.25)
        self.assertEqual(float(row["OASD"]), 3.90)

    def test_each_measure_carries_its_own_duration_type(self):
        fetch_movers("OAS", "2026-01-25", "2026-02-01")
        # Declared order, with ``None`` for the bare call.
        self.assertEqual(
            self.fake.duration_args,
            [measure for _label, measure in config.DURATION_FIELDS],
        )

    def test_a_failed_family_keeps_the_ranking_and_names_the_measures(self):
        self.fake.failing_labels = {"OASD"}
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertEqual(result.increases["ID"].tolist(), ["A", "B"])
        self.assertIn("FAILED", result.field_status["Duration measures"])
        self.assertTrue(
            any("Duration measures" in note and "unavailable" in note for note in result.notes)
        )
        # Nothing was invented for the measures that never arrived.
        for label, _measure in config.DURATION_FIELDS:
            self.assertNotIn(label, result.descriptors.columns)

    def test_identical_measures_are_reported_rather_than_silently_accepted(self):
        # A builder that ignores duration_type returns one measure under three
        # names. Nothing raises, so the only defence is the note.
        result = FetchResult()
        result.descriptors = pd.DataFrame([{"ID": "A"}, {"ID": "B"}])
        same = pd.Series([4.25, 4.25])
        data._note_duplicate_duration(
            {"Modified Duration": same, "Effective Duration": same},
            "Duration measures",
            result.notes,
        )
        self.assertTrue(
            any("hold identical values" in note for note in result.notes)
        )

    def test_distinct_measures_produce_no_note(self):
        result = FetchResult()
        data._note_duplicate_duration(
            {
                "Modified Duration": pd.Series([4.25, 4.25]),
                "Effective Duration": pd.Series([4.10, 4.10]),
            },
            "Duration measures",
            result.notes,
        )
        self.assertEqual(result.notes, [])


class AllNullDescriptorTests(unittest.TestCase):
    """An all-null column is a data finding and must not read as a success."""

    def setUp(self):
        self.fake = FakeBQL()
        patcher = patch.object(data, "bql", self.fake)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_several_all_null_rows_mark_the_field_failed(self):
        self.fake.null_labels = {"Country"}
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertTrue(result.field_status["Country"].startswith("FAILED"))
        self.assertIn("all values null", result.field_status["Country"])
        self.assertTrue(
            any("Country returned 2 row(s) with no value" in note for note in result.notes)
        )

    def test_a_single_row_all_null_is_noted_but_not_failed(self):
        # The Bond path has one security; one missing value there is a per-bond
        # gap, not evidence that the whole field is broken.
        result = FetchResult()
        frame = pd.DataFrame({"ID": ["A"], "Country": [None]})
        non_null = int(frame["Country"].notna().sum())
        self.assertEqual(non_null, 0)
        self.assertEqual(len(frame), 1)

    def test_a_partly_populated_column_is_a_clean_success(self):
        result = fetch_movers("OAS", "2026-01-25", "2026-02-01")
        self.assertFalse(result.field_status["Country"].startswith("FAILED"))


class NamelessArrowResponse:
    """A Desktop Arrow response with no ``.get``, no ``len``, and no item names.

    ``RAG KB/07`` documents that shape: the object is a valid response, it just
    does not expose the item list. An app that only tries ``.get(name)`` and
    ``item.name`` reports it as "no item named ...", which reads as a rejected
    request when the request actually answered.
    """


class _CombinedModule:
    """A stand-in for the ``bql`` module, holding only ``combined_df``."""

    def __init__(self, frame):
        self.combined_df = lambda response: frame.copy()


class ResponseLookupTests(unittest.TestCase):
    """The documented Arrow fallback, and what it refuses to guess."""

    def test_a_nameless_response_is_read_through_combined_df(self):
        combined = pd.DataFrame(
            {"ID": ["A", "B"], "Spread Change": [1.5, -2.5]}
        )
        with patch.object(data, "bql", _CombinedModule(combined)):
            frame = data._item_frame(NamelessArrowResponse(), "Spread Change")
        self.assertEqual(list(frame.columns), ["ID", "Spread Change"])
        self.assertEqual(sorted(frame["ID"].tolist()), ["A", "B"])

    def test_an_empty_combined_frame_reads_as_zero_rows_not_an_error(self):
        combined = pd.DataFrame({"ID": pd.Series(dtype="object"), "Spread Change": pd.Series(dtype="float64")})
        with patch.object(data, "bql", _CombinedModule(combined)):
            frame = data._item_frame(NamelessArrowResponse(), "Spread Change")
        self.assertEqual(len(frame), 0)
        self.assertEqual(list(frame.columns), ["ID", "Spread Change"])

    def test_several_value_columns_are_refused_rather_than_guessed(self):
        # No column matches the name asked for, and there is more than one
        # candidate: picking one would label one measure with another's numbers.
        combined = pd.DataFrame({"ID": ["A"], "Duration": [1.0], "OASD": [2.0]})
        with patch.object(data, "bql", _CombinedModule(combined)):
            with self.assertRaises(ValueError) as caught:
                data._item_frame(NamelessArrowResponse(), "Modified Duration")
        message = str(caught.exception)
        self.assertIn("no item named 'Modified Duration'", message)
        self.assertIn("NamelessArrowResponse", message)

    def test_the_message_names_what_the_response_did_expose(self):
        response = FakeMultiResponse(
            [
                FakeItem("Some Other Item", pd.DataFrame()),
                FakeItem("Another Item", pd.DataFrame()),
            ]
        )
        with self.assertRaises(ValueError) as caught:
            data._response_item(response, "Spread Change")
        message = str(caught.exception)
        self.assertIn("2 item(s) exposed", message)
        self.assertIn("Some Other Item", message)

    def test_a_response_with_no_value_column_becomes_zero_ranked_rows(self):
        # A successful request that matched nothing is a 0-row answer, not a
        # column error: the ranking then reports "no rows" with a diagnostic.
        frame = data._change_frame(pd.DataFrame())
        self.assertEqual(list(frame.columns), ["ID", "Change"])
        self.assertTrue(frame.empty)

    def test_a_wide_date_frame_from_combined_df_is_folded_into_id_date_value(self):
        # A dated item comes back with one column per observation date. The
        # fallback must not rename one of them as the measure.
        combined = pd.DataFrame(
            {
                "ID": ["A", "B"],
                "2026-01-25": [100.0, 50.0],
                "2026-02-01": [120.0, 45.0],
            }
        )
        with patch.object(data, "bql", _CombinedModule(combined)):
            frame = data._item_frame(NamelessArrowResponse(), "Spread")
        self.assertEqual(list(frame.columns), ["ID", "DATE", "Spread"])
        self.assertEqual(len(frame), 4)


class _ZeroItemResponse:
    """A valid response that states it holds no item (``len`` is ``0``)."""

    def __len__(self):
        return 0


class _UncountableResponse:
    """A valid response whose item list this build will not report at all."""

    def __len__(self):
        raise TypeError("length is not supported for this response")


class EmptyVersusUnreadableResponseTests(unittest.TestCase):
    """``0`` items is an answer; an unreported count is a diagnostic.

    The two were printed with the same sentence, so an empty universe (end date
    = today, membership not published) read exactly like a misspelt data item.
    Only the response saying ``0`` may become zero rows; anything else keeps the
    error, because inventing an empty table over a response that cannot be read
    would be a silent wrong answer.
    """

    def test_a_zero_item_response_is_an_empty_answer(self):
        with self.assertRaises(data.EmptyResponseError):
            data._item_frame(_ZeroItemResponse(), "Spread Change")

    def test_an_unreadable_count_keeps_the_item_error(self):
        with self.assertRaises(ValueError) as caught:
            data._item_frame(_UncountableResponse(), "Spread Change")
        message = str(caught.exception)
        self.assertIn("no item named 'Spread Change'", message)
        self.assertIn("not exposed", message)
        self.assertNotIn("0 item(s)", message)

    def test_the_request_layer_turns_a_zero_item_response_into_zero_rows(self):
        result = FetchResult()
        entry_writer = result.request_log
        response = _ZeroItemResponse()
        with patch.object(data, "_execute_attempts", return_value=(response, 1)):
            out = data._request_frame(
                bql_module=type("M", (), {"Request": staticmethod(lambda *a, **k: None)}),
                bq=None,
                universe=None,
                output_name="Spread Change",
                item=None,
                result=result,
                label="Increases",
            )
        self.assertEqual(list(out.columns), ["ID", "Spread Change"])
        self.assertTrue(out.empty)
        self.assertEqual(entry_writer[-1]["rows"], 0)
        self.assertTrue(any("not a rejected data item" in note for note in result.notes))


class EmptyAnswerWordingTests(unittest.TestCase):
    """What an empty run is allowed to claim about the universe.

    A run with errors was **refused**, so nothing in it describes the book. The
    helper used to say "the account returned no ranked holding" for any empty
    result, which turns a `FILTER(...)` rejection into a statement about the
    account's holdings. Those are different facts and only one of them is known.
    """

    def test_a_failed_run_is_not_described_as_an_empty_book(self):
        result = FetchResult(errors=["Increases ranking: ResponseError: predicate"])
        data._note_empty_universe(
            result,
            "aim",
            "ACCOUNT",
            pd.Timestamp("2026-10-30"),
            start=pd.Timestamp("2026-10-26"),
        )
        text = " ".join(result.notes)
        self.assertIn("not ranked because its ranking request failed", text)
        # Never an assertion about holdings from a request that was refused.
        self.assertNotIn("no ranked holding", text)
        self.assertIn("nothing here is evidence about what the book holds", text)

    def test_a_completed_empty_aim_run_still_names_the_holdings_possibility(self):
        result = FetchResult()
        data._note_empty_universe(
            result,
            "aim",
            "ACCOUNT",
            pd.Timestamp("2026-10-30"),
            start=pd.Timestamp("2026-10-26"),
        )
        self.assertIn("returned no ranked holding", " ".join(result.notes))

    def test_a_bond_empty_run_has_its_own_advice(self):
        # A one-security universe has two different reasons to be empty — a
        # ticker that matches nothing and a bond that simply did not move — and
        # neither is an index-membership-date problem.
        result = FetchResult()
        data._note_empty_universe(
            result,
            "bond",
            "AAPL 4 % 05/12/35 Corp",
            pd.Timestamp("2026-10-30"),
            start=pd.Timestamp("2026-10-26"),
        )
        text = " ".join(result.notes)
        self.assertIn("Confirm the ticker on Terminal first", text)
        self.assertNotIn("index membership", text)


    def test_a_weekend_end_date_names_the_business_day_to_use(self):
        # Pure calendar arithmetic, no knowledge of Bloomberg's schedule: a
        # Saturday end date made the membership cohort empty, the ranking
        # completed with no item at all, and the operator read that as a broken
        # field. The suggestion is computed, not described.
        result = FetchResult()
        data._note_empty_universe(
            result,
            "index",
            "LEGATRUU Index",
            pd.Timestamp("2026-10-31"),
            start=pd.Timestamp("2026-10-26"),
        )
        text = " ".join(result.notes)
        self.assertIn("is a Saturday", text)
        self.assertIn("2026-10-30", text)
        self.assertIn("not a business day", text)

    def test_a_sunday_end_date_rolls_back_to_the_friday(self):
        result = FetchResult()
        data._note_empty_universe(
            result,
            "index",
            "LEGATRUU Index",
            pd.Timestamp("2026-11-01"),
            start=pd.Timestamp("2026-10-26"),
        )
        self.assertIn("2026-10-30", " ".join(result.notes))

    def test_a_today_end_date_is_not_described_as_a_weekend(self):
        # The two causes are different facts and get different sentences: a
        # weekend is a calendar fact, "today" is about the data still moving.
        result = FetchResult()
        today = pd.Timestamp(data.date.today()).normalize()
        data._note_empty_universe(
            result,
            "index",
            "LEGATRUU Index",
            today,
            start=today - pd.Timedelta(days=7),
        )
        text = " ".join(result.notes)
        if today.weekday() >= 5:
            self.assertIn("not a business day", text)
        else:
            self.assertIn("today or later", text)
            self.assertNotIn("not a business day", text)


class RankingFailureClassificationTests(unittest.TestCase):
    """A refused request and an empty result must not read the same.

    The AIM run on 2026-11-02 returned
    `BQLInternalExecutionError ... Predicate must be a Boolean expression` inside
    `FILTER(MEMBERS(type='AIM'), ...)`. The app reported "the account returned no
    ranked holding", which asserts something about the book that the request never
    established. These cases pin the wording.
    """

    def _boom(self, message):
        return RuntimeError(message)

    def test_a_predicate_refusal_is_named_a_universe_finding(self):
        exc = self._boom(
            "ResponseError: [BQLInternalExecutionError] - An error occurred while "
            "running the query. Error encountered while processing "
            "FILTER(MEMBERS(type='AIM'),(NET_CHG(SPREAD(...))>0)) clause. "
            "Predicate must be a Boolean expression."
        )
        reason = data._explain_ranking_error(exc, {"accounts": ["X"]})
        self.assertIn("before evaluating it", reason)
        self.assertIn("universe-compatibility finding", reason)
        self.assertIn("not evidence about holdings", reason)

    def test_the_account_block_is_named_as_the_difference(self):
        exc = self._boom("Predicate must be a Boolean expression")
        self.assertIn(
            "the AIM account universe",
            data._explain_ranking_error(exc, {"accounts": ["X"]}),
        )
        self.assertIn(
            "this universe",
            data._explain_ranking_error(exc, None),
        )

    def test_an_unrelated_error_gets_no_invented_reason(self):
        # A timeout is handled elsewhere; wrapping every message in a story
        # would be worse than printing the message alone.
        self.assertEqual(data._explain_ranking_error(self._boom("Query Timed out"), None), "")
        self.assertEqual(data._explain_ranking_error(self._boom("boom"), {}), "")


if __name__ == "__main__":
    unittest.main()
