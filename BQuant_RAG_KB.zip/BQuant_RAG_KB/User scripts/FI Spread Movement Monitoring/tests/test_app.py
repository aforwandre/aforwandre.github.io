"""Local widget-stub tests for the Update-only app. No BQL is executed."""

from __future__ import annotations

import re
import sys
import tempfile
import types
import unittest
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


class _Button:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.disabled = False
        self._handlers = []

    def on_click(self, handler):
        self._handlers.append(handler)


class _HTML:
    def __init__(self, value=""):
        self.value = value


class _Output:
    def __init__(self):
        self.entries = []

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        return False

    def clear_output(self, wait=False):
        self.entries.clear()


class _Box:
    def __init__(self, children=(), **kwargs):
        self.children = list(children)
        self.layout = kwargs.get("layout")


class _Observed:
    """``observe`` / ``unobserve`` support for the trait-driven widgets."""

    def observe(self, handler, names="value"):
        self._observers.append((handler, names))

    def unobserve(self, handler, names="value"):
        self._observers = [item for item in self._observers if item[0] is not handler]


class _DatePicker(_Observed):
    def __init__(self, description="", value=None):
        self._observers = []
        self.description = description
        self.value = value


class _Text(_Observed):
    def __init__(self, description="", value="", placeholder="", **kwargs):
        self._observers = []
        self.description = description
        self.value = value
        self.placeholder = placeholder


class _IntText(_Observed):
    """Stub for ``widgets.IntText``: the Display Top box."""

    def __init__(self, description="", value=0, **kwargs):
        self._observers = []
        self.description = description
        self.value = value
        self.layout = kwargs.get("layout")


class _Dropdown(_Observed):
    def __init__(self, description="", options=(), value=None, **kwargs):
        self._observers = []
        self.description = description
        self.options = list(options)
        self.value = value
        self.style = kwargs.get("style")
        self.layout = kwargs.get("layout")


class _SelectMultiple(_Observed):
    """Stub for ``widgets.SelectMultiple``: options and a tuple value."""

    def __init__(self, description="", options=(), value=(), **kwargs):
        self._observers = []
        self.description = description
        self.options = list(options)
        self.value = tuple(value)
        # Geometry, copied from the real widget's constructor arguments so the
        # layout-parity tests can read them back.
        self.rows = kwargs.get("rows")
        self.style = kwargs.get("style")
        self.layout = kwargs.get("layout")

    def __setattr__(self, name, value):
        # ipywidgets coerces the assigned value to a tuple of legal options.
        if name == "value":
            value = tuple(value or ())
        object.__setattr__(self, name, value)


class _Layout:
    def __init__(self, **kwargs):
        self.kwargs = kwargs


class _Tab:
    """Stub for ``widgets.Tab``: named children and a selected index."""

    def __init__(self, children=(), titles=(), **kwargs):
        self.children = list(children)
        self.titles = list(titles)
        self.selected_index = 0
        self.layout = kwargs.get("layout")

    def set_title(self, index, title):
        while len(self.titles) <= index:
            self.titles.append("")
        self.titles[index] = title


widgets = types.ModuleType("ipywidgets")
widgets.Button = _Button
widgets.HTML = _HTML
widgets.Output = _Output
widgets.VBox = _Box
widgets.HBox = _Box
widgets.DatePicker = _DatePicker
widgets.Dropdown = _Dropdown
widgets.Text = _Text
widgets.IntText = _IntText
widgets.SelectMultiple = _SelectMultiple
widgets.Layout = _Layout
widgets.Tab = _Tab
sys.modules["ipywidgets"] = widgets

ipython = types.ModuleType("IPython")
display_module = types.ModuleType("IPython.display")
displayed: list = []
display_module.display = lambda obj: displayed.append(obj)
ipython.display = display_module
sys.modules["IPython"] = ipython
sys.modules["IPython.display"] = display_module

from fi_spread_movement import app as app_module  # noqa: E402
from fi_spread_movement import cache as cache_module  # noqa: E402
from fi_spread_movement import charts  # noqa: E402
from fi_spread_movement import config  # noqa: E402
from fi_spread_movement.data import FetchResult  # noqa: E402


def make_app(**kwargs):
    """Build the app with its own throwaway cache directory.

    A suite run must never write into the operator's real ``cache/`` folder, and
    one test must never read a run another test saved. Both went wrong once and
    made a failing-Update test pass by loading a cached success from an earlier
    test, so every construction in this module goes through here.
    """
    if "cache_root" not in kwargs:
        kwargs["cache_root"] = tempfile.mkdtemp(prefix="fi-spread-cache-")
    return app_module.FISpreadMovementApp(**kwargs)


def _fetch_result():
    result = FetchResult()
    result.increases = pd.DataFrame(
        [{"ID": "A", "Change": 20.0}, {"ID": "B", "Change": 5.0}]
    )
    result.decreases = pd.DataFrame([{"ID": "C", "Change": -10.0}])
    result.descriptors = pd.DataFrame(
        [{"ID": "A", "Name": "Alpha"}, {"ID": "C", "Name": "Charlie"}]
    )
    result.series = pd.DataFrame(
        [
            {"ID": "A", "DATE": pd.Timestamp("2026-01-25"), "Spread": 100.0},
            {"ID": "A", "DATE": pd.Timestamp("2026-02-01"), "Spread": 120.0},
            {"ID": "C", "DATE": pd.Timestamp("2026-01-25"), "Spread": 90.0},
            {"ID": "C", "DATE": pd.Timestamp("2026-02-01"), "Spread": 80.0},
        ]
    )
    result.field_status = {"Name": "returned 2 row(s)"}
    result.request_log = [{"label": "x", "elapsed_sec": 0.1, "rows": 2, "columns": "ID, Change"}]
    return result


def _view_result():
    """A run whose descriptors give all three filters real distinct values."""
    result = FetchResult()
    result.increases = pd.DataFrame(
        [
            {"ID": "A", "Change": 20.0},
            {"ID": "B", "Change": 5.0},
        ]
    )
    result.decreases = pd.DataFrame([{"ID": "C", "Change": -10.0}])
    result.descriptors = pd.DataFrame(
        [
            {
                "ID": "A",
                "Name": "Alpha",
                "Rating": "AA",
                "Currency": "USD",
                "Maturity": "2031-01-25",
            },
            {
                "ID": "B",
                "Name": "Beta",
                "Rating": "BB",
                "Currency": "EUR",
                "Maturity": "2035-06-01",
            },
            {
                "ID": "C",
                "Name": "Charlie",
                "Rating": "NR",
                "Currency": "USD",
                "Maturity": "2027-03-01",
            },
        ]
    )
    result.series = pd.DataFrame(
        [
            {"ID": "A", "DATE": pd.Timestamp("2026-01-25"), "Spread": 100.0},
            {"ID": "A", "DATE": pd.Timestamp("2026-02-01"), "Spread": 120.0},
            {"ID": "C", "DATE": pd.Timestamp("2026-01-25"), "Spread": 90.0},
            {"ID": "C", "DATE": pd.Timestamp("2026-02-01"), "Spread": 80.0},
        ]
    )
    result.field_status = {"Name": "returned 3 row(s)"}
    return result


def _comparison_result():
    """The same payload with two labelled books, as the comparison run returns."""
    result = _fetch_result()
    result.source = config.COMPARISON_SOURCE
    result.comparison = True
    result.universe = "LEGATRUU Index vs ABC123"
    # Bond A is an index member AND an account holding, with two changes.
    result.increases = pd.DataFrame(
        [
            {"ID": "A", "Change": 20.0, config.UNIVERSE_COLUMN: "Index"},
            {"ID": "B", "Change": 5.0, config.UNIVERSE_COLUMN: "Index"},
            {"ID": "A", "Change": 12.0, config.UNIVERSE_COLUMN: "AIM"},
        ]
    )
    result.decreases = pd.DataFrame(
        [
            {"ID": "C", "Change": -10.0, config.UNIVERSE_COLUMN: "Index"},
            {"ID": "B", "Change": -3.0, config.UNIVERSE_COLUMN: "AIM"},
        ]
    )
    return result


class AppTests(unittest.TestCase):
    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.universe_input.value = "LEGATRUU Index"

    def _main_rows(self, app=None):
        """The Main tab's children, in layout order."""
        app = app or self.app
        return list(app.tabs.children[config.TAB_MAIN].children)

    def _row_holding(self, widget, app=None):
        """The HBox or VBox that directly holds one control, or None."""
        for row in self._main_rows(app):
            if isinstance(row, _Box) and any(child is widget for child in row.children):
                return row
        return None

    def test_the_layout_is_two_tabs_named_main_and_export_excel(self):
        # The operator asked for the dashboard under Main and the copy/paste
        # tables under Export Excel, exactly as FI Index Change splits them.
        self.assertEqual(list(self.app.tabs.titles), ["Main", "Export Excel"])
        self.assertEqual(len(self.app.tabs.children), 2)
        self.assertEqual(self.app.tabs.selected_index, config.TAB_MAIN)
        self.assertIs(self.app.tabs.children[config.TAB_MAIN], self.app.main_tab)
        self.assertIs(self.app.tabs.children[config.TAB_EXPORT], self.app.export_body)

    def test_index_starts_empty_with_the_example_as_placeholder(self):
        fresh = make_app()
        self.assertEqual(fresh.universe_input.value, "")
        self.assertEqual(fresh.universe_input.placeholder, "LEGATRUU Index")
        row = fresh.universe_row.children
        # Universe source first, then the field it labels. Spread moved off this
        # row so the source and its value stay one unit.
        self.assertIs(row[0], fresh.universe_source)
        self.assertIs(row[1], fresh.index_input)
        self.assertEqual(len(row), 2)
        spread_row = self._row_holding(fresh.spread_type, fresh)
        self.assertIsNotNone(spread_row)
        self.assertNotIn(fresh.spread_type, list(row))

    def test_the_date_pair_sits_on_its_own_row(self):
        # The date fields are one unit. Keeping them off the Universe row is
        # what stops a narrow notebook from wrapping one date away from the
        # other.
        fresh = make_app()
        date_row = self._row_holding(fresh.start_date, fresh)
        self.assertIsNotNone(date_row)
        self.assertEqual(list(date_row.children), [fresh.start_date, fresh.end_date])
        self.assertIsNot(self._row_holding(fresh.universe_source, fresh), date_row)

    def test_universe_dropdown_offers_all_four_sources(self):
        self.assertEqual(
            list(self.app.universe_source.options),
            ["Index", "AIM account", "AIM vs Index", "Bond"],
        )
        self.assertEqual(self.app.universe_source.value, "Index")
        self.assertEqual(self.app.universe_input.description, "Index")

    def test_source_switch_swaps_the_visible_fields_and_keeps_typed_values(self):
        # Each source reads its own field, so a value typed for one source can
        # never be sent as another source's universe. Switching back keeps what
        # was typed in each field.
        self.app.index_input.value = "LEGATRUU Index"
        self.app.universe_source.value = "AIM account"
        self.app._on_source_change(None)
        self.assertEqual(
            [widget.description for widget in self.app.universe_row.children[1:]],
            ["AIM code"],
        )
        self.assertEqual(self.app.aim_input.placeholder, "ABC123")
        self.assertEqual(self.app.aim_input.value, "")
        self.assertEqual(self.app.index_input.value, "LEGATRUU Index")

        self.app.universe_source.value = "Index"
        self.app._on_source_change(None)
        self.assertEqual(
            [widget.description for widget in self.app.universe_row.children[1:]],
            ["Index"],
        )
        self.assertEqual(self.app.index_input.value, "LEGATRUU Index")

    def test_the_comparison_source_shows_both_fields_at_once(self):
        self.app.universe_source.value = "AIM vs Index"
        self.app._on_source_change(None)
        self.assertEqual(
            [widget.description for widget in self.app.universe_row.children[1:]],
            ["AIM code", "Index"],
        )

    def test_the_comparison_fields_keep_their_own_values_after_the_reorder(self):
        """AIM first is a layout order, not a remapping of the two fields."""
        self.app.universe_source.value = "AIM vs Index"
        self.app._on_source_change(None)
        self.app.aim_input.value = "ABC123"
        self.app.index_input.value = "LEGATRUU Index"
        self.app._on_source_change(None)
        self.assertEqual(self.app.aim_input.value, "ABC123")
        self.assertEqual(self.app.index_input.value, "LEGATRUU Index")
        self.assertEqual(
            [widget.description for widget in self.app.universe_row.children[1:]],
            ["AIM code", "Index"],
        )

    def test_the_bond_source_shows_one_bond_field(self):
        self.app.universe_source.value = "Bond"
        self.app._on_source_change(None)
        self.assertEqual(
            [widget.description for widget in self.app.universe_row.children[1:]],
            ["Bond"],
        )
        self.assertIn("one bond ticker", self.app.bond_input.placeholder.lower())

    def test_aim_blank_code_does_not_fetch(self):
        self.app.universe_source.value = "AIM account"
        self.app.universe_input.value = "   "
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("AIM account is empty", self.app.status.value)
        self.assertIn("Request not sent", self.app.detail.value)

    def test_aim_code_is_upper_cased_and_passed_with_the_source(self):
        self.app.universe_source.value = "AIM account"
        self.app.universe_input.value = " abc123 "
        seen = {}

        def fake_fetch(spread, start, end, universe, source=None):
            seen["universe"] = universe
            seen["source"] = source
            return _fetch_result()

        with patch.object(app_module, "fetch_movers", side_effect=fake_fetch):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertEqual(seen["universe"], "ABC123")
        self.assertEqual(seen["source"], "aim")
        self.assertIn("AIM account ABC123", self.app.status.value)

    def test_aim_code_with_an_inner_space_is_refused(self):
        self.app.universe_source.value = "AIM account"
        self.app.universe_input.value = "ABC 123"
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("one account code", self.app.status.value)

    def test_aim_run_explains_the_frozen_request_contract(self):
        self.app.universe_source.value = "AIM account"
        self.app.universe_input.value = "ABC123"
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertIn("with_params", self.app.detail.value)
        self.assertIn("whole-account holdings", self.app.detail.value)
        self.assertNotIn("index membership", self.app.detail.value)

    def test_index_run_keeps_the_membership_note(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertIn("index membership as of the end date", self.app.detail.value)
        self.assertNotIn("with_params", self.app.detail.value)

    def test_switching_the_source_after_a_load_asks_for_update(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.app.universe_source.value = "AIM account"
        self.app._refresh_selection_state()
        self.assertIn("Please Click Update", self.app.status.value)

    def test_blank_index_does_not_fetch(self):
        self.app.universe_input.value = "   "
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("empty", self.app.status.value)
        self.assertFalse(self.app.update_button.disabled)

    def test_ticker_without_the_index_suffix_does_not_fetch(self):
        self.app.universe_input.value = "LEGATRUU"
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("must end with", self.app.status.value)

    def test_status_names_the_typed_index(self):
        self.app.universe_input.value = "LF98TRUU Index"
        seen = {}

        def fake_fetch(spread, start, end, index, source=None):
            seen["index"] = index
            return _fetch_result()

        with patch.object(app_module, "fetch_movers", side_effect=fake_fetch):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertEqual(seen["index"], "LF98TRUU Index")
        self.assertIn("LF98TRUU Index", self.app.status.value)
        self.assertNotIn("LEGATRUU", self.app.status.value)

    def test_constructor_does_not_fetch(self):
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            make_app()
        self.assertIn("Idle", self.app.status.value)
        self.assertIn("Environment: Idle", self.app.status.value)
        self.assertIn(f"Top {config.TOP_N}", self.app.detail.value)

    def test_no_version_stamp_is_shown_anywhere(self):
        # The stamp was a hand-edited dated string, so it drifted and told the
        # operator nothing the request log does not already date. It is gone from
        # the project, not merely hidden: neither the title, the detail panel,
        # nor the status bar may print it again.
        self.assertFalse(hasattr(config, "REQUEST_STAMP"))
        self.assertEqual(app_module.APP_TITLE, "FI Spread Movement Monitoring")
        for surface in (self.app.detail.value, self.app.status.value):
            self.assertNotIn("validation build", surface.lower())
            self.assertNotIn("(V1)", surface)
            self.assertNotIn("not production approval", surface.lower())
        self.assertNotIn("Stamp", app_module.TITLE_HTML)
        self.assertNotIn("V1", app_module.TITLE_HTML)

    def test_update_renders_tables_and_status(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

        self.assertFalse(self.app.update_button.disabled)
        # The bar keeps the phase and the Environment line; the long run summary
        # lives in the detail panel.
        self.assertIn(">Updated<", self.app.status.value)
        self.assertIn("Environment: Idle", self.app.status.value)
        self.assertIn("Requests:", self.app.detail.value)
        rendered = [getattr(item, "value", "") for item in displayed]
        # The two ranked tables are panels under their own charts, so the page
        # body no longer repeats them. The retired validation table is gone for
        # good: its findings are log text, not a second copy of the page.
        self.assertIn("Top 10 increases", self.app.increase_table.value)
        self.assertIn("Top 10 decreases", self.app.decrease_table.value)
        self.assertTrue(rendered)
        self.assertFalse(any("Effective-date" in text for text in rendered))

    def test_the_ranked_table_headings_name_the_spread_type(self):
        # The same bond has an OAS, a Z and an I. A heading that says only
        # "Change" cannot be read back later, so the loaded spread type is part
        # of every spread heading and every cell keeps its real value.
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

        table = self.app.increase_table.value
        self.assertIn("<th>Start OAS</th>", table)
        self.assertIn("<th>End OAS</th>", table)
        self.assertIn("<th>OAS Change</th>", table)
        self.assertNotIn("<th>Change</th>", table)
        self.assertNotIn("<th>Spread</th>", table)
        # A carried A series is 100 -> 120, and B has no series row at all.
        self.assertIn("<td>100.0</td>", table)
        self.assertIn("<td>120.0</td>", table)

    def test_the_start_and_end_levels_follow_the_loaded_spread_type(self):
        result = _fetch_result()
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app.spread_type.value = "Z"
                self.app._on_update(None)

        table = self.app.increase_table.value
        self.assertIn("<th>Start Z</th>", table)
        self.assertIn("<th>End Z</th>", table)
        self.assertIn("<th>Z Change</th>", table)

    def test_the_export_copy_keeps_the_spread_headings(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

        frame = self.app.export_frame("increases")
        headers = [str(column) for column in frame.columns]
        self.assertIn("Start OAS", headers)
        self.assertIn("End OAS", headers)
        self.assertIn("OAS Change", headers)
        # The repeated header row of the paste carries the same headings.
        self.assertEqual(frame.iloc[0].tolist(), headers)
        # The run that fed the charts and the click handlers keeps the
        # canonical names, so the rename stays a label and never a contract.
        self.assertIn("Change", self.app._frames["increases"].columns)
        self.assertIn("Start Spread", self.app._frames["increases"].columns)

    def test_a_ranked_id_with_no_series_keeps_a_blank_level(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

        frame = self.app._frames["increases"]
        row = frame.loc[frame["ID"] == "B"].iloc[0]
        self.assertTrue(pd.isna(row["Start Spread"]))
        self.assertTrue(pd.isna(row["End Spread"]))
        self.assertEqual(float(row["Change"]), 5.0)

    def test_exception_clears_stale_results_and_shows_error(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertTrue(displayed)

        with patch.object(
            app_module,
            "fetch_movers",
            side_effect=RuntimeError("synthetic BQL failure"),
        ):
            self.app._on_update(None)

        self.assertIn("Error:", self.app.status.value)
        self.assertIn("RuntimeError", self.app.status.value)
        self.assertFalse(self.app.update_button.disabled)
        # The failed run leaves no figure behind for the red bar to vouch for:
        # the tables are empty and the last run's frames are gone.
        self.assertIn("No rows to list", self.app.increase_table.value)
        self.assertIn("No rows to list", self.app.decrease_table.value)
        self.assertFalse(self.app._frames)
        self.assertFalse(self.app._comparison)
        self.assertIn("No result loaded", self.app.headline.value)

    def test_start_after_end_clears_previous_results(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.app.start_date.value = date(2026, 2, 1)
        self.app.end_date.value = date(2026, 1, 1)
        self.app._on_update(None)
        self.assertIn("earlier than end date", self.app.status.value)

    def test_future_and_too_wide_windows_are_blocked(self):
        self.app.start_date.value = date.today()
        self.app.end_date.value = date.today() + timedelta(days=1)
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("future", self.app.status.value)

        self.app.start_date.value = date.today() - timedelta(days=400)
        self.app.end_date.value = date.today()
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("capped at", self.app.status.value)

    def test_update_disables_the_button_during_the_request(self):
        observed = {}

        def fake_fetch(*_args, **_kwargs):
            observed["disabled"] = self.app.update_button.disabled
            return _fetch_result()

        with patch.object(app_module, "fetch_movers", side_effect=fake_fetch):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

        self.assertTrue(observed.get("disabled"))
        self.assertFalse(self.app.update_button.disabled)

    def test_post_fetch_exception_keeps_request_and_field_diagnostics(self):
        result = _fetch_result()
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(
                app_module,
                "prepare_ranked_movers",
                side_effect=ValueError("synthetic merge failure"),
            ):
                self.app._on_update(None)

        self.assertIn("Error:", self.app.status.value)
        self.assertIn("synthetic merge failure", self.app.status.value)
        self.assertIn("Requests executed before the error", self.app.detail.value)
        # The per-field receipt is request metadata, so only a FAILED field is
        # written to the page; the successful receipt lives in Export Excel.
        logged = [getattr(item, "value", "") for item in displayed]
        self.assertFalse(any("returned 2 row(s)" in line for line in logged))
        self.assertIn("Request detail", self.app.export_note.value)

    def test_a_failed_field_stays_visible_in_the_log(self):
        result = _fetch_result()
        result.field_status = {"Name": "returned 2 row(s)", "Country": "FAILED: timeout"}
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        logged = [getattr(item, "value", "") for item in displayed]
        self.assertTrue(any("Country: FAILED" in line for line in logged))
        self.assertFalse(any("Name: returned 2 row(s)" in line for line in logged))
        self.assertFalse(any("Descriptor and series status" in text for text in logged))

    def test_headings_follow_the_display_top_box(self):
        # The heading is the number the panel actually draws, so it must follow
        # the Display Top box and not a hard-coded 10. The default of that box is
        # ``config.TOP_N``, which a new run restores.
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.app.display_top_inputs["increases"].value = 5
        self.app.display_top_inputs["decreases"].value = 7
        self.app._on_display_top("increases")
        self.app._on_display_top("decreases")
        # The two ranked tables sit under their own charts now, not in the
        # bottom output area, so the heading is read from the table widget.
        self.assertIn("Top 5 increases", self.app.increase_table.value)
        self.assertIn("Top 7 decreases", self.app.decrease_table.value)
        self.assertNotIn("Top 10 increases", self.app.increase_table.value)

    def test_the_request_log_is_not_on_the_main_page(self):
        result = FetchResult()
        result.errors = ["synthetic failure"]
        result.request_log = [
            {"label": "Increases ranking", "elapsed_sec": 0.2, "rows": "parse-failed", "columns": "boom"}
        ]
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        rendered = [getattr(item, "value", "") for item in displayed]
        # Request metadata is diagnostic; the Export Excel tab keeps it (DR-16).
        self.assertFalse(any("Request log" in text for text in rendered))
        self.assertIn("requests", self.app._export_frames())
        self.assertTrue(any("No ranked movers" in text for text in rendered))

    def test_error_only_result_does_not_render_success_tables(self):
        result = FetchResult()
        result.errors = ["BQL request failed"]
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        rendered = [getattr(item, "value", "") for item in displayed]
        self.assertTrue(any("No ranked movers" in text for text in rendered))
        self.assertFalse(any("Top 10 increases" in text for text in rendered))
        # The table panels are cleared too, so a failed run cannot leave the
        # previous run's rows under a red bar.
        self.assertIn("No rows to list", self.app.increase_table.value)
        self.assertNotIn("<table", self.app.increase_table.value)


class StatusBarTests(unittest.TestCase):
    """The two-line bar, adapted from FI Index Change. No request is ever sent."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()

    def _load(self):
        self.app.universe_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def test_bar_has_a_phase_line_and_an_environment_line(self):
        self.assertIn("Idle", self.app.status.value)
        self.assertIn("Environment: Idle", self.app.status.value)
        # Idle phase is red, the Idle environment is green.
        self.assertIn("#c62828", self.app.status.value)
        self.assertIn("#1b7f37", self.app.status.value)

    def test_bar_carries_no_version_stamp(self):
        self.assertNotIn("Stamp", self.app.status.value)
        self.assertNotIn("2026-11-01a", self.app.status.value)

    def test_environment_reads_processing_only_while_running(self):
        observed = {}

        def fake_fetch(*_args, **_kwargs):
            observed["status"] = self.app.status.value
            return _fetch_result()

        self.app.universe_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", side_effect=fake_fetch):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

        self.assertIn("Environment: Processing", observed["status"])
        self.assertIn("Loading", observed["status"])
        self.assertIn("Environment: Idle", self.app.status.value)

    def test_updated_phase_is_green(self):
        self._load()
        self.assertIn('color:#1b7f37">Updated', self.app.status.value)
        self.assertIn("Environment: Idle", self.app.status.value)

    def test_refused_input_is_red_and_sends_nothing(self):
        self.app.universe_input.value = "LEGATRUU"
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn('color:#c62828">Refused', self.app.status.value)
        self.assertIn("Environment: Idle", self.app.status.value)
        self.assertIn("Request not sent", self.app.detail.value)

    def test_editing_a_control_after_a_load_asks_for_update(self):
        self._load()
        self.assertIn(">Updated<", self.app.status.value)
        self.app.spread_type.value = "Z-Spread"
        # The local handler compares the visible controls with the loaded run.
        self.app._refresh_selection_state()
        self.assertIn("Please Click Update", self.app.status.value)
        self.assertIn("Environment: Idle", self.app.status.value)

    def test_the_universe_handler_itself_asks_for_update(self):
        # The dropdown is bound to ``_on_source_change``, so that handler has to
        # restate the bar. Otherwise a switch to Bond hides the bucket panels
        # under a green "Updated" that belongs to the previous run.
        self._load()
        self.assertIn(">Updated<", self.app.status.value)
        self.app.universe_source.value = "Bond"
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_source_change(None)
        self.assertIn("Please Click Update", self.app.status.value)

    def test_switching_the_source_back_restores_updated(self):
        self._load()
        original = self.app.universe_source.value
        self.app.universe_source.value = "Bond"
        self.app._on_source_change(None)
        self.assertIn("Please Click Update", self.app.status.value)
        self.app.universe_source.value = original
        self.app._on_source_change(None)
        self.assertIn(">Updated<", self.app.status.value)

    def test_editing_before_any_load_keeps_the_idle_bar(self):
        self.app.universe_input.value = "LF98TRUU Index"
        self.app._refresh_selection_state()
        self.assertIn("Idle", self.app.status.value)
        self.assertNotIn("Please Click Update", self.app.status.value)

    def test_matching_control_does_not_raise_the_pending_phase(self):
        self._load()
        self.app._refresh_selection_state()
        self.assertIn(">Updated<", self.app.status.value)
        self.assertNotIn("Please Click Update", self.app.status.value)

    def test_putting_the_control_back_restores_updated(self):
        # An edit that is undone leaves the tables matching the loaded run, so a
        # red "Please Click Update" would invite a second, unnecessary request.
        self._load()
        original = self.app.spread_type.value
        self.app.spread_type.value = "Z-Spread"
        self.app._refresh_selection_state()
        self.assertIn("Please Click Update", self.app.status.value)
        self.app.spread_type.value = original
        self.app._refresh_selection_state()
        self.assertIn(">Updated<", self.app.status.value)
        self.assertNotIn("Please Click Update", self.app.status.value)

    def test_second_click_is_ignored_while_a_run_is_active(self):
        self.app.universe_input.value = "LEGATRUU Index"
        calls = []

        def fake_fetch(*_args, **_kwargs):
            calls.append(1)
            self.app._on_update(None)  # re-entrant click
            return _fetch_result()

        with patch.object(app_module, "fetch_movers", side_effect=fake_fetch):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertEqual(len(calls), 1)

    def test_event_binding_is_idempotent(self):
        before = len(self.app.update_button._handlers)
        self.app._bind_events()
        self.app._bind_events()
        self.assertEqual(len(self.app.update_button._handlers), before)

    def test_log_keeps_one_line_per_stage(self):
        self._load()
        logged = [getattr(item, "value", "") for item in displayed]
        self.assertTrue(any("Checking the universe" in line for line in logged))
        self.assertTrue(any("Requesting OAS changes" in line for line in logged))
        self.assertTrue(any("Ranking the movers" in line for line in logged))

    def test_log_is_cleared_at_the_start_of_the_next_run(self):
        self._load()
        displayed.clear()
        self.app.universe_input.value = "LEGATRUU"
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        logged = [getattr(item, "value", "") for item in displayed]
        # Only this run's steps remain: the check line plus the refusal.
        self.assertEqual(len(logged), 2)
        self.assertIn("Checking the universe", logged[0])
        self.assertIn("Refused", logged[-1])
        self.assertFalse(any("Ranking the movers" in line for line in logged))


class ViewPanelTests(unittest.TestCase):
    """Filters, grouping, charts, and click detail. All local; never a request."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()

    def _load(self, result=None):
        """Load a run with bond-shaped descriptors so the filters have values."""
        payload = _view_result() if result is None else result
        self.app.universe_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", return_value=payload):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def test_filters_start_on_all_only(self):
        for label, _column in config.FILTER_COLUMNS:
            widget = self.app.filters[label]
            self.assertEqual(list(widget.options), [config.ALL_FILTER_LABEL])
            self.assertEqual(tuple(widget.value), (config.ALL_FILTER_LABEL,))

    def test_every_filter_has_a_planted_column(self):
        for label, column in config.FILTER_COLUMNS:
            self.assertIn(column, config.DIMENSIONS.values(), msg=label)

    def test_a_load_populates_the_options_from_the_returned_descriptors(self):
        self._load()
        self.assertIn("USD", self.app.filters["Currency"].options)
        self.assertIn("IG", self.app.filters["Rating"].options)
        self.assertTrue(
            any(option != config.ALL_FILTER_LABEL for option in self.app.filters["Tenor"].options)
        )

    def test_a_load_resets_each_filter_to_all(self):
        self._load()
        for label, _column in config.FILTER_COLUMNS:
            self.assertEqual(tuple(self.app.filters[label].value), (config.ALL_FILTER_LABEL,))

    def test_a_filter_change_redraws_without_a_fetch(self):
        self._load()
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app.filters["Currency"].value = ("USD",)
            self.app._on_view_change(None)
        self.assertIn("1 filter(s) applied", self.app.headline.value)

    def test_a_filter_change_does_not_change_the_status_bar(self):
        self._load()
        before = self.app.status.value
        self.app.filters["Currency"].value = ("USD",)
        self.app._on_view_change(None)
        self.assertEqual(self.app.status.value, before)

    def test_an_impossible_filter_empties_the_view_without_raising(self):
        self._load()
        self.app.filters["Currency"].value = ("JPY",)
        self.app._on_view_change(None)
        self.assertIn("<b>0</b> mover(s) charted", self.app.headline.value)

    def test_the_export_follows_the_filters_on_main(self):
        # What is copied out is what is on screen. An export that silently
        # expands a 1-row filtered view back to the whole run is how a
        # three-bond answer gets pasted into Excel as twenty rows.
        self._load()
        everything = len(self.app._export_frames()["increases"])
        self.assertGreater(everything, 1)
        self.app.filters["Currency"].value = ("USD",)
        self.app._on_view_change(None)
        narrowed = self.app._export_frames()["increases"]
        self.assertLess(len(narrowed), everything)
        self.assertEqual(len(narrowed), len(self.app._visible["increases"]))
        # The copy keeps the repeated header row of the unfiltered table.
        self.assertEqual(
            list(self.app.export_frame("increases").columns),
            list(narrowed.columns),
        )

    def test_the_export_panel_is_redrawn_when_the_filter_keeps_rows_on_both_sides(self):
        # The cache used to key on the loaded frames, which a filter never
        # replaces, so a narrowing that still left both sides non-empty showed
        # the old rows in Export while Main showed the new ones.
        self._load()
        self.app._refresh_export_tables()
        before = self.app.export_box.children[0].value
        # USD keeps one increase (A) and one decrease (C): neither side empties,
        # so the old cache key would have been unchanged.
        self.app.filters["Currency"].value = ("USD",)
        self.app._on_view_change(None)
        self.assertEqual(len(self.app._visible["increases"]), 1)
        self.assertEqual(len(self.app._visible["decreases"]), 1)
        after = self.app.export_box.children[0].value
        self.assertNotEqual(before, after)
        # The panel lists the filtered rows, not the two loaded ones.
        self.assertEqual(after.count("<tr"), len(self.app._visible["increases"]) + 2)

    def test_a_filter_that_empties_one_side_still_redraws_the_export(self):
        self._load()
        self.app._refresh_export_tables()
        before = self.app.export_box.children[0].value
        # No decrease row is rated IG, so the decreases table empties.
        self.app.filters["Rating"].value = ("IG",)
        self.app._on_view_change(None)
        self.assertEqual(len(self.app._visible["decreases"]), 0)
        after = self.app.export_box.children[0].value
        self.assertNotEqual(before, after)
        # The tab states the empty table instead of showing the previous run's.
        self.app.export_view.value = "decreases"
        self.app._show_export_view()
        shown = self.app.export_box.children[0].value
        self.assertIn("No rows", shown)

    def test_a_filter_that_empties_one_side_still_redraws_the_export(self):
        self._load()
        self.app._refresh_export_tables()
        before = self.app.export_box.children[0].value
        self.app.filters["Rating"].value = ("BB",)
        self.app._on_view_change(None)
        after = self.app.export_box.children[0].value
        self.assertNotEqual(before, after)
        # The decreases side had no BB row, so the tab must state that rather
        # than showing the previous run's decreases table.
        self.app.export_view.value = "decreases"
        self.app._show_export_view()
        shown = self.app.export_box.children[0].value
        self.assertIn("No rows", shown)

    def _panel_text(self, panel):
        """All HTML text inside a panel, including width-locked chart slots."""
        def walk(node):
            if isinstance(node, _Box):
                return "".join(walk(child) for child in node.children)
            return str(getattr(node, "value", "") or "")

        return "".join(walk(child) for child in getattr(panel, "children", ()))

    def test_the_spread_path_follows_the_clicked_security_only(self):
        # The chart used to draw every ranked candidate at once. It now draws
        # the one bond the operator clicked, and says so when nothing is
        # selected or when that bond has no series in the returned window.
        self._load()
        rendered = self._panel_text(self.app.path_box)
        self.assertIn("Select a bond to view its spread path", rendered)
        self.assertNotIn("<td>A</td>", rendered)

        self.app._show_security("A")
        rendered = self._panel_text(self.app.path_box)
        self.assertIn("<td>A</td>", rendered)
        self.assertNotIn("<td>C</td>", rendered)

        self.app._show_security("C")
        rendered = self._panel_text(self.app.path_box)
        self.assertIn("<td>C</td>", rendered)
        self.assertNotIn("<td>A</td>", rendered)

        self.app._clear_selection()
        rendered = self._panel_text(self.app.path_box)
        self.assertIn("Select a bond to view its spread path", rendered)

    def test_a_selected_id_with_no_series_says_so(self):
        self._load()
        # B is a ranked mover in this payload but has no series row.
        self.app._show_security("B")
        rendered = self._panel_text(self.app.path_box)
        self.assertIn("No spread series was returned for B", rendered)
        self.assertNotIn("<table", rendered)

    def test_grouping_change_redraws_the_bucket_title(self):
        self._load()
        self.app.dimension_input.value = "Tenor"
        self.app._on_view_change(None)
        self.assertIn("grouped by <b>Tenor</b>", self.app.headline.value)

    def test_the_charts_are_rendered_on_a_kernel_without_plotly(self):
        # This test process has no plotly, so the app must take the table path
        # instead of failing to construct.
        self.assertIsNone(self.app.movers_figure)
        self.assertIsNone(self.app.spread_figure)
        self._load()
        # Both bucket charts fall back to their specification tables, and the
        # full bucket table and the daily table are on screen as well.
        self.assertIn("Country buckets", self.app.bucket_table.value)
        self.assertIn("Daily spread observations", self.app.daily_table.value)
        slot = self.app.bucket_box.children[0]
        self.assertIn("<table", slot.children[0].value)

    def test_clicking_a_security_shows_its_row_and_series(self):
        self._load()
        self.app._show_security("A")
        self.assertIn("Selected security", self.app.detail_title.value)
        self.assertIn("Alpha", self.app.detail_view.value)
        self.assertIn("Spread observations", self.app.detail_view.value)

    def test_clicking_an_unknown_security_says_so_instead_of_raising(self):
        self._load()
        self.app._show_security("NOT-IN-THE-RUN")
        self.assertIn("No loaded row matches", self.app.detail_view.value)

    def test_a_click_payload_without_a_security_is_ignored(self):
        self._load()
        class _Points:
            customdata = None
            ids = None
            x = None
            y = None

        self.app._on_chart_click(None, _Points())
        self.assertIn("Click a bar or a line", self.app.detail_title.value)

    def test_a_selection_hidden_by_a_filter_says_so(self):
        # The row is still shown from the loaded run, but the panel must not
        # imply the security is one of the charted movers.
        self._load()
        self.app.filters["Currency"].value = ("EUR",)
        self.app._on_view_change(None)
        self.app._show_security("A")  # A is USD, so it is filtered out
        self.assertIn("Hidden by the current filters", self.app.detail_title.value)
        self.assertIn("Alpha", self.app.detail_view.value)

    def test_a_visible_selection_carries_no_such_note(self):
        self._load()
        self.app.filters["Currency"].value = ("USD",)
        self.app._on_view_change(None)
        self.app._show_security("A")
        self.assertNotIn("Hidden by the current filters", self.app.detail_title.value)

    def test_a_new_run_clears_the_previous_selection(self):
        self._load()
        self.app._show_security("A")
        self._load()
        self.assertEqual(self.app._selected_id, None)
        self.assertEqual(self.app.detail_view.value, "")

    def test_a_refused_input_clears_the_previous_view(self):
        self._load()
        self.assertTrue(self.app._frames)
        self.app.universe_input.value = ""
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("Refused", self.app.status.value)
        # Fail closed: a refusal must not leave the last run's numbers and
        # charts on screen under a red status bar, where they read as the
        # answer to the input that was just refused.
        self.assertFalse(self.app._frames)
        self.assertFalse(self.app._comparison)
        self.assertIn("No result loaded", self.app.headline.value)
        self.assertEqual(self.app._export_frames(), {})

    def test_a_failed_update_keeps_no_rows_but_keeps_the_receipt(self):
        self._load()
        self.assertTrue(len(self.app._frames.get("increases")))
        failure = FetchResult(
            errors=["Spread series request failed: RuntimeError"],
            field_status={"Name": "OK", "Rating": "FAILED: RuntimeError"},
        )
        with patch.object(app_module, "fetch_movers", return_value=failure):
            self.app._on_update(None)
        # No row of the previous run survives the failed one.
        self.assertTrue(self.app._frames.get("increases").empty)
        self.assertTrue(self.app._frames.get("decreases").empty)
        self.assertIn("Incomplete", self.app.status.value)
        self.assertEqual(self.app._export_frames(), {})
        # The receipt is request metadata: it explains what did arrive, so it
        # survives in the Export Excel tab even though the figures are gone.
        self.assertEqual(self.app._field_status.get("Name"), "OK")
        self.assertTrue(self.app.export_note.value)


class NotebookTests(unittest.TestCase):
    def test_main_notebook_is_import_and_display_only(self):
        import json

        notebook = json.loads(
            (PROJECT_ROOT / "MAIN.ipynb").read_text(encoding="utf-8")
        )
        source = "".join(
            "".join(cell.get("source", [])) for cell in notebook["cells"]
        )
        self.assertIn("Path.cwd()", source)
        self.assertIn("display(app.render())", source)
        self.assertIn("clicks Update", source)
        self.assertNotIn("bq.execute", source)
        self.assertNotIn("load_on_start", source)
        for cell in notebook["cells"]:
            self.assertTrue(cell.get("id"))
            self.assertIsNone(cell.get("execution_count"))
            self.assertEqual(cell.get("outputs"), [])

    def test_package_uses_only_documented_bq_tokens(self):
        # A real whitelist, not a presence check. The descriptor items are
        # reached through ``getattr(bq.data, item_name)``, so the names live in
        # ``config.DESCRIPTOR_FIELDS`` and no ``bq.data.<name>`` literal exists
        # in the source. Checking the literal therefore proves nothing; the
        # field list itself has to be the thing that is compared.
        allowed = {
            "spread",
            "name",
            "rating",
            "crncy",
            "maturity",
            "duration",
            "country_full_name",
            "classification_name",
        }
        self.assertEqual(
            {item for _label, item in config.DESCRIPTOR_FIELDS} - allowed,
            set(),
            "A descriptor was added without the RAG KB/23 review and this "
            "whitelist. Record the decision first, then add it here.",
        )
        package = PROJECT_ROOT / "fi_spread_movement"
        text = "\n".join(
            path.read_text(encoding="utf-8") for path in package.glob("*.py")
        )
        # Any literal bq.data.<name> call site must also be on the whitelist.
        literal_calls = set(re.findall(r"\bbq\.data\.([A-Za-z_]\w*)", text))
        self.assertEqual(
            literal_calls - allowed,
            set(),
            f"Undeclared bq.data item(s) in the package: "
            f"{sorted(literal_calls - allowed)}",
        )
        data_text = (package / "data.py").read_text(encoding="utf-8")
        self.assertNotIn('id()["value"]', text)
        self.assertNotIn("bq.data.id", data_text)
        self.assertNotIn("bq.data.id", (package / "config.py").read_text(encoding="utf-8"))
        self.assertNotIn("fill=", text)
        self.assertIn("bq.univ.members", text)
        self.assertIn("bq.univ.list", text)
        self.assertIn("net_chg()", text)
        self.assertIn(".grouprank(order=order)", text)
        self.assertIn(".groupsort()", text)

    def test_no_restricted_data_family_is_named_anywhere(self):
        # 00-bquant-hard-stops: no ESG/GHG/climate item may be requested,
        # probed, or used for any purpose -- including as a negative test
        # fixture. Scope is the runtime package: the docs have to be able to
        # state the prohibition, so prose is not scanned.
        banned = ("esg", "ghg", "climate", "sustainab", "carbon", "asb_")
        package = PROJECT_ROOT / "fi_spread_movement"
        offenders = []
        for path in sorted(package.glob("*.py")):
            text = path.read_text(encoding="utf-8").lower()
            for token in banned:
                if token in text:
                    offenders.append(f"{path.name}: {token}")
        self.assertEqual(offenders, [], msg=f"Restricted family token(s): {offenders}")


class LayoutParityTests(unittest.TestCase):
    """The control geometry that must match FI Index Change exactly."""

    def setUp(self):
        self.app = make_app()

    def test_the_group_by_control_sits_alone_at_the_far_left(self):
        rows = list(self.app.tabs.children[config.TAB_MAIN].children)
        group_row = next(
            row
            for row in rows
            if isinstance(row, _Box) and self.app.dimension_input in row.children
        )
        self.assertEqual(list(group_row.children), [self.app.dimension_input])
        self.assertEqual(
            self.app.dimension_input.layout.kwargs.get("width"),
            f"{config.GROUP_WIDTH_PX}px",
        )

    def test_five_selection_boxes_in_one_row_with_the_shared_geometry(self):
        rows = list(self.app.tabs.children[config.TAB_MAIN].children)
        filter_row = next(
            row
            for row in rows
            if isinstance(row, _Box) and self.app.filters["Country"] in row.children
        )
        self.assertEqual(
            [widget.description for widget in filter_row.children],
            ["Country", "Sector", "Tenor", "Rating", "Currency"],
        )
        for widget in filter_row.children:
            self.assertEqual(widget.rows, config.FILTER_ROWS)
            self.assertEqual(widget.rows, 10)
            self.assertEqual(
                widget.layout.kwargs.get("width"),
                f"{config.FILTER_WIDTHS[widget.description]}px",
            )
            self.assertEqual(
                widget.style["description_width"], config.FILTER_DESCRIPTION_WIDTH
            )
            self.assertEqual(widget.style["description_width"], "90px")

    def test_the_chart_width_is_the_width_of_the_five_boxes(self):
        widths = [config.FILTER_WIDTHS[label] for label, _column in config.FILTER_COLUMNS]
        self.assertEqual(config.CHART_WIDTH_PX, sum(widths) + config.FILTER_GAP_PX * 4)
        self.assertEqual(config.CHART_WIDTH_PX, 1292)
        self.assertEqual(config.CHART_WIDTH, "1292px")

    def test_no_descriptor_or_series_table_sits_in_the_page_body(self):
        # The receipt is request metadata. It must not come back as a table at
        # the top of the layout; only a FAILED field line is allowed.
        rows = list(self.app.tabs.children[config.TAB_MAIN].children)
        text = "".join(
            str(getattr(child, "value", ""))
            for row in rows
            for child in (row.children if isinstance(row, _Box) else [row])
        )
        self.assertNotIn("Descriptor and series status", text)
        self.assertNotIn("row(s)", text)


class ComparisonPanelTests(unittest.TestCase):
    """AIM vs Index: two typed fields, two labelled books, one comparison panel."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.universe_source.value = "AIM vs Index"
        self.app._on_source_change(None)
        # Both fields are required by this source, so both are typed here; the
        # individual tests override one of them where the refusal is the point.
        self.app.index_input.value = "LEGATRUU Index"
        self.app.aim_input.value = "ABC123"

    def _load(self, result=None):
        with patch.object(
            app_module, "fetch_comparison", return_value=result or _comparison_result()
        ):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def test_both_fields_are_required_before_any_request(self):
        self.app.index_input.value = "LEGATRUU Index"
        self.app.aim_input.value = ""
        with patch.object(
            app_module, "fetch_comparison", side_effect=AssertionError("no fetch")
        ):
            self.app._on_update(None)
        self.assertIn("Refused", self.app.status.value)
        self.assertIn("AIM account is empty", self.app.status.value)

    def test_the_run_passes_both_values_and_names_both_books(self):
        self.app.index_input.value = "LEGATRUU Index"
        self.app.aim_input.value = "abc123"
        seen = {}

        def fake_compare(spread, start, end, index=None, aim=None):
            seen["index"] = index
            seen["aim"] = aim
            return _comparison_result()

        with patch.object(app_module, "fetch_comparison", side_effect=fake_compare):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertEqual(seen["index"], "LEGATRUU Index")
        self.assertEqual(seen["aim"], "ABC123")
        self.assertIn("AIM vs Index", self.app.status.value)
        self.assertIn("LEGATRUU Index vs ABC123", self.app.status.value)
        self.assertIn("ranked separately", self.app.detail.value)

    def test_the_ranked_rows_keep_their_book(self):
        self._load()
        self.assertIn("Universe", self.app._frames["increases"].columns)
        self.assertEqual(
            sorted(set(self.app._frames["increases"]["Universe"])), ["AIM", "Index"]
        )

    def test_a_single_run_draws_one_book_in_the_bucket_charts(self):
        self.app.universe_source.value = "Index"
        self.app.index_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        # There is no separate comparison panel any more: both bucket charts are
        # drawn inside ``bucket_box``, and a one-book run draws only that book.
        self.assertIn("Country buckets", self.app.bucket_table.value)
        self.assertNotIn("Universe", self.app.bucket_table.value)
        spec_text = self.app.bucket_box.children[0].children[0].value
        self.assertNotIn("AIM", spec_text)

    def test_the_comparison_draws_both_books_in_the_two_bucket_charts(self):
        self._load()
        # Two charts, then the full bucket table, all inside one box.
        self.assertEqual(len(self.app.bucket_box.children), 3)
        movers = self.app.bucket_box.children[0].children[0].value
        spread = self.app.bucket_box.children[1].children[0].value
        for text in (movers, spread):
            self.assertIn("AIM increases", text)
            self.assertIn("Index decreases", text)
        table = self.app.bucket_table.value
        self.assertIn("AIM", table)
        self.assertIn("Index", table)
        # The retired aggregate ``Top bucket`` column is gone: the table is the
        # full bucket list, one AIM row then one Index row per bucket.
        self.assertNotIn("Top bucket", table)
        # The headings name the loaded spread type, so two screenshots taken on
        # a different spread type cannot be confused afterwards.
        self.assertIn("Increase OAS", table)
        self.assertIn("Decrease OAS", table)
        self.assertNotIn("Increase Spread", table)

    def test_the_chart_above_the_table_carries_both_books(self):
        self._load()
        spec = charts.comparison_spec(
            ["US"],
            {"AIM": [1], "Index": [2]},
            {"AIM": [3], "Index": [0]},
            ("AIM", "Index"),
            "Country",
            6,
        )
        self.assertEqual(spec["books"], ["AIM", "Index"])
        self.assertEqual(
            [row["label"] for row in spec["rows"]], ["US \u00b7 AIM", "US \u00b7 Index"]
        )
        # Increase is positive, decrease is negative, and both halves share the
        # same absolute limit so neither side is scaled on its own.
        self.assertEqual(spec["traces"][0]["values"], [1, None])
        self.assertEqual(spec["traces"][1]["values"], [-3, None])
        self.assertEqual(spec["traces"][2]["values"], [None, 2])
        self.assertEqual(spec["limit"], 3)

    def test_the_headline_names_both_books(self):
        self._load()
        self.assertIn("AIM vs Index", self.app.headline.value)

    def test_the_two_bucket_charts_are_titled_with_the_group_by_and_both_books(self):
        self._load()
        movers = self.app.bucket_box.children[0].children[0].value
        spread = self.app.bucket_box.children[1].children[0].value
        self.assertIn("Movers by Country", movers)
        self.assertIn("AIM vs Index", movers)
        self.assertIn("Spread Change by Country", spread)
        self.assertIn("AIM vs Index", spread)
        self.assertIn("OAS", spread)

    def test_the_bucket_chart_titles_follow_the_group_by(self):
        self._load()
        self.app.dimension_input.value = "Sector"
        self.app._render_view()
        movers = self.app.bucket_box.children[0].children[0].value
        spread = self.app.bucket_box.children[1].children[0].value
        self.assertIn("Movers by Sector", movers)
        self.assertIn("Spread Change by Sector", spread)
        self.assertNotIn("Movers by Country", movers)

    def test_the_two_top_ten_charts_name_the_book_not_the_direction(self):
        self._load()
        spec = charts.change_spec(
            self.app._frames["increases"], "Increase", "OAS"
        )
        labels = [row["label"] for row in spec["rows"]]
        # AIM above Index, and the label says which book each bar belongs to.
        self.assertTrue(labels[0].startswith("AIM \u00b7 "), msg=labels)
        self.assertTrue(labels[-1].startswith("Index \u00b7 "), msg=labels)
        colours = dict(zip([row["book"] for row in spec["rows"]], spec["colors"]))
        self.assertEqual(colours["AIM"], config.CHART_BOOK_COLORS["AIM"])
        self.assertEqual(colours["Index"], config.CHART_BOOK_COLORS["Index"])
        # Two books, two colours: the colour must not be the direction colour,
        # which is identical on both sides of a two-book run.
        self.assertNotEqual(colours["AIM"], colours["Index"])
        self.assertIn("Top 10 increases: OAS change", spec["title"])


class BondSourceTests(unittest.TestCase):
    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.universe_source.value = "Bond"
        self.app._on_source_change(None)

    def test_the_bond_ticker_is_sent_as_the_universe(self):
        self.app.bond_input.value = "US91282CLW91 Govt"
        seen = {}

        def fake_fetch(spread, start, end, universe, source=None):
            seen["universe"] = universe
            seen["source"] = source
            return _fetch_result()

        with patch.object(app_module, "fetch_movers", side_effect=fake_fetch):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertEqual(seen["universe"], "US91282CLW91 Govt")
        self.assertEqual(seen["source"], "bond")
        self.assertIn("bond US91282CLW91 Govt", self.app.status.value)

    def test_the_detail_explains_the_explicit_list_universe(self):
        self.app.bond_input.value = "XS123 Corp"
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertIn("bq.univ.list", self.app.detail.value)
        self.assertIn("one typed bond", self.app.detail.value)

    def test_a_bond_run_hides_the_bucket_and_change_panels(self):
        self.app.bond_input.value = "XS123 Corp"
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        # Everything that is a bucket or a ranking is removed for this source.
        self.assertEqual(self.app.bucket_box.layout.display, "none")
        self.assertEqual(self.app.change_box.layout.display, "none")

    def test_a_bond_run_selects_that_bond_for_the_path_chart(self):
        self.app.bond_input.value = "XS123 Corp"
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        # The only security of the run is the selected one, so the path chart
        # and the daily table are filled without a click.
        self.assertEqual(self.app._selected_id, "XS123 Corp")
        self.assertNotIn("Select a bond", self.app.path_box.children[0].children[0].value)

    def test_a_list_separator_is_refused_before_the_request(self):
        self.app.bond_input.value = "XS1 Corp, XS2 Corp"
        with patch.object(app_module, "fetch_movers", side_effect=AssertionError("no fetch")):
            self.app._on_update(None)
        self.assertIn("not a list", self.app.status.value)


class ExportTabTests(unittest.TestCase):
    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"

    def _load(self):
        with patch.object(app_module, "fetch_movers", return_value=_fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def test_the_export_tab_starts_with_no_run_message(self):
        self.assertIn("No run loaded", self.app.export_box.children[0].value)

    def test_every_export_table_repeats_its_header_as_the_first_row(self):
        self._load()
        for key in ("increases", "decreases"):
            self.app.export_view.value = key
            self.app._show_export_view()
            table = self.app.export_box.children[0].value
            frame = self.app.export_frame(key)
            header = [str(column) for column in frame.columns]
            for name in header:
                self.assertIn(f"<td>{name}</td>", table)

    def test_the_two_ranked_tables_and_the_request_log_are_offered(self):
        self._load()
        # The validation table was retired from the UI on 2026-11-01, so it is
        # no longer an export choice either.
        self.assertNotIn("validation", self.app.export_view.options)
        for key in ("increases", "decreases", "requests"):
            self.app.export_view.value = key
            self.app._show_export_view()
            self.assertNotIn("No rows for this table", self.app.export_box.children[0].value)

    def test_the_request_receipt_lives_in_the_export_tab(self):
        self._load()
        self.assertIn("Request detail", self.app.export_note.value)
        self.assertIn("returned 2 row(s)", self.app.export_note.value)


class BucketPickTests(unittest.TestCase):
    """A click on a bucket row narrows the two Top 10 charts and their tables.

    The pick is a local view over rows already in memory. It must follow the
    rows it was made on, so a new grouping, a new filter, or a refused run has
    to drop it instead of leaving the charts scoped to a bucket that is gone.
    """

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", return_value=_view_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def _paint(self, countries):
        """Give the loaded rows real Country values, then redraw."""
        for side in ("increases", "decreases"):
            frame = self.app._frames[side].copy()
            frame["Country"] = [
                countries[index % len(countries)] for index in range(len(frame))
            ]
            self.app._frames[side] = frame
        self.app._refresh_filter_options()
        self.app._render_view()

    def _charted(self):
        match = re.search(r"<b>(\d+)</b> mover", self.app.headline.value)
        self.assertIsNotNone(match, msg=self.app.headline.value)
        return int(match.group(1))

    def test_a_bucket_click_narrows_the_two_top_ten_tables(self):
        self._paint(["Germany", "France"])
        total = self._charted()
        germany = int(
            sum(
                self.app._frames[side]["Country"].eq("Germany").sum()
                for side in ("increases", "decreases")
            )
        )
        self.assertGreater(germany, 0)
        self.assertLess(germany, total)

        self.app._on_bucket_pick("Germany")

        self.assertEqual(self.app._selected_bucket, "Germany")
        self.assertEqual(self._charted(), germany)
        self.assertIn("Germany", self.app.headline.value)

    def test_a_grid_click_resolves_by_position_and_by_label(self):
        # A click arrives as the dataset row; a build that reports the index
        # label instead must still pick the right row rather than nothing.
        labels = ["Germany", "France"]
        self.assertEqual(app_module._pick_row_key(labels, 0), "Germany")
        self.assertEqual(app_module._pick_row_key(labels, 1), "France")
        self.assertEqual(app_module._pick_row_key(labels, "France"), "France")
        # Anything unresolvable picks nothing: never the wrong bucket.
        self.assertEqual(app_module._pick_row_key(labels, 9), "")
        self.assertEqual(app_module._pick_row_key(labels, "Japan"), "")
        self.assertEqual(app_module._pick_row_key(labels, None), "")

    def test_clicking_the_same_bucket_again_clears_it(self):
        self._paint(["Germany", "France"])
        total = self._charted()
        self.app._on_bucket_pick("Germany")
        self.app._on_bucket_pick("Germany")
        self.assertIsNone(self.app._selected_bucket)
        self.assertEqual(self._charted(), total)

    def test_changing_group_by_drops_a_bucket_that_no_longer_exists(self):
        self._paint(["Germany", "France"])
        self.app.dimension_input.value = "Country"
        self.app._on_bucket_pick("Germany")

        self.app.dimension_input.value = "Sector"
        self.app._render_view()

        self.assertIsNone(self.app._selected_bucket)
        self.assertGreater(self._charted(), 0)

    def test_a_filter_that_removes_the_bucket_drops_the_pick(self):
        self._paint(["Germany", "France"])
        self.app.dimension_input.value = "Country"
        self.app._on_bucket_pick("Germany")

        # Narrow the rows to France only: Germany is no longer a bucket.
        self.app._frames["increases"] = self.app._frames["increases"].loc[
            lambda frame: ~frame["Country"].eq("Germany")
        ]
        self.app._frames["decreases"] = self.app._frames["decreases"].loc[
            lambda frame: ~frame["Country"].eq("Germany")
        ]
        self.app._render_view()

        self.assertIsNone(self.app._selected_bucket)

    def test_a_refused_run_drops_the_pick(self):
        self._paint(["Germany", "France"])
        self.app.dimension_input.value = "Country"
        self.app._on_bucket_pick("Germany")

        self.app._reset_view()

        self.assertIsNone(self.app._selected_bucket)

    def test_a_blank_bucket_stays_clickable(self):
        frame = self.app._frames["increases"].copy()
        frame["Sector"] = None
        self.app._frames["increases"] = frame
        self.app.dimension_input.value = "Sector"
        self.app._render_view()

        self.app._on_bucket_pick("(blank)")

        self.assertEqual(self.app._selected_bucket, "(blank)")
        self.assertEqual(self._charted(), len(frame))

    def test_the_bucket_table_draws_its_bucket_names(self):
        # The grid used to drop the column named by ``key_column``, which is the
        # right thing only when the key duplicates a displayed column. The bucket
        # table's key is `Bucket` — the country name itself — so the grid showed
        # counts and sums with no label column, and the rows could not be told
        # apart or clicked with any confidence. The names must be in the rendered
        # block, whatever the widget layer does with columns.
        self._paint(["Germany", "France"])
        blocks = self._bucket_blocks()
        self.assertEqual(len(blocks), 1)
        frame = blocks[0]["frame"]
        self.assertIn("Bucket", frame.columns)
        self.assertEqual(
            sorted(frame["Bucket"].astype(str)), ["France", "Germany"]
        )

    def test_the_grid_receives_the_bucket_column_and_fitted_widths(self):
        self._paint(["Germany", "France"])
        seen = []

        class _Grid:
            def __init__(self, dataframe, **kwargs):
                seen.append((list(dataframe.columns), kwargs))

            def on_cell_click(self, handler):
                pass

        fake = type(
            "ipd",
            (),
            {"DataGrid": _Grid, "TextRenderer": object},
        )
        with patch.object(app_module, "_grid_available", return_value=True):
            with patch.dict(sys.modules, {"ipydatagrid": fake}):
                self.app._render_view()
        bucket_grids = [
            (columns, kwargs)
            for columns, kwargs in seen
            if "Bucket" in columns
        ]
        self.assertTrue(bucket_grids, msg=f"no bucket grid among {len(seen)} grid(s)")
        columns, kwargs = bucket_grids[0]
        widths = kwargs.get("column_widths")
        self.assertIsInstance(widths, dict)
        self.assertIn("Bucket", widths or {})
        # A label column is wider than the default narrow cell, and the estimate
        # never collapses to zero.
        self.assertGreaterEqual(widths["Bucket"], 70)
        # Every displayed column has a width, so no column keeps the default and
        # gets clipped while its neighbours are fitted.
        self.assertEqual(set(widths), set(columns))

    def test_the_chart_spec_and_its_fallback_both_carry_the_bucket_names(self):
        # The charts and the table are read together, and a chart whose bars are
        # unlabelled cannot be matched to a table row. The names must reach the
        # spec (which the Plotly renderer draws as tick labels) and the HTML
        # fallback (which a kernel without Plotly shows instead).
        self._paint(["Germany", "France"])
        captured = {}
        original = app_module.charts.comparison_spec

        def _capture(*args, **kwargs):
            spec = original(*args, **kwargs)
            captured.setdefault("specs", []).append(spec)
            return spec

        with patch.object(app_module.charts, "comparison_spec", _capture):
            self.app._render_view()
        specs = captured.get("specs") or []
        self.assertTrue(specs)
        for spec in specs:
            self.assertEqual(
                sorted(set(spec.get("labels") or [])), ["France", "Germany"]
            )
            self.assertEqual(
                sorted(set(spec.get("row_labels") or [])), ["France", "Germany"]
            )
            fallback = app_module.charts.html_fallback(spec)
            self.assertIn("France", fallback)
            self.assertIn("Germany", fallback)

    def test_a_numeric_column_is_measured_at_display_precision(self):
        # A float's full binary form is a 17-digit artefact; sizing a column for
        # it would waste half the table. Four decimals plus a sign is what the
        # reader sees, so that is what the width follows.
        frame = pd.DataFrame(
            {
                "Bucket": ["United States", "Japan"],
                "Net Change": [0.0274567891, -0.5123456789],
            }
        )
        widths = app_module._grid_column_widths(frame)
        self.assertGreater(widths["Bucket"], widths["Net Change"])
        self.assertLessEqual(widths["Net Change"], 130)

    def test_a_missing_width_never_raises(self):
        # A column the estimator cannot read must not cost the table: the grid
        # still receives a width for every column, and a frame it cannot measure
        # yields an empty dictionary so the grid keeps its own defaults.
        self.assertEqual(app_module._grid_column_widths(None), {})
        self.assertEqual(app_module._grid_column_widths(pd.DataFrame()), {})
        widths = app_module._grid_column_widths(
            pd.DataFrame({"Odd": [object(), object()]})
        )
        self.assertIn("Odd", widths)

    def test_the_bucket_panel_passes_a_book_label_so_traces_exist(self):
        # A chart with no traces draws nothing at all. `comparison_spec` builds
        # one trace per book, so an empty `books` tuple produced an empty card
        # while the table below it — built from the same frames — carried every
        # number. That is the reported "charts blank, tables fine".
        self._paint(["Germany", "France"])
        captured = {}
        original = app_module.charts.comparison_spec

        def _capture(*args, **kwargs):
            spec = original(*args, **kwargs)
            captured.setdefault("specs", []).append(spec)
            return spec

        with patch.object(app_module.charts, "comparison_spec", _capture):
            self.app._render_view()
        specs = captured.get("specs") or []
        self.assertTrue(specs)
        for spec in specs:
            self.assertTrue(spec.get("traces"), msg="a bucket chart had no traces")
            self.assertTrue(spec.get("books"))
            # Every trace must carry at least one non-None value, or the bar has
            # nothing to draw even though the trace exists.
            for trace in spec["traces"]:
                self.assertTrue(
                    any(value is not None for value in trace.get("values") or []),
                    msg=f"trace {trace.get('name')!r} had no drawable value",
                )

    def test_a_rerender_does_not_reparent_the_bucket_figures(self):
        # Assigning a displayed FigureWidget into a freshly built container
        # re-parents it. On Desktop the front end then shows an empty card while
        # the figure object holds the data, which is why the tables survived and
        # the charts did not. The slot objects must be stable across renders.
        self._paint(["Germany", "France"])
        self.app._render_view()
        slots_before = list(self.app.bucket_box.children)
        figures_before = [app_module._slot_child(slot) for slot in slots_before[:2]]
        self.app._render_view()
        slots_after = list(self.app.bucket_box.children)
        self.assertEqual(
            [id(slot) for slot in slots_before],
            [id(slot) for slot in slots_after],
        )
        self.assertEqual(
            [id(child) for child in figures_before],
            [id(app_module._slot_child(slot)) for slot in slots_after[:2]],
        )

    def _bucket_blocks(self):
        captured = {}
        original = self.app.bucket_table.render
        self.app.bucket_table.render = lambda blocks=None, **kwargs: captured.setdefault(
            "blocks", blocks
        )
        try:
            self.app._render_view()
        finally:
            self.app.bucket_table.render = original
        return captured.get("blocks") or []


class DisplayTopTests(unittest.TestCase):
    """Each ranked panel draws the number of rows its own Display Top box asks.

    The box is a view control: it slices frames already in memory, per book, and
    never builds a request. A refused value leaves the panel on its last applied
    count instead of silently clamping to something the operator did not type.
    """

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", return_value=_view_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def _rows(self, side):
        frame = self.app._frames[side]
        drawn = self.app._display_top_rows(frame, side)
        return 0 if not isinstance(drawn, pd.DataFrame) else len(drawn)

    def test_the_box_defaults_to_top_n_and_both_panels_follow_it(self):
        # A new run restores both boxes, so a count sized for the previous run
        # cannot narrow a fresh one without the operator seeing it change.
        self.app.display_top_inputs["increases"].value = 2
        self.app._on_display_top("increases")
        self.assertEqual(self.app._display_top["increases"], 2)
        with patch.object(app_module, "fetch_movers", return_value=_view_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.assertEqual(
            self.app.display_top_inputs["increases"].value, config.DEFAULT_DISPLAY_TOP
        )
        self.assertEqual(config.DEFAULT_DISPLAY_TOP, config.TOP_N)
        total = sum(self._rows(side) for side in ("increases", "decreases"))
        self.assertEqual(total, len(self.app._frames["increases"]) + len(self.app._frames["decreases"]))

    def test_each_panel_draws_its_own_count(self):
        self.app.display_top_inputs["increases"].value = 1
        self.app._on_display_top("increases")
        self.assertEqual(self._rows("increases"), 1)
        # The decrease panel keeps its own count: two boxes, two panels.
        self.assertEqual(self._rows("decreases"), len(self.app._frames["decreases"]))
        self.assertIn("Top 1 increases", self.app.increase_table.value)
        self.assertIn("Top 10 decreases", self.app.decrease_table.value)

    def test_zero_and_a_non_number_are_refused_not_clamped(self):
        for bad in (0, -3, "", "abc"):
            self.app.display_top_inputs["increases"].value = bad
            self.app._on_display_top("increases")
            self.assertEqual(self.app._display_top["increases"], config.DEFAULT_DISPLAY_TOP)
            self.assertIn("must be a whole number", self.app.display_top_notes["increases"].value)
        # A valid value clears the refusal note instead of leaving it behind.
        self.app.display_top_inputs["increases"].value = 4
        self.app._on_display_top("increases")
        self.assertEqual(self.app._display_top["increases"], 4)
        self.assertNotIn("must be a whole number", self.app.display_top_notes["increases"].value)
        # This fixture holds two increase rows, so a short panel is explained
        # rather than left silently blank.
        self.assertIn("only 2 row(s) available", self.app.display_top_notes["increases"].value)

    def test_asking_for_more_than_the_run_fetched_is_explained(self):
        # The ranking request is capped at TOP_N, so a larger box value cannot
        # invent rows. The panel draws what exists and says why.
        self.app.display_top_inputs["increases"].value = config.TOP_N + 5
        self.app._on_display_top("increases")
        self.assertEqual(
            self._rows("increases"), len(self.app._frames["increases"])
        )
        note = self.app.display_top_notes["increases"].value
        self.assertIn("fetched at most", note)
        self.assertIn("Update", note)

    def test_refresh_never_marks_the_run_stale_or_calls_the_fetch(self):
        # A Display Top refresh is local: the fetched frames must be untouched
        # and no request may be built.
        before = {side: self.app._frames[side].copy() for side in ("increases", "decreases")}
        with patch.object(app_module, "fetch_movers") as fetch:
            self.app.display_top_inputs["increases"].value = 2
            self.app._on_display_top("increases")
        self.assertFalse(fetch.called)
        for side, frame in before.items():
            pd.testing.assert_frame_equal(self.app._frames[side], frame)

    def test_each_refresh_button_is_wired_to_its_own_panel(self):
        # Desktop has no page script and no `data-field`: the only thing that
        # makes a Refresh act is `Button.on_click`. Fire the registered handler
        # itself, so a missing or swapped binding fails here instead of on the
        # Desktop run this project cannot do from this machine.
        for side in ("increases", "decreases"):
            button = self.app.display_top_buttons[side]
            self.assertTrue(
                getattr(button, "_handlers", []),
                msg=f"the {side} Refresh button has no on_click handler",
            )
        with patch.object(app_module, "fetch_movers") as fetch:
            self.app.display_top_inputs["increases"].value = 2
            for handler in self.app.display_top_buttons["increases"]._handlers:
                handler(self.app.display_top_buttons["increases"])
        self.assertFalse(fetch.called)
        self.assertEqual(self.app._display_top["increases"], 2)
        self.assertEqual(self.app._display_top["decreases"], config.DEFAULT_DISPLAY_TOP)
        self.assertEqual(self._rows("increases"), 2)
        # The box keeps the applied number: a Desktop Refresh must not look like
        # a reset, which is what a click routed to Update did in the preview.
        self.assertEqual(self.app.display_top_inputs["increases"].value, 2)

    def test_a_comparison_counts_each_book_separately(self):
        # "Display Top 3" in AIM vs Index means three AIM rows AND three Index
        # rows. One head(3) on the stacked frame would drop Index entirely.
        frame = pd.DataFrame(
            [
                {"ID": f"AIM{index}", "Universe": "AIM", "Change": 10.0 - index}
                for index in range(6)
            ]
            + [
                {"ID": f"IDX{index}", "Universe": "Index", "Change": 9.0 - index}
                for index in range(6)
            ]
        )
        self.app._display_top["increases"] = 3
        drawn = self.app._display_top_rows(frame, "increases")
        self.assertEqual(len(drawn), 6)
        self.assertEqual(drawn.groupby("Universe").size().to_dict(), {"AIM": 3, "Index": 3})


class LabelFilterTests(unittest.TestCase):
    """The Rating / Sector boxes must not split one bond across two options."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"
        with patch.object(app_module, "fetch_movers", return_value=_view_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def _column(self, label):
        return dict(config.FILTER_COLUMNS)[label]

    def _paint(self, label, values):
        column = self._column(label)
        frame = self.app._frames["increases"].copy()
        frame[column] = values[: len(frame)]
        self.app._frames["increases"] = frame
        self.app._refresh_filter_options()
        self.app._render_view()

    def _options(self, label):
        return [
            value
            for value in self.app.filters[label].options
            if value != config.ALL_FILTER_LABEL
        ]

    def test_an_invisible_space_does_not_create_a_second_rating_option(self):
        self._paint("Rating", ["IG", "IG\u00a0"])
        self.assertEqual([v for v in self._options("Rating") if v.casefold() == "ig"], ["IG"])

    def test_a_case_variant_does_not_create_a_second_option(self):
        self._paint("Rating", ["IG", "ig"])
        self.assertEqual([v for v in self._options("Rating") if v.casefold() == "ig"], ["IG"])

    def test_picking_a_rating_keeps_every_row_that_carries_it(self):
        self._paint("Rating", ["IG", "IG\u00a0"])
        self.app.filters["Rating"].value = ("IG",)
        self.app._render_view()
        self.assertEqual(len(self.app._visible["increases"]), 2)

    def test_a_blank_sector_is_one_option_and_keeps_its_rows(self):
        self._paint("Sector", [None, None])
        self.assertIn("(blank)", self._options("Sector"))
        self.app.filters["Sector"].value = ("(blank)",)
        self.app._render_view()
        self.assertEqual(len(self.app._visible["increases"]), 2)


class DurationColumnsTests(unittest.TestCase):
    """The three extra duration measures ride in one request, and are display only."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"

    def _load(self, result):
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def _result_with_durations(self):
        result = _fetch_result()
        result.descriptors = result.descriptors.assign(
            **{"Modified Duration": [4.25, 2.75], "Effective Duration": [4.10, 2.60], "OASD": [3.90, 2.40]}
        )
        return result

    def test_the_three_measures_reach_the_ranked_table(self):
        self._load(self._result_with_durations())
        columns = self.app._frames["increases"].columns.tolist()
        for label in ("Modified Duration", "Effective Duration", "OASD"):
            self.assertIn(label, columns)
        row = self.app._frames["increases"].iloc[0]
        self.assertEqual(row["Modified Duration"], 4.25)

    def test_a_missing_measure_stays_out_instead_of_being_invented(self):
        result = _fetch_result()  # no duration family at all
        self._load(result)
        columns = self.app._frames["increases"].columns.tolist()
        self.assertNotIn("Modified Duration", columns)
        # The table still renders; the column is simply absent, never zero.
        self.assertIn("Change", columns)

    def test_the_ranking_and_filters_never_consume_a_duration(self):
        self._load(self._result_with_durations())
        # A duration column must not become a filter option or a bucket label.
        filter_columns = {column for _label, column in config.FILTER_COLUMNS}
        for label in ("Modified Duration", "Effective Duration", "OASD"):
            self.assertNotIn(label, filter_columns)
            self.assertNotIn(label, config.DIMENSIONS.values())
            self.assertNotIn(label, [column for column, _item in config.DESCRIPTOR_FIELDS])


class IncompleteStatusTests(unittest.TestCase):
    """A run where every descriptor failed must not report a green Updated."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"

    def _load(self, result):
        with patch.object(app_module, "fetch_movers", return_value=result):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def test_failed_fields_degrade_the_status_word(self):
        result = _fetch_result()
        result.field_status = {
            label: "FAILED: RuntimeError: synthetic"
            for label, _item in config.DESCRIPTOR_FIELDS
        }
        self._load(result)
        self.assertEqual(self.app._loaded_status[0], "Incomplete")
        self.assertIn("field(s) failed", self.app._loaded_status[1])
        # The word and the reason both reach the status bar, and the counts
        # still render because the ranked rows did arrive.
        self.assertIn("Incomplete", self.app.status.value)
        self.assertIn("field(s) failed", self.app.status.value)
        self.assertIn("mover(s) charted", self.app.headline.value)

    def test_a_clean_run_still_says_updated(self):
        self._load(_fetch_result())
        self.assertEqual(self.app._loaded_status[0], "Updated")


class FailClosedDetailTests(unittest.TestCase):
    """A refusal must not leave the last run's selected bond on screen."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"

    def test_a_refusal_clears_the_detail_panel_and_the_filter_picks(self):
        with patch.object(app_module, "fetch_movers", return_value=_view_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)
        self.app._selected_id = "A"
        self.app.detail_view.value = "<p>20.0</p>"
        self.app.filters["Rating"].value = ("IG",)

        self.app._refuse("Index is empty.")

        self.assertEqual(self.app.detail_view.value, "")
        self.assertIn("Selected security", self.app.detail_title.value)
        self.assertNotIn("20.0", self.app.detail_view.value)
        for label, _column in config.FILTER_COLUMNS:
            self.assertEqual(
                tuple(self.app.filters[label].value), (config.ALL_FILTER_LABEL,)
            )
            self.assertEqual(
                list(self.app.filters[label].options), [config.ALL_FILTER_LABEL]
            )


class LocalStageFailureTests(unittest.TestCase):
    """A failure after the data arrived must say so, and must not cost the run."""

    def setUp(self):
        displayed.clear()
        self.app = make_app()
        self.app.index_input.value = "LEGATRUU Index"

    def _load(self, result=None):
        with patch.object(app_module, "fetch_movers", return_value=result or _fetch_result()):
            with patch.object(app_module, "display", side_effect=displayed.append):
                self.app._on_update(None)

    def test_a_reshape_failure_names_its_stage(self):
        # The old banner printed a bare "KeyError" next to ten completed
        # requests, which reads exactly like a refused query. The stage says the
        # data arrived and the local step failed.
        with patch.object(
            app_module, "prepare_ranked_movers", side_effect=KeyError("synthetic")
        ):
            self._load()
        self.assertIn("Preparing the ranked tables failed", self.app.detail.value)
        self.assertIn("KeyError", self.app.detail.value)
        # The receipts survive: the operator can still see the ten requests.
        self.assertIn("Requests executed before the error", self.app.detail.value)

    def test_a_drawing_failure_names_the_drawing_stage(self):
        with patch.object(
            app_module.FISpreadMovementApp, "_render", side_effect=ValueError("synthetic")
        ):
            self._load()
        self.assertIn("Drawing the figures failed", self.app.detail.value)
        self.assertIn("ValueError", self.app.detail.value)

    def _log_text(self) -> str:
        return "".join(str(getattr(item, "value", "")) for item in displayed)

    def test_a_failed_change_check_does_not_blank_the_tables(self):
        # The arithmetic check is a diagnostic; nothing on screen is drawn from
        # it, so its failure is a note and the ranked rows stay visible.
        with patch.object(
            app_module, "validate_candidate_changes", side_effect=RuntimeError("synthetic")
        ):
            self._load()
        self.assertIn("Updated", self.app.status.value)
        self.assertIn("mover(s) charted", self.app.headline.value)
        self.assertIn(
            "change-arithmetic check could not be completed",
            self.app.detail.value,
        )

    def test_a_failed_label_consistency_check_is_only_a_log_line(self):
        with patch.object(
            app_module, "label_conflicts", side_effect=RuntimeError("synthetic")
        ):
            self._load()
        self.assertIn("Updated", self.app.status.value)
        self.assertIn("Label consistency check skipped", self._log_text())

    def test_a_grid_that_refuses_the_frame_falls_back_to_the_html_table(self):
        # The clickable grid is third-party; a build that raises on the frame
        # must cost the click, not the Update. The rows are still there.
        fake = types.SimpleNamespace(
            DataGrid=lambda *args, **kwargs: (_ for _ in ()).throw(KeyError("synthetic"))
        )
        with patch.object(app_module, "_grid_available", return_value=True):
            with patch.dict(sys.modules, {"ipydatagrid": fake}):
                self._load()
        self.assertIn("Updated", self.app.status.value)
        rendered = "".join(
            str(getattr(child, "value", "")) for child in self.app.bucket_table.box.children
        )
        self.assertIn("could not be built", rendered)
        self.assertIn("Country buckets", rendered)


if __name__ == "__main__":
    unittest.main()
