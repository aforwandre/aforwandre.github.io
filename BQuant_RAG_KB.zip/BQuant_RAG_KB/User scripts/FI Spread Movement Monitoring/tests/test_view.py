"""Synthetic checks for the derived dimensions, filters, and chart specs.

No BQL is executed. Every frame here is built in the test, which is the only
way this workspace may exercise the ranking and view paths locally.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PACKAGE = PROJECT_ROOT / "fi_spread_movement"
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fi_spread_movement import charts, config, engine  # noqa: E402


AS_OF = pd.Timestamp("2026-10-30")


def _rgb(value: str) -> tuple[int, int, int]:
    """``#rrggbb`` to its three channels; the colour tests read the hue."""
    text = str(value).lstrip("#")
    return int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16)


def _ranked() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "ID": "A",
                "Name": "Alpha",
                "Change": 2.0,
                "Currency": "USD",
                "Rating": "AA",
                "Maturity": "2031-01-01",
            },
            {
                "ID": "B",
                "Name": "Beta",
                "Change": -1.0,
                "Currency": "EUR",
                "Rating": "BB",
                "Maturity": "",
            },
            {
                "ID": "C",
                "Name": "Charlie",
                "Change": 3.0,
                "Currency": "EUR",
                "Rating": "NR",
                "Maturity": "2099-01-01",
            },
        ]
    )


class RatingBucketTests(unittest.TestCase):
    def test_agency_letters_map_to_ig_and_hy(self):
        self.assertEqual(engine.rating_bucket("AA"), "IG")
        self.assertEqual(engine.rating_bucket("BBB-"), "IG")
        self.assertEqual(engine.rating_bucket("BB+"), "HY")
        self.assertEqual(engine.rating_bucket("C"), "HY")

    def test_moody_letters_map_without_inventing_a_scale(self):
        self.assertEqual(engine.rating_bucket("Aaa"), "IG")
        self.assertEqual(engine.rating_bucket("Baa3"), "IG")
        self.assertEqual(engine.rating_bucket("Ba1"), "HY")

    def test_not_rated_tokens_and_blanks_are_missing(self):
        for token in (None, "", "  ", "NR", "WR", "n/a", "nan"):
            self.assertEqual(engine.rating_bucket(token), "NR/Missing", msg=token)

    def test_a_numeric_rating_is_unmapped_not_converted(self):
        # The numeric scale is not established for this app, so a number is
        # labelled rather than silently turned into a letter grade.
        self.assertEqual(engine.rating_bucket("5"), "Numeric (unmapped)")

    def test_an_unknown_letter_is_other(self):
        self.assertEqual(engine.rating_bucket("XYZ"), "Other")

    def test_a_provisional_suffix_does_not_change_the_bucket(self):
        self.assertEqual(engine.rating_bucket("AA(P)"), "IG")


class TenorBucketTests(unittest.TestCase):
    def test_years_come_from_the_maturity_date_and_the_as_of_date(self):
        years = engine._tenor_years(pd.Series(["2031-10-30"]), AS_OF)
        self.assertAlmostEqual(float(years.iloc[0]), 5.0, places=2)

    def test_a_past_or_blank_maturity_is_missing_not_negative(self):
        years = engine._tenor_years(pd.Series(["2020-01-01", ""]), AS_OF)
        self.assertTrue(years.isna().all())

    def test_buckets_have_no_nan_label(self):
        years = pd.Series([0.5, 2.0, 4.0, 6.0, 8.0, 15.0, 30.0, None])
        buckets = engine.tenor_bucket(years)
        self.assertEqual(
            list(buckets),
            ["0-1Y", "1-3Y", "3-5Y", "5-7Y", "7-10Y", "10-20Y", "20Y+", "Missing"],
        )

    def test_a_boundary_value_falls_in_the_upper_bucket(self):
        buckets = engine.tenor_bucket(pd.Series([5.0]))
        self.assertEqual(buckets.iloc[0], "5-7Y")


class EnrichTests(unittest.TestCase):
    def test_missing_descriptors_become_explicit_labels(self):
        frame = pd.DataFrame([{"ID": "A", "Change": 1.0}])
        enriched = engine.enrich_ranked(frame, AS_OF)
        self.assertEqual(enriched["Currency"].iloc[0], "(unavailable)")
        # An absent Rating column is a failed request, not an unrated bond: the
        # bucket says so instead of stamping every row NR/Missing.
        self.assertEqual(enriched["Rating Bucket"].iloc[0], "(unavailable)")
        self.assertEqual(enriched["Tenor Bucket"].iloc[0], "Missing")

    def test_an_unavailable_rating_does_not_read_as_unrated(self):
        frame = pd.DataFrame(
            [{"ID": "A", "Change": 1.0, "Rating": "(unavailable)"}]
        )
        enriched = engine.enrich_ranked(frame, AS_OF)
        self.assertEqual(enriched["Rating Bucket"].iloc[0], "(unavailable)")
        # A genuine blank is still NR/Missing: the two must stay distinguishable.
        blank = pd.DataFrame([{"ID": "A", "Change": 1.0, "Rating": "  "}])
        self.assertEqual(
            engine.enrich_ranked(blank, AS_OF)["Rating Bucket"].iloc[0], "NR/Missing"
        )

    def test_a_blank_currency_is_blank_not_dropped(self):
        frame = pd.DataFrame([{"ID": "A", "Change": 1.0, "Currency": "  "}])
        enriched = engine.enrich_ranked(frame, AS_OF)
        self.assertEqual(enriched["Currency"].iloc[0], "(blank)")

    def test_an_empty_side_returns_empty_not_an_error(self):
        enriched = engine.enrich_ranked(pd.DataFrame(), AS_OF)
        self.assertTrue(enriched.empty)
        self.assertIn("Rating Bucket", enriched.columns)

    def test_side_label_is_added(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF, side="Increase")
        self.assertTrue((enriched["Side"] == "Increase").all())


class FilterTests(unittest.TestCase):
    def test_choices_are_distinct_and_sorted_without_the_all_marker(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        choices = engine.filter_choices([enriched])
        self.assertEqual(choices["Currency"], ["EUR", "USD"])
        self.assertEqual(choices["Rating Bucket"], ["HY", "IG", "NR/Missing"])
        self.assertNotIn(config.ALL_FILTER_LABEL, choices["Currency"])

    def test_an_empty_filter_set_keeps_every_row(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        kept = engine.apply_dimension_filters(enriched, {})
        self.assertEqual(len(kept), 3)

    def test_a_filter_narrows_and_can_empty_the_frame(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        kept = engine.apply_dimension_filters(enriched, {"Currency": {"EUR"}})
        self.assertEqual(sorted(kept["ID"]), ["B", "C"])
        empties = engine.apply_dimension_filters(enriched, {"Currency": {"JPY"}})
        self.assertTrue(empties.empty)

    def test_a_filter_on_an_absent_column_does_not_empty_the_frame(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        # Country and Sector are carried dimensions now, so a genuinely absent
        # column is used here: the frame must be kept, not silently emptied.
        kept = engine.apply_dimension_filters(enriched, {"Security Type": {"Bond"}})
        self.assertEqual(len(kept), 3)

    def test_country_and_sector_are_always_carried(self):
        # A failed descriptor request cannot remove the dimension: the column
        # stays and every row says the value is unavailable, so a pick can
        # never fall back to another field's values.
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        for column in ("Country", "Sector"):
            self.assertIn(column, enriched.columns)
            self.assertTrue((enriched[column] == "(unavailable)").all())

    def test_country_and_sector_values_are_trimmed_and_never_blank(self):
        frame = _ranked()
        frame["Country"] = ["  United States ", "", None]
        frame["Sector"] = ["Sovereign", "  Agency", None]
        enriched = engine.enrich_ranked(frame, AS_OF)
        self.assertEqual(list(enriched["Country"]), ["United States", "(blank)", "(blank)"])
        self.assertEqual(list(enriched["Sector"]), ["Sovereign", "Agency", "(blank)"])

    def test_a_descriptor_row_that_never_came_back_is_unavailable_not_blank(self):
        # The descriptor response covers only A. B and C were never described,
        # which is not the same as Bloomberg returning an empty value for them:
        # (blank) means "returned empty", (unavailable) means "not returned".
        frame = pd.DataFrame(
            [
                {"ID": "A", "Change": 3.0},
                {"ID": "B", "Change": 2.0},
                {"ID": "C", "Change": 1.0},
            ]
        )
        descriptors = pd.DataFrame(
            [{"ID": "A", "Country": "", "Sector": "Sovereign", "Duration": 4.0}]
        )
        movers = engine.prepare_ranked_movers(
            frame,
            None,
            descriptors,
            top_n=10,
            descriptor_columns=("Country", "Sector", "Duration"),
        )
        enriched = engine.enrich_ranked(movers.increases, AS_OF)

        self.assertEqual(list(enriched["ID"]), ["A", "B", "C"])
        self.assertEqual(enriched["Country"].iloc[0], "(blank)")
        self.assertEqual(list(enriched["Country"].iloc[1:]), ["(unavailable)"] * 2)
        self.assertEqual(list(enriched["Sector"].iloc[1:]), ["(unavailable)"] * 2)
        # A numeric descriptor stays missing instead of becoming a label, so
        # its tenor bucket is still Missing rather than a string bucket.
        self.assertTrue(enriched["Duration"].iloc[1:].isna().all())
        self.assertTrue(any("did not cover" in note for note in movers.notes))

    def test_two_filters_are_combined(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        kept = engine.apply_dimension_filters(
            enriched, {"Currency": {"EUR"}, "Rating Bucket": {"HY"}}
        )
        self.assertEqual(list(kept["ID"]), ["B"])


class SummaryTests(unittest.TestCase):
    def test_counts_and_net_change_are_grouped_by_the_dimension(self):
        enriched = engine.enrich_ranked(_ranked(), AS_OF)
        summary = engine.summarize_by_dimension(enriched, "Rating Bucket")
        row = summary.loc[summary["Rating Bucket"] == "IG"].iloc[0]
        self.assertEqual(int(row["Increases"]), 1)
        self.assertEqual(int(row["Decreases"]), 0)
        self.assertAlmostEqual(float(row["Net Change"]), 2.0)

    def test_widening_and_tightening_do_not_cancel_into_a_count(self):
        frame = pd.DataFrame(
            [
                {"ID": "A", "Change": 5.0, "Rating Bucket": "IG"},
                {"ID": "B", "Change": -5.0, "Rating Bucket": "IG"},
            ]
        )
        summary = engine.summarize_by_dimension(frame, "Rating Bucket")
        row = summary.iloc[0]
        self.assertEqual(int(row["Increases"]), 1)
        self.assertEqual(int(row["Decreases"]), 1)
        self.assertAlmostEqual(float(row["Net Change"]), 0.0)
        self.assertAlmostEqual(float(row["Abs Change"]), 10.0)

    def test_a_missing_dimension_returns_the_empty_shape(self):
        summary = engine.summarize_by_dimension(_ranked(), "Country")
        self.assertTrue(summary.empty)
        self.assertEqual(
            list(summary.columns),
            [
                "Country",
                "Increases",
                "Decreases",
                "Total",
                "Increase Spread",
                "Decrease Spread",
                "Net Change",
                "Abs Change",
            ],
        )

    def test_a_long_tail_collapses_into_one_others_row(self):
        frame = pd.DataFrame(
            [
                {"ID": str(position), "Change": 1.0, "Tenor Bucket": f"B{position}"}
                for position in range(5)
            ]
        )
        summary = engine.summarize_by_dimension(frame, "Tenor Bucket")
        labels, increases, decreases = engine.bucket_chart_rows(
            summary, "Tenor Bucket", limit=2
        )
        self.assertEqual(len(labels), 3)
        self.assertEqual(labels[-1], "Others (3)")
        self.assertEqual(sum(increases), 5)

    def test_an_empty_summary_charts_nothing(self):
        self.assertEqual(
            engine.bucket_chart_rows(pd.DataFrame(), "Tenor Bucket"), ([], [], [])
        )


class SpreadPathTests(unittest.TestCase):
    def test_the_pivot_keeps_real_dates_and_leaves_gaps(self):
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-10-01", "Spread": 1.0},
                {"ID": "A", "DATE": "2026-10-03", "Spread": 1.5},
                {"ID": "B", "DATE": "2026-10-03", "Spread": 2.0},
            ]
        )
        wide = engine.spread_paths(series)
        self.assertEqual(len(wide), 2)
        self.assertTrue(pd.isna(wide.loc[pd.Timestamp("2026-10-01"), "B"]))

    def test_a_requested_subset_limits_the_traces(self):
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-10-01", "Spread": 1.0},
                {"ID": "B", "DATE": "2026-10-01", "Spread": 2.0},
            ]
        )
        wide = engine.spread_paths(series, ["B"])
        self.assertEqual(list(wide.columns), ["B"])

    def test_duplicate_id_date_keeps_the_last_observation(self):
        series = pd.DataFrame(
            [
                {"ID": "A", "DATE": "2026-10-01", "Spread": 1.0},
                {"ID": "A", "DATE": "2026-10-01", "Spread": 9.0},
            ]
        )
        wide = engine.spread_paths(series)
        self.assertAlmostEqual(float(wide.iloc[0, 0]), 9.0)

    def test_a_bad_frame_returns_empty_instead_of_raising(self):
        self.assertTrue(engine.spread_paths(pd.DataFrame([{"ID": "A"}])).empty)
        self.assertTrue(engine.spread_paths(None).empty)


class ChartSpecTests(unittest.TestCase):
    def test_the_bucket_spec_carries_the_counts_it_was_given(self):
        spec = charts.bucket_spec(["IG", "HY"], [3, 0], [0, 2], "Rating", 5)
        self.assertEqual(spec["labels"], ["IG", "HY"])
        self.assertEqual(spec["increases"], [3, 0])
        self.assertEqual(spec["decreases"], [0, 2])
        self.assertFalse(spec["empty"])

    def test_an_empty_bucket_spec_is_marked_empty(self):
        self.assertTrue(charts.bucket_spec([], [], [], "Rating", 0)["empty"])

    def test_the_change_spec_orders_by_magnitude_and_colours_the_sign(self):
        frame = engine.enrich_ranked(_ranked(), AS_OF)
        spec = charts.change_spec(frame, "Increase", "OAS")
        self.assertFalse(spec["empty"])
        self.assertEqual([row["ID"] for row in spec["rows"]], ["C", "A", "B"])
        self.assertEqual(spec["colors"][0], config.CHART_INCREASE_COLOR)
        self.assertEqual(spec["colors"][-1], config.CHART_DECREASE_COLOR)

    def test_the_change_spec_falls_back_to_the_id_when_the_name_is_blank(self):
        frame = pd.DataFrame([{"ID": "A", "Change": 1.0, "Name": "  "}])
        spec = charts.change_spec(frame, "Increase", "OAS")
        self.assertEqual(spec["rows"][0]["label"], "A")

    def test_a_missing_frame_yields_an_empty_change_spec(self):
        self.assertTrue(charts.change_spec(None, "Increase", "OAS")["empty"])

    def test_the_path_spec_uses_the_returned_dates(self):
        wide = engine.spread_paths(
            pd.DataFrame(
                [
                    {"ID": "A", "DATE": "2026-10-01", "Spread": 1.0},
                    {"ID": "A", "DATE": "2026-10-02", "Spread": 1.4},
                ]
            )
        )
        spec = charts.path_spec(wide, "OAS", "2026-10-01", "2026-10-02")
        self.assertEqual(spec["traces"][0]["dates"], ["2026-10-01", "2026-10-02"])
        self.assertEqual(spec["traces"][0]["values"], [1.0, 1.4])
        self.assertIn("2026-10-01", spec["title"])

    def test_an_empty_path_spec_is_marked_empty(self):
        self.assertTrue(charts.path_spec(None, "OAS")["empty"])

    def test_the_table_fallback_shows_every_bucket(self):
        html = charts.html_fallback(
            charts.bucket_spec(["IG", "HY"], [2, 1], [0, 3], "Rating", 6)
        )
        self.assertIn("IG", html)
        self.assertIn("HY", html)
        self.assertIn("<table", html)

    def test_the_table_fallback_states_an_empty_spec(self):
        html = charts.html_fallback(charts.bucket_spec([], [], [], "Rating", 0))
        self.assertIn("No rows to chart", html)

    def test_plotly_availability_is_a_boolean_not_an_import_error(self):
        self.assertIsInstance(charts.plotly_available(), bool)


class ConfigContractTests(unittest.TestCase):
    def test_every_filter_column_exists_on_the_dimension_map(self):
        # A filter must name a column the summary can also group by, or the
        # widget and the chart would disagree about the vocabulary.
        for _label, column in config.FILTER_COLUMNS:
            self.assertIn(column, config.DIMENSIONS.values())

    def test_no_filter_requests_a_field_outside_the_confirmed_descriptors(self):
        # A filter may name a confirmed descriptor, or a bucket derived from
        # one. It may not name a data item this app never requests.
        derived = {
            "Rating Bucket": "Rating",
            "Tenor Bucket": "Maturity",
        }
        confirmed = {label for label, _item in config.DESCRIPTOR_FIELDS}
        for _label, column in config.FILTER_COLUMNS:
            source = derived.get(column, column)
            self.assertIn(
                source,
                confirmed,
                msg=f"{column} would need a data item outside the confirmed descriptors",
            )

    def test_the_default_dimension_is_offered(self):
        self.assertIn(config.DEFAULT_DIMENSION, config.DIMENSIONS)


class LayoutParityConfigTests(unittest.TestCase):
    """The constants that make this screen match FI Index Change."""

    def test_the_five_dimension_boxes_keep_that_apps_order_and_widths(self):
        self.assertEqual(
            [label for label, _column in config.FILTER_COLUMNS],
            ["Country", "Sector", "Tenor", "Rating", "Currency"],
        )
        self.assertEqual(
            config.FILTER_WIDTHS,
            {"Country": 300, "Sector": 300, "Tenor": 220, "Rating": 220, "Currency": 220},
        )
        self.assertEqual(config.FILTER_DESCRIPTION_WIDTH, "90px")
        self.assertEqual(config.FILTER_ROWS, 10)
        self.assertEqual(config.FILTER_GAP_PX, 8)

    def test_the_chart_width_is_the_width_of_the_five_boxes(self):
        self.assertEqual(config.CHART_WIDTH_PX, 1292)
        self.assertEqual(config.CHART_WIDTH, "1292px")

    def test_the_chart_palette_and_size_match_that_app(self):
        self.assertEqual(config.CHART_FONT_COLOR, "#f5f5f5")
        self.assertEqual(config.CHART_MUTED_COLOR, "#b8b8b8")
        self.assertEqual(config.CHART_GRID_COLOR, "#3a3a3a")
        self.assertEqual(config.CHART_ZERO_COLOR, "#9a9a9a")
        self.assertEqual(config.CHART_MARGIN_LEFT_PX, 140)
        self.assertEqual(config.CHART_HEIGHT_PX, 360)
        self.assertEqual(config.CHART_DETAIL_HEIGHT_PX, 300)
        self.assertEqual(config.CHART_DETAIL_MARGIN_TOP_PX, 40)
        self.assertEqual(config.CHART_DETAIL_MARGIN_BOTTOM_PX, 48)

    def test_the_path_chart_takes_the_shorter_lower_card(self):
        # A declared-but-unused height constant is how the path chart silently
        # stayed at 360 px while FI Index Change drew its lower chart at 300.
        source = (PACKAGE / "charts.py").read_text(encoding="utf-8")
        self.assertIn("def _detail_layout(", source)
        self.assertIn("height=config.CHART_DETAIL_HEIGHT_PX", source)
        self.assertIn("t=config.CHART_DETAIL_MARGIN_TOP_PX", source)
        self.assertIn("b=config.CHART_DETAIL_MARGIN_BOTTOM_PX", source)
        builder = source.split("def path_figure(", 1)[1].split("\ndef ", 1)[0]
        self.assertIn("_detail_layout(figure)", builder)
        # Only the path chart is the lower card; the bar charts stay at 360.
        for builder_name in ("def bucket_figure(", "def change_figure(", "def comparison_figure("):
            body = source.split(builder_name, 1)[1].split("\ndef ", 1)[0]
            self.assertNotIn("_detail_layout(figure)", body)

    def test_the_two_tabs_are_main_and_export_excel(self):
        self.assertEqual(config.TAB_TITLES, ("Main", "Export Excel"))
        self.assertEqual(config.TAB_MAIN, 0)
        self.assertEqual(config.TAB_EXPORT, 1)

    def test_the_four_universe_sources_are_offered(self):
        self.assertEqual(
            list(config.UNIVERSE_SOURCES),
            ["Index", "AIM account", "AIM vs Index", "Bond"],
        )
        self.assertEqual(config.UNIVERSE_SOURCES["AIM vs Index"], config.COMPARISON_SOURCE)
        self.assertEqual(config.UNIVERSE_SOURCES["Bond"], "bond")

    def test_the_comparison_colours_are_two_pairs(self):
        for book in ("Index", "AIM"):
            pair = config.CHART_COMPARE_COLORS[book]
            self.assertEqual(len(pair), 2)
            self.assertNotEqual(pair[0], pair[1])

    def test_one_book_draws_the_direction_colours(self):
        # Blue for an increase, orange for a decrease. A one-book run used to be
        # drawn in that book's comparison pair, which was two shades of one hue,
        # so the two halves of the zero line could not be told apart.
        spec = charts.comparison_spec(
            ["US"], {"Index": [2]}, {"Index": [1]}, ("Index",), "Country", 0
        )
        colours = [trace["color"] for trace in spec["traces"]]
        self.assertEqual(colours, list(config.CHART_DIRECTION_COLORS))

    def test_a_comparison_keeps_the_direction_in_the_colour(self):
        # The book is told apart by depth, not by a second hue: every increase
        # stays blue-dominant and every decrease red-dominant, in both books.
        spec = charts.comparison_spec(
            ["US"],
            {"Index": [2], "AIM": [1]},
            {"Index": [1], "AIM": [2]},
            ("AIM", "Index"),
            "Country",
            3,
        )
        for trace in spec["traces"]:
            red, green, blue = _rgb(trace["color"])
            if trace["direction"] == "Increase":
                self.assertGreater(blue, red, trace["name"])
            else:
                self.assertGreater(red, blue, trace["name"])
        # ...and the two books are not the same shade, so depth still names them.
        pairs = {trace["book"]: trace["color"] for trace in spec["traces"]
                 if trace["direction"] == "Increase"}
        self.assertNotEqual(pairs["AIM"], pairs["Index"])

    def test_the_svg_bucket_chart_reads_the_specification_colour(self):
        # The preview renderer used to look the colour up in the book palette
        # again, which is how a one-book page kept the comparison pair. It must
        # draw what the specification published, or the two front ends disagree
        # about what a colour means.
        from preview import svg_charts

        spec = charts.comparison_spec(
            ["US"], {"Index": [2]}, {"Index": [1]}, ("Index",), "Country", 0
        )
        spec["traces"][0]["color"] = "#123456"
        spec["traces"][1]["color"] = "#654321"
        svg = svg_charts.render(spec)
        self.assertIn("#123456", svg)
        self.assertIn("#654321", svg)
        self.assertNotIn(config.CHART_COMPARE_COLORS["Index"][0], svg)


class ComparisonSpecTests(unittest.TestCase):
    def test_one_increase_and_one_decrease_series_per_book(self):
        spec = charts.comparison_spec(
            ["US", "DE"],
            {"Index": [2, 0], "AIM": [0, 1]},
            {"Index": [0, 1], "AIM": [1, 0]},
            ("AIM", "Index"),
            "Country",
            4,
        )
        self.assertEqual(spec["kind"], "comparison")
        # One increase and one decrease trace per book, and the books are in
        # the shared comparison order, AIM first.
        self.assertEqual(
            [trace["name"] for trace in spec["traces"]],
            [
                "AIM increases",
                "AIM decreases",
                "Index increases",
                "Index decreases",
            ],
        )
        # One row per (bucket, book): AIM above Index inside every bucket, and
        # each trace only carries its own rows so the other book draws nothing.
        self.assertEqual(
            spec["row_labels"],
            ["US \u00b7 AIM", "US \u00b7 Index", "DE \u00b7 AIM", "DE \u00b7 Index"],
        )
        self.assertEqual(spec["traces"][0]["values"], [0, None, 1, None])
        self.assertEqual(spec["traces"][1]["values"], [-1, None, 0, None])
        self.assertEqual(spec["traces"][2]["values"], [None, 2, None, 0])
        self.assertFalse(spec["empty"])

    def test_increases_are_positive_and_decreases_negative(self):
        spec = charts.comparison_spec(
            ["US"], {"AIM": [3]}, {"AIM": [5]}, ("AIM",), "Country", 8
        )
        self.assertEqual(spec["traces"][0]["values"], [3])
        self.assertEqual(spec["traces"][1]["values"], [-5])
        # One symmetric limit, so neither side can be rescaled on its own.
        self.assertEqual(spec["limit"], 5)
        # A one-book chart does not repeat the book's name on every bar: the
        # screen already says which universe was loaded. The book prefix is
        # what tells the two rows for one bucket apart, so it is only added when
        # there really are two.
        self.assertEqual(spec["rows"][0]["label"], "US")

    def test_an_empty_spec_is_still_a_spec(self):
        spec = charts.comparison_spec([], {}, {}, (), "Country", 0)
        self.assertTrue(spec["empty"])
        self.assertIn("No rows to chart", charts.html_fallback(spec))

    def test_the_fallback_table_renders_every_book(self):
        spec = charts.comparison_spec(
            ["US"], {"Index": [2], "AIM": [1]}, {"Index": [0], "AIM": [4]}, ("AIM", "Index"), "Country", 3
        )
        html = charts.html_fallback(spec)
        self.assertIn("AIM increases", html)
        self.assertIn("Index increases", html)
        self.assertIn("<td>US</td>", html)
        self.assertIn("<td>4</td>", html)

    def test_the_spread_chart_publishes_one_symmetric_limit(self):
        spec = charts.comparison_spec(
            ["US", "DE"],
            {"AIM": [0.25, 0.0]},
            {"AIM": [1.5, 0.0]},
            ("AIM",),
            "Country",
            4,
            value_format="spread",
        )
        values = [value for trace in spec["traces"] for value in trace["values"] if value is not None]
        self.assertEqual(spec["limit"], max(abs(value) for value in values))
        self.assertTrue(any(value < 0 for value in values))
        self.assertTrue(any(value > 0 for value in values))

    def test_a_spread_bar_keeps_its_decimals(self):
        spec = charts.comparison_spec(
            ["US"], {"AIM": [0.0125]}, {"AIM": [0.034]}, ("AIM",), "Country", 2,
            value_format="spread",
        )
        # The rows keep the exact values: a spread bar must not be rounded to an
        # integer the way a mover count can be.
        self.assertEqual(spec["rows"][0]["increase"], 0.0125)
        self.assertEqual(spec["rows"][0]["decrease"], 0.034)
        self.assertEqual(spec["value_format"], "spread")
        self.assertEqual(spec["traces"][0]["values"], [0.0125])
        self.assertEqual(spec["traces"][1]["values"], [-0.034])

    def test_the_book_order_survives_a_missing_book(self):
        # One book returning nothing must not silently become a one-book chart:
        # both books stay in the spec, so the empty side is visible as empty.
        spec = charts.comparison_spec(
            ["US"], {"AIM": []}, {"AIM": []}, ("AIM", "Index"), "Country", 0
        )
        self.assertEqual(spec["books"], ["AIM", "Index"])
        self.assertEqual(len(spec["rows"]), 2)


if __name__ == "__main__":
    unittest.main()
