"""Local tests for the Plotly update path. No BQL, no Desktop, no browser.

The rule these tests hold is narrow and was expensive to learn: a
``FigureWidget`` that has already been displayed inside an ``ipywidgets``
container must be **mutated**, never rebuilt, when its data changes.
``figure.data = [...]`` renders correctly in a notebook but left the bucket
charts and the bond path card blank on Desktop while the tables around them --
ordinary widget output -- kept every number.

There is no Plotly in this environment, so the figures below are minimal
stand-ins that record what an update actually does to them: whether the trace
objects survived, and what values they ended up holding.
"""

from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fi_spread_movement import charts  # noqa: E402


class _Trace:
    """One trace that records assignment like a real Plotly trace does."""

    def __init__(self, **kwargs):
        # `data` on a figure is a tuple of trace objects that Plotly mutates in
        # place; a trace therefore has writable attributes, not a dict.
        self.name = kwargs.get("name", "")
        self.x = kwargs.get("x", [])
        self.y = kwargs.get("y", [])
        self.mode = kwargs.get("mode", "")
        self.text = kwargs.get("text", [])
        self.customdata = kwargs.get("customdata", [])
        self.orientation = kwargs.get("orientation", "")
        self.hovertemplate = kwargs.get("hovertemplate", "")
        self.marker = types.SimpleNamespace(color=kwargs.get("color"))

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<Trace {self.name!r} x={self.x!r}>"


class _Figure:
    """The smallest figure that can answer 'was `data` reassigned?'."""

    def __init__(self, data=()):
        self.data = tuple(data)
        self._assignments = 0
        self.layout = types.SimpleNamespace(
            title=types.SimpleNamespace(text=""),
            xaxis=types.SimpleNamespace(title=types.SimpleNamespace(text=""), range=None),
            yaxis=types.SimpleNamespace(
                title=types.SimpleNamespace(text=""), autorange=None
            ),
            annotations=[],
        )

    def __setattr__(self, name, value):
        if name == "data":
            object.__setattr__(self, "_assignments", getattr(self, "_assignments", 0) + 1)
        object.__setattr__(self, name, value)

    def add_traces(self, traces):
        self.data = tuple(self.data) + tuple(traces)

    def update_layout(self, **kwargs):
        """Apply the flat keys the theme helper and the layout setter use.

        Only the names this app actually writes are supported; a stand-in that
        silently accepted anything would pass a call that real Plotly rejects.
        `template` is recorded because the theme fix depends on clearing it.
        """
        for key, value in kwargs.items():
            if key in ("paper_bgcolor", "plot_bgcolor", "template", "barmode"):
                setattr(self.layout, key, value)
            elif key == "font":
                self.layout.font = value
            elif key == "title":
                if isinstance(value, dict):
                    for name, item in value.items():
                        setattr(self.layout.title, name, item)
                else:
                    self.layout.title.text = value
            else:
                raise AttributeError(f"unsupported layout key: {key}")

    def batch_update(self):
        figure = self

        class _Context:
            def __enter__(self):
                return figure

            def __exit__(self, *exc_info):
                return False

        return _Context()


def _go_module(trace_class):
    """A stand-in for ``plotly.graph_objects``."""

    def _bar(**kwargs):
        return trace_class(orientation="h", **kwargs)

    def _scatter(**kwargs):
        return trace_class(**kwargs)

    return types.SimpleNamespace(Bar=_bar, Scatter=_scatter)


class _PlotlyPatched(unittest.TestCase):
    """Installs the fake ``plotly.graph_objects`` for the duration of a test."""

    def setUp(self):
        self._real = sys.modules.get("plotly")
        self.trace_class = _Trace
        plotly = types.ModuleType("plotly")
        graph = types.ModuleType("plotly.graph_objects")
        graph.Bar = lambda **kwargs: _Trace(**{"orientation": "h", **kwargs})
        graph.Scatter = lambda **kwargs: _Trace(**kwargs)
        plotly.graph_objects = graph
        sys.modules["plotly"] = plotly
        sys.modules["plotly.graph_objects"] = graph

    def tearDown(self):
        if self._real is None:
            sys.modules.pop("plotly", None)
            sys.modules.pop("plotly.graph_objects", None)
        else:  # pragma: no cover - only when the real library is installed
            sys.modules["plotly"] = self._real


class ComparisonUpdateTests(_PlotlyPatched):
    """`apply_comparison` mutates the traces it was given."""

    def _spec(self, books=("Index",), value_format="count"):
        traces = []
        for book in books:
            for direction, sign in (("increase", 1), ("decrease", -1)):
                traces.append(
                    {
                        "name": f"{book} {direction}s",
                        "book": book,
                        "direction": direction,
                        "color": "#123456",
                        "values": [sign * 2.0, sign * 1.0],
                    }
                )
        return {
            "traces": traces,
            "row_labels": ["Germany", "France"],
            "labels": ["Germany", "France"],
            "books": list(books),
            "limit": 2.0,
            "value_format": value_format,
            "title": "Movers by Country",
            "x_title": "Number of ranked movers",
        }

    def test_the_traces_exist_and_carry_the_bucket_labels(self):
        figure = _Figure([_Trace(), _Trace()])
        charts.apply_comparison(figure, self._spec())
        self.assertEqual(len(figure.data), 2)
        for trace in figure.data:
            self.assertEqual(list(trace.y), ["Germany", "France"])
            self.assertTrue(trace.x)

    def test_a_displayed_figure_is_not_rebuilt(self):
        # One `data` assignment is the initial `_Figure(data=...)`; the update
        # must add nothing further. This is the assertion that fails on the old
        # `figure.data = series` form.
        figure = _Figure([_Trace(), _Trace()])
        before = tuple(id(trace) for trace in figure.data)
        assignments_before = figure._assignments
        charts.apply_comparison(figure, self._spec())
        self.assertEqual(figure._assignments, assignments_before)
        self.assertEqual(tuple(id(trace) for trace in figure.data), before)

    def test_a_second_book_adds_traces_without_replacing_the_existing_ones(self):
        # Adding a trace is legitimate — the second book's traces did not exist
        # yet. What must not happen is the wholesale `figure.data = [...]`
        # replacement, so the assertion is about the objects, not about whether
        # `data` was touched at all.
        figure = _Figure([_Trace(), _Trace()])
        before = tuple(id(trace) for trace in figure.data)
        charts.apply_comparison(figure, self._spec(books=("AIM", "Index")))
        self.assertEqual(len(figure.data), 4)
        # The two original trace objects survive; the new two are appended.
        self.assertEqual(tuple(id(trace) for trace in figure.data[:2]), before)

    def test_a_book_that_returns_nothing_leaves_no_stale_bar(self):
        figure = _Figure([_Trace(), _Trace(), _Trace(), _Trace()])
        charts.apply_comparison(figure, self._spec(books=("Index",)))
        # Traces beyond the spec are emptied, not deleted: a leftover bar would
        # draw a book that is not in this run.
        for trace in figure.data[2:]:
            self.assertEqual(list(trace.x), [])
            self.assertEqual(list(trace.y), [])
            self.assertEqual(trace.name, "")

    def test_the_axis_range_follows_the_limit(self):
        figure = _Figure([_Trace(), _Trace()])
        charts.apply_comparison(figure, self._spec())
        low, high = figure.layout.xaxis.range
        self.assertLess(low, 0)
        self.assertAlmostEqual(high, 2.0 * 1.08)


class PathUpdateTests(_PlotlyPatched):
    """`apply_paths` mutates the single path trace in place."""

    def _spec(self, traces=None, note=""):
        return {
            "traces": traces if traces is not None else [],
            "title": "OAS path",
            "x_title": "Date",
            "y_title": "OAS",
            "note": note,
        }

    def test_a_selected_bond_fills_the_line_without_reassigning_data(self):
        figure = _Figure([])
        charts.apply_paths(
            figure,
            self._spec(
                [{"id": "XS123", "dates": ["2026-10-26"], "values": [1.5]}]
            ),
        )
        self.assertEqual(len(figure.data), 1)
        self.assertEqual(figure.data[0].name, "XS123")
        self.assertEqual(list(figure.data[0].y), [1.5])
        self.assertEqual(figure._assignments, 1)  # the constructor's own

    def test_clearing_the_selection_empties_the_line(self):
        figure = _Figure([])
        charts.apply_paths(
            figure,
            self._spec([{"id": "XS123", "dates": ["2026-10-26"], "values": [1.5]}]),
        )
        assignments_before = figure._assignments
        charts.apply_paths(figure, self._spec([], note="Select a bond to view its path."))
        self.assertEqual(figure._assignments, assignments_before)
        self.assertEqual(list(figure.data[0].x), [])
        self.assertEqual(list(figure.data[0].y), [])
        # The state sentence is an annotation, not an empty plot.
        self.assertTrue(figure.layout.annotations)
        self.assertIn("Select a bond", figure.layout.annotations[0]["text"])

    def test_switching_bond_replaces_the_values_not_the_trace(self):
        figure = _Figure([])
        charts.apply_paths(
            figure,
            self._spec([{"id": "A", "dates": ["d1"], "values": [1.0]}]),
        )
        trace_id = id(figure.data[0])
        charts.apply_paths(
            figure,
            self._spec([{"id": "B", "dates": ["d2"], "values": [9.0]}]),
        )
        self.assertEqual(id(figure.data[0]), trace_id)
        self.assertEqual(figure.data[0].name, "B")
        self.assertEqual(list(figure.data[0].y), [9.0])


if __name__ == "__main__":
    unittest.main()
