# FI Spread Movement Monitoring — Verification Report

- **Date:** 2026-10-23 (Asia/Shanghai)
- **Project:** `User scripts/FI Spread Movement Monitoring/`
- **Verified revision:** files as of 2026-10-23 23:44:38 (see Appendix A)
- **Verification type:** read-only design/review workspace audit. **No BQL, BQuant, or Bloomberg request was executed or constructed.** Local checks used synthetic pandas frames and a fake `bql` module only.
- **Authorities used:** `RAG KB/29` (both the pre-23:44 revision and the current revision), `.cursor/rules/00`, `01`, `02`, `03`, `10`, `project-fi-spread-movement-monitoring.mdc` (both revisions), `RAG KB/00-RAG-INDEX.md`, `23`, `02`, `07`, `08`, `12`, `18`, `22`, `28`, plus the sibling `User scripts/` projects.

> **Status update 2026-10-24:** the Copilot draft audited below was superseded by
> a full V1 rewrite after the operator confirmed the 2026-10-23 selections. See
> "Update 2026-10-24 — V1 rewrite" at the end of this report. The draft findings
> below remain as the historical audit trail.

> **Status update 2026-11-01:** four universe sources, two tabs, and the
> `AIM vs Index` candidate-union fix. See "Update 2026-11-01" at the end of this
> report. The 2026-10-23 sections below stay as the historical audit trail; they
> describe a build that no longer exists.

## Verdict

**The version is technically close to a working validation prototype, but it must not be
treated as a verified, signed-off, or production deliverable.**

What passes:

1. **No forbidden data.** No ESG/GHG/climate/sustainable-finance item, no ASKB, no `pip`,
   no new `bqport`, no local BQL execution. The declared "no bps / no percentage"
   labelling is compliant (`RAG KB/29:57-58`).
2. **No invented BQL mnemonics.** Of ~22 API tokens/behaviours in `data.py`, all are
   documented in the local KB or copied from the KB's own official FI recipe
   (`RAG KB/02:385-400`, `12:111-122`, `11:630-636`). Two items are genuinely
   unverified (`bq.data.id()["value"]`, `duration()` semantics), not fabricated.
3. **The requested UI features exist:** OAS/Z/I `Dropdown` and two custom `DatePicker`s
   (`app.py:39-51`), Update-only lifecycle, ranked tables, per-field status display.
   `MAIN.ipynb` displays only; it does not start a request.
4. **Local test suite passes:** `python3 -m unittest discover -s tests -v` → 4 tests OK.
   KB integrity check passes: `python3 "RAG KB/regenerate_kb_bundle.py" --check` →
   `integrity=ok topics=29 rules=11`.

What blocks sign-off (in priority order):

1. **Provenance / governance.** The runtime-authority card `RAG KB/29` (mtime
   23:44:14) and the project rule (23:44:38) were **rewritten inside the same
   23:40–23:44 window as the code** to authorize exactly this live request
   (`LEGATRUU`, OAS/Z/I, custom dates, 6 descriptors). The revisions state
   "The user selected … on 2026-10-23" (`29:68-70`; rule `:9-17`), but the workspace
   has **no dated user-evidence record and no `23` decision record**. The untouched
   navigator still says the opposite: Desktop only after every requested field is
   signed (`00-RAG-INDEX.md:62`), and the router/rules still list only route cards
   25–28 (`00-bquant-hard-stops.mdc:50`, `01:11-16`, `10:3,8-9`). The verification
   therefore treats the new authorization as **pending user confirmation**, not as
   independent evidence.
2. **Unverified semantics.** Units, `net_chg()` endpoint behaviour with `fill` omitted,
   Z-spread parameterization, `duration()` definition, `id()["value"]` accessor, and
   `rating()` letter/number scale are all unresolved locally. The only KB movers
   recipe uses `fill='prev'` (`02:390-391`, `12:76`, `12:116`); the draft deliberately
   omits it (`29:77`). Entitlement and request breadth are explicitly outside card 29's
   authority (`29:9-12`).
3. **Code defects that would distort or hide the first Desktop validation** — app
   exceptions leave stale success screens; ID heuristic can fabricate IDs; excluded
   rows/duplicates are silent; descriptor merge can wipe all metadata; value-column
   detection fails on documented shapes; only `.get`-style responses are supported.
   The tests do not catch any of these (mutation runs still pass 4/4).
4. **Handoff conventions** (unchanged from the earlier audit): no `Upload/` staging,
   `MAIN` lacks the sibling `sys.path` bootstrap and `display(app.render())` contract,
   no README "Files to copy into BQuant" section or account-safety banner, no
   `instruction.md` / `VersionLog.md` / `ToDoList.md` entry.

**Recommended status: `validation implementation, not approved output`.** Confirm the
recorded user selections, create the dated evidence and `23` decision records, reconcile
the KB/router/pipeline, fix the defects below, then run a **narrow** first Desktop
validation (business-day endpoints, short window, measured runtime/rows) before any
production claim.

---

## 1. Authority timeline (why this report scores against two baselines)

| Time (2026-10-23) | File | Change observed |
|---|---|---|
| 23:26:56 | `RAG KB/00-RAG-INDEX.md` | Route row for `29` present; "First-success: … Desktop only after the universe and every requested field are signed"; do-not list includes "guessed universe, spread type, history interval, or units" |
| 23:26 | `RAG KB/29-fi-spread-movement-monitoring.md` (original) | Fail-closed card: "No universe, field, signature, period, entitlement, request breadth, or Desktop response shape is approved"; "Do not construct a BQL Request or call `bq.execute` in the starter files"; "the data adapter returns an explicit approval-required diagnostic and no data" |
| 23:26 | `.cursor/rules/project-fi-spread-movement-monitoring.mdc` (original) | "Do not add `bq.data`, `bq.univ`, `bql.Request`, or `bq.execute` calls until the user reviews the FLDS BQL tab and signs off the decision record" |
| 23:29–23:30 | `MAIN.ipynb`, `README.md` | First-draft shell |
| 23:40:14 | `config.py` | Gate removed; `DEFAULT_INDEX`, `SPREAD_TYPES`, `DESCRIPTOR_FIELDS` added |
| 23:41:19 | `README.md`, `MAIN.ipynb` | Rewritten with live-request claims |
| 23:42:31 | `RAG KB/regenerate_kb_bundle.py` | Builder edited in the same window |
| 23:43:02 | `app.py` | Dropdown + DatePickers + live `fetch_movers` on Update |
| 23:44:07 | `engine.py`, `tests/test_engine.py` | Rewritten around BQL-side ranking / `FakeBQL` |
| 23:44:14 | `RAG KB/29-fi-spread-movement-monitoring.md` | Rewritten to "user-authorized validation request" (`29:66-85`); `authority_for` gains `fi_spread_movement_validation_request`; `not_authority_for` loses `approved_universe` / `spread_item_signature` |
| 23:44:38 | `data.py`, project rule | Live BQL implemented; rule rewritten to match (`rule:9-17`) |
| 23:44:44 | `BQUANT_RAG_KNOWLEDGE_BASE.md`, `RAG_KB_MANIFEST.json`, `CONCEPT_INDEX.*`, `BUNDLE_EXAMPLES.*` | Regenerated |
| 23:45–23:54 | — | This audit (read-only) |

The original card/rule are the versions the first verification round (23:30–23:40)
reviewed; the current versions are the ones this report scores as "pending confirmation".

### KB integrity findings

| # | Severity | Finding | Evidence |
|---|---|---|---|
| I1 | **blocker (process)** | Runtime authority was rewritten in-window to authorize the implementation; no dated user-evidence artifact or `23` record exists. Verification against a self-rewritten authority is circular until the user confirms. | `29:68-70`, `rule:9-17`; `00:44-45` (dated evidence must be user-supplied); `23:51-53,211-235`; no file under `User scripts/` or `VersionLog.md` records the selection |
| I2 | **high** | Navigator not reconciled: route row still requires sign-off before Desktop and forbids "guessed universe, spread type, history interval, or units"; header `local_user_evidence_through: 2026-09-03` stale despite claimed 2026-10-23 evidence. | `00-RAG-INDEX.md:4,44-45,62` vs `29:66-85`; rule 10:47-48 requires the update |
| I3 | **high** | Router/rules still omit card 29: hard-stops front door lists 25/26/27/28; retrieval protocol lists route cards 25–28; maintenance rule says canonical topics are `01`–`28` and globs `2[0-8]`. | `00-bquant-hard-stops.mdc:50`; `01-bquant-retrieval-protocol.mdc:11-16`; `10-rag-maintenance.mdc:3,8-9` |
| I4 | **medium** | Card 29 sits outside the canonical builder range: `topic_sources()` iterates `range(1, 29)` → `01`–`28`; the bundle/manifest do not include card 29's body, while `CONCEPT_INDEX.md` does index its new headings (`1508`, `2205`). `--check` passes because it only compares generated outputs with the builder. | `RAG KB/regenerate_kb_bundle.py` `topic_sources()`; `CONCEPT_INDEX.md:1508,2205`; `RAG_KB_MANIFEST.json` topic list |
| I5 | **high** | No `23` decision record, no `VersionLog.md` entry, no `instruction.md` section, no `ToDoList.md` rows for the fail-closed→live-BQL decision. | mtimes 12:29/13:05/13:15 unchanged; `VersionLog.md:5` ("read it before continuing earlier work"); `23:211-235` |
| I6 | **medium** | Project rule was rewritten to match the code, so there is currently no rule-vs-code drift — but the rule set is internally inconsistent (I2/I3/I4) and the provenance of the change is only the self-declared text. | `rule:9-17` vs `00/01/10` |

---

## 2. Policy / KB compliance matrix

| Claim | Status | Evidence |
|---|---|---|
| UI: OAS/Z/I dropdown + custom start/end dates | **User-requested**; acceptable as UI | user instruction 2026-10-23; recorded `29:68-70` |
| OAS / I spread types | Documented; I-spread is the KB's "Movers" field, OAS is "rich/cheap vs curve" | `02:285` (OAS/ASW/I verified); `12:69-82` |
| Z-spread (`spread_type='Z'`) | Recipe-documented only; absent from both verified lists; some recipes add `pricing_source='BVAL'` | `02:932-940`, `02:1969-1970`, `12:380-382,685-686`; `08:175-177` |
| Universe `LEGATRUU Index` | Identity is evidenced (Global Aggregate tracker recipe / card 28), but approval for **this project** is only the self-rewritten `29:68-70`; needs user confirmation | `02:690-704` (`### Masterpiece Case: Global Aggregate …`, `index_ticker = 'LEGATRUU Index'`); `28:52-57`; `00:62` |
| "not US Treasury" claim | **No supporting local evidence**; reword or remove | repeated `app.py:34-35,58-61,100-104`, `README.md:3-6`, `MAIN.ipynb:9`; no other KB occurrence |
| Live BQL reachable from Update | **Policy conflict under the old card**, authorized only by the new in-window card/rule; no gate, no approval diagnostic | original `29` text (quoted above); current `29:66-85`; `data.py:108-113,129-244`; `app.py:79-89` |
| No-fill `net_chg()` | Allowed by new card (`29:77`) but contradicts the only KB movers recipe (`fill='prev'`) and leaves endpoint semantics undocumented | `07:386-390`; `02:168,390-391`; `12:76,116` |
| `bq.univ.members(index, dates=end)` | Signature documented; as-of semantics and future/weekend dates partly unresolved | `02:200-206`; `12:61,76`; `28:258,271` |
| Descriptor fields `id/name/rating/crncy/maturity/duration` | `name/rating/crncy/maturity` documented core FI items; `rating()` scale unresolved; `duration()` definition undocumented; `id()["value"]` unverified accessor | `08:145,152-156,125-128`; `22:6937,7701,14096,15231,18581`; `18:48-50`; `28:271`; `08:101-111` |
| `23` due diligence for each item | **None exists** | `23:51-53,166-175,180-193,211-235`; `rule 02:7-14,44-46` |
| Request breadth vs Desktop limits | **Unmeasured / at risk**: 8 sequential `bq.execute` per Update; ranking spans full Global Aggregate membership × dated spread; card 28 records LEGATRUU timeout pressure for 16 undated items | `data.py:145-149,164-177,218-241`; `tests:195`; `00-bquant-hard-stops.mdc:43-45`; `28:273-274` |
| Units | Unverified; app correctly avoids bps/% labels | `29:9-12,57-58`; `app.py:58-61` |
| Hard stops (ESG/ASKB/pip/local BQL/new `bqport`) | **Clean** | grep + `bql` import guarded (`data.py:12-17`); tests fake; no network/pip |
| Fail-closed / approval diagnostic | **Removed** by the new design | old `config.FIELD_DECISIONS_SIGNED_OFF` / `FetchResult` gate gone; `config.py:1-20` |

---

## 3. BQL API / field verification summary

Full token-by-token evidence is in the audit annex; result:

- **Documented with exact spelling + shown signature/semantics (~15):** `bql.Service`,
  `bq.univ.members(..., dates=)`, `bq.data.spread(spread_type=)`, `bq.func.range(start,end)`
  including absolute `YYYY-MM-DD` (`07:442-448`), `.net_chg()` (`07:386-390`),
  data-item comparisons, chained universe `.filter`, `.grouprank(order=)`, `.groupsort()`
  (recipe-level), `bql.Request`/`bq.execute`, Arrow `.get(name)`/`item.df()`,
  `bq.univ.list(ids)`, `name`, `crncy`, `maturity`.
- **Recipe-level / partial (~5):** method-form `grouprank`/`groupsort`; `net_chg` without
  `fill`; `spread_type='Z'`; the symmetric top-up/bottom-down composition
  (nearest KB recipe is one-sided LF98TRUU); units.
- **Unverified (2):** `bq.data.id()["value"]` (documented member key is `id()['weights']`;
  `['value']` is documented for `id_isin/id_sedol1/id_cusip`, not `id()` — `08:101-111`),
  and `duration()` semantics (catalog-only `22:7701`; separate explicit codes
  `dur_adj_mid_semi_ann()` / `duration_maturity()` exist at `22:7699,7702`).
- **Zero invented mnemonics.** The ranking pipeline is a near-verbatim copy of the KB's
  official "Top 10 HY spread wideners" recipe (`02:385-400`; `12:111-122`; `11:630-636`),
  generalized with documented primitives. This is the strongest part of the draft.

---

## 4. Code findings (current revision)

| ID | Severity | Finding | Evidence | Impact | Minimal fix |
|---|---|---|---|---|---|
| C1 | **high** | Update handler has no `try/except`; any exception leaves a traceback plus the previous success status/tables. `data.py` also raises before its own `try` blocks for `None`/invalid dates, `start>=end`, and unsupported spread type. | `app.py:70-111`; `data.py:135-141`; repro: success → patched raise → status unchanged, old tables still shown | Stale/misleading validation screen; violates card `29:84-85` | Wrap handler body, render escaped `Error: <type>: <msg>` in status, clear results in `finally`; keep validation inside `fetch_movers` so it returns `FetchResult(errors=…)` |
| C2 | **high** | `_normalize_id_frame` promotes **any** unnamed non-`RangeIndex` to `ID` (Int64Index, DatetimeIndex, numeric MultiIndex) → fabricated IDs; a lowercase `id` column is rejected before the case-insensitive lookup. | `data.py:41-51,52-61`; repro yields IDs `0,1` / dates | Violates `VersionLog.md:21-23`, `rule 03:26`, card `29:56`; corrupts ranking keys | Promote an unnamed index only when `index.dtype == object`; reject numeric/datetime with a diagnostic; search an ID column case-insensitively first |
| C3 | **high** | Silent exclusions and dedup: non-numeric/NaN changes dropped without note; `drop_duplicates("ID", keep="last")` silently changes values; blank/"nan" IDs dropped without count. | `data.py:178-181`; `engine.py:43-49`; repro 5-row → 1-row, `notes=[]` | Violates card `29:59-60` ("excluded with diagnostics", duplicate IDs not silently expanded) | Count each exclusion category, add notes; report duplicates instead of keep-last; filter nan-like IDs case-insensitively |
| C4 | **medium** | Descriptor merge uses `DATE` as an outer-merge key when present and `validate="one_to_one"`; one bad descriptor frame can multiply rows and wipe **all** metadata ("Descriptor response has duplicate IDs; metadata merge skipped"). | `data.py:116-126`, `engine.py:50-63` | Metadata table silently lost for all fields | Merge descriptors on `ID` only; isolate each field frame; set per-field status on failure |
| C5 | **medium** | Value-column detection reserves `DATE` as a key before finding the value and mishandles documented shapes: `rating()` + hidden `NORMALIZED_SCALE`, `maturity` arriving as `DATE`, `id()["value"]` frame whose only column is `ID`. | `data.py:69-105`; `18:48-50`, `08:56`; `28:271` | Individual descriptor FAILED / wrong column | Resolve value column first (case-insensitive, item/output name preferred); allow `DATE` as value for date items; log chosen columns |
| C6 | **medium** | Response extraction only supports `.get(name)`; valid classic/indexable responses are reported as "no item named". | `data.py:69-72`; `07:106-111` vs `18:193` | First Desktop run could fail with a misleading diagnostic | Lookup order `.get` → `response[0]` → iterate by `item.name`; include `type(response).__name__` in errors |
| C7 | **medium** | The app claims "Dates: start to end", but `net_chg()` is defined as the change between the **first and last values in the range**; non-observation endpoints silently shift the effective interval. | `07:386-390`; `app.py:100-107`; card `29:52-54` | Misstated period, non-comparable movers | Add `first()`/`last()` spread values for the ≤10 candidates to the request, verify `Change == End − Start`, display effective observation dates, warn on non-business-day endpoints |
| C8 | **medium** | No date validation: weekend/holiday/future end dates accepted; default window is today−30 → today; no max range or `end <= today` guard. | `app.py:38-46`; `data.py:137-140`; `28:133-136,258,271` | Silent empty/partial results; avoidable timeout | Business-day validation, `end <= today`, configurable max window, explicit endpoint note |
| C9 | **medium** | `start >= end` branch sets status but does not clear previous results. | `app.py:76-78` | Stale tables under an error status | Clear results in that branch (same as the `None` branch) |
| C10 | **medium** | Tests do not exercise real signatures or semantics: `FakeUniverse.filter` ignores the condition, `grouprank(order)` ignores order, `net_chg`/`groupsort` are no-ops, `FakeResponse` always has `.get`, `FakeItem.df()` always ID-column. Mutations (flip decreases condition; delete RangeIndex guard) still pass 4/4. | `tests:54-213`; mutation evidence | Green tests over a wrong request/parser | Recording fakes asserting `(condition, order)` per direction and exact candidate IDs; parser-shape tests; app no-request/error tests |
| C11 | **low** | No button disable/re-entrancy guard; double click issues 16 requests and last-write-wins. | `app.py:70-111` | Duplicate heavy requests | `disabled=True` + `try/finally` |
| C12 | **low** | Hard-coded UI labels/headings/defaults diverge from config (`LEGATRUU` in initial status, "Top 10" with `TOP_N=5`, default `"OAS"`). | `app.py:34,50,110-111` | Stale doctrine if config changes | Derive from `config` |
| C13 | **low** | Dead/unreachable code and edge contracts: `direction_specs` try can never raise; `pd.isna(pd.Timestamp(start))` dead after `strftime`; `isinstance(..., DataFrame)` checks after `.loc`/`reset_index`; `np.int64 top_n` rejected; engine `Change` column collisions. | `data.py:64-65,103-104,137-141,154-162`; `engine.py:25` | Confusing maintenance; latent edge errors | Clean up; accept `numbers.Integral`; suffix/guard collisions |
| C14 | **nit** | `MAIN.ipynb` has a markdown cell, no `sys.path`/`ROOT` bootstrap, `display(app.ui)` instead of sibling `display(app.render())`, invented `language_info.version`, missing nbformat 4.5 cell `id`s. | `MAIN.ipynb:4-24,32-35`; sibling `MAIN.ipynb` files | Handoff inconsistency | Align with EC/ES/FI `MAIN` pattern |
| C15 | **high (operational)** | Request breadth/timeout unmeasured: 2 full-membership dated-spread ranking requests + 6 descriptor requests per Update; no `with_params={'mode':'cached'}` for a broad index pull even though `12:210-221` recommends it for broad index pulls; card 28 records LEGATRUU timeout pressure. | `data.py:145-149,164-241`; `tests:195`; `28:273-274`; `00-bquant-hard-stops.mdc:43-45`; `12:210-221` | First run may hit the 2-minute timeout and show partial/empty tables | Measure a narrow run first; log per-request timing/rows; consider cached mode and/or a single combined ranking request; keep per-field failure isolation |

**Verified good in code:** constructor performs no fetch; Update is the only request path;
no startup BQL; ranking directions and caps are structurally correct; zero-change bonds
excluded; deterministic ordering; descriptor requests bounded to the returned candidate
IDs; HTML escaping in status/tables; per-field failure isolation; source-units labelling;
no zero-fill/interpolation/universe widening; `bql` import guarded so nothing runs locally.

---

## 5. Test evidence and gaps

- `python3 -m unittest discover -s tests -v` → **4 tests, OK, 0.038 s** (system
  Python 3.12.7 / pandas 3.0.5 / numpy 2.5.1; `bql` absent, ImportError path exercised).
- `python3 "RAG KB/regenerate_kb_bundle.py" --check` → `integrity=ok topics=29 rules=11`.
- Mutation evidence (code-reviewer, /tmp copies only): changing the decreases filter to
  `spread_change > 0` and deleting the RangeIndex fake-ID guard both still pass 4/4.
  This means the suite does not pin the request semantics or parser shape.
- Missing coverage groups: ID-index/row-number/Arrow response shapes; direction/order/
  filter assertions; duplicate/non-numeric diagnostics; descriptor merge collisions;
  `maturity`-as-`DATE` / `id()['value']` / `rating`+`NORMALIZED_SCALE` shapes; invalid
  dates and unsupported spread type; no-request-before-Update; app error/clearing;
  notebook JSON/no-request; card-29 constant pinning.

---

## 6. Convention / handoff gaps (unchanged baseline plus new items)

| # | Severity | Gap |
|---|---|---|
| H1 | high | No `Upload/` staging folder or README "Files to copy into BQuant" section (copy order, restart kernel, do-not-copy `tests/`); sibling FI project documents this (`instruction.md:27`, `FI Index Change/Upload/`) |
| H2 | high | `MAIN.ipynb` not aligned with the 4/4 sibling pattern (`sys.path` bootstrap, `display(app.render())`); `app.py` still exposes `ui` + `display()` instead of `render()`/`container` |
| H3 | high | No `VersionLog.md` entry for the 2026-10-23 authorization/rewrite/live-BQL decision; no `instruction.md` section; no `ToDoList.md` rows |
| H4 | medium | README lacks the CRITICAL ACCOUNT-SAFETY STOP banner used by EC/ES; lacks card-29 citation; duplicates doctrine in app/MAIN |
| H5 | medium | `config.py` has no confirmation date or "validation-only, not production approval" marker (FI config convention) |
| H6 | low | `__init__.py` lazy export, tests module docstring, `_build_widgets`/`_bind_events` split, notebook metadata |

---

## 7. Residual unresolved items (must be closed before production)

1. **Units** of OAS/Z/I values and of `Change` — verify against Terminal for at least one
   bond; do not label bps until then.
2. **`net_chg()` endpoints and `fill`** — reproduce first/last-in-range behaviour with
   non-observation start/end dates; decide `fill='prev'` (KB recipe) versus no-fill
   (current card). Document the decision.
3. **Z-spread** — confirm parameters (`pricing_source`?), definition, and coverage on
   multi-currency Global Aggregate members.
4. **OAS as a mover measure** — KB maps OAS to "rich/cheap vs curve" and I-spread to
   "Movers" (`12:75-76`); confirm the user wants OAS included as a mover measure.
5. **`duration()`** — confirm it is the intended duration measure (vs
   `dur_adj_mid_semi_ann()` / `duration_maturity()`).
6. **`id()["value"]`** — replace with the response `ID` key or a documented identifier
   accessor; current accessor is unverified for member/list universes.
7. **`rating()` scale** — letters/numbers/mixed; display-only, no numeric interpretation.
8. **Membership as-of-end semantics** — survivorship; weekend/future end dates; whether
   the cohort should be point-in-time at both endpoints.
9. **Request breadth / timeout / bytes** — measure before widening the date window.
10. **Entitlement** — confirm core-data entitlement for all items on the work account;
    card 29 explicitly is not authority for this.
11. **Response shape** — capture each of the 8 request outputs' `item.df()` columns on
    Desktop (field_status already logs descriptor columns; log ranking columns too).

---

## 8. Proposed first Desktop validation (narrow, after fixes + confirmation)

1. Pick **one** bond that Terminal shows OAS/Z/I for; record its values for the two
   chosen business days; choose start/end as **last 5 trading days** (not 30).
2. Click Update once. Log per-request: type, elapsed, row count, returned columns,
   error text; keep the app's per-field status panel.
3. Compare Top-10 `Change` values and units against Terminal; verify
   `Change == End Spread − Start Spread` using the added `first()`/`last()` validation
   values.
4. Inspect null/coverage counts (especially non-USD Global Aggregate members) and the
   effective observation dates.
5. Only after a successful narrow run: widen dates / consider cached mode / decide
   production status; record results in `VersionLog.md` and the `23` decision records.

---

## 9. Remediation options

**Option A (recommended if the recorded selections are genuinely yours):**
keep the UI and BQL design; then

1. Record a dated user-evidence note (this report's section 2 selections) and create
   `DECISION_RECORD.md` with `23` records for universe/membership, each spread type,
   each descriptor, and a Guarded "validation run" record.
2. Fix C1–C13; add diagnostics, date guards, `first()`/`last()` validation values, and
   the missing tests.
3. Reconcile the KB: promote card 29 into the canonical pipeline (rules 00/01/10, index
   header counts + `local_user_evidence_through`, `topic_sources` range, semantic index,
   route row first-success wording, `regenerate --check`), and add the VersionLog /
   instruction / ToDoList entries.
4. Add `Upload/`, align `MAIN`/`render()`, add the safety banner and validation-only
   labelling.
5. Run the narrow Desktop validation above.

**Option B (if the recorded selections are not confirmed):** restore the fail-closed
gate (approval-required diagnostic, no data), keep the OAS/Z/I dropdown and date pickers
as visibly disabled UI, revert card 29/project rule to the fail-closed version, reconcile
the router back to `00:62`, and update the secretary files.

Either way, no production reliance until units, entitlement, semantics, and breadth are
verified on Desktop.

---

## 10. Questions requiring the user's decision

1. **Did you (in the Copilot conversation) select:** `LEGATRUU Index` as this project's
   universe, the 6 descriptor fields (`id`, `name`, `rating`, `crncy`, `maturity`,
   `duration`), and a "validation run" (not production)? The rewritten card 29 and
   project rule say yes; this workspace has no independent record.
2. **Is this version intended as validation-only,** or as an approved production tool?
3. **May I promote card 29 into the canonical KB pipeline** and reconcile
   `00`/rules `00`/`01`/`10`, then regenerate and `--check`?
4. **Which remediation option** should I execute now (A: confirm + fix + document, or
   B: revert to fail-closed)? Option A is recommended only after question 1 is answered.

---

## Appendix A — verified file inventory (mtimes, 2026-10-23)

| File | mtime | Note |
|---|---|---|
| `fi_spread_movement/config.py` | 23:40:14 | live constants, gate removed |
| `README.md`, `MAIN.ipynb` | 23:41:19 | live-request claims |
| `fi_spread_movement/app.py` | 23:43:02 | dropdown + date pickers |
| `fi_spread_movement/engine.py` | 23:44:07 | BQL-ranked validation |
| `tests/test_engine.py` | 23:44:07 | FakeBQL suite |
| `RAG KB/29-fi-spread-movement-monitoring.md` | 23:44:14 | rewritten authority |
| `fi_spread_movement/data.py` | 23:44:38 | live BQL |
| `.cursor/rules/project-fi-spread-movement-monitoring.mdc` | 23:44:38 | rewritten rule |
| `RAG KB/regenerate_kb_bundle.py` | 23:42:31 | builder edited in-window |
| generated KB artifacts | 23:44:44 | regenerated |
| `fi_spread_movement/__init__.py` | 23:27:53 | unchanged |

## Appendix B — commands executed by this verification

- `python3 -m unittest discover -s tests -v` (project folder) → 4 tests OK
- `python3 -m py_compile fi_spread_movement/*.py tests/test_engine.py` → OK
- `python3 "RAG KB/regenerate_kb_bundle.py" --check` → `integrity=ok topics=29 rules=11`
- `stat`/`find -newermt` timestamp audit of the workspace
- read-only greps against `RAG KB/` and `.cursor/rules/`
- synthetic pandas probes of `_normalize_id_frame`, `_item_frame`, `_merge_item_frames`,
  and `prepare_ranked_movers` (no BQL; recorded in the audit annex)

The draft-audit portion of this report wrote only this report. The 2026-10-24 V1
rewrite recorded in the update section below changed the project, KB, rules, and
secretary files as described there.

---

## Update 2026-10-24 — V1 rewrite (supersedes the draft findings above)

**Trigger.** The operator confirmed in chat on 2026-10-24 that the 2026-10-23
selections are theirs (universe `LEGATRUU Index`, OAS/Z/I, custom start/end dates,
descriptors `id`/`name`/`rating`/`crncy`/`maturity`/`duration`), asked for a first
version followed by a Desktop production/validation test and iterative fixes,
confirmed BQuant Python is 3.11, and authorised a full redesign where the Copilot
draft was unsuitable.

**Authority reconciliation (after the user confirmation).**

- `RAG KB/29` now records the dated confirmation (section `## User confirmation
  (2026-10-24)`, `29:88-97`) while keeping the no-fill rule and the explicit
  "not proof of entitlement/units/semantics" caveat.
- Card 29 was promoted into the canonical KB pipeline: `00-RAG-INDEX.md` header
  `local_user_evidence_through: 2026-10-24` and `canonical_markdown_sources: 30`,
  route-row first-success/do-not wording updated, rules `00`/`01`/`10` route-card
  lists updated, and `regenerate_kb_bundle.py` now covers topics `01`–`29`.
- Generated artifacts were regenerated (never hand-edited):
  `python3 "RAG KB/regenerate_kb_bundle.py" --check` →
  `integrity=ok topics=30 rules=11 bundle_lines=39023`.
- This closes integrity findings I1–I4 from the draft audit at the process level.
  It does **not** imply production sign-off.

**V1 rewrite (project files).**

- `data.py`: documented calls only — `bq.univ.members(index, dates=end)`,
  `spread(spread_type=..., dates=func.range(start, end)).net_chg()`,
  `universe.filter(condition).filter(grouprank(order=...) <= TOP_N)`,
  `groupsort()`, `bql.Request`/`bq.execute`, `bq.univ.list(candidate_ids)`, and
  per-descriptor `name`/`rating`/`crncy`/`maturity`/`duration`. The undocumented
  `bq.data.id()["value"]` request was removed; the Bloomberg ID is the ranking
  response `ID` key. No `fill`, no `replacena`, no zero substitution.
- Added a bounded candidate-series request (≤20 IDs) that exposes the effective
  observation dates and checks `Change == Last Spread − First Spread`; it is
  diagnostic only and cannot hide the ranked tables.
- Response normalization supports Arrow `.get` and len/index fallback, named and
  unnamed object ID indexes, an `ID` column, `ID`/`DATE` MultiIndex, `DATE`-column
  and wide date-column series; row-number and datetime indexes are rejected rather
  than promoted to fake IDs.
- `engine.py`: pure pandas direction validation, deterministic ordering, cap,
  dedupe/dropped/tie/short-list diagnostics, descriptor merge on `ID`, and the
  effective-date/unit comparison.
- `app.py`: the whole Update handler runs in `try/except`, the button is disabled
  in `finally`, results are cleared on every failure/early return, and date guards
  cover start≥end, future ends, a 31-day cap, and weekend warnings. The UI carries
  a validation-only banner, per-field status, and a request log.
- `MAIN.ipynb`: sibling-style `sys.path` bootstrap, stamp print,
  `display(app.render())`, Update-only comment, nbformat cell id; no startup request.
- Tests: 49 synthetic tests across engine, data/adapter, app (widget stubs), and
  notebook; all pass locally.
- Handoff: README rewritten, `DECISION_RECORD.md` added with the dated confirmation
  and `23`-format records, `Upload/` `.txt` staging generated, and the root
  `VersionLog.md` / `instruction.md` / `ToDoList.md` updated.

**Independent review pass (2026-10-24).** A separate read-only review of the V1
rewrite found four must-fix defects; all were fixed before handoff:
(1) a post-fetch exception now keeps the already-collected request log and
per-field diagnostics on screen; (2) ranking frames that carry a `DATE` column no
longer fail both lists; (3) the descriptor/series candidate universe is capped at
the at-most-20 rule even when BQL `grouprank` ties return more rows; (4) a response
parse failure still records the executed request in the log. Should-fix items were
also closed: object date/numeric indexes are rejected instead of becoming fake IDs,
single-date wide series melt correctly, effective-date mismatches and duplicate
series rows are noted, and the surviving-mutation test gaps were covered. A second
reviewer verified every BQL token against the local KB: the request construction
matches the documented FI recipe; the only non-verbatim composition is the bounded
candidate-series validation request, which is diagnostic, fail-soft, and now
described in card 29 and DR-10 with the documented-ingredient citations.

**Local evidence (2026-10-24).**

- `python3 -m py_compile fi_spread_movement/*.py tests/*.py` → OK.
- `python3 -m unittest discover -s tests -v` → **49 tests OK** (system Python
  3.12.7 / pandas 3.0.5; fake `bql` only; no BQL executed).
- `python3 "RAG KB/regenerate_kb_bundle.py" --check` → `integrity=ok topics=30 rules=11`.
- Python 3.11 compatibility: the code avoids 3.12-only syntax and uses pandas APIs
  available in the 1.5/2.x era; the local runtime is 3.12, so the first Desktop run
  remains the real 3.11 check.

**Remaining validation risks (unchanged until the Desktop run).**

1. Units of OAS/Z/I values and of `Change` (no bps/% labels are applied).
2. `net_chg()` endpoint behaviour with no `fill` on weekend/holiday endpoints —
   exposed by the effective-date validation table.
3. Z-spread parameters/coverage, OAS-as-mover use, `duration()` semantics, and
   `rating()` scale.
4. Request breadth/timeout: 2 ranking + 5 descriptor + 1 series request; default
   7-day window with a 31-day cap; measure and record before widening.
5. The candidate-series request re-reads a fresh dated item on an explicit
   `bq.univ.list` universe; the documented ingredients are `02:1966-1978` /
   `12:682-694`, but the whole composition is diagnostic and not verbatim in the
   KB. Failure is non-blocking by design. It now builds a fresh item (never the
   `net_chg()` expression) and is described in card 29 and DR-10.
6. Membership as of the end date (survivorship) and entitlement confirmation.

**Copilot draft score: 6/10** for a free-tier Auto first pass. The high-level
design and BQL skeleton were right and largely copied from the KB's own FI recipe
(the strongest part), but governance (rewriting the authority card/rule in the
implementation window), error handling, diagnostics, parser heuristics, and
test fakes were not production-grade. Suitable as a reference draft, not an
unreviewed handoff.

**Next step.** Copy the runtime files from `Upload/` to BQuant Desktop
(Python 3.11), run the narrow first validation (last five business days), record
the request log, effective dates, units, and coverage in `DECISION_RECORD.md`,
then widen the window and iterate.

## Update 2026-11-01 — four sources, two tabs, comparison union fix

**Scope.** Everything below is a local read/author/test pass. **No BQL, BQuant,
or Bloomberg request was executed or constructed**; the checks use the widget
stubs and the fake `bql` module in `tests/`.

**State at this revision.**

- Runtime: `fi_spread_movement/{__init__,config,data,engine,charts,app}.py`.
  `charts.py` was added on 2026-11-01, so the Desktop copy step is **six**
  runtime files plus `MAIN.ipynb`, all staged in `Upload/`.
- Sources: `Index`, `AIM account`, `AIM vs Index` (DR-14), `Bond` (DR-15).
- Tabs: `Main` and `Export Excel` (DR-16).
- `python3 -m unittest discover -s tests` → **245 tests OK** (synthetic data
  only, no network).
- `python3 preview/build_preview.py --check` → `interface.html is in sync`.
- `python3 .qoder/sync_rules.py --check` → `rule-sync=ok artifacts=13 rules=12`.
- `python3 "RAG KB/regenerate_kb_bundle.py" --check` →
  `integrity=ok topics=30 rules=12 bundle_lines=39961`.

**Defects found in the 2026-11-01 review pass and fixed.**

1. **Comparison candidate union was truncated.** `_candidate_ids` sliced each
   side with `[:TOP_N]` *after* the two books had already been concatenated, so
   an `AIM vs Index` run kept only the index book's IDs. The AIM descriptors were
   never requested, and the missing rows rendered as `(blank)` instead of
   `(unavailable)` — "we did not ask" presented as a bridge answer, which is
   exactly what DR-14's first comparison run is meant to disprove. The bound is
   now the deduplicated union of both books (≤20 one-book, ≤40 comparison), and
   the cut stays where it belongs: `grouprank` per book.
2. **Descriptor coverage is now explicit.** An ID the descriptor response never
   covered is `(unavailable)` with a note counting those IDs; `(blank)` is kept
   for a value Bloomberg returned empty. Numeric descriptors stay NaN so their
   buckets stay `Missing`.
3. **The field whitelist test was a no-op.** It looped over the allowed names
   but asserted only that the literal `"bq.data."` appeared, so an unreviewed
   descriptor could be added silently. It now compares
   `config.DESCRIPTOR_FIELDS` against an explicit whitelist and regex-scans the
   package for undeclared `bq.data.<name>` call sites. A companion test keeps
   the restricted data families out of the runtime package.
4. **Refused / failed Update left the previous run on screen.** The figures are
   now cleared with the state that produced them; the per-field receipt survives
   in `Export Excel`, which is where DR-16 puts it.
5. **`Export Excel` ignored the filters.** The two ranked tables now copy what
   `Main` shows; `Validation` and the request log are copied whole.
6. **A one-book run carried a constant `Universe` column.** It is now only
   present when two books were actually requested.
7. Smaller: control edits returned to their loaded values restore `Updated`
   instead of a stale `Please Click Update`; the duplicate-ID and `no_series`
   notes count the right unit; dead `normalize_index()`, `MIXED_UNIVERSE_LABEL`,
   `AIM_ACCOUNT_BATCH`, and `EXPORT_HEADER_REPEAT` removed; `AIM_PXNUM` is the
   frozen `1377` and a non-numeric override is refused instead of sent as text;
   the path-chart fallback table tolerates a trace with no observation.

**Still not verified. Nothing below can be signed off from this machine.**

Units of OAS/Z/I and of `Change`, `net_chg()` endpoint behaviour, Z-spread
parameters and coverage, `duration()` semantics, `rating()` scale,
`country_full_name()` / `classification_name()` vocabulary and null rate, AIM
account resolution and the number of holdings without a spread, whether
`bq.univ.list` supports the ranking composition for `Bond`, the 10/12 request
budget against the two-minute timeout, and the Desktop versions of Plotly,
pandas, and ipywidgets. The `AIM vs Index` first run is the evidence that DR-14
and DR-18 §G4 are waiting for.

## Update 2026-11-01 (later) — display pass (DR-21)

**Scope.** Display only. No `bql.Request`, field list, `with_params`, or request
count changed; `data.py` and `engine.py` semantics, units, fill direction, and the
`(unavailable)` / `(blank)` rule are untouched. Every check below ran locally
against the widget stubs and the placeholder `FetchResult`; **no BQL request was
executed or constructed.**

- `python3 -m unittest discover -s tests` → **259 tests OK**.
- `python3 sync_upload.py --check` → `Upload mirrors are in sync`.
- `python3 preview/build_preview.py --check` → `interface.html is in sync`.
- `rg "Index vs AIM comparison"` across the project → no match; the string lives
  only in `config.COMPARISON_TITLE`.

**What the interactive preview showed (port 8775, `Universe = AIM vs Index`).**

- The comparison panel renders a diverging chart: one row per `(bucket, book)`,
  `AIM` above `Index`, increases to the right and decreases to the left of a
  centred zero line, with one symmetric limit shared by both sides.
- `Top 10 increases` and `Top 10 decreases` each sit directly under their own
  chart, split into `AIM (n row(s))` then `Index (n row(s))`.
- The path chart says `Select a bond to view its spread path: click a bar, a
  line, or a ranked row.` before any click, and draws exactly one line after one.
- `Main` no longer shows the request log; `Export Excel` still carries it
  (`Request log`), next to the DR-16 `Request detail` receipt.

**Not verified, and not claimed.** The Desktop Plotly rendering of the diverging
axis (bar stacking, tick placement, legend order), whether the Desktop series
response covers the selected ID at the expected density, and whether a real
two-book run produces any `Matches BQL = False` row. The placeholder dataset in
the preview deliberately reports mismatches (its series and its ranking are
generated independently), so that banner is a fixture property, not a finding.

## Update 2026-11-02 — Display Top per ranked panel (DR-25)

**Scope.** Display only. No `bql.Request`, field list, `with_params`, `TOP_N`, or
request count changed. Both panels slice frames already in memory.

- `python3 -m pytest -q` → **317 passed**.
- `python3 sync_upload.py --check` → `Upload mirrors are in sync`.
- `python3 preview/build_preview.py --check` → `interface.html is in sync`.
- Live preview (port 8812, `Universe = Index`): `Update` drew 19 movers; typing
  `3` in the increases box and pressing its `Refresh` redrew 3 increase rows and
  left the 9 decrease rows alone; the headline changed from `19 mover(s) charted`
  to `12 mover(s) charted · … Display Top 3 per book (3 of 10 row(s) drawn)`.
  `GET /` carried one `Update` button plus the four Display Top field names.
- App-level tests pin the two-book rule: `Display Top 3` over a six-row-per-book
  frame draws `{'AIM': 3, 'Index': 3}`. A single `head(3)` on the stacked frame
  would have returned 3 AIM rows and no Index rows.

**Not verified, and not claimed.** `widgets.IntText` is new to this app, so the
Desktop rendering of the box (description width, spinner behaviour) and the
Desktop `Button.on_click` path are unverified until the next Desktop run. The
preview exercises the same `_apply_display_top` / `_display_top_rows` code, not a
parallel copy, but it is not the Desktop kernel.
## Update 2026-11-02 (later) — `Asset swap spread` withdrawn (DR-26)

- Scope: one dropdown option removed, not a request change. `config.SPREAD_TYPES`
  is `OAS` / `Z` / `I` again; `DR-22`, which added `ASW`, is marked superseded.
- `data._validated_window()` now refuses both `"Asset swap spread"` and `"ASW"`
  with `ValueError`, because the label lookup returns nothing and the code check
  no longer matches a mapped value. Pinned by
  `tests/test_engine.py::SpreadChoiceTests`.
- `preview/preview_core._SPREAD_FACTORS` lost its `Asset swap spread` factor; it
  is read with `.get(label, 1.0)`, so no dangling key can raise.
- Local checks: `pytest -q` → 320 passed; `sync_upload.py --check` in sync;
  `preview/build_preview.py --check` → `interface.html is in sync`;
  `.qoder/sync_rules.py --check` → `rule-sync=ok artifacts=13 rules=12`; the live
  page (port 8775, build `eb9c06eba763`) lists exactly `OAS`, `Z-Spread`,
  `I-Spread` in the Spread box.

**Not claimed.** No elapsed time was measured before or after this removal. A run
sends one spread type either way, so this does not reduce a returned frame; it
removes the heaviest selectable measure. Whether `ASW` ever caused a real Desktop
timeout is unverified, and the units/sign questions in `DR-22` stay open should
the choice ever return.

