"""CSV result cache for one (universe, spread, window) run.

Why this exists. The operator's only remaining worry about this project is the
Desktop two-minute query limit, and the sibling project solved it three ways:
a cache, a split request, and a retry. This module is the cache. ``data.py``
spends the split, and ``app.py`` spends the retry, so a run that times out can
still put a usable screen in front of the operator.

**What is stored, and what that means for correctness.** One file per run key,
holding only what the run produced: the two ranked sides, the descriptor table
and the spread series, plus the diagnostics and the request log. It is the
*result* of a run, not a security master, so reloading it replays exactly what
one Update returned and never re-derives anything.

**Why a cached result is stale-able and must say so.** A spread change is only
true for its window. This cache therefore keys on the universe, the spread type
and both dates, so a different window can never be served the same file. It also
keys on a generation token, so a change to the pipeline invalidates old files
instead of replaying a frame the current code would not have produced: the
sibling project shipped a poisoned month exactly that way. ``CACHE_GENERATION``
must be bumped whenever a stored result would be wrong under the new code.

**Never a silent substitution.** A cached run is presented as cached: the
status word is ``Cached``, the detail box names the cache file and its age, and
the request log says the data came from disk rather than from Bloomberg. A
cached table is never labelled ``Updated``, because that word would claim a
request ran.

**A cache hit is not a reason to skip the request.** Only two paths read this
cache: an explicit operator request to use what was saved, and the automatic
fallback after a timeout. A normal Update always asks Bloomberg first. That
keeps the cache a safety net rather than a stale-data trap.

pyarrow is not required; the format is CSV plus a JSON manifest, the same choice
``FI Index Change`` made for the same reason.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from . import config

# What the stored result *means*, not which columns it holds. Bump this whenever
# a stored run would be wrong under the new code: a changed merge key, a changed
# ranking rule, a changed descriptor list, or a changed spread mapping. A change
# that only touches wording does not need a bump, but a reader cannot tell the
# two apart later, so the safe direction is to bump.
#
# "result-v1" is the first generation. Everything written before this module
# existed does not exist, so there is nothing older to invalidate.
CACHE_GENERATION = "result-v1"

MANIFEST_NAME = "manifest.json"
SERIES_NAME = "series"
RANKED_NAME = "ranked"


def cache_dir(root: Path | None = None) -> Path:
    """Where cached runs live. Does not create the directory.

    Creating it during a read meant every Update paid a ``mkdir`` even when the
    run was not cached and nothing would be written, so a read-only Desktop
    project folder failed the whole Update before any data was read. Only the
    write path creates it now; a missing folder reads as "nothing cached".
    """
    base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    return base / config.CACHE_DIR_NAME


def _manifest_path(root: Path | None) -> Path:
    return cache_dir(root) / MANIFEST_NAME


def _read_manifest(root: Path | None) -> dict:
    path = _manifest_path(root)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_manifest(payload: dict, root: Path | None) -> None:
    path = _manifest_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def safe_name(text: str) -> str:
    """A file-name-safe token. An AIM code or a ticker can hold ``/`` or spaces."""
    token = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in str(text))
    return token or "unnamed"


def run_key(
    source_key: str,
    universe_key: str,
    aim_value: str,
    spread_code: str,
    start: str,
    end: str,
    top_n: int,
) -> str:
    """The identity of one run's result.

    Every input that changes what the request returns is in the key, so a
    cached file can only ever be served to the run that asked for it. ``TOP_N``
    is included because it decides how many rows the ranking request asks for:
    raising it and being served the narrower cached frame would silently cap the
    tables at the old width.

    The two universe values are always present, in a fixed order, because
    ``AIM vs Index`` needs both and a one-book run passes an empty second value.
    That keeps one key shape for all four sources.
    """
    parts = (
        CACHE_GENERATION,
        str(source_key),
        str(universe_key),
        str(aim_value),
        str(spread_code),
        str(start),
        str(end),
        str(int(top_n)),
    )
    # A readable prefix plus a hash: readable so a folder listing can be
    # understood without opening the manifest, hashed so a long ticker or a pair
    # of universes cannot produce an over-long or colliding file name.
    readable = "_".join(safe_name(part) for part in parts[1:6])
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:12]
    return f"{readable}__{digest}"


def _stem(key: str) -> str:
    return safe_name(key)


def files_for(key: str, root: Path | None = None) -> dict[str, Path]:
    """Every file one cached run owns. Used by the writer and by pruning."""
    folder = cache_dir(root)
    stem = _stem(key)
    return {
        "ranked": folder / f"{stem}_{RANKED_NAME}.csv",
        "descriptors": folder / f"{stem}_descriptors.csv",
        "series": folder / f"{stem}_{SERIES_NAME}.csv",
    }


def _storable(frame: pd.DataFrame | None) -> pd.DataFrame:
    if frame is None:
        return pd.DataFrame()
    return frame.copy()


def save_run(
    key: str,
    result,
    root: Path | None = None,
) -> None:
    """Persist one successful run. A run with no ranked row is refused.

    An empty result is not cached on purpose: it is either a genuine "no movers"
    or a parse that lost everything, and replaying it as a cache hit would tell
    the operator nothing arrived when the truth is that nothing was asked. The
    next Update requests it again, which is the behaviour a fail-visible app
    wants.
    """
    if result is None:
        raise ValueError("Refusing to cache a missing result.")
    increases = _storable(getattr(result, "increases", None))
    decreases = _storable(getattr(result, "decreases", None))
    descriptors = _storable(getattr(result, "descriptors", None))
    series = _storable(getattr(result, "series", None))
    if increases.empty and decreases.empty:
        raise ValueError("Refusing to cache a run with no ranked rows.")

    folder = cache_dir(root)
    folder.mkdir(parents=True, exist_ok=True)
    paths = files_for(key, root)

    ranked_frames = []
    for side, frame in (("increases", increases), ("decreases", decreases)):
        if frame.empty:
            continue
        work = frame.copy()
        work.insert(0, "SIDE", side)
        ranked_frames.append(work)
    if ranked_frames:
        pd.concat(ranked_frames, ignore_index=True).to_csv(
            paths["ranked"], index=False, encoding="utf-8"
        )
    else:  # pragma: no cover - guarded by the emptiness check above
        paths["ranked"].unlink(missing_ok=True)

    if not descriptors.empty:
        descriptors.to_csv(paths["descriptors"], index=False, encoding="utf-8")
    else:
        paths["descriptors"].unlink(missing_ok=True)

    if not series.empty:
        series.to_csv(paths["series"], index=False, encoding="utf-8")
    else:
        paths["series"].unlink(missing_ok=True)

    manifest = _read_manifest(root)
    manifest[key] = {
        "generation": CACHE_GENERATION,
        # A monotonic sequence, because the manifest is written sorted by key:
        # its insertion order says nothing about which run is newer, so pruning
        # on key order could delete the run that was just saved.
        "seq": _next_seq(manifest),
        "saved_at": pd.Timestamp.now().isoformat(timespec="seconds"),
        "source": str(getattr(result, "source", "")),
        "universe": str(getattr(result, "universe", "")),
        "comparison": bool(getattr(result, "comparison", False)),
        # The four inputs the screen is labelled with. A cached load renders
        # these, never the live widgets, so an edit made while the request was
        # running cannot relabel the cached data as a different run.
        "request": dict(getattr(result, "cache_request", None) or {}),
        "rows": {"increases": int(len(increases)), "decreases": int(len(decreases))},
        "files": {
            name: path.name
            for name, path in paths.items()
            if path.exists()
        },
        "bytes": {
            name: path.stat().st_size
            for name, path in paths.items()
            if path.exists()
        },
        "field_status": dict(getattr(result, "field_status", {}) or {}),
        # The log is stored so a cached load can still show what the original
        # run cost. It is labelled in the app as the original run, never as a
        # measurement of the load.
        "request_log": list(getattr(result, "request_log", []) or []),
    }
    _write_manifest(manifest, root)


def _next_seq(manifest: dict) -> int:
    """One higher than every recorded sequence, so ordering survives a restart."""
    values = [
        int(entry.get("seq", 0))
        for entry in manifest.values()
        if isinstance(entry, dict) and isinstance(entry.get("seq"), (int, float))
    ]
    return (max(values) + 1) if values else 1


def has_run(key: str, root: Path | None = None) -> bool:
    """True when a complete, current-generation result is on disk for ``key``.

    Existence alone is not enough: a write that crashed midway leaves a truncated
    CSV, and serving it would show fewer rows than the manifest claims with no
    sign that anything was missing. The recorded byte size catches that, so a
    half-written run reads as "nothing cached" and the next Update rewrites it.
    """
    manifest = _read_manifest(root)
    entry = manifest.get(key)
    if not isinstance(entry, dict):
        return False
    if entry.get("generation") != CACHE_GENERATION:
        return False
    files = entry.get("files")
    if not isinstance(files, dict) or "ranked" not in files:
        return False
    sizes = entry.get("bytes")
    folder = cache_dir(root)
    for name, filename in files.items():
        path = folder / str(filename)
        if not path.exists():
            return False
        if isinstance(sizes, dict) and name in sizes:
            try:
                if int(sizes[name]) != path.stat().st_size:
                    return False
            except (OSError, TypeError, ValueError):
                return False
    return True


def load_run(key: str, root: Path | None = None):
    """Return ``(result, info)`` for a cached run, or ``(None, None)``.

    ``info`` is what the app shows so a reader can tell a cached screen from a
    fresh one: the file names, the row counts and the original request log.
    Text columns are read as text with no NA inference, so an empty cell stays an
    empty string instead of becoming ``"nan"`` in a table.
    """
    if not has_run(key, root):
        return None, None
    manifest = _read_manifest(root)
    entry = manifest[key]
    folder = cache_dir(root)
    files = {name: folder / str(value) for name, value in entry["files"].items()}

    try:
        ranked = pd.read_csv(files["ranked"], dtype=str, keep_default_na=False)
    except Exception:
        return None, None
    if ranked.empty or "SIDE" not in ranked.columns:
        return None, None

    from .data import FetchResult

    result = FetchResult()
    result.source = str(entry.get("source", ""))
    result.universe = str(entry.get("universe", ""))
    result.comparison = bool(entry.get("comparison", False))
    result.field_status = dict(entry.get("field_status", {}) or {})
    result.request_log = list(entry.get("request_log", []) or [])

    for side, attribute in (("increases", "increases"), ("decreases", "decreases")):
        block = ranked.loc[ranked["SIDE"] == side].drop(columns=["SIDE"])
        setattr(result, attribute, _restore(block, config.NUMERIC_RESULT_COLUMNS))

    descriptors = _read_optional(files.get("descriptors"))
    result.descriptors = (
        pd.DataFrame(columns=["ID"])
        if descriptors is None
        else _restore(descriptors, config.NUMERIC_DESCRIPTOR_COLUMNS)
    )
    series = _read_optional(files.get("series"))
    result.series = (
        pd.DataFrame(columns=["ID", "DATE", "Spread"])
        if series is None
        else _restore(series, ("Spread",))
    )
    info = {
        "generation": entry.get("generation"),
        "rows": dict(entry.get("rows", {}) or {}),
        "files": sorted(files[name].name for name in files),
        "request_log": result.request_log,
        # What the screen must be labelled with. Read from the manifest, never
        # from the live widgets: an edit made while a request was running would
        # otherwise caption one run's numbers with another run's dates.
        "request": dict(entry.get("request", {}) or {}),
        "saved_at": entry.get("saved_at"),
    }
    result.cache_request = dict(info["request"])
    return result, info


def _read_optional(path: Path | None) -> pd.DataFrame | None:
    if path is None or not path.exists():
        return None
    try:
        return pd.read_csv(path, dtype=str, keep_default_na=False)
    except Exception:
        return None


def _restore(frame: pd.DataFrame, numeric: tuple[str, ...]) -> pd.DataFrame:
    """Turn the text columns read back from CSV into the dtypes the app expects.

    Only the columns that must be numeric are converted, and ``errors="coerce"``
    is used because an empty cell is a legitimate value on a cached frame: it
    came from a run where that field did not arrive, and it must stay NaN rather
    than become ``0``.
    """
    out = frame.copy()
    if "ID" in out.columns:
        out["ID"] = out["ID"].astype("string")
    for column in numeric:
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce")
    if "DATE" in out.columns:
        out["DATE"] = pd.to_datetime(out["DATE"], errors="coerce")
    return out


def prune(keep: int, root: Path | None = None) -> list[str]:
    """Delete the oldest cached runs beyond ``keep``. Returns the removed keys.

    A cache that grows without limit eventually fills a Desktop project folder
    with files nobody reads. Ordering comes from each entry's ``seq``, not from
    the manifest's key order: the manifest is written sorted by key, so slicing
    it by position deletes by *name* and can remove the run that was just saved.
    Entries written before ``seq`` existed sort last, which is the safe direction
    — a new run always outranks them.

    Files whose key is no longer in the manifest are removed too; they can only be
    left over from an interrupted write.
    """
    manifest = _read_manifest(root)
    if keep < 0:
        keep = 0
    ordered = sorted(
        manifest,
        key=lambda key: (
            int(manifest[key].get("seq", 0))
            if isinstance(manifest.get(key), dict)
            and isinstance(manifest[key].get("seq"), (int, float))
            else -1
        ),
    )
    stale = ordered[:-keep] if keep else ordered
    removed: list[str] = []
    for key in stale:
        entry = manifest.pop(key, None)
        if isinstance(entry, dict):
            for name in (entry.get("files") or {}).values():
                (cache_dir(root) / str(name)).unlink(missing_ok=True)
        removed.append(key)
    if removed:
        _write_manifest(manifest, root)
    # Orphaned files: a write that crashed after creating a CSV but before the
    # manifest was updated leaves a file no key points at.
    live = {
        str(name)
        for entry in manifest.values()
        if isinstance(entry, dict)
        for name in (entry.get("files") or {}).values()
    }
    folder = cache_dir(root)
    if folder.is_dir():
        for path in folder.glob("*.csv"):
            if path.name not in live:
                path.unlink(missing_ok=True)
    return removed


def describe(info: dict | None) -> str:
    """One sentence naming the cache file and what it holds, for the log."""
    if not info:
        return "Cached run: no details recorded."
    files = ", ".join(info.get("files") or []) or "(no files)"
    rows = info.get("rows") or {}
    return (
        f"Cached run {info.get('generation')}: "
        f"{rows.get('increases', 0)} increase and {rows.get('decreases', 0)} "
        f"decrease row(s) read from {files}."
    )
