"""BQL access for FI Spread Movement Monitoring.

Only KB-documented calls are used (``RAG KB/02``, ``12``, ``07``, ``08``,
``25``):

Index universe:
- ``bq.univ.members(index, dates='YYYY-MM-DD')``

Bond universe (added 2026-11-01):
- ``bq.univ.list([one_ticker])``. ``RAG KB/06`` § universe requires a private
  literal universe to be wrapped in ``bq.univ.list([...])``, and ``RAG KB/02``
  § Project Practice Notes already spends ``spread().value(bq.univ.list(bond))``
  on one bond. Exactly one ticker is sent: a comma-separated list would widen
  the universe past the bond the operator asked for, so it is refused.

AIM universe (frozen 2026-08-28 Desktop contract, ``RAG KB/25`` § AIM request
shape):
- ``bq.univ.members(type="AIM")`` as the expression
- ``accounts=[one code]``, ``pxnum``, ``profile="DEFAULT_PROFILE"`` on
  ``bql.Request(..., with_params=...)``. Not on ``members()``. No dates.
- The frozen position item ``position_without_pending()["value"]`` is part of
  the same contract, but this app needs the spread ranking only, so the
  position item is not requested. Do not add ``ts_position()`` in its place.
- Holdings include cash and equity lines. Those carry no spread, so they never
  rank; the request does not filter them, because a filter on an unverified
  type vocabulary could silently drop a bond.

Both universes:
- ``bq.data.spread(spread_type=..., dates=bq.func.range(start, end))``
  followed by ``.net_chg()`` and ``.grouprank()`` / ``.groupsort()``
- ``bq.data.name()``, ``rating()``, ``crncy()``, ``maturity()``, ``duration()``
- ``bq.univ.list(ids)`` for the ranked candidate IDs: at most ``2 * TOP_N``
  in a one-book run and ``4 * TOP_N`` in the two-book comparison
- a bounded candidate-series request (fresh dated item on the candidate list)
  used only to expose effective observation dates and check the change arithmetic
- ``bql.Request`` / ``bq.execute``

``AIM vs Index`` (added 2026-11-01) runs the two frozen request shapes above
sequentially inside one Update and labels each ranked row with its book, so the
two universes are compared rather than added together. It spends four ranking
requests (two per book), then ONE descriptor set and ONE series request on the
union of both candidate lists, which keeps the total at twelve small requests
instead of twenty. Nothing is merged by ``ID`` alone: a bond can be a member of
the index and a holding of the account at the same time.

``fill`` is not added (RAG KB/29 requires two explicit dates without a
nearby-observation substitution). The ``bql`` import is guarded so this
module stays importable outside BQuant Desktop; no request can run locally.
"""

from __future__ import annotations

import numbers
import re
import time
import warnings
from dataclasses import dataclass, field
from datetime import date
from typing import Any

import pandas as pd

from . import config

try:
    import bql as _bql
except ImportError:  # pragma: no cover - exercised automatically off Desktop
    _bql = None

bql: Any = _bql

RANK_COLUMNS = ("ID", "Change")
SERIES_COLUMNS = ("ID", "DATE", "Spread")


@dataclass
class FetchResult:
    increases: pd.DataFrame = field(
        default_factory=lambda: pd.DataFrame(columns=list(RANK_COLUMNS))
    )
    decreases: pd.DataFrame = field(
        default_factory=lambda: pd.DataFrame(columns=list(RANK_COLUMNS))
    )
    descriptors: pd.DataFrame = field(default_factory=lambda: pd.DataFrame(columns=["ID"]))
    series: pd.DataFrame = field(
        default_factory=lambda: pd.DataFrame(columns=list(SERIES_COLUMNS))
    )
    field_status: dict[str, str] = field(default_factory=dict)
    request_log: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    # The typed ticker or AIM code, kept even when the request fails so the
    # status bar can name what was refused.
    universe: str = ""
    # The universe actually requested: "index", "aim", "bond", or the
    # comparison pair "aim_vs_index".
    source: str = "index"
    # True only for the two-book comparison run, so the app can switch the
    # comparison panels on from the result instead of guessing from a column.
    comparison: bool = False
    # The inputs that produced this run, captured before the request was built.
    # The cache stores them and a cached screen is labelled from them, so an
    # edit made while the request was running cannot relabel the data. A live run
    # leaves it empty; only the app fills it in, because only the app knows what
    # the operator typed and when.
    cache_request: dict = field(default_factory=dict)

    @property
    def index(self) -> str:
        """Backwards-compatible alias for the typed universe value."""
        return self.universe


def _require_bql() -> Any:
    if bql is None:
        raise RuntimeError(
            "bql is unavailable. Run this notebook on BQuant Desktop; this "
            "workspace never executes Bloomberg requests."
        )
    return bql


# A timeout is the only failure a second identical attempt can recover from.
# Everything else (a rejected item name, an unentitled field, a malformed
# ticker) is deterministic, so retrying it only spends another two minutes.
_TIMEOUT_MARKERS = (
    "bqltimeouterror",
    "took too long",
    "query timed out",
    "timed out",
    "timeout",
)

# Text that can only mean a deterministic failure, whatever else the message
# says. Checked first, so these always win: the sibling project once classified
# ``No BQL data item named 'timeout_field'`` as a timeout because the marker
# "timeout" appeared inside the field name, and paid a second two-minute wait
# for something that could never succeed.
_DETERMINISTIC_MARKERS = (
    "no bql data item",
    "not entitled",
    "entitlement",
    "not authorized",
    "unauthorized",
    "403",
    "license",
    "invalid ticker",
    "does not exist",
    "unknown field",
)


def is_timeout(exc: BaseException) -> bool:
    """True when ``exc`` is the Desktop two-minute query limit.

    A message naming a deterministic failure is never a timeout, even when the
    item or ticker name happens to contain the word.
    """
    text = f"{type(exc).__name__}: {exc}".casefold()
    if any(marker in text for marker in _DETERMINISTIC_MARKERS):
        return False
    return any(marker in text for marker in _TIMEOUT_MARKERS)


def _execute_attempts(
    bq: Any,
    request_factory,
    label: str,
    errors: list[str],
    notes: list[str] | None = None,
) -> tuple[Any | None, int]:
    """Execute one request, retrying only a timeout. Returns ``(response, tries)``.

    ``request_factory`` rebuilds the Request per attempt so no state from a
    failed execute is reused; the item expressions themselves are built once by
    the caller. The retry sends exactly the same request, because the evidence
    is that the second attempt hits a warmed Bloomberg-side cache rather than
    that the first one was too wide.
    """
    notes = notes if notes is not None else []
    attempts = max(1, int(config.QUERY_ATTEMPTS))
    seconds: list[float] = []
    last: BaseException | None = None
    for attempt in range(1, attempts + 1):
        started = time.perf_counter()
        try:
            response = bq.execute(request_factory())
        except Exception as exc:
            elapsed = time.perf_counter() - started
            seconds.append(elapsed)
            last = exc
            if not is_timeout(exc) or attempt == attempts:
                break
            notes.append(
                f"{label}: attempt {attempt} of {attempts} timed out after "
                f"{elapsed:.0f}s. Retrying the same request unchanged; only a "
                "warm Bloomberg-side cache can make this faster."
            )
            continue
        elapsed = time.perf_counter() - started
        seconds.append(elapsed)
        if attempt > 1:
            notes.append(
                f"{label}: answered on attempt {attempt} of {attempts} in "
                f"{elapsed:.0f}s after a first attempt of {seconds[0]:.0f}s."
            )
        return response, attempt
    if last is not None:
        errors.append(f"{label}: {type(last).__name__}: {last}")
        if len(seconds) > 1:
            errors.append(
                f"{label}: all {len(seconds)} attempts failed "
                f"({', '.join(f'{value:.0f}s' for value in seconds)})."
            )
    return None, len(seconds)


def _as_date(value: Any, label: str) -> pd.Timestamp:
    if isinstance(value, bool) or isinstance(value, numbers.Number):
        raise ValueError(f"{label} must be a calendar date, not a number.")
    stamp = pd.Timestamp(value)
    if pd.isna(stamp):
        raise ValueError(f"{label} must be a valid calendar date.")
    return stamp.normalize()


def _as_index(index: Any) -> str:
    """Return the operator's index ticker, or raise a visible input error.

    The value is never replaced with a default: an empty field means no request.
    A ticker without the ``Index`` asset-class token is refused rather than
    resolved, because the same root can be a different universe.
    """
    if index is None:
        raise ValueError("Index is empty. Type the Bloomberg index ticker.")
    if not isinstance(index, str):
        raise ValueError("Index must be text.")
    cleaned = " ".join(index.split())
    if not cleaned:
        raise ValueError("Index is empty. Type the Bloomberg index ticker.")
    if not cleaned.lower().endswith(config.INDEX_REQUIRED_SUFFIX.lower()):
        raise ValueError(
            f"Index {cleaned!r} must end with {config.INDEX_REQUIRED_SUFFIX!r}, "
            "for example 'LEGATRUU Index'."
        )
    return cleaned


def _as_bond(bond: Any) -> str:
    """Return the operator's bond ticker, or raise a visible input error.

    A bond is ONE security, so a list separator is refused instead of being
    split: sending two bonds would silently widen the universe past the one the
    operator asked to inspect. An index ticker is refused too, because that
    names thousands of bonds and is what the Index source is for. The value is
    never replaced with a default: an empty field means no request.
    """
    if bond is None:
        raise ValueError("Bond is empty. Type one Bloomberg bond ticker.")
    if not isinstance(bond, str):
        raise ValueError("Bond must be text.")
    cleaned = " ".join(bond.split())
    if not cleaned:
        raise ValueError("Bond is empty. Type one Bloomberg bond ticker.")
    for token in config.BOND_FORBIDDEN_TOKENS:
        if token in bond:
            raise ValueError(
                f"Bond {cleaned!r} contains {token!r}; type one bond ticker, "
                "not a list."
            )
    if cleaned.lower().endswith(config.INDEX_REQUIRED_SUFFIX.lower()):
        raise ValueError(
            f"Bond {cleaned!r} names an index. Use the Index source for an "
            "index, or type one bond ticker here."
        )
    return cleaned


def normalize_bond(bond: Any) -> str:
    """Public form of the Bond-field check."""
    return _as_bond(bond)


def _as_aim_account(account: Any) -> str:
    """Return the operator's AIM code, or raise a visible input error.

    The value is never replaced with a default and never guessed from a fund
    name: an empty field means no request. AIM codes are single upper-case
    tokens, so the outside whitespace is trimmed and the token is upper-cased.
    A value that still contains whitespace is refused rather than joined or
    trimmed into a different account.
    """
    if account is None:
        raise ValueError("AIM account is empty. Type the AIM account code.")
    if not isinstance(account, str):
        raise ValueError("AIM account must be text.")
    cleaned = account.strip()
    if not cleaned:
        raise ValueError("AIM account is empty. Type the AIM account code.")
    if any(character.isspace() for character in cleaned):
        raise ValueError(
            f"AIM account {cleaned!r} contains a space; type one account code, "
            "for example 'ABC123'."
        )
    return cleaned.upper()


def normalize_universe(source: Any, value: Any) -> tuple[str, str]:
    """Return ``(source_key, universe_key)`` for the typed input.

    ``source`` is the dropdown label or the stored key. The returned universe
    is a normalised index ticker, AIM code, or bond ticker. A blank or
    malformed value raises ``ValueError`` so the app can refuse before any
    request is built.

    The comparison source needs TWO values, so it is refused here: use
    ``normalize_comparison()``, which validates both fields together and never
    falls back to one of them.
    """
    key = _universe_source_key(source)
    if key == config.COMPARISON_SOURCE:
        raise ValueError(
            "AIM vs Index needs both an AIM code and an index ticker; use the "
            "comparison request."
        )
    if key == "aim":
        return key, _as_aim_account(value)
    if key == "bond":
        return key, _as_bond(value)
    return key, _as_index(value)


def normalize_comparison(index: Any, aim: Any) -> tuple[tuple[str, str], tuple[str, str]]:
    """Validate both fields of the AIM vs Index source.

    Returns ``((("index", ticker), ("aim", code)))``. Both values are required:
    a blank on either side is a refusal, never a silent single-book run, because
    a one-sided "comparison" would read as a result.

    The AIM code is validated first because it is the left-hand field on
    screen. With both boxes blank the operator is told about the box on the
    left, not about whichever one the tuple happens to name first. The returned
    pair order is unchanged.
    """
    aim_pair = ("aim", _as_aim_account(aim))
    index_pair = ("index", _as_index(index))
    return index_pair, aim_pair


def _universe_source_key(source: Any) -> str:
    """Map the dropdown label or stored key to a stored source key."""
    text = str(source or "").strip()
    if text.lower() in config.UNIVERSE_SOURCES.values():
        return text.lower()
    for label, key in config.UNIVERSE_SOURCES.items():
        if label.strip().lower() == text.lower():
            return key
    raise ValueError(f"Unsupported universe source: {text!r}.")


def _aim_pxnum() -> int:
    """The pricing number sent with the AIM request.

    ``config.AIM_PXNUM`` is the frozen ``1377`` from ``RAG KB/25``, so the rule
    ("defaults to the frozen 1377") and the code say the same thing. A
    non-numeric override is refused rather than sent as a string: the block
    must fail closed, because a silently-wrong ``pxnum`` would price the book
    on a different curve and look like a valid answer.
    """
    configured = config.AIM_PXNUM
    try:
        return int(str(configured).strip())
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"AIM_PXNUM must be an integer pricing number, got {configured!r}; "
            "the AIM request was not built."
        ) from exc


def _aim_with_params(account: str) -> dict:
    """The frozen ``with_params`` block for one AIM account (``RAG KB/25``).

    ``accounts``, ``pxnum``, and ``profile`` stay on ``with_params``. They are
    never moved onto ``members()``, no dates are added, and ``ts_position()`` is
    not used. ``accounts`` is a list of exactly one code; the whole book is
    never sent as one list.
    """
    return {
        "accounts": [account],
        "pxnum": _aim_pxnum(),
        "profile": config.AIM_PROFILE,
    }


class _FrameItem:
    """One item's frame when the response exposed no named item.

    ``ArrowExecuteResponse`` on Desktop does not always answer ``.get(name)`` and
    does not always carry ``item.name`` (``RAG KB/07``, ``09``). ``RAG KB/07``
    documents ``bql.combined_df(response)`` as the last documented way to read
    that object, so the frame it produces is wrapped in the small interface
    ``_item_frame`` already expects: ``.df()`` and ``.name``.
    """

    def __init__(self, name: str, frame: pd.DataFrame):
        self.name = name
        self._frame = frame

    def df(self) -> pd.DataFrame:
        return self._frame.copy()


def _response_item_count(response: Any) -> int | None:
    """How many items the response exposes, or ``None`` when it says nothing.

    The distinction matters. ``0`` is the response itself stating it holds no
    item, which is an empty answer; ``None`` means this build will not say, so
    "no items" cannot be concluded and the caller keeps its diagnostic instead
    of turning an unreadable response into a silent zero-row table.
    """
    try:
        return int(len(response))
    except (TypeError, AttributeError, ValueError, OverflowError):
        return None


def _looks_like_response(response: Any) -> bool:
    """The cheap success test from ``RAG KB/07``.

    A Desktop ``ArrowExecuteResponse`` is a valid response even when it is not
    iterable, has no ``.get``, and exposes no item names. ``type(...).__name__``
    containing ``response`` is what the knowledge base offers as that test, and
    an error tuple or an exception is never a response.
    """
    if isinstance(response, (tuple, BaseException, pd.DataFrame)):
        return False
    return "response" in type(response).__name__.casefold()


def _response_item_name(item: Any) -> str | None:
    """The item's own name, whichever attribute the build exposes it on."""
    for attribute in ("name", "item_name"):
        value = getattr(item, attribute, None)
        if value:
            return str(value)
    inner = getattr(item, "item", None)
    value = getattr(inner, "name", None)
    return str(value) if value else None


def _response_names(response: Any) -> list[str]:
    """The item names this response exposes, for the failure message.

    Naming what did arrive is the difference between "Bloomberg returned nothing
    usable" and "the parser looked for the wrong name"; the operator cannot tell
    those apart from a bare "no item named" sentence.
    """
    names: list[str] = []
    for position in range(_response_item_count(response) or 0):
        try:
            item = response[position]
        except Exception:
            continue
        name = _response_item_name(item)
        if name:
            names.append(name)
    return names


def _combined_frame(response: Any) -> pd.DataFrame | None:
    """``bql.combined_df(response)`` when this BQL build exposes it.

    Returns ``None`` when the helper is missing or refuses the object, so the
    caller keeps its own diagnostic instead of replacing it with a guess.
    """
    helper = getattr(bql, "combined_df", None) if bql is not None else None
    if not callable(helper):
        return None
    try:
        combined = helper(response)
    except Exception:
        return None
    return combined if isinstance(combined, pd.DataFrame) else None


def _combined_item(response: Any, output_name: str) -> _FrameItem | None:
    """The single value column of ``combined_df(response)``, named as asked.

    A combined frame with several value columns is refused: choosing one of them
    would label one measure with another measure's numbers. A frame with no rows
    is still usable, and it is the honest reading of "the request matched
    nothing" instead of an error about item names.
    """
    combined = _combined_frame(response)
    if combined is None:
        return None
    frame = combined.copy()
    frame.columns = [str(column) for column in frame.columns]
    if output_name in frame.columns:
        return _FrameItem(output_name, frame)
    keys = {"ID", "DATE", "DATETIME"}
    values = [column for column in frame.columns if column.strip().upper() not in keys]
    if len(values) == 1:
        return _FrameItem(output_name, frame.rename(columns={values[0]: output_name}))
    if values and _parse_date_columns(values) is not None:
        # A wide date-column frame: one column per observation date. It is
        # returned as it is, and ``_normalize_frame`` folds it into
        # ID/DATE/<value>; renaming one date column here would be wrong.
        return _FrameItem(output_name, frame)
    return None


class EmptyResponseError(RuntimeError):
    """A response object that states it holds no item at all.

    This is not a naming problem. ``len(response) == 0`` on a valid response
    object is the response saying "nothing came back", which happens when the
    filtered universe matched no security: an index membership as of a date that
    is not published yet, or a window whose changes are all on the other side.
    The distinction matters because the two need different reactions — one is a
    data/universe fact, the other a parser defect — and the old code printed the
    same "no item named" sentence for both.
    """


def _response_item(response: Any, output_name: str) -> Any:
    """Return one item response; supports Arrow ``.get`` and index access."""
    getter = getattr(response, "get", None)
    if callable(getter):
        try:
            item = getter(output_name)
        except Exception:
            item = None
        if item is not None:
            return item

    count = _response_item_count(response)
    for index in range(count or 0):
        try:
            item = response[index]
        except Exception:
            continue
        if _response_item_name(item) == output_name:
            return item
    if count == 1:
        return response[0]
    names = _response_names(response)
    exposed = "not exposed" if count is None else f"{count} item(s) exposed"
    raise ValueError(
        f"BQL response has no item named {output_name!r} "
        f"(response type: {type(response).__name__}, {exposed}, names="
        f"{names if names else 'not exposed'})."
    )


def _find_value_column(frame: pd.DataFrame, candidates: tuple) -> str | None:
    columns = [column for column in frame.columns if column != "ID"]
    for candidate in candidates:
        if candidate is None:
            continue
        target = str(candidate).strip().lower()
        for column in columns:
            if column.strip().lower() == target:
                return column
    return None


def _parse_date_columns(columns: list[str]) -> pd.DatetimeIndex | None:
    """Return parsed date-column names, or None when they are not dates."""
    if not columns:
        return None
    if all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(column)) for column in columns):
        parsed = pd.to_datetime(pd.Index(columns), format="%Y-%m-%d", errors="coerce")
        return None if pd.isna(parsed).any() else parsed
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        parsed = pd.to_datetime(pd.Index(columns), errors="coerce")
    if pd.isna(parsed).any():
        return None
    return parsed


def _looks_like_security_ids(values: pd.Series) -> bool:
    """Reject row-number-like or date-like object indexes before promoting them."""
    sample = [str(value).strip() for value in values.head(50) if str(value).strip()]
    if not sample:
        return False
    for value in sample:
        if re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value):
            return False
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:[T ].*)?", value):
            return False
    return True


def _finalize_id(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    frame["ID"] = frame["ID"].astype("string").fillna("").str.strip()
    invalid = frame["ID"].str.lower().isin({"", "nan", "none", "nat"})
    dropped = int(invalid.sum())
    frame = frame.loc[~invalid].copy()
    if "DATE" in frame.columns:
        frame = frame.sort_values(["ID", "DATE"], kind="mergesort").reset_index(
            drop=True
        )
    frame.attrs["dropped_ids"] = dropped
    return frame


def _normalize_frame(
    raw: Any,
    output_name: str,
    item_name: str | None,
    allow_date_value: bool = False,
) -> pd.DataFrame:
    """Normalize one BQL item frame to ``ID`` (+ optional ``DATE``) + value.

    Supports the documented Desktop shapes: security-ID index, ``ID`` column,
    ``ID``/``DATE`` MultiIndex, ``DATE`` column, and a wide date-column series.
    A row-number index is rejected instead of becoming fake IDs.
    """
    if not isinstance(raw, pd.DataFrame):
        raise ValueError(f"{output_name}: item.df() did not return a DataFrame.")
    frame = raw.copy()
    frame.columns = [str(column) for column in frame.columns]
    index = frame.index

    id_column = next(
        (column for column in frame.columns if column.strip().upper() == "ID"),
        None,
    )
    if id_column is not None:
        if id_column != "ID":
            frame = frame.rename(columns={id_column: "ID"})
    else:
        if isinstance(index, pd.RangeIndex):
            raise ValueError(
                f"{output_name}: response has a row-number index and no ID "
                f"column; columns={list(frame.columns)}."
            )
        before = list(frame.columns)
        frame = frame.reset_index()
        frame.columns = [str(column) for column in frame.columns]
        index_columns = [column for column in frame.columns if column not in before]
        date_column = next(
            (
                column
                for column in index_columns
                if column.strip().upper() in {"DATE", "DATETIME"}
                or pd.api.types.is_datetime64_any_dtype(frame[column])
            ),
            None,
        )
        id_column = next(
            (
                column
                for column in index_columns
                if column.strip().upper() == "ID"
            ),
            None,
        )
        if id_column is None:
            candidates = [
                column
                for column in index_columns
                if column != date_column
                and (
                    pd.api.types.is_object_dtype(frame[column])
                    or pd.api.types.is_string_dtype(frame[column])
                )
                and _looks_like_security_ids(frame[column])
            ]
            if not candidates:
                raise ValueError(
                    f"{output_name}: response index is not a security-ID index; "
                    f"index levels={index_columns}, columns={list(frame.columns)}."
                )
            id_column = candidates[0]
        frame = frame.rename(columns={id_column: "ID"})
        if date_column is not None and date_column != "DATE":
            frame = frame.rename(columns={date_column: "DATE"})
        residual = [
            column
            for column in index_columns
            if column not in {id_column, date_column}
        ]
        if residual:
            raise ValueError(
                f"{output_name}: response has extra index levels {residual}; "
                "normalize them in the data adapter."
            )

    value_column = _find_value_column(
        frame, (output_name, item_name, "VALUE")
    )

    if value_column is None and "DATE" not in frame.columns:
        value_columns = [column for column in frame.columns if column != "ID"]
        parsed = _parse_date_columns(value_columns)
        if (
            len(value_columns) >= 1
            and parsed is not None
            and len(parsed) == len(value_columns)
        ):
            long = frame.melt(
                id_vars=["ID"],
                value_vars=value_columns,
                var_name="DATE",
                value_name=output_name,
            )
            long["DATE"] = pd.to_datetime(long["DATE"], errors="coerce")
            long = long.loc[long["DATE"].notna()].copy()
            long["DATE"] = long["DATE"].dt.normalize()
            return _finalize_id(long)

    if value_column is None:
        extras = [column for column in frame.columns if column != "ID"]
        non_date = [column for column in extras if column != "DATE"]
        if allow_date_value and "DATE" in frame.columns and not non_date:
            value_column = "DATE"
        elif len(non_date) == 1:
            value_column = non_date[0]
        elif len(extras) == 1:
            value_column = extras[0]
        else:
            raise ValueError(
                f"{output_name}: cannot identify the value column; "
                f"columns={list(frame.columns)}."
            )

    keep = ["ID"]
    if "DATE" in frame.columns and value_column != "DATE":
        keep.append("DATE")
    if value_column != output_name:
        frame[output_name] = frame[value_column]
    keep.append(output_name)
    frame = frame.loc[:, keep].copy()
    if "DATE" in frame.columns:
        frame["DATE"] = pd.to_datetime(frame["DATE"], errors="coerce")
        frame = frame.loc[frame["DATE"].notna()].copy()
        frame["DATE"] = frame["DATE"].dt.normalize()
    return _finalize_id(frame)


def _item_frame(
    response: Any, output_name: str, allow_date_value: bool = False
) -> pd.DataFrame:
    """One item of the response as a normalized frame.

    Lookup order follows ``RAG KB/07``: ``.get(name)``, then index access with a
    name match, then, for a response that exposes neither, the documented
    ``bql.combined_df(response)`` fallback. Without that third step a valid
    Desktop ``ArrowExecuteResponse`` is reported as "no item named ...", which
    reads as a rejected request when the request actually answered.
    """
    try:
        item = _response_item(response, output_name)
    except ValueError:
        item = _combined_item(response, output_name)
        if item is None:
            if _looks_like_response(response) and _response_item_count(response) == 0:
                # The response itself says it holds nothing. Reported as an
                # empty answer by the caller, never as a misspelt item.
                raise EmptyResponseError(
                    f"the response carried no item at all for {output_name!r} "
                    f"(response type: {type(response).__name__})"
                ) from None
            raise
    df_method = getattr(item, "df", None)
    if not callable(df_method):
        raise ValueError(f"BQL item {output_name!r} does not expose df().")
    return _normalize_frame(
        df_method(),
        output_name,
        getattr(item, "name", None),
        allow_date_value=allow_date_value,
    )


def _request_frame(
    bq: Any,
    bql_module: Any,
    universe: Any,
    output_name: str,
    item: Any,
    result: FetchResult,
    label: str,
    allow_date_value: bool = False,
    with_params: dict | None = None,
) -> pd.DataFrame:
    def build_request():
        if with_params is None:
            return bql_module.Request(universe, {output_name: item})
        return bql_module.Request(universe, {output_name: item}, with_params=with_params)

    started = time.perf_counter()
    response, attempts = _execute_attempts(
        bq, build_request, label, result.errors, result.notes
    )
    elapsed = time.perf_counter() - started
    entry: dict[str, Any] = {
        "label": label,
        "elapsed_sec": round(elapsed, 3),
        # How many times the same request was sent. A retry that answers is a
        # different fact from a single slow answer, and the log has to show it.
        "attempts": attempts,
        "rows": "parse-failed",
        "columns": "",
    }
    result.request_log.append(entry)
    if response is None:
        # The failures are already in ``result.errors`` with their exception
        # text; this only says there is nothing to parse, so the caller's own
        # handler can turn it into a per-field FAILED status.
        entry["columns"] = f"no response after {attempts} attempt(s)"
        raise RuntimeError(
            f"{label}: no response after {attempts} attempt(s)."
        )
    try:
        frame = _item_frame(response, output_name, allow_date_value=allow_date_value)
    except EmptyResponseError as exc:
        # A valid response holding no item is an empty answer, not a refused
        # field. It is recorded as 0 rows so the run continues and the reason is
        # on the record; nothing is invented and no fallback field is used.
        entry["rows"] = 0
        entry["columns"] = f"empty response: {exc}"
        result.notes.append(
            f"{label}: {exc}. The request completed and this window returned no "
            "row for it; this is not a rejected data item."
        )
        frame = pd.DataFrame(columns=["ID", output_name])
        frame.attrs["dropped_ids"] = 0
        return frame
    except Exception as exc:
        entry["columns"] = f"{type(exc).__name__}: {exc}"
        raise
    entry["rows"] = int(len(frame))
    entry["columns"] = ", ".join(str(column) for column in frame.columns)
    dropped = int(frame.attrs.get("dropped_ids", 0))
    if dropped:
        result.notes.append(f"{label}: excluded {dropped} row(s) without a usable ID.")
    return frame


def _change_frame(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    if "Change" not in out.columns:
        value_columns = [column for column in out.columns if column not in {"ID", "DATE"}]
        if not value_columns:
            # No value column at all: nothing came back for this direction. An
            # empty ID/Change frame reads as "0 rows" and is logged as such,
            # where a column error would read as a broken field.
            return pd.DataFrame(columns=["ID", "Change"])
        if len(value_columns) != 1:
            raise ValueError(
                "Ranking response must contain one value column; "
                f"columns={list(out.columns)}."
            )
        out = out.rename(columns={value_columns[0]: "Change"})
    return out.loc[:, ["ID", "Change"]].copy()


def _parse_response(
    response: Any,
    label: str,
    item_names: tuple[str, ...],
    errors: list[str],
    notes: list[str],
) -> pd.DataFrame:
    """Parse one multi-item response into ``ID`` + one column per item.

    Every frame is deduplicated on ``ID``, **including the first**. A dated
    response carries ``ID`` + ``DATE`` and therefore one row per observation per
    bond, so the same ID can legitimately appear twice; merging such a frame
    ``one_to_one`` raises ``MergeError``, and a raise here would abandon the
    whole Update after the ranking had already succeeded. Keeping the last row
    per ID matches what the descriptor path already does.
    """
    frames: list[pd.DataFrame] = []
    missing: list[str] = []
    for output_name in item_names:
        try:
            frame = _item_frame(response, output_name)
        except Exception as exc:
            missing.append(output_name)
            notes.append(
                f"{label}: {output_name} did not parse ({type(exc).__name__}: {exc})."
            )
            continue
        keep = frame.loc[:, ["ID", output_name]].copy()
        if keep["ID"].duplicated().any():
            dupes = int(keep["ID"].duplicated().sum())
            notes.append(
                f"{label}: {output_name} returned {dupes} duplicate ID row(s); "
                "kept the last value per ID."
            )
            keep = keep.drop_duplicates("ID", keep="last")
        frames.append(keep)
    if not frames:
        errors.append(f"{label}: no item in the response parsed.")
        return pd.DataFrame(columns=["ID", *item_names])
    merged = frames[0]
    for frame in frames[1:]:
        try:
            merged = merged.merge(frame, on="ID", how="outer", validate="one_to_one")
        except Exception as exc:
            # A merge failure loses this item, not the run. The caller turns the
            # absent column into a per-field FAILED status, which the app already
            # knows how to display and refuses to cache.
            errors.append(
                f"{label}: {frame.columns[-1]} could not be merged on ID "
                f"({type(exc).__name__}: {exc})."
            )
            merged = merged.merge(frame, on="ID", how="outer")
    return merged.sort_values("ID", kind="mergesort").reset_index(drop=True)


def _duration_items(bq: Any) -> dict[str, Any]:
    """The four duration measures from one builder, in declared order.

    ``None`` is the bare ``duration()`` call; the other three are parameter
    values on the same builder. All four ride in the request that already
    existed for ``Duration``, so the family adds no request of its own.
    """
    items: dict[str, Any] = {}
    for label, measure in config.DURATION_FIELDS:
        items[label] = (
            bq.data.duration() if measure is None else bq.data.duration(duration_type=measure)
        )
    return items


def _merge_duration_family(
    result: "FetchResult",
    duration_frame: pd.DataFrame | None,
) -> None:
    """Fold the duration family into ``result.descriptors`` on ``ID``.

    A missing column is left absent rather than filled, so the ranked table
    prints ``(unavailable)`` for that measure instead of a fabricated number.
    The merge is ``left`` from the descriptor table's side when one exists, so
    a duration row can never invent a bond that the descriptors never saw.
    """
    if duration_frame is None or duration_frame.empty:
        return
    extra = [column for column in duration_frame.columns if column != "ID"]
    if not extra:
        return
    if result.descriptors is None or result.descriptors.empty:
        result.descriptors = duration_frame.copy()
        return
    if "ID" not in result.descriptors.columns:
        result.notes.append(
            "Duration measures arrived but the descriptor table has no ID "
            "column; they were not attached."
        )
        return
    collisions = [
        column for column in extra if column in result.descriptors.columns
    ]
    if collisions:
        # ``Duration`` is already a descriptor; the three extra measures are
        # distinct names, so a collision means a wiring mistake, not a merge
        # detail. Refuse rather than overwrite a column with the same name.
        result.notes.append(
            f"Duration measures collided with existing columns {collisions}; "
            "the existing columns were kept."
        )
        extra = [column for column in extra if column not in collisions]
        if not extra:
            return
    keep = duration_frame.loc[:, ["ID", *extra]]
    try:
        result.descriptors = result.descriptors.merge(
            keep, on="ID", how="left", validate="one_to_one"
        )
    except Exception as exc:
        result.notes.append(
            f"Duration measures could not be merged into the descriptor table: "
            f"{type(exc).__name__}: {exc}"
        )


def _fetch_duration_family(
    bq: Any,
    bql_module: Any,
    duration_universe: Any,
    result: "FetchResult",
) -> None:
    """The duration measure family: one Request, four items, no extra request.

    This costs what the app already spent. ``Duration`` used to be its own
    single-item descriptor Request; the family replaces that request rather than
    sitting beside it, so the Update sends the same number of ``bq.execute``
    calls it did before the three extra measures were asked for.

    A failure here never discards the ranked rows: the measures stay absent and
    the step log names them, so a spread ranking is still readable without them.
    """
    label = "Duration measures"
    try:
        items = _duration_items(bq)
    except Exception as exc:
        result.field_status[label] = f"FAILED: {type(exc).__name__}: {exc}"
        result.notes.append(
            f"{label} request was not built; their columns stay (unavailable)."
        )
        return
    started = time.perf_counter()
    response, attempts = _execute_attempts(
        bq,
        lambda: bql_module.Request(duration_universe, items),
        label,
        result.errors,
        result.notes,
    )
    elapsed = time.perf_counter() - started
    if response is None:
        result.request_log.append(
            {
                "label": label,
                "elapsed_sec": round(elapsed, 3),
                "attempts": attempts,
                "rows": "failed",
                "columns": f"no response after {attempts} attempt(s)",
            }
        )
        result.field_status[label] = (
            f"FAILED: no response after {attempts} attempt(s)"
        )
        result.notes.append(
            f"{label} request failed; their columns stay (unavailable)."
        )
        return
    names = tuple(names for names, _measure in config.DURATION_FIELDS)
    frame = _parse_response(response, label, names, result.errors, result.notes)
    result.request_log.append(
        {
            "label": label,
            "elapsed_sec": round(elapsed, 3),
            "attempts": attempts,
            "rows": int(len(frame)),
            "columns": ", ".join(str(column) for column in frame.columns),
        }
    )
    for name in names:
        if name in frame.columns:
            non_null = int(frame[name].notna().sum())
            result.field_status[name] = f"returned {len(frame)} row(s), {non_null} non-null"
        else:
            result.field_status[name] = "FAILED: column absent from the response"
    if not frame.empty:
        numeric = {name: pd.to_numeric(frame[name], errors="coerce") for name in names if name in frame.columns}
        _note_duplicate_duration(numeric, label, result.notes)
    _merge_duration_family(result, frame)


def _note_duplicate_duration(
    numeric: dict[str, pd.Series], label: str, notes: list[str]
) -> None:
    """Name a pair of duration columns that carry the same number everywhere.

    ``RAG KB/28`` records the failure mode: one builder with four parameter
    values can silently ignore the parameter and return one measure under
    several names. Nothing raises, so the only defence is comparing the columns
    and saying so.
    """
    names = list(numeric)
    for index, left in enumerate(names):
        for right in names[index + 1:]:
            both = numeric[left].notna() & numeric[right].notna()
            if int(both.sum()) < 2:
                continue
            if numeric[left][both].round(10).equals(numeric[right][both].round(10)):
                notes.append(
                    f"{label}: {left} and {right} hold identical values on every "
                    "row that carries both; one measure may be duplicated."
                )


def _descriptor_fields() -> tuple:
    """Descriptor list for every universe source.

    All four paths use the same confirmed descriptor list. Neither the AIM path
    nor the Bond path adds a security-type or cash classifier: those are
    separate data items and would need the ``RAG KB/23`` review before they are
    requested on a bond book.
    """
    return tuple(config.DESCRIPTOR_FIELDS)


def _fetch_descriptors(
    bq: Any,
    bql_module: Any,
    descriptor_universe: Any,
    result: FetchResult,
    fields: tuple | None = None,
) -> None:
    frames: dict[str, pd.DataFrame] = {}
    for label, item_name in fields if fields is not None else config.DESCRIPTOR_FIELDS:
        try:
            item = getattr(bq.data, item_name)()
            frame = _request_frame(
                bq,
                bql_module,
                descriptor_universe,
                label,
                item,
                result,
                f"Descriptor {label}",
                allow_date_value=(item_name == "maturity"),
            )
            non_null = int(frame[label].notna().sum())
            result.field_status[label] = (
                f"returned {len(frame)} row(s), {non_null} non-null; "
                f"columns={list(frame.columns)}"
            )
            if non_null == 0:
                # An all-null column is evidence about the data, not about the
                # spelling: the request arrived and every value was empty. It
                # must not read as a clean success, because the table then shows
                # ``(blank)`` for every row and cannot be told apart from a
                # field Bloomberg genuinely left blank.
                #
                # One row is the exception. On the Bond path a single security
                # with no duration is a per-bond data gap, not evidence that
                # the field is broken, so it is noted and the status is left
                # alone. Two or more all-null rows is the field failing.
                result.notes.append(
                    f"{label} returned {len(frame)} row(s) with no value; "
                    "check the field on this universe."
                )
                if len(frame) > 1:
                    result.field_status[label] = (
                        f"FAILED: all values null; returned {len(frame)} row(s), "
                        f"columns={list(frame.columns)}"
                    )
            frames[label] = frame.loc[:, ["ID", label]].copy()
        except Exception as exc:  # one field never hides the others
            result.field_status[label] = f"FAILED: {type(exc).__name__}: {exc}"
            result.notes.append(
                f"{label} descriptor request failed; the column is left blank."
            )

    if not frames:
        return
    merged: pd.DataFrame | None = None
    for label, frame in frames.items():
        if frame["ID"].duplicated().any():
            duplicates = int(frame["ID"].duplicated().sum())
            result.notes.append(
                f"{label}: {duplicates} duplicate ID row(s); kept the last value."
            )
            frame = frame.drop_duplicates("ID", keep="last")
        if merged is None:
            merged = frame
            continue
        try:
            merged = merged.merge(frame, on="ID", how="outer", validate="one_to_one")
        except Exception as exc:
            result.notes.append(
                f"{label} could not be merged into the descriptor table: "
                f"{type(exc).__name__}: {exc}"
            )
    if merged is not None:
        result.descriptors = merged.sort_values("ID", kind="mergesort").reset_index(
            drop=True
        )


def _fetch_series(
    bq: Any,
    bql_module: Any,
    descriptor_universe: Any,
    spread_code: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    result: FetchResult,
) -> None:
    label = "Spread Series"
    try:
        # Build a fresh dated item for the bounded candidate universe; do not
        # reuse the expression that already went through net_chg()/groupsort().
        series_item = bq.data.spread(
            spread_type=spread_code,
            dates=bq.func.range(
                start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")
            ),
        )
        frame = _request_frame(
            bq,
            bql_module,
            descriptor_universe,
            "Spread",
            series_item,
            result,
            label,
        )
    except Exception as exc:
        result.field_status[label] = f"FAILED: {type(exc).__name__}: {exc}"
        result.notes.append(
            "Spread-series validation request failed; effective dates and the "
            "first/last spread check are unavailable."
        )
        return

    missing = sorted({"ID", "DATE", "Spread"} - set(frame.columns))
    if missing:
        result.field_status[label] = (
            f"FAILED: missing columns {missing}; columns={list(frame.columns)}"
        )
        result.notes.append(
            "Spread-series validation frame did not contain ID/DATE/Spread; "
            "effective dates were not checked."
        )
        return

    frame = frame.loc[:, ["ID", "DATE", "Spread"]].copy()
    frame["Spread"] = pd.to_numeric(frame["Spread"], errors="coerce")
    frame = frame.loc[frame["Spread"].notna()].copy()
    if frame.empty:
        result.field_status[label] = "FAILED: no usable spread observation."
        return
    result.series = frame
    result.field_status[label] = (
        f"returned {len(frame)} observation(s) across "
        f"{int(frame['ID'].nunique())} ID(s)."
    )


def _validated_window(
    spread_type: Any, start_date: Any, end_date: Any
) -> tuple[pd.Timestamp, pd.Timestamp, str]:
    """Validate the spread choice and the date window. Raises ``ValueError``."""
    start = _as_date(start_date, "start date")
    end = _as_date(end_date, "end date")
    if start >= end:
        raise ValueError("Start date must be earlier than end date.")
    code = config.SPREAD_TYPES.get(spread_type)
    if code is None and spread_type in config.SPREAD_TYPES.values():
        code = spread_type
    if code is None:
        raise ValueError(f"Unsupported spread type: {spread_type!r}.")
    today = pd.Timestamp(date.today()).normalize()
    if end > today:
        raise ValueError("End date cannot be in the future.")
    if (end - start).days > config.MAX_RANGE_DAYS:
        raise ValueError(
            f"Date window is {(end - start).days} days; the validation "
            f"build is capped at {config.MAX_RANGE_DAYS} days."
        )
    return start, end, code


def _build_universe(
    bq: Any, source_key: str, universe_key: str, end: pd.Timestamp
) -> tuple[Any, dict | None]:
    """Return ``(universe_expression, with_params)`` for one source.

    ``index`` uses ``members(index, dates=end_date)``, ``aim`` uses
    ``members(type="AIM")`` plus the frozen account block on the ranking
    request, and ``bond`` uses ``univ.list([one ticker])``. Only the AIM path
    carries ``with_params``; the block stays off ``members()`` and off the
    descriptor/series requests, which run on an explicit ID list.
    """
    if source_key == "aim":
        return bq.univ.members(type="AIM"), _aim_with_params(universe_key)
    if source_key == "bond":
        return bq.univ.list([universe_key]), None
    return bq.univ.members(universe_key, dates=end.strftime("%Y-%m-%d")), None


def _rank_movers(
    bq: Any,
    bql_module: Any,
    universe: Any,
    with_params: dict | None,
    spread_change: Any,
    result: FetchResult,
    label: str = "",
) -> None:
    """Two ranking requests (top increases, top decreases) on one universe."""
    prefix = f"{label} " if label else ""
    for direction, positive, order in (
        ("increases", True, "desc"),
        ("decreases", False, "asc"),
    ):
        try:
            condition = spread_change > 0 if positive else spread_change < 0
            ranked_universe = universe.filter(condition).filter(
                spread_change.grouprank(order=order) <= config.TOP_N
            )
            frame = _request_frame(
                bq,
                bql_module,
                ranked_universe,
                "Spread Change",
                spread_change.groupsort(),
                result,
                f"{prefix}{direction.title()} ranking",
                with_params=with_params,
            )
            if frame.empty:
                # A successful request that matched nothing is not a parse
                # failure. Saying so here keeps the operator from reading a
                # narrow window or a quiet week as a broken field.
                result.notes.append(
                    f"{prefix}{direction.title()} ranking returned 0 row(s): no "
                    "security on this universe had that direction of change in "
                    "the window."
                )
            setattr(result, direction, _change_frame(frame))
        except Exception as exc:
            reason = _explain_ranking_error(exc, with_params)
            suffix = f" {reason}" if reason else ""
            result.errors.append(
                f"{prefix}{direction.title()} request failed: "
                f"{type(exc).__name__}: {exc}{suffix}"
            )


def _explain_ranking_error(exc: BaseException, with_params: dict | None) -> str:
    """One clause naming what a ranking failure was, when the message says it.

    Two failures look identical on screen and are not: a query that ran and
    matched nothing, and a query BQL refused before evaluating it. The AIM run on
    2026-11-02 returned the second — `BQLInternalExecutionError` saying
    "Predicate must be a Boolean expression" inside
    `FILTER(MEMBERS(type='AIM'), ...)` — and the app reported it as "the account
    returned no ranked holding", which is a claim about the book made from a
    request that never ran. That wording is now impossible, and this helper adds
    the reason in the operator's words.

    A refusal on a filtered universe is named as a universe-compatibility
    finding, not a data finding, because that is what the evidence supports: the
    same expression works on `members(index, dates=...)` and on
    `univ.list`, and the account block is the only difference here.
    """
    text = f"{exc}"
    lowed = text.casefold()
    if "predicate" in lowed and "boolean" in lowed:
        where = (
            "the AIM account universe"
            if with_params is not None
            else "this universe"
        )
        return (
            f"[BQL refused the filter expression on {where} before evaluating "
            "it: the change expression did not present as a Boolean predicate "
            "there. This is a universe-compatibility finding (RAG KB 23 G4), not "
            "evidence about holdings or about a data item's spelling. Do not "
            "retry it unchanged.]"
        )
    if "bqlinternalexecutionerror" in lowed:
        return (
            "[BQL reported an internal execution error while processing this "
            "request. That is a query-shape problem, not an empty universe; the "
            "rows were never evaluated.]"
        )
    return ""


def _candidate_ids(result: FetchResult) -> list[str]:
    """Every ranked ID, deduplicated, in ranking order.

    The bound is already enforced by the ranking request: ``grouprank`` caps
    each (book, direction) at ``TOP_N`` rows, so the union is at most
    ``2 * TOP_N`` in a one-book run and ``4 * TOP_N`` in a two-book run. Do
    NOT slice positionally here. The comparison frames are stacked book by
    book, so ``[:TOP_N]`` kept only the first book and silently dropped the
    second book's candidates: their descriptor rows never existed, which then
    rendered as ``(blank)`` instead of ``(unavailable)`` and made "we did not
    ask" read as "Bloomberg returned nothing".
    """
    ids: list[str] = []
    for frame in (result.increases, result.decreases):
        if frame is None or frame.empty or "ID" not in frame.columns:
            continue
        ids.extend(frame["ID"].astype("string").fillna("").str.strip().tolist())
    return list(dict.fromkeys(value for value in ids if value))


def _validate_candidates(
    bq: Any,
    bql_module: Any,
    candidate_ids: list[str],
    code: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    result: FetchResult,
) -> None:
    """Descriptor set, duration measures, and the series request on one ID list.

    The three requests share one bounded ``bq.univ.list`` universe. There is no
    per-source behaviour here: the same three requests are spent on every
    universe source, which is why no ``source_key`` parameter is accepted. It
    used to take one and never read it, so a future per-source guard wired to
    that name would have done nothing.
    """
    try:
        descriptor_universe = bq.univ.list(candidate_ids)
    except Exception as exc:
        result.errors.append(
            f"Could not build the descriptor universe: {type(exc).__name__}: {exc}"
        )
        return

    _fetch_descriptors(
        bq,
        bql_module,
        descriptor_universe,
        result,
        _descriptor_fields(),
    )
    _fetch_duration_family(bq, bql_module, descriptor_universe, result)
    _fetch_series(bq, bql_module, descriptor_universe, code, start, end, result)


def fetch_movers(
    spread_type: str,
    start_date: Any,
    end_date: Any,
    index: Any = None,
    source: Any = None,
) -> FetchResult:
    """Run the validation request and return ranked candidates plus diagnostics.

    ``source`` is the universe source: ``"Index"`` / ``"index"`` (the default),
    ``"AIM account"`` / ``"aim"``, or ``"Bond"`` / ``"bond"``. ``index`` is
    then the typed index ticker, AIM account code, or bond ticker. It is
    required on every path: when it is empty the result carries an
    invalid-input error and no request is built, so a missing universe can
    never fall back to a default.

    The three sources spend the same spread ranking. Only the universe
    constructor differs: index members as of the end date, the AIM book for one
    account with the frozen ``with_params`` block, or one explicit bond.
    Rankings stay change-based for all three: the AIM holding size and the bond
    universe are not used to widen, narrow, or re-weight the lists.

    ``AIM vs Index`` needs two values and is refused here; it has its own entry
    point, ``fetch_comparison()``.
    """
    result = FetchResult()
    try:
        bql_module = _require_bql()
    except RuntimeError as exc:
        return FetchResult(errors=[str(exc)])

    try:
        source_key, universe_key = normalize_universe(
            config.DEFAULT_UNIVERSE_SOURCE if source is None else source, index
        )
        start, end, code = _validated_window(spread_type, start_date, end_date)
    except (TypeError, ValueError) as exc:
        return FetchResult(errors=[f"Invalid input: {exc}"])

    result.universe = universe_key
    result.source = source_key

    try:
        bq = bql_module.Service()
        universe, universe_params = _build_universe(bq, source_key, universe_key, end)
        spread_item = bq.data.spread(
            spread_type=code,
            dates=bq.func.range(
                start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")
            ),
        )
        spread_change = spread_item.net_chg()
    except Exception as exc:
        return FetchResult(
            errors=[f"Could not build the BQL request: {type(exc).__name__}: {exc}"]
        )

    _rank_movers(bq, bql_module, universe, universe_params, spread_change, result)

    candidate_ids = _candidate_ids(result)
    if not candidate_ids:
        result.notes.append(
            "No ranked IDs were returned; descriptor and series validation "
            "requests were not sent."
        )
        _note_empty_universe(result, source_key, universe_key, end, start=start)
        return result

    _validate_candidates(bq, bql_module, candidate_ids, code, start, end, result)
    return result


def _previous_business_day(day: Any) -> pd.Timestamp:
    """The last weekday on or before ``day``.

    A weekday loop, not ``numpy.busday_offset``: that call raises on a Saturday
    or Sunday unless a roll is given, and rolling is exactly the decision being
    made here, so it is written out instead of configured. Nothing here can
    throw on any calendar date.
    """
    stamp = pd.Timestamp(day).normalize()
    while stamp.weekday() >= 5:
        stamp -= pd.Timedelta(days=1)
    return stamp


def _note_empty_universe(
    result: FetchResult,
    source_key: str,
    universe_key: str,
    end: pd.Timestamp,
    start: pd.Timestamp | None = None,
) -> None:
    """Say why an empty ranking is most likely empty, when that is knowable.

    An index membership keyed on the *end* date is the one input here that can
    legitimately resolve to zero members, and picking today as the end date is
    the way an operator reaches it: the membership file for a day that has not
    been published yet can come back empty, and then every filter on it matches
    nothing. That produces a completed request with no rows, which used to be
    reported as a misspelt item. Naming the likely cause and the one thing to
    change is the difference between a dead end and a next step.

    A run that *failed* is not an empty run. When ``result.errors`` is not empty
    the request was refused, and saying "this account returned no holding" would
    invent an answer about the book from a response that never described it.
    That is the one thing this function must never do, so errors win first.
    """
    if result.errors:
        result.notes.append(
            f"Universe {universe_key} was not ranked because its ranking request "
            "failed; nothing here is evidence about what the book holds. Read the "
            "error above before changing the account, the ticker, or the window."
        )
        return
    if source_key == "index" and start is not None:
        today = pd.Timestamp(date.today()).normalize()
        # The membership key is the end date, and `RAG KB 28` records that
        # `members(dates=)` follows the rebalance boundary and that a projected
        # date returns its set only after the membership publication. So a
        # non-business end date and a date whose file has not been published yet
        # both resolve to a cohort BQL cannot match, and the ranking completes
        # with no item at all — which is the screen the operator reports as "no
        # item for 'Spread Change'". Both are named here, cheapest first: a
        # weekend is a fact about the calendar and needs no knowledge of
        # Bloomberg's publication schedule.
        if end.weekday() >= 5:
            suggested = _previous_business_day(end)
            result.notes.append(
                f"End date {end.date()} is a {end.day_name()}, which is not a "
                "business day. The universe is index membership keyed on that "
                "date, and `RAG KB 28` records that `members(dates=)` follows the "
                "rebalance boundary rather than the literal calendar day, so a "
                "non-business anchor does not resolve to a cohort the ranking can "
                "match. Use the last business day on or before "
                f"{end.date()} ({suggested.date()}) as the end date and press "
                "Update. This is a date-anchor problem: no field is at fault and "
                "nothing needs to be rebuilt."
            )
            return
        if end >= today:
            suggested = _previous_business_day(today - pd.Timedelta(days=1))
            result.notes.append(
                f"End date {end.date()} is today or later, and the universe is "
                "index membership keyed on that date. Today's membership and "
                "today's spread are both still moving, so this window is not "
                f"final. Use {suggested.date()} as the end date and press Update; "
                "the request itself completed, so nothing needs to be rebuilt."
            )
            return
    if source_key == "aim":
        result.notes.append(
            f"AIM account {universe_key} returned no ranked holding. Check the "
            "account code and whether the book holds spread-bearing lines; cash "
            "and equity holdings carry no spread and never rank."
        )
        return
    if source_key == "bond":
        result.notes.append(
            f"Bond {universe_key} returned no ranked row. Confirm the ticker on "
            "Terminal first: a private one-security universe that matches nothing "
            "produces no row at all, and one bond with no change in the window "
            "produces the same screen. Try the last completed business day as the "
            "end date before changing the ticker."
        )
        return
    result.notes.append(
        f"Universe {universe_key} completed the request with no ranked row. "
        "That is an empty answer for this window, not a rejected field: widen "
        "the window or check the universe for the end date before re-running."
    )


def fetch_comparison(
    spread_type: str,
    start_date: Any,
    end_date: Any,
    index: Any = None,
    aim: Any = None,
) -> FetchResult:
    """Rank the same spread on an index AND an AIM account, then compare them.

    Both fields are required and both are validated before any request is
    built, so a blank side is a refusal rather than a one-book run that would
    read as a comparison. The two frozen request shapes are spent sequentially
    (Desktop allows at most two concurrent workloads), each side keeps its own
    ``with_params``, and every ranked row is labelled with its book in
    ``config.UNIVERSE_COLUMN``.

    The descriptor and series validation runs ONCE on the union of both
    candidate lists, so a bond that sits in both books is described once and
    still appears as two rows: identity in this mode is (book, ID), not ID.
    """
    result = FetchResult()
    try:
        bql_module = _require_bql()
    except RuntimeError as exc:
        return FetchResult(errors=[str(exc)])

    try:
        (index_side, aim_side) = normalize_comparison(index, aim)
        start, end, code = _validated_window(spread_type, start_date, end_date)
    except (TypeError, ValueError) as exc:
        return FetchResult(errors=[f"Invalid input: {exc}"])

    result.source = config.COMPARISON_SOURCE
    result.comparison = True
    result.universe = (
        f"{index_side[1]} vs {aim_side[1]}"
    )

    try:
        bq = bql_module.Service()
        spread_item = bq.data.spread(
            spread_type=code,
            dates=bq.func.range(
                start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")
            ),
        )
        spread_change = spread_item.net_chg()
    except Exception as exc:
        return FetchResult(
            errors=[f"Could not build the BQL request: {type(exc).__name__}: {exc}"]
        )

    sides = []
    for source_key, universe_key in (index_side, aim_side):
        label = config.COMPARISON_LABELS.get(source_key, source_key.title())
        side = FetchResult(source=source_key, universe=universe_key)
        try:
            universe, universe_params = _build_universe(
                bq, source_key, universe_key, end
            )
        except Exception as exc:
            side.errors.append(
                f"{label} universe could not be built: "
                f"{type(exc).__name__}: {exc}"
            )
            sides.append((label, side))
            continue
        _rank_movers(
            bq, bql_module, universe, universe_params, spread_change, side, label
        )
        sides.append((label, side))

    for label, side in sides:
        result.errors.extend(side.errors)
        result.request_log.extend(side.request_log)
        # Both books are labelled, so no row can be read as belonging to the
        # other book after the two frames are stacked.
        result.increases = pd.concat(
            [
                result.increases,
                _label_universe(side.increases, label),
            ],
            ignore_index=True,
        )
        result.decreases = pd.concat(
            [
                result.decreases,
                _label_universe(side.decreases, label),
            ],
            ignore_index=True,
        )

    candidate_ids = _candidate_ids(result)
    if not candidate_ids:
        result.notes.append(
            "No ranked IDs were returned from either book; descriptor and "
            "series validation requests were not sent."
        )
        return result

    _validate_candidates(bq, bql_module, candidate_ids, code, start, end, result)
    return result


def _label_universe(frame: pd.DataFrame, label: str) -> pd.DataFrame:
    """Add the book column to one ranked side, keeping ``ID`` as the key."""
    out = frame.copy()
    out[config.UNIVERSE_COLUMN] = label
    return out
