"""Operator settings for FI Spread Movement Monitoring.

Provenance: the operator confirmed the universe, the OAS/Z/I spread choices,
custom start/end dates, and the descriptor list on 2026-10-23 and again in
chat on 2026-10-24. The confirmation is recorded in ``RAG KB/29`` and
``.cursor/rules/project-fi-spread-movement-monitoring.mdc``.

On 2026-10-31 the operator asked for a Universe Source choice: either a typed
Bloomberg index ticker, or an AIM account code whose holdings become the
universe. Both paths spend the same OAS/Z/I ranking and descriptor logic; only
the universe constructor differs.

On 2026-11-01 the operator added two more sources: ``AIM vs Index``, which
enters an AIM code and an index ticker at the same time and ranks both books in
one Update, and ``Bond``, which takes one typed bond ticker for targeted
analysis. See ``DECISION_RECORD.md`` DR-14 and DR-15.

``DEFAULT_INDEX`` is the recorded confirmation and the example ticker. The app
does not pre-fill it: the input starts empty and the operator types the
universe on every launch, so a stale value is never used by accident.

This build has not been compared against Terminal, so the units and the field
semantics are still unverified; review the returned values in Terminal.
"""

TOP_N = 10

# Each of the two ranked panels carries a "Display Top" box and a Refresh
# button above its chart. The box is a *view* control: it decides how many of
# the rows already in memory are drawn, and never builds a request. The last
# run asked Bloomberg for at most ``TOP_N`` rows per direction per book, so a
# larger number cannot invent rows — it is truncated with a visible note
# instead of being clamped silently. ``DISPLAY_TOP_MAX`` bounds the box so a
# typo cannot ask the page to draw a wall of rows; it is deliberately wider
# than ``TOP_N`` so the control needs no code change if the ranking breadth is
# ever reviewed upward.
DISPLAY_TOP_LABEL = "Display Top"
DISPLAY_TOP_REFRESH_LABEL = "Refresh"
DEFAULT_DISPLAY_TOP = TOP_N
DISPLAY_TOP_MAX = 50

# Recorded confirmation / example only. Never applied implicitly; see the
# module docstring. The input widget starts empty.
DEFAULT_INDEX = "LEGATRUU Index"

# The ways to name the universe. The dropdown label is the operator's, the
# stored key is what data.py switches on. Order is the dropdown order, with the
# single-universe choices first and the two-input comparison last but one.
UNIVERSE_SOURCES = {
    "Index": "index",
    "AIM account": "aim",
    "AIM vs Index": "aim_vs_index",
    "Bond": "bond",
}
DEFAULT_UNIVERSE_SOURCE = "Index"

# The source that runs two universes in one Update. It is the only source that
# needs both a typed index ticker and a typed AIM code.
COMPARISON_SOURCE = "aim_vs_index"
COMPARISON_LABELS = {"index": "Index", "aim": "AIM"}
# One source for the comparison wording and its book order. The heading, the
# chart title, the diverging chart's rows, and the Top 10 tables all read this,
# so "AIM vs Index" and "AIM above Index" are changed in exactly one place.
COMPARISON_TITLE = "AIM vs Index comparison"
COMPARISON_BOOK_ORDER = ("AIM", "Index")
# The column that keeps the two books apart. A bond can be a member of the
# index and a holding of the account at the same time, so in comparison mode a
# row identity is (Universe, ID) and not the ID alone.
UNIVERSE_COLUMN = "Universe"

# A descriptor label has to say which of the two things happened: the request
# failed or never covered that bond (``(unavailable)``), or Bloomberg returned
# an empty value for it (``(blank)``). Collapsing the two makes a request that
# was never sent read as a bridge answer.
DESCRIPTOR_UNAVAILABLE = "(unavailable)"
DESCRIPTOR_BLANK = "(blank)"
# Only these descriptor columns are free text. A numeric or date descriptor is
# left as NaN so its bucket stays Missing instead of turning the column into
# strings and silently changing every downstream comparison.
TEXT_DIMENSIONS = ("Country", "Sector", "Currency", "Rating")

# The Index field is a free-text Bloomberg index ticker. A bare ticker without
# the "Index" asset-class token is rejected instead of being silently resolved
# to an equity, because that would rank a different universe.
INDEX_REQUIRED_SUFFIX = "Index"

# A bond ticker is a single security, so a comma-separated list would silently
# widen the universe past the one bond the operator asked to inspect. It is
# refused instead of being split or truncated.
BOND_FORBIDDEN_TOKENS = (",", ";", "\n")

# AIM pricing number. The frozen Desktop contract in ``RAG KB/25`` pins
# pxnum=1377. The default IS that frozen value, so the rule text and the code
# agree; a non-empty override is a request-shape change and must be recorded.
AIM_PXNUM = 1377
AIM_PROFILE = "DEFAULT_PROFILE"

# No extra descriptor is added on the AIM path or the Bond path. The AIM
# holding list also contains cash and equity lines; those simply return no
# spread and are excluded with a diagnostic. Adding security_typ() or crncy()
# to label them would be a new data item on a bond book and needs the RAG KB/23
# review first.

# Dropdown label -> bq.data.spread(spread_type=...) code.
# Three choices: the operator removed ``Asset swap spread`` on 2026-11-02 (DR-26)
# because the swap-curve measure is the heaviest of the four to ask for across a
# multi-currency index, and a Desktop run must stay inside the two-minute
# timeout. This is the frozen ``OAS`` / ``Z`` / ``I`` set from the 2026-10-23
# confirmation. Do not re-add ``ASW`` here without a new dated instruction: the
# label was offered, requested, and withdrawn, so restoring it is a decision,
# not a typo fix.
SPREAD_TYPES = {
    "OAS": "OAS",
    "Z-Spread": "Z",
    "I-Spread": "I",
}
DEFAULT_SPREAD_TYPE = "OAS"

# (display column, bq.data item name). "Bloomberg ID" is NOT in this list:
# it is taken from the ranking response ID key. The id() value accessor is
# not documented for index members in the local KB, so no extra request is sent.
# ``Country`` and ``Sector`` were added on 2026-10-31 at the operator's
# request, so the five dimension filters match FI Index Change. They are the
# same two items that app already requests on this same bond index universe
# (``RAG KB/28``: ``country_full_name()`` and ``classification_name()``); see
# ``DECISION_RECORD.md`` DR-13 for the ``RAG KB/23`` review. They are display
# dimensions here: nothing is filtered in BQL, and a failed request leaves the
# column blank rather than falling back to another field.
DESCRIPTOR_FIELDS = (
    ("Name", "name"),
    ("Country", "country_full_name"),
    ("Sector", "classification_name"),
    ("Rating", "rating"),
    ("Currency", "crncy"),
    ("Maturity", "maturity"),
)

# The four duration measures, taken from the FI Index Change build that completed
# on Desktop on 2026-11-02 (``RAG KB/28``, ``RAG KB/08``). All four come from the
# SAME ``duration()`` builder this app already called for ``Duration``; three are
# parameter values, not new data items. ``RAG KB/22`` has one ``duration()`` row
# and no ``modified_duration()`` / ``effective_duration()`` item exists.
#
# Why ``Duration`` moved here. It used to be the seventh ``DESCRIPTOR_FIELDS``
# entry, and every descriptor is sent as its own one-item Request. Leaving it
# there and adding three more descriptors would have cost four requests. Merging
# the whole measure family into the request that already existed costs NOTHING:
# the Update spends the same number of ``bq.execute`` calls it did before the
# extra measures were asked for.
#
# That is the ``RAG KB/23`` rule read correctly: "replacing a no-call-site item
# with a parameter value is the move that costs nothing; appending is the move
# that turns a working run into a timeout." Here the shape is even better than a
# replacement, because the same request now returns four measures instead of one.
#
# Durations ride on the bounded candidate universe (at most ``2 * TOP_N`` IDs in
# a one-book run, ``4 * TOP_N`` in the comparison), never on the whole index, so
# this family cannot re-create the width problem that hit FI Index Change: that
# project evaluates duration over the entire index membership, this one over the
# ranked candidates only.
#
# ``None`` means the bare ``duration()`` call, kept argument-free because that is
# the form the official recipes use (``RAG KB/02`` calls it with no argument, and
# with a fill keyword and a dated range in other examples). Nothing in the corpus
# states which measure it returns, so if it is Modified then ``Duration`` and
# ``Modified Duration`` are one number under two names -- the duplicate check in
# ``data._note_duplicate_duration`` names that pair in the step log instead of
# letting it pass.
#
# ``OASD`` as a label does not collide with ``OAS``: the filters, the ranking and
# the export compare whole column names.
#
# FLDS evidence for the value strings: operator-supplied FLDS BQL tab text on
# 2026-11-02 listed 'MODIFIED', 'EFFECTIVE' and 'SPREAD', with 'SPREAD'
# described as "Spread Duration (OAS Duration)". Do not add a fifth value
# without new dated FLDS text.
DURATION_FIELDS = (
    ("Duration", None),
    ("Modified Duration", "MODIFIED"),
    ("Effective Duration", "EFFECTIVE"),
    ("OASD", "SPREAD"),
)

# Display label -> the sentence shown where the measure is explained. Kept here
# so the page, the export and the docs cannot drift apart.
DURATION_LABELS = {
    "Duration": "Duration",
    "Modified Duration": "Modified duration",
    "Effective Duration": "Effective duration",
    "OASD": "Option adjusted spread duration",
}

# First validation window. Desktop has a two-minute request timeout, so the
# window stays narrow until a measured run proves how long the request takes.
DEFAULT_WINDOW_DAYS = 7
MAX_RANGE_DAYS = 31

# ---------------------------------------------------------------------------
# Dimension filters and charts
# ---------------------------------------------------------------------------

# Filter label -> candidate column. Built only from what this app requests
# plus derived buckets, so no filter builds a request of its own:
#   Country       country_full_name()  -- requested descriptor
#   Sector        classification_name() -- requested descriptor
#   Tenor         maturity()          -- requested descriptor, converted to years
#   Rating        rating()            -- requested descriptor, letter buckets
#   Currency      crncy()             -- requested descriptor
# The order is the widget order and matches the Dimension list in FI Index
# Change. Every one of these is a pandas filter over the frames the last
# Update already returned.
FILTER_COLUMNS = (
    ("Country", "Country"),
    ("Sector", "Sector"),
    ("Tenor", "Tenor Bucket"),
    ("Rating", "Rating Bucket"),
    ("Currency", "Currency"),
)

# First option in every dimension filter, and the value the widget starts on.
# A picked value always wins over it, so "(All)" plus "USD" still means USD.
ALL_FILTER_LABEL = "(All)"

# Selection-box geometry, copied from FI Index Change so the five boxes, the
# Group by dropdown, and the charts share one right edge and one height:
#   - description_width 90px and rows=10 are that app's SelectMultiple settings
#   - 300 px for Country/Sector, 220 px for the other three
#   - an 8 px right margin between boxes
# The chart width is their total plus four gaps (1,292 px), which is exactly
# the width of that app's five dimension boxes.
FILTER_DESCRIPTION_WIDTH = "90px"
FILTER_WIDTHS = {
    "Country": 300,
    "Sector": 300,
    "Tenor": 220,
    "Rating": 220,
    "Currency": 220,
}
FILTER_GAP_PX = 8
FILTER_ROWS = 10
CHART_WIDTH_PX = sum(FILTER_WIDTHS.values()) + FILTER_GAP_PX * (
    len(FILTER_WIDTHS) - 1
)
CHART_WIDTH = f"{CHART_WIDTH_PX}px"

# The Group by dropdown is the same fixed width and height as its row partner
# in FI Index Change (the Dimension dropdown: 240 px).
GROUP_WIDTH_PX = 240

# Split-by choices for the bucket chart. Same order and vocabulary as the
# filters, and the value is the summary column.
DIMENSIONS = {
    "Country": "Country",
    "Sector": "Sector",
    "Tenor": "Tenor Bucket",
    "Rating": "Rating Bucket",
    "Currency": "Currency",
}
DEFAULT_DIMENSION = "Country"

# Both bucket charts show this many buckets, then one aggregated Others row.
# The operator asked for Top 10 on 2026-11-01. The bucket TABLE below the two
# charts is never truncated: it lists every bucket, which is why the charts and
# the table carry different counts on purpose.
BUCKET_CHART_TOP = 10

# The two charts above the bucket table. The first counts movers, the second
# sums the signed spread change each way, so a bucket with many small moves and
# a bucket with one large move cannot be confused.
MOVERS_CHART_LABEL = "Movers by"
SPREAD_CHART_LABEL = "Spread Change by"
# The x-axis hint shared by both: the direction is the side of the zero line.
DIVERGING_AXIS_HINT = "(decrease \u2190 | \u2192 increase)"

# Tenor buckets come from the returned Maturity date and the end date. They are
# a derived approximation; no additional tenor data item is requested.
TENOR_BINS = (0.0, 1.0, 3.0, 5.0, 7.0, 10.0, 20.0)
TENOR_LABELS = ("0-1Y", "1-3Y", "3-5Y", "5-7Y", "7-10Y", "10-20Y", "20Y+")
TENOR_MISSING_LABEL = "Missing"

# Chart styling, copied from FI Index Change so both screens read the same:
# light text on the dark plot card, muted axis labels, dark grid lines,
# transparent paper and plot backgrounds so Desktop's dark theme shows through.
CHART_HEIGHT_PX = 360
# FI Index Change draws its lower chart shorter and with a tighter top and
# bottom margin. The path chart here is the same lower chart.
CHART_DETAIL_HEIGHT_PX = 300
CHART_MARGIN_LEFT_PX = 140
CHART_MARGIN_RIGHT_PX = 16
CHART_MARGIN_TOP_PX = 48
CHART_MARGIN_BOTTOM_PX = 64
CHART_DETAIL_MARGIN_TOP_PX = 40
CHART_DETAIL_MARGIN_BOTTOM_PX = 48
CHART_FONT_COLOR = "#f5f5f5"
CHART_MUTED_COLOR = "#b8b8b8"
CHART_GRID_COLOR = "#3a3a3a"
CHART_ZERO_COLOR = "#9a9a9a"
# The local preview card only. The Desktop figure keeps a transparent
# background, exactly as FI Index Change does.
CHART_BACKGROUND_COLOR = "#0d1117"
CHART_INCREASE_COLOR = "#1565c0"
CHART_DECREASE_COLOR = "#ef6c00"
# The two diverging bucket charts read the colour as the direction, not as the
# book: an increase is blue, a decrease is orange, so the two halves of the zero
# line differ even without the legend. A two-book comparison separates its books
# by depth inside those two hues (AIM deeper, Index lighter) rather than by a
# second hue, which is what used to leave an increase and the matching decrease
# in the same colour family.
CHART_DIRECTION_COLORS = (CHART_INCREASE_COLOR, CHART_DECREASE_COLOR)
CHART_COMPARE_COLORS = {
    # (increase, decrease)
    "AIM": ("#0d47a1", "#e65100"),
    "Index": ("#64b5f6", "#ffb74d"),
}
# In the two Top 10 change charts both books sit on the same side of the axis,
# so there the colour has to name the book and not the sign. These are two
# unmistakable hues of their own, deliberately not the blue/orange above.
CHART_BOOK_COLORS = {"AIM": "#e76f51", "Index": "#2a9d8f"}

# ---------------------------------------------------------------------------
# Tabs and Export Excel
# ---------------------------------------------------------------------------

# Two tabs, as in FI Index Change (there: Main / Export / Full Position).
TAB_TITLES = ("Main", "Export Excel")
TAB_MAIN = 0
TAB_EXPORT = 1

# Export Excel choices. The value is the key used by the app. The arithmetic
# validation table was retired as a UI surface on 2026-11-01; the bounded series
# request it read is still sent, because that same response now feeds the
# per-bond daily table under the path chart.
EXPORT_VIEWS = (
    ("Top 10 increases", "increases"),
    ("Top 10 decreases", "decreases"),
    ("Request log", "requests"),
)

# There is no version stamp in this project any more. It was a dated string the
# page printed as "Stamp 2026-11-01a", and it had to be hand-edited after every
# change, so it drifted and told the operator nothing the request log does not
# already date. Nothing reads it: the app header is the bare title, the preview
# banner carries no version, and MAIN.ipynb prints no line. Do not reintroduce a
# stamp, a V1 label, or a build number here — see the project rule.

# ---------------------------------------------------------------------------
# Timeout protection: cache, retry, and split
# ---------------------------------------------------------------------------

# Where cached runs live, under the project folder. Created only when a run is
# actually written, so a read-only project folder cannot fail an Update.
CACHE_DIR_NAME = "cache"
# How many cached runs to keep. One Update writes one run, and a spread change is
# only meaningful for its own window, so old entries are worth little. Keeping a
# handful covers "the run I just did timed out, use what we had" without growing
# the Desktop project folder without limit.
CACHE_KEEP_RUNS = 12
# Set True to show a cached run when one exists instead of asking Bloomberg.
# Off by default: a normal Update must ask Bloomberg first, and the cache is a
# safety net, not a speed setting. The app offers a separate button for reading
# what was saved, and falls back to the cache automatically after a timeout.
CACHE_READ_FIRST = False

# A timed-out request is attempted again, unchanged, on the operator's
# 2026-11-02 evidence in the sibling project that pressing Update a second time
# answers in seconds while the first attempt ran close to the limit. Nothing is
# dropped and no item is substituted: only a warm Bloomberg-side cache can make
# the retry faster. Only a timeout is retried; a rejected item, a missing
# entitlement or a bad ticker can never succeed on a second try, so retrying
# those would spend another two minutes for nothing.
QUERY_ATTEMPTS = 2

# The columns that must come back as numbers after a cached run is read from
# CSV. Everything else was stored as text on purpose, so a blank cell stays
# blank instead of turning into the string "nan".
NUMERIC_RESULT_COLUMNS = (
    "Change",
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
)
NUMERIC_DESCRIPTOR_COLUMNS = (
    "Duration",
    "Modified Duration",
    "Effective Duration",
    "OASD",
)
