"""Update-only BQuant Desktop UI for FI spread movers.

The visible surface is a two-line status bar, adapted from FI Index Change:

- line 1: the phase word (Idle / Loading / Updated / Refused / Error / ...)
- line 2: ``Environment:`` Idle or Processing

Long diagnostics (request totals, errors) live in the ``detail`` box under the
bar, and the step log goes to the ``log`` output. The per-field descriptor and
series receipt is request metadata, not data: it is recorded on the result and
offered in the Export Excel tab, and the page body carries only a FAILED field
line, so a failure stays visible without a metadata table above the numbers
(operator instruction 2026-11-01; ``DECISION_RECORD.md`` DR-16).

Layout mirrors the FI Index Change app: a title, then a ``Tab`` with ``Main``
and ``Export Excel``. On ``Main`` the controls run header row (universe source,
its input(s), Spread, Update), then the date pair, then the status surfaces,
then the ``Group by`` dropdown at the far left of its own row, then exactly five
selection boxes (Country, Sector, Tenor, Rating, Currency) with that app's
widths, rows, and gap. Charts are ``CHART_WIDTH_PX`` wide, the width of those
five boxes, so one right edge runs down the screen.

Constructing the app never fetches: constructing only builds widgets.
"""

from __future__ import annotations

import traceback
from datetime import date, timedelta
from html import escape
from pathlib import Path

import ipywidgets as widgets
import pandas as pd
from IPython.display import display

from . import cache, charts, config
from .data import (
    fetch_comparison,
    fetch_movers,
    is_timeout,
    normalize_comparison,
    normalize_universe,
)
from .engine import (
    SeriesValidation,
    apply_dimension_filters,
    attach_spread_levels,
    bucket_diverging_rows,
    bucket_table,
    daily_spread_rows,
    enrich_ranked,
    export_display_frame,
    filter_choices,
    label_conflicts,
    label_key,
    prepare_ranked_movers,
    spread_levels,
    spread_paths,
    validate_candidate_changes,
)

# Phases that mean "nothing is loaded, click Update". They are red.
IDLE_PHASES = {"Idle", "Please Click Update", "Refused"}

# Phases that mean the loaded tables match the visible controls. They are green.
DONE_PHASES = {"Updated"}

# A cached screen is neither: something is loaded, but no request produced it.
# It gets its own colour so it can never be mistaken for a fresh `Updated`, and
# so a reader can tell at a glance that the numbers came off disk.
CACHED_PHASES = {"Cached"}

# The local steps of one Update, named in the failure message.
#
# A request failure and a failure in this file are different facts: the first is
# about Bloomberg, the second about reshaping data that already arrived. The
# banner used to print both without saying which, so a KeyError raised while
# drawing the tables read exactly like a refused query — and cost a reader a
# whole diagnosis cycle. Each step now names itself.
_UPDATE_STAGES = {
    "request": "Requesting the data",
    "prepare": "Preparing the ranked tables",
    "check": "Checking the change arithmetic",
    "render": "Drawing the figures",
}


def _exception_site(exc: BaseException) -> str:
    """``file.py:line in function`` for the innermost frame of ``exc``.

    A stage name says which step broke; it does not say where. One line of the
    traceback is enough to point at the statement, and it is the only part of a
    traceback that fits on the banner without turning it into a log dump. An
    exception without a traceback (raised by hand, or a bare stub in a test)
    yields an empty string, so the message simply omits it.
    """
    frames = traceback.extract_tb(exc.__traceback__) if exc.__traceback__ else []
    if not frames:
        return ""
    frame = frames[-1]
    name = Path(frame.filename).name
    function = frame.name
    return f"{name}:{frame.lineno} in {function}()"

# The app header, kept as two plain literals because the local preview reads
# them with ast, so no version stamp and no build step can creep back in.
# Same format as FI Index Change: one 20px bold line, nothing under it.
APP_TITLE = "FI Spread Movement Monitoring"
TITLE_HTML = "<p style='font-size:20px;font-weight:700;margin:0 0 8px 0'>FI Spread Movement Monitoring</p>"

# Column order of the ranked tables. ``Universe`` appears only in the two-book
# comparison, where a row belongs to a book and not to the whole screen.
RANKED_COLUMNS = (
    "Universe",
    "ID",
    "Name",
    "Country",
    "Sector",
    "Rating",
    "Currency",
    "Maturity",
    "Duration",
    # The three extra duration measures. They ride in one grouped request on
    # the bounded candidate universe, so they cost one `bq.execute` per Update
    # and are display columns only: no filter, chart, or ranking reads them.
    "Modified Duration",
    "Effective Duration",
    "OASD",
    # The two observed endpoints of the ranked change, read from the same
    # bounded series the change check requests. They sit immediately before
    # ``Change`` so the row reads "start, end, change".
    "Start Spread",
    "End Spread",
    "Change",
)

# The selected-security panel's resting text. One constant, because three
# places wrote the same sentence and a reset that drifted from the constructor
# would have left the panel looking populated when it was not.
_DETAIL_PROMPT_HTML = (
    "<b>Selected security</b><br>Click a bar or a line to inspect one security."
)


def _phase_markup(phase: str) -> str:
    """First status line.

    Idle and Please Click Update are red; Updated is green; Cached is amber, so a
    screen served from disk is visibly neither fresh nor empty.
    """
    if phase in IDLE_PHASES:
        color = "#c62828"
    elif phase in DONE_PHASES:
        color = "#1b7f37"
    elif phase in CACHED_PHASES:
        color = "#8a5a00"
    else:
        return f"<b>{escape(phase)}</b>"
    return f"<b style=\"color:{color}\">{escape(phase)}</b>"


def _environment_markup(activity: str) -> str:
    """Second status line. Processing is red. Idle is green."""
    color = "#c62828" if activity == "Processing" else "#1b7f37"
    return f"<p style=\"margin:2px 0;color:{color}\">Environment: {escape(activity)}</p>"


def _info_box(content: str, tone: str = "ok") -> str:
    """Boxed detail block. Same visual language as the status bar."""
    palettes = {
        "ok": ("#e8f5e9", "#c8e6c9", "#1b5e20"),
        "warn": ("#fff8e1", "#ffe082", "#8a5a00"),
        "error": ("#ffebee", "#ffcdd2", "#b71c1c"),
        "neutral": ("#f5f5f5", "#e0e0e0", "#333333"),
    }
    background, border, color = palettes.get(tone, palettes["neutral"])
    return (
        f"<div style='margin:4px 0;padding:6px 10px;background:{background};"
        f"border:1px solid {border};color:{color}'>"
        f"{content}</div>"
    )


def _field_log_lines(field_status: dict[str, str]) -> list[str]:
    """Every per-field descriptor and series line, for the log or the export.

    This is the per-request receipt (how many rows each descriptor returned,
    and whether a request failed). It used to be an HTML table titled
    "Descriptor and series status" at the top of the layout. It is request
    metadata, not data, so it is no longer part of the page body: success
    lines are available in the Export Excel tab's request detail, and only a
    FAILED field is written to the step log, where a problem must stay visible.
    """
    return [
        f"{label}: {status}" for label, status in (field_status or {}).items()
    ]


def _field_failure_lines(field_status: dict[str, str]) -> list[str]:
    """The subset of the receipt that is a diagnostic: failed fields only."""
    return [
        f"{label}: {status}"
        for label, status in (field_status or {}).items()
        if str(status).upper().startswith("FAILED")
    ]


def _failed_field_labels(field_status: dict[str, str]) -> list[str]:
    """Names of the fields whose request failed, in receipt order.

    A descriptor failure does not add to ``FetchResult.errors``: each field is
    its own request and the adapter deliberately keeps going. That made a run
    where every descriptor failed still report a green ``Updated``, because the
    status word only looked at ``errors``. The status now degrades on this list
    too, so a screen of ``(unavailable)`` columns cannot be read as a clean run.
    """
    return [
        label
        for label, status in (field_status or {}).items()
        if str(status).upper().startswith("FAILED")
    ]


def _as_date_or(value, fallback):
    """A stored ISO date as a ``date``, or ``fallback`` when it is unusable."""
    if value:
        try:
            return pd.Timestamp(str(value)).date()
        except (TypeError, ValueError):
            pass
    return fallback


def _result_is_timeout(result) -> bool:
    """True only when the query limit is the *only* thing that went wrong.

    Gated on that, not on "there was an error", and not on "one of the errors was
    a timeout". A run that also hit a deterministic failure — a rejected item, a
    missing entitlement, a bad ticker — must keep the fail-closed behaviour:
    showing a previous run's numbers there would hide a real problem behind a
    table that looks current. A mixed set is therefore treated as deterministic.

    Checked in both places a failure is recorded, because the adapter puts a
    ranking failure in ``errors`` and a duration-family failure in
    ``field_status``.
    """
    messages = [str(item) for item in (getattr(result, "errors", []) or [])]
    failures = [str(status) for status in (getattr(result, "field_status", {}) or {}).values()]
    messages += [status for status in failures if status.upper().startswith("FAILED")]
    if not messages:
        return False
    return all(is_timeout(RuntimeError(message)) for message in messages)


# The row attribute name each clickable column writes in the HTML form. It has
# to match what preview/preview_core.py listens for: a bucket row narrows the
# Top 10 charts, a security row drives the path chart and its daily table.
_ROW_ATTRIBUTES = {"Bucket": "bucket", "ID": "security"}


def _table_html(
    frame: pd.DataFrame,
    max_rows: int | None = None,
    row_attribute: str | None = None,
) -> str:
    """One frame as an HTML table.

    ``row_attribute`` names a column whose value is written onto each ``<tr>``
    as a ``data-`` attribute. The local preview uses that to make a bucket row
    or a security row clickable without a plotting library or a DataGrid;
    pandas' own ``to_html`` cannot carry a row attribute.
    """
    if frame is None or frame.empty:
        return "<p>No rows are available.</p>"
    view = frame if max_rows is None else frame.head(max_rows)
    html = view.to_html(index=False, border=0, escape=True, na_rep="")
    name = _ROW_ATTRIBUTES.get(str(row_attribute or ""))
    if not name or row_attribute not in view.columns:
        return html
    keys = [
        escape(str(value), quote=True)
        for value in view[row_attribute]
    ]
    lines = html.splitlines()
    out: list[str] = []
    position = 0
    for line in lines:
        stripped = line.strip()
        if stripped == "<tr>" and position < len(keys):
            out.append(
                line.replace("<tr>", f'<tr data-{name}="{keys[position]}">', 1)
            )
            position += 1
            continue
        # pandas writes the header row as <thead><tr> on one line, so that one
        # is not a data row and must not consume a key.
        out.append(line)
    return "\n".join(out)


def _display_columns(frame: pd.DataFrame) -> list[str]:
    """The ranked-table column order for one frame, whichever columns exist."""
    if frame is None:
        return []
    return [column for column in RANKED_COLUMNS if column in frame.columns] + [
        column
        for column in frame.columns
        if column not in RANKED_COLUMNS
        and column not in {"Side", "Rating Bucket", "Tenor Bucket"}
    ]


# How each spread-carrying column is titled in a table. OAS, Z and I are three
# different numbers on the same bond, so a header that says only "Change" or
# "Spread" cannot be read back later without guessing which one it was. The
# spread type is part of the heading, taken from the run that filled the cells.
_SPREAD_HEADERS = {
    "Start Spread": "Start {spread}",
    "End Spread": "End {spread}",
    "Change": "{spread} Change",
    "Increase Spread": "Increase {spread}",
    "Decrease Spread": "Decrease {spread}",
    "Net Change": "Net {spread} Change",
    "Spread": "{spread}",
}


def _spread_headers(frame: pd.DataFrame, spread_label: str) -> pd.DataFrame:
    """A display copy whose spread columns name the spread type.

    Applied at the last step only, when a table is drawn or copied out. The
    frames that feed the charts, the click handlers, and the ranking keep the
    canonical column names, so a heading stays a label and never becomes a data
    contract that a later rename could break.

    An unknown spread label renames nothing rather than producing a heading
    such as "Start " with a dangling blank.
    """
    label = str(spread_label or "").strip()
    if frame is None or not label:
        return frame
    rename = {
        column: template.format(spread=label)
        for column, template in _SPREAD_HEADERS.items()
        if column in frame.columns
    }
    if not rename:
        return frame
    return frame.rename(columns=rename)


def _universe_label(source_key: str) -> str:
    """Readable noun for the chosen universe source, used in the status text."""
    if source_key == "aim":
        return "AIM account"
    if source_key == "bond":
        return "bond"
    if source_key == config.COMPARISON_SOURCE:
        return "AIM vs Index"
    return "index"


def _grid_available() -> bool:
    """True when ``ipydatagrid`` can be imported in this kernel."""
    try:
        import ipydatagrid  # noqa: F401
    except Exception:
        return False
    return True


GRID_NO_CLICK_NOTE = (
    "<p style='margin:2px 0;color:#8a5a00'>ipydatagrid is unavailable in this "
    "kernel, so the table is plain HTML and a row click cannot reach the "
    "detail panel inside the notebook. The chart bars can still be clicked.</p>"
)


def _slot_child(slot):
    """The single widget inside a chart slot, or ``None`` when it holds no one."""
    children = list(getattr(slot, "children", ()) or ())
    return children[0] if len(children) == 1 else None


def _grid_column_widths(frame: pd.DataFrame) -> dict[str, int]:
    """Pixel width per column, measured from the header and the values.

    ``ipydatagrid`` gives every column the same narrow default, so a header like
    `Decrease Spread` truncates while a numeric column wastes the same width. The
    knowledge base documents `column_widths` (pixels keyed by column name) and
    `base_column_size` (the default for the rest); this builds that dictionary
    from the text the grid will actually draw.

    The estimate is generous, not exact — a bold header is wider than a digit, so
    the header is weighted as the wider of the two, and a padding allowance covers
    the cell borders and the sort glyph. A float is measured at display precision
    (four decimals plus a sign) rather than at full binary precision, because the
    full form is a 17-digit artefact no reader wants to size a column for. An
    empty frame returns an empty dictionary and the grid keeps its own defaults,
    so nothing depends on this function succeeding.
    """
    if not isinstance(frame, pd.DataFrame) or frame.empty:
        return {}
    widths: dict[str, int] = {}
    for column in frame.columns:
        header = str(column)
        longest = 0
        values = frame[column]
        try:
            if pd.api.types.is_numeric_dtype(values) and not pd.api.types.is_bool_dtype(values):
                # Round to the display precision first, then measure the text.
                # One vectorised pass: this runs on every render, and a
                # 2,000-row grid must not pay a per-cell Python call for a
                # column width.
                numbers = pd.to_numeric(values, errors="coerce").dropna().round(4)
                if not numbers.empty:
                    longest = max(
                        len(str(numbers.max())),
                        len(str(numbers.min())),
                    ) + 1  # room for an explicit sign
            else:
                text = values.astype("string").fillna("")
                longest = int(text.str.len().max() or 0)
        except Exception:
            longest = 0
        characters = max(len(header), longest)
        # 8 px per character at the default 12 px mono-ish cell font, plus 28 px
        # for padding. Clamped so one long identifier cannot push the other
        # columns off the screen.
        widths[column] = max(70, min(260, int(characters * 8) + 28))
    return widths


class _PickTable:
    """A table whose every row click selects one security or one bucket.

    ``widgets.HTML`` has no click event, so a clickable table has to be an
    ``ipydatagrid.DataGrid``: ``RAG KB/09`` documents ``on_cell_click`` with
    ``event['primary_key_row']``, and the row key is read from the frame index.
    Without ipydatagrid the same frame is drawn as an HTML table and a note says
    plainly that a click does not work there, instead of looking clickable.

    ``on_cell_click`` fires for every column, so any cell in a row is the same
    event: that is what "click anywhere in the row" means.
    """

    def __init__(self, on_pick, height: int = 260):
        self._on_pick = on_pick
        self._default_height = height
        self.box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.box.children = (widgets.HTML("<p>No rows are available.</p>"),)
        # The HTML of the last render, kept as text. The visible surface is the
        # grid (or the HTML fallback), but a test and the preview both need to
        # read what this table currently says without driving a browser.
        self.value = ""

    def render(
        self,
        blocks: list[dict] | None = None,
        frame: pd.DataFrame | None = None,
        title: str = "",
        key_column: str | None = None,
        pick: str | None = None,
        note: str = "",
        height: int | None = None,
    ) -> None:
        """Draw one block, or several stacked blocks (one per book).

        A block is ``{title, frame, key_column, pick, note}``. ``key_column``
        names the frame column that carries the row key; ``pick`` passes a fixed
        value instead, which is what the per-bond daily table needs (one bond,
        many dates).
        """
        if blocks is None:
            blocks = [
                {
                    "frame": frame,
                    "title": title,
                    "key_column": key_column,
                    "pick": pick,
                    "note": note,
                }
            ]
        children: list = []
        text: list[str] = []
        for block in blocks:
            children.extend(self._block_widgets(block, height))
            text.append(self._block_html(block))
        if not children:
            children = [widgets.HTML("<p>No rows are available.</p>")]
        self.box.children = tuple(children)
        self.value = "".join(text)

    def _block_html(self, block: dict) -> str:
        """The plain-HTML form of one block. Read by tests and by the export."""
        title = str(block.get("title") or "")
        note = str(block.get("note") or "")
        heading = (
            f"<h4 style='margin:8px 0 2px'>{escape(title)}</h4>" if title else ""
        )
        note_html = (
            f"<p style='margin:2px 0;color:#666'>{escape(note)}</p>" if note else ""
        )
        frame = block.get("frame")
        if block.get("caption") and not isinstance(frame, pd.DataFrame):
            return heading + note_html
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            if not title:
                return ""
            return (
                heading
                + "<p style='margin:2px 0;color:#666'>No rows to list: no run is "
                "loaded, or the current filters removed every row.</p>"
            )
        return heading + _table_html(
            frame.reset_index(drop=True),
            row_attribute=block.get("row_attribute"),
        )

    def _block_widgets(self, block: dict, height: int | None) -> list:
        title = str(block.get("title") or "")
        note = str(block.get("note") or "")
        heading = (
            f"<h4 style='margin:8px 0 2px'>{escape(title)}</h4>" if title else ""
        )
        note_html = (
            f"<p style='margin:2px 0;color:#666'>{escape(note)}</p>" if note else ""
        )
        frame = block.get("frame")
        if block.get("caption") and not isinstance(frame, pd.DataFrame):
            return [widgets.HTML(heading + note_html)]
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            if title:
                empty = "No rows to list: no run is loaded, or the current filters removed every row."
                return [widgets.HTML(heading + f"<p style='margin:2px 0;color:#666'>{empty}</p>")]
            return []
        key_column = block.get("key_column")
        view = frame.reset_index(drop=True).copy()
        fixed = block.get("pick")
        if key_column is not None and key_column in view.columns:
            keys = [str(value) for value in view[key_column]]
        elif fixed:
            keys = [str(fixed)] * len(view)
        else:
            keys = [""] * len(view)
        # The key column stays visible. It used to be dropped from the grid, which
        # was harmless for the ranked tables because their key is `ID` and an ID
        # reads as an identifier whether or not it is the hidden key. The bucket
        # table's key is `Bucket` — the country name itself — so dropping it left
        # a grid of counts and sums with no label column at all: the numbers were
        # right and there was no way to tell one row from another or to know what
        # a click would select. Nothing is dropped now.
        shown = view
        # The grid is handed a plain RangeIndex frame on purpose. The custom
        # index here used to carry the row key, and the bucket table in a
        # two-book run legitimately repeats one bucket once per book, so that
        # index was **non-unique**: one label, two rows. A third-party grid has
        # to align rows against that index, and an alignment that finds nothing
        # is exactly what ``KeyError: None of [Int64Index([-1, ...])] are in the
        # [index]`` reports — after every request has already succeeded. The
        # keys live in ``labels`` instead, and a click is resolved by row
        # position (``_pick_row_key``), so no consumer depends on the index.
        shown = shown.reset_index(drop=True)
        if not _grid_available():
            return [
                widgets.HTML(
                    heading
                    + note_html
                    + _table_html(view, row_attribute=block.get("row_attribute"))
                    + GRID_NO_CLICK_NOTE
                )
            ]
        import ipydatagrid as ipd

        box_height = height if height is not None else self._default_height
        box_height = min(box_height, max(120, len(shown) * 26 + 44))
        widths = _grid_column_widths(shown)
        try:
            # `column_widths` and `base_column_size` are the documented sizing
            # arguments (`RAG KB/09`). A build that does not accept them must
            # still draw the grid, so they are tried first and dropped on
            # refusal rather than turning a sizing preference into a lost table.
            try:
                grid = ipd.DataGrid(
                    shown,
                    layout=widgets.Layout(width="100%", height=f"{box_height}px"),
                    selection_mode="cell",
                    editable=False,
                    column_widths=widths,
                    base_column_size=110,
                )
            except TypeError:
                grid = ipd.DataGrid(
                    shown,
                    layout=widgets.Layout(width="100%", height=f"{box_height}px"),
                    selection_mode="cell",
                    editable=False,
                )
        except Exception as exc:
            # The grid is a convenience over a table that already rendered. A
            # build that refuses this frame must cost the click, never the
            # Update: the rows stay on screen as HTML and the reason is printed.
            return [
                widgets.HTML(
                    heading
                    + note_html
                    + _table_html(view, row_attribute=block.get("row_attribute"))
                    + GRID_NO_CLICK_NOTE
                    + f"<p style='margin:2px 0;color:#8a5a00'>The clickable "
                    f"grid could not be built ({type(exc).__name__}: {exc}).</p>"
                )
            ]
        labels = list(keys)

        def on_click(event) -> None:
            value = _pick_row_key(labels, (event or {}).get("primary_key_row"))
            if value:
                self._on_pick(value)

        try:
            grid.on_cell_click(on_click)
        except Exception:
            # A build without on_cell_click keeps the grid readable; the note
            # says the click is not wired rather than hiding it.
            return [widgets.HTML(heading + note_html + GRID_NO_CLICK_NOTE), grid]
        return [widgets.HTML(heading + note_html), grid]


def _pick_row_key(labels: list[str], raw) -> str:
    """The row a grid click landed on, from ``event['primary_key_row']``.

    ``ipydatagrid`` documents ``primary_key_row`` as the dataset row, so a
    position is tried first. A build that reports the index label instead would
    otherwise fail the conversion and the click would silently pick nothing, so
    the label is accepted as a fallback. An unresolved click returns ``""`` and
    the caller ignores it rather than picking the wrong row.
    """
    try:
        position = int(raw)
    except (TypeError, ValueError):
        position = None
    if position is not None and 0 <= position < len(labels):
        return labels[position]
    text = "" if raw is None else str(raw)
    return text if text in labels else ""


def _default_end_date() -> date:
    today = date.today()
    while today.weekday() >= 5:
        today -= timedelta(days=1)
    return today


class FISpreadMovementApp:
    """Update-triggered controller; constructing it never fetches data."""

    def __init__(self, cache_root=None):
        # Where the result cache lives. ``None`` means the project folder, which
        # is what Desktop uses. The parameter exists so a test or the preview can
        # point at a temporary directory: a suite run must never write into the
        # operator's real cache, and a test that reuses another test's cached run
        # would pass or fail depending on execution order.
        self._cache_root = cache_root
        # Idempotent re-bind, as in FI Index Change: a status refresh must never
        # leave the controls without handlers.
        self._events_bound = False
        # True only while one Update is inside a request.
        self._running = False
        # True while a local redraw is in progress, so a widget event cannot
        # re-enter the render path.
        self._rendering = False
        # The universe / spread / dates that produced the tables on screen.
        self._loaded = None
        # The status word and message of that same run, restored when the
        # controls are put back on the loaded values.
        self._loaded_status: tuple[str, str] | None = None
        # The enriched ranked sides, the candidate series, and the window that
        # produced them. The local view (filters, grouping, charts, click
        # detail) reads only these frames, so no filter can build a request.
        self._frames: dict = {}
        # The same two frames after the filters on Main, cached at render time so
        # the Export Excel tab exports exactly what is on screen.
        self._visible: dict = {}
        # True when the loaded run compared two books.
        self._comparison = False
        # The per-field receipt of the last run (metadata, not data).
        self._field_status: dict[str, str] = {}
        # Diagnostics from the last run: effective-date and arithmetic notes.
        # The table itself is not on screen; these lines print as log text.
        self._validation_notes: list[str] = []
        self._request_log: list[dict] = []
        # The security currently shown in the click-to-inspect panel.
        self._selected_id: str | None = None
        # The bucket a click on the full bucket table narrowed the two Top 10
        # charts to, or None for every bucket. A local view only.
        self._selected_bucket: str | None = None
        # How many rows each ranked panel draws, per side. A local view only:
        # the run fetched at most ``config.TOP_N`` rows per direction, so this
        # slices what is in memory and never asks for more. It survives a new
        # Update, because it is the operator's reading preference, not data.
        self._display_top: dict[str, int] = {
            "increases": config.DEFAULT_DISPLAY_TOP,
            "decreases": config.DEFAULT_DISPLAY_TOP,
        }
        # A refused Display Top value leaves its reason here until a valid value
        # replaces it. The render path would otherwise overwrite the red refusal
        # with its own "only N available" note and the operator would see no
        # reason for the panel not changing.
        self._display_top_error: dict[str, str] = {}
        self._export_key = None
        # Bumped by every Update. The export cache key uses it instead of an
        # object address, because CPython reuses ids and a new filtered frame
        # could then collide with a retired one and be skipped.
        self._run_token = 0
        # The key of the run most recently saved. Kept so the log can say the
        # fallback is available without re-deriving it.
        self._last_cache_key = None
        self._build_widgets()
        self._bind_events()

    # ------------------------------------------------------------------
    # Widgets
    # ------------------------------------------------------------------

    def _build_widgets(self) -> None:
        self.update_button = widgets.Button(
            description="Update",
            button_style="primary",
            icon="refresh",
        )
        # Reads the last saved run for the current inputs instead of asking
        # Bloomberg. It is the manual counterpart to the automatic fallback: the
        # fallback fires by itself after a failure, this one on request.
        self.cache_button = widgets.Button(
            description="Load saved",
            layout=widgets.Layout(width="130px"),
        )
        # The two-line status bar: phase first, then the Environment line.
        self.status = widgets.HTML(value="")
        # Long diagnostics (request totals, errors).
        self.detail = widgets.HTML(value="")
        # Step log, one line per stage of the run plus any failed field.
        self.log = widgets.Output()

        end = _default_end_date()
        start = end - timedelta(days=config.DEFAULT_WINDOW_DAYS)
        self.start_date = widgets.DatePicker(description="Start date", value=start)
        self.end_date = widgets.DatePicker(description="End date", value=end)

        # Universe source first, then the field(s) it labels. The dropdown
        # decides what each input means, so it sits to the left of them.
        self.universe_source = widgets.Dropdown(
            description="Universe",
            options=list(config.UNIVERSE_SOURCES),
            value=config.DEFAULT_UNIVERSE_SOURCE,
        )
        # Every input starts empty and is never pre-filled: DEFAULT_INDEX is the
        # recorded example, shown as an Index placeholder only. The comparison
        # source shows the Index and the AIM field at the same time, which is
        # why they are separate widgets rather than one relabelled field.
        self.index_input = widgets.Text(
            description="Index",
            value="",
            placeholder=config.DEFAULT_INDEX,
        )
        self.aim_input = widgets.Text(
            description="AIM code",
            value="",
            placeholder="ABC123",
        )
        self.bond_input = widgets.Text(
            description="Bond",
            value="",
            placeholder="One bond ticker, for example US91282CLW91 Govt",
        )
        # The row is rebuilt on every source change; only the inputs that the
        # chosen source reads are in it, so no stale field can look active.
        self.universe_row = widgets.HBox(
            layout=widgets.Layout(flex_flow="row wrap", align_items="flex-start")
        )
        self.spread_type = widgets.Dropdown(
            description="Spread",
            options=list(config.SPREAD_TYPES),
            value=config.DEFAULT_SPREAD_TYPE,
        )

        # Filter widgets start with only "(All)", which is the widget's rest
        # state. The real values arrive from the loaded descriptors, so a filter
        # can never request a field (``RAG KB/23``): it only narrows in pandas.
        # Fixed width and height, and the same order, width, gap, and row count
        # as the Dimension list in FI Index Change, so the two screens line up.
        style = {"description_width": config.FILTER_DESCRIPTION_WIDTH}
        self.filters: dict[str, widgets.SelectMultiple] = {}
        for label, _column in config.FILTER_COLUMNS:
            width = config.FILTER_WIDTHS.get(label, 220)
            self.filters[label] = widgets.SelectMultiple(
                description=label,
                options=[config.ALL_FILTER_LABEL],
                value=(config.ALL_FILTER_LABEL,),
                rows=config.FILTER_ROWS,
                style=style,
                layout=widgets.Layout(
                    width=f"{width}px",
                    margin=f"0 {config.FILTER_GAP_PX}px 0 0",
                ),
            )
        # The grouping dimension of the bucket chart. It re-reads the frames
        # already in memory; it never sends a request. Same width and height as
        # the Dimension dropdown it mirrors in FI Index Change.
        self.dimension_input = widgets.Dropdown(
            description="Group by",
            options=list(config.DIMENSIONS),
            value=config.DEFAULT_DIMENSION,
            style=style,
            layout=widgets.Layout(width=f"{config.GROUP_WIDTH_PX}px"),
        )
        self.headline = widgets.HTML(value="")

        # Charts. Built once and updated in place, following the Desktop
        # pattern: create the FigureWidget once, then ``batch_update()`` rather
        # than rebuilding. With no Plotly the same specification is rendered as
        # an HTML table, so a kernel without the library still shows the numbers.
        #
        # ``movers_figure`` and ``spread_figure`` are the same diverging chart
        # twice: once counting movers, once summing the signed spread change.
        # Both are drawn with increases to the right of a centred zero line and
        # decreases to the left, and both cut to Top 10 with the tail inside one
        # Others bar. The full list is the table underneath them.
        self.movers_figure = None
        self.spread_figure = None
        self.increase_figure = None
        self.decrease_figure = None
        self.path_figure_widget = None
        self._charts_live = charts.plotly_available()
        if self._charts_live:
            self.movers_figure = charts.comparison_figure(
                charts.comparison_spec([], {}, {}, (), config.DEFAULT_DIMENSION, 0)
            )
            self.spread_figure = charts.comparison_figure(
                charts.comparison_spec(
                    [],
                    {},
                    {},
                    (),
                    config.DEFAULT_DIMENSION,
                    0,
                    value_format="spread",
                )
            )
            self.increase_figure = charts.change_figure(
                charts.change_spec(None, "Increase", config.DEFAULT_SPREAD_TYPE)
            )
            self.decrease_figure = charts.change_figure(
                charts.change_spec(None, "Decrease", config.DEFAULT_SPREAD_TYPE)
            )
            self.path_figure_widget = charts.path_figure(
                charts.path_spec(None, config.DEFAULT_SPREAD_TYPE)
            )
        # Every chart sits in a width-locked HBox, as in FI Index Change: the
        # HBox alone does not size a FigureWidget on Desktop, so the Plotly
        # layout carries the same fixed width.
        self.bucket_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.change_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.path_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        # The full bucket table sits directly under the two bucket charts, and
        # the per-bond daily table directly under the path chart. Each ranked
        # table lives directly under its own chart, inside the same box, so
        # nothing can be inserted between the bars and the rows they describe.
        self.bucket_table = _PickTable(self._on_bucket_pick)
        self.increase_table = _PickTable(self._show_security)
        self.decrease_table = _PickTable(self._show_security)
        self.daily_table = _PickTable(self._show_security)
        # One "Display Top" box and one Refresh button per ranked panel, drawn
        # above that panel's chart. Two boxes mean two independent panels: an
        # empty increase side can be widened without touching the decreases.
        # Neither handler builds a request.
        self.display_top_inputs: dict[str, object] = {}
        self.display_top_buttons: dict[str, object] = {}
        self.display_top_notes: dict[str, object] = {}
        for side in ("increases", "decreases"):
            self.display_top_inputs[side] = widgets.IntText(
                value=self._display_top[side],
                description=config.DISPLAY_TOP_LABEL,
                layout=widgets.Layout(width="190px"),
            )
            self.display_top_buttons[side] = widgets.Button(
                description=config.DISPLAY_TOP_REFRESH_LABEL,
                layout=widgets.Layout(width="110px"),
            )
            self.display_top_notes[side] = widgets.HTML(value="")
        # Click-to-inspect: the selected security, its row, and its series.
        self.detail_title = widgets.HTML(value=_DETAIL_PROMPT_HTML)
        self.detail_view = widgets.HTML(value="")

        # --------------------------------------------------------------
        # Export Excel tab: copy/paste tables, no file is written
        # --------------------------------------------------------------
        self.export_view = widgets.Dropdown(
            description="Data",
            options=list(config.EXPORT_VIEWS),
            value="increases",
            layout=widgets.Layout(width="280px"),
        )
        self.export_box = widgets.VBox(layout=widgets.Layout(width="100%"))
        self.export_box.children = (widgets.HTML("<p>No run loaded.</p>"),)
        self.export_note = widgets.HTML(value="")
        self.export_body = widgets.VBox(
            [
                widgets.HTML(
                    "<p style='margin:4px 0;color:#666'>Pick a table, then select the "
                    "whole table, copy it, and paste it into Excel. The first data row "
                    "repeats the column names so the header is kept. No file is written."
                    "</p>"
                ),
                self.export_view,
                self.export_box,
                self.export_note,
            ],
            layout=widgets.Layout(width="100%"),
        )

        self.main_tab = widgets.VBox(
            [
                widgets.HTML(
                    "<p>A Bloomberg request runs only after Update is clicked. "
                    "Choose the universe source, then type its value; every field "
                    "starts empty "
                    f"(Index example: {escape(config.DEFAULT_INDEX)}). "
                    "Index membership is as of the end date; an AIM account uses "
                    "that account's holdings; a Bond is that one security. "
                    "AIM vs Index ranks both books in one Update and keeps them "
                    "apart. Changes stay in source spread units; review the "
                    "returned values and units in Terminal before relying on "
                    "them.</p>"
                ),
                # Header row: universe source and the input(s) it reads, then
                # Spread and Update. The date pair stays on its own line so a
                # narrow notebook cannot wrap one date away from its partner.
                self.universe_row,
                widgets.HBox([self.spread_type, self.update_button, self.cache_button]),
                widgets.HBox([self.start_date, self.end_date]),
                self.status,
                self.detail,
                self.log,
                self.headline,
                # Group by at the far left of its own row, then the five
                # dimension boxes beneath it, in the FI Index Change order.
                widgets.HBox(
                    [self.dimension_input],
                    layout=widgets.Layout(flex_flow="row wrap"),
                ),
                widgets.HBox(
                    [*self.filters.values()],
                    layout=widgets.Layout(flex_flow="row wrap"),
                ),
                self.bucket_box,
                self.change_box,
                self.detail_title,
                self.detail_view,
                self.path_box,
            ],
            layout=widgets.Layout(width="100%"),
        )
        self.tabs = widgets.Tab(
            children=[self.main_tab, self.export_body],
            titles=config.TAB_TITLES,
            layout=widgets.Layout(width="100%"),
        )
        self.tabs.selected_index = config.TAB_MAIN
        self.container = widgets.VBox([widgets.HTML(TITLE_HTML), self.tabs])

        self._refresh_universe_row()
        self._refresh_initial_status()
        self._render_chart_shell()

    def _set_bond_mode(self, active: bool) -> None:
        """Bond source shows only the path chart and its daily table.

        A single-security run has no bucket, no ranked movers, and no spread
        change to group, so the two diverging charts, the full bucket table, and
        both Top 10 charts are removed rather than left empty. The daily table
        lives inside ``path_box`` with the chart, so it stays.
        """
        self.bucket_box.layout.display = "none" if active else ""
        self.change_box.layout.display = "none" if active else ""
        if active:
            self._selected_bucket = None

    # ------------------------------------------------------------------
    # Universe inputs: one row, rebuilt from the chosen source
    # ------------------------------------------------------------------

    @property
    def universe_input(self):
        """The input the current source reads, under one name for the preview.

        ``Index`` and ``AIM vs Index`` read the Index field, ``AIM account`` the
        AIM field, and ``Bond`` the Bond field. The comparison source also shows
        ``aim_input``; both are on screen at once.
        """
        key = self._source_key()
        if key == "aim":
            return self.aim_input
        if key == "bond":
            return self.bond_input
        return self.index_input

    def _source_key(self) -> str:
        """The stored source key for the dropdown label, never raising."""
        return config.UNIVERSE_SOURCES.get(
            self.universe_source.value, config.DEFAULT_UNIVERSE_SOURCE
        )

    def _visible_inputs(self) -> list:
        """The input widgets the chosen source reads, in display order."""
        key = self._source_key()
        if key == "aim":
            return [self.aim_input]
        if key == "bond":
            return [self.bond_input]
        if key == config.COMPARISON_SOURCE:
            # The comparison reads an AIM account against an index, so the AIM
            # code comes first and the index it is compared with follows. The
            # request itself is unchanged: each value is still read from its own
            # field, never from the other one's box.
            return [self.aim_input, self.index_input]
        return [self.index_input]

    def _refresh_universe_row(self) -> None:
        """Rebuild the header row for the chosen source. Local only; no request.

        The typed values are kept, so switching source and back does not lose
        what the operator typed, and switching to the comparison source starts
        with the Index field already holding the value they were looking at.
        """
        self.universe_row.children = (
            self.universe_source,
            *self._visible_inputs(),
        )
        self.index_input.description = "Index"
        self.index_input.placeholder = config.DEFAULT_INDEX
        self.aim_input.description = "AIM code"
        self.aim_input.placeholder = "ABC123"
        self.bond_input.description = "Bond"

        # A Bond run has no bucket to group, so its chart area is hidden here,
        # before any request, the same way the input row is rebuilt.
        self._set_bond_mode(self._source_key() == "bond")

    def _field_values(self) -> dict[str, str]:
        """The typed value of every input, normalised for display only."""
        return {
            "index": " ".join(str(self.index_input.value or "").split()),
            "aim": str(self.aim_input.value or "").strip(),
            "bond": " ".join(str(self.bond_input.value or "").split()),
        }

    # ------------------------------------------------------------------
    # Charts shell
    # ------------------------------------------------------------------

    def _chart_slot(self, figure, spec: dict):
        """A chart inside a width-locked HBox, or its table fallback."""
        if figure is not None:
            inner = figure
        else:
            inner = widgets.HTML(charts.html_fallback(spec))
        return widgets.HBox(
            [inner],
            layout=widgets.Layout(width=config.CHART_WIDTH, overflow="visible"),
        )

    def _slot_reuse(self, slot, figure, spec: dict) -> None:
        """Update a chart slot in place instead of rebuilding its container.

        A `FigureWidget` that has already been displayed must not be moved to a
        new parent. Assigning it into a freshly built `HBox` re-parents it, and
        on Desktop that leaves the front end showing an empty card while the
        figure object itself holds every point: the tables around it — ordinary
        widget output — kept their numbers, which is exactly the report. The two
        Top 10 charts never hit this because their containers are built once in
        `_render_chart_shell()` and only `apply_change()` runs afterwards.

        So the slot keeps its container, and a rebuild only happens when the kind
        of child has to change: a chart appearing where a table fallback was
        drawn, or the reverse on a kernel without Plotly. A slot that is already
        a single-`HBox` holding the same figure is left alone.
        """
        children = list(getattr(slot, "children", ()) or ())
        current = children[0] if len(children) == 1 else None
        if figure is not None and current is figure:
            return
        if figure is None and isinstance(current, widgets.HTML):
            # Same widget, new text: no re-parenting, no lost scroll position.
            current.value = charts.html_fallback(spec)
            return
        slot.children = tuple(self._chart_slot(figure, spec).children)

    def _display_top_bar(self, side: str):
        """The "Display Top" row drawn above one ranked panel's chart.

        The box, its Refresh button, and its note sit on one HBox, above the
        chart, so the control reads as belonging to that panel and not to the
        screen as a whole.
        """
        return widgets.HBox(
            [
                self.display_top_inputs[side],
                self.display_top_buttons[side],
                self.display_top_notes[side],
            ],
            layout=widgets.Layout(width="100%", align_items="center"),
        )

    def _render_chart_shell(self) -> None:
        """Put the empty chart slots (or their table fallbacks) on screen once."""
        self.bucket_box.children = (
            self._chart_slot(
                self.movers_figure,
                charts.comparison_spec(
                    [], {}, {}, (), config.DEFAULT_DIMENSION, 0
                ),
            ),
            self._chart_slot(
                self.spread_figure,
                charts.comparison_spec(
                    [],
                    {},
                    {},
                    (),
                    config.DEFAULT_DIMENSION,
                    0,
                    value_format="spread",
                ),
            ),
            self.bucket_table.box,
        )
        # The two-book run draws both books inside ``bucket_box``; nothing is
        # drawn here.
        # Display Top row, chart, its table, then the same for the other side:
        # the top row belongs to exactly one panel, and the table is the next
        # widget after the bars it lists, with nothing between them.
        self.bucket_table.render(
            blocks=[
                {
                    "title": f"{config.DEFAULT_DIMENSION} buckets",
                    "frame": None,
                    "key_column": "Bucket",
                    "note": "",
                }
            ]
        )
        self.increase_table.render(
            blocks=[{"title": f"Top {config.TOP_N} increases", "frame": None, "key_column": "ID"}]
        )
        self.decrease_table.render(
            blocks=[{"title": f"Top {config.TOP_N} decreases", "frame": None, "key_column": "ID"}]
        )
        self.change_box.children = (
            self._display_top_bar("increases"),
            self._chart_slot(
                self.increase_figure, charts.change_spec(None, "Increase", "")
            ),
            self.increase_table.box,
            self._display_top_bar("decreases"),
            self._chart_slot(
                self.decrease_figure, charts.change_spec(None, "Decrease", "")
            ),
            self.decrease_table.box,
        )
        self.daily_table.render(
            blocks=[{"title": "Daily spread observations", "frame": None, "key_column": "Date"}]
        )
        self.path_box.children = (
            self._chart_slot(
                self.path_figure_widget,
                charts.path_spec(
                    None,
                    "",
                    selected=None,
                    note=self._path_prompt(),
                ),
            ),
            self.daily_table.box,
        )

    def _bind_events(self) -> None:
        if self._events_bound:
            return
        self.update_button.on_click(self._on_update)
        self.cache_button.on_click(self._on_load_cached)
        # Local only: an edit marks the loaded tables stale and asks for Update.
        # No handler here builds a request.
        self.universe_source.observe(self._on_source_change, names="value")
        for widget in (
            self.index_input,
            self.aim_input,
            self.bond_input,
            self.spread_type,
            self.start_date,
            self.end_date,
        ):
            widget.observe(self._on_selection_change, names="value")
        # Filters and the grouping dimension are local views over frames that
        # are already in memory. They never reach the request layer.
        for widget in self.filters.values():
            widget.observe(self._on_view_change, names="value")
        self.dimension_input.observe(self._on_view_change, names="value")
        # Display Top is a view control too: its Refresh redraws from memory. A
        # typed value alone does nothing, which is what the button is for.
        for side, button in self.display_top_buttons.items():
            button.on_click(
                lambda _button, side=side: self._on_display_top(side)
            )
        self.export_view.observe(self._on_export_view_change, names="value")
        self._bind_chart_clicks()
        self._events_bound = True

    def _bind_chart_clicks(self) -> None:
        """Wire a bar or a line click to the detail panel.

        ``FigureWidget`` click payloads differ between plotly versions and
        between a bar and a scatter trace, so the handler reads whatever point
        payload arrived and ignores a click it cannot attribute. It never
        raises at the user.
        """
        for figure in (
            self.movers_figure,
            self.spread_figure,
            self.increase_figure,
            self.decrease_figure,
            self.path_figure_widget,
        ):
            if figure is None:
                continue
            try:
                figure.on_click(self._on_chart_click)
            except Exception:
                # A plotly build without on_click support leaves the detail
                # panel on its instruction text; the tables still work.
                pass

    def _on_chart_click(self, trace, points, _state=None) -> None:
        try:
            identifier = self._point_identifier(trace, points)
        except Exception:
            identifier = None
        if not identifier:
            return
        self._show_security(identifier)

    @staticmethod
    def _point_identifier(trace, points):
        """Best-effort security ID from a click payload."""
        for attr in ("customdata", "ids"):
            values = getattr(points, attr, None)
            if not values:
                continue
            for value in values:
                if isinstance(value, (list, tuple)) and value:
                    return str(value[0])
                if value not in (None, ""):
                    return str(value)
        # A bar chart's y value is the security label when the label is the ID.
        for attr in ("y", "x"):
            values = getattr(points, attr, None)
            if values:
                for value in values:
                    text = str(value or "").strip()
                    if text:
                        return text
        return None

    def _show_security(self, identifier: str) -> None:
        """Render one security from the frames already in memory.

        In the two-book comparison the same ID can be a member of the index and
        a holding of the account, so every matching row is shown, each under its
        book heading, rather than one row silently standing for both.
        """
        self._selected_id = identifier
        self.detail_title.value = (
            f"<b>Selected security:</b> {escape(identifier)}"
            + self._filtered_out_note(identifier)
        )
        self.detail_view.value = self._security_html(identifier)
        # The path chart follows the selection: A, then B, then back to the
        # prompt when the selection is cleared. It never keeps drawing the
        # whole ranked list.
        self._render_path_chart()

    def _clear_selection(self) -> None:
        """Drop the click selection and return the path chart to its prompt."""
        self._selected_id = None
        self.detail_title.value = (
            "<b>Selected security</b><br>Click a bar or a line to inspect one security."
        )
        self.detail_view.value = ""
        self._render_path_chart()

    def _filtered_out_note(self, identifier: str) -> str:
        """Say so when the selected ID is hidden by the current filters.

        The row and its series are still shown from the loaded run, because the
        operator asked for that security by name. Without this note the panel
        would look like it is still on the chart.
        """
        frames = getattr(self, "_frames", None) or {}
        loaded = any(
            isinstance(frame, pd.DataFrame)
            and not frame.empty
            and "ID" in frame.columns
            and bool((frame["ID"].astype(str) == identifier).any())
            for frame in frames.values()
        )
        if not loaded:
            return ""
        visible = self._visible_frames()
        shown = any(
            isinstance(frame, pd.DataFrame)
            and not frame.empty
            and "ID" in frame.columns
            and bool((frame["ID"].astype(str) == identifier).any())
            for frame in visible.values()
        )
        if shown:
            return ""
        return (
            "<br><span style='color:#8a5a00'>Hidden by the current filters: "
            "this row is shown from the loaded run, but it is not in the "
            "charts or the headline count.</span>"
        )

    def _security_html(self, identifier: str) -> str:
        frames = getattr(self, "_frames", None) or {}
        sections = []
        matches = []
        for label in ("increases", "decreases"):
            frame = frames.get(label)
            if frame is None or frame.empty or "ID" not in frame.columns:
                continue
            row = frame.loc[frame["ID"].astype(str) == identifier]
            if not row.empty:
                matches.append((label.title(), row))
        for label, row in matches:
            book = ""
            if config.UNIVERSE_COLUMN in row.columns and not row.empty:
                book = str(row.iloc[0].get(config.UNIVERSE_COLUMN) or "")
            heading = f"{book} {label} row".strip()
            sections.append(
                f"<h4>{escape(heading)}</h4>"
                + _table_html(
                    _spread_headers(
                        row.reset_index(drop=True), self._spread_label()
                    )
                )
            )
        series = frames.get("series")
        if series is not None and not series.empty and "ID" in series.columns:
            rows = series.loc[series["ID"].astype(str) == identifier]
            if not rows.empty:
                sections.append(
                    "<h4>Spread observations</h4>"
                    + _table_html(
                        _spread_headers(
                            rows.reset_index(drop=True), self._spread_label()
                        )
                    )
                )
        if not sections:
            return (
                "<p>No loaded row matches this selection. It may belong to a "
                "run that has since been replaced; click Update to refresh.</p>"
            )
        return "".join(sections)

    def _on_source_change(self, _change) -> None:
        """Rebuild the header row for the chosen source. Local only; never fetches.

        The status bar is re-stated too. A source switch can hide the bucket and
        Top 10 panels (Bond) or change which field the next run reads, so leaving
        a green ``Updated`` above them would present an old run as the answer to
        the new controls.
        """
        self._refresh_universe_row()
        self._refresh_selection_state()

    # ------------------------------------------------------------------
    # Status bar
    # ------------------------------------------------------------------

    def _set_status(self, phase: str, detail: str = "", activity: str | None = None) -> None:
        if activity is None:
            activity = "Processing" if self._running else "Idle"
        detail_text = f" {escape(detail)}" if detail else ""
        self.status.value = (
            f"<p style='margin:2px 0'>{_phase_markup(phase)}{detail_text}</p>"
            + _environment_markup(activity)
        )

    def _set_detail(self, content: str) -> None:
        self.detail.value = content

    def _clear_detail(self) -> None:
        self.detail.value = ""

    def _clear_log(self) -> None:
        with self.log:
            self.log.clear_output(wait=True)

    def _log_line(self, message: str) -> None:
        # An HTML line rather than print(): the Output widget then shows the same
        # step log on Desktop and in the local preview.
        with self.log:
            display(widgets.HTML(f"<div style='margin:1px 0'>{escape(message)}</div>"))

    def _progress(self, message: str) -> None:
        self._set_status("Loading", message, "Processing")
        self._log_line(message)

    def _refresh_initial_status(self) -> None:
        self._set_status("Idle", "Click Update to run the request.", "Idle")
        self._set_detail(
            _info_box(
                f"Top {config.TOP_N}. "
                "This notebook never starts a request by itself; Update is the "
                "only action that sends one.",
                "neutral",
            )
        )

    def render(self):
        """Return the widget tree without issuing a data request."""
        # Idempotent re-bind, exactly as FI Index Change does: a status refresh
        # or a partial rebuild must never leave the controls without handlers.
        self._bind_events()
        return self.container

    def _clear_results(self) -> None:
        """Drop the last run's validation notes and log lines.

        The effective-date table is no longer on screen, so there is nothing to
        clear visually; the notes and the step log are what remain of that run.
        """
        self._validation_notes = []
        try:
            with self.log:
                self.log.clear_output(wait=True)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Selection state: local comparison against the loaded run
    # ------------------------------------------------------------------

    def _selection(self) -> dict[str, str]:
        """The visible control values. No validation and no request."""
        start = self.start_date.value
        end = self.end_date.value
        values = self._field_values()
        return {
            "source": str(self.universe_source.value or ""),
            "index": values["index"],
            "aim": values["aim"],
            "bond": values["bond"],
            "spread": str(self.spread_type.value or ""),
            "start": start.isoformat() if isinstance(start, date) else str(start),
            "end": end.isoformat() if isinstance(end, date) else str(end),
        }

    def _on_selection_change(self, _change) -> None:
        self._refresh_selection_state()

    def _refresh_selection_state(self) -> None:
        """Mark the loaded tables stale after a local edit. Never fetches."""
        if self._running or self._loaded is None:
            return
        current = self._selection()
        if all(current[key] == self._loaded.get(key) for key in current):
            # The controls are back on the loaded values, so the tables are not
            # stale after all. Restore the status that produced them rather than
            # leaving a false "Please Click Update" that invites a second,
            # unnecessary Bloomberg run.
            if self._loaded_status:
                self._set_status(self._loaded_status[0], self._loaded_status[1], "Idle")
            return
        self._set_status(
            "Please Click Update",
            "Universe source, universe value, spread, or dates changed; the "
            "tables below are from the previous run.",
            "Idle",
        )

    # ------------------------------------------------------------------
    # Local view: filters, grouping, charts, click detail
    # ------------------------------------------------------------------

    def _current_filters(self) -> dict[str, set[str]]:
        """The picked filter values, with the ``(All)`` marker dropped.

        ``(All)`` is the widget's rest state, not a value in the data. A pick
        alongside it still filters, so only the marker itself is removed.
        """
        picked: dict[str, set[str]] = {}
        for label, column in config.FILTER_COLUMNS:
            selected = set(self.filters[label].value or ()) - {config.ALL_FILTER_LABEL}
            if selected:
                picked[column] = selected
        return picked

    def _reset_filter_picks(self) -> None:
        """Return the five dimension filters to ``(All)`` and drop their options.

        A refusal clears the figures, so a pick that survived it was filtering
        an empty table while ``_current_filters()`` still reported a value. The
        options are emptied to ``(All)`` for the same reason: an option list
        that outlived its rows invites a pick that can never match again. The
        next successful run repopulates both from its own rows.
        """
        for label, _column in config.FILTER_COLUMNS:
            widget = self.filters.get(label)
            if widget is None:
                continue
            try:
                widget.unobserve(self._on_view_change, names="value")
            except Exception:
                pass
            try:
                widget.value = ()
                widget.options = [config.ALL_FILTER_LABEL]
                widget.value = (config.ALL_FILTER_LABEL,)
            finally:
                try:
                    widget.observe(self._on_view_change, names="value")
                except Exception:
                    pass

    def _reset_detail_panel(self) -> None:
        """Put the selected-security panel back to its prompt.

        It renders one bond's row and spread numbers, so leaving it populated
        under a red status is the same stale-number read the figures are cleared
        to prevent. The widgets are written directly instead of calling
        ``_clear_selection()`` because that method also redraws the path chart,
        and the caller clears the frames first.
        """
        self.detail_title.value = _DETAIL_PROMPT_HTML
        self.detail_view.value = ""

    def _refresh_filter_options(self) -> None:
        """Repopulate the filters from the rows just loaded.

        The options are cleared before they are reassigned: the previous pick
        may not exist in the new run, and assigning options while a missing
        value is still selected raises a trait error instead of updating.
        """
        frames = [self._frames.get("increases"), self._frames.get("decreases")]
        choices = filter_choices([frame for frame in frames if frame is not None])
        for label, column in config.FILTER_COLUMNS:
            widget = self.filters[label]
            try:
                widget.unobserve(self._on_view_change, names="value")
            except Exception:
                pass
            try:
                widget.value = ()
                widget.options = [
                    config.ALL_FILTER_LABEL,
                    *choices.get(column, []),
                ]
                widget.value = (config.ALL_FILTER_LABEL,)
            finally:
                try:
                    widget.observe(self._on_view_change, names="value")
                except Exception:
                    pass

    def _on_view_change(self, _change=None) -> None:
        """Redraw from memory after a filter or grouping change."""
        if self._running or self._rendering or not self._frames:
            return
        self._render_view()
        # The export tables follow the same filters, so they are refreshed from
        # memory here too. No request is built.
        self._refresh_export_tables()

    def _visible_frames(self) -> dict[str, "pd.DataFrame"]:
        """The two ranked sides after the dimension filters are applied."""
        picked = self._current_filters()
        return {
            label: apply_dimension_filters(self._frames.get(label), picked)
            for label in ("increases", "decreases")
        }

    def _books(self, frames: list[pd.DataFrame]) -> tuple[str, ...]:
        """The books present in the loaded rows, in the comparison's own order.

        ``config.COMPARISON_BOOK_ORDER`` is AIM first, so the heading, the
        diverging chart, and the two Top 10 tables all read top to bottom in
        the same book order.
        """
        seen: list[str] = []
        for frame in frames:
            if frame is None or frame.empty:
                continue
            if config.UNIVERSE_COLUMN not in frame.columns:
                continue
            for value in frame[config.UNIVERSE_COLUMN].astype(str):
                text = value.strip()
                if text and text not in seen:
                    seen.append(text)
        preferred = list(config.COMPARISON_BOOK_ORDER)
        order = [label for label in preferred if label in seen]
        return tuple(order + [label for label in seen if label not in order])

    def _render_view(self) -> None:
        """Charts, headline, and detail panel for the current filter state."""
        if self._rendering:
            return
        self._rendering = True
        try:
            self._render_view_body()
        finally:
            self._rendering = False

    def _render_view_body(self) -> None:
        visible = self._visible_frames()
        # The Export Excel tab reads the same two frames, so what is copied out
        # is what is on screen. A filter change must refresh both.
        self._visible = visible
        combined = [_frame for _frame in visible.values() if _frame is not None]
        combined = [frame for frame in combined if not frame.empty]

        dimension_label = self.dimension_input.value or config.DEFAULT_DIMENSION
        dimension = config.DIMENSIONS.get(dimension_label, dimension_label)

        # A bucket pick is only meaningful inside the dimension it was made on.
        # Switching Group by (or a filter that removes that bucket) would
        # otherwise leave the two Top 10 charts scoped to a bucket that no
        # longer exists, which reads as "this run has no movers".
        self._drop_stale_bucket(combined, dimension)

        # The two Top 10 charts are narrowed to the selected bucket when the
        # operator clicked one; otherwise they cover everything the filters
        # left. Either way the table under a chart lists that chart's own rows.
        scoped = self._bucket_scoped(visible, dimension)
        # The Display Top box then decides how many of those rows are drawn. It
        # slices memory only, per book, so one panel can be widened or shortened
        # without a request and without disturbing the other panel.
        drawn = {
            "increases": self._display_top_rows(scoped.get("increases"), "increases"),
            "decreases": self._display_top_rows(scoped.get("decreases"), "decreases"),
        }
        # The headline counts what the Top 10 charts are actually drawing, so a
        # bucket pick cannot leave "19 mover(s) charted" above two rows and a
        # Display Top of 3 cannot leave it claiming 19 either.
        scoped_frames = [
            frame
            for frame in drawn.values()
            if isinstance(frame, pd.DataFrame) and not frame.empty
        ]
        total = sum(len(frame) for frame in scoped_frames) if scoped_frames else 0
        cut_text = ""
        for side in ("increases", "decreases"):
            source = scoped.get(side)
            available = 0 if not isinstance(source, pd.DataFrame) else len(source)
            shown_rows = 0 if not isinstance(drawn.get(side), pd.DataFrame) else len(drawn[side])
            if available and shown_rows < available:
                count = self._display_top.get(side, config.DEFAULT_DISPLAY_TOP)
                cut_text = (
                    f"Display Top {count} per book "
                    f"({shown_rows} of {available} row(s) drawn) \u00b7 "
                )
                break
        self.headline.value = self._headline_html(total, scoped, cut_text)

        books = self._chart_books(combined)
        self._render_bucket_panel(combined, dimension, dimension_label, books)

        spread_label = self._spread_label()
        specs = {
            "Increase": charts.change_spec(
                drawn.get("increases"),
                "Increase",
                spread_label,
                top_n=self._display_top.get("increases"),
            ),
            "Decrease": charts.change_spec(
                drawn.get("decreases"),
                "Decrease",
                spread_label,
                top_n=self._display_top.get("decreases"),
            ),
        }
        heading_suffix = (
            f" \u00b7 {self._selected_bucket}" if self._selected_bucket else ""
        )
        # A note explains a short panel: either the box asks for more than the
        # run fetched, or fewer rows exist in this bucket. It is cleared when the
        # count and the rows agree, so a corrected value leaves no stale warning.
        for side in ("increases", "decreases"):
            note = self.display_top_notes.get(side)
            if note is not None:
                note.value = self._display_top_error.get(side) or self._display_top_note(
                    side, scoped.get(side), drawn.get(side)
                )
        increase_count = self._display_top.get("increases", config.DEFAULT_DISPLAY_TOP)
        decrease_count = self._display_top.get("decreases", config.DEFAULT_DISPLAY_TOP)
        self.increase_table.render(
            *self._ranked_table_blocks(
                drawn.get("increases"),
                f"Top {increase_count} increases: {spread_label} change"
                + heading_suffix,
                f"Top {increase_count} increases: {spread_label} change",
            )
        )
        self.decrease_table.render(
            *self._ranked_table_blocks(
                drawn.get("decreases"),
                f"Top {decrease_count} decreases: {spread_label} change"
                + heading_suffix,
                f"Top {decrease_count} decreases: {spread_label} change",
            )
        )
        if self.increase_figure is not None:
            charts.apply_change(self.increase_figure, specs["Increase"])
            charts.apply_change(self.decrease_figure, specs["Decrease"])
        else:
            # Without Plotly there are no figures to update in place, so the two
            # SVG slots are replaced. The Display Top row above each chart stays
            # the same widget object, so an open box keeps its focus and value.
            self.change_box.children = (
                self._display_top_bar("increases"),
                self._chart_slot(None, specs["Increase"]),
                self.increase_table.box,
                self._display_top_bar("decreases"),
                self._chart_slot(None, specs["Decrease"]),
                self.decrease_table.box,
            )

        self._render_path_chart()

        if self._selected_id:
            self.detail_view.value = self._security_html(self._selected_id)

    # ------------------------------------------------------------------
    # Bucket panel: two diverging charts and the full bucket table
    # ------------------------------------------------------------------

    def _chart_books(self, combined: list[pd.DataFrame]) -> tuple[str, ...]:
        """The book labels the two bucket charts draw.

        A two-book run keeps AIM above Index. A one-book run gets that book's
        own label, which is what makes the same chart function usable on both
        screens: with one book the label prefix is suppressed and the bars keep
        the direction colours.

        A comparison always keeps both books even when one returned no rows.
        Dropping the empty book would turn the chart, the table, and the
        headline into a single-book run with no label prefix, which reads as
        "the two books are the same" instead of "one book is empty".
        """
        if self._comparison:
            return tuple(config.COMPARISON_BOOK_ORDER)
        found = self._books(combined)
        if found:
            return found
        source_key = self._source_key()
        return (config.COMPARISON_LABELS["aim"] if source_key == "aim" else config.COMPARISON_LABELS["index"],)

    def _bucket_slots(self) -> list:
        """The two bucket chart slots, built once and then only updated.

        Building them per render re-parents the `FigureWidget` into a new `HBox`
        every time, which on Desktop leaves the card blank while the figure holds
        the data. The list is replaced only when the figures are rebuilt (a
        kernel without Plotly), so a normal Update mutates the same objects.
        """
        slots = getattr(self, "_bucket_chart_slots", None)
        stale = slots is None or any(
            figure is not None and _slot_child(slot) is not figure
            for slot, figure in zip(slots, (self.movers_figure, self.spread_figure))
        )
        if stale:
            slots = [
                self._chart_slot(
                    self.movers_figure,
                    charts.comparison_spec(
                        [], {}, {}, (), config.DEFAULT_DIMENSION, 0
                    ),
                ),
                self._chart_slot(
                    self.spread_figure,
                    charts.comparison_spec(
                        [],
                        {},
                        {},
                        (),
                        config.DEFAULT_DIMENSION,
                        0,
                        value_format="spread",
                    ),
                ),
            ]
            self._bucket_chart_slots = slots
        return slots

    def _render_bucket_panel(
        self,
        combined: list[pd.DataFrame],
        dimension: str,
        dimension_label: str,
        books: tuple[str, ...],
    ) -> None:
        """Two diverging charts — movers, then spread — and the full table.

        Both charts plot each book once, increases to the right of a centred
        zero line and decreases to the left, on one symmetric scale per chart.
        Both cut to Top 10 with the remaining buckets inside one ``Others`` bar;
        the table underneath is never cut, so a bucket inside ``Others`` still
        has its own row. The table is also the place a bucket is picked: a click
        on any of its rows narrows the two Top 10 charts below to that bucket.
        """
        movers_labels, movers_up, movers_down = bucket_diverging_rows(
            combined, dimension, books, metric="count"
        )
        spread_labels, spread_up, spread_down = bucket_diverging_rows(
            combined, dimension, books, metric="spread"
        )
        spread_label = self._spread_label()
        # In a two-book run the title names both books, so the chart cannot be
        # mistaken for the single-book one above the same table.
        book_suffix = (
            f" \u2014 {config.COMPARISON_LABELS['aim']} vs "
            f"{config.COMPARISON_LABELS['index']}"
            if self._comparison
            else ""
        )
        # A chart with no traces is an empty card: `comparison_spec` builds one
        # trace per book, so an empty `books` tuple yields no bar at all — not a
        # blank chart with axes, an empty one. An empty tuple is therefore never
        # passed on; `_chart_books()` supplies the one-book label, so the charts
        # and the table below them always describe the same book.
        if not books:
            books = self._chart_books(combined)
        movers_spec = charts.comparison_spec(
            movers_labels,
            movers_up,
            movers_down,
            books,
            dimension_label,
            0,
            title=f"{config.MOVERS_CHART_LABEL} {dimension_label}{book_suffix}",
            x_title="Number of ranked movers " + config.DIVERGING_AXIS_HINT,
        )
        spread_spec = charts.comparison_spec(
            spread_labels,
            spread_up,
            spread_down,
            books,
            dimension_label,
            0,
            value_format="spread",
            title=(
                f"{config.SPREAD_CHART_LABEL} {dimension_label}"
                f"{book_suffix} ({spread_label})"
            ),
            x_title=f"{spread_label} change, source units "
            + config.DIVERGING_AXIS_HINT,
        )
        # A chart with no traces is an empty card, and `comparison_spec` builds
        # one trace per book: an empty `books` tuple yields no bar at all, not a
        # blank chart with axes. So an empty tuple is never passed through. The
        # one-book label from `_chart_books` is the fallback, which keeps the two
        # diverging charts and the table below them describing the same book.
        chart_slots = self._bucket_slots()
        if self.movers_figure is not None:
            charts.apply_comparison(self.movers_figure, movers_spec)
            charts.apply_comparison(self.spread_figure, spread_spec)
        else:
            self._slot_reuse(chart_slots[0], None, movers_spec)
            self._slot_reuse(chart_slots[1], None, spread_spec)

        table = bucket_table(combined, dimension, books if self._comparison else ())
        note = (
            "Full bucket list, largest first, in the same order as the two "
            "charts above (those cut to the Top "
            f"{config.BUCKET_CHART_TOP} and group the rest as Others). Increase "
            f"and Decrease {spread_label} are the signed sum of each bond's "
            f"change inside the bucket, in source units, so Increase "
            f"{spread_label} + Decrease {spread_label} = Net {spread_label} "
            "Change. A bucket spanning several currencies therefore sums "
            "spreads that are not currency-neutral; read it as movement inside "
            "that bucket, not as one tradable total. Click any row to narrow the "
            "two Top 10 charts below to that bucket; click it again to show every "
            "bucket."
            + (f" Showing: {self._selected_bucket}." if self._selected_bucket else "")
        )
        self.bucket_table.render(
            blocks=[
                {
                    "title": f"{dimension_label} buckets",
                    "frame": _spread_headers(table, spread_label),
                    "key_column": "Bucket",
                    "row_attribute": "Bucket",
                    "pick": None,
                    "note": note,
                }
            ]
        )
        # Same slot objects every render: only their `children` are set, and the
        # figures inside them are mutated. Reassigning the whole tuple with new
        # containers is what re-parented the chart and blanked the card.
        if len(self.bucket_box.children) != 3 or any(
            existing is not expected
            for existing, expected in zip(
                self.bucket_box.children, (*chart_slots, self.bucket_table.box)
            )
        ):
            self.bucket_box.children = (*chart_slots, self.bucket_table.box)

    def _drop_stale_bucket(
        self,
        combined: list[pd.DataFrame],
        dimension: str,
    ) -> None:
        """Clear the bucket pick when that bucket is not in the current rows.

        The pick is a view, not data, so it must not survive a change that
        removes its bucket: a new dimension, a filter, or a new run. Tested
        against the same bucket list the table is about to draw, so "the table
        shows it" and "the pick is valid" cannot disagree.
        """
        bucket = self._selected_bucket
        if not bucket:
            return
        table = bucket_table(combined, dimension, ())
        if table is None or table.empty or "Bucket" not in table.columns:
            self._selected_bucket = None
            return
        known = {label_key(value, config.DESCRIPTOR_BLANK) for value in table["Bucket"]}
        if label_key(bucket, config.DESCRIPTOR_BLANK) not in known:
            self._selected_bucket = None
            self._log_line(
                f"Bucket {bucket} is not in this {dimension} grouping; the "
                "bucket scope was cleared."
            )

    def _bucket_scoped(
        self,
        visible: dict[str, pd.DataFrame],
        dimension: str,
    ) -> dict[str, pd.DataFrame]:
        """The two ranked sides after the bucket pick, if one is active.

        A bucket pick is a local view over frames already in memory: it applies
        the same dimension column the charts group on, and it never narrows a
        BQL request. It goes through ``apply_dimension_filters`` rather than
        comparing labels itself, so the pick, the filter boxes, and the bucket
        table all decide "who is in this bucket" in exactly one place.
        """
        bucket = self._selected_bucket
        if not bucket:
            return visible
        scoped: dict[str, pd.DataFrame] = {}
        for side, frame in visible.items():
            if not isinstance(frame, pd.DataFrame) or frame.empty:
                scoped[side] = frame
                continue
            if dimension not in frame.columns:
                scoped[side] = frame
                continue
            scoped[side] = apply_dimension_filters(frame, {dimension: {bucket}})
        return scoped

    def _on_bucket_pick(self, bucket: str) -> None:
        """Toggle the bucket scope and redraw from memory. Never requests."""
        value = str(bucket or "").strip()
        self._selected_bucket = None if value == self._selected_bucket else value
        self._render_view()
        self._refresh_export_tables()

    # ------------------------------------------------------------------
    # Display Top: how many fetched rows each ranked panel draws
    # ------------------------------------------------------------------

    def _reset_display_top(self) -> None:
        """Put both Display Top boxes back to ``config.TOP_N``.

        Called for a new run and for a cleared screen: the count describes the
        rows on show, so it must not outlive them. The box value follows, because
        a box reading 3 above a panel drawing 10 would be a lie about the state.
        """
        for side in ("increases", "decreases"):
            self._display_top[side] = config.DEFAULT_DISPLAY_TOP
            widget = getattr(self, "display_top_inputs", {}).get(side)
            if widget is not None:
                widget.value = config.DEFAULT_DISPLAY_TOP
            note = getattr(self, "display_top_notes", {}).get(side)
            if note is not None:
                note.value = ""
        self._display_top_error = {}

    def _apply_display_top(self, side: str) -> bool:
        """Validate one Display Top box and store it. Returns True if applied.

        Validation is explicit rather than a widget bound, because a bound
        clamps silently: a typed ``0`` or ``999`` would become a number the
        operator never asked for. Here an out-of-range value is refused with a
        note and the panel keeps drawing the last applied count.
        """
        widget = self.display_top_inputs.get(side)
        note = self.display_top_notes.get(side)
        if widget is None or side not in self._display_top:
            return False
        raw = getattr(widget, "value", None)
        try:
            value = int(raw)
        except (TypeError, ValueError):
            value = None
        if value is None or value < 1 or value > config.DISPLAY_TOP_MAX:
            message = (
                "<span style='color:#c62828'>Display Top must be a whole "
                f"number from 1 to {config.DISPLAY_TOP_MAX}. The panel still "
                f"shows {self._display_top[side]}.</span>"
            )
            self._display_top_error[side] = message
            if note is not None:
                note.value = message
            return False
        self._display_top[side] = value
        self._display_top_error.pop(side, None)
        return True

    def _on_display_top(self, side: str) -> None:
        """Refresh one ranked panel from memory. Never requests."""
        if not self._apply_display_top(side):
            return
        # A refused value must not leave its red note above a freshly drawn
        # chart, so the render path clears it when the count is valid.
        self._render_view()
        self._refresh_export_tables()

    def _display_top_rows(self, frame, side: str):
        """The first ``Display Top`` rows per book, from memory only.

        A two-book run keeps the count per book, because one ``head(n)`` on the
        stacked frame would cut the second book out entirely — the same defect
        the candidate-ID builder was fixed for. Nothing is fetched here: the
        rows beyond what the run returned simply do not exist.
        """
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            return frame
        count = self._display_top.get(side, config.DEFAULT_DISPLAY_TOP)
        if count < 1:
            return frame.head(0)
        if config.UNIVERSE_COLUMN in frame.columns:
            books = self._books([frame])
            if len(books) > 1:
                column = frame[config.UNIVERSE_COLUMN].astype(str).str.strip()
                parts = []
                for book in books:
                    rows = frame.loc[column == book]
                    if not rows.empty:
                        parts.append(rows.head(count))
                if parts:
                    return pd.concat(parts)
                return frame.head(0)
        return frame.head(count)

    def _display_top_note(self, side: str, frame, drawn) -> str:
        """Why the panel draws fewer rows than the box asks for, if it does.

        In a two-book run the count is per book, so the note is per book too: a
        short AIM side must not be hidden behind a full Index side.
        """
        count = self._display_top.get(side, config.DEFAULT_DISPLAY_TOP)
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            return ""
        if count > config.TOP_N:
            shown = 0 if not isinstance(drawn, pd.DataFrame) else len(drawn)
            return (
                "<span style='color:#8a5a00'>Display Top "
                f"{count}: the last run fetched at most {config.TOP_N} row(s) per "
                f"book per direction, so {shown} are drawn. Raise Top N and press "
                "Update to fetch more.</span>"
            )
        short: list[str] = []
        books = self._books([frame])
        if len(books) > 1:
            column = frame[config.UNIVERSE_COLUMN].astype(str).str.strip()
            for book in books:
                available = int((column == book).sum())
                if 0 < available < count:
                    short.append(f"{book} {available}")
        else:
            available = len(frame)
            if 0 < available < count:
                short.append(f"{available} row(s)")
        if short:
            return (
                "<span style='color:#8a5a00'>Display Top "
                f"{count}: only {' / '.join(short)} available.</span>"
            )
        return ""

    def _ranked_table_blocks(
        self,
        frame: pd.DataFrame | None,
        title: str,
        base_title: str,
    ) -> tuple:
        """Blocks for one Top 10 table: one per book in a comparison.

        The grid is row-clickable, so a click on any cell of a row selects that
        bond and drives the path chart and its daily table.
        """
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            return (
                [{"title": base_title, "frame": None, "key_column": "ID"}],
            )
        columns = _display_columns(frame)
        # The headings name the spread type (Start OAS / End OAS / OAS Change).
        # Renamed here, on the copy that is drawn, so the frames behind the
        # charts and the click handlers keep their canonical column names.
        drawn = _spread_headers(frame.loc[:, columns], self._spread_label())
        books = self._books([frame])
        if len(books) <= 1:
            return (
                [
                    {
                        "title": title,
                        "frame": drawn,
                        "key_column": "ID",
                        "row_attribute": "ID",
                    }
                ],
            )
        shown = [column for column in columns if column != config.UNIVERSE_COLUMN]
        blocks: list[dict] = [
            {"title": title, "frame": None, "caption": True, "note": ""}
        ]
        for book in books:
            block = frame.loc[
                frame[config.UNIVERSE_COLUMN].astype(str).str.strip() == book
            ]
            if block.empty:
                continue
            blocks.append(
                {
                    "title": f"{book} ({len(block)} row(s))",
                    "frame": _spread_headers(
                        block.loc[:, shown or columns], self._spread_label()
                    ),
                    "key_column": "ID",
                    "row_attribute": "ID",
                }
            )
        return (blocks,)

    def _path_prompt(self) -> str:
        """What the path chart says before a bond has been clicked."""
        return (
            "Select a bond to view its spread path: click a bar, a line, or a "
            "ranked row."
        )

    def _render_path_chart(self) -> None:
        """The spread path of the one selected security, plus its daily rows.

        Nothing selected is its own state, with a sentence instead of an empty
        plot, and a selected ID that the series request did not cover says so
        by name. Either way the chart shows at most one line, and the table
        underneath lists only the observation dates that came back for that
        bond: a weekend, a holiday, or a day with no quote has no row, and no
        value is carried forward to fill it.
        """
        spread_label = self._spread_label()
        selected = self._selected_id
        start = self._frames.get("start")
        end = self._frames.get("end")
        wide = pd.DataFrame()
        note = self._path_prompt()
        if selected:
            wide = spread_paths(self._frames.get("series"), [selected])
            if wide.empty:
                note = (
                    f"No spread series was returned for {selected} in this "
                    "window. The ranked row stays on screen; its path does not."
                )
            else:
                note = ""
        spec = charts.path_spec(
            wide,
            spread_label,
            start,
            end,
            selected=selected,
            note=note,
        )
        if self.path_figure_widget is not None:
            charts.apply_paths(self.path_figure_widget, spec)
        # Same rule as the bucket slots: the path chart's container is kept, so
        # the figure is mutated in place instead of being re-parented into a new
        # HBox on every render (which showed an empty card on Desktop while the
        # spec held the points).
        chart_slot = getattr(self, "_path_chart_slot", None)
        if chart_slot is None or (
            self.path_figure_widget is not None
            and _slot_child(chart_slot) is not self.path_figure_widget
        ):
            chart_slot = self._chart_slot(self.path_figure_widget, spec)
            self._path_chart_slot = chart_slot
        elif self.path_figure_widget is None:
            self._slot_reuse(chart_slot, None, spec)

        daily = daily_spread_rows(self._frames.get("series"), selected or "")
        window = f" {start} \u2192 {end}" if start and end else ""
        if selected:
            title = f"{spread_label} daily observations \u00b7 {selected}{window}"
            table_note = (
                "One row per observation the window request returned. A weekend, "
                "a holiday, or a day with no quote has no row: nothing is filled "
                "and nothing is carried forward. The last column is the "
                "difference from the previous observation above it."
            )
        else:
            title = "Daily spread observations"
            table_note = ""
        self.daily_table.render(
            blocks=[
                {
                    "title": title,
                    # The column is the spread itself, so its heading names the
                    # spread type (OAS / Z / I) rather than a generic "Spread".
                    "frame": _spread_headers(daily, spread_label),
                    "note": table_note,
                }
            ]
        )
        if len(self.path_box.children) != 2 or (
            self.path_box.children[0] is not chart_slot
            or self.path_box.children[1] is not self.daily_table.box
        ):
            self.path_box.children = (chart_slot, self.daily_table.box)

    def _spread_label(self) -> str:
        loaded = self._loaded or {}
        return str(loaded.get("spread") or self.spread_type.value or "")

    def _headline_html(self, total: int, visible: dict, cut_text: str = "") -> str:
        """One line stating what the charts are currently showing."""
        picked = self._current_filters()
        loaded = self._loaded or {}
        shown = len(picked)
        filter_text = (
            f"{shown} filter(s) applied"
            if shown
            else "no filter (all returned movers)"
        )
        books = self._books([_frame for _frame in visible.values() if _frame is not None])
        book_text = ""
        if self._comparison and books:
            book_text = f"books <b>{escape(' vs '.join(books))}</b> \u00b7 "
        bucket_text = ""
        if self._selected_bucket:
            bucket_text = f"bucket <b>{escape(self._selected_bucket)}</b> \u00b7 "
        return (
            "<p style='margin:4px 0'>"
            f"<b>{total}</b> mover(s) charted \u00b7 {escape(filter_text)} \u00b7 "
            f"{book_text}{bucket_text}{escape(cut_text)}"
            f"grouped by <b>{escape(str(self.dimension_input.value or ''))}</b> \u00b7 "
            f"{escape(str(loaded.get('spread', self.spread_type.value or '')))} "
            f"{escape(str(loaded.get('start', '')))} \u2192 "
            f"{escape(str(loaded.get('end', '')))}</p>"
        )

    # ------------------------------------------------------------------
    # Failure surfaces
    # ------------------------------------------------------------------

    def _refuse(self, message: str) -> None:
        """Input refused before any request. The reason stays on the status bar."""
        self._loaded = None
        self._loaded_status = None
        # A refusal means nothing is loaded, so the previous run's receipt is
        # cleared with its figures rather than described as still available.
        self._field_status = {}
        self._request_log = []
        self._clear_results()
        self._reset_view()
        self._set_status("Refused", message, "Idle")
        self._set_detail(
            _info_box(
                f"<b>Request not sent.</b> {escape(message)}<br>"
                "Nothing was requested from Bloomberg; fix the input and click "
                "Update again.",
                "error",
            )
        )
        self._log_line(f"Refused: {message}")

    def _set_error(self, message: str, result=None) -> None:
        """A failure once the run had started. Diagnostics already collected stay."""
        self._loaded = None
        self._loaded_status = None
        self._clear_results()
        self._set_status("Error", message, "Idle")
        parts = [_info_box(f"<b>Update failed.</b> {escape(message)}", "error")]
        if result is not None:
            if result.errors:
                parts.append(
                    "<p>" + "<br>".join(escape(item) for item in result.errors) + "</p>"
                )
            if result.request_log:
                total = sum(float(entry["elapsed_sec"]) for entry in result.request_log)
                parts.append(
                    f"<p><b>Requests executed before the error:</b> "
                    f"{len(result.request_log)} (total {total:.2f} s).</p>"
                )
            for line in _field_failure_lines(result.field_status):
                self._log_line(line)
            # The receipt stays available after a failed merge: it is the
            # request metadata that explains what did arrive. Set before the
            # view is reset so the export tab picks it up.
            self._field_status = dict(result.field_status)
            self._request_log = list(result.request_log)
        self._reset_view()
        self._set_detail("".join(parts))
        self._log_line(message)

    def _reset_view(self) -> None:
        """Blank everything the last run put on screen.

        Fail closed. A red ``Refused`` or ``Error`` next to the previous run's
        headline, charts, and tables is the exact way an old number gets read as
        the new answer, so the figures are cleared together with the state that
        produced them. Local redraw only: no request is built here.
        """
        self._frames = {}
        self._comparison = False
        self._selected_id = None
        # The bucket pick is a view over the loaded rows, so it dies with them:
        # keeping it would narrow the next run's charts to a bucket of a run the
        # operator can no longer see.
        self._selected_bucket = None
        self._visible = {}
        # A refused Display Top value has nothing left to describe once the run
        # is cleared, so its red note and its count do not outlive the figures.
        self._reset_display_top()
        # The dimension picks go too. They are a view over the loaded rows, and
        # a pick that survived a refusal kept filtering an empty table while
        # `_current_filters()` still reported a value nobody could see applied.
        self._reset_filter_picks()
        # The selected-security panel is the third surface that could outlive
        # the figures: it renders one bond's row and its spread numbers, so a
        # refusal used to leave the previous run's numbers under a red bar.
        self._reset_detail_panel()
        self._render_view()
        self.headline.value = (
            "<p style='margin:4px 0;color:#666'>No result loaded. A refused "
            "input or a failed Update clears the figures instead of leaving "
            "the previous run on screen.</p>"
        )
        self._refresh_export_tables(force=True)

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def _validate_dates(self) -> tuple[date, date] | str:
        start = self.start_date.value
        end = self.end_date.value
        if start is None or end is None:
            return "Select both comparison dates."
        if start >= end:
            return "Start date must be earlier than end date."
        if end > date.today():
            return "End date cannot be in the future."
        # A non-business end date is refused before the request, not after it.
        # The universe for `Index` is membership keyed on this date, and BQL
        # anchors that on the rebalance boundary, so a weekend date produced a
        # completed request with no item at all — two requests and the better
        # part of a minute spent to learn what the calendar already said. The
        # message names the date to use instead, because "pick a business day"
        # leaves the operator to work it out.
        if end.weekday() >= 5:
            suggested = end
            while suggested.weekday() >= 5:
                suggested -= timedelta(days=1)
            return (
                f"End date {end.isoformat()} is a "
                f"{end.strftime('%A')}, not a business day. The index universe is "
                "membership keyed on that date, so the ranking would return no "
                f"row at all. Use {suggested.isoformat()} as the end date and "
                "press Update."
            )
        span = (end - start).days
        if span > config.MAX_RANGE_DAYS:
            return (
                f"Date window is {span} days; the window is capped at "
                f"{config.MAX_RANGE_DAYS} days. Narrow the window until the "
                "request timing is measured."
            )
        return start, end

    @staticmethod
    def _date_notes(start: date, end: date) -> list[str]:
        notes = []
        if start.weekday() >= 5:
            notes.append(
                "Start date is a weekend. net_chg() uses the first available "
                "observation in the range; see the request values in Export "
                "Excel → Request detail."
            )
        if end.weekday() >= 5:
            notes.append(
                "End date is a weekend. net_chg() uses the last available "
                "observation in the range; see the request values in Export "
                "Excel → Request detail."
            )
        return notes

    def _typed_values(self, source_key: str) -> tuple[str, str] | str:
        """Validate what the operator typed for one source.

        Returns ``(index_value, aim_value)`` or a refusal message. Every source
        is checked before any request is built, so a blank field can never fall
        back to another field or to the recorded example.
        """
        values = self._field_values()
        if source_key == config.COMPARISON_SOURCE:
            try:
                pairs = normalize_comparison(values["index"], values["aim"])
            except ValueError as exc:
                return str(exc)
            # The normalised values are what is requested: an AIM code is
            # upper-cased and a ticker's inner whitespace is collapsed here, so
            # the value on the status bar is the value in the request.
            return pairs[0][1], pairs[1][1]
        typed = values.get(source_key, values["index"])
        try:
            _key, normalized = normalize_universe(source_key, typed)
        except ValueError as exc:
            return str(exc)
        return normalized, ""

    def _on_update(self, _button) -> None:
        if self._running:
            return
        self._running = True
        self.update_button.disabled = True
        self._clear_results()
        self._clear_log()
        result = None
        # Which local step is running. Named in the failure so a reshape error
        # can never be read as a Bloomberg rejection (see _UPDATE_STAGES).
        stage = "request"
        try:
            self._progress("Checking the universe, the dates, and the date window.")
            dates = self._validate_dates()
            if isinstance(dates, str):
                self._refuse(dates)
                return
            start, end = dates
            source_key = self._source_key()
            typed = self._typed_values(source_key)
            if isinstance(typed, str):
                self._refuse(typed)
                return
            index_value, aim_value = typed
            spread_label = self.spread_type.value
            comparison = source_key == config.COMPARISON_SOURCE
            key = self._cache_key(
                source_key, start, end, index_value, aim_value, spread_label
            )
            if config.CACHE_READ_FIRST and cache.has_run(key, self._cache_root):
                self._load_from_cache(key, cached_reason="CACHE_READ_FIRST is on")
                return
            if comparison:
                self._progress(
                    f"Requesting {spread_label} changes for "
                    f"{index_value} and AIM account {aim_value} "
                    f"between {start} and {end}."
                )
                result = fetch_comparison(
                    spread_label, start, end, index_value, aim_value
                )
            else:
                self._progress(
                    f"Requesting {spread_label} changes for "
                    f"{_universe_label(source_key)} {index_value} "
                    f"between {start} and {end}."
                )
                result = fetch_movers(
                    spread_label,
                    start,
                    end,
                    index_value,
                    source=source_key,
                )
            # Record what was actually sent, before anything else can consult a
            # widget again. The cache writes this, and a cached screen is
            # labelled from it, so an edit made while the request was running
            # cannot caption one run's numbers with another run's inputs.
            result.cache_request = {
                "source": source_key,
                "index": index_value,
                "aim": aim_value,
                "spread": spread_label,
                "start": start.isoformat(),
                "end": end.isoformat(),
                "top_n": int(config.TOP_N),
            }
            if (
                result.errors
                and _result_is_timeout(result)
                and cache.has_run(key, self._cache_root)
            ):
                # The one step that keeps a timeout from being a dead end. Only
                # a timeout qualifies: it is transient, and the operator's
                # evidence is that the data was reachable moments earlier. A
                # rejected item, a missing entitlement or a bad ticker is
                # deterministic, so showing yesterday's numbers for it would
                # hide a real problem behind a stale table and is refused here.
                # The failure still prints; on top of that the last good run for
                # this exact key is shown, labelled as cached.
                self._load_from_cache(
                    key,
                    cached_reason=f"the live request timed out: {result.errors[0]}",
                    failed_result=result,
                )
                return
            if not result.errors and not _failed_field_labels(result.field_status):
                # Only a clean run is cached. A run that arrived with a FAILED
                # field would replay as a clean `Cached` screen, because the
                # cached render has no live receipt to show which column was
                # missing: the operator would see `(unavailable)` cells with no
                # explanation, and `Incomplete` would have become `Cached`.
                self._save_to_cache(key, result)
            self._progress("Ranking the movers and checking the returned fields.")
            stage = "prepare"
            movers = prepare_ranked_movers(
                result.increases,
                result.decreases,
                result.descriptors,
                top_n=config.TOP_N,
                descriptor_columns=tuple(
                    label
                    for label, _item in (
                        *config.DESCRIPTOR_FIELDS,
                        *config.DURATION_FIELDS,
                    )
                ),
                group_column=config.UNIVERSE_COLUMN if comparison else None,
            )
            stage = "check"
            validation = self._safe_validation(
                movers.increases,
                movers.decreases,
                result.series,
                requested_start=start,
                requested_end=end,
            )
            # The status line names what was typed (normalised), not what the
            # adapter echoed back, so an empty echo can never hide the universe.
            display_universe = (
                f"{index_value} vs {aim_value}" if comparison else index_value
            )
            stage = "render"
            self._render(
                start,
                end,
                spread_label,
                display_universe,
                result,
                movers,
                validation,
                source_key,
            )
        except Exception as exc:  # fail-visible: keep the diagnostics already collected
            # The stage is part of the message: "Preparing the ranked tables:
            # KeyError" says the data arrived and the reshape failed, while
            # "Requesting the data: ..." points at Bloomberg (or the request).
            stage_label = _UPDATE_STAGES.get(stage, stage)
            where = _exception_site(exc)
            detail = f" [{where}]" if where else ""
            self._set_error(
                f"{stage_label} failed — {type(exc).__name__}: {exc}{detail}",
                result=result,
            )
        finally:
            self._running = False
            self.update_button.disabled = False

    def _safe_validation(
        self,
        increases,
        decreases,
        series,
        requested_start=None,
        requested_end=None,
    ) -> SeriesValidation:
        """Run the change-arithmetic check without letting it end the Update.

        The check is a diagnostic: it compares each ranked ``Change`` with the
        series' last-minus-first value, and nothing on screen is drawn from it.
        A failure here therefore must not discard ten completed requests and
        blank the tables — it is reported as a note and the ranked rows keep
        their numbers, unresolved and labelled.
        """
        try:
            return validate_candidate_changes(
                increases,
                decreases,
                series,
                requested_start=requested_start,
                requested_end=requested_end,
            )
        except Exception as exc:
            return SeriesValidation(
                notes=[
                    "The change-arithmetic check could not be completed locally "
                    f"({type(exc).__name__}: {exc}). The ranked rows and their "
                    "BQL changes are unaffected; only the effective-date and "
                    "first/last-spread check is missing for this run."
                ]
            )

    def _on_load_cached(self, _button) -> None:
        """Load the saved run for the current inputs, without a request.

        The manual door to the same cache the automatic fallback uses. It
        validates the inputs the same way Update does, then refuses politely when
        nothing is saved for that exact universe, spread and window, so it can
        never show a different run's numbers.
        """
        if self._running:
            return
        dates = self._validate_dates()
        if isinstance(dates, str):
            self._refuse(dates)
            return
        start, end = dates
        source_key = self._source_key()
        typed = self._typed_values(source_key)
        if isinstance(typed, str):
            self._refuse(typed)
            return
        index_value, aim_value = typed
        key = self._cache_key(
            source_key, start, end, index_value, aim_value, self.spread_type.value
        )
        if not cache.has_run(key, self._cache_root):
            self._refuse(
                "No saved run matches this universe, spread and date window. "
                "Press Update to request it; a successful run is saved "
                "automatically."
            )
            return
        self._clear_results()
        self._clear_log()
        try:
            self._load_from_cache(key, cached_reason="Load saved was clicked")
        except Exception as exc:
            self._set_error(f"{type(exc).__name__}: {exc}")

    # ------------------------------------------------------------------
    # Cache
    # ------------------------------------------------------------------

    def _cache_key(self, source_key, start, end, index_value, aim_value, spread_label):
        """The identity of the run the operator is asking for.

        Built from exactly the inputs that change what Bloomberg returns, so a
        cached file can only be served to the run that asked for it. A different
        window, spread, universe or ``TOP_N`` is a different key and therefore a
        different file.
        """
        return cache.run_key(
            source_key=source_key,
            universe_key=index_value,
            aim_value=aim_value,
            spread_code=spread_label,
            start=start.isoformat(),
            end=end.isoformat(),
            top_n=config.TOP_N,
        )

    def _save_to_cache(self, key: str, result) -> None:
        """Write one successful run. Never raises into the Update.

        A cache write is a convenience, so a read-only Desktop project folder or
        a full disk must not turn a good run into a failed one. The failure is
        logged and the screen keeps its data.
        """
        try:
            cache.save_run(key, result, self._cache_root)
            removed = cache.prune(config.CACHE_KEEP_RUNS, self._cache_root)
        except Exception as exc:
            self._log_line(
                f"Cache: the run could not be saved ({type(exc).__name__}: {exc}). "
                "The results on screen are unaffected; only the fallback is missing."
            )
            return
        self._last_cache_key = key
        self._log_line(
            "Cache: this run was saved, so a timeout on the same universe, spread "
            "and dates can fall back to it."
        )
        if removed:
            self._log_line(
                f"Cache: removed {len(removed)} older run(s); "
                f"{config.CACHE_KEEP_RUNS} are kept."
            )

    def _load_from_cache(
        self,
        key: str,
        cached_reason: str,
        failed_result=None,
    ) -> None:
        """Render the cached run for ``key``, labelled as cached.

        The status word is ``Cached``, never ``Updated``: no request produced
        this screen, and saying ``Updated`` would claim one did. When the load
        follows a failed live request, the live failure is kept in the detail
        box and the step log so the operator sees both facts: the request
        failed, and here is the last good answer for the same question.
        """
        loaded, info = cache.load_run(key, self._cache_root)
        if loaded is None:
            # has_run() said yes but the files could not be read. That is a
            # partial write, and the honest response is the plain error path.
            self._set_error(
                "The cached run for these inputs could not be read. "
                "Press Update to request it again, which will overwrite the entry.",
                result=failed_result,
            )
            return
        moves = [
            ("Checking the cache for this universe, spread and window.", None)
        ]
        for line, _ in moves:
            self._log_line(line)
        self._log_line(cache.describe(info))
        if failed_result is not None:
            self._log_line(
                "The live request did not complete, so the cached run is shown "
                "instead. The error itself is recorded in the detail panel."
            )
        comparison = loaded.comparison
        descriptor_columns = tuple(
            label
            for label, _item in (*config.DESCRIPTOR_FIELDS, *config.DURATION_FIELDS)
        )
        try:
            movers = prepare_ranked_movers(
                loaded.increases,
                loaded.decreases,
                loaded.descriptors,
                top_n=config.TOP_N,
                descriptor_columns=descriptor_columns,
                group_column=config.UNIVERSE_COLUMN if comparison else None,
            )
            validation = self._safe_validation(
                movers.increases,
                movers.decreases,
                loaded.series,
            )
        except Exception as exc:
            self._set_error(
                f"The cached run could not be prepared: {type(exc).__name__}: {exc}",
                result=failed_result,
            )
            return
        self._render(
            *self._cached_window(loaded, info),
            loaded.universe or "cached",
            loaded,
            movers,
            validation,
            loaded.source or "index",
            cached_info=info,
            cached_reason=cached_reason,
            failed_result=failed_result,
        )

    def _cached_window(self, loaded, info: dict):
        """The ``(start, end, spread_label)`` the cached run was made with.

        Read from the saved request, not from the widgets. When the manifest has
        no request block (an entry written by an older build), the live date
        widgets are the only fallback, and the caller already validated them.
        """
        request = (info or {}).get("request") or {}
        start = _as_date_or(request.get("start"), self.start_date.value)
        end = _as_date_or(request.get("end"), self.end_date.value)
        spread = str(request.get("spread") or self.spread_type.value)
        return start, end, spread

    def _render(
        self,
        start,
        end,
        spread_label,
        universe_key,
        result,
        movers,
        validation,
        source_key="index",
        cached_info=None,
        cached_reason="",
        failed_result=None,
    ) -> None:
        comparison = source_key == config.COMPARISON_SOURCE
        messages = [
            *(f"Error: {message}" for message in result.errors),
            *result.notes,
            *movers.notes,
            *validation.notes,
            *self._date_notes(start, end),
        ]
        if comparison:
            universe_note = (
                f"{escape(universe_key)} (index membership and whole-account "
                "holdings, ranked separately)"
            )
        elif source_key == "aim":
            universe_note = (
                f"AIM account {escape(universe_key)} (whole-account holdings)"
            )
        elif source_key == "bond":
            universe_note = f"{escape(universe_key)} (one typed bond)"
        else:
            universe_note = (
                f"{escape(universe_key)} (index membership as of the end date)"
            )

        detail_parts = [
            _info_box(
                f"Dates: {start} → {end}. Spread: {escape(spread_label)}. "
                f"Universe: {universe_note}.",
                (
                    "warn"
                    if cached_info is not None
                    else (
                        "error"
                        if result.errors or _failed_field_labels(result.field_status)
                        else "warn"
                    )
                ),
            ),
            "<p>Start, end, and change are the same "
            f"{escape(spread_label)} series in source spread units; no bps or "
            "percent conversion is applied. The effective-date and "
            "change-arithmetic checks run in the background and report to the "
            "step log; units still need a Terminal comparison.</p>",
        ]
        if cached_info is not None:
            # A cached screen has to be unmistakable: the numbers are real but
            # they were not fetched for this press of Update, so the box leads
            # with that and names the cache generation.
            detail_parts.insert(
                0,
                _info_box(
                    "<b>Cached result — no request produced this screen.</b><br>"
                    f"Reason: {escape(cached_reason)}.<br>"
                    f"{escape(cache.describe(cached_info))}",
                    "warn",
                ),
            )
        if failed_result is not None and failed_result.errors:
            detail_parts.append(
                "<p><b>The live request failed:</b> "
                + "<br>".join(escape(item) for item in failed_result.errors)
                + "</p>"
            )
        if source_key == "aim":
            detail_parts.append(
                "<p>The AIM request uses the frozen Desktop contract: one account "
                "per request, <code>accounts</code> / <code>pxnum</code> / "
                "<code>profile</code> on <code>with_params</code>, and no dates on "
                "<code>members()</code>. Its holding list can include cash and "
                "equity lines; those return no spread and are excluded with a "
                "diagnostic. Rankings are change-based only — the holding size "
                "does not widen, narrow, or re-weight the lists.</p>"
            )
        if source_key == "bond":
            detail_parts.append(
                "<p>The bond request is an explicit <code>bq.univ.list([one "
                "ticker])</code> universe, not an index and not an account. It "
                "ranks the same spread change on that one security, so a screen "
                "with one row is the expected shape. A list separator is refused "
                "rather than widened.</p>"
            )
        if comparison:
            detail_parts.append(
                "<p>Both books were ranked separately and labelled with their "
                "book; a bond held by the account and held by the index appears "
                "once per book. The descriptors and the candidate series were "
                "requested once on the union of both candidate lists. A "
                "successful index ranking says nothing about AIM entitlement.</p>"
            )
        if result.request_log:
            total = sum(log["elapsed_sec"] for log in result.request_log)
            detail_parts.append(
                f"<p><b>Requests:</b> {len(result.request_log)} "
                f"(total {total:.2f} s).</p>"
            )
        if messages:
            detail_parts.append(
                "<p>" + "<br>".join(escape(message) for message in messages) + "</p>"
            )
        self._set_detail("".join(detail_parts))

        failed_fields = _failed_field_labels(result.field_status)
        if cached_info is not None:
            # Never `Updated`. No request produced this screen, and the word
            # would claim one did. The failure, when there was one, is on the
            # status line too, because both facts have to survive on screen.
            word = "Cached"
            status_message = (
                f"{spread_label} · {_universe_label(source_key)} {universe_key} · "
                f"{start} → {end} · last good run from cache"
            )
            if failed_result is not None and failed_result.errors:
                status_message += " (the live request failed)"
        elif result.errors or failed_fields:
            word = "Incomplete"
            pieces = []
            if result.errors:
                pieces.append(f"{len(result.errors)} request(s) failed")
            if failed_fields:
                pieces.append(
                    f"{len(failed_fields)} field(s) failed ({', '.join(failed_fields)})"
                )
            status_message = "; ".join(pieces) + "; read the detail panel."
        else:
            word = "Updated"
            status_message = (
                f"{spread_label} · {_universe_label(source_key)} {universe_key} · "
                f"{start} → {end}"
            )
        self._set_status(word, status_message, "Idle")
        # Remembered so that returning the controls to the loaded values can
        # restore this status instead of leaving a stale "Please Click Update".
        self._loaded_status = (word, status_message)
        for message in messages:
            self._log_line(message)
        # Only a FAILED field is a diagnostic. The successful per-field receipt
        # stays off the page and is available in the Export Excel tab, so the
        # top of the screen carries no static metadata table (DR-16).
        for line in _field_failure_lines(result.field_status):
            self._log_line(line)

        self._run_token += 1
        self._loaded = {
            "source": self.universe_source.value,
            "index": " ".join(str(self.index_input.value or "").split()),
            "aim": str(self.aim_input.value or "").strip(),
            "bond": " ".join(str(self.bond_input.value or "").split()),
            "spread": spread_label,
            "start": start.isoformat(),
            "end": end.isoformat(),
        }
        self._comparison = comparison
        self._field_status = dict(result.field_status)
        self._request_log = list(result.request_log)

        # Everything the local view needs, enriched once. The dimension
        # buckets are derived from descriptors already requested; nothing here
        # sends a request, and no new BQL item is introduced.
        #
        # Start and End come from the same bounded series the change check
        # already reads, so the table names the two endpoints of the change
        # without a second request. An ID the series did not cover keeps a
        # blank level instead of a carried-forward or zero-filled one.
        levels = spread_levels(result.series)
        self._selected_id = None
        # A bucket pick belongs to the run that produced it. A new run may not
        # even contain that bucket, and a stale pick would silently narrow its
        # charts to nothing.
        self._selected_bucket = None
        # Display Top is reset with every run: the new ranking has a different
        # number of rows, so carrying the old count over would show a panel the
        # operator never sized for this run without any sign that it changed.
        self._reset_display_top()
        self._frames = {
            "increases": enrich_ranked(
                attach_spread_levels(movers.increases, levels), end, side="Increase"
            ),
            "decreases": enrich_ranked(
                attach_spread_levels(movers.decreases, levels), end, side="Decrease"
            ),
            "series": result.series,
            "start": start,
            "end": end,
        }
        if source_key == "bond" and universe_key:
            # A Bond run is one security, so it is the selected one. The path
            # chart and its daily table are the whole screen for this source;
            # leaving them on "select a bond" would ask a question the run has
            # already answered.
            self._selected_id = universe_key
        self._refresh_filter_options()
        # One bond, one label. If the two ranked sides ever disagree about a
        # bond's country, sector, rating bucket, or currency, that bond would
        # show up under two values of the same selection box while its detail
        # row shows only one. The frames are built from one descriptor table so
        # this count is expected to be zero; anything else is named in the log
        # instead of being split silently.
        #
        # Diagnostic only, so it must never end the Update: the tables are
        # already built and a failed consistency count says nothing about them.
        try:
            conflicts = label_conflicts(
                [self._frames.get("increases"), self._frames.get("decreases")]
            )
        except Exception as exc:
            conflicts = {}
            self._log_line(
                "Label consistency check skipped "
                f"({type(exc).__name__}: {exc}); the tables are unaffected."
            )
        for column, count in sorted(conflicts.items()):
            self._log_line(
                f"{column}: {count} bond(s) carried more than one label in this "
                "run; the filter lists every value, so a row can appear under "
                "each of them."
            )
        self.detail_title.value = (
            "<b>Selected security</b><br>Click a bar or a line to inspect one security."
        )
        self.detail_view.value = ""
        self._render_view()
        self._refresh_export_tables(force=True)

        # The effective-date table is not on screen by operator decision. Its
        # findings are kept as log text only, so a shifted effective date or a
        # change that does not equal Last - First is still visible in the step
        # log without occupying the page.
        if not validation.frame.empty and not validation.notes:
            self._log_line(
                f"Change arithmetic checked on {len(validation.frame)} ranked "
                "bond(s) against a second bounded series request; no mismatch "
                "was flagged."
            )
        self._validation_notes = list(validation.notes)
        # The retired validation table's diagnostics go to the step log, which
        # is what the notes in the detail panel now point the operator at. A
        # shifted effective date or a change that is not Last - First must stay
        # visible somewhere after the table itself was removed.
        for note in validation.notes:
            self._log_line(str(note))
        if movers.increases.empty and movers.decreases.empty:
            # The tables say this themselves, but the log is where a reader
            # checks what happened to the run, so the state is stated once.
            self._log_line(
                "No ranked movers were returned. Read the detail panel above "
                "before retrying."
            )

    # ------------------------------------------------------------------
    # Export Excel tab
    # ------------------------------------------------------------------

    def _export_frames(self) -> dict[str, pd.DataFrame]:
        """The four export tables of the loaded run, or an empty mapping.

        The two ranked sides are the frames currently on screen, so a filter
        picked on Main narrows the copy as well. Validation and the request log
        are not filterable and are exported whole.
        """
        frames = getattr(self, "_frames", None) or {}
        visible = getattr(self, "_visible", None) or {}
        increases = visible.get("increases", frames.get("increases"))
        decreases = visible.get("decreases", frames.get("decreases"))
        out: dict[str, pd.DataFrame] = {}
        # The copy carries the same headings Main shows, so the pasted table
        # still names its spread type (Start OAS / End OAS / OAS Change).
        if isinstance(increases, pd.DataFrame) and not increases.empty:
            out["increases"] = _spread_headers(
                increases.loc[:, _display_columns(increases)], self._spread_label()
            )
        if isinstance(decreases, pd.DataFrame) and not decreases.empty:
            out["decreases"] = _spread_headers(
                decreases.loc[:, _display_columns(decreases)], self._spread_label()
            )
        log = getattr(self, "_request_log", []) or []
        if log:
            out["requests"] = pd.DataFrame(log)
        return out

    def _refresh_export_tables(self, force: bool = False) -> None:
        """Fill the Export Excel tab from the loaded run. Never requests."""
        frames = self._export_frames()
        # The key describes the content, not the object identity. It used to be
        # ``id(frame)``, and CPython reuses a freed object's address, so a new
        # filtered view could collide with a retired one and be skipped. The run
        # token changes on every Update, and the row count plus the filter set
        # change on every filter move, so a stale key is no longer reachable.
        key = (
            self._run_token,
            tuple(sorted(frames)),
            tuple(sorted((name, int(len(frame))) for name, frame in frames.items())),
            self.dimension_input.value,
            tuple(
                sorted(
                    (label, tuple(sorted(values)))
                    for label, values in self._current_filters().items()
                )
            ),
        )
        if not force and key == self._export_key:
            return
        self._export_key = key
        # The receipt is shown whether or not rows came back: after a failed or
        # empty run it is the only record of what did arrive (DR-16).
        self.export_note.value = self._receipt_note(len(frames) > 0)
        if not frames:
            unfiltered = any(
                isinstance(frames_pair, pd.DataFrame) and not frames_pair.empty
                for frames_pair in (
                    (getattr(self, "_frames", None) or {}).get("increases"),
                    (getattr(self, "_frames", None) or {}).get("decreases"),
                )
            )
            message = (
                "<p>No rows match the filters on Main. Clear a filter to export "
                "that table.</p>"
                if unfiltered
                else (
                    "<p>No rows came back from the last run. The request detail "
                    "below records what was attempted.</p>"
                    if getattr(self, "_field_status", None)
                    else "<p>No run loaded.</p>"
                )
            )
            self.export_box.children = (widgets.HTML(message),)
            return
        self._show_export_view(frames)

    def _receipt_note(self, has_rows: bool) -> str:
        """The per-field receipt HTML of the last run, or '' when there is none."""
        receipts = _field_log_lines(getattr(self, "_field_status", {}))
        if not receipts:
            return ""
        rows_note = (
            "<p style='margin:2px 0;color:#666'>The two ranked tables copy "
            "what Main shows under the current filter boxes. A bucket picked in "
            "the bucket table narrows Main only; it is not applied to this copy. "
            "The request log is not filterable and is copied whole.</p>"
            if has_rows
            else ""
        )
        return (
            "<h4>Request detail</h4>"
            "<p style='margin:2px 0;color:#666'>Per-field request receipt. "
            "This is request metadata, not data, so it lives here rather than "
            "under the status bar.</p>"
            + rows_note
            + "<pre style='margin:2px 0;color:#444;white-space:pre-wrap'>"
            + escape("\n".join(receipts))
            + "</pre>"
        )

    def _on_export_view_change(self, _change) -> None:
        self._show_export_view(self._export_frames())

    def _show_export_view(self, frames: dict[str, pd.DataFrame] | None = None) -> None:
        frames = frames if frames is not None else self._export_frames()
        key = self.export_view.value
        frame = frames.get(key)
        if frame is None or frame.empty:
            self.export_box.children = (
                widgets.HTML("<p>No rows for this table in the loaded run.</p>"),
            )
            return
        self.export_box.children = (widgets.HTML(_table_html(self.export_frame(key))),)

    def export_frame(self, key: str) -> pd.DataFrame:
        """The copy-to-Excel frame for one export choice, or an empty frame.

        Exposed because two callers need the identical frame: the Export Excel
        tab, and the tests that check the repeated header row.
        """
        frame = self._export_frames().get(key)
        if frame is None or frame.empty:
            return pd.DataFrame()
        return export_display_frame(frame, tuple(frame.columns))
