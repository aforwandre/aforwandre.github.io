"""Pure pandas validation and ordering of BQL-ranked spread movers.

No BQL is imported here. The data adapter returns candidate frames
(``ID`` + ``Change``), an optional descriptor table keyed by ``ID``, and an
optional ``ID``/``DATE``/``Spread`` series used only to validate the effective
observation dates and the ``net_chg`` value.
"""

from __future__ import annotations

import numbers
import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import config


RANK_COLUMNS = ("ID", "Change")
# The two spread levels carried onto the ranked rows. They are read from the
# same bounded series the change check already requests, so the table can show
# where the change started and where it ended without a new BQL item and
# without a second request.
SPREAD_LEVEL_COLUMNS = ("Start Spread", "End Spread")
VALIDATION_COLUMNS = (
    "ID",
    "Side",
    "BQL Change",
    "First Spread",
    "Last Spread",
    "Effective Start",
    "Effective End",
    "Series Change",
    "Matches BQL",
)


@dataclass
class RankedMovers:
    increases: pd.DataFrame = field(
        default_factory=lambda: pd.DataFrame(columns=list(RANK_COLUMNS))
    )
    decreases: pd.DataFrame = field(
        default_factory=lambda: pd.DataFrame(columns=list(RANK_COLUMNS))
    )
    notes: list[str] = field(default_factory=list)


@dataclass
class SeriesValidation:
    frame: pd.DataFrame = field(
        default_factory=lambda: pd.DataFrame(columns=list(VALIDATION_COLUMNS))
    )
    notes: list[str] = field(default_factory=list)


def _as_float(series: pd.Series) -> pd.Series:
    """Return a plain float64 series across pandas nullable/extension dtypes."""
    numeric = pd.to_numeric(series, errors="coerce")
    try:
        return numeric.astype("float64")
    except (TypeError, ValueError):
        return numeric


def _check_top_n(top_n) -> int:
    if isinstance(top_n, bool) or not isinstance(top_n, numbers.Integral) or top_n < 1:
        raise ValueError("top_n must be a positive integer.")
    return int(top_n)


def _side_columns(group_column: str | None = None) -> list[str]:
    """The ranked-side column order: the book first when there is one."""
    if group_column:
        return [group_column, *RANK_COLUMNS]
    return list(RANK_COLUMNS)


def _prepare_side(
    source: pd.DataFrame | None,
    label: str,
    positive: bool,
    ascending: bool,
    top_n: int,
    notes: list[str],
    group_column: str | None = None,
) -> pd.DataFrame:
    empty = pd.DataFrame(columns=_side_columns(group_column))
    if source is None or source.empty:
        notes.append(f"{label}: no rows were returned.")
        return empty

    frame = source.copy()
    missing = [column for column in RANK_COLUMNS if column not in frame.columns]
    if missing:
        notes.append(f"{label}: response is missing columns {missing}; list left empty.")
        return empty

    frame["ID"] = frame["ID"].astype("string").fillna("").str.strip()
    frame["Change"] = _as_float(frame["Change"])
    values = frame["Change"].to_numpy(dtype=float)
    # Positional boolean arrays throughout this function. A row-label mask is a
    # label lookup, and a label lookup can fail on an index this code did not
    # build; a positional mask cannot (`-1` cannot appear, because there is no
    # indexer to leave unfound).
    invalid = np.asarray(frame["ID"].eq("").to_numpy() | ~np.isfinite(values), dtype=bool)
    invalid_count = int(invalid.sum())
    if invalid_count:
        notes.append(
            f"{label}: excluded {invalid_count} row(s) with a blank ID or a "
            "missing/non-numeric change."
        )
    frame = frame.loc[~invalid].copy()

    # In the two-book comparison the row identity is (book, ID): one bond can
    # be a member of the index and a holding of the account, with two different
    # changes, and dropping it as a "duplicate" would delete one book's row.
    if group_column and group_column in frame.columns:
        frame[group_column] = (
            frame[group_column].fillna("").astype(str).str.strip().replace({"": "(unknown)"})
        )
        key = [group_column, "ID"]
    else:
        key = ["ID"]

    duplicate = frame.duplicated(key, keep=False)
    if duplicate.any():
        duplicate_ids = int(
            pd.unique(frame["ID"].to_numpy()[np.asarray(duplicate, dtype=bool)]).size
        )
        # In comparison mode the key includes the book, so the unit is a
        # (book, ID) pair and the same bond in both books is not a duplicate.
        unit = "(book, ID) pair" if group_column else "ID"
        notes.append(
            f"{label}: {duplicate_ids} duplicate ID(s) in the response; "
            f"kept the last row per {unit}."
        )
        frame = frame.drop_duplicates(key, keep="last")

    expected = np.asarray(
        (frame["Change"].gt(0) if positive else frame["Change"].lt(0)).to_numpy(),
        dtype=bool,
    )
    wrong_direction = int((~expected).sum())
    if wrong_direction:
        notes.append(f"{label}: dropped {wrong_direction} row(s) with the wrong sign.")
        frame = frame.loc[expected].copy()

    if frame.empty:
        notes.append(f"{label}: no movers remain after validation.")
        return empty

    frame = frame.sort_values(key, kind="mergesort")
    frame = frame.sort_values("Change", ascending=ascending, kind="mergesort")
    returned = len(frame)
    if group_column and group_column in frame.columns:
        # The top N is per book: an index with 10 movers must not push the AIM
        # book's movers out of a comparison that asked for both.
        frame = frame.groupby(group_column, sort=False, group_keys=False).head(top_n)
    else:
        frame = frame.head(top_n)
    frame = frame.reset_index(drop=True)
    if returned > len(frame):
        notes.append(
            f"{label}: {returned} rows ranked; truncated to "
            f"{'the top ' + str(top_n) + ' per book' if group_column else 'the top ' + str(len(frame))} "
            "(ties at the cutoff are ordered by ID)."
        )
    if not group_column and len(frame) < top_n:
        notes.append(
            f"{label}: only {len(frame)} qualifying mover(s) returned "
            f"(the request asked for {top_n})."
        )
    return frame.loc[:, _side_columns(group_column)].copy()


def _merge_descriptors(
    frame: pd.DataFrame,
    descriptors: pd.DataFrame | None,
    descriptor_columns: tuple[str, ...],
    label: str,
    notes: list[str],
    group_column: str | None = None,
) -> pd.DataFrame:
    if frame.empty or descriptors is None or descriptors.empty:
        return frame
    if "ID" not in descriptors.columns:
        return frame
    columns = [
        column
        for column in descriptor_columns
        if column in descriptors.columns and column not in frame.columns
    ]
    if not columns:
        return frame

    lookup = descriptors.loc[:, ["ID", *columns]].copy()
    if lookup["ID"].duplicated().any():
        notes.append(
            f"{label}: descriptor lookup had duplicate IDs; kept the last row per ID."
        )
        lookup = lookup.drop_duplicates("ID", keep="last")
    # Which ranked IDs the descriptor response actually described. A left join
    # cannot tell "Bloomberg returned an empty value" from "this ID was never
    # in the response", and the two must stay distinct: the first is (blank),
    # the second is (unavailable) because the field was not returned for that
    # bond. The marker column is dropped again below.
    described_column = "__described__"
    lookup[described_column] = True
    merged = frame.merge(lookup, on="ID", how="left", validate="many_to_one")
    described_flag = merged.pop(described_column)
    # A positional boolean array, deliberately. Assignment through a row-label
    # mask is the one construct in this function that a pandas build can route
    # through a label lookup, and a label lookup on a frame this code did not
    # create can fail with `KeyError: None of [Int64Index([-1, ...])] are in the
    # [index]`. A positional mask cannot: there is nothing to match against the
    # index, so no label indexer is built at all. `described_flag` is measured
    # on `merged` before any column is touched, so its length always matches.
    not_described = np.asarray(described_flag.isna(), dtype=bool)
    if not_described.any():
        uncovered = merged["ID"].to_numpy()[not_described]
        missing_units = int(pd.unique(uncovered).size)
        notes.append(
            f"{label}: the descriptor response did not cover {missing_units} "
            "ID(s); those rows show (unavailable) rather than (blank)."
        )
        for column in columns:
            # Text dimensions only. A numeric or date descriptor keeps NaN so
            # its bucket stays Missing instead of becoming a string column.
            if column in config.TEXT_DIMENSIONS:
                values = merged[column].astype(object).to_numpy(copy=True)
                values[not_described] = config.DESCRIPTOR_UNAVAILABLE
                merged[column] = values
    if group_column:
        ordered = [group_column, "ID", *columns, "Change"]
    else:
        ordered = ["ID", *columns, "Change"]
    return merged.loc[:, ordered]


def prepare_ranked_movers(
    increases: pd.DataFrame | None,
    decreases: pd.DataFrame | None,
    descriptors: pd.DataFrame | None = None,
    top_n: int = 10,
    descriptor_columns: tuple[str, ...] = (),
    group_column: str | None = None,
) -> RankedMovers:
    """Validate BQL-ranked candidate frames and merge display descriptors.

    ``group_column`` turns on the two-book comparison: duplicate detection and
    the top-N cut are then per book, and the column is carried into the ranked
    output so the tables and charts can tell the two universes apart.
    """
    top_n = _check_top_n(top_n)
    notes: list[str] = []
    prepared = []
    for label, source, positive, ascending in (
        ("increases", increases, True, False),
        ("decreases", decreases, False, True),
    ):
        side = _prepare_side_safely(
            source, label, positive, ascending, top_n, notes, group_column
        )
        side = _merge_descriptors_safely(
            side, descriptors, descriptor_columns, label, notes, group_column
        )
        prepared.append(side)
    return RankedMovers(increases=prepared[0], decreases=prepared[1], notes=notes)


def _prepare_side_safely(
    source: pd.DataFrame | None,
    label: str,
    positive: bool,
    ascending: bool,
    top_n: int,
    notes: list[str],
    group_column: str | None = None,
) -> pd.DataFrame:
    """One ranked side, with its own failure contained to that side.

    A defect while ranking one direction must not delete the other direction,
    which is what a raising call did: the exception left the Update with ten
    completed requests and no table. The failure is named in the notes, so an
    empty half is never silent, and the other half is still drawn.
    """
    try:
        return _prepare_side(
            source, label, positive, ascending, top_n, notes, group_column
        )
    except Exception as exc:
        notes.append(
            f"{label}: the ranked rows could not be prepared locally "
            f"({type(exc).__name__}: {exc}); this side is drawn empty. The "
            "request itself succeeded, so this is a reshape fault, not a "
            "refused field."
        )
        return pd.DataFrame(columns=_side_columns(group_column))


def _merge_descriptors_safely(
    frame: pd.DataFrame,
    descriptors: pd.DataFrame | None,
    descriptor_columns: tuple[str, ...],
    label: str,
    notes: list[str],
    group_column: str | None = None,
) -> pd.DataFrame:
    """Attach display descriptors, never at the cost of the ranked rows.

    Name, country, sector, rating, currency, maturity and the duration measures
    are decoration on top of ``ID``/``Change``. If joining them fails, the
    ranked rows and their changes are still the answer to the question that was
    asked, so the join is dropped and the columns are named as unavailable. The
    alternative — which shipped — was aborting the whole Update over a lookup
    column, which threw away every request and showed nothing.
    """
    if frame.empty:
        return frame
    try:
        return _merge_descriptors(
            frame, descriptors, descriptor_columns, label, notes, group_column
        )
    except Exception as exc:
        notes.append(
            f"{label}: the display columns could not be attached "
            f"({type(exc).__name__}: {exc}); the ranked rows and their changes "
            "are shown without them. This is a local reshape fault, not a "
            "refused field."
        )
        for column in descriptor_columns:
            if column in frame.columns or column == "ID":
                continue
            if column in config.TEXT_DIMENSIONS:
                frame[column] = config.DESCRIPTOR_UNAVAILABLE
            else:
                frame[column] = pd.NA
        ordered = ([group_column] if group_column else []) + ["ID"]
        ordered += [column for column in descriptor_columns if column in frame.columns]
        ordered += [
            column
            for column in frame.columns
            if column not in ordered
        ]
        return frame.loc[:, ordered]


def validate_candidate_changes(
    increases: pd.DataFrame | None,
    decreases: pd.DataFrame | None,
    series: pd.DataFrame | None,
    atol: float = 1e-6,
    requested_start=None,
    requested_end=None,
) -> SeriesValidation:
    """Compare each ranked ``Change`` with the series last-minus-first value.

    ``net_chg()`` is documented as the change between the first and last values
    in the requested range, so this check exposes the effective observation
    dates and catches a silent endpoint substitution before anyone trusts the
    ranking or its units.
    """
    pieces = []
    # In the two-book run the same eligible ID can appear once per book with a
    # different ranked ``Change``. The series is fetched once on the union of
    # both candidate lists, so the join stays on ``ID``; the book is carried
    # into the table only so a mismatch can be attributed to the row that has
    # it instead of naming a bare ID that exists twice.
    group_column = None
    for frame in (increases, decreases):
        if frame is not None and not frame.empty and config.UNIVERSE_COLUMN in frame.columns:
            group_column = config.UNIVERSE_COLUMN
            break
    for side, frame in (("increases", increases), ("decreases", decreases)):
        if frame is None or frame.empty:
            continue
        if "ID" not in frame.columns or "Change" not in frame.columns:
            continue
        wanted = ["ID", "Change"]
        if group_column and group_column in frame.columns:
            wanted.insert(0, group_column)
        piece = frame.loc[:, wanted].copy()
        piece["Side"] = side
        pieces.append(piece)

    if not pieces:
        return SeriesValidation(notes=["No ranked rows were available to validate."])

    ranked = pd.concat(pieces, ignore_index=True).rename(columns={"Change": "BQL Change"})
    if series is None or series.empty:
        return SeriesValidation(
            notes=[
                "Spread-series validation request returned no observations; the "
                "effective dates and the source units were not checked."
            ]
        )

    missing = sorted({"ID", "DATE", "Spread"} - set(series.columns))
    if missing:
        return SeriesValidation(
            notes=[f"Spread-series validation frame is missing columns {missing}."]
        )

    data = series.copy()
    data["ID"] = data["ID"].astype("string").fillna("").str.strip()
    data["DATE"] = pd.to_datetime(data["DATE"], errors="coerce")
    data["Spread"] = pd.to_numeric(data["Spread"], errors="coerce")
    data = data.loc[
        data["ID"].ne("") & data["DATE"].notna() & data["Spread"].notna()
    ].copy()
    if data.empty:
        return SeriesValidation(
            notes=["Spread-series validation frame had no usable observations."]
        )

    data = data.sort_values(["ID", "DATE"], kind="mergesort")
    duplicate_series = data.duplicated(["ID", "DATE"], keep=False)
    duplicate_note = None
    if duplicate_series.any():
        duplicate_ids = int(data.loc[duplicate_series, "ID"].nunique())
        duplicate_note = (
            f"{duplicate_ids} ID(s) had duplicate ID/DATE series rows; kept the "
            "first row per key before the effective-date check."
        )
        data = data.drop_duplicates(["ID", "DATE"], keep="first")
    first = data.groupby("ID", as_index=False).first()
    last = data.groupby("ID", as_index=False).last()
    merged = ranked.merge(
        first.loc[:, ["ID", "DATE", "Spread"]].rename(
            columns={"DATE": "Effective Start", "Spread": "First Spread"}
        ),
        on="ID",
        how="left",
        validate="many_to_one",
    )
    merged = merged.merge(
        last.loc[:, ["ID", "DATE", "Spread"]].rename(
            columns={"DATE": "Effective End", "Spread": "Last Spread"}
        ),
        on="ID",
        how="left",
        validate="many_to_one",
    )
    merged["Series Change"] = merged["Last Spread"] - merged["First Spread"]

    bql_change = _as_float(merged["BQL Change"]).to_numpy(dtype=float)
    series_change = _as_float(merged["Series Change"]).to_numpy(dtype=float)
    matches = np.isclose(bql_change, series_change, rtol=1e-6, atol=atol)
    merged["Matches BQL"] = matches

    notes: list[str] = []
    if duplicate_note:
        notes.append(duplicate_note)
    if requested_start is not None:
        wanted_start = pd.Timestamp(requested_start).normalize()
        shifted_start = merged.loc[
            merged["Effective Start"].notna()
            & merged["Effective Start"].ne(wanted_start)
        ]
        if len(shifted_start):
            notes.append(
                f"{len(shifted_start)} ranked ID(s) have an effective start date "
                f"different from the requested {wanted_start.date()}; see the step "
                "log and Export Excel → Request detail."
            )
    if requested_end is not None:
        wanted_end = pd.Timestamp(requested_end).normalize()
        shifted_end = merged.loc[
            merged["Effective End"].notna()
            & merged["Effective End"].ne(wanted_end)
        ]
        if len(shifted_end):
            notes.append(
                f"{len(shifted_end)} ranked ID(s) have an effective end date "
                f"different from the requested {wanted_end.date()}; see the step "
                "log and Export Excel → Request detail."
            )
    no_series = int(merged["First Spread"].isna().sum())
    if no_series:
        notes.append(
            f"{no_series} ranked row(s) had no usable spread-series observation; "
            "the effective-date check could not be completed for them."
        )
    checked = merged.loc[merged["Series Change"].notna()]
    mismatches = int((~checked["Matches BQL"]).sum()) if not checked.empty else 0
    if mismatches:
        notes.append(
            f"{mismatches} ranked row(s) had Series Change != BQL Change; inspect "
            "these rows before trusting the ranking or units."
        )
    if not notes:
        notes.append(
            "All checked IDs satisfy Change = Last Spread - First Spread in the "
            "returned series."
        )

    ordered_columns = list(VALIDATION_COLUMNS)
    if group_column and group_column in merged.columns:
        # Right after the ID, so a two-book table reads "which book, which bond".
        ordered_columns.insert(1, group_column)
    ordered = merged.loc[:, ordered_columns].copy()
    return SeriesValidation(frame=ordered.reset_index(drop=True), notes=notes)


def spread_levels(series: pd.DataFrame | None) -> pd.DataFrame:
    """First and last observed spread per ID, from the bounded candidate series.

    ``Start Spread`` / ``End Spread`` are the two endpoints the change is
    measured between. They are read from a frame this app already requested for
    the change-arithmetic check, so showing them costs no extra BQL item, no
    extra request, and no wider universe.

    The cleaning is the same as ``validate_candidate_changes`` — a blank ID, an
    unparseable date, or a non-numeric spread is dropped rather than filled. A
    duplicated ``(ID, DATE)`` keeps the first row, because the first and last
    observation must come from one consistent series. An ID with no usable
    observation is absent from the result instead of contributing a zero.
    """
    empty = pd.DataFrame(columns=["ID", *SPREAD_LEVEL_COLUMNS])
    if series is None or series.empty:
        return empty
    if not {"ID", "DATE", "Spread"} <= set(series.columns):
        return empty
    data = series.loc[:, ["ID", "DATE", "Spread"]].copy()
    data["ID"] = data["ID"].astype("string").fillna("").str.strip()
    data["DATE"] = pd.to_datetime(data["DATE"], errors="coerce")
    data["Spread"] = _as_float(data["Spread"])
    data = data.loc[
        data["ID"].ne("") & data["DATE"].notna() & data["Spread"].notna()
    ].copy()
    if data.empty:
        return empty
    data = data.sort_values(["ID", "DATE"], kind="mergesort")
    data = data.drop_duplicates(["ID", "DATE"], keep="first")
    first = (
        data.groupby("ID", as_index=False)
        .first()
        .loc[:, ["ID", "Spread"]]
        .rename(columns={"Spread": "Start Spread"})
    )
    last = (
        data.groupby("ID", as_index=False)
        .last()
        .loc[:, ["ID", "Spread"]]
        .rename(columns={"Spread": "End Spread"})
    )
    merged = first.merge(last, on="ID", how="outer", validate="one_to_one")
    return merged.loc[:, ["ID", *SPREAD_LEVEL_COLUMNS]].reset_index(drop=True)


def attach_spread_levels(
    frame: pd.DataFrame | None,
    levels: pd.DataFrame | None,
) -> pd.DataFrame:
    """Put ``Start Spread`` / ``End Spread`` immediately before ``Change``.

    A ranked ID the series did not cover keeps a blank level (NaN), never a
    zero and never a neighbouring observation: a missing quote is displayed as
    missing, and the change column is left exactly as Bloomberg ranked it. The
    function is idempotent, so a frame that already carries the two columns is
    rebuilt instead of gaining a duplicate pair.

    Idempotent and side-effect free: the caller's frame is not modified.
    """
    if frame is None:
        return pd.DataFrame(columns=list(SPREAD_LEVEL_COLUMNS))
    out = frame.copy()
    # Rebuilt on every call: a stale level from an earlier attach must not
    # survive a refresh whose series request returned less.
    out = out.drop(
        columns=[column for column in SPREAD_LEVEL_COLUMNS if column in out.columns]
    )
    usable = (
        isinstance(levels, pd.DataFrame)
        and not levels.empty
        and {"ID", *SPREAD_LEVEL_COLUMNS} <= set(levels.columns)
    )
    if not out.empty and usable:
        lookup = levels.loc[:, ["ID", *SPREAD_LEVEL_COLUMNS]].copy()
        lookup = lookup.drop_duplicates("ID", keep="last")
        out = out.merge(lookup, on="ID", how="left", validate="many_to_one")
    else:
        for column in SPREAD_LEVEL_COLUMNS:
            out[column] = np.nan
    ordered = [column for column in out.columns if column not in SPREAD_LEVEL_COLUMNS]
    if "Change" in ordered:
        position = ordered.index("Change")
        ordered[position:position] = list(SPREAD_LEVEL_COLUMNS)
    else:
        ordered = [*ordered, *SPREAD_LEVEL_COLUMNS]
    return out.loc[:, ordered].reset_index(drop=True)


# ---------------------------------------------------------------------------
# Display dimensions: derived from descriptors this app already requests
# ---------------------------------------------------------------------------

# The letter tables are the frozen mapping in ``RAG KB/28`` (FI Index Change).
# They are copied, not re-invented, so both apps bucket a rating() value the
# same way. A numeric rating stays unmapped instead of being scaled by guess.
SP_IG = {
    "AAA", "AA+", "AA", "AA-", "A+", "A", "A-", "BBB+", "BBB", "BBB-",
}
SP_HY = {
    "BB+", "BB", "BB-", "B+", "B", "B-",
    "CCC+", "CCC", "CCC-", "CC", "C", "D", "SD", "RD",
}
MOODY_IG = {
    "AAA", "AA1", "AA2", "AA3", "A1", "A2", "A3", "BAA1", "BAA2", "BAA3",
}
MOODY_HY = {
    "BA1", "BA2", "BA3", "B1", "B2", "B3",
    "CAA1", "CAA2", "CAA3", "CA", "C",
}
# Tokens Bloomberg uses for "no rating". They are missing data, not a grade.
NR_TOKENS = {"", "NR", "WR", "NA", "N/A", "NONE", "NAN", "NULL", "(BLANK)"}

RATING_NA_LABEL = "N.A."
RATING_NR_LABEL = "NR/Missing"
RATING_UNMAPPED_LABEL = "Numeric (unmapped)"
RATING_OTHER_LABEL = "Other"
RATING_BUCKETS = (
    "IG",
    "HY",
    RATING_NA_LABEL,
    RATING_NR_LABEL,
    RATING_UNMAPPED_LABEL,
    RATING_OTHER_LABEL,
)
SIDE_LABELS = ("Increase", "Decrease")


# Every character Python's ``str.strip()`` treats as blank is not the whole set
# Bloomberg can return: a no-break space or a zero-width space survives
# ``strip()``, so "AAA" and "AAA\u00a0" become two options in one filter box and
# one bond then looks like it belongs to both. This is the single normalisation
# used by the dimension columns, the filter options, and the bucket grouping, so
# the option list and the rows it filters on cannot disagree.
_INVISIBLE = dict.fromkeys(
    map(ord, "\u00a0\u2007\u202f\u200b\u200c\u200d\ufeff\t\r\n"), " "
)
_MISSING_TEXT = {"", "NAN", "NONE", "NAT", "NULL", "<NA>", "(BLANK)"}


def clean_label(value, missing: str | None = None) -> str:
    """One display label: invisible spaces folded, runs of spaces collapsed.

    ``missing`` is returned for a null or a null-like token. Without it a null
    comes back as an empty string, which is what a caller building a set of
    options should skip.
    """
    if value is None:
        return missing or ""
    if isinstance(value, float) and np.isnan(value):
        return missing or ""
    text = str(value).translate(_INVISIBLE)
    text = " ".join(text.split())
    if text.upper() in _MISSING_TEXT:
        return missing or ""
    return text


def label_key(value, missing: str | None = None) -> str:
    """The comparison key for a label: cleaned, then case-folded.

    Two rows that spell one country differently ("Germany" and "gerMANY") are
    one country. Grouping, option lists, and the filter comparison all compare
    on this key, so a spelling difference cannot split one bond across two
    values of the same selection box. Only the display spelling differs, and
    ``canonical_labels`` decides that.
    """
    return clean_label(value, missing).casefold()


def canonical_labels(values, missing: str | None = None) -> pd.Series:
    """One display spelling per distinct value, matched case-insensitively.

    The most frequent spelling wins; a tie goes to the alphabetically first.
    The rule is deterministic, so the same rows always produce the same label
    and two frames that share a value agree on how it is written.
    """
    cleaned = values.map(lambda value: clean_label(value, missing))
    keys = cleaned.map(lambda text: str(text).casefold())
    if cleaned.empty:
        return cleaned
    # An explicit two-column frame: the source column's own name would clash
    # with the reset_index() column and would be named like a dimension.
    counts = (
        pd.DataFrame({"label": cleaned.to_numpy(), "key": keys.to_numpy()})
        .groupby(["key", "label"], dropna=False)
        .size()
        .rename("_n")
        .reset_index()
    )
    counts = counts.sort_values(
        ["key", "_n", "label"],
        ascending=[True, False, True],
        kind="mergesort",
    )
    best = counts.drop_duplicates("key").set_index("key")["label"]
    return keys.map(best)


def label_conflicts(
    frames: list[pd.DataFrame],
    columns: tuple[str, ...] = ("Country", "Sector", "Rating Bucket", "Currency"),
    identity: tuple[str, ...] = ("ID",),
) -> dict[str, int]:
    """How many identities carry more than one label in a display column.

    A bond has one country, one sector, one rating bucket, and one currency.
    Two labels for one ID is what makes the same bond show up under two values
    of the same selection box, which is exactly the reporting symptom this
    check exists to catch: the detail panel shows one rating while the filter
    offers two.

    The count is a diagnostic, never a silent repair. ``0`` for every column is
    the expected state; anything else is named in the log so it can be traced to
    the request that returned it.
    """
    usable = [
        frame
        for frame in frames
        if isinstance(frame, pd.DataFrame) and not frame.empty
    ]
    keys = [column for column in identity if column in (usable[0].columns if usable else ())]
    if not usable or not keys:
        return {}
    merged = pd.concat(usable, ignore_index=True)
    out: dict[str, int] = {}
    for column in columns:
        if column not in merged.columns:
            continue
        work = merged.loc[:, [*keys, column]].copy()
        work[column] = work[column].map(lambda value: label_key(value, config.DESCRIPTOR_BLANK))
        distinct = work.groupby(list(keys), dropna=False, sort=False)[column].nunique()
        conflicts = int((distinct > 1).sum())
        if conflicts:
            out[column] = conflicts
    return out


def rating_bucket(value) -> str:
    """Map one ``rating()`` value to a letter bucket.

    The value is shown as returned; nothing is invented. A numeric rating is
    labelled unmapped rather than converted, because the numeric scale is not
    established for this app (``RAG KB/29``).

    The text is normalised first (``clean_label``), then a parenthetical suffix
    such as ``(P)``, ``(EXP)``, or ``(DEF)`` is removed from anywhere in the
    value. A dual-agency value is graded on both halves and only takes a letter
    bucket when they agree; a genuinely split rating stays ``Other`` rather than
    being forced into IG or HY on one agency's word.
    """
    text = clean_label(value)
    # An unavailable rating is a failed request, not an unrated bond. Collapsing
    # the two made "we never got the field" read as "the issuer has no rating",
    # which is the exact blank-versus-unavailable distinction the rest of this
    # screen keeps apart.
    if text == config.DESCRIPTOR_UNAVAILABLE:
        return config.DESCRIPTOR_UNAVAILABLE
    if not text:
        return RATING_NR_LABEL
    compact = text.upper().replace(" ", "")
    try:
        float(compact)
        return RATING_UNMAPPED_LABEL
    except ValueError:
        pass
    token = re.sub(r"\([^)]*\)", "", compact)
    if not token:
        return RATING_NR_LABEL
    # "N.A." is Bloomberg's own not-applicable token. "MBS/TBA" is the one extra
    # token folded into it: a pass-through has no issuer letter grade, so N.A.
    # states that, while "Other" would claim a rating the app does not have.
    if token == RATING_NA_LABEL or token == "MBS/TBA":
        return RATING_NA_LABEL
    if token in NR_TOKENS:
        return RATING_NR_LABEL
    parts = [part for part in re.split(r"[/,;]", token) if part]
    buckets = {_single_rating_bucket(part) for part in parts} if parts else set()
    if len(buckets) == 1:
        return buckets.pop()
    if not buckets:
        return RATING_OTHER_LABEL
    # A split rating (one agency IG, another HY) is not silently rounded to
    # either side, and it is not "Numeric" either.
    return RATING_OTHER_LABEL


def _single_rating_bucket(token: str) -> str:
    if token in SP_IG or token in MOODY_IG:
        return "IG"
    if token in SP_HY or token in MOODY_HY:
        return "HY"
    if token in NR_TOKENS:
        return RATING_NR_LABEL
    return RATING_OTHER_LABEL


def _tenor_years(maturity: pd.Series, as_of) -> pd.Series:
    """Years to maturity from the returned Maturity date.

    This is a derived display quantity, not a separate tenor item:
    computed from a descriptor this app already requests. A blank or
    unparseable maturity stays NaN and lands in the Missing bucket; it is never
    filled from another field.
    """
    anchor = pd.Timestamp(as_of).normalize()
    parsed = pd.to_datetime(maturity, errors="coerce")
    years = (parsed - anchor).dt.days / 365.25
    years = years.where(np.isfinite(years))
    negative = years < 0
    # A bond already past maturity is bad descriptor data, so it is Missing
    # rather than a negative bucket.
    return years.mask(negative)


def tenor_bucket(years: pd.Series) -> pd.Series:
    """Bucket tenor years without leaving a NaN label behind."""
    buckets = config.TENOR_BINS
    labels = config.TENOR_LABELS
    out = pd.Series(
        config.TENOR_MISSING_LABEL, index=years.index, dtype="object"
    )
    for position, label in enumerate(labels):
        lower = buckets[position]
        upper = buckets[position + 1] if position + 1 < len(buckets) else None
        mask = years.ge(lower) if upper is None else years.ge(lower) & years.lt(upper)
        out = out.mask(mask.fillna(False), label)
    return out


def _text_dimension(frame: pd.DataFrame, column: str, missing: str) -> pd.Series:
    """A displayed text dimension with an explicit label for a blank value.

    Country and Sector arrive as free text from Bloomberg. A blank value stays
    visible as ``(blank)`` so it can be filtered on, and an absent column
    becomes one explicit ``missing`` label for every row. The two are kept
    apart on purpose: ``(unavailable)`` means the descriptor request failed,
    ``(blank)`` means Bloomberg returned nothing for that bond.
    """
    if column not in frame.columns:
        return pd.Series(missing, index=frame.index, dtype="object")
    blank = config.DESCRIPTOR_BLANK
    return frame[column].map(lambda value: clean_label(value, blank))


def enrich_ranked(
    frame: pd.DataFrame | None,
    as_of,
    side: str | None = None,
) -> pd.DataFrame:
    """Add the display dimensions to one ranked side.

    Only columns this app already has are used. A missing descriptor column
    becomes an explicit Missing label instead of raising, so one failed
    descriptor request cannot blank the filters or the charts.

    The book column of the two-book comparison is carried through unchanged. A
    one-book run has no book column at all: a constant label column saying
    "Universe" on every row is noise in the table and in the Excel copy, and the
    universe is already stated in the status bar and the detail panel.
    """
    columns = [
        "ID",
        "Change",
        "Side",
        "Country",
        "Sector",
        "Currency",
        "Rating Bucket",
        "Tenor Bucket",
    ]
    if frame is None or frame.empty:
        return pd.DataFrame(columns=columns)
    out = frame.copy()
    if config.UNIVERSE_COLUMN in out.columns:
        # A two-book run labels every row with its own book; a blank label can
        # only mean the ranking lost it, and it stays visible as such.
        out[config.UNIVERSE_COLUMN] = out[config.UNIVERSE_COLUMN].map(
            lambda value: clean_label(value, "(unknown)")
        )
    # Country and Sector are the two extra descriptors the filters need. A
    # failed request leaves the column absent here and the label explicit, so
    # the filter never silently shows another field's values.
    out["Country"] = _text_dimension(out, "Country", config.DESCRIPTOR_UNAVAILABLE)
    out["Sector"] = _text_dimension(out, "Sector", config.DESCRIPTOR_UNAVAILABLE)
    out["Currency"] = _text_dimension(
        out, "Currency", config.DESCRIPTOR_UNAVAILABLE
    )
    if "Rating" in out.columns:
        # One normalisation for the displayed rating and the bucket derived
        # from it, so the two can never describe the same bond differently.
        out["Rating"] = out["Rating"].map(
            lambda value: clean_label(value, config.DESCRIPTOR_BLANK)
        )
        out["Rating Bucket"] = out["Rating"].map(rating_bucket)
    else:
        # No Rating column at all means the request never returned it. That is
        # unavailable, not "every bond is unrated"; `rating_bucket` keeps the
        # same label for a value that arrived as `(unavailable)`.
        out["Rating Bucket"] = config.DESCRIPTOR_UNAVAILABLE
    if "Maturity" in out.columns:
        out["Tenor Bucket"] = tenor_bucket(_tenor_years(out["Maturity"], as_of))
    else:
        out["Tenor Bucket"] = config.TENOR_MISSING_LABEL
    if side is not None:
        out["Side"] = side
    return out.reset_index(drop=True)


def filter_choices(frames: list[pd.DataFrame]) -> dict[str, list[str]]:
    """Distinct values per filter column, in a stable display order.

    ``(All)`` is added by the caller, not here, because it is a widget state
    and not a data value.

    Every value goes through ``canonical_labels``, the same normalisation the
    rows carry, so an option can never be a visually identical near-duplicate of
    a row's label. That is what stops one bond from looking like it belongs to
    two values of the same box.

    A blank is offered as ``(blank)`` rather than dropped. Bloomberg returns an
    empty ``classification_name`` for much of the US MBS/TBA in a global bond
    index (``RAG KB/08``), so dropping it would make those rows unreachable by
    any filter and, worse, would let a Sector filter remove them with no
    diagnostic.
    """
    choices: dict[str, list[str]] = {}
    for _label, column in config.FILTER_COLUMNS:
        values: set[str] = set()
        for frame in frames:
            if frame is None or frame.empty or column not in frame.columns:
                continue
            labels = canonical_labels(frame[column], config.DESCRIPTOR_BLANK)
            for text in labels.unique():
                if text:
                    values.add(str(text))
        choices[column] = sorted(values)
    return choices


def apply_dimension_filters(
    frame: pd.DataFrame | None,
    filters: dict[str, set[str]] | None,
) -> pd.DataFrame:
    """Apply the visible dimension filters to one frame.

    An empty filter set means "no restriction", which is what ``(All)`` alone
    produces. A filter on a column the frame does not carry keeps the frame
    rather than silently emptying it. The comparison is made on the same
    normalised key the option list was built from, so a value that differs
    only by an invisible space or by letter case still matches its option
    instead of silently dropping the row.
    """
    if frame is None or frame.empty:
        return frame if frame is not None else pd.DataFrame()
    if not filters:
        return frame
    out = frame
    for column, wanted in filters.items():
        if not wanted or column not in out.columns:
            continue
        # Both sides use the same sentinel: a blank cell keys to ``(blank)``,
        # exactly the label the option list offers and the bucket table draws.
        # Without it, picking ``(blank)`` would match nothing.
        labels = out[column].map(
            lambda value: label_key(value, config.DESCRIPTOR_BLANK)
        )
        wanted_keys = {
            label_key(value, config.DESCRIPTOR_BLANK) for value in wanted
        }
        out = out.loc[labels.isin(wanted_keys)]
        if out.empty:
            break
    return out.reset_index(drop=True)


def summarize_by_dimension(
    frame: pd.DataFrame | None,
    dimension: str,
) -> pd.DataFrame:
    """One row per bucket: how many move each way, and the net change.

    Counts are the primary ranking here. The net change is the sum of the
    signed changes inside the bucket, which keeps widening and tightening on
    opposite sides of zero instead of cancelling into a false "no movement".
    """
    columns = [
        dimension,
        "Increases",
        "Decreases",
        "Total",
        "Increase Spread",
        "Decrease Spread",
        "Net Change",
        "Abs Change",
    ]
    if frame is None or frame.empty or dimension not in frame.columns:
        return pd.DataFrame(columns=columns)
    work = frame.copy()
    work["Change"] = _as_float(work["Change"])
    work = work.loc[work["Change"].notna()]
    if work.empty:
        return pd.DataFrame(columns=columns)
    work[dimension] = canonical_labels(work[dimension], config.DESCRIPTOR_BLANK)
    # Indicator columns keep the aggregation vectorised: no per-group Python
    # closure, so the same code is fast on a large book.
    work["_increase"] = (work["Change"] > 0).astype("int64")
    work["_decrease"] = (work["Change"] < 0).astype("int64")
    work["_abs"] = work["Change"].abs()
    # Two separate sums, not one net figure: a bucket that added 3 bp in one
    # bond and lost 3 bp in another has a net of zero and is not flat. The
    # decrease side is kept negative so it draws to the left of zero and
    # ``Increase Spread + Decrease Spread`` is exactly ``Net Change``.
    work["_increase_spread"] = work["Change"].where(work["Change"] > 0, 0.0)
    work["_decrease_spread"] = work["Change"].where(work["Change"] < 0, 0.0)
    grouped = work.groupby(dimension, dropna=False, sort=False)
    summary = grouped.agg(
        Increases=("_increase", "sum"),
        Decreases=("_decrease", "sum"),
        Net_Change=("Change", "sum"),
        Abs_Change=("_abs", "sum"),
        Increase_Spread=("_increase_spread", "sum"),
        Decrease_Spread=("_decrease_spread", "sum"),
    ).reset_index()
    summary = summary.rename(
        columns={
            "Net_Change": "Net Change",
            "Abs_Change": "Abs Change",
            "Increase_Spread": "Increase Spread",
            "Decrease_Spread": "Decrease Spread",
        }
    )
    summary["Increases"] = summary["Increases"].astype("int64")
    summary["Decreases"] = summary["Decreases"].astype("int64")
    summary["Total"] = summary["Increases"] + summary["Decreases"]
    summary = summary.loc[:, columns]
    return summary.sort_values(
        ["Total", "Abs Change", dimension], ascending=[False, False, True], kind="mergesort"
    ).reset_index(drop=True)


def bucket_chart_rows(
    summary: pd.DataFrame | None,
    dimension: str,
    limit: int = None,
) -> tuple[list[str], list[float], list[float]]:
    """Chart-ready parallel lists: bucket labels, increases, decreases.

    Past ``limit`` buckets the remaining rows collapse into one Others row, so
    a long tail cannot push the bars off the chart.
    """
    limit = config.BUCKET_CHART_TOP if limit is None else int(limit)
    if summary is None or summary.empty:
        return [], [], []
    frame = summary.copy()
    label_column = dimension if dimension in frame.columns else frame.columns[0]
    labels = [str(value) for value in frame[label_column]]
    increases = [_as_count(value) for value in frame.get("Increases", [])]
    decreases = [_as_count(value) for value in frame.get("Decreases", [])]
    if len(labels) <= limit:
        return labels, increases, decreases
    kept = limit
    tail_labels = labels[kept:]
    rest = f"Others ({len(tail_labels)})"
    return (
        labels[:kept] + [rest],
        increases[:kept] + [sum(increases[kept:])],
        decreases[:kept] + [sum(decreases[kept:])],
    )


def bucket_spread_rows(
    summary: pd.DataFrame | None,
    dimension: str,
    limit: int = None,
) -> tuple[list[str], list[float], list[float]]:
    """Chart-ready spread sums: bucket labels, increase side, decrease side.

    Same labels and the same Top-N cut as ``bucket_chart_rows``, so the movers
    chart and the spread chart above one table always list the same buckets in
    the same order. The decrease side is returned negative: it is drawn left of
    the shared zero line, and it is not an absolute value.
    """
    limit = config.BUCKET_CHART_TOP if limit is None else int(limit)
    if summary is None or summary.empty:
        return [], [], []
    frame = summary.copy()
    label_column = dimension if dimension in frame.columns else frame.columns[0]
    labels = [str(value) for value in frame[label_column]]
    increases = [_as_sum(value) for value in frame.get("Increase Spread", [])]
    decreases = [-abs(_as_sum(value)) for value in frame.get("Decrease Spread", [])]
    if len(labels) <= limit:
        return labels, increases, decreases
    kept = limit
    rest = f"Others ({len(labels) - kept})"
    return (
        labels[:kept] + [rest],
        increases[:kept] + [round(sum(increases[kept:]), 6)],
        decreases[:kept] + [round(sum(decreases[kept:]), 6)],
    )


def _bucket_order(merged: pd.DataFrame, dimension: str) -> list[str]:
    """Bucket labels by total row count, largest first, ties alphabetically.

    The two diverging charts and the full bucket table all take their order
    from this one function, so a bucket is on the same line in all three.
    """
    # Canonicalise BEFORE counting: two spellings of one bucket must add up to
    # one row count, not produce two identical labels in the order.
    frame = merged.copy()
    frame[dimension] = canonical_labels(frame[dimension], config.DESCRIPTOR_BLANK)
    counts = frame.groupby(dimension, dropna=False, sort=False).size()
    frame = counts.reset_index()
    frame.columns = ["_bucket", "_rows"]
    frame = frame.sort_values(
        ["_rows", "_bucket"], ascending=[False, True], kind="mergesort"
    )
    return [str(value) for value in frame["_bucket"]]


def bucket_diverging_rows(
    frames: list[pd.DataFrame | None],
    dimension: str,
    books: tuple[str, ...],
    metric: str = "count",
    limit: int = None,
) -> tuple[list[str], dict[str, list[float]], dict[str, list[float]]]:
    """One chart's worth of diverging rows, per book, cut to Top N plus Others.

    ``metric="count"`` reads the mover counts; ``metric="spread"`` reads the two
    signed spread sums. Both take the same bucket order and the same Top-N cut,
    so the movers chart and the spread chart above one table list identical
    buckets in identical positions.

    The decrease side is negative for both metrics: it is drawn left of the
    shared zero line. Nothing is recomputed beyond a sum of the loaded changes.
    """
    limit = config.BUCKET_CHART_TOP if limit is None else int(limit)
    usable = [
        frame for frame in frames if isinstance(frame, pd.DataFrame) and not frame.empty
    ]
    if not usable or not dimension:
        return [], {}, {}
    merged = pd.concat(usable, ignore_index=True)
    if dimension not in merged.columns:
        return [], {}, {}
    work = merged.copy()
    work["Change"] = _as_float(work["Change"])
    work = work.loc[work["Change"].notna()].copy()
    if work.empty:
        return [], {}, {}
    work[dimension] = canonical_labels(work[dimension], config.DESCRIPTOR_BLANK)
    if books and config.UNIVERSE_COLUMN in work.columns:
        work["_book"] = (
            work[config.UNIVERSE_COLUMN].fillna("").astype(str).str.strip()
        )
    else:
        work["_book"] = books[0] if books else ""
    labels = _bucket_order(work, dimension)
    spread = str(metric) == "spread"
    increases: dict[str, list[float]] = {}
    decreases: dict[str, list[float]] = {}
    for book in books or ("",):
        block = work.loc[work["_book"] == book]
        summary = summarize_by_dimension(block, dimension)
        lookup: dict[str, tuple[float, float]] = {}
        if summary is not None and not summary.empty:
            for _, row in summary.iterrows():
                if spread:
                    up = _as_sum(row.get("Increase Spread"))
                    down = _as_sum(row.get("Decrease Spread"))
                else:
                    up = float(_as_count(row.get("Increases")))
                    down = float(_as_count(row.get("Decreases")))
                lookup[str(row[dimension])] = (up, down)
        increases[book] = [lookup.get(label, (0.0, 0.0))[0] for label in labels]
        decreases[book] = [-abs(lookup.get(label, (0.0, 0.0))[1]) for label in labels]
    if len(labels) <= limit:
        return labels, increases, decreases
    kept = limit
    rest = f"Others ({len(labels) - kept})"
    out_increases: dict[str, list[float]] = {}
    out_decreases: dict[str, list[float]] = {}
    for book in books or ("",):
        out_increases[book] = increases[book][:kept] + [
            round(sum(increases[book][kept:]), 6)
        ]
        out_decreases[book] = decreases[book][:kept] + [
            round(sum(decreases[book][kept:]), 6)
        ]
    return labels[:kept] + [rest], out_increases, out_decreases


BUCKET_TABLE_COLUMNS = (
    "Bucket",
    "Increases",
    "Decreases",
    "Increase Spread",
    "Decrease Spread",
    "Net Change",
)
COMPARISON_BUCKET_COLUMNS = (
    "Bucket",
    config.UNIVERSE_COLUMN,
    "Increases",
    "Decreases",
    "Increase Spread",
    "Decrease Spread",
    "Net Change",
)


def bucket_table(
    frames: list[pd.DataFrame | None],
    dimension: str,
    books: tuple[str, ...] = (),
) -> pd.DataFrame:
    """The full bucket table under the two charts, in the chart's bucket order.

    Full means full: a bucket past the charts' Top-10 cut keeps its own row
    here instead of hiding inside ``Others``, because the table is where the
    numbers are read. One book yields one row per bucket; a two-book run yields
    one row per ``(bucket, book)`` pair, AIM above Index, so a bucket can be
    compared line by line with the two charts above it.

    Spread sums are rounded for display only; nothing is recomputed, and no
    value is filled or substituted.
    """
    usable = [
        frame
        for frame in frames
        if isinstance(frame, pd.DataFrame) and not frame.empty
    ]
    if not usable or not dimension:
        return pd.DataFrame(columns=list(BUCKET_TABLE_COLUMNS))
    merged = pd.concat(usable, ignore_index=True)
    if dimension not in merged.columns:
        return pd.DataFrame(columns=list(BUCKET_TABLE_COLUMNS))
    has_book = (
        bool(books) and config.UNIVERSE_COLUMN in merged.columns
    )
    if not has_book:
        summary = summarize_by_dimension(merged, dimension)
        return _bucket_display(summary, dimension, None, _bucket_order(merged, dimension))
    merged = merged.copy()
    merged[config.UNIVERSE_COLUMN] = (
        merged[config.UNIVERSE_COLUMN].fillna("").astype(str).str.strip()
    )
    per_book = {
        book: summarize_by_dimension(
            merged.loc[merged[config.UNIVERSE_COLUMN] == book], dimension
        )
        for book in books
    }
    rows = []
    for bucket in _bucket_order(merged, dimension):
        for book in books:
            summary = per_book.get(book)
            if summary is None or summary.empty:
                continue
            line = summary.loc[summary[dimension].astype(str) == str(bucket)]
            if line.empty:
                continue
            row = {"Bucket": str(bucket), config.UNIVERSE_COLUMN: str(book)}
            for column in BUCKET_TABLE_COLUMNS[1:]:
                row[column] = line.iloc[0][column]
            rows.append(row)
    if not rows:
        return pd.DataFrame(columns=list(COMPARISON_BUCKET_COLUMNS))
    return _round_spread_columns(pd.DataFrame(rows, columns=list(COMPARISON_BUCKET_COLUMNS)))


def _bucket_display(
    summary: pd.DataFrame,
    dimension: str,
    book: str | None,
    order: list[str] | None = None,
) -> pd.DataFrame:
    """Rename the dimension column to ``Bucket`` and keep the display columns."""
    if summary is None or summary.empty:
        return pd.DataFrame(columns=list(BUCKET_TABLE_COLUMNS))
    frame = summary.copy()
    frame = frame.rename(columns={dimension: "Bucket"})
    columns = [column for column in BUCKET_TABLE_COLUMNS if column in frame.columns]
    out = frame.loc[:, columns].copy()
    if order:
        rank = {str(label): position for position, label in enumerate(order)}
        out["_rank"] = out["Bucket"].astype(str).map(rank).fillna(len(rank)).astype(int)
        out = out.sort_values("_rank", kind="mergesort").drop(columns=["_rank"])
    if book is not None:
        out.insert(1, config.UNIVERSE_COLUMN, book)
    return _round_spread_columns(out)


def _round_spread_columns(frame: pd.DataFrame) -> pd.DataFrame:
    """Four decimals on the two spread columns, display only."""
    out = frame.copy()
    for column in ("Increase Spread", "Decrease Spread", "Net Change"):
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce").round(4)
    return out


def _as_sum(value) -> float:
    """A float for a summed spread; an unreadable cell counts as 0, not NaN."""
    number = pd.to_numeric(pd.Series([value]), errors="coerce").iloc[0]
    if pd.isna(number):
        return 0.0
    return float(number)


DAILY_COLUMNS = ("Date", "Spread", "Change vs previous observation")


def daily_spread_rows(
    series: pd.DataFrame | None,
    identifier: str,
) -> pd.DataFrame:
    """One row per observation date for one security, oldest first.

    Every row here is an observation the window request actually returned. A
    weekend, a holiday, or a day with no quote has no row at all: it is absent
    rather than forward-filled or zero-filled, so a gap in the table is a real
    gap in the source. The last column is the difference from the previous
    observation and is arithmetic on these same values, not a new data item.
    """
    wanted = str(identifier or "").strip()
    if not wanted or series is None or series.empty:
        return pd.DataFrame(columns=list(DAILY_COLUMNS))
    missing = sorted({"ID", "DATE", "Spread"} - set(series.columns))
    if missing:
        return pd.DataFrame(columns=list(DAILY_COLUMNS))
    work = series.loc[:, ["ID", "DATE", "Spread"]].copy()
    work["ID"] = work["ID"].astype("string").fillna("").str.strip()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work["Spread"] = _as_float(work["Spread"])
    work = work.loc[
        work["ID"].eq(wanted) & work["DATE"].notna() & work["Spread"].notna()
    ].copy()
    if work.empty:
        return pd.DataFrame(columns=list(DAILY_COLUMNS))
    work = work.drop_duplicates(["DATE"], keep="last").sort_values(
        "DATE", kind="mergesort"
    )
    values = work["Spread"].astype(float)
    return pd.DataFrame(
        {
            "Date": [stamp.date().isoformat() for stamp in work["DATE"]],
            "Spread": values.round(6).tolist(),
            "Change vs previous observation": (
                values.diff().round(6).tolist()
            ),
        },
        columns=list(DAILY_COLUMNS),
    )


def _as_count(value) -> int:
    number = pd.to_numeric(pd.Series([value]), errors="coerce").iloc[0]
    if pd.isna(number):
        return 0
    return int(number)


def spread_paths(
    series: pd.DataFrame | None,
    ids: list[str] | None = None,
) -> pd.DataFrame:
    """Pivot the candidate series to ``DATE`` x ``ID`` for the path chart.

    Rows keep their original ``DATE`` index so the x axis is the real
    observation date, never a row position. Missing observations stay NaN
    instead of being forward-filled: a gap is information.
    """
    if series is None or series.empty:
        return pd.DataFrame()
    missing = sorted({"ID", "DATE", "Spread"} - set(series.columns))
    if missing:
        return pd.DataFrame()
    work = series.loc[:, ["ID", "DATE", "Spread"]].copy()
    work["ID"] = work["ID"].astype("string").fillna("").str.strip()
    work["DATE"] = pd.to_datetime(work["DATE"], errors="coerce")
    work["Spread"] = _as_float(work["Spread"])
    work = work.loc[
        work["ID"].ne("") & work["DATE"].notna() & work["Spread"].notna()
    ].copy()
    if work.empty:
        return pd.DataFrame()
    wanted = None if ids is None else {str(value) for value in ids}
    if wanted is not None:
        work = work.loc[work["ID"].isin(wanted)]
        if work.empty:
            return pd.DataFrame()
    work = work.drop_duplicates(["ID", "DATE"], keep="last")
    wide = work.pivot(index="DATE", columns="ID", values="Spread")
    return wide.sort_index()


# ---------------------------------------------------------------------------
# AIM vs Index comparison
# ---------------------------------------------------------------------------

COMPARISON_COLUMNS = (
    "Universe",
    "Movers",
    "Increases",
    "Decreases",
    "Net Change",
    "Mean Change",
    "Widest",
    "Mean Duration",
    "Top bucket",
)


def summarize_comparison(
    frames: list[pd.DataFrame | None],
    dimension: str = "Country",
) -> pd.DataFrame:
    """One row per book, so AIM and Index are measured on the same measures.

    The same ranked-change frames the tables and charts already use are read
    here; nothing is recomputed and no request is sent. A book with no row
    keeps a line with zero movers instead of disappearing, because a missing
    book in a comparison reads as "no difference" when it is really "no data".
    """
    if not frames:
        return pd.DataFrame(columns=COMPARISON_COLUMNS)
    usable = [frame for frame in frames if isinstance(frame, pd.DataFrame)]
    usable = [frame for frame in usable if not frame.empty]
    if not usable:
        return pd.DataFrame(columns=COMPARISON_COLUMNS)
    merged = pd.concat(usable, ignore_index=True)
    if config.UNIVERSE_COLUMN not in merged.columns:
        return pd.DataFrame(columns=COMPARISON_COLUMNS)
    merged = merged.copy()
    merged["Change"] = _as_float(merged["Change"])
    merged = merged.loc[merged["Change"].notna()].copy()
    if merged.empty:
        return pd.DataFrame(columns=COMPARISON_COLUMNS)
    merged[config.UNIVERSE_COLUMN] = (
        merged[config.UNIVERSE_COLUMN].fillna("").astype(str).str.strip()
    )
    merged["_increase"] = (merged["Change"] > 0).astype("int64")
    merged["_decrease"] = (merged["Change"] < 0).astype("int64")
    merged["_abs"] = merged["Change"].abs()
    if dimension in merged.columns:
        merged[dimension] = canonical_labels(merged[dimension], config.DESCRIPTOR_BLANK)

    rows = []
    for book, group in merged.groupby(config.UNIVERSE_COLUMN, sort=True):
        top_bucket = ""
        if dimension in group.columns and not group.empty:
            counts = group.groupby(dimension, sort=False).size()
            if not counts.empty:
                top_bucket = str(counts.idxmax())
        duration = group.get("Duration")
        mean_duration = pd.NA
        if duration is not None:
            numeric = pd.to_numeric(duration, errors="coerce")
            if numeric.notna().any():
                mean_duration = float(numeric.mean())
        rows.append(
            {
                "Universe": str(book),
                "Movers": int(len(group)),
                "Increases": int(group["_increase"].sum()),
                "Decreases": int(group["_decrease"].sum()),
                "Net Change": float(group["Change"].sum()),
                "Mean Change": float(group["Change"].mean()),
                "Widest": float(group.loc[group["_abs"].idxmax(), "Change"]),
                "Mean Duration": mean_duration,
                "Top bucket": top_bucket,
            }
        )
    summary = pd.DataFrame(rows, columns=list(COMPARISON_COLUMNS))
    return summary.reset_index(drop=True)


def comparison_bucket_rows(
    summary: pd.DataFrame | None,
    dimension: str,
    books: tuple[str, ...],
    limit: int = None,
) -> tuple[list[str], dict[str, list[float]], dict[str, list[float]]]:
    """Chart-ready counts per bucket, one increase and decrease list per book.

    ``summary`` is the output of ``summarize_by_dimension`` run on each book's
    rows after stacking them with the book column, so the labels are shared.
    Past ``limit`` buckets the tail collapses into one Others row per book.
    """
    limit = config.BUCKET_CHART_TOP if limit is None else int(limit)
    if summary is None or summary.empty or dimension not in summary.columns:
        return [], {}, {}
    frame = summary.copy()
    labels = [str(value) for value in frame[dimension]]
    increases: dict[str, list[float]] = {}
    decreases: dict[str, list[float]] = {}
    for book in books:
        column = f"{book} increases"
        increases[book] = [
            _as_count(value) for value in frame.get(column, [0] * len(labels))
        ]
        column = f"{book} decreases"
        decreases[book] = [
            _as_count(value) for value in frame.get(column, [0] * len(labels))
        ]
    if len(labels) <= limit:
        return labels, increases, decreases
    kept = limit
    rest = f"Others ({len(labels) - kept})"
    tail_labels = [rest]
    for book in books:
        increases[book] = increases[book][:kept] + [sum(increases[book][kept:])]
        decreases[book] = decreases[book][:kept] + [sum(decreases[book][kept:])]
    return labels[:kept] + tail_labels, increases, decreases


def stack_by_book(
    frames: list[pd.DataFrame | None],
    dimension: str,
) -> pd.DataFrame:
    """Stack the ranked sides of both books, then count each direction per book.

    The output has one row per bucket and four count columns
    (``<book> increases`` / ``<book> decreases``), which is exactly what the
    comparison chart reads. A book with no rows contributes no column, and the
    chart then draws only the book that returned data.
    """
    usable = [
        frame
        for frame in frames
        if isinstance(frame, pd.DataFrame) and not frame.empty
    ]
    if not usable:
        return pd.DataFrame()
    merged = pd.concat(usable, ignore_index=True)
    if dimension not in merged.columns or config.UNIVERSE_COLUMN not in merged.columns:
        return pd.DataFrame()
    work = merged.copy()
    work["Change"] = _as_float(work["Change"])
    work = work.loc[work["Change"].notna()].copy()
    if work.empty:
        return pd.DataFrame()
    work[dimension] = canonical_labels(work[dimension], config.DESCRIPTOR_BLANK)
    work[config.UNIVERSE_COLUMN] = (
        work[config.UNIVERSE_COLUMN].fillna("").astype(str).str.strip()
    )
    work["_increase"] = (work["Change"] > 0).astype("int64")
    work["_decrease"] = (work["Change"] < 0).astype("int64")
    grouped = work.groupby(
        [dimension, config.UNIVERSE_COLUMN], dropna=False, sort=False
    ).agg(
        Increases=("_increase", "sum"),
        Decreases=("_decrease", "sum"),
        Rows=("Change", "size"),
    )
    grouped = grouped.reset_index()
    # The chart order is by mover count per bucket across both books, so a
    # bucket that only one book carries still sorts by its real size.
    order = (
        grouped.groupby(dimension, sort=False)["Rows"]
        .sum()
        .sort_values(ascending=False, kind="mergesort")
    )
    wide = grouped.pivot(
        index=dimension, columns=config.UNIVERSE_COLUMN, values=["Increases", "Decreases"]
    )
    wide.columns = [f"{book} {measure.lower()}" for measure, book in wide.columns]
    wide = wide.fillna(0).reindex(order.index).reset_index()
    return wide


# ---------------------------------------------------------------------------
# Export Excel: the copy/paste contract used by FI Index Change
# ---------------------------------------------------------------------------


def _export_cell(value) -> str:
    """One exported cell as text. Blank stays empty, never the string 'nan'."""
    if value is None or value is pd.NA:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)


def export_display_frame(
    frame: pd.DataFrame | None,
    columns: tuple[str, ...] | list[str] | None = None,
) -> pd.DataFrame:
    """Copy-to-Excel frame: a repeated header row first, then the data as text.

    A widget DataGrid copy does not carry the column header. Repeating the
    column names in the first data row keeps the header when the whole table is
    pasted into Excel. This is the same contract as FI Index Change
    (``export_display_frame`` there), so both apps paste the same way.
    """
    if frame is None:
        frame = pd.DataFrame()
    if columns is None:
        keep = list(frame.columns)
    else:
        # The requested columns are kept even when the run did not produce one:
        # a missing column keeps its header and exports a blank cell, so the
        # paste still lines up with the header row.
        keep = list(columns)
    header = [str(column) for column in keep]
    rows = []
    if not frame.empty and keep:
        rows = [
            [_export_cell(row_map.get(column)) for column in keep]
            for row_map in frame.to_dict(orient="records")
        ]
    return pd.DataFrame([header] + rows, columns=keep)
