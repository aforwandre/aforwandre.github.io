"""FI Spread Movement Monitoring BQuant application."""

from __future__ import annotations

__all__ = ["FISpreadMovementApp"]


def __getattr__(name):
    if name == "FISpreadMovementApp":
        from .app import FISpreadMovementApp

        return FISpreadMovementApp
    raise AttributeError(name)
