"""Chart specifications for the spread-mover screen.

One module, two renderers. Desktop gets Plotly ``FigureWidget`` objects, which
support in-place ``batch_update()`` and the click-to-select detail panel. The
local preview cannot import Plotly, so it renders the *same* specification as
inline SVG. Neither renderer computes anything: every number here comes from
``engine.py``, so the two front ends cannot disagree about the data.

Only this module knows about a plotting library, and it imports it lazily. That
is deliberate: ``engine.py`` stays pure pandas and the tests stay importable on
a machine with no Plotly installed.
"""

from __future__ import annotations

from html import escape

import pandas as pd

from . import config


def plotly_available() -> bool:
    """True when ``go.FigureWidget`` can be built in this kernel."""
    try:
        import plotly.graph_objects as go  # noqa: F401
    except Exception:
        return False
    try:
        import ipywidgets  # noqa: F401
    except Exception:
        return False
    return True


def _first_last(values) -> str:
    """``first → last`` for the fallback table, or an em dash when empty.

    The fallback is the only renderer on a kernel without Plotly, so it must not
    raise on a trace that carries no observation.
    """
    numeric = [value for value in (values or []) if isinstance(value, (int, float))]
    if not numeric:
        return "\u2014"
    return f"{numeric[0]:.4f} \u2192 {numeric[-1]:.4f}"


def html_fallback(spec: dict) -> str:
    """Table form of a specification, used when Plotly is unavailable.

    The local preview replaces this function with an SVG renderer, so the
    preview shows a real chart from the same spec. On a kernel without Plotly
    the Desktop app falls back to this table, which keeps the numbers visible
    instead of dropping the panel.
    """
    title = escape(str(spec.get("title", "")))
    if spec.get("empty"):
        # A spec may carry its own sentence: "Select a bond to view its spread
        # path" is a different state from "no rows passed the filters", and the
        # operator must not have to guess which one they are looking at.
        note = str(spec.get("note", "") or "").strip()
        return (
            f"<h4>{title}</h4><p style='margin:4px 0;color:#8a5a00'>"
            f"{escape(note) if note else 'No rows to chart after the current filters.'}"
            "</p>"
        )
    kind = spec.get("kind")
    if kind == "buckets":
        labels = spec.get("labels") or []
        increases = spec.get("increases") or []
        decreases = spec.get("decreases") or []
        dimension = escape(str(spec.get("dimension", "Bucket")))
        rows = "".join(
            f"<tr><td>{escape(str(label))}</td>"
            f"<td>{int(increases[position]) if position < len(increases) else 0}</td>"
            f"<td>{int(decreases[position]) if position < len(decreases) else 0}</td></tr>"
            for position, label in enumerate(labels)
        )
        return (
            f"<h4>{title}</h4>"
            "<table border='0'><tr><th>" + dimension
            + "</th><th>Increases</th><th>Decreases</th></tr>"
            + rows + "</table>"
        )
    if kind == "changes":
        rows = "".join(
            f"<tr><td>{escape(str(row['label']))}</td>"
            f"<td>{escape(str(row['text']))}</td></tr>"
            for row in spec.get("rows") or []
        )
        return (
            f"<h4>{title}</h4>"
            "<table border='0'><tr><th>Security</th><th>Change</th></tr>"
            + rows + "</table>"
        )
    if kind == "paths":
        traces = spec.get("traces") or []
        rows = "".join(
            f"<tr><td>{escape(str(trace.get('id')))}</td>"
            f"<td>{len(trace.get('values') or [])}</td>"
            f"<td>{_first_last(trace.get('values'))}</td></tr>"
            for trace in traces
        )
        return (
            f"<h4>{title}</h4>"
            "<table border='0'><tr><th>ID</th><th>Observations</th>"
            "<th>First \u2192 last</th></tr>" + rows + "</table>"
        )
    if kind == "comparison":
        rows = spec.get("rows") or []
        dimension = escape(str(spec.get("dimension", "Bucket")))
        books = [str(book) for book in (spec.get("books") or [])]
        is_count = str(spec.get("value_format", "count")) == "count"
        header = "".join(
            f"<th>{escape(book)} increases</th><th>{escape(book)} decreases</th>"
            for book in books
        )

        def cell(value) -> str:
            return f"{int(round(value))}" if is_count else f"{float(value):+.4f}"

        body = ""
        for bucket in dict.fromkeys(str(row.get("bucket", "")) for row in rows):
            cells = "".join(
                f"<td>{cell(row.get('increase', 0))}</td>"
                f"<td>{cell(row.get('decrease', 0))}</td>"
                for book in books
                for row in rows
                if str(row.get("bucket", "")) == bucket
                and str(row.get("book", "")) == book
            )
            body += f"<tr><td>{escape(bucket)}</td>{cells}</tr>"
        return (
            f"<h4>{title}</h4>"
            f"<table border='0'><tr><th>{dimension}</th>{header}</tr>{body}</table>"
            "<p style='margin:2px 0;color:#666'>Per book and per direction; a "
            "bucket with no bar in one book has 0 there.</p>"
        )
    return ""


# ---------------------------------------------------------------------------
# Specifications. These are plain dicts, so both renderers read the same thing.
# ---------------------------------------------------------------------------


def bucket_spec(
    labels: list[str],
    increases: list[float],
    decreases: list[float],
    dimension: str,
    total_movers: int,
) -> dict:
    """Horizontal grouped bars: how many movers per bucket, by direction.

    Counts rather than a summed spread are used here on purpose. One bucket
    with two 40-unit moves and one bucket with a single 80-unit move are
    different pictures, and summing would hide the difference. The net-change
    sums stay in the table beside the chart.
    """
    return {
        "kind": "buckets",
        "dimension": dimension,
        "labels": list(labels),
        "increases": list(increases),
        "decreases": list(decreases),
        "total_movers": int(total_movers),
        "title": f"Movers by {dimension} ({int(total_movers)} ranked)",
        "x_title": "Number of ranked movers",
        "empty": not labels,
    }


def _shown_top_n(top_n: int | None) -> int:
    """The count that goes in a ranked title: the caller's, else ``TOP_N``."""
    if top_n is None:
        return config.TOP_N
    try:
        value = int(top_n)
    except (TypeError, ValueError):
        return config.TOP_N
    return value if value > 0 else config.TOP_N


def change_spec(
    frame: pd.DataFrame | None,
    side: str,
    spread_label: str,
    top_n: int | None = None,
) -> dict:
    """Signed ranked changes: one bar per security, largest magnitude first.

    ``top_n`` is the number of rows the caller drew (the ``Display Top`` box),
    used for the title only; the frame is already sliced. It defaults to
    ``config.TOP_N`` so a caller that does not slice keeps the old title.

    In the two-book comparison the bars are grouped by book rather than sorted
    across both: every AIM row, then every Index row, each block still ordered
    by magnitude. The bar chart and the Top 10 table beneath it then read top
    to bottom in the same order, which is what makes them one pair instead of
    two lists that happen to hold the same numbers.
    """
    if frame is None or frame.empty or not {"ID", "Change"} <= set(frame.columns):
        return {
            "kind": "changes",
            "side": side,
            "rows": [],
            "colors": [],
            "books": [],
            "title": f"Top {_shown_top_n(top_n)} {side.lower()}s: {spread_label} change",
            "x_title": f"{spread_label} change (source units)",
            "empty": True,
        }
    work = frame.copy()
    work["_value"] = pd.to_numeric(work["Change"], errors="coerce")
    work = work.loc[work["_value"].notna()].copy()
    work["_abs"] = work["_value"].abs()
    # Book order is the shared comparison order (AIM above Index), so this
    # order and ``config.COMPARISON_BOOK_ORDER`` cannot drift apart.
    books: list[str] = []
    if config.UNIVERSE_COLUMN in work.columns:
        work["_book"] = (
            work[config.UNIVERSE_COLUMN].fillna("").astype(str).str.strip()
        )
        present = list(dict.fromkeys(work["_book"]))
        books = [
            book for book in config.COMPARISON_BOOK_ORDER if book in present
        ] + [book for book in present if book not in config.COMPARISON_BOOK_ORDER]
        work["_rank"] = work["_book"].map(
            {book: position for position, book in enumerate(books)}
        ).fillna(len(books)).astype(int)
        work = work.sort_values(
            ["_rank", "_book", "_abs"], ascending=[True, True, False], kind="mergesort"
        )
    else:
        work = work.sort_values(["_abs"], ascending=[False], kind="mergesort")
    names = work["Name"] if "Name" in work.columns else work["ID"]
    book_column = work["_book"] if books else pd.Series([""] * len(work), index=work.index)
    rows = []
    for identifier, name, value, book_value in zip(
        work["ID"], names, work["_value"], book_column
    ):
        label = str(name).strip() or str(identifier)
        book = str(book_value).strip() if books else ""
        if len(books) > 1 and book:
            label = f"{book} \u00b7 {label}"
        rows.append(
            {
                "ID": str(identifier),
                "label": label,
                "book": book,
                "value": float(value),
                "text": f"{float(value):+.4f}",
            }
        )
    # In a two-book run the colour has to name the book, because both books sit
    # on the same side of the axis (this chart is increases only, or decreases
    # only). A one-book run keeps the single direction colour.
    if len(books) > 1:
        colors = [
            config.CHART_BOOK_COLORS.get(
                row["book"],
                config.CHART_INCREASE_COLOR
                if row["value"] > 0
                else config.CHART_DECREASE_COLOR,
            )
            for row in rows
        ]
    else:
        colors = [
            config.CHART_INCREASE_COLOR
            if row["value"] > 0
            else config.CHART_DECREASE_COLOR
            for row in rows
        ]
    return {
        "kind": "changes",
        "side": side,
        "rows": rows,
        "colors": colors,
        "books": books,
        "title": f"Top {_shown_top_n(top_n)} {side.lower()}s: {spread_label} change",
        "x_title": f"{spread_label} change (source units)",
        "empty": not rows,
    }


def path_spec(
    wide: pd.DataFrame | None,
    spread_label: str,
    start=None,
    end=None,
    selected: str | None = None,
    note: str = "",
) -> dict:
    """One line: the spread path of the security the operator selected.

    The chart used to draw every ranked candidate at once, which answered no
    question: the operator had already clicked one bond. It now draws that one
    bond, and carries a sentence for the two empty states ("nothing selected"
    and "the selected ID has no series") instead of an almost-blank plot.
    """
    window = ""
    if start is not None and end is not None:
        window = f" \u00b7 {start} \u2192 {end}"
    title = f"Spread path for the selected bond ({spread_label}{window})"
    if wide is None or wide.empty:
        return {
            "kind": "paths",
            "traces": [],
            "selected": str(selected or ""),
            "title": title,
            "x_title": "Observation date",
            "y_title": f"{spread_label} (source units)",
            "note": note,
            "empty": True,
        }
    traces = []
    for identifier in wide.columns:
        series = pd.to_numeric(wide[identifier], errors="coerce")
        keep = series.notna()
        traces.append(
            {
                "id": str(identifier),
                "dates": [str(index.date()) for index in series.index[keep]],
                "values": [float(value) for value in series[keep]],
            }
        )
    return {
        "kind": "paths",
        "traces": traces,
        "selected": str(selected or ""),
        "title": title,
        "x_title": "Observation date",
        "y_title": f"{spread_label} (source units)",
        "note": note,
        "empty": not traces,
    }


def comparison_spec(
    labels: list[str],
    increases: dict[str, list[float]],
    decreases: dict[str, list[float]],
    books: tuple[str, ...],
    dimension: str,
    total_movers: int,
    value_format: str = "count",
    title: str | None = None,
    x_title: str | None = None,
    metric_label: str = "mover",
) -> dict:
    """Diverging bars: decreases left, increases right, AIM above Index.

    One row per ``(bucket, book)``, two traces per book: the increase side is
    positive and the decrease side is negative, so both are measured from one
    shared zero line. ``limit`` is the largest absolute value and is published
    with the spec, so both renderers pin the axis to ``[-limit, +limit]`` and
    neither half can scale itself.

    ``value_format`` decides only how a bar is labelled and how many decimals
    are shown — ``count`` for mover counts, ``spread`` for a summed spread in
    source units. Nothing is recomputed here: the caller has already done the
    arithmetic and this function only arranges it.
    """
    rows = []
    for position, label in enumerate(labels):
        for book in books:
            up = increases.get(book) or []
            down = decreases.get(book) or []
            rows.append(
                {
                    "bucket": str(label),
                    "book": str(book),
                    "label": f"{label} \u00b7 {book}" if len(books) > 1 else str(label),
                    "increase": float(up[position]) if position < len(up) else 0.0,
                    "decrease": float(down[position]) if position < len(down) else 0.0,
                }
            )
    traces = []
    for book in books:
        # One book: the colour is the direction. Two books: the colour is still
        # the direction, and the book is told apart by its depth within that
        # hue, so an increase and a decrease never share a colour family.
        if len(books) == 1:
            pair = config.CHART_DIRECTION_COLORS
        else:
            pair = config.CHART_COMPARE_COLORS.get(
                str(book), config.CHART_DIRECTION_COLORS
            )
        for direction, colour, key, sign in (
            ("Increase", pair[0], "increase", 1),
            ("Decrease", pair[1], "decrease", -1),
        ):
            traces.append(
                {
                    "name": f"{book} {direction.lower()}s",
                    "book": str(book),
                    "direction": direction,
                    "color": colour,
                    "values": [
                        sign * abs(row[key]) if row["book"] == str(book) else None
                        for row in rows
                    ],
                }
            )
    counts = [
        abs(value)
        for trace in traces
        for value in trace["values"]
        if value is not None
    ]
    dimension_title = title or f"Movers by {dimension}"
    return {
        "kind": "comparison",
        "dimension": dimension,
        "labels": list(labels),
        "rows": rows,
        "row_labels": [row["label"] for row in rows],
        "traces": traces,
        "books": [str(book) for book in books],
        "limit": max(counts) if counts else 0.0,
        "total_movers": int(total_movers),
        "value_format": value_format,
        "metric_label": metric_label,
        "title": dimension_title,
        "x_title": x_title
        or (
            "Number of ranked movers " + config.DIVERGING_AXIS_HINT
            if value_format == "count"
            else "Summed spread change, source units " + config.DIVERGING_AXIS_HINT
        ),
        "empty": not rows,
    }


# ---------------------------------------------------------------------------
# Plotly renderer (BQuant Desktop)
# ---------------------------------------------------------------------------


def _apply_theme(figure) -> None:
    """Re-state the dark theme on a figure that is about to gain traces.

    The three charts that came back with a **white** background — both bucket
    charts and the path chart — share one structural property the two correct
    Top 10 charts do not: they are built empty (`FigureWidget(data=[])`) and
    receive their traces later through `add_traces()`. Plotly merges a default
    template into the layout when a figure first acquires traces, and on that
    path the template's own paper/plot colours — white — win over the
    transparent values `_base_layout()` set on the still-empty figure. The Top
    10 figures are constructed with their trace, so the template is applied
    before `_base_layout()` runs and the explicit colours survive.

    `template=None` removes the inherited default rather than copying it, and
    the four colour properties are then set again explicitly. This runs after
    the traces are in place, which is the only point where the merge can no
    longer overwrite them.

    Transparent, not black: the page behind these cards is the Bloomberg dark
    theme, and `rgba(0,0,0,0)` lets that show through. A literal `#000000`
    would draw a black rectangle over the theme and look almost right, which is
    worse than being wrong.
    """
    figure.update_layout(
        template=None,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=config.CHART_FONT_COLOR),
        title=dict(font=dict(color=config.CHART_FONT_COLOR)),
    )


def _base_layout(figure, spec: dict) -> None:
    """One layout, copied from FI Index Change.

    Fixed width and height (2,284 px parent; 1,292 px here, the width of the
    same five dimension boxes), transparent paper and plot background so the
    Bloomberg dark theme shows through, light title text, muted axis titles,
    dark grid lines, and a legend under the plot. Every chart on the screen
    shares one palette, and the right edge of the charts meets the right edge
    of the last selection box. The path chart is the one exception to the
    height: it takes ``_detail_layout`` on top of this, as the lower chart does
    in FI Index Change.
    """
    figure.update_layout(
        width=config.CHART_WIDTH_PX,
        autosize=False,
        height=config.CHART_HEIGHT_PX,
        margin=dict(
            l=config.CHART_MARGIN_LEFT_PX,
            r=config.CHART_MARGIN_RIGHT_PX,
            t=config.CHART_MARGIN_TOP_PX,
            b=config.CHART_MARGIN_BOTTOM_PX,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=config.CHART_FONT_COLOR),
        title=dict(text=spec.get("title", ""), font=dict(color=config.CHART_FONT_COLOR)),
        xaxis=dict(
            title=dict(
                text=spec.get("x_title", ""), font=dict(color=config.CHART_MUTED_COLOR)
            ),
            tickfont=dict(color=config.CHART_MUTED_COLOR),
            gridcolor=config.CHART_GRID_COLOR,
            zeroline=True,
            zerolinecolor=config.CHART_ZERO_COLOR,
        ),
        yaxis=dict(
            title=dict(
                text=spec.get("y_title", ""), font=dict(color=config.CHART_MUTED_COLOR)
            ),
            tickfont=dict(color=config.CHART_FONT_COLOR),
            gridcolor=config.CHART_GRID_COLOR,
        ),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.12,
            x=0,
            xanchor="left",
            font=dict(color=config.CHART_MUTED_COLOR),
            bgcolor="rgba(0,0,0,0)",
        ),
        bargap=0.25,
    )


def bucket_figure(spec: dict):
    """A grouped horizontal bar chart for the bucket counts."""
    import plotly.graph_objects as go

    figure = go.FigureWidget(
        data=[
            go.Bar(
                name="Increases",
                orientation="h",
                marker_color=config.CHART_INCREASE_COLOR,
                hovertemplate="%{y}<br>%{x} increase(s)<extra></extra>",
            ),
            go.Bar(
                name="Decreases",
                orientation="h",
                marker_color=config.CHART_DECREASE_COLOR,
                hovertemplate="%{y}<br>%{x} decrease(s)<extra></extra>",
            ),
        ]
    )
    _base_layout(figure, spec)
    figure.update_layout(barmode="group")
    figure.update_yaxes(autorange="reversed")
    apply_bucket(figure, spec)
    return figure


def apply_bucket(figure, spec: dict) -> None:
    """Update an existing bucket figure in place."""
    labels = list(spec.get("labels") or [])
    with figure.batch_update():
        figure.data[0].x = list(spec.get("increases") or [])
        figure.data[0].y = labels
        figure.data[1].x = list(spec.get("decreases") or [])
        figure.data[1].y = labels
        figure.layout.title.text = spec.get("title", "")
        figure.layout.xaxis.title.text = spec.get("x_title", "")
        figure.layout.yaxis.autorange = "reversed"


def change_figure(spec: dict):
    """Signed bars for one ranked side."""
    import plotly.graph_objects as go

    figure = go.FigureWidget(
        data=[go.Bar(orientation="h", hovertemplate="%{y}<br>%{text}<extra></extra>")]
    )
    _base_layout(figure, spec)
    figure.update_layout(showlegend=False)
    figure.update_yaxes(autorange="reversed")
    apply_change(figure, spec)
    return figure


def apply_change(figure, spec: dict) -> None:
    """Update an existing change figure in place."""
    rows = spec.get("rows") or []
    with figure.batch_update():
        figure.data[0].x = [row["value"] for row in rows]
        figure.data[0].y = [row["label"] for row in rows]
        figure.data[0].text = [row["text"] for row in rows]
        # The y label is the security NAME (book-prefixed in a comparison), so
        # the click payload has to carry the ID separately or click-to-inspect
        # would look up a name that is not an ID and find nothing.
        figure.data[0].customdata = [row["ID"] for row in rows]
        figure.data[0].marker.color = list(spec.get("colors") or [])
        figure.layout.title.text = spec.get("title", "")
        figure.layout.xaxis.title.text = spec.get("x_title", "")
        figure.layout.yaxis.title.text = spec.get("y_title", "")
        figure.layout.yaxis.autorange = "reversed"


def comparison_figure(spec: dict):
    """Diverging horizontal bars: decreases left, increases right, per book."""
    import plotly.graph_objects as go

    figure = go.FigureWidget(data=[])
    _base_layout(figure, spec)
    figure.update_layout(barmode="overlay", bargap=0.35)
    figure.update_yaxes(autorange="reversed")
    apply_comparison(figure, spec)
    return figure


def apply_comparison(figure, spec: dict) -> None:
    """Update an existing comparison figure in place.

    The trace count follows how many books returned data, so a one-book run
    draws two traces and a two-book run draws four. The x axis is pinned to one
    symmetric range, so the decrease half and the increase half cannot scale
    differently and the zero line stays centred.

    **Traces are updated in place, never reassigned.** The previous version did
    ``figure.data = series`` inside the batch. That is a valid way to build a
    figure and it renders in a notebook, but on Desktop the widget has already
    been placed inside an `ipywidgets` container by the time the first Update
    runs, and replacing the whole `data` tuple on a *displayed* `FigureWidget`
    leaves the front end drawing the figure it was given: the panel came back
    blank while the table underneath it — ordinary widget output — carried every
    number. The two Top 10 charts were unaffected because they assign
    `data[0].x`/`data[0].y`, which is the form `RAG KB/09` documents. Adding
    traces with `add_traces` and then mutating them keeps the figure object
    stable for the front end.
    """
    import plotly.graph_objects as go

    traces = spec.get("traces") or []
    labels = list(spec.get("row_labels") or spec.get("labels") or [])
    is_count = str(spec.get("value_format", "count")) == "count"
    # No floor of 1.0 here: a summed spread limit is a small number (a few
    # basis points), and flooring it would squash every bar into the middle.
    raw_limit = abs(float(spec.get("limit") or 0.0))
    limit = raw_limit if raw_limit > 0 else 1.0
    with figure.batch_update():
        existing = len(figure.data)
        if len(traces) > existing:
            figure.add_traces(
                [
                    go.Bar(orientation="h")
                    for _ in range(len(traces) - existing)
                ]
            )
        for position, trace in enumerate(traces):
            bar = figure.data[position]
            bar.name = str(trace.get("name", ""))
            bar.orientation = "h"
            bar.marker.color = trace.get("color", config.CHART_INCREASE_COLOR)
            bar.x = list(trace.get("values") or [])
            bar.y = labels
            bar.hovertemplate = (
                "%{y}<br>%{x:.0f} mover(s)<extra>"
                if is_count
                else "%{y}<br>%{x:+.4f} (source units)<extra>"
            ) + escape(str(trace.get("name", ""))) + "</extra>"
        # A book that returned nothing this run leaves its traces behind if they
        # are only overwritten, so the extra ones are emptied rather than kept:
        # a stale bar would draw yesterday's book under today's title.
        for position in range(len(traces), existing):
            bar = figure.data[position]
            bar.x = []
            bar.y = []
            bar.name = ""
        figure.layout.title.text = spec.get("title", "")
        figure.layout.xaxis.title.text = spec.get("x_title", "")
        figure.layout.xaxis.range = [-limit * 1.08, limit * 1.08]
        figure.layout.yaxis.autorange = "reversed"
    _apply_theme(figure)


def _detail_layout(figure) -> None:
    """The shorter card FI Index Change uses for its lower chart.

    The path chart is that same lower chart: 300 px tall with a tighter top and
    bottom margin, while the width, palette, and left margin stay the shared
    ones. Kept as an override instead of a second copy of ``_base_layout`` so
    there is still exactly one palette in the module.
    """
    figure.update_layout(
        height=config.CHART_DETAIL_HEIGHT_PX,
        margin=dict(
            l=config.CHART_MARGIN_LEFT_PX,
            r=config.CHART_MARGIN_RIGHT_PX,
            t=config.CHART_DETAIL_MARGIN_TOP_PX,
            b=config.CHART_DETAIL_MARGIN_BOTTOM_PX,
        ),
    )


def path_figure(spec: dict):
    """One line: the selected security's spread path, or its state message."""
    import plotly.graph_objects as go

    figure = go.FigureWidget(data=[])
    _base_layout(figure, spec)
    _detail_layout(figure)
    apply_paths(figure, spec)
    return figure


def apply_paths(figure, spec: dict) -> None:
    """Update the traces in place: the trace count changes with the selection.

    Same rule as `apply_comparison`, and it matters for the same reason: this
    figure is displayed inside an `ipywidgets` container before the first click
    exists, and assigning `figure.data = [...]` on a displayed `FigureWidget`
    left the lower chart card blank on Desktop while the daily table under it
    kept its rows. Traces are added once with `add_traces` and then mutated;
    unused ones are emptied rather than dropped, because the count is small (at
    most one path) and a stale line would draw the previously clicked bond
    underneath the new title.
    """
    import plotly.graph_objects as go

    traces = spec.get("traces") or []
    with figure.batch_update():
        existing = len(figure.data)
        if len(traces) > existing:
            figure.add_traces(
                [go.Scatter(mode="lines+markers") for _ in range(len(traces) - existing)]
            )
        for position, trace in enumerate(traces):
            line = figure.data[position]
            line.x = list(trace["dates"])
            line.y = list(trace["values"])
            line.mode = "lines+markers"
            line.name = str(trace["id"])
            line.hovertemplate = (
                "%{x}<br>" + str(trace["id"]) + ": %{y}<extra></extra>"
            )
        for position in range(len(traces), existing):
            line = figure.data[position]
            line.x = []
            line.y = []
            line.name = ""
        figure.layout.title.text = spec.get("title", "")
        figure.layout.xaxis.title.text = spec.get("x_title", "")
        figure.layout.yaxis.title.text = spec.get("y_title", "")
        # "Select a bond…" and "no series for this ID" are states, not empty
        # plots: without this line the operator sees axes and nothing else.
        note = str(spec.get("note", "") or "").strip()
        figure.layout.annotations = (
            [
                dict(
                    text=note,
                    x=0.5,
                    y=0.5,
                    xref="paper",
                    yref="paper",
                    showarrow=False,
                    font=dict(color=config.CHART_MUTED_COLOR, size=13),
                )
            ]
            if note and not traces
            else []
        )
    _apply_theme(figure)
