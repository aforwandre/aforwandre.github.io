"""BQL retrieval for Hang Seng members, HK indices, and US index futures.

Canonical fields: px_open / px_high / px_low / px_last / px_volume / name /
classification_name / id()['weights'] / members().
History uses cached mode to stay inside the Desktop 2-minute window.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from .config import (
    HISTORY_RANGE_END,
    HISTORY_RANGE_START,
    HSI_INDEX,
    MEMBER_OHLCV_BATCH,
    all_bench_tickers,
)

try:
    import bql
except ImportError:  # local Cursor dry-run
    bql = None


OHLCV_ITEM_NAMES = ('Open', 'High', 'Low', 'Close', 'Volume')
PARSER_VERSION = '2026-08-28c'

_COLUMN_ALIASES = {
    'OPEN': 'Open',
    'PX_OPEN()': 'Open',
    'PX_OPEN': 'Open',
    'HIGH': 'High',
    'PX_HIGH()': 'High',
    'PX_HIGH': 'High',
    'LOW': 'Low',
    'PX_LOW()': 'Low',
    'PX_LOW': 'Low',
    'CLOSE': 'Close',
    'PX_LAST()': 'Close',
    'PX_LAST': 'Close',
    'VOLUME': 'Volume',
    'PX_VOLUME()': 'Volume',
    'PX_VOLUME': 'Volume',
    'NAME': 'Name',
    'NAME()': 'Name',
    'NAMECN': 'NameCN',
    'OFFICIAL_TRAD_LOCAL_LANG_SEC_NM()': 'NameCN',
    'OFFICIAL_TRAD_LOCAL_LANG_SEC_NM': 'NameCN',
    'NAME_CHINESE_TRADITIONAL()': 'NameCN',
    'NAME_CHINESE_TRADITIONAL': 'NameCN',
    'SECTOR': 'Sector',
    'CLASSIFICATION_NAME()': 'Sector',
    'CLASSIFICATION_NAME': 'Sector',
    'WEIGHT': 'Weight',
    'WEIGHTS': 'Weight',
    'ID()': 'ID',
}


@dataclass
class ScanPayload:
    members: pd.DataFrame
    ohlcv: pd.DataFrame
    errors: list[str] = field(default_factory=list)


def _require_bql():
    if bql is None:
        raise RuntimeError('bql is not available. Run this app on Bloomberg BQuant Desktop.')
    return bql.Service()


def _pick_column(frame: pd.DataFrame, candidates: tuple[str, ...]):
    lookup = {str(col).upper(): col for col in frame.columns}
    for name in candidates:
        if name.upper() in lookup:
            return lookup[name.upper()]
    return None


def item_frames(response) -> list[pd.DataFrame]:
    frames = []
    for item in _response_items(response):
        raw = item.df().copy()
        value_name = item.name
        frame = raw.reset_index()
        if value_name not in frame.columns:
            leftover = [
                col for col in frame.columns
                if str(col).upper() not in {'ID', 'DATE', 'CURRENCY', 'ORIG_IDS'}
            ]
            if not leftover:
                continue
            frame = frame.rename(columns={leftover[0]: value_name})
        keep = []
        id_col = _pick_column(frame, ('ID',))
        date_col = _pick_column(frame, ('DATE',))
        if date_col is None:
            for col in frame.columns:
                if col == value_name:
                    continue
                if pd.api.types.is_datetime64_any_dtype(frame[col]):
                    date_col = col
                    break
        if id_col is None:
            for col in frame.columns:
                if col in {value_name, date_col}:
                    continue
                sample = frame[col].astype(str)
                if sample.str.contains(r'Equity|Index|Corp', na=False).mean() > 0.2:
                    id_col = col
                    break
        if id_col is None:
            for col in frame.columns:
                if col not in {value_name, date_col}:
                    id_col = col
                    break
        if id_col is not None:
            keep.append(id_col)
        if date_col is not None:
            keep.append(date_col)
        keep.append(value_name)
        piece = frame.loc[:, keep].copy()
        rename = {}
        if id_col is not None and id_col != 'ID':
            rename[id_col] = 'ID'
        if date_col is not None and date_col != 'DATE':
            rename[date_col] = 'DATE'
        piece = piece.rename(columns=rename)
        if 'DATE' in piece.columns:
            piece['DATE'] = pd.to_datetime(piece['DATE'], errors='coerce')
        frames.append(piece)
    return frames


def merge_item_frames(frames: list[pd.DataFrame]) -> pd.DataFrame:
    if not frames:
        return pd.DataFrame()
    has_date = all('DATE' in frame.columns for frame in frames)
    keys = ['ID', 'DATE'] if has_date else ['ID']
    merged = frames[0]
    for extra in frames[1:]:
        overlap = [col for col in extra.columns if col not in keys]
        merged = merged.merge(extra[keys + overlap], on=keys, how='outer')
    if 'ID' in merged.columns:
        merged['ID'] = merged['ID'].astype(str)
    return merged


def _on_request_error(error_tuple):
    return error_tuple


def _brief(obj) -> str:
    return type(obj).__name__


def _is_response(obj) -> bool:
    if obj is None or isinstance(obj, (tuple, str, bytes, pd.DataFrame, Exception)):
        return False
    type_name = type(obj).__name__.lower()
    if 'response' in type_name:
        return True
    return any(hasattr(obj, name) for name in ('get', 'single', '__getitem__', 'df'))


def _item_df(item, preferred_name: str | None = None) -> pd.DataFrame:
    frame = _alias_columns(item.df().copy().reset_index())
    name = preferred_name or getattr(item, 'name', None)
    keep = [c for c in ('ID', 'DATE', name, preferred_name) if c and c in frame.columns]
    piece = frame.loc[:, list(dict.fromkeys(keep))].copy() if keep else frame
    if preferred_name and name in piece.columns and preferred_name != name:
        piece = piece.rename(columns={name: preferred_name})
    if 'DATE' in piece.columns:
        piece['DATE'] = pd.to_datetime(piece['DATE'], errors='coerce')
    return piece


def _lookup_item(response, name: str):
    keys = (name, name.upper(), name.lower(), f'{name}()')
    if hasattr(response, 'get'):
        for key in keys:
            try:
                item = response.get(key)
            except Exception:
                item = None
            if item is not None and hasattr(item, 'df'):
                return item
    for key in keys:
        try:
            item = response[key]
        except Exception:
            item = None
        if item is not None and hasattr(item, 'df'):
            return item
    return None


def _response_items(response) -> list:
    """07: sequence of SingleItemResponse; Arrow may lack __iter__."""
    try:
        count = len(response)
    except Exception:
        count = None
    if count is not None and 0 < count <= 32:
        try:
            indexed = [response[i] for i in range(count)]
            if indexed and hasattr(indexed[0], 'df'):
                return indexed
        except Exception:
            pass
    try:
        items = list(response)
        if items and hasattr(items[0], 'df'):
            return items
    except TypeError:
        pass
    if hasattr(response, 'single'):
        try:
            found = [response.single()]
            if found and hasattr(found[0], 'df'):
                return found
        except Exception:
            pass
    return []


def _alias_columns(frame: pd.DataFrame) -> pd.DataFrame:
    rename = {}
    for col in frame.columns:
        key = str(col).strip().upper()
        if key in _COLUMN_ALIASES:
            rename[col] = _COLUMN_ALIASES[key]
    if rename:
        frame = frame.rename(columns=rename)
    return frame.loc[:, ~frame.columns.duplicated()]


def _normalize_id_date(frame: pd.DataFrame) -> pd.DataFrame:
    if frame is None or frame.empty:
        return pd.DataFrame()
    out = frame.copy()
    if out.index.name or getattr(out.index, 'nlevels', 1) > 1:
        out = out.reset_index()
    out = _alias_columns(out)
    id_col = _pick_column(out, ('ID',))
    date_col = _pick_column(out, ('DATE',))
    if date_col is None:
        for col in out.columns:
            if pd.api.types.is_datetime64_any_dtype(out[col]):
                date_col = col
                break
    rename = {}
    if id_col is not None and id_col != 'ID':
        rename[id_col] = 'ID'
    if date_col is not None and date_col != 'DATE':
        rename[date_col] = 'DATE'
    out = out.rename(columns=rename)
    if 'ID' in out.columns:
        out['ID'] = out['ID'].astype(str)
    if 'DATE' in out.columns:
        out['DATE'] = pd.to_datetime(out['DATE'], errors='coerce')
    return out


def _concat_item_frames(parts: list[pd.DataFrame]) -> pd.DataFrame:
    if not parts:
        return pd.DataFrame()
    if all('ID' in p.columns for p in parts):
        return merge_item_frames(parts)
    result = pd.concat(parts, axis=1)
    result = result.loc[:, ~result.columns.duplicated()]
    return _normalize_id_date(result)


def _response_to_frame(response, item_names: tuple[str, ...] | None = None) -> pd.DataFrame:
    names = tuple(item_names or ())
    named_parts = []
    for name in names:
        item = _lookup_item(response, name)
        if item is None:
            continue
        named_parts.append(_item_df(item, preferred_name=name))
    if named_parts:
        return _concat_item_frames(named_parts)

    items = _response_items(response)
    if items:
        parts = [_item_df(item) for item in items]
        return _concat_item_frames(parts)

    if bql is not None:
        try:
            combined = bql.combined_df(response)
            parsed = _normalize_id_date(combined)
            if parsed is not None and not parsed.empty:
                return parsed
        except Exception:
            pass

    frames = item_frames(response)
    return merge_item_frames(frames)


def _parse_response(
    response,
    label: str,
    errors: list[str],
    item_names: tuple[str, ...] | None = None,
) -> pd.DataFrame:
    if not _is_response(response):
        errors.append(f'{label}: not a BQL response ({_brief(response)})')
        return pd.DataFrame()
    try:
        frame = _response_to_frame(response, item_names=item_names)
    except Exception as exc:
        errors.append(f'{label}: {type(exc).__name__}: {exc}')
        return pd.DataFrame()
    if frame is None or frame.empty:
        errors.append(f'{label}: parsed empty from {_brief(response)}')
        return pd.DataFrame()
    return frame


def _chunks(values: list[str], size: int):
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _normalize_weights(meta: pd.DataFrame) -> pd.DataFrame:
    if meta.empty or 'Weight' not in meta.columns:
        return meta
    weight = pd.to_numeric(meta['Weight'], errors='coerce')
    if weight.abs().sum() <= 2.5:
        meta['Weight'] = weight * 100.0
    else:
        meta['Weight'] = weight
    return meta


def fetch_scan_payload(progress=None) -> ScanPayload:
    """Pull live HSI membership + daily OHLCV for members and benchmarks."""
    bq = _require_bql()
    errors: list[str] = []

    def note(message: str) -> None:
        if progress is not None:
            progress(message)

    date_range = bq.func.range(HISTORY_RANGE_START, HISTORY_RANGE_END)
    ohlcv_items = {
        'Open': bq.data.px_open(dates=date_range),
        'High': bq.data.px_high(dates=date_range),
        'Low': bq.data.px_low(dates=date_range),
        'Close': bq.data.px_last(dates=date_range),
        'Volume': bq.data.px_volume(dates=date_range),
    }

    note(f'parser {PARSER_VERSION}: resolving live {HSI_INDEX} members...')
    meta_request = bql.Request(
        bq.univ.members(HSI_INDEX),
        {
            'Name': bq.data.name(),
            'Sector': bq.data.classification_name(),
            'Weight': bq.data.id()['weights'],
        },
        with_params={'mode': 'cached'},
    )
    meta = _parse_response(
        bq.execute(meta_request),
        'members',
        errors,
        item_names=('Name', 'Sector', 'Weight'),
    )
    if not meta.empty:
        meta['ID'] = meta['ID'].astype(str)
        meta = _normalize_weights(meta)
        cn = _parse_response(
            bq.execute(bql.Request(
                bq.univ.members(HSI_INDEX),
                {'NameCN': bq.data.official_trad_local_lang_sec_nm()},
                with_params={'mode': 'cached'},
            )),
            'members_cn',
            errors,
            item_names=('NameCN',),
        )
        if not cn.empty and 'NameCN' in cn.columns:
            cn['ID'] = cn['ID'].astype(str)
            meta = meta.merge(cn[['ID', 'NameCN']].drop_duplicates('ID'), on='ID', how='left')

    member_ids = [] if meta.empty else meta['ID'].drop_duplicates().tolist()
    note(f'HSI members: {len(member_ids)}. Pulling daily OHLCV...')

    labeled_requests = []
    for i, batch in enumerate(_chunks(member_ids, MEMBER_OHLCV_BATCH), start=1):
        labeled_requests.append((
            f'member_ohlcv_{i}',
            bql.Request(batch, ohlcv_items, with_params={'mode': 'cached'}),
        ))
    for ticker in all_bench_tickers():
        labeled_requests.append((
            f'bench::{ticker}',
            bql.Request(ticker, ohlcv_items),
        ))

    ohlcv_parts = []
    if labeled_requests:
        responses = list(
            bq.execute_many(
                [request for _, request in labeled_requests],
                on_request_error=_on_request_error,
                num_retries=1,
            )
        )
        for (label, _request), response in zip(labeled_requests, responses):
            frame = _parse_response(
                response,
                label,
                errors,
                item_names=OHLCV_ITEM_NAMES,
            )
            if frame.empty:
                continue
            frame = frame.copy()
            frame['Bucket'] = 'HSI' if label.startswith('member_ohlcv') else 'BENCH'
            ohlcv_parts.append(frame)

    ohlcv = pd.concat(ohlcv_parts, ignore_index=True, sort=False) if ohlcv_parts else pd.DataFrame()
    if not ohlcv.empty:
        for col in OHLCV_ITEM_NAMES:
            if col in ohlcv.columns:
                ohlcv[col] = pd.to_numeric(ohlcv[col], errors='coerce')
        keys = [c for c in ('ID', 'DATE') if c in ohlcv.columns]
        if 'DATE' not in keys:
            errors.append(f'ohlcv missing DATE; columns={list(ohlcv.columns)}')
        ohlcv = ohlcv.dropna(subset=[c for c in keys + ['Close'] if c in ohlcv.columns])
        ohlcv = ohlcv.drop_duplicates(subset=keys, keep='last') if keys else ohlcv
        ohlcv = ohlcv.sort_values(keys) if keys else ohlcv

    note(
        f'Members={len(member_ids)}  bars={0 if ohlcv.empty else len(ohlcv)}'
        + (f'  notes={len(errors)}' if errors else '')
    )
    return ScanPayload(members=meta, ohlcv=ohlcv, errors=errors)
