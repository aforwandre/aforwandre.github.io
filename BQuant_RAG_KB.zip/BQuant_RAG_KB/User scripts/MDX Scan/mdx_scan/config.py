"""MDX Scan configuration. Security IDs are yellow-key defaults; edit if a ticker fails."""

from dataclasses import dataclass


# Hang Seng Index — membership is always taken live via bq.univ.members().
HSI_INDEX = 'HSI Index'

# Hang Seng family cash indices. HSI / HSCEI are official-script yellow keys.
# HSTECH Index is the Hang Seng TECH cash index; change here if Terminal uses another ID.
HK_INDICES = (
    ('HSI Index', 'Hang Seng'),
    ('HSCEI Index', 'HSCEI'),
    ('HSTECH Index', 'HSTECH'),
)

# US equity-index futures (user-confirmed yellow keys).
US_FUTURES = (
    ('ESA Index', 'S&P 500'),
    ('NQA Index', 'Nasdaq 100'),
    ('DMA Index', 'DJI'),
)

# Daily lookback for EMA60 / HHV60 / buy-history(40) warmup.
HISTORY_RANGE_START = '-6m'
HISTORY_RANGE_END = '0d'
MEMBER_OHLCV_BATCH = 40

COOLDOWN_BARS = 8
BUY_LOOKBACK = 40

# Signal rank used for default sort (higher first).
SIGNAL_RANK = {
    'BUY': 60,
    'SELL': 50,
    'WASH': 40,
    'DUMP': 30,
    'REVU': 20,
    'REVD': 10,
    'CONT': 4,
    'SQZ': 3,
    '': 0,
}

SIGNAL_COLORS = {
    'BUY': '#3dd68c',
    'SELL': '#ff6b6b',
    'WASH': '#e6c07b',
    'DUMP': '#61afef',
    'REVU': '#7aa2f7',
    'REVD': '#e6c07b',
    'CONT': '#3dd68c',
    'SQZ': '#c5c8d0',
    '': '#8b93a7',
}

# Later flags overwrite earlier ones; BUY wins last. Shown under the member grid.
SIGNAL_LEGEND = (
    ('BUY', 'Deep-reclaim buy: PCTB < 0.18, 18% off the 60-day high, bounce, reclaim, close at or above the open'),
    ('SELL', 'Vote-cross sell: VS crosses N5 after a buy in the last 40 bars'),
    ('WASH', 'Washout: new low and down day, then close back above the prior low'),
    ('DUMP', 'Dump or grind: high-volume reversal after a quiet rally'),
    ('REVU', '%B crosses down through 0.12 with RSI < 28'),
    ('REVD', '%B crosses up through 0.88 with RSI > 72'),
    ('CONT', 'Continuation: above EMA60, mid %B, MACD histogram turns up'),
    ('SQZ', 'Squeeze: Bollinger band inside the Keltner channel'),
    ('(blank)', 'No MDX flag on the latest bar'),
)

METRIC_LEGEND = (
    ('PCTB', 'Position in the MDX band: 0 at lower (DN), 1 at upper (UP)'),
    ('VS', 'Sell-vote score; SELL fires when VS crosses up through N5'),
    ('DD60', 'Drawdown from the 60-session high (Close / 60-day HHV - 1)'),
)


@dataclass(frozen=True)
class MDXParams:
    n1: int = 20
    n2: int = 14
    n3: float = 1.8
    n4: int = 4
    n5: int = 5
    cooldown: int = COOLDOWN_BARS
    buy_lookback: int = BUY_LOOKBACK


@dataclass
class BenchSpec:
    ticker: str
    label: str
    group: str


def bench_universe() -> list[BenchSpec]:
    rows = [BenchSpec(ticker, label, 'HK') for ticker, label in HK_INDICES]
    rows.extend(BenchSpec(ticker, label, 'US') for ticker, label in US_FUTURES)
    return rows


def all_bench_tickers() -> list[str]:
    return [row.ticker for row in bench_universe()]
