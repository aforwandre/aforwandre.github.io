"""MDX Scan BQuant app — Hang Seng members + HK/US benchmarks."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from functools import partial

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import ipywidgets as widgets
from IPython.display import clear_output
from ipydatagrid import DataGrid, TextRenderer

from .config import (
    HK_INDICES,
    SIGNAL_COLORS,
    SIGNAL_LEGEND,
    US_FUTURES,
    MDXParams,
    bench_universe,
)
from .data import fetch_scan_payload
from .mdx_engine import FORMULA_VERSION, compute_universe, latest_snapshot


def _short_id(ticker: str) -> str:
    return str(ticker).replace(" Equity", "").replace(" Index", "").strip()


def _now_hkt() -> datetime:
    try:
        from zoneinfo import ZoneInfo

        return datetime.now(ZoneInfo("Asia/Hong_Kong"))
    except Exception:
        return datetime.now(timezone(timedelta(hours=8)))


def _fmt_px(value) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "—"
    number = float(value)
    abs_number = abs(number)
    if abs_number >= 1000:
        return f"{number:,.2f}"
    if abs_number >= 10:
        return f"{number:,.3f}"
    return f"{number:,.4f}"


def _fmt_pct(value) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "—"
    return f"{float(value) * 100:+.2f}%"


def _fmt_pts(last, chg) -> str:
    if last is None or chg is None:
        return "—"
    try:
        last_f = float(last)
        chg_f = float(chg)
    except (TypeError, ValueError):
        return "—"
    if np.isnan(last_f) or np.isnan(chg_f) or chg_f <= -1.0:
        return "—"
    pts = last_f - last_f / (1.0 + chg_f)
    return f"{pts:+,.2f}"


def _fmt_date(value) -> str:
    if value is None or pd.isna(value):
        return ""
    stamp = pd.to_datetime(value)
    return stamp.strftime("%Y-%m-%d")


def _chg_color(value) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "#8b93a7"
    if value > 0:
        return "#3dd68c"
    if value < 0:
        return "#ff6b6b"
    return "#8b93a7"


class MDXScanApp:
    def __init__(self):
        self._events_bound = False
        self._loading = False
        self._fixing_dropdown = False
        self._ohlcv = pd.DataFrame()
        self._members = pd.DataFrame()
        self._bars = pd.DataFrame()
        self._snapshot = pd.DataFrame()
        self._errors = []
        self._prev_member_count = None
        self._build_widgets()
        self._bind_events()

    def _params(self) -> MDXParams:
        return MDXParams(
            n1=int(self.n1.value),
            n2=int(self.n2.value),
            n3=float(self.n3.value),
            n5=int(self.n5.value),
        )

    def _build_widgets(self):
        self.title = widgets.HTML(
            value=self._header_html(
                "Ready", extra="Click Refresh to load live HSI members."
            )
        )
        self.status = widgets.HTML(value="")
        self.refresh_button = widgets.Button(
            description="Refresh",
            icon="refresh",
            button_style="primary",
            layout=widgets.Layout(width="120px", height="36px"),
        )
        self.auto_play = widgets.Play(
            value=0,
            min=0,
            max=10000,
            step=1,
            interval=60000,
            repeat=True,
            layout=widgets.Layout(width="180px", height="36px"),
        )
        self.interval = widgets.Dropdown(
            options=[
                ("30s", 30000),
                ("60s", 60000),
                ("2 min", 120000),
                ("3 min", 180000),
                ("5 min", 300000),
                ("15 min", 900000),
            ],
            value=60000,
            description="Every",
            layout=widgets.Layout(width="160px"),
            style={"description_width": "40px"},
        )
        self.filter_dd = widgets.Dropdown(
            options=[
                "All",
                "Actionable",
                "BUY",
                "SELL",
                "WASH",
                "DUMP",
                "REVU",
                "REVD",
            ],
            value="All",
            description="Show",
            layout=widgets.Layout(width="170px"),
            style={"description_width": "40px"},
        )
        self.search = widgets.Text(
            placeholder="Name or ticker",
            description="Find",
            layout=widgets.Layout(width="220px"),
            style={"description_width": "40px"},
        )
        self.n1 = widgets.IntSlider(
            value=20, min=5, max=60, description="N1", continuous_update=False
        )
        self.n2 = widgets.IntSlider(
            value=14, min=5, max=30, description="N2", continuous_update=False
        )
        self.n3 = widgets.FloatSlider(
            value=1.8,
            min=1.0,
            max=3.0,
            step=0.1,
            description="N3",
            continuous_update=False,
        )
        self.n5 = widgets.IntSlider(
            value=5, min=2, max=8, description="N5", continuous_update=False
        )
        self.params_box = widgets.Accordion(
            children=[widgets.HBox([self.n1, self.n2, self.n3, self.n5])],
            selected_index=None,
            titles=("MDX parameters (v4e daily)",),
        )

        self.cards = widgets.HTML(value="")
        self.breadth = widgets.HTML(value="")
        self.chip_box = widgets.Box(
            children=[],
            layout=widgets.Layout(display="flex", flex_flow="row wrap", width="100%"),
        )
        self.grid_box = widgets.VBox(
            [
                widgets.HTML(
                    '<div style="color:#8b93a7;padding:12px;">No data yet.</div>'
                )
            ]
        )
        self.column_legend = widgets.HTML(
            value=self._column_legend_html(),
            layout=widgets.Layout(width="42%", overflow="visible"),
        )
        self.legend = widgets.HTML(
            value=self._signal_legend_html(),
            layout=widgets.Layout(width="58%", overflow="visible"),
        )
        self.legend_row = widgets.HBox(
            [self.legend, self.column_legend],
            layout=widgets.Layout(width="100%", align_items="flex-start"),
        )
        self.ticker_dd = widgets.Dropdown(
            options=[],
            description="Chart",
            layout=widgets.Layout(width="100%"),
            style={"description_width": "48px"},
        )
        self.figure = self._empty_figure()
        self.log = widgets.Output(
            layout=widgets.Layout(max_height="90px", overflow="auto")
        )
        self.chart_box = widgets.VBox(
            [self.ticker_dd, self.figure],
            layout=widgets.Layout(width="42%", min_width="420px"),
        )
        self.grid_wrap = widgets.VBox(
            [self.grid_box],
            layout=widgets.Layout(width="58%", min_width="520px", overflow="visible"),
        )
        self.body = widgets.HBox(
            [self.grid_wrap, self.chart_box],
            layout=widgets.Layout(
                width="100%", align_items="flex-start", overflow="visible"
            ),
        )
        self.footer = widgets.HTML(
            value=(
                '<div style="color:#6b7385;font-size:11px;padding:8px 2px 0;">'
                "Daily MDX v4e from the Futu formula (EMA channel + deep-reclaim buy / vote-cross sell). "
                "A down bar (close below the open) does not buy. "
                "HSI membership is always the live <code>members(HSI Index)</code> list. "
                "This app scans daily bars only. 5-minute and 1-minute scans are not included. "
                "Refresh re-pulls BQL. Auto: pick an interval (incl. 15 min), press Play, leave Loop on. "
                "After replacing .py files, restart the kernel then Run All. Not investment advice."
                "</div>"
            )
        )
        controls = widgets.HBox(
            [
                self.refresh_button,
                widgets.HTML(
                    '<span style="color:#8b93a7;padding:6px 8px 0 10px;">Auto</span>'
                ),
                self.auto_play,
                self.interval,
                self.filter_dd,
                self.search,
            ],
            layout=widgets.Layout(flex_flow="row wrap", align_items="center"),
        )
        self.container = widgets.VBox(
            [
                self.title,
                controls,
                self.params_box,
                self.cards,
                self.breadth,
                self.chip_box,
                self.body,
                self.legend_row,
                self.log,
                self.footer,
            ],
            layout=widgets.Layout(width="100%", padding="6px 8px 12px"),
        )

    def _empty_figure(self) -> go.FigureWidget:
        fig = go.FigureWidget()
        fig.add_candlestick(
            name="OHLC",
            x=[],
            open=[],
            high=[],
            low=[],
            close=[],
            increasing_line_color="#3dd68c",
            decreasing_line_color="#ff6b6b",
        )
        fig.add_scatter(
            name="MID", x=[], y=[], mode="lines", line=dict(color="#e8eaed", width=2)
        )
        fig.add_scatter(
            name="UP", x=[], y=[], mode="lines", line=dict(color="#ff6b6b", width=1)
        )
        fig.add_scatter(
            name="DN", x=[], y=[], mode="lines", line=dict(color="#3dd68c", width=1)
        )
        fig.add_scatter(
            name="BUY",
            x=[],
            y=[],
            mode="markers",
            marker=dict(symbol="triangle-up", size=12, color="#3dd68c"),
        )
        fig.add_scatter(
            name="SELL",
            x=[],
            y=[],
            mode="markers",
            marker=dict(symbol="triangle-down", size=12, color="#ff6b6b"),
        )
        fig.add_scatter(
            name="WASH",
            x=[],
            y=[],
            mode="markers",
            marker=dict(symbol="diamond", size=9, color="#e6c07b"),
        )
        fig.add_scatter(
            name="DUMP",
            x=[],
            y=[],
            mode="markers",
            marker=dict(symbol="diamond", size=9, color="#61afef"),
        )
        fig.add_scatter(
            name="REVU",
            x=[],
            y=[],
            mode="markers",
            marker=dict(symbol="circle", size=8, color="#7aa2f7"),
        )
        fig.add_scatter(
            name="REVD",
            x=[],
            y=[],
            mode="markers",
            marker=dict(symbol="circle", size=8, color="#e6c07b"),
        )
        fig.update_layout(
            template="plotly_dark",
            height=500,
            margin=dict(l=44, r=12, t=44, b=36),
            paper_bgcolor="#121722",
            plot_bgcolor="#121722",
            xaxis=dict(rangeslider=dict(visible=False), gridcolor="#2a3142"),
            yaxis=dict(gridcolor="#2a3142"),
            legend=dict(orientation="h", y=1.08, font=dict(size=11)),
            hovermode="x unified",
            title=dict(text="Select a name", font=dict(size=14)),
        )
        return fig

    def _bind_events(self):
        if self._events_bound:
            return
        self.refresh_button.on_click(self._on_refresh)
        self.auto_play.observe(self._on_auto_tick, names="value")
        self.interval.observe(self._on_interval, names="value")
        self.filter_dd.observe(self._on_local_filter, names="value")
        self.search.observe(self._on_local_filter, names="value")
        self.ticker_dd.observe(self._on_ticker, names="value")
        for slider in (self.n1, self.n2, self.n3, self.n5):
            slider.observe(self._on_params, names="value")
        self._events_bound = True

    def render(self):
        return self.container

    def load_on_start(self):
        self._refresh()

    def _on_refresh(self, _button=None):
        self._refresh()

    def _on_auto_tick(self, change):
        if self._loading:
            return
        if change.get("old") is None:
            return
        if change.get("new") in (None, 0):
            return
        self._refresh()

    def _on_interval(self, change):
        self.auto_play.interval = int(change["new"])

    def _on_params(self, _change):
        if self._ohlcv is None or self._ohlcv.empty:
            return
        self._recompute_and_draw(refetch=False)

    def _on_local_filter(self, _change):
        self._render_tables()

    def _on_ticker(self, change):
        if self._fixing_dropdown:
            return
        self._draw_chart(change["new"])

    def _on_chip(self, ticker, _button=None):
        self._select_ticker(ticker)

    def _progress(self, message: str):
        self.status.value = f'<div style="color:#8b93a7;font-size:12px;padding:4px 2px;">{message}</div>'

    def _refresh(self):
        if self._loading:
            return
        self._loading = True
        self.refresh_button.disabled = True
        self._progress("Loading BQL…")
        with self.log:
            clear_output(wait=True)
            from .data import PARSER_VERSION

            print(
                _now_hkt().strftime("%H:%M:%S HKT"),
                "Refreshing…",
                "parser",
                PARSER_VERSION,
                "formula",
                FORMULA_VERSION,
            )
        try:
            payload = fetch_scan_payload(progress=self._progress)
            self._ohlcv = payload.ohlcv
            self._members = payload.members
            self._errors = payload.errors
            self._recompute_and_draw(refetch=True)
            if self._errors:
                with self.log:
                    for err in self._errors:
                        print("Request note:", err)
        except Exception as exc:
            self._progress(f"Error: {exc}")
            with self.log:
                print(exc)
            self.title.value = self._header_html("Error", extra=str(exc))
        finally:
            self._loading = False
            self.refresh_button.disabled = False

    def _recompute_and_draw(self, refetch: bool = False):
        if self._ohlcv is None or self._ohlcv.empty:
            self._progress("No OHLCV returned. Check yellow keys / entitlement.")
            return
        self._bars = compute_universe(self._ohlcv, self._params())
        snapshot = latest_snapshot(self._bars)
        snapshot = self._attach_meta(snapshot)
        self._snapshot = snapshot
        member_count = (
            int((snapshot["Group"] == "HSI").sum())
            if "Group" in snapshot.columns
            else 0
        )
        delta = ""
        if refetch and self._prev_member_count not in (None, member_count):
            delta = f"  ({member_count - self._prev_member_count:+d} vs last refresh)"
        if refetch:
            self._prev_member_count = member_count
        as_of = ""
        if "DATE" in snapshot.columns and not snapshot["DATE"].isna().all():
            as_of = pd.to_datetime(snapshot["DATE"].max()).strftime("%Y-%m-%d")
        extra = f'{member_count} HSI members{delta}  ·  bars through {as_of}  ·  {_now_hkt().strftime("%Y-%m-%d %H:%M:%S HKT")}'
        if self._errors:
            extra += f"  ·  {len(self._errors)} request note(s) in the log"
        self.title.value = self._header_html("Live", extra=extra)
        self._progress(extra)
        self._render_tables()
        options = self._ticker_options(snapshot)
        current = self.ticker_dd.value
        option_values = [value for _, value in options]
        preferred = [ticker for ticker, _label in HK_INDICES]
        self._fixing_dropdown = True
        try:
            self.ticker_dd.options = options
            if current in option_values:
                self.ticker_dd.value = current
            else:
                chosen = next(
                    (tick for tick in preferred if tick in option_values), None
                )
                self.ticker_dd.value = chosen or (options[0][1] if options else None)
        finally:
            self._fixing_dropdown = False
        self._draw_chart(self.ticker_dd.value)

    def _attach_meta(self, snapshot: pd.DataFrame) -> pd.DataFrame:
        frame = snapshot.copy()
        labels = {ticker: label for ticker, label in HK_INDICES + US_FUTURES}
        hk_ids = {ticker for ticker, _ in HK_INDICES}
        us_ids = {ticker for ticker, _ in US_FUTURES}
        meta = self._members.copy() if self._members is not None else pd.DataFrame()
        if not meta.empty:
            keep = [
                col
                for col in ("ID", "Name", "NameCN", "Sector", "Weight")
                if col in meta.columns
            ]
            meta = meta[keep].drop_duplicates("ID")
            frame = frame.merge(meta, on="ID", how="left", suffixes=("", "_meta"))
            if "Name_meta" in frame.columns:
                frame["Name"] = frame["Name"].fillna(frame["Name_meta"])
                frame = frame.drop(columns=["Name_meta"])
        if "Name" not in frame.columns:
            frame["Name"] = np.nan
        if "NameCN" not in frame.columns:
            frame["NameCN"] = np.nan
        if "Weight" not in frame.columns:
            frame["Weight"] = np.nan
        if "Sector" not in frame.columns:
            frame["Sector"] = np.nan
        frame["Name"] = (
            frame["Name"].fillna(frame["ID"].map(labels)).fillna(frame["ID"])
        )
        frame["NameCN"] = frame["NameCN"].fillna("")
        member_ids = set()
        if not meta.empty:
            member_ids = set(meta["ID"].astype(str))

        def group_of(ticker: str) -> str:
            if ticker in hk_ids:
                return "HK"
            if ticker in us_ids:
                return "US"
            return "HSI"

        frame["Group"] = frame["ID"].map(group_of)
        if member_ids:
            frame.loc[frame["ID"].isin(member_ids), "Group"] = "HSI"
        return frame

    def _ticker_options(self, snapshot: pd.DataFrame) -> list[tuple[str, str]]:
        rows = snapshot.sort_values(
            ["Rank", "Weight", "Name"],
            ascending=[False, False, True],
            na_position="last",
        )
        options = []
        for _, row in rows.iterrows():
            label = f"{_short_id(row['ID'])}  {row.get('Name', '')}"
            options.append((label, row["ID"]))
        return options

    def _filtered_members(self) -> pd.DataFrame:
        frame = self._snapshot
        if frame is None or frame.empty:
            return pd.DataFrame()
        members = frame.loc[frame["Group"] == "HSI"].copy()
        show = self.filter_dd.value
        if show == "Actionable":
            members = members.loc[
                members["Signal"].isin(["BUY", "SELL", "WASH", "DUMP", "REVU", "REVD"])
            ]
        elif show in {"BUY", "SELL", "WASH", "DUMP", "REVU", "REVD"}:
            members = members.loc[members["Signal"] == show]
        query = (self.search.value or "").strip().lower()
        if query:
            mask = (
                members["ID"].astype(str).str.lower().str.contains(query, na=False)
                | members["Name"].astype(str).str.lower().str.contains(query, na=False)
                | members["NameCN"]
                .astype(str)
                .str.lower()
                .str.contains(query, na=False)
            )
            members = members.loc[mask]
        return members.sort_values(
            ["Rank", "Weight"], ascending=[False, False], na_position="last"
        )

    def _render_tables(self):
        snap = self._snapshot
        self.cards.value = self._cards_html(snap)
        members = snap.loc[snap["Group"] == "HSI"] if not snap.empty else pd.DataFrame()
        self.breadth.value = self._breadth_html(members)
        self.chip_box.children = tuple(self._chip_buttons(members))
        grid_df = self._grid_frame(self._filtered_members())
        if grid_df.empty:
            self.grid_box.children = [
                widgets.HTML(
                    '<div style="color:#8b93a7;padding:16px;">No names match this filter.</div>'
                )
            ]
            return
        grid = DataGrid(
            grid_df,
            base_row_size=26,
            base_column_size=84,
            base_row_header_size=92,
            header_renderer=TextRenderer(
                background_color="#1c2433", text_color="#d5d9e2"
            ),
            default_renderer=TextRenderer(text_color="#dce1ea"),
            renderers={
                "Name": TextRenderer(text_color="#dce1ea"),
                "CN": TextRenderer(text_color="#dce1ea"),
                "Signal": TextRenderer(font="bold 12px sans-serif"),
                "Chg": TextRenderer(format=".2%"),
                "Last": TextRenderer(format=",.3f"),
                "Weight": TextRenderer(format=".2f"),
                "PCTB": TextRenderer(format=".2f"),
                "VS": TextRenderer(format=".0f"),
                "DD60": TextRenderer(format=".1%"),
            },
            column_widths={
                "Name": 140,
                "CN": 88,
                "Signal": 64,
                "Chg": 72,
                "Last": 84,
                "Weight": 70,
                "Sector": 140,
                "PCTB": 64,
                "VS": 48,
                "DD60": 72,
                "LastBuy": 96,
            },
            layout={"width": "100%", "height": "532px"},
        )
        grid.on_cell_click(partial(self._on_grid_click, grid_df))
        self.grid_box.children = [grid]

    def _grid_frame(self, members: pd.DataFrame) -> pd.DataFrame:
        if members.empty:
            return pd.DataFrame()
        out = pd.DataFrame(
            {
                "Name": members["Name"].values,
                "CN": (
                    members["NameCN"].fillna("").values
                    if "NameCN" in members.columns
                    else ""
                ),
                "Signal": members["Signal"].values,
                "Chg": pd.to_numeric(members["Chg"], errors="coerce").values,
                "Last": pd.to_numeric(members["Close"], errors="coerce").values,
                "Weight": (
                    pd.to_numeric(members["Weight"], errors="coerce").values
                    if "Weight" in members.columns
                    else np.nan
                ),
                "PCTB": pd.to_numeric(members["PCTB"], errors="coerce").values,
                "VS": pd.to_numeric(members["VS"], errors="coerce").values,
                "DD60": pd.to_numeric(members["DD60"], errors="coerce").values,
                "Sector": (
                    members["Sector"].fillna("").values
                    if "Sector" in members.columns
                    else ""
                ),
                "LastBuy": (
                    members["LastBuy"].map(_fmt_date).values
                    if "LastBuy" in members.columns
                    else ""
                ),
            },
            index=members["ID"].map(_short_id),
        )
        out.index.name = "Ticker"
        return out

    def _on_grid_click(self, grid_df, event):
        try:
            clicked_row = event["primary_key_row"]
            short_name = grid_df.iloc[clicked_row].name
        except Exception:
            return
        match = self._snapshot.loc[
            self._snapshot["ID"].map(_short_id) == short_name, "ID"
        ]
        if match.empty:
            return
        self._select_ticker(match.iloc[0])

    def _select_ticker(self, ticker: str):
        option_values = [value for _, value in self.ticker_dd.options]
        if ticker is None or ticker not in option_values:
            self._draw_chart(ticker)
            return
        self._fixing_dropdown = True
        try:
            self.ticker_dd.value = ticker
        finally:
            self._fixing_dropdown = False
        self._draw_chart(ticker)

    def _chip_buttons(self, members: pd.DataFrame):
        if members.empty:
            return []
        hot = members.loc[
            members["Signal"].isin(["BUY", "SELL", "WASH", "DUMP", "REVU", "REVD"])
        ]
        hot = hot.sort_values(["Rank", "Weight"], ascending=[False, False]).head(24)
        buttons = []
        for _, row in hot.iterrows():
            color = SIGNAL_COLORS.get(row["Signal"], "#8b93a7")
            btn = widgets.Button(
                description=f"{row['Signal']}  {_short_id(row['ID'])}  {_fmt_pct(row['Chg'])}",
                layout=widgets.Layout(
                    width="auto", height="30px", margin="2px 4px 2px 0"
                ),
            )
            btn.style.button_color = color
            btn.on_click(partial(self._on_chip, row["ID"]))
            buttons.append(btn)
        return buttons

    def _draw_chart(self, ticker: str):
        if not ticker or self._bars.empty:
            return
        bars = self._bars.loc[self._bars["ID"] == ticker].sort_values("DATE")
        if bars.empty:
            return
        name = ticker
        if not self._snapshot.empty:
            hit = self._snapshot.loc[self._snapshot["ID"] == ticker]
            if not hit.empty:
                row = hit.iloc[0]
                pctb = row.get("PCTB")
                vs = row.get("VS")
                dd60 = row.get("DD60")
                pctb_txt = (
                    "—"
                    if pctb is None or (isinstance(pctb, float) and np.isnan(pctb))
                    else f"{float(pctb):.2f}"
                )
                vs_txt = (
                    "—"
                    if vs is None or (isinstance(vs, float) and np.isnan(vs))
                    else f"{float(vs):.0f}"
                )
                name = (
                    f"{_short_id(ticker)}  {row.get('Name', '')}  {row.get('Signal', '')}"
                    f"   PCTB {pctb_txt}  VS {vs_txt}  DD60 {_fmt_pct(dd60)}"
                )
        dates = bars["DATE"]
        with self.figure.batch_update():
            candle = self.figure.data[0]
            candle.x = dates
            candle.open = bars["Open"]
            candle.high = bars["High"]
            candle.low = bars["Low"]
            candle.close = bars["Close"]
            self.figure.data[1].x = dates
            self.figure.data[1].y = bars["MID"]
            self.figure.data[2].x = dates
            self.figure.data[2].y = bars["UP"]
            self.figure.data[3].x = dates
            self.figure.data[3].y = bars["DN"]
            self._set_marks(4, bars, "BUY0", "Low", 0.992)
            self._set_marks(5, bars, "SELL0", "High", 1.008)
            self._set_marks(6, bars, "WASH", "Low", 0.978)
            self._set_marks(7, bars, "DUMP", "High", 1.022)
            self._set_marks(8, bars, "REVU", "Low", 0.972)
            self._set_marks(9, bars, "REVD", "High", 1.028)
            self.figure.layout.title.text = name

    def _set_marks(
        self, index: int, bars: pd.DataFrame, flag: str, price_col: str, scale: float
    ):
        mask = bars[flag].fillna(False)
        self.figure.data[index].x = bars.loc[mask, "DATE"]
        self.figure.data[index].y = bars.loc[mask, price_col] * scale

    def _header_html(self, state: str, extra: str = "") -> str:
        return (
            '<div style="display:flex;justify-content:space-between;align-items:flex-end;'
            'padding:4px 2px 10px;border-bottom:1px solid #2a3142;margin-bottom:8px;">'
            "<div>"
            '<div style="color:#8b93a7;font-size:11px;letter-spacing:0.14em;">BQUANT APP</div>'
            '<div style="color:#f2f4f8;font-size:22px;font-weight:650;letter-spacing:0.02em;">MDX Scan</div>'
            f'<div style="color:#8b93a7;font-size:12px;padding-top:2px;">{extra}</div>'
            "</div>"
            f'<div style="color:#7aa2f7;font-size:12px;padding-bottom:4px;">{state}</div>'
            "</div>"
        )

    def _cards_html(self, snapshot: pd.DataFrame) -> str:
        specs = list(bench_universe())
        lookup = {}
        if snapshot is not None and not snapshot.empty:
            lookup = snapshot.set_index("ID").to_dict("index")
        cards = []
        for spec in specs:
            row = lookup.get(spec.ticker, {})
            last = row.get("Close")
            chg = row.get("Chg")
            signal = row.get("Signal", "")
            color = _chg_color(chg)
            signal_color = SIGNAL_COLORS.get(signal, "#8b93a7")
            cards.append(
                '<div style="flex:1;min-width:150px;background:#171d2b;border-radius:12px;'
                f'padding:12px 14px;border-left:4px solid {color};">'
                f'<div style="color:#8b93a7;font-size:11px;letter-spacing:0.08em;">{spec.label}</div>'
                f'<div style="color:#f2f4f8;font-size:20px;font-weight:600;padding-top:4px;">{_fmt_px(last)}</div>'
                f'<div style="color:{color};font-size:13px;padding-top:2px;">{_fmt_pts(last, chg)}  {_fmt_pct(chg)}</div>'
                f'<div style="color:{signal_color};font-size:12px;padding-top:8px;font-weight:600;">{signal or "—"}</div>'
                "</div>"
            )
        return (
            '<div style="display:flex;gap:10px;flex-wrap:wrap;padding:8px 0 4px;">'
            + "".join(cards)
            + "</div>"
        )

    def _breadth_html(self, members: pd.DataFrame) -> str:
        if members is None or members.empty:
            return '<div style="color:#8b93a7;padding:4px 2px 8px;">Waiting for HSI members.</div>'
        counts = members["Signal"].value_counts()
        chips = []
        for key, label in (
            ("BUY", "Buy"),
            ("SELL", "Sell"),
            ("WASH", "Wash"),
            ("DUMP", "Dump"),
            ("REVU", "Rev↑"),
            ("REVD", "Rev↓"),
        ):
            n = int(counts.get(key, 0))
            color = SIGNAL_COLORS[key]
            chips.append(
                f'<span style="display:inline-block;margin:0 10px 8px 0;padding:4px 10px;border-radius:999px;'
                f'background:#171d2b;color:{color};font-size:12px;">{label} {n}</span>'
            )
        n_up = int((members["Chg"] > 0).sum())
        n_down = int((members["Chg"] < 0).sum())
        return (
            '<div style="padding:2px 0 6px;">'
            f'<span style="color:#dce1ea;font-size:13px;margin-right:12px;">HSI {len(members)}</span>'
            f'<span style="color:#3dd68c;font-size:12px;margin-right:8px;">Up {n_up}</span>'
            f'<span style="color:#ff6b6b;font-size:12px;margin-right:16px;">Down {n_down}</span>'
            + "".join(chips)
            + "</div>"
        )

    def _column_legend_html(self) -> str:
        return (
            '<div style="padding:8px 2px 0;border-top:1px solid #2a3142;margin-top:6px;">'
            '<div style="color:#dce1ea;font-size:11px;letter-spacing:0.08em;margin-bottom:6px;">COLUMNS</div>'
            '<div style="margin:0 0 6px;font-size:12px;line-height:1.5;color:#c5c8d0;">'
            '<b style="color:#7aa2f7;">PCTB</b>'
            "&nbsp;&nbsp;Band position: 0 at lower DN, 1 at upper UP</div>"
            '<div style="margin:0 0 6px;font-size:12px;line-height:1.5;color:#c5c8d0;">'
            '<b style="color:#7aa2f7;">VS</b>'
            "&nbsp;&nbsp;Sell-vote score; SELL fires when VS crosses N5</div>"
            '<div style="margin:0 0 6px;font-size:12px;line-height:1.5;color:#c5c8d0;">'
            '<b style="color:#7aa2f7;">DD60</b>'
            "&nbsp;&nbsp;Drawdown from the 60-session high</div>"
            "</div>"
        )

    def _signal_legend_html(self) -> str:
        chips = []
        for key, text in SIGNAL_LEGEND:
            color = SIGNAL_COLORS.get(key, "#8b93a7")
            chips.append(
                f'<div style="margin:0 0 4px;font-size:11px;line-height:1.35;">'
                f'<span style="display:inline-block;min-width:58px;color:{color};font-weight:650;">{key}</span>'
                f'<span style="color:#8b93a7;">{text}</span></div>'
            )
        return (
            '<div style="padding:8px 2px 0;border-top:1px solid #2a3142;margin-top:6px;">'
            '<div style="color:#dce1ea;font-size:11px;letter-spacing:0.08em;margin-bottom:6px;">SIGNAL</div>'
            + "".join(chips)
            + "</div>"
        )
