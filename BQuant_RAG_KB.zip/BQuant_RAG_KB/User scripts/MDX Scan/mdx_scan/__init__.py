"""MDX Scan package. On BQuant, import MDXScanApp from mdx_scan.app."""

__all__ = ['MDXScanApp']


def __getattr__(name):
    if name == 'MDXScanApp':
        from .app import MDXScanApp
        return MDXScanApp
    raise AttributeError(name)
