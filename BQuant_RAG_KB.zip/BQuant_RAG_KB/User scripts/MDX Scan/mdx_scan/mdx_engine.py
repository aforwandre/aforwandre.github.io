"""Daily MDX v4e channel — pandas port of Source/MDX_futu_formula.txt.

Futu SMA(X, N, 1) is Wilder smoothing. EMA uses alpha = 2 / (N + 1).
STD uses population std (ddof=0), matching TDX/Futu STD.
AND binds tighter than OR in the WASH reclaim clause.
v4e BOT requires Close >= Open. A down bar does not buy.
Daily bars only. Not investment advice.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import MDXParams, SIGNAL_RANK


FORMULA_VERSION = 'v4e'

OHLCV_COLS = ('Open', 'High', 'Low', 'Close', 'Volume')


def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False, min_periods=span).mean()


def _wilder(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()


def _sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).mean()


def _sum(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).sum()


def _std(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).std(ddof=0)


def _hhv(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).max()


def _llv(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).min()


def _safe_div(numer: pd.Series, denom: pd.Series) -> pd.Series:
    denom = denom.replace(0, np.nan)
    out = numer / denom
    return out.replace([np.inf, -np.inf], np.nan)


def _flag(condition: pd.Series) -> pd.Series:
    return condition.fillna(False).astype(bool)


def compute_mdx_bars(ohlcv: pd.DataFrame, params: MDXParams | None = None) -> pd.DataFrame:
    """Compute MDX v4e columns for one ticker.

    `ohlcv` must contain DATE plus Open/High/Low/Close/Volume, sorted by DATE.
    """
    params = params or MDXParams()
    frame = ohlcv.copy()
    missing = [col for col in OHLCV_COLS if col not in frame.columns]
    if missing:
        raise KeyError(f'Missing OHLCV columns: {missing}')

    frame = frame.sort_values('DATE').reset_index(drop=True)
    for col in OHLCV_COLS:
        frame[col] = pd.to_numeric(frame[col], errors='coerce')

    open_ = frame['Open']
    high = frame['High']
    low = frame['Low']
    close = frame['Close']
    volume = frame['Volume'].fillna(0.0)

    n1, n2, n3, n5 = params.n1, params.n2, params.n3, params.n5

    mid = _ema(close, n1)
    ema60 = _ema(close, 60)
    sdv = _std(close, n1)
    prev_close = close.shift(1)
    tr1 = pd.concat(
        [high - low, (high - prev_close).abs(), (low - prev_close).abs()],
        axis=1,
    ).max(axis=1)
    atrv = _wilder(tr1, n2)
    mix = 0.5 * sdv + 0.5 * atrv
    up = mid + n3 * mix
    dn = mid - n3 * mix
    pctb = _safe_div(close - dn, up - dn)

    lc = prev_close
    gain = (close - lc).clip(lower=0)
    abs_chg = (close - lc).abs()
    rsi1 = 100.0 * _safe_div(_wilder(gain, n2), _wilder(abs_chg, n2))

    rsv_span = (_hhv(high, 9) - _llv(low, 9))
    rsv1 = 100.0 * _safe_div(close - _llv(low, 9), rsv_span)
    kk = _wilder(rsv1, 3)
    dd1 = _wilder(kk, 3)
    jj = 3.0 * kk - 2.0 * dd1
    dif1 = _ema(close, 12) - _ema(close, 26)
    dea1 = _ema(dif1, 9)
    macdh = 2.0 * (dif1 - dea1)

    typical = (high + low + close) / 3.0
    hl = high - low
    clv = _safe_div((close - low) - (high - close), hl).fillna(0.0)
    cmf1 = _safe_div(_sum(clv * volume, n1), _sum(volume, n1))
    prev_typ = typical.shift(1)
    posmf = _sum((typical * volume).where(typical > prev_typ, 0.0), n2)
    negmf = _sum((typical * volume).where(typical < prev_typ, 0.0), n2)
    mf_ratio = _safe_div(posmf, negmf)
    mfi1 = 100.0 - 100.0 / (1.0 + mf_ratio)
    mfi1 = mfi1.where(negmf != 0, np.where(posmf > 0, 100.0, np.nan))
    volr = _safe_div(volume, _sma(volume, n1))
    madev = _sma((typical - _sma(typical, n2)).abs(), n2)
    cci1 = _safe_div(typical - _sma(typical, n2), 0.015 * madev)
    wr1 = _safe_div(_hhv(high, n2) - close, _hhv(high, n2) - _llv(low, n2)) * -100.0

    upt = _flag(close > ema60)
    pull = _flag(pctb < 0.28)
    gold = _flag((kk > dd1) & (kk.shift(1) <= dd1.shift(1)))
    dead = _flag((kk < dd1) & (kk.shift(1) >= dd1.shift(1)))
    mfup = _flag((cmf1 > cmf1.shift(1)) | (mfi1 < 30))
    mfdn = _flag((cmf1 < cmf1.shift(1)) | (mfi1 > 70))
    hammer = _flag((close - low > 1.5 * (open_ - close).abs()) & (close >= open_))
    pl = _llv(low, 5).shift(1)
    rng = (high - low).clip(lower=0.000001)
    ls = pd.concat([open_, close], axis=1).min(axis=1) - low
    ret_lc = _safe_div(close - lc, lc)
    wash = _flag(
        (low < pl * 0.998)
        & (ret_lc <= -0.015)
        & ((close >= pl) | ((close > open_) & (ls / rng > 0.35)))
    )
    ret3 = _safe_div(close, close.shift(3)) - 1.0
    dump1 = _flag(
        (ret3.shift(1) > 0.025)
        & (volr.shift(1) < 1.05)
        & (close < open_)
        & (volr > 1.3)
        & (ret_lc <= -0.02)
    )
    grind = _flag((ret3 > 0.03) & (_sma(volr, 3) < 0.9) & (pctb > 0.7))
    macdup = _flag(macdh > macdh.shift(1))
    macddn = _flag(macdh < macdh.shift(1))
    ososc = _flag((cci1 < -80) | (wr1 < -80))
    nearhi = _flag(close > _hhv(high, 20).shift(1) * 0.97)
    bounce = _flag(close > close.shift(1))
    reclaim = _flag((close > open_.shift(1)) | (close >= high.shift(1)))
    deep = _flag(_llv(low, 5) <= _llv(low, 60) * 1.005)
    dd60 = _safe_div(close, _hhv(high, 60)) - 1.0
    bot = _flag(
        deep
        & (pctb < 0.18)
        & bounce
        & reclaim
        & (close >= open_)
        & (dd60 < -0.18)
        & (~dump1)
        & (~nearhi)
    )

    vb = (
        upt.astype(int)
        + pull.astype(int)
        + _flag(rsi1 < 45).astype(int)
        + _flag(gold | (jj < 20)).astype(int)
        + mfup.astype(int)
        + _flag(wash | hammer).astype(int)
        + macdup.astype(int)
        + ososc.astype(int)
        - 2 * dump1.astype(int)
    )
    dnt = _flag(close < ema60)
    highz = _flag((pctb > 0.65) | (close > mid))
    vs = (
        dnt.astype(int)
        + highz.astype(int)
        + _flag(rsi1 > 55).astype(int)
        + _flag(dead | (jj > 80)).astype(int)
        + mfdn.astype(int)
        + dump1.astype(int)
        + grind.astype(int)
        + macddn.astype(int)
        - 2 * wash.astype(int)
    )

    b1 = bot.astype(int)
    s1 = _flag((vs >= n5) & (vs.shift(1) < n5) & (~wash)).astype(int)
    cooldown = params.cooldown
    cb = sum(b1.shift(i).fillna(0) for i in range(1, cooldown + 1))
    cs = sum(s1.shift(i).fillna(0) for i in range(1, cooldown + 1))
    hb = _sum(b1, params.buy_lookback) - b1
    buy0 = _flag((b1 == 1) & (cb == 0) & (cs == 0))
    sell0 = _flag((s1 == 1) & (cb == 0) & (cs == 0) & (hb > 0) & (~buy0))

    kcu = _ema(close, n1) + 1.5 * atrv
    kcl = _ema(close, n1) - 1.5 * atrv
    squeeze = _flag((mid - 2 * sdv > kcl) & (mid + 2 * sdv < kcu))
    contu = _flag(
        upt
        & (pctb > 0.45)
        & (pctb < 0.88)
        & (macdh > 0)
        & (cmf1 > 0)
        & macdup
        & (macdh.shift(1) <= 0)
    )
    revu = _flag((pctb < 0.12) & (pctb.shift(1) >= 0.12) & (rsi1 < 28))
    revd = _flag((pctb > 0.88) & (pctb.shift(1) <= 0.88) & (rsi1 > 72))

    wash_mark = _flag(wash & (~buy0))
    dump_mark = _flag((dump1 | grind) & (~sell0))
    revu_mark = _flag(revu & (~buy0))
    revd_mark = _flag(revd & (~sell0))

    chg = _safe_div(close, prev_close) - 1.0

    out = frame.copy()
    out['MID'] = mid
    out['UP'] = up
    out['DN'] = dn
    out['PCTB'] = pctb
    out['RSI'] = rsi1
    out['VS'] = vs
    out['VB'] = vb
    out['DD60'] = dd60
    out['Chg'] = chg
    out['BUY0'] = buy0
    out['SELL0'] = sell0
    out['WASH'] = wash_mark
    out['DUMP'] = dump_mark
    out['REVU'] = revu_mark
    out['REVD'] = revd_mark
    out['SQUEEZE'] = squeeze
    out['CONTU'] = contu
    out['Signal'] = _signal_label(buy0, sell0, wash_mark, dump_mark, revu_mark, revd_mark, contu, squeeze)
    out['Rank'] = out['Signal'].map(SIGNAL_RANK).fillna(0).astype(int)
    return out


def _signal_label(buy0, sell0, wash, dump, revu, revd, contu, squeeze) -> pd.Series:
    label = pd.Series('', index=buy0.index, dtype=object)
    label = np.where(squeeze, 'SQZ', label)
    label = np.where(contu, 'CONT', label)
    label = np.where(revd, 'REVD', label)
    label = np.where(revu, 'REVU', label)
    label = np.where(dump, 'DUMP', label)
    label = np.where(wash, 'WASH', label)
    label = np.where(sell0, 'SELL', label)
    label = np.where(buy0, 'BUY', label)
    return pd.Series(label, index=buy0.index)


def compute_universe(long_ohlcv: pd.DataFrame, params: MDXParams | None = None) -> pd.DataFrame:
    """Run MDX on a long OHLCV frame with an ID column. Returns stacked bar rows."""
    params = params or MDXParams()
    if long_ohlcv is None or long_ohlcv.empty:
        return pd.DataFrame()

    parts = []
    for ticker, group in long_ohlcv.groupby('ID', sort=False):
        bars = compute_mdx_bars(group, params)
        bars['ID'] = ticker
        parts.append(bars)
    if not parts:
        return pd.DataFrame()
    return pd.concat(parts, ignore_index=True, sort=False)


def latest_snapshot(bar_df: pd.DataFrame) -> pd.DataFrame:
    """One row per ID: the latest DATE."""
    if bar_df is None or bar_df.empty:
        return pd.DataFrame()
    ordered = bar_df.sort_values(['ID', 'DATE'])
    latest = ordered.groupby('ID', as_index=False).tail(1).copy()
    last_buy = _last_flag_date(bar_df, 'BUY0')
    last_sell = _last_flag_date(bar_df, 'SELL0')
    latest['LastBuy'] = latest['ID'].map(last_buy)
    latest['LastSell'] = latest['ID'].map(last_sell)
    return latest.reset_index(drop=True)


def _last_flag_date(bar_df: pd.DataFrame, flag_col: str) -> pd.Series:
    flagged = bar_df.loc[bar_df[flag_col].fillna(False), ['ID', 'DATE']]
    if flagged.empty:
        return pd.Series(dtype='datetime64[ns]')
    return flagged.groupby('ID')['DATE'].max()
