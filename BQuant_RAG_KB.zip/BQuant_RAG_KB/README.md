# BQuant RAG KB — Portable AI Dictionary

A **self-contained, platform-agnostic knowledge base** for building Bloomberg
**BQuant Desktop** analytics notebooks with any AI coding agent (Cursor, Qoder,
TRAE, Claude Code, GitHub Copilot, or a plain LLM). It bundles three layers that
work together:

1. **`wiki/`** — a generated navigation index (55 pages) that maps every module
   and concept to the exact source file and line range.
2. **`RAG KB/`** — the curated knowledge itself: numbered topic files, the
   retrieval router, exact-search catalogs, and proven request recipes.
3. **`User scripts/`** — five complete reference implementations (real BQuant
   Desktop dashboards) that the wiki and topics cite line-by-line.

Plus **`rules/`** (12 project rules in neutral Markdown) and **`.aiignore`**
(what *not* to vector-index). Everything a coding agent needs to reason about
BQuant BQL, pandas/Arrow response shapes, Desktop limits, and these five apps —
without access to the curator's original workspace.

> **Start here:** read this README, then `INDEX.md` for the navigation map, then
> `RAG KB/00-RAG-INDEX.md` (the retrieval router) before writing any query.

---

## How to use this with your AI coding agent

1. **Point your agent at this folder** as its knowledge/context root.
2. **Install the rules** — see `rules/README.md` to convert the 12 neutral rules
   into your platform's format (Cursor `.mdc`, `CLAUDE.md`/`AGENTS.md`, Qoder,
   TRAE, Copilot instructions). At minimum, load the always-on rules
   (`00`–`03`, `95`) into the system/context prompt.
3. **Apply `.aiignore`** to your indexer (rename to `.cursorignore`,
   `.aiexclude`, etc.) so large exact-search-only files don't crowd out the
   routed topics.
4. **Follow the retrieval protocol** (below) — do not let the agent free-search
   the whole corpus.

### Retrieval protocol (destination-first — this is what makes it efficient)

Stop at the **first** match; do not load the atlas or the whole catalog:

1. **Hard stops first** — `rules/00-bquant-hard-stops.md` (ESG/GHG ban, Desktop-only, closed-world).
2. **A named app?** → open its **one** route card: `RAG KB/25`–`29` + the matching `rules/project-*.md`. Then read `config → data → engine → app → MAIN` of that project under `User scripts/`.
3. **A new composition goal?** → open **one** card in `RAG KB/BUNDLE_EXAMPLES.md` (Goal table). Official-card *code usage* is authoritative; its feature set is not your spec.
4. **Not a named destination?** → one row of the intent atlas in `RAG KB/00-RAG-INDEX.md` §8, then that section only.
5. **A genuinely new BQL token?** → exact-search `## <token>` in `RAG KB/CONCEPT_INDEX.md` (never semantic search), then run the substitution review in `RAG KB/23`.

Never implement from the `09`/`11` tutorials or from `22` description
similarity. `22-BQuant_DataItems.md` is **exact-search spelling only**.

---

## Package layout

```
BQuant_RAG_KB/
├── README.md                  ← you are here
├── INDEX.md                   ← navigation map (projects, topics, wiki tree)
├── .aiignore                  ← merged, platform-neutral indexing boundary
├── rules/                     ← 12 project rules in neutral Markdown + README
├── RAG KB/                    ← curated knowledge (topics 00–29 + artifacts)
│   ├── 00-RAG-INDEX.md        ← the retrieval router (entry point)
│   ├── 01…29-*.md             ← canonical topic files
│   ├── 22-BQuant_DataItems.md ← exact-search data-item catalog (22,513 items)
│   ├── CONCEPT_INDEX.md/.json ← exact `## token` census
│   ├── BUNDLE_EXAMPLES.md/.json ← proven request recipes (Goal table)
│   ├── RAG_KB_MANIFEST.json   ← topic registry + load policies (metadata)
│   ├── PROJECT_OPERATIONS_AND_HISTORY.md ← aggregated ops + known-gaps + history
│   └── *.py                   ← bundle builders (upstream maintenance)
├── User scripts/              ← 5 reference implementations (source only)
└── wiki/                      ← 55-page generated navigation index
```

---

## Redaction and data-governance (important)

This package was prepared for **external sharing**. Sensitive payload has been
removed or replaced with sample values:

- **Real AIM account codes → `ACCTnn`**, **real fund names → `Sample Fund nn`**,
  **real personnel names → `Sample FM n`**, and a refused account code →
  `SAMPLEAIM`. This affects `User scripts/ETF Capping Monitoring/`
  (`config.py`, `tests/test_engine.py`), `RAG KB/25-etf-capping-monitor.md`, and
  the FI Spread `DECISION_RECORD.md`.
- ETF Capping `config.py` is the **redacted** sample config (54 `ACCTnn` sample
  accounts). Consequence: the shipped `tests/test_engine.py` fixtures are
  illustrative of test *structure* and are **not guaranteed to pass** against the
  redacted config — read them as patterns, not as a green suite.
- **Bloomberg index mnemonics** such as `LEGATRUU Index` are **kept** on purpose —
  they are published market identifiers, not credentials.
- No absolute local paths, no API keys/tokens, and no ESG/GHG/sustainable-finance
  content are present.

---

## What is intentionally NOT included (and why)

| Excluded | Reason |
|---|---|
| `RAG KB/Raw source/` (~154 MB Bloomberg Help Center HTML) | Already transcribed into the curated topics; raw HTML is quarantined provenance, not needed and too large to redistribute. Some topics still contain historical `Raw source/…` **citations** — treat them as provenance pointers, not resolvable links. |
| `RAG KB/Official scripts/` (19 Bloomberg demo cards) | Per the KB's own policy these are OCR-heavy duplicates whose verified patterns are **distilled into** topics `01`/`02`/`09`/`18` and the `BUNDLE_EXAMPLES.md` Goal table (which explicitly says "Do not copy `Official scripts/`"). The usable knowledge is in `BUNDLE_EXAMPLES.md`. |
| `RAG KB/Restricted reference/` (ESG/GHG historical examples) | Touches the highest-priority hard stop; restricted and not for redistribution. |
| `RAG KB/BQUANT_RAG_KNOWLEDGE_BASE.md` (2.3 MB generated bundle) | A generated concatenation of topics `00`–`29`; redundant with the individual topic files, which are all present. |
| Platform rule trees `.cursor/`, `.qoder/`, `.trae/` | Replaced by the single neutral **`rules/`** folder so any agent can adapt them. |
| `.qoder/sync_rules.py`, `.qoder/MANIFEST.json`, `.cursorindexingignore`, `.qoderignore` | Upstream three-way-mirror maintenance tooling; not needed to consume the KB. `.aiignore` replaces the two ignore files. |
| `instruction.md`, `ToDoList.md`, `VersionLog.md` | Workspace-running documents; their durable, KB-relevant content was **aggregated into** `RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md`, then the originals were dropped. |
| `cache/`, `Upload/`, `__pycache__/`, `*.backup-*/`, `.DS_Store` | Regenerated caches, duplicate deployment snapshots, and bloat. |

---

## Caveats for the consumer

- **Frozen corpus.** Official Help Center / catalog evidence is frozen at
  **2026-07-25**. Anything later needs dated, user-supplied evidence. Never fill
  a BQuant gap from web search or model memory.
- **`RAG_KB_MANIFEST.json` SHA-256 values reflect the curator's original files**,
  not these redacted copies. Do not run `regenerate_kb_bundle.py --check` here and
  expect it to pass; the builders are included for reference only and need the
  full upstream repo (including the quarantined archives) to run.
- **Wiki line-anchors** into `rules/*.md` are exact (rules were copied verbatim).
  Wiki citations that previously pointed at `instruction.md` / `VersionLog.md` /
  `ToDoList.md` now resolve to `RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md`; their
  old line numbers are approximate because the content was aggregated.
- **Desktop-only.** Nothing here executes BQL. BQuant Desktop is the runtime; a
  local machine is for authoring and review only.

See `INDEX.md` for the full navigation map.
