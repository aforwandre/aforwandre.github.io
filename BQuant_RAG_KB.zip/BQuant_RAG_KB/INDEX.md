# INDEX — Navigation Map

Fast lookup for the whole package. Read `README.md` first for usage, governance,
and exclusions. The authoritative retrieval router is `RAG KB/00-RAG-INDEX.md`.

---

## 1. The five reference apps (start from the route card)

For a named app, open **one** route card + its project rule, then read the
reference implementation in the order `config → data → engine → app → MAIN`.

| App | Route card | Project rule | Reference implementation | Wiki module |
|---|---|---|---|---|
| ETF Capping Monitoring | `RAG KB/25-etf-capping-monitor.md` | `rules/project-etf-capping-monitor.md` | `User scripts/ETF Capping Monitoring/etf_capping/` | `wiki/ETF Capping Monitoring Module/` |
| ETF Spread Monitoring | `RAG KB/27-etf-spread-monitor.md` | `rules/project-etf-spread-monitor.md` | `User scripts/ETF Spread Monitoring/etf_spread/` | `wiki/ETF Spread Monitoring Module/` |
| FI Index Change | `RAG KB/28-fi-index-change.md` | `rules/project-fi-index-change.md` | `User scripts/FI Index Change/fi_index_change/` | `wiki/Fixed Income Index Change Module/` |
| FI Spread Movement Monitoring | `RAG KB/29-fi-spread-movement-monitoring.md` | `rules/project-fi-spread-movement-monitoring.md` | `User scripts/FI Spread Movement Monitoring/fi_spread_movement/` | `wiki/Fixed Income Spread Movement Module/` |
| MDX Scan | `RAG KB/26-mdx-scan.md` | `rules/project-mdx-scan.md` | `User scripts/MDX Scan/mdx_scan/` | `wiki/MDX Scan Module.md` |

---

## 2. RAG KB topic index (`RAG KB/`)

### Router and safety
| File | Role |
|---|---|
| `00-RAG-INDEX.md` | **Entry point.** Closed-world navigator: route table, retrieval procedure, risk classes, evidence taxonomy, intent atlas. |
| `23-bql-substitution-due-diligence.md` | Mandatory review before adding/replacing any BQL field or API source. |
| `24-etf-field-migration-incident.md` | Company-mapping / Thai-pricing / restricted-data incident + prevention. |

### BQL domain recipes
| File | Role |
|---|---|
| `01-bql-for-equities.md` | Equity universes, fundamentals, returns, screening, aggregation, PIT. |
| `02-bql-for-fixed-income.md` | Bond snapshots, index analytics, spreads, ratings, cashflows, membership diff. |
| `12-bql-fixed-income-screening.md` | Fixed-income screening patterns. |
| `13-bql-for-economics.md` | Country macro series, estimates, economic calendar. |
| `14-bql-for-port-prep.md` | PORT PREP recipes. |
| `19-equity-scoring-model.md` | Building an equity scoring model. |
| `20-earnings-surprise.md` | Earnings-surprise investigation. |

### API, data items, and response shape
| File | Role |
|---|---|
| `07-pybql-api-reference.md` | PyBQL API signatures (`Service`, `Request`, `execute`/`execute_many`, transforms). |
| `08-bql-data-items.md` | Curated data-item semantics, traps, market-status zero-price rule. |
| `18-using-pandas.md` | pandas/Arrow response shapes, `DATE` handling, `execute_many` lineage. |
| `22-BQuant_DataItems.md` | **Exact-search-only** catalog of 22,513 data-item mnemonics (spelling/existence, not semantics). In `.aiignore`. |
| `CONCEPT_INDEX.md` / `.json` | Exact `## token` census for new-token due diligence. In `.aiignore`. |

### Platform, onboarding, and provenance
| File | Role |
|---|---|
| `05-get-started.md` | Get started + Desktop limits (2-min timeout, 256 MB, concurrency). |
| `06-get-data-overview.md` | Get-data overview. |
| `03-equity-foundations.md` / `04-fixed-income-foundations.md` | Developing in BQuant — equity / fixed-income foundations. |
| `09-build-analysis.md` | UI templates & Error Log tutorial. **Open by path only** (in `.aiignore`; it stole named-app retrieval). |
| `11-sample-notebooks.md` | PyBQL recipe catalog. **Open by path only** (in `.aiignore`). |
| `10-bquant-research.md` | BQuant Research. |
| `15-share-results.md` | Sharing results. |
| `16-home.md` | BQuant coverage ledger. |
| `17-scheduling.md` | Scheduling — Desktop stop card. |
| `21-bquant-whats-new.md` | Curated release digest. |
| `Technical_Analysis_Indicators.txt` | Post-cutoff model-authored draft (in `.aiignore`; provenance not requalified). |

### Generated artifacts and builders (reference only — see README caveats)
| File | Role |
|---|---|
| `BUNDLE_EXAMPLES.md` / `.json` | Proven request recipes + Goal table (distilled official-card usage). **Keep `.md` indexed.** |
| `RAG_KB_MANIFEST.json` | Topic registry, load policies, route anchors (SHAs reflect upstream, not these copies). In `.aiignore`. |
| `concept_index_overlay.json`, `bundle_examples_registry.json` | Curated overlays feeding the builders. |
| `regenerate_kb_bundle.py`, `build_concept_index.py`, `build_bundle_examples.py` | Bundle builders (need the full upstream repo to run). |

### Aggregated operations layer (new in this package)
| File | Role |
|---|---|
| `PROJECT_OPERATIONS_AND_HISTORY.md` | Global operating protocol, cross-platform model, per-project deployment shape, **known-gaps ledger**, and decision-history digest — aggregated from the former `instruction.md` / `ToDoList.md` / `VersionLog.md`. |

---

## 3. Rules (`rules/`)

12 project rules in neutral Markdown + `rules/README.md` (adaptation guide).
Always-on: `00`–`03`, `95`. Scoped: `10`, `11`, and the five `project-*`.
See `rules/README.md` for the index and how to convert to your platform.

---

## 4. Wiki navigation tree (`wiki/`)

Top-level pages:
- `Project Overview and Introduction.md`, `Getting Started Guide.md`
- `System Architecture and Design/` (Core Architecture Patterns, Data Flow, Deployment, Integration)
- `Bloomberg BQL Integration/` (Service Configuration, Query Building Patterns, Data Items Reference, Error Handling)
- `Configuration Management System.md`, `Data Processing Pipeline.md`
- `Testing Strategy and Framework.md`, `Deployment and Operations Guide.md`, `Developer Guide and Contributing.md`
- `MDX Scan Module.md`

Per-app module folders:
- `ETF Capping Monitoring Module/` (7 pages)
- `ETF Spread Monitoring Module/` (5 pages)
- `Fixed Income Index Change Module/` (nested: Data Processing Pipeline → BQL Query Construction and Execution; Analytical Algorithms and Change Detection; Reporting and Export Capabilities)
- `Fixed Income Spread Movement Module/` (5 pages)

> The wiki uses `file://` links with line anchors (e.g.
> `RAG KB/27-etf-spread-monitor.md#L123-L149`) that resolve against this
> package. Links that formerly cited `instruction.md` / `VersionLog.md` /
> `ToDoList.md` now point to `RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md`.

---

## 5. Quick retrieval cheat-sheet

| I want to… | Open |
|---|---|
| Check what is forbidden before anything | `rules/00-bquant-hard-stops.md` |
| Work on one of the five apps | its route card `RAG KB/25`–`29` + `rules/project-*.md` |
| Build a new BQuant composition | one card in `RAG KB/BUNDLE_EXAMPLES.md` |
| Confirm a data-item spelling | exact-search `RAG KB/22-BQuant_DataItems.md` |
| Understand a data-item's meaning/traps | `RAG KB/08-bql-data-items.md` |
| Get a PyBQL signature | `RAG KB/07-pybql-api-reference.md` |
| Handle a BQL response in pandas | `RAG KB/18-using-pandas.md` |
| Vet a field/API substitution | `RAG KB/23` (+ `CONCEPT_INDEX.md` census) |
| Recall project decisions / known gaps | `RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md` |
| Route anything else | `RAG KB/00-RAG-INDEX.md` |
