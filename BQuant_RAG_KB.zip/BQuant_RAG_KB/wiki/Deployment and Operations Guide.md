# Deployment and Operations Guide

<cite>
**Referenced Files in This Document**
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [ToDoList.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/fi_index_change/config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [User scripts/FI Index Change/refresh_local.py](file://User scripts/FI Index Change/refresh_local.py)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py](file://User scripts/FI Spread Movement Monitoring/sync_upload.py)
- [User scripts/ETF Spread Monitoring/etf_spread/config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [RAG KB/regenerate_kb_bundle.py](file://RAG KB/regenerate_kb_bundle.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This guide documents the deployment, build, release, monitoring, backup, recovery, operational runbooks, cross-platform synchronization, capacity planning, and troubleshooting procedures for the Bloomberg Desktop applications in this repository. The project contains three primary Desktop-facing modules:

- ETF Capping Monitoring
- ETF Spread Monitoring
- FI Index Change
- FI Spread Movement Monitoring

The workspace is not a traditional server application; it is a collection of BQuant Desktop notebooks and Python packages that request data from Bloomberg through BQL, render results locally, and optionally cache intermediate or historical data. Operational control therefore centers on notebook execution, local preview servers, package mirroring into `Upload/`, and cross-platform rule/KB synchronization between Cursor, Qoder, and TRAE.

## Project Structure
At a high level, the repository separates:

- Operator instructions and change records at the workspace root.
- Per-application code under `User scripts/<Project Name>/`.
- Generated or mirrored artifacts such as `Upload/` and preview pages.
- A closed-world knowledge base under `RAG KB/` with regeneration tooling.
- Cross-platform rule trees under `.cursor/`, `.qoder/`, and `.trae/`.

```mermaid
graph TB
Root["Workspace Root"]
Instructions["instruction.md<br/>ToDoList.md<br/>VersionLog.md"]
Scripts["User scripts"]
ETF_Capping["ETF Capping Monitoring"]
ETF_Spread["ETF Spread Monitoring"]
FI_Index["FI Index Change"]
FI_Spread["FI Spread Movement Monitoring"]
RAGKB["RAG KB"]
Rules[".cursor / .qoder / .trae rules"]
Root --> Instructions
Root --> Scripts
Root --> RAGKB
Root --> Rules
Scripts --> ETF_Capping
Scripts --> ETF_Spread
Scripts --> FI_Index
Scripts --> FI_Spread
```

**Diagram sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [RAG KB/regenerate_kb_bundle.py:1-80](file://RAG KB/regenerate_kb_bundle.py#L1-L80)

**Section sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:11-17](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Core Components
The operational surface area consists of four application families plus shared build and synchronization tooling.

| Component | Primary Purpose | Desktop Entry Point | Key Operational Artifacts |
|---|---|---|---|
| ETF Capping Monitoring | AIM account capping checks and fund-level alerts | Notebook cell described in operator instructions | `etf_capping/` package, optional PDF helper |
| ETF Spread Monitoring | ETF quote, return, NAV, and flow history with local CSV cache | Notebook cell described in operator instructions | `etf_spread/` package, `cache/` directory |
| FI Index Change | Index membership changes, analytics, and export tables | Notebook cell described in operator instructions | `fi_index_change/` package, `cache/` directory |
| FI Spread Movement Monitoring | Spread movement ranking, bucket charts, and per-bond paths | Notebook cell described in operator instructions | `fi_spread_movement/` package, `cache/` directory |
| Build and Sync Tooling | Preview generation, upload mirroring, KB bundle regeneration | Local CLI commands | `refresh_local.py`, `sync_upload.py`, `regenerate_kb_bundle.py` |

**Section sources**
- [instruction.md:13-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/fi_index_change/config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)

## Architecture Overview
The Desktop deployment model is notebook-driven rather than service-driven. Each application follows a similar pattern:

1. The operator copies generated runtime files into a BQuant Desktop project.
2. The kernel restarts and runs one notebook cell.
3. The UI waits for an explicit action such as Update or Refresh.
4. Data requests are sent to Bloomberg via BQL.
5. Results are parsed, validated, cached where supported, and rendered locally.
6. Export surfaces copy data to clipboard without writing files on Desktop.

```mermaid
sequenceDiagram
participant Operator as "Operator"
participant Notebook as "Desktop Notebook"
participant App as "Application Package"
participant Cache as "Local Cache"
participant BQL as "Bloomberg BQL"
Operator->>Notebook : Copy Upload files and start notebook
Operator->>Notebook : Restart kernel and run initial cell
Operator->>App : Click Update or Refresh
App->>BQL : Execute one or more requests
BQL-->>App : Response frames or errors
App->>Cache : Read or write cached data when allowed
App-->>Notebook : Render tables, charts, status, and logs
```

**Diagram sources**
- [instruction.md:13-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/fi_index_change/config.py:88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)

## Detailed Component Analysis

### Bloomberg Desktop Deployment Process

#### Environment Setup
- Do not run data requests from the development Mac unless explicitly instructed.
- Use the system Python interpreter for local refresh commands because the project virtual environment may lack pandas.
- For FI Spread Movement Monitoring, the local preview server is managed by a launchctl service; editing `server.py` requires restarting the service.
- For FI Index Change, the local preview server is started by the refresh command and listens on port 8770.

**Section sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:55-60](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/refresh_local.py:15-19](file://User scripts/FI Index Change/refresh_local.py#L15-L19)

#### Package Distribution
Each application ships a generated `Upload/` mirror so the Desktop copy step is deterministic:

- FI Index Change uses `refresh_local.py` to copy seven runtime modules plus `MAIN.ipynb`.
- FI Spread Movement Monitoring uses `sync_upload.py` to mirror seven runtime modules plus `MAIN.ipynb.txt`.
- ETF Spread Monitoring documentation lists `cache.py` as required because `app.py` imports it at module load.
- ETF Capping Monitoring documentation lists its package contents and copy steps.

```mermaid
flowchart TD
Start(["Developer edits package"]) --> RunSync["Run sync or refresh command"]
RunSync --> ValidateTests["Run tests"]
ValidateTests --> BuildPreview["Build preview page"]
BuildPreview --> CheckPreview["Check preview behavior"]
CheckPreview --> MirrorUpload["Mirror Upload/ files"]
MirrorUpload --> ByteCompare["Byte-compare source and mirror"]
ByteCompare --> Success{"All steps pass?"}
Success --> |Yes| Deploy["Copy Upload/ into BQuant Desktop project"]
Success --> |No| Stop["Stop and fix failing step"]
```

**Diagram sources**
- [User scripts/FI Index Change/refresh_local.py:1-20](file://User scripts/FI Index Change/refresh_local.py#L1-L20)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:1-13](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L1-L13)
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [User scripts/FI Index Change/refresh_local.py:40-51](file://User scripts/FI Index Change/refresh_local.py#L40-L51)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:33-59](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L33-L59)
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

#### Configuration Management
Configuration is kept in per-application `config.py` modules and documented in operator instructions:

- ETF Capping Monitoring defines batch sizes, limits, status colors, and desensitized output configuration.
- ETF Spread Monitoring defines period keys, business-day assumptions, share-class entries, and ISIN book entries.
- FI Index Change defines index defaults, filter widths, chart sizing, split-request policy, retry policy, and cache directory naming.
- FI Spread Movement Monitoring defines universe sources, spread types, descriptor fields, duration measures, window constraints, display controls, and timeout protection.

```mermaid
classDiagram
class ETFSpreadConfig {
+PERIOD_KEYS
+HISTORY_BUSINESS_DAYS
+SHARE_CLASSES
+ISIN_BOOK
+enabled_share_classes()
+isin_book_frame()
+share_class_directory()
}
class FIIndexChangeConfig {
+DEFAULT_INDEX
+SPLIT_REQUESTS
+QUERY_ATTEMPTS
+CACHE_DIR_NAME
+CHART_WIDTH_PX
+PIN_FIRST_COLUMN
}
class FISpreadMovementConfig {
+TOP_N
+UNIVERSE_SOURCES
+SPREAD_TYPES
+DESCRIPTOR_FIELDS
+DURATION_FIELDS
+MAX_RANGE_DAYS
+CACHE_KEEP_RUNS
+QUERY_ATTEMPTS
}
ETFSpreadConfig <.. FISpreadMovementConfig : "similar operator-config pattern"
FIIndexChangeConfig <.. FISpreadMovementConfig : "shared Desktop operational concepts"
```

**Diagram sources**
- [User scripts/ETF Spread Monitoring/etf_spread/config.py:15-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L140)
- [User scripts/FI Index Change/fi_index_change/config.py:12-133](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L133)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:26-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L389)

**Section sources**
- [User scripts/ETF Capping Monitoring/etf_capping/config.py:1-48](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L48)
- [User scripts/ETF Spread Monitoring/etf_spread/config.py:15-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L140)
- [User scripts/FI Index Change/fi_index_change/config.py:12-133](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L133)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:26-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L389)

### Build and Release Procedures

#### Updating Modules Across Platforms
The repository treats generated artifacts and mirrors as authoritative delivery targets:

- For FI Index Change, `python3 refresh_local.py` runs tests, builds the preview, checks the preview, starts the preview server, and re-copies runtime files plus the notebook into `Upload/`.
- For FI Spread Movement Monitoring, `python3 sync_upload.py` writes or checks the `Upload/` mirror and prunes stray metadata such as `.DS_Store` and `__pycache__`.
- For ETF Spread Monitoring, the README and instruction document require copying `cache.py`; missing it causes a `ModuleNotFoundError` at the first notebook cell.
- For ETF Capping Monitoring, the README documents the package layout and copy procedure.

```mermaid
flowchart TD
Edit["Edit package code"] --> Command["Run platform-specific sync command"]
Command --> Test["Run tests"]
Test --> Artifact["Generate Upload/ or preview artifact"]
Artifact --> Integrity["Verify byte identity or sync status"]
Integrity --> Pass{"Integrity check passes?"}
Pass --> |Yes| Commit["Commit source and regenerated artifacts"]
Pass --> |No| Fix["Fix failing step before continuing"]
```

**Diagram sources**
- [User scripts/FI Index Change/refresh_local.py:1-20](file://User scripts/FI Index Change/refresh_local.py#L1-L20)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:1-13](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L1-L13)
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [User scripts/FI Index Change/refresh_local.py:129-158](file://User scripts/FI Index Change/refresh_local.py#L129-L158)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:100-135](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L100-L135)
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Monitoring and Logging Systems

#### Application-Level Status and Logs
Monitoring is primarily operator-facing through status words, step logs, and export receipts:

- FI Spread Movement Monitoring prints elapsed time, row count, returned columns, effective dates, change-arithmetic checks, failed fields, and local failure stages.
- FI Index Change reports missing items, partial months, weight classification notes, and approximate turnover.
- ETF Spread Monitoring reports cache usage, stored rows reused, settled rows written, and identifier identity mismatches.
- ETF Capping Monitoring uses status categories such as Breach, Near Limit, OK, and Data Issue.

```mermaid
flowchart TD
Request["BQL request completes"] --> Parse["Parse response"]
Parse --> Validate["Validate fields and shapes"]
Validate --> Status{"Status"}
Status --> |Updated| Draw["Draw tables and charts"]
Status --> |Cached| ShowCache["Show cached result with reason"]
Status --> |Incomplete| ReportFail["Report failed fields and stage"]
Status --> |Partial| WarnMonth["Warn about partial month"]
Draw --> Export["Export Excel receipt and tables"]
ShowCache --> Export
ReportFail --> Export
WarnMonth --> Export
```

**Diagram sources**
- [instruction.md:66-75](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:89-107](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:384-395](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [instruction.md:66-75](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:89-107](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:384-395](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Backup and Recovery Procedures

#### Cache Data
There are two distinct caching strategies:

- ETF Spread Monitoring caches daily history rows per `(ID, DATE)` across quotes, returns, NAVs, and flows, with a manifest tracking coverage, fingerprints, and identity tokens.
- FI Index Change caches monthly membership snapshots keyed by index and month-end, requiring identity columns but allowing some analytics to be absent.
- FI Spread Movement Monitoring caches ranked results, descriptors, and series keyed by run parameters, keeping a bounded number of runs.

```mermaid
flowchart TD
Run["Update or Refresh"] --> Strategy{"Which app?"}
Strategy --> |ETF Spread| DailyCSV["Append daily (ID, DATE) rows"]
Strategy --> |FI Index| MonthlySnapshot["Save monthly membership snapshot"]
Strategy --> |FI Spread| RunKey["Save ranked/descriptor/series by run key"]
DailyCSV --> Manifest["Write manifest.json"]
MonthlySnapshot --> Manifest
RunKey --> Manifest
Manifest --> Recover{"Recovery path"}
Recover --> |Timeout| Fallback["Load saved clean run if available"]
Recover --> |Formula change| ReRequest["Discard stale cache and re-request"]
Recover --> |Identity mismatch| FullWindow["Re-request full window for changed ID"]
```

**Diagram sources**
- [VersionLog.md:46-58](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:89-107](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/fi_index_change/config.py:122](file://User scripts/FI Index Change/fi_index_change/config.py#L122)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:350-357](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L350-L357)

**Section sources**
- [VersionLog.md:46-58](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:89-107](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/fi_index_change/config.py:122](file://User scripts/FI Index Change/fi_index_change/config.py#L122)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:350-357](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L350-L357)

#### Configuration Files
Configuration files are not backed up as secrets here; they are versioned source files. Operators should treat `config.py` modules as immutable defaults unless a dated decision authorizes a change. Desensitized outputs such as `config_redacted.py` exist only as controlled examples and must not be imported by production code.

**Section sources**
- [User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py:1-6](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py#L1-L6)
- [User scripts/ETF Capping Monitoring/etf_capping/config.py:1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)

### Operational Runbooks

#### Common Maintenance Tasks
| Task | Expected Command or Action | Success Signal |
|---|---|---|
| Verify FI Index Change local build | `python3 refresh_local.py` | Exit code 0 and preview server answers |
| Verify FI Spread Movement Monitoring mirrors | `python3 sync_upload.py --check` | `rule-sync=ok` or mirrors in sync |
| Regenerate knowledge-base bundle | `python3 "RAG KB/regenerate_kb_bundle.py"` then `--check` | `integrity=ok` |
| Run ETF Spread Monitoring tests | `python3 -m pytest tests -q` | All tests pass |
| Run ETF Capping Monitoring tests | Follow test command in its README | All tests pass |
| Open FI Spread Movement Monitoring preview | Visit `http://localhost:8775/` | Interactive page loads without stale-build banner |

**Section sources**
- [User scripts/FI Index Change/refresh_local.py:129-158](file://User scripts/FI Index Change/refresh_local.py#L129-L158)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:117-135](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L117-L135)
- [instruction.md:55-60](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

#### Troubleshooting Procedures
- If a Desktop notebook fails at import, verify that all required runtime files were copied from `Upload/` and that no `.txt` suffix remains on importable modules.
- If a request times out, read whether the failure is a timeout versus a rejected field or missing entitlement; only timeouts are retried automatically.
- If a cached screen appears after a timeout, confirm the status reads `Cached` and inspect the live error and step log.
- If a cache exists but shows stale numbers, toggle cache off for ETF Spread Monitoring or clear the affected cache entry according to the app’s contract.
- If the preview server does not answer, use the refresh command for FI Index Change or restart the launchctl service for FI Spread Movement Monitoring.

**Section sources**
- [instruction.md:66-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:89-107](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/refresh_local.py:65-78](file://User scripts/FI Index Change/refresh_local.py#L65-L78)

#### Incident Response Protocols
- Append incidents to `VersionLog.md` with a dated heading and platform tag.
- Record what changed, when, and the decision that mattered.
- Keep open ideas in `ToDoList.md` and current run steps in `instruction.md`.
- Do not rewrite existing `VersionLog.md` entries; corrections are new entries.
- Cross-platform conflicts stop for the operator; there is no automatic platform priority.

**Section sources**
- [VersionLog.md:1-10](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Cross-Platform Synchronization for Cursor, Qoder, and TRAE

#### Rule Trees and Knowledge Base
Cross-platform synchronization is enforced by:

- Running `python3 .qoder/sync_rules.py --check` to validate rule-tree drift.
- Regenerating the KB bundle when Cursor rules change.
- Treating `instruction.md`, `ToDoList.md`, and `VersionLog.md` as shared workspace documents.
- Ensuring any edit to rule files ends with a successful sync and check.

```mermaid
flowchart TD
EditRule["Edit rule file on any platform"] --> Sync["Run sync_rules.py"]
Sync --> Check["Run sync_rules.py --check"]
Check --> Drift{"Drift detected?"}
Drift --> |No| Bundle["Regenerate KB bundle if needed"]
Drift --> |Yes| Resolve["Resolve conflict manually"]
Bundle --> Done["rule-sync=ok and integrity=ok"]
Resolve --> Sync
```

**Diagram sources**
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [RAG KB/regenerate_kb_bundle.py:1-31](file://RAG KB/regenerate_kb_bundle.py#L1-L31)

**Section sources**
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [RAG KB/regenerate_kb_bundle.py:1-31](file://RAG KB/regenerate_kb_bundle.py#L1-L31)

### Capacity Planning, Resource Allocation, and Performance Monitoring

#### Request Budgets
- FI Index Change splits requests by measure family and retries timed-out month-ends up to `QUERY_ATTEMPTS`.
- FI Spread Movement Monitoring sends one-item requests except for the duration family, which groups four measures into one call.
- ETF Spread Monitoring plans gaps per identifier and re-requests only missing days when the history cache is enabled.
- ETF Capping Monitoring batches AIM accounts and security descriptors.

#### Timeouts and Retries
- Both FI Index Change and FI Spread Movement Monitoring set `QUERY_ATTEMPTS = 2`.
- Only timeouts are retried; rejected fields, missing entitlements, and bad universes are not retried.
- FI Spread Movement Monitoring falls back to a saved clean run after repeated timeouts.

#### Storage Growth
- ETF Spread Monitoring stores daily history rows; growth depends on the number of identifiers and the selected window.
- FI Index Change stores monthly snapshots; size depends on index membership and retained fields.
- FI Spread Movement Monitoring keeps a bounded number of cached runs.

**Section sources**
- [User scripts/FI Index Change/fi_index_change/config.py:88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:138-182](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L138-L182)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)
- [VersionLog.md:46-58](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Dependency Analysis
The main operational dependencies are:

- Notebook cells depend on runtime modules being present and synchronized.
- Preview pages depend on generated HTML and JavaScript checks.
- Upload mirrors depend on exact byte identity with source modules.
- Cross-platform collaboration depends on rule synchronization and KB bundle integrity.

```mermaid
graph TB
Notebook["Desktop Notebook"]
Runtime["Runtime Modules"]
Upload["Upload/ Mirrors"]
Preview["Preview Page"]
Tests["Test Suite"]
Sync["Sync Script"]
KB["Knowledge Base Bundle"]
Notebook --> Runtime
Runtime --> Upload
Tests --> Runtime
Preview --> Runtime
Sync --> Upload
KB --> Rules["Cursor/Qoder/TRAE Rules"]
```

**Diagram sources**
- [User scripts/FI Index Change/refresh_local.py:40-51](file://User scripts/FI Index Change/refresh_local.py#L40-L51)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:33-59](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L33-L59)
- [RAG KB/regenerate_kb_bundle.py:1-31](file://RAG KB/regenerate_kb_bundle.py#L1-L31)

**Section sources**
- [User scripts/FI Index Change/refresh_local.py:40-51](file://User scripts/FI Index Change/refresh_local.py#L40-L51)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:33-59](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L33-L59)
- [RAG KB/regenerate_kb_bundle.py:1-31](file://RAG KB/regenerate_kb_bundle.py#L1-L31)

## Performance Considerations
- Prefer narrow windows until measured Desktop runs prove wider ranges are acceptable.
- Monitor per-request timing in the request log rather than assuming total elapsed time.
- Avoid adding new data items unless they can be expressed as parameter values on an existing builder.
- Treat cache hits as performance relief, not correctness guarantees; always compare units and effective dates against Terminal.
- Watch cache folder growth for ETF Spread Monitoring and avoid automatic pruning tied to the active book unless explicitly authorized.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Deployment Issues
| Symptom | Likely Cause | Resolution |
|---|---|---|
| First notebook cell raises `ModuleNotFoundError` | Missing runtime module in Desktop project | Copy all required files from `Upload/` and remove `.txt` suffixes |
| Preview server does not answer | Port taken or server process died | Run `refresh_local.py` again or restart the preview service |
| Upload mirror differs from package | Source changed without running sync | Run the appropriate sync command and verify exit status |
| KB bundle rebuild reports integrity failure | Stale or inconsistent rule/KB state | Regenerate bundle and run `--check` |

**Section sources**
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/FI Index Change/refresh_local.py:129-158](file://User scripts/FI Index Change/refresh_local.py#L129-L158)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:117-135](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L117-L135)
- [RAG KB/regenerate_kb_bundle.py:1-31](file://RAG KB/regenerate_kb_bundle.py#L1-L31)

### Operational Problems
| Symptom | Likely Cause | Resolution |
|---|---|---|
| Update times out twice | Bloomberg-side latency or broad universe | Inspect request log, confirm retry behavior, and consider narrowing universe or window |
| Cached screen appears after timeout | Timeout fallback loaded saved run | Review status word `Cached`, live error, and step log |
| Cache shows stale numbers | Formula or request fingerprint changed | Toggle cache off or allow fingerprint mismatch to force re-request |
| Identifier now resolves to different security | Primary share class or peer listing moved | Confirm status detail names the identifier and allows full-window re-request |

**Section sources**
- [instruction.md:66-75](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:89-107](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:46-58](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Conclusion
This repository’s operations model is centered on disciplined notebook deployment, strict artifact synchronization, conservative caching, and explicit cross-platform governance. Successful deployments depend on following the documented copy steps, running the correct sync command, validating preview and upload artifacts, and recording decisions in `VersionLog.md`. Performance and reliability improvements should be measured on Desktop rather than assumed from local tests, and cache behavior should be treated as a safety net and speed mechanism, not a substitute for verified data contracts.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Appendix A: Quick Reference Commands
| Area | Command | Notes |
|---|---|---|
| FI Index Change local refresh | `python3 refresh_local.py` | Runs tests, preview build, preview check, preview serve, and Upload sync |
| FI Spread Movement Monitoring mirror check | `python3 sync_upload.py --check` | Reports drift and exits non-zero when out of sync |
| FI Spread Movement Monitoring mirror update | `python3 sync_upload.py` | Writes mirrors and prunes junk files |
| KB bundle regeneration | `python3 "RAG KB/regenerate_kb_bundle.py"` | Rebuilds knowledge-base artifacts |
| Rule-tree validation | `python3 .qoder/sync_rules.py --check` | Validates Cursor/Qoder/TRAE rule alignment |

**Section sources**
- [User scripts/FI Index Change/refresh_local.py:1-20](file://User scripts/FI Index Change/refresh_local.py#L1-L20)
- [User scripts/FI Spread Movement Monitoring/sync_upload.py:7-13](file://User scripts/FI Spread Movement Monitoring/sync_upload.py#L7-L13)
- [RAG KB/regenerate_kb_bundle.py:1-31](file://RAG KB/regenerate_kb_bundle.py#L1-L31)
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)