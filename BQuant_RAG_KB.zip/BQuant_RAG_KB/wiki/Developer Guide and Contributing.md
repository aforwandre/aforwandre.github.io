# Developer Guide and Contributing

<cite>
**Referenced Files in This Document**   
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [ToDoList.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [.trae/rules/00-bquant-hard-stops.md](file://rules/00-bquant-hard-stops.md)
- [.trae/rules/01-bquant-retrieval-protocol.md](file://rules/01-bquant-retrieval-protocol.md)
- [.trae/rules/95-visual-diff-gate.md](file://rules/95-visual-diff-gate.md)
- [.trae/rules/project-fi-spread-movement-monitoring.md](file://rules/project-fi-spread-movement-monitoring.md)
- [.trae/rules/project-fi-index-change.md](file://rules/project-fi-index-change.md)
- [.trae/rules/project-etf-spread-monitor.md](file://rules/project-etf-spread-monitor.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This guide documents how developers contribute to the Bloomberg BQuant platform workspace under `CURSOR_BQNT`. It covers development environment setup for Cursor, Qoder, and TRAE; code standards and conventions; contribution workflow; debugging techniques; extension guidelines; knowledge-base management; performance and memory best practices; and troubleshooting for common issues.

The workspace is a multi-platform authoring and review environment. Data execution must run only on BQuant Desktop. Local IDEs are used for design, authoring, rule maintenance, preview generation, and visual diff review. The repository contains:
- Cross-platform coordination files at the root.
- Project-specific applications under `User scripts/<Project Name>/`.
- A RAG knowledge base under `RAG KB/`.
- Platform rules under `.cursor/rules/`, `.qoder/rules/`, and `.trae/rules/`.

**Section sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [.trae/rules/00-bquant-hard-stops.md:17-23](file://rules/00-bquant-hard-stops.md#L17-L23)

## Project Structure
The workspace is organized around named applications and shared governance artifacts:

```mermaid
graph TB
Root["Repository Root"]
Instructions["instruction.md<br/>ToDoList.md<br/>VersionLog.md"]
RulesCursor[".cursor/rules/*"]
RulesQoder[".qoder/rules/*"]
RulesTrae[".trae/rules/*"]
KB["RAG KB/"]
Scripts["User scripts/<Project Name>/"]
ETFSpread["ETF Spread Monitoring"]
FIIndex["FI Index Change"]
FISpread["FI Spread Movement Monitoring"]
ETFCapping["ETF Capping Monitoring"]
MDXScan["MDX Scan"]
Root --> Instructions
Root --> RulesCursor
Root --> RulesQoder
Root --> RulesTrae
Root --> KB
Root --> Scripts
Scripts --> ETFSpread
Scripts --> FIIndex
Scripts --> FISpread
Scripts --> ETFCapping
Scripts --> MDXScan
```

Key responsibilities:
- `instruction.md` defines current operational steps and cross-platform collaboration protocol.
- `ToDoList.md` tracks open ideas and validation tasks.
- `VersionLog.md` records dated decisions and changes across platforms.
- `.trae/rules/*` and sibling rule trees define hard stops, retrieval protocol, visual diff gate, and per-project contracts.
- `RAG KB/` holds indexed knowledge, concept overlays, bundle examples, and project route cards.
- `User scripts/<Project Name>/` holds application packages, notebooks, tests, previews, and upload mirrors.

**Diagram sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [.trae/rules/00-bquant-hard-stops.md:17-45](file://rules/00-bquant-hard-stops.md#L17-L45)

**Section sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [ToDoList.md:1-8](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:1-12](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Core Components
The core contributor components are:

| Component | Purpose | Authoring Scope | Execution Scope |
|---|---|---|---|
| Cross-platform coordination files | Shared procedure, task tracking, and decision history | Repository root | All platforms read the same copy |
| Rule trees | Hard stops, retrieval protocol, visual diff gate, per-project contracts | `.cursor/rules/`, `.qoder/rules/`, `.trae/rules/` | IDEs enforce rules during authoring and review |
| RAG knowledge base | Official corpus, concept index, bundle examples, project routes | `RAG KB/` | Reference only; generated bundles may be rebuilt |
| Application packages | Named BQuant apps with data, engine, charts, cache, app, and notebook | `User scripts/<Project Name>/` | Notebook runs on BQuant Desktop |
| Preview and upload mirrors | Static page build and Desktop-ready package mirror | Per project | Generated by local scripts |

Development rules emphasize:
- Never execute BQL or Bloomberg requests locally.
- Keep user code under `User scripts/<Project Name>/`.
- Default to documented libraries such as `bql`, pandas, Plotly, ipywidgets, `ipydatagrid`, and Portfolio Library where supported.
- Keep requests narrow and batched because Desktop has download limits, a two-minute request timeout, concurrency limits, one running instance per project, and a 256 MB file limit.

**Section sources**
- [.trae/rules/00-bquant-hard-stops.md:17-45](file://rules/00-bquant-hard-stops.md#L17-L45)
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Architecture Overview
The contributor architecture separates authoring from execution:

```mermaid
graph TB
Dev["Developer"]
IDE["IDE<br/>Cursor / Qoder / TRAE"]
Rules["Rules<br/>Hard Stops + Retrieval + Visual Diff + Project Rules"]
KB["RAG Knowledge Base"]
Code["Application Code<br/>User scripts/<Project Name>/"]
Preview["Preview Build<br/>interface.html"]
Upload["Upload Mirror<br/>Desktop runtime files"]
Desktop["BQuant Desktop<br/>Notebook Runtime"]
BQL["Bloomberg BQL"]
Dev --> IDE
IDE --> Rules
IDE --> KB
IDE --> Code
Code --> Preview
Code --> Upload
Desktop --> Code
Desktop --> BQL
```

- IDEs enforce hard stops and retrieval protocol while editing.
- Visual diff review applies all planned edits first, then presents them for acceptance or rejection.
- Preview builds render static pages for layout checks without sending requests.
- Upload mirrors contain the Desktop runtime package.
- Desktop executes notebooks against Bloomberg BQL.

**Diagram sources**
- [.trae/rules/00-bquant-hard-stops.md:17-45](file://rules/00-bquant-hard-stops.md#L17-L45)
- [.trae/rules/95-visual-diff-gate.md:1-27](file://rules/95-visual-diff-gate.md#L1-L27)
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Detailed Component Analysis

### Development Environment Setup

#### Cursor
- Use Cursor for design, authoring, and review.
- Follow the three-sided visual diff gate: apply all edits in one pass, then review each changed file or hunk before accepting.
- After any rule change, run the sync script and confirm `rule-sync=ok`.
- If a Cursor rule changed, regenerate the RAG KB bundle before trusting the check output.

#### Qoder
- Use Qoder as an equal platform; there is no platform priority.
- Confirm that project rules attach correctly on first use.
- Run the sync script after rule changes and verify artifact counts.
- Treat the root `.qoderignore` as the indexing boundary for Qoder.

#### TRAE
- Use TRAE as an equal platform; it mirrors rule bodies byte-for-byte from the source rule tree.
- Confirm that TRAE shows the expected number of project rules.
- TRAE has no index-exclusion file mechanism in this workspace; exclusions rely on `.gitignore` and the documented boundaries.

#### Common Setup Rules
- Chat in Traditional Chinese when required by workspace policy, but write code, comments, and knowledge markdown in English.
- Do not install packages from this workspace.
- Do not run a second concurrent instance of the same project.
- Read `VersionLog.md`, `ToDoList.md`, and `instruction.md` before continuing work.

**Section sources**
- [.trae/rules/95-visual-diff-gate.md:1-27](file://rules/95-visual-diff-gate.md#L1-L27)
- [instruction.md:78-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [ToDoList.md:24-29](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Code Standards and Conventions

#### Naming Conventions
- Use descriptive labels for UI controls and short labels for table/export headers.
- Keep canonical frame column names separate from display-only headings.
- Preserve Bloomberg security identifiers rather than replacing them with derived names.
- Spread types, duration parameters, and yield parameters follow frozen value strings documented in the relevant project rule and knowledge base.

#### Documentation Standards
- Record decisions in `VersionLog.md` with a dated entry and platform tag.
- Keep unfinished ideas in `ToDoList.md` without rewriting existing rows unless status changes.
- Update `instruction.md` by replacing the affected step rather than appending obsolete text.
- Do not hand-edit generated artifacts such as `preview/interface.html` or `Upload/`.

#### Code Organization Principles
- Each named application lives under `User scripts/<Project Name>/`.
- Packages typically include configuration, data access, engine logic, charting, caching, and app wiring.
- Tests live under a project-local `tests/` directory.
- Preview builds and upload mirrors are generated and kept in sync by local scripts.

**Section sources**
- [.trae/rules/project-fi-spread-movement-monitoring.md:40-43](file://rules/project-fi-spread-movement-monitoring.md#L40-L43)
- [.trae/rules/project-fi-index-change.md:206-216](file://rules/project-fi-index-change.md#L206-L216)
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Contribution Workflow

#### Branch Management
- The repository currently has no commit history recorded in this workspace snapshot.
- Treat the workspace as a single working area until formal branching policy is introduced.
- Avoid parallel work by the same operator on the same project.

#### Pull Request Procedures
- There is no explicit pull request process defined in the referenced files.
- Contributions should still follow the visual diff gate: complete all planned edits, then present the full changeset for review.
- Any rule-file change must end with the sync script reporting `rule-sync=ok`.

#### Code Review Process
- Apply all edits first in one pass.
- Review each changed file, hunk, or line independently.
- Accept or reject per checkpoint, or Accept All / Reject All.
- Derived artifacts form a second batch: show sync dry-run output, run sync after source changes are accepted, and review the generated artifacts.

```mermaid
flowchart TD
Start["Start Task"] --> Plan["Plan All Edits"]
Plan --> Apply["Apply All Edits in One Pass"]
Apply --> Review["Review Changed Files and Hunks"]
Review --> Decision{"Accept or Reject?"}
Decision --> |Reject| Revise["Revise Rejected Checkpoint"]
Revise --> Review
Decision --> |Accept| Sync["Run Sync Script"]
Sync --> Check{"rule-sync=ok?"}
Check --> |No| FixSync["Fix Drift or Conflict"]
FixSync --> Sync
Check --> |Yes| Done["Task Complete"]
```

**Diagram sources**
- [.trae/rules/95-visual-diff-gate.md:1-27](file://rules/95-visual-diff-gate.md#L1-L27)

**Section sources**
- [ToDoList.md:8-8](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [.trae/rules/95-visual-diff-gate.md:1-27](file://rules/95-visual-diff-gate.md#L1-L27)
- [instruction.md:93-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Debugging Techniques and Tools

#### Logging and Status
- Read the step log and status banner before trusting results.
- Errors and notes print in the status area; items that did not parse are named together with the columns actually returned.
- Failure banners name the local stage, file, line, and function when available.

#### Request Diagnostics
- Record request count, timing, units, effective dates, and coverage.
- For timeout investigation, probe request breadth by sending incremental groups and measuring elapsed time.
- Distinguish between timeouts, rejected fields, missing entitlements, and local reshape failures.

#### Cache Inspection
- For ETF Spread Monitoring, inspect `cache/quotes.csv`, `returns.csv`, `navs.csv`, `flows.csv`, and `manifest.json`.
- For FI Spread Movement Monitoring, inspect cached ranked tables, descriptors, series, and manifest entries keyed by run metadata.
- A read-only project folder can cause cache writes to fail silently; the refresh should still complete but without persisting new rows.

#### Preview Validation
- Open the preview page directly or through the local server.
- Reload with a forced refresh if the page was rendered by older code.
- Compare the page build id with the current server build id when stale behavior appears.

**Section sources**
- [instruction.md:31-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:55-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Extending Modules and Adding Features

#### Extension Guidelines
- Add new functionality under `User scripts/<Project Name>/`.
- Freeze Request shapes, date rules, universes, and field usage in the corresponding project rule and knowledge-base route card.
- Prefer parameter forms over adding new data items when the catalog exposes a builder with multiple values.
- Keep display-only columns separate from filtering, ranking, and chart logic.

#### Backward Compatibility
- Do not introduce manual parser version constants until the first Desktop pull is frozen and the bundle registry has a reviewed row.
- Invalidate caches when the stored contract changes, such as when item lists, column sets, or request builders change.
- Preserve canonical column names internally even when display headings are renamed for export or rendering.

#### Example Extension Pattern
```mermaid
flowchart TD
Idea["New Feature Idea"] --> RuleCheck["Check Project Rule and RAG Route Card"]
RuleCheck --> Contract["Define Frozen Contract<br/>Request Shape, Fields, Dates"]
Contract --> Implementation["Implement config → data → engine → app"]
Implementation --> Tests["Add Unit and Wiring Tests"]
Tests --> Preview["Regenerate Preview"]
Preview --> Upload["Sync Upload Mirror"]
Upload --> DesktopValidation["Validate on BQuant Desktop"]
DesktopValidation --> Record["Record Evidence in VersionLog and Decision Records"]
```

**Diagram sources**
- [.trae/rules/project-fi-spread-movement-monitoring.md:96-113](file://rules/project-fi-spread-movement-monitoring.md#L96-L113)
- [.trae/rules/project-fi-index-change.md:243-252](file://rules/project-fi-index-change.md#L243-L252)

**Section sources**
- [instruction.md:11-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [.trae/rules/project-fi-spread-movement-monitoring.md:96-113](file://rules/project-fi-spread-movement-monitoring.md#L96-L113)
- [.trae/rules/project-etf-spread-monitor.md:206-207](file://rules/project-etf-spread-monitor.md#L206-L207)

### Knowledge Base Management and Documentation Updates

#### Knowledge Base Responsibilities
- The RAG KB is the authority for BQuant facts when it conflicts with assistant replies.
- New tokens require a curated entry in the concept index overlay and a reviewed bundle update.
- Generated files such as `BQUANT_RAG_KNOWLEDGE_BASE.md`, `CONCEPT_INDEX.md`, `CONCEPT_INDEX.json`, `BUNDLE_EXAMPLES.md`, and `BUNDLE_EXAMPLES.json` are derived from source documents.

#### Update Procedure
- Edit source markdown under `RAG KB/`.
- Regenerate the bundle using `python3 "RAG KB/regenerate_kb_bundle.py"`.
- Verify integrity with `--check`.
- Do not treat generated files as primary policy; trace changes back to their source documents.

```mermaid
sequenceDiagram
participant Dev as "Developer"
participant Source as "RAG KB Source"
participant Builder as "regenerate_kb_bundle.py"
participant Bundle as "Generated Bundle"
participant Check as "--check"
Dev->>Source : Edit source document
Dev->>Builder : Run bundle regeneration
Builder->>Bundle : Rebuild knowledge base and index
Dev->>Check : Run integrity check
Check-->>Dev : Report integrity status
```

**Diagram sources**
- [VersionLog.md:1-12](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:84-90](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [VersionLog.md:1-12](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:84-90](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Performance Optimization and Memory Management

#### Request Budget
- Keep requests narrow and batched.
- Split heavy analytics into measure families when a single wide request times out.
- For FI Index Change, the proven split uses identity columns, spreads/yields, and durations as separate groups.
- For FI Spread Movement Monitoring, the duration family replaces the original single-duration request so extra columns do not increase the call count.

#### Timeout Protection
- Retry timed-out requests once with identical parameters.
- Do not retry deterministic failures such as rejected fields or missing entitlements.
- Serve clean cached runs only when every recorded failure is a timeout and no field failed.

#### Memory and File Limits
- Respect the 256 MB file limit.
- Use CSV-based caches rather than introducing parquet or external dependencies.
- Bound cached runs and prune by monotonic sequence numbers, not manifest key order.

#### Data Processing Best Practices
- Compute derived metrics such as spread percent, return percent, and flow scaling after merging raw request outputs.
- Avoid zero-filling missing spreads or interpolating unknown values.
- Validate arithmetic such as `Change = End - Start` and report mismatches.

**Section sources**
- [.trae/rules/00-bquant-hard-stops.md:43-45](file://rules/00-bquant-hard-stops.md#L43-L45)
- [.trae/rules/project-fi-spread-movement-monitoring.md:15-28](file://rules/project-fi-spread-movement-monitoring.md#L15-L28)
- [.trae/rules/project-fi-index-change.md:49-58](file://rules/project-fi-index-change.md#L49-L58)
- [.trae/rules/project-fi-index-change.md:249-252](file://rules/project-fi-index-change.md#L249-L252)

### Troubleshooting Guide

#### Environment Setup Problems
- **Rule mismatch:** Run the sync script and inspect drift output.
- **Stale preview:** Force reload the browser or restart the preview server.
- **Missing module on Desktop:** Copy the full package list from `Upload/`; do not omit modules imported at module load.
- **Read-only project folder:** Cache writes may be skipped; the refresh can still complete without persisting new data.

#### Data Request Problems
- **Timeout:** Measure request breadth, reduce analytics width, and rely on timeout retry plus cached fallback.
- **Rejected field:** Inspect the refusal message; do not retry deterministically.
- **Missing entitlement:** Stop and obtain HelpDesk confirmation before changing the field.
- **Empty result:** Confirm the ticker resolves and the date window is valid; a weekend end date is refused before building the request.

#### Rendering and Export Problems
- **Blank chart:** Ensure the figure container is mutated in place rather than replaced wholesale on some Desktop Plotly versions.
- **Truncated header:** Fit column widths to headers and content; avoid narrow default grid sizing.
- **Excel paste loses header:** Use the exported format that repeats column names as the first data row.

#### Cross-Platform Conflicts
- No platform is primary; conflicts stop for the operator.
- Append to `VersionLog.md`; never rewrite, delete, or reorder existing entries.
- Replace the affected step in `instruction.md` instead of appending outdated instructions.

**Section sources**
- [instruction.md:27-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:55-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:449-469](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Dependency Analysis
The contributor dependency graph connects rules, knowledge, code, preview, upload, and Desktop execution:

```mermaid
graph LR
Rules["Project Rules"] --> KB["RAG KB"]
Rules --> Code["Application Code"]
KB --> Code
Code --> Preview["Preview Build"]
Code --> Upload["Upload Mirror"]
Preview --> Desktop["BQuant Desktop"]
Upload --> Desktop
Desktop --> BQL["Bloomberg BQL"]
```

- Rules constrain retrieval, request shape, and review behavior.
- The knowledge base provides official usage patterns and frozen contracts.
- Application code depends on both rules and knowledge.
- Preview and upload are derived from application code.
- Desktop depends on the final package and executes against Bloomberg BQL.

**Diagram sources**
- [.trae/rules/01-bquant-retrieval-protocol.md:1-34](file://rules/01-bquant-retrieval-protocol.md#L1-L34)
- [.trae/rules/00-bquant-hard-stops.md:17-45](file://rules/00-bquant-hard-stops.md#L17-L45)

**Section sources**
- [.trae/rules/01-bquant-retrieval-protocol.md:1-34](file://rules/01-bquant-retrieval-protocol.md#L1-L34)
- [.trae/rules/00-bquant-hard-stops.md:17-45](file://rules/00-bquant-hard-stops.md#L17-L45)

## Performance Considerations
- Prefer bounded candidate universes for descriptor and series requests.
- Group related measures into one request when the API supports parameterized builders.
- Avoid widening windows, adding heavy swap-curve measures, or restoring deprecated duration functions without measured evidence.
- Record per-request elapsed time and attempt count so timeout margins are known rather than assumed.
- Keep cache size reasonable and bound retained runs.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Use this checklist when development or Desktop runs fail:

1. Confirm the correct platform is executing the task.
2. Read the latest `VersionLog.md` entries.
3. Confirm the sync script reports `rule-sync=ok`.
4. Check whether the failure is local (reshape, preview, cache) or remote (BQL refusal, timeout, entitlement).
5. Inspect the step log, status banner, and request log.
6. Validate tickers, universes, spread types, and date windows.
7. Reproduce locally with synthetic data where possible.
8. Validate on BQuant Desktop with the exact Desktop kernel and environment.
9. Record timing, rows, units, effective dates, and coverage.
10. Update `VersionLog.md`, `ToDoList.md`, and `instruction.md` according to their respective rules.

**Section sources**
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [ToDoList.md:10-23](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Conclusion
Contributors should treat this workspace as a disciplined, multi-platform authoring environment with strict separation between local IDE work and BQuant Desktop execution. Follow the hard stops, retrieve from the correct knowledge-base route, freeze Request shapes, keep requests narrow, validate on Desktop, and record evidence. The visual diff gate, sync scripts, and generated artifacts ensure consistency across Cursor, Qoder, and TRAE.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Quick Reference: Named Applications
| Application | Primary Rule File | Key Operational Notes |
|---|---|---|
| ETF Capping Monitoring | `.trae/rules/project-etf-capping-monitor.md` | Copy project folder on Desktop; request starts only on Update. |
| ETF Spread Monitoring | `.trae/rules/project-etf-spread-monitor.md` | History cache, identity binding, and per-identifier coverage. |
| FI Index Change | `.trae/rules/project-fi-index-change.md` | Membership diff, split request, pinned detail column, approximate turnover. |
| FI Spread Movement Monitoring | `.trae/rules/project-fi-spread-movement-monitoring.md` | Timeout protection, cached fallback, display Top N, duration reference columns. |
| MDX Scan | `.trae/rules/project-mdx-scan.md` | Separate notebook; do not merge into other projects. |

**Section sources**
- [instruction.md:13-23](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [.trae/rules/project-etf-spread-monitor.md:1-10](file://rules/project-etf-spread-monitor.md#L1-L10)
- [.trae/rules/project-fi-index-change.md:1-14](file://rules/project-fi-index-change.md#L1-L14)
- [.trae/rules/project-fi-spread-movement-monitoring.md:1-14](file://rules/project-fi-spread-movement-monitoring.md#L1-L14)