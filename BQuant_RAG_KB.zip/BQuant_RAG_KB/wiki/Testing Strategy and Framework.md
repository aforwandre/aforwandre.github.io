# Testing Strategy and Framework

<cite>
**Referenced Files in This Document**
- [conftest.py](file://User scripts/FI Index Change/tests/conftest.py)
- [widget_stubs.py](file://User scripts/FI Index Change/tests/widget_stubs.py)
- [test_engine.py (ETF Capping Monitoring)](file://User scripts/ETF Capping Monitoring/tests/test_engine.py)
- [test_engine.py (ETF Spread Monitoring)](file://User scripts/ETF Spread Monitoring/tests/test_engine.py)
- [test_cache.py (ETF Spread Monitoring)](file://User scripts/ETF Spread Monitoring/tests/test_cache.py)
- [test_app_contract.py (FI Index Change)](file://User scripts/FI Index Change/tests/test_app_contract.py)
- [test_app_runtime.py (FI Index Change)](file://User scripts/FI Index Change/tests/test_app_runtime.py)
- [test_data_request.py (FI Index Change)](file://User scripts/FI Index Change/tests/test_data_request.py)
- [test_engine.py (FI Index Change)](file://User scripts/FI Index Change/tests/test_engine.py)
- [test_data.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/tests/test_data.py)
- [test_cache.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py)
- [test_engine.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py)
- [data.py (FI Index Change)](file://User scripts/FI Index Change/fi_index_change/data.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the testing strategy and framework used across the project’s modules. The suite is built around Python’s `unittest` framework, with tests organized per feature module under dedicated `tests/` directories. External dependencies such as Bloomberg BQL and interactive widgets are isolated through synthetic data, fake services, and widget stubs so that tests run reliably without live API calls or a full desktop environment.

The testing approach covers:
- Unit testing of pure business logic using pandas frames.
- Contract and runtime validation for interactive applications.
- Mocked integration tests for Bloomberg BQL interactions.
- Synthetic data generation and local cache-based test fixtures.
- Performance-oriented checks for query shape, request semantics, and data processing efficiency.
- Guidelines for writing new tests and maintaining coverage.

## Project Structure
Each user script has its own application code and a sibling `tests/` directory. Tests follow these patterns:
- One test file per major component or concern.
- Local helpers to build synthetic pandas DataFrames.
- Fake or stubbed external systems, including BQL and widgets.
- Temporary directories for cache and file-backed behavior.

```mermaid
graph TB
subgraph "ETF Capping Monitoring"
ECF["etf_capping"]
ECFT["tests/test_engine.py"]
end
subgraph "ETF Spread Monitoring"
ESM["etf_spread"]
ESMT["tests/test_engine.py"]
ESMTc["tests/test_cache.py"]
end
subgraph "FI Index Change"
FIC["fi_index_change"]
FICT["tests/test_engine.py"]
FICTa["tests/test_app_contract.py"]
FICTr["tests/test_app_runtime.py"]
FICTd["tests/test_data_request.py"]
FICC["tests/conftest.py"]
FICS["tests/widget_stubs.py"]
end
subgraph "FI Spread Movement Monitoring"
FSM["fi_spread_movement"]
FSMT["tests/test_engine.py"]
FSMTd["tests/test_data.py"]
FSMTc["tests/test_cache.py"]
end
ECFT --> ECF
ESMT --> ESM
ESMTc --> ESM
FICT --> FIC
FICTa --> FIC
FICTr --> FIC
FICTd --> FIC
FICC --> FICS
FSMT --> FSM
FSMTd --> FSM
FSMTc --> FSM
```

**Diagram sources**
- [test_engine.py (ETF Capping Monitoring):1-40](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1-L40)
- [test_engine.py (ETF Spread Monitoring):1-37](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L1-L37)
- [test_cache.py (ETF Spread Monitoring):1-19](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L1-L19)
- [test_engine.py (FI Index Change):1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)
- [test_app_contract.py (FI Index Change):1-15](file://User scripts/FI Index Change/tests/test_app_contract.py#L1-L15)
- [test_app_runtime.py (FI Index Change):1-32](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L32)
- [test_data_request.py (FI Index Change):1-24](file://User scripts/FI Index Change/tests/test_data_request.py#L1-L24)
- [conftest.py (FI Index Change):1-22](file://User scripts/FI Index Change/tests/conftest.py#L1-L22)
- [widget_stubs.py (FI Index Change):1-108](file://User scripts/FI Index Change/tests/widget_stubs.py#L1-L108)
- [test_engine.py (FI Spread Movement Monitoring):1-38](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py#L1-L38)
- [test_data.py (FI Spread Movement Monitoring):1-20](file://User scripts/FI Spread Movement Monitoring/tests/test_data.py#L1-L20)
- [test_cache.py (FI Spread Movement Monitoring):1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)

**Section sources**
- [test_engine.py (ETF Capping Monitoring):1-40](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1-L40)
- [test_engine.py (ETF Spread Monitoring):1-37](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L1-L37)
- [test_engine.py (FI Index Change):1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)
- [test_app_contract.py (FI Index Change):1-15](file://User scripts/FI Index Change/tests/test_app_contract.py#L1-L15)
- [test_app_runtime.py (FI Index Change):1-32](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L32)
- [test_data_request.py (FI Index Change):1-24](file://User scripts/FI Index Change/tests/test_data_request.py#L1-L24)
- [conftest.py (FI Index Change):1-22](file://User scripts/FI Index Change/tests/conftest.py#L1-L22)
- [widget_stubs.py (FI Index Change):1-108](file://User scripts/FI Index Change/tests/widget_stubs.py#L1-L108)
- [test_engine.py (FI Spread Movement Monitoring):1-38](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py#L1-L38)
- [test_data.py (FI Spread Movement Monitoring):1-20](file://User scripts/FI Spread Movement Monitoring/tests/test_data.py#L1-L20)
- [test_cache.py (FI Spread Movement Monitoring):1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)

## Core Components
The testing framework centers on several reusable components:

- **Unit test base**: All tests inherit from `unittest.TestCase`.
- **Synthetic data helpers**: Small functions create pandas DataFrames representing positions, observations, members, quotes, and spreads.
- **Fake BQL service**: Lightweight classes simulate `bql.Service`, requests, responses, and execution pipelines without calling Bloomberg.
- **Widget stubs**: A shared installer provides permissive stand-ins for `plotly`, `ipywidgets`, and related objects so app lifecycle tests can import real UI code safely.
- **Temporary filesystem fixtures**: Tests use `tempfile.TemporaryDirectory` to validate cache contracts, gap planning, merge rules, and identity handling.
- **Contract assertions**: Some tests inspect source code to enforce UI contract requirements such as event binding order, tab layout, and footnote dynamics.

Key responsibilities:
- Validate pure computation paths with deterministic inputs.
- Verify external interaction contracts by capturing mock calls.
- Ensure cache behavior matches operator requirements.
- Guard against regressions in UI wiring and display formatting.

**Section sources**
- [test_engine.py (ETF Capping Monitoring):103-177](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L103-L177)
- [test_engine.py (ETF Spread Monitoring):48-104](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L48-L104)
- [test_cache.py (ETF Spread Monitoring):34-136](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L136)
- [test_app_contract.py (FI Index Change):25-60](file://User scripts/FI Index Change/tests/test_app_contract.py#L25-L60)
- [test_app_runtime.py (FI Index Change):1-32](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L32)
- [test_data_request.py (FI Index Change):30-52](file://User scripts/FI Index Change/tests/test_data_request.py#L30-L52)
- [widget_stubs.py (FI Index Change):18-108](file://User scripts/FI Index Change/tests/widget_stubs.py#L18-L108)

## Architecture Overview
The testing architecture isolates three layers:

1. **Business logic layer**: Pure pandas transformations, classification, aggregation, bucketing, and summary calculations.
2. **Integration layer**: BQL request construction, response normalization, caching, and data merging.
3. **UI/application layer**: Interactive app construction, widget wiring, rendering, and status updates.

Tests target each layer independently:
- Business logic tests assert output frames and metrics.
- Integration tests assert request shapes, error propagation, and cache behavior.
- UI tests assert contract and runtime behavior without requiring a live desktop.

```mermaid
graph TB
UT["Unit Tests<br/>pandas-only logic"]
IT["Integration Tests<br/>Mocked BQL + Cache"]
UIT["UI Tests<br/>Widget Stubs + Runtime"]
SRC["Source Modules<br/>engine / data / cache / app"]
UT --> SRC
IT --> SRC
UIT --> SRC
IT --> UT
UIT --> IT
```

**Diagram sources**
- [test_engine.py (ETF Capping Monitoring):1-40](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1-L40)
- [test_engine.py (ETF Spread Monitoring):1-37](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L1-L37)
- [test_cache.py (ETF Spread Monitoring):1-19](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L1-L19)
- [test_app_contract.py (FI Index Change):1-15](file://User scripts/FI Index Change/tests/test_app_contract.py#L1-L15)
- [test_app_runtime.py (FI Index Change):1-32](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L32)
- [test_data_request.py (FI Index Change):1-24](file://User scripts/FI Index Change/tests/test_data_request.py#L1-L24)

## Detailed Component Analysis

### ETF Capping Monitoring Test Suite
The capping engine tests focus on pure-Pandas logic. They avoid BQL entirely and instead construct small position frames, runbook configurations, and exception overrides to verify:
- Asset classification rules.
- Primary FM propagation through positions and groups.
- Monitor grid column ordering.
- Zero-price market status handling.
- Currency code extraction.
- Fundamental ticker mapping and company aggregation.
- Ranking and dynamic limit calculation.
- Warning thresholds and alert selection.
- Exception override priority and case-insensitive matching.
- Missing fundamental ticker fallback.
- Missing price marking account incomplete.
- Special status price preservation.

```mermaid
flowchart TD
Start(["Test Entry"]) --> BuildData["Build Synthetic Positions and Runbook"]
BuildData --> EngineCall["Call calculate_monitor(...)"]
EngineCall --> Assertions{"Assertions"}
Assertions --> |Classification| ClassCheck["Verify asset type mapping"]
Assertions --> |Aggregation| GroupCheck["Verify group weights and listing counts"]
Assertions --> |Ranking| RankCheck["Verify rank and dynamic limits"]
Assertions --> |Alerts| AlertCheck["Verify alerts and data issues"]
Assertions --> |Display| DisplayCheck["Verify grid and display columns"]
ClassCheck --> End(["Test Exit"])
GroupCheck --> End
RankCheck --> End
AlertCheck --> End
DisplayCheck --> End
```

**Diagram sources**
- [test_engine.py (ETF Capping Monitoring):103-177](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L103-L177)
- [test_engine.py (ETF Capping Monitoring):214-317](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L214-L317)
- [test_engine.py (ETF Capping Monitoring):319-393](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L393)
- [test_engine.py (ETF Capping Monitoring):393-503](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L393-L503)
- [test_engine.py (ETF Capping Monitoring):534-657](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L534-L657)
- [test_engine.py (ETF Capping Monitoring):659-799](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L659-L799)

**Section sources**
- [test_engine.py (ETF Capping Monitoring):1-40](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1-L40)
- [test_engine.py (ETF Capping Monitoring):103-177](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L103-L177)
- [test_engine.py (ETF Capping Monitoring):214-317](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L214-L317)
- [test_engine.py (ETF Capping Monitoring):319-393](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L393)
- [test_engine.py (ETF Capping Monitoring):393-503](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L393-L503)
- [test_engine.py (ETF Capping Monitoring):534-657](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L534-L657)
- [test_engine.py (ETF Capping Monitoring):659-799](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L659-L799)

### ETF Spread Monitoring Test Suite
The spread monitoring tests cover both engine logic and daily history cache behavior. Key areas include:
- Placeholder spread payload retrieval and repeat-fetch consistency.
- Disabled share class filtering.
- As-of date adjustment for weekends.
- Quote guard behavior for crossed, non-numeric, missing, and duplicate rows.
- Period view construction and window constraints.
- Peer visibility toggling.
- Package boundary checks ensuring only allowed BQL items and universes are requested.
- Representative seed selection and company ID extraction.
- BQL unavailability handling.
- Request fingerprint stability and token scoping.
- Gap planning and warm/cold cache runs.

```mermaid
sequenceDiagram
participant Test as "SpreadCacheTests"
participant Cache as "etf_spread.cache"
participant Data as "etf_spread.data"
participant BQL as "Fake BQL Service"
Test->>Cache : save("quotes", frame, as_of, root)
Cache-->>Test : written count
Test->>Cache : read_series("quotes", root)
Cache-->>Test : stored frame
Test->>Data : fetch_parallel_histories(...)
Data->>BQL : execute waves with gap windows
BQL-->>Data : fake responses
Data-->>Test : merged observations
Note over Test,BQL : No live Bloomberg call; behavior validated via mocks and temp files
```

**Diagram sources**
- [test_cache.py (ETF Spread Monitoring):34-136](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L136)
- [test_cache.py (ETF Spread Monitoring):547-611](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L547-L611)
- [test_cache.py (ETF Spread Monitoring):632-686](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L632-L686)
- [test_engine.py (ETF Spread Monitoring):48-104](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L48-L104)

**Section sources**
- [test_engine.py (ETF Spread Monitoring):1-37](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L1-L37)
- [test_engine.py (ETF Spread Monitoring):48-104](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L48-L104)
- [test_engine.py (ETF Spread Monitoring):106-207](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L106-L207)
- [test_engine.py (ETF Spread Monitoring):209-270](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L209-L270)
- [test_engine.py (ETF Spread Monitoring):272-338](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L272-L338)
- [test_engine.py (ETF Spread Monitoring):340-432](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L340-L432)
- [test_cache.py (ETF Spread Monitoring):34-136](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L136)
- [test_cache.py (ETF Spread Monitoring):138-260](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L138-L260)
- [test_cache.py (ETF Spread Monitoring):263-382](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L263-L382)
- [test_cache.py (ETF Spread Monitoring):384-481](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L384-L481)
- [test_cache.py (ETF Spread Monitoring):484-611](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L484-L611)
- [test_cache.py (ETF Spread Monitoring):632-800](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L632-L800)

### FI Index Change Test Suite
The FI Index Change suite validates scheduling, configuration, chart ordering, diff logic, metric computation, export formatting, grid display, parser behavior, and app contracts. It also includes runtime tests that install widget stubs and exercise the app controller lifecycle.

Highlights:
- Schedule defaults and month-end choices.
- Configuration constants and chart width caps.
- Footnote captions and terminology.
- Signed change ordering and bucket chart row generation.
- Member diffs, book separation, fraction weight scaling.
- OAS sentinel exclusion and rating/tenor buckets.
- Snapshot label alignment.
- Summary and headline construction.
- Export table header repetition and percent formatting.
- Grid frame column filtering and NaT handling.
- Parser robustness for unnamed indices and multi-column ratings.
- Static contract checks for UI wiring and tabs.
- Widget-stubbed runtime tests for successful and failed updates.

```mermaid
classDiagram
class ScheduleTests {
+test_october_22_defaults_to_the_open_month()
+test_locked_month_defaults_to_itself_and_offers_next()
+test_sunday_month_end_rolls_back()
+test_index_yellow_key_and_unknown_date()
}
class ConfigTests {
+test_default_book_is_all()
+test_chart_width_stops_at_eighty_percent_of_fhd()
+test_no_manual_version_stamp()
}
class DiffTests {
+test_add_and_exit_on_id()
+test_country_change_is_not_an_add()
+test_empty_side_is_unavailable()
+test_tba_is_separated()
+test_same_book_ignores_another_book()
+test_fraction_weights_scale_once()
}
class MetricTests {
+test_oas_sentinel_is_excluded_and_zero_coupon_stays()
+test_rating_buckets()
+test_tenor_buckets()
+test_mbs_missing_tenor_is_not_applicable()
+test_alignment_latest_value_wins_when_both_present()
+test_alignment_fills_missing_latest_from_previous()
+test_alignment_keeps_latest_not_applicable_label()
+test_summary_before_after()
+test_summary_orders_by_add_plus_exit_weight()
+test_summary_carries_all_three_spread_blocks()
+test_turnover_uses_index_mv_ratio()
+test_turnover_falls_back_without_index_mv()
}
class ExportTableTests {
+test_first_data_row_repeats_the_header()
+test_weight_is_printed_as_a_percent_without_rounding()
+test_other_numeric_columns_keep_no_percent_sign()
+test_weight_sits_after_sector_in_both_copy_tables()
+test_empty_frame_still_has_the_header_row()
+test_frame_with_none_of_the_columns_keeps_the_header_instead_of_raising()
}
class GridFrameTests {
+test_grid_frame_keeps_only_requested_columns()
+test_grid_frame_turns_nat_and_timestamps_into_text()
+test_grid_frame_handles_empty_and_missing_columns()
}
class ParserTests {
+test_unnamed_security_index_becomes_id()
+test_row_number_index_is_not_an_id()
+test_multi_column_rating_uses_the_base_rating_field()
+test_multi_column_rating_reaches_ig_and_hy_buckets()
+test_a_two_column_item_without_a_mapping_stays_empty()
}
ScheduleTests <|-- FIIndexChangeEngineTests
ConfigTests <|-- FIIndexChangeEngineTests
DiffTests <|-- FIIndexChangeEngineTests
MetricTests <|-- FIIndexChangeEngineTests
ExportTableTests <|-- FIIndexChangeEngineTests
GridFrameTests <|-- FIIndexChangeEngineTests
ParserTests <|-- FIIndexChangeEngineTests
```

**Diagram sources**
- [test_engine.py (FI Index Change):70-106](file://User scripts/FI Index Change/tests/test_engine.py#L70-L106)
- [test_engine.py (FI Index Change):108-145](file://User scripts/FI Index Change/tests/test_engine.py#L108-L145)
- [test_engine.py (FI Index Change):177-255](file://User scripts/FI Index Change/tests/test_engine.py#L177-L255)
- [test_engine.py (FI Index Change):264-330](file://User scripts/FI Index Change/tests/test_engine.py#L264-L330)
- [test_engine.py (FI Index Change):332-602](file://User scripts/FI Index Change/tests/test_engine.py#L332-L602)
- [test_engine.py (FI Index Change):604-627](file://User scripts/FI Index Change/tests/test_engine.py#L604-L627)
- [test_engine.py (FI Index Change):629-640](file://User scripts/FI Index Change/tests/test_engine.py#L629-L640)
- [test_engine.py (FI Index Change):643-690](file://User scripts/FI Index Change/tests/test_engine.py#L643-L690)
- [test_engine.py (FI Index Change):692-721](file://User scripts/FI Index Change/tests/test_engine.py#L692-L721)
- [test_engine.py (FI Index Change):723-800](file://User scripts/FI Index Change/tests/test_engine.py#L723-L800)

**Section sources**
- [test_engine.py (FI Index Change):1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)
- [test_engine.py (FI Index Change):70-106](file://User scripts/FI Index Change/tests/test_engine.py#L70-L106)
- [test_engine.py (FI Index Change):108-145](file://User scripts/FI Index Change/tests/test_engine.py#L108-L145)
- [test_engine.py (FI Index Change):177-255](file://User scripts/FI Index Change/tests/test_engine.py#L177-L255)
- [test_engine.py (FI Index Change):264-330](file://User scripts/FI Index Change/tests/test_engine.py#L264-L330)
- [test_engine.py (FI Index Change):332-602](file://User scripts/FI Index Change/tests/test_engine.py#L332-L602)
- [test_engine.py (FI Index Change):604-627](file://User scripts/FI Index Change/tests/test_engine.py#L604-L627)
- [test_engine.py (FI Index Change):629-640](file://User scripts/FI Index Change/tests/test_engine.py#L629-L640)
- [test_engine.py (FI Index Change):643-690](file://User scripts/FI Index Change/tests/test_engine.py#L643-L690)
- [test_engine.py (FI Index Change):692-721](file://User scripts/FI Index Change/tests/test_engine.py#L692-L721)
- [test_engine.py (FI Index Change):723-800](file://User scripts/FI Index Change/tests/test_engine.py#L723-L800)
- [test_app_contract.py (FI Index Change):1-60](file://User scripts/FI Index Change/tests/test_app_contract.py#L1-L60)
- [test_app_runtime.py (FI Index Change):1-39](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L39)
- [test_data_request.py (FI Index Change):1-24](file://User scripts/FI Index Change/tests/test_data_request.py#L1-L24)

### FI Spread Movement Monitoring Test Suite
The FI Spread Movement Monitoring tests validate:
- BQL adapter and response normalization without executing live BQL.
- Engine logic for ranking movers, attaching spread levels, bucketing diverging rows, and summarizing comparisons.
- Cache timeout protections, retry behavior, and cached fallback.

```mermaid
flowchart TD
Start(["Test Entry"]) --> Normalize["Normalize BQL Response Frames"]
Normalize --> RankMovers["Prepare Ranked Movers"]
RankMovers --> AttachLevels["Attach Spread Levels"]
AttachLevels --> BucketRows["Bucket Diverging Rows"]
BucketRows --> Summarize["Summarize Comparison"]
Summarize --> Assertions{"Assertions"}
Assertions --> Columns["Validate Column Contracts"]
Assertions --> Metrics["Validate Computed Metrics"]
Columns --> End(["Test Exit"])
Metrics --> End
```

**Diagram sources**
- [test_data.py (FI Spread Movement Monitoring):1-20](file://User scripts/FI Spread Movement Monitoring/tests/test_data.py#L1-L20)
- [test_engine.py (FI Spread Movement Monitoring):1-38](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py#L1-L38)
- [test_cache.py (FI Spread Movement Monitoring):1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)

**Section sources**
- [test_data.py (FI Spread Movement Monitoring):1-20](file://User scripts/FI Spread Movement Monitoring/tests/test_data.py#L1-L20)
- [test_engine.py (FI Spread Movement Monitoring):1-38](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py#L1-L38)
- [test_cache.py (FI Spread Movement Monitoring):1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)

## Dependency Analysis
Testing dependencies follow clear boundaries:
- Tests depend on their corresponding module’s public interfaces.
- External systems (`bql`, `plotly`, `ipywidgets`) are mocked or stubbed.
- Cache tests depend on temporary directories rather than global state.
- Contract tests depend on source text inspection to enforce UI structure.

```mermaid
graph LR
TestETF_Cap["ETF Capping Tests"] --> EngineETF_Cap["etf_capping.engine"]
TestETF_Spread["ETF Spread Tests"] --> EngineETF_Spread["etf_spread.engine"]
TestETF_Spread --> CacheETF_Spread["etf_spread.cache"]
TestFIC["FI Index Change Tests"] --> EngineFIC["fi_index_change.engine"]
TestFIC --> DataFIC["fi_index_change.data"]
TestFIC --> AppFIC["fi_index_change.app"]
TestFSM["FI Spread Movement Tests"] --> EngineFSM["fi_spread_movement.engine"]
TestFSM --> DataFSM["fi_spread_movement.data"]
TestFSM --> CacheFSM["fi_spread_movement.cache"]
```

**Diagram sources**
- [test_engine.py (ETF Capping Monitoring):19-40](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L19-L40)
- [test_engine.py (ETF Spread Monitoring):20-37](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L20-L37)
- [test_cache.py (ETF Spread Monitoring):19-19](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L19-L19)
- [test_engine.py (FI Index Change):17-46](file://User scripts/FI Index Change/tests/test_engine.py#L17-L46)
- [test_app_contract.py (FI Index Change):14-15](file://User scripts/FI Index Change/tests/test_app_contract.py#L14-L15)
- [test_engine.py (FI Spread Movement Monitoring):16-38](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py#L16-L38)

**Section sources**
- [test_engine.py (ETF Capping Monitoring):19-40](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L19-L40)
- [test_engine.py (ETF Spread Monitoring):20-37](file://User scripts/ETF Spread Monitoring/tests/test_engine.py#L20-L37)
- [test_cache.py (ETF Spread Monitoring):19-19](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L19-L19)
- [test_engine.py (FI Index Change):17-46](file://User scripts/FI Index Change/tests/test_engine.py#L17-L46)
- [test_app_contract.py (FI Index Change):14-15](file://User scripts/FI Index Change/tests/test_app_contract.py#L14-L15)
- [test_engine.py (FI Spread Movement Monitoring):16-38](file://User scripts/FI Spread Movement Monitoring/tests/test_engine.py#L16-L38)

## Performance Considerations
The tests emphasize efficient and predictable performance characteristics:
- **No live network calls**: All BQL interactions are mocked, preventing slow or flaky external dependencies.
- **Deterministic inputs**: Synthetic pandas frames ensure reproducible results.
- **Cache-aware workflows**: Tests validate cold vs warm cache runs, gap planning, and selective refresh windows to minimize redundant data pulls.
- **Request shape validation**: Tests assert that only required fields and universes are requested, reducing payload size and latency.
- **Output formatting checks**: Percent formatting and column ordering tests prevent expensive reformatting or misaligned grids at runtime.

These practices help maintain fast test execution and protect against performance regressions in data processing and UI rendering.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common test failure categories and debugging strategies:

- **Missing external packages**: If tests fail due to missing `plotly` or `ipywidgets`, ensure the widget stub installer is applied before importing the app. In FI Index Change, `conftest.py` installs stubs globally for the test session.
  - Check: [conftest.py (FI Index Change):1-22](file://User scripts/FI Index Change/tests/conftest.py#L1-L22)
  - Stub installer: [widget_stubs.py (FI Index Change):86-108](file://User scripts/FI Index Change/tests/widget_stubs.py#L86-L108)

- **BQL unavailable locally**: When running outside Bloomberg Desktop, BQL is intentionally unavailable. Tests should not call live BQL; use fake services or mock patches.
  - Example guard: [data.py (FI Index Change):35-63](file://User scripts/FI Index Change/fi_index_change/data.py#L35-L63)

- **Cache contract violations**: If cache reads/writes fail, check manifest generation, contract versioning, and column schema validation.
  - Relevant tests: [test_cache.py (ETF Spread Monitoring):34-136](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L136)

- **UI contract regressions**: Static contract tests detect changes in method bodies, widget wiring, and tab layout.
  - Relevant tests: [test_app_contract.py (FI Index Change):25-60](file://User scripts/FI Index Change/tests/test_app_contract.py#L25-L60)

- **Runtime lifecycle failures**: Widget-stubbed runtime tests verify app construction, update success, and update failure paths.
  - Relevant tests: [test_app_runtime.py (FI Index Change):1-39](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L39)

- **Request semantics drift**: Tests assert exact BQL request shapes, item names, and mode flags.
  - Relevant tests: [test_data_request.py (FI Index Change):1-24](file://User scripts/FI Index Change/tests/test_data_request.py#L1-L24)

**Section sources**
- [conftest.py (FI Index Change):1-22](file://User scripts/FI Index Change/tests/conftest.py#L1-L22)
- [widget_stubs.py (FI Index Change):86-108](file://User scripts/FI Index Change/tests/widget_stubs.py#L86-L108)
- [data.py (FI Index Change):35-63](file://User scripts/FI Index Change/fi_index_change/data.py#L35-L63)
- [test_cache.py (ETF Spread Monitoring):34-136](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L136)
- [test_app_contract.py (FI Index Change):25-60](file://User scripts/FI Index Change/tests/test_app_contract.py#L25-L60)
- [test_app_runtime.py (FI Index Change):1-39](file://User scripts/FI Index Change/tests/test_app_runtime.py#L1-L39)
- [test_data_request.py (FI Index Change):1-24](file://User scripts/FI Index Change/tests/test_data_request.py#L1-L24)

## Conclusion
The testing strategy across all modules is consistent, modular, and resilient:
- Use `unittest.TestCase` for structured unit tests.
- Isolate external dependencies with mocks and stubs.
- Generate synthetic data with small, readable pandas helpers.
- Validate cache contracts and request semantics explicitly.
- Protect UI contracts with static source checks and runtime stubs.
- Keep tests fast, deterministic, and focused on one responsibility.

For new features, follow these guidelines:
- Add tests next to the feature under a `tests/` directory.
- Prefer pure pandas assertions for business logic.
- Mock BQL and widgets; never rely on live APIs in automated tests.
- Use temporary directories for cache-related behavior.
- Assert both happy paths and edge cases, including missing data, invalid inputs, and external failures.
- Include contract tests when changing UI wiring or display formatting.
- Review request shapes and field lists to prevent performance regressions.

[No sources needed since this section summarizes without analyzing specific files]