# Project Overview and Introduction

<cite>
**Referenced Files in This Document**
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [RAG KB/00-RAG-INDEX.md](file://RAG KB/00-RAG-INDEX.md)
- [User scripts/ETF Capping Monitoring/README.md](file://User scripts/ETF Capping Monitoring/README.md)
- [User scripts/ETF Spread Monitoring/README.md](file://User scripts/ETF Spread Monitoring/README.md)
- [User scripts/FI Index Change/MAIN.ipynb](file://User scripts/FI Index Change/MAIN.ipynb)
- [User scripts/FI Spread Movement Monitoring/README.md](file://User scripts/FI Spread Movement Monitoring/README.md)
- [User scripts/MDX Scan/MAIN.ipynb](file://User scripts/MDX Scan/MAIN.ipynb)
- [RAG KB/25-etf-capping-monitor.md](file://RAG KB/25-etf-capping-monitor.md)
- [RAG KB/27-etf-spread-monitor.md](file://RAG KB/27-etf-spread-monitor.md)
- [RAG KB/28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
- [RAG KB/29-fi-spread-movement-monitoring.md](file://RAG KB/29-fi-spread-movement-monitoring.md)
- [RAG KB/26-mdx-scan.md](file://RAG KB/26-mdx-scan.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
Bloomberg BQuant Desktop is the institutional-grade runtime for this fixed-income analytics platform. The codebase implements five production-oriented applications that support portfolio managers, fixed-income analysts, and index/portfolio operations teams:

- ETF Capping Monitoring: converts AIM positions into company-level weights and monitors account-specific capping limits.
- ETF Spread Monitoring: tracks historical bid-ask spreads for a configured ETF share-class book, with peer comparison, taxonomy, flows, and NAV/total-return views.
- FI Index Change Tracking: compares month-end membership snapshots for a fixed-income index to surface adds, exits, and weighted changes.
- FI Spread Movement Monitoring: ranks top spread increases and decreases across an index, an AIM account, both together, or one bond.
- MDX Scan: loads Hang Seng members, daily OHLCV, and pandas-based MDX signals.

The platform’s core mission is monitoring ETF positions, ETF spreads, index membership changes, and fixed-income spread movements through Bloomberg Query Language (BQL), while integrating AIM portfolio data where applicable. All applications are designed as Jupyter notebook interfaces on BQuant Desktop, with thin `MAIN.ipynb` bootstrappers and modular Python packages under `User scripts/<Application>/`.

This document explains the platform purpose, target audience, application scope, installation and environment requirements, basic usage patterns, repository structure, development workflow across Cursor/Qoder/TRAE, and the relationship between this codebase and Bloomberg’s financial data infrastructure.

**Section sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [RAG KB/00-RAG-INDEX.md:35-73](file://RAG KB/00-RAG-INDEX.md#L35-L73)

## Project Structure
The workspace is organized by application rather than by layer. Each application owns its notebook entry point, package modules, tests, preview tooling, and documentation.

```mermaid
graph TB
Root["Repository Root"]
Scripts["User scripts"]
ETF_Capping["ETF Capping Monitoring<br/>etf_capping + MAIN.ipynb"]
ETF_Spread["ETF Spread Monitoring<br/>etf_spread + MAIN.ipynb"]
FI_Index["FI Index Change<br/>fi_index_change + MAIN.ipynb"]
FI_Spread["FI Spread Movement Monitoring<br/>fi_spread_movement + MAIN.ipynb"]
MDX["MDX Scan<br/>mdx_scan + MAIN.ipynb"]
RAGKB["RAG KB<br/>Route cards and navigator"]
Rules[".cursor / .qoder / .trae rules"]
Logs["VersionLog.md<br/>instruction.md"]
Root --> Scripts
Scripts --> ETF_Capping
Scripts --> ETF_Spread
Scripts --> FI_Index
Scripts --> FI_Spread
Scripts --> MDX
Root --> RAGKB
Root --> Rules
Root --> Logs
```

Key structural facts:

- Each application has a thin `MAIN.ipynb` that imports the app class and renders it; data requests are not executed until the user clicks Update or Refresh.
- Package modules live under `User scripts/<Application>/<package>/`, typically including `config.py`, `data.py`, `engine.py`, `app.py`, and optional helpers such as `cache.py`, `charts.py`, `peers.py`, or `field_library.py`.
- `RAG KB/` contains the closed-world navigator and route cards for each named application. These cards freeze BQL shapes, identity rules, failure behavior, and deployment expectations.
- Cross-platform rules and operational instructions live at the repository root and under `.cursor/`, `.qoder/`, and `.trae/`.

```mermaid
flowchart TD
Notebook["MAIN.ipynb"] --> AppClass["App class render()"]
AppClass --> Config["config.py constants"]
AppClass --> Data["data.py BQL requests"]
AppClass --> Engine["engine.py pandas logic"]
Data --> BQL["Bloomberg Query Language"]
Data --> AIM["AIM portfolio universe"]
Engine --> Charts["charts.py / views"]
Engine --> Export["Export tables"]
```

**Diagram sources**
- [User scripts/FI Index Change/MAIN.ipynb:1-42](file://User scripts/FI Index Change/MAIN.ipynb#L1-L42)
- [User scripts/MDX Scan/MAIN.ipynb:1-45](file://User scripts/MDX Scan/MAIN.ipynb#L1-L45)
- [RAG KB/25-etf-capping-monitor.md:277-314](file://RAG KB/25-etf-capping-monitor.md#L277-L314)
- [RAG KB/27-etf-spread-monitor.md:394-414](file://RAG KB/27-etf-spread-monitor.md#L394-L414)
- [RAG KB/29-fi-spread-movement-monitoring.md:465-479](file://RAG KB/29-fi-spread-movement-monitoring.md#L465-L479)

**Section sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/ETF Capping Monitoring/README.md:13-45](file://User scripts/ETF Capping Monitoring/README.md#L13-L45)
- [User scripts/ETF Spread Monitoring/README.md:21-54](file://User scripts/ETF Spread Monitoring/README.md#L21-L54)
- [User scripts/FI Spread Movement Monitoring/README.md:45-80](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L80)
- [RAG KB/00-RAG-INDEX.md:52-73](file://RAG KB/00-RAG-INDEX.md#L52-L73)

## Core Components
The platform consists of five main applications, each targeting a specific institutional workflow.

### ETF Capping Monitoring
Purpose:
- Convert Current or Projected AIM holdings into company-level portfolio weights.
- Apply dynamic capping limits and flag breaches or near-limit exposures.
- Support Thai foreign-line pricing overrides, Last Close versus Real Time pricing, and account diagnostics.

Target users:
- Portfolio managers and risk operators monitoring fund-level concentration and capping compliance.

Data integration:
- AIM positions through `bq.univ.members(type="AIM")` with frozen account parameters.
- Company mapping via fundamental ticker lineage.
- Pricing through last-price items with explicit fallback behavior.

Operational notes:
- Update-only lifecycle: data is requested only when the user clicks Update.
- Safety rule prohibits ESG, GHG, climate, or sustainable-finance data.
- Validation cases include AIM accounts, Thai mappings, suspended names, and zero-price market status.

**Section sources**
- [User scripts/ETF Capping Monitoring/README.md:9-144](file://User scripts/ETF Capping Monitoring/README.md#L9-L144)
- [RAG KB/25-etf-capping-monitor.md:49-77](file://RAG KB/25-etf-capping-monitor.md#L49-L77)
- [RAG KB/25-etf-capping-monitor.md:201-275](file://RAG KB/25-etf-capping-monitor.md#L201-L275)
- [RAG KB/25-etf-capping-monitor.md:277-314](file://RAG KB/25-etf-capping-monitor.md#L277-L314)

### ETF Spread Monitoring
Purpose:
- Monitor historical bid-ask spreads for a typed ETF share-class book.
- Compare spreads and returns against peers.
- Display taxonomy, flows, benchmark peers, expense ratios, tracking errors, and NAV return.

Target users:
- ETF portfolio managers, liquidity analysts, and passive strategy operators.

Data integration:
- Typed ISIN book and peer map.
- Quote history, total-return index, NAV, fund flows, and benchmark identifiers.
- Local history cache for quotes, returns, NAVs, and flows.

Operational notes:
- Refresh-only data loading; period and chart controls redraw from cached frames.
- Cache invalidation covers settled rows, identifier-to-ISIN binding, request fingerprint, and window trimming.
- No ESG/GHG/climate data; entitlement and units remain subject to Desktop validation.

**Section sources**
- [User scripts/ETF Spread Monitoring/README.md:9-116](file://User scripts/ETF Spread Monitoring/README.md#L9-L116)
- [User scripts/ETF Spread Monitoring/README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)
- [RAG KB/27-etf-spread-monitor.md:31-51](file://RAG KB/27-etf-spread-monitor.md#L31-L51)
- [RAG KB/27-etf-spread-monitor.md:394-473](file://RAG KB/27-etf-spread-monitor.md#L394-L473)

### FI Index Change Tracking
Purpose:
- Track month-end bond adds and exits for a fixed-income index.
- Show weighted changes, spreads, durations, yields, and dashboard dimensions.
- Support projected month-end membership before effective publication.

Target users:
- Fixed-income index operators, passive portfolio construction teams, and rebalance analysts.

Data integration:
- Index membership through `bq.univ.members(index, dates=...)`.
- Identity columns, spreads, duration measures, yields, and weight.
- Cache keyed by field contract; projected month is not written to cache.

Operational notes:
- Membership diff is computed on string ID after normalization.
- Request breadth was reduced and split to avoid two-minute timeouts.
- Dashboard filters and charts are display-only after Update.

**Section sources**
- [RAG KB/28-fi-index-change.md:41-77](file://RAG KB/28-fi-index-change.md#L41-L77)
- [RAG KB/28-fi-index-change.md:78-253](file://RAG KB/28-fi-index-change.md#L78-L253)
- [RAG KB/28-fi-index-change.md:389-429](file://RAG KB/28-fi-index-change.md#L389-L429)
- [User scripts/FI Index Change/MAIN.ipynb:1-42](file://User scripts/FI Index Change/MAIN.ipynb#L1-L42)

### FI Spread Movement Monitoring
Purpose:
- Rank top spread increases and decreases over a bounded date window.
- Support four universes: index, AIM account, AIM vs index, and single bond.
- Provide bucket charts, Top 10 panels, selected-bond spread paths, and export tables.

Target users:
- Fixed-income traders, relative-value analysts, and portfolio risk monitors.

Data integration:
- Index membership as of end date.
- AIM account holdings using the frozen AIM request shape.
- Descriptor fields, duration measure family, and bounded series validation.

Operational notes:
- One Update sends a bounded set of BQL requests; no fill, no silent substitution.
- Timeout protection includes retry, result cache, and automatic fallback.
- Start and end spread levels are added without extra requests.

**Section sources**
- [User scripts/FI Spread Movement Monitoring/README.md:1-44](file://User scripts/FI Spread Movement Monitoring/README.md#L1-L44)
- [User scripts/FI Spread Movement Monitoring/README.md:82-167](file://User scripts/FI Spread Movement Monitoring/README.md#L82-L167)
- [RAG KB/29-fi-spread-movement-monitoring.md:36-91](file://RAG KB/29-fi-spread-movement-monitoring.md#L36-L91)
- [RAG KB/29-fi-spread-movement-monitoring.md:428-463](file://RAG KB/29-fi-spread-movement-monitoring.md#L428-L463)

### MDX Scan
Purpose:
- Load Hang Seng members, daily OHLCV, and pandas-based MDX signals.
- Support optional Chinese security name and Play-driven visualization.

Target users:
- Equity and cross-asset researchers building signal dashboards on BQuant Desktop.

Data integration:
- Members universe for HSI Index.
- Daily OHLCV range and batched member requests.
- Pandas signal engine ported from a documented formula file.

Operational notes:
- Notebook calls `load_on_start()` once after rendering.
- Signals are pandas computations, not BQL data items.

**Section sources**
- [RAG KB/26-mdx-scan.md:40-54](file://RAG KB/26-mdx-scan.md#L40-L54)
- [RAG KB/26-mdx-scan.md:66-159](file://RAG KB/26-mdx-scan.md#L66-L159)
- [User scripts/MDX Scan/MAIN.ipynb:1-45](file://User scripts/MDX Scan/MAIN.ipynb#L1-L45)

## Architecture Overview
At a high level, each application follows the same BQuant Desktop pattern:

1. `MAIN.ipynb` imports the app class and displays the UI.
2. The app reads configuration from `config.py`.
3. `data.py` builds BQL requests against Bloomberg data.
4. `engine.py` performs pandas transformations, ranking, grouping, and validation.
5. `app.py` renders widgets, handles Update/Refresh, and exposes export tables.
6. Optional modules provide caching, chart specifications, peer maps, or field libraries.

```mermaid
sequenceDiagram
participant User as "Portfolio Manager"
participant Notebook as "MAIN.ipynb"
participant App as "App class"
participant Data as "data.py"
participant BQL as "Bloomberg Query Language"
participant AIM as "AIM Portfolio System"
participant Engine as "engine.py"
participant View as "Charts / Tables"
User->>Notebook : Open project and run cell
Notebook->>App : Create app instance
App->>View : Render controls
User->>App : Click Update or Refresh
App->>Data : Build universe and requests
Data->>BQL : Execute BQL queries
Data->>AIM : Read AIM universe when required
BQL-->>Data : Response frames
Data-->>Engine : Parsed frames
Engine->>Engine : Ranking, grouping, validation
Engine-->>View : Display-ready tables and charts
View-->>User : Dashboard, exports, diagnostics
```

**Diagram sources**
- [RAG KB/00-RAG-INDEX.md:433-474](file://RAG KB/00-RAG-INDEX.md#L433-L474)
- [RAG KB/25-etf-capping-monitor.md:277-314](file://RAG KB/25-etf-capping-monitor.md#L277-L314)
- [RAG KB/27-etf-spread-monitor.md:394-414](file://RAG KB/27-etf-spread-monitor.md#L394-L414)
- [RAG KB/29-fi-spread-movement-monitoring.md:465-479](file://RAG KB/29-fi-spread-movement-monitoring.md#L465-L479)

## Detailed Component Analysis

### ETF Capping Monitoring Analysis
Responsibilities:
- Preserve AIM ticker and quantity.
- Map held securities to company-level keys.
- Compute USD price and position market value.
- Sum weights by company and apply dynamic capping thresholds.
- Surface data issues without hiding breaches.

```mermaid
classDiagram
class ETF_Capping_App {
+render()
+on_update()
+export_monitor()
+export_full_positions()
}
class ETF_Capping_Config {
+WARNING_RATIO
+AIM_ACCOUNT_BATCH
+SECURITY_BATCH
+PRIMARY_FM_BY_AIM
}
class ETF_Capping_Data {
+fetch_aim_positions()
+fetch_descriptors()
+fetch_px_last()
+parse_response()
}
class ETF_Capping_Engine {
+coerce_prices()
+classify_assets()
+compute_company_weights()
+apply_dynamic_limit()
}
ETF_Capping_App --> ETF_Capping_Config : "reads"
ETF_Capping_App --> ETF_Capping_Data : "uses"
ETF_Capping_App --> ETF_Capping_Engine : "uses"
ETF_Capping_Data --> ETF_Capping_Engine : "returns parsed frames"
```

**Diagram sources**
- [RAG KB/25-etf-capping-monitor.md:297-314](file://RAG KB/25-etf-capping-monitor.md#L297-L314)
- [RAG KB/25-etf-capping-monitor.md:201-275](file://RAG KB/25-etf-capping-monitor.md#L201-L275)

**Section sources**
- [User scripts/ETF Capping Monitoring/README.md:35-144](file://User scripts/ETF Capping Monitoring/README.md#L35-L144)
- [RAG KB/25-etf-capping-monitor.md:79-116](file://RAG KB/25-etf-capping-monitor.md#L79-L116)
- [RAG KB/25-etf-capping-monitor.md:252-275](file://RAG KB/25-etf-capping-monitor.md#L252-L275)

### ETF Spread Monitoring Analysis
Responsibilities:
- Load quote history, returns, NAV, and flows.
- Compute spread, spread percent, and period averages.
- Bind identifiers to ISINs so moved primary classes do not reuse stale history.
- Plan gap fills per identifier and trim answers to requested windows.

```mermaid
flowchart TD
Start["Refresh clicked"] --> CheckCache["Use cache enabled?"]
CheckCache --> |Yes| ReadSeries["Read stored quotes/returns/navs/flows"]
CheckCache --> |No| FullWindow["Request full window"]
ReadSeries --> GapPlan["Plan gaps per identifier"]
FullWindow --> GapPlan
GapPlan --> MergeRaw["Merge raw request output"]
MergeRaw --> ComputeDerived["Compute spread, percent, flow scaling"]
ComputeDerived --> TrimWindow["Trim to requested window"]
TrimWindow --> SaveSettled["Write settled rows before last completed London session"]
SaveSettled --> Render["Render table and charts"]
```

**Diagram sources**
- [User scripts/ETF Spread Monitoring/README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)
- [RAG KB/27-etf-spread-monitor.md:416-473](file://RAG KB/27-etf-spread-monitor.md#L416-L473)

**Section sources**
- [User scripts/ETF Spread Monitoring/README.md:73-116](file://User scripts/ETF Spread Monitoring/README.md#L73-L116)
- [User scripts/ETF Spread Monitoring/README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)
- [RAG KB/27-etf-spread-monitor.md:123-149](file://RAG KB/27-etf-spread-monitor.md#L123-L149)
- [RAG KB/27-etf-spread-monitor.md:416-473](file://RAG KB/27-etf-spread-monitor.md#L416-L473)

### FI Index Change Tracking Analysis
Responsibilities:
- Fetch two month-end membership snapshots.
- Normalize identity, spreads, durations, yields, and weights.
- Compute add/exit diffs and weighted dashboard summaries.
- Handle projected month-end membership safely.

```mermaid
flowchart TD
SelectMonth["Select month-end"] --> BuildRequests["Build identity, analytics, duration, yield requests"]
BuildRequests --> SplitGroup["Split by measure group if needed"]
SplitGroup --> Execute["Execute bq.execute per group"]
Execute --> Parse["Parse response frames"]
Parse --> ValidateItems["Check required items and returned columns"]
ValidateItems --> Normalize["Normalize ID, currency, rating, tenor, MBS/TBA mask"]
Normalize --> Diff["Compute Add/Exit by ID"]
Diff --> Summarize["Summarize by Country/Sector/Tenor/Rating/Currency"]
Summarize --> Render["Render dashboard and detail tables"]
```

**Diagram sources**
- [RAG KB/28-fi-index-change.md:78-253](file://RAG KB/28-fi-index-change.md#L78-L253)
- [RAG KB/28-fi-index-change.md:389-429](file://RAG KB/28-fi-index-change.md#L389-L429)

**Section sources**
- [RAG KB/28-fi-index-change.md:78-253](file://RAG KB/28-fi-index-change.md#L78-L253)
- [RAG KB/28-fi-index-change.md:389-429](file://RAG KB/28-fi-index-change.md#L389-L429)
- [RAG KB/28-fi-index-change.md:431-540](file://RAG KB/28-fi-index-change.md#L431-L540)

### FI Spread Movement Monitoring Analysis
Responsibilities:
- Build universes for index, AIM account, AIM vs index, and single bond.
- Rank top spread increases and decreases.
- Attach descriptors, duration measures, and bounded series validation.
- Provide interactive bucket charts, Top 10 panels, and selected-bond paths.

```mermaid
sequenceDiagram
participant User as "Fixed-Income Analyst"
participant App as "FISpreadMovementApp"
participant Data as "data.py"
participant Engine as "engine.py"
participant Charts as "charts.py"
User->>App : Choose Universe, Spread, Start, End
App->>App : Validate inputs and window
App->>Data : Build ranking and descriptor requests
Data-->>App : Ranked frames and metadata
App->>Engine : Prepare sides, attach descriptors, validate change arithmetic
Engine-->>App : Ranked tables and diagnostic notes
App->>Charts : Render bucket charts and Top 10 panels
Charts-->>User : Interactive figures and tables
```

**Diagram sources**
- [User scripts/FI Spread Movement Monitoring/README.md:82-167](file://User scripts/FI Spread Movement Monitoring/README.md#L82-L167)
- [RAG KB/29-fi-spread-movement-monitoring.md:75-125](file://RAG KB/29-fi-spread-movement-monitoring.md#L75-L125)
- [RAG KB/29-fi-spread-movement-monitoring.md:135-191](file://RAG KB/29-fi-spread-movement-monitoring.md#L135-L191)

**Section sources**
- [User scripts/FI Spread Movement Monitoring/README.md:82-167](file://User scripts/FI Spread Movement Monitoring/README.md#L82-L167)
- [User scripts/FI Spread Movement Monitoring/README.md:168-317](file://User scripts/FI Spread Movement Monitoring/README.md#L168-L317)
- [RAG KB/29-fi-spread-movement-monitoring.md:75-191](file://RAG KB/29-fi-spread-movement-monitoring.md#L75-L191)
- [RAG KB/29-fi-spread-movement-monitoring.md:428-463](file://RAG KB/29-fi-spread-movement-monitoring.md#L428-L463)

### MDX Scan Analysis
Responsibilities:
- Load HSI Index members and optional Chinese security name.
- Pull daily OHLCV history.
- Compute pandas-based MDX signals.
- Render live bars and legend.

```mermaid
flowchart TD
Boot["MAIN.ipynb load_on_start()"] --> Members["Members + NameCN"]
Members --> OHLCV["Daily OHLCV range"]
OHLCV --> Signals["Pandas MDX signals"]
Signals --> Plot["Play-driven chart and legend"]
```

**Diagram sources**
- [RAG KB/26-mdx-scan.md:66-159](file://RAG KB/26-mdx-scan.md#L66-L159)
- [RAG KB/26-mdx-scan.md:186-200](file://RAG KB/26-mdx-scan.md#L186-L200)

**Section sources**
- [RAG KB/26-mdx-scan.md:40-54](file://RAG KB/26-mdx-scan.md#L40-L54)
- [RAG KB/26-mdx-scan.md:66-159](file://RAG KB/26-mdx-scan.md#L66-L159)
- [RAG KB/26-mdx-scan.md:186-200](file://RAG KB/26-mdx-scan.md#L186-L200)

## Dependency Analysis
The applications depend on three major layers:

1. **Bloomberg data layer**: BQL universes, data items, and response parsing.
2. **AIM portfolio layer**: Account membership and holdings where required.
3. **Local computation layer**: Pandas transformations, caching, charting, and export.

```mermaid
graph LR
BQL["Bloomberg Query Language"] --> Apps["Five Applications"]
AIM["AIM Portfolio System"] --> ETF_Capping["ETF Capping Monitoring"]
AIM --> FI_Spread["FI Spread Movement Monitoring"]
Apps --> Pandas["Pandas Analytics"]
Pandas --> UI["Jupyter Notebook Interface"]
```

**Diagram sources**
- [RAG KB/00-RAG-INDEX.md:35-51](file://RAG KB/00-RAG-INDEX.md#L35-L51)
- [RAG KB/25-etf-capping-monitor.md:201-221](file://RAG KB/25-etf-capping-monitor.md#L201-L221)
- [RAG KB/29-fi-spread-movement-monitoring.md:215-239](file://RAG KB/29-fi-spread-movement-monitoring.md#L215-L239)

Coupling and cohesion observations:

- Each application is cohesive around one business outcome but shares common patterns: thin notebooks, Update-only execution, fail-closed diagnostics, and export tables.
- External coupling is primarily to BQL and AIM; local dependencies are internal to each package.
- Route cards in `RAG KB/` act as authority boundaries, preventing ad hoc BQL substitutions.

**Section sources**
- [RAG KB/00-RAG-INDEX.md:35-73](file://RAG KB/00-RAG-INDEX.md#L35-L73)
- [RAG KB/25-etf-capping-monitor.md:201-221](file://RAG KB/25-etf-capping-monitor.md#L201-L221)
- [RAG KB/29-fi-spread-movement-monitoring.md:215-239](file://RAG KB/29-fi-spread-movement-monitoring.md#L215-L239)

## Performance Considerations
Performance characteristics are driven by Bloomberg request breadth, timeout limits, and local processing.

Key constraints:

- Desktop kills long-running queries at approximately two minutes.
- Wide requests can time out even when individual items are valid.
- Caching reduces repeated history pulls but does not eliminate live tail re-request.
- Duration and yield families may be expensive because they involve model evaluation.

Optimization patterns used in the codebase:

- Splitting analytics by measure family instead of sending one wide request.
- Bounded candidate universes for descriptors and series.
- Per-identifier history cache with settled-row semantics.
- Retry of identical timed-out requests.
- Cached fallback for clean runs when a timeout occurs.

**Section sources**
- [RAG KB/28-fi-index-change.md:214-253](file://RAG KB/28-fi-index-change.md#L214-L253)
- [RAG KB/28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)
- [RAG KB/29-fi-spread-movement-monitoring.md:428-463](file://RAG KB/29-fi-spread-movement-monitoring.md#L428-L463)
- [User scripts/ETF Spread Monitoring/README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)

## Troubleshooting Guide
Common operational issues and their intended handling:

- **Timeouts**: Retried once when classified as a timeout; deterministic failures are not retried.
- **Missing or failed fields**: Reported per field; successful fields are not hidden.
- **Empty results**: A request returning no rows is reported as zero rows with a note, not as a rejected item.
- **Stale cache**: Identifier-to-ISIN binding prevents reused tickers from serving wrong history.
- **Preview drift**: Preview pages compare build IDs and warn when rendered by older code.
- **Cross-platform drift**: Rule trees and upload mirrors must be synchronized and checked.

Recommended steps:

1. Read the status banner and step log before changing data items.
2. Record request count, elapsed time, row count, and column names.
3. For ETF Spread Monitoring, check whether the cache was written and whether identifiers resolved to different ISINs.
4. For FI Spread Movement Monitoring, verify the bounded series check and effective dates.
5. For FI Index Change, confirm which measure group timed out and whether the month is partial.
6. For cross-platform work, run sync checks and append to `VersionLog.md` rather than rewriting existing entries.

**Section sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/ETF Spread Monitoring/README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)
- [User scripts/FI Spread Movement Monitoring/README.md:365-421](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L421)
- [RAG KB/28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)
- [VersionLog.md:1-335](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Conclusion
This repository implements Bloomberg BQuant Desktop applications for institutional fixed-income analytics. It combines Bloomberg Query Language, AIM portfolio connectivity, and Jupyter notebook interfaces to monitor ETF positions, ETF spreads, index membership changes, and fixed-income spread movements. The architecture emphasizes safe defaults, explicit data contracts, bounded request breadth, and clear diagnostics. Development is coordinated across Cursor, Qoder, and TRAE through shared instructions, version logs, and rule synchronization. Production use requires Desktop validation of entitlements, units, and request timing before relying on any analytical output.