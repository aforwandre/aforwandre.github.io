# Module Overview and Purpose

<cite>
**Referenced Files in This Document**
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [interface.html](file://User scripts/FI Index Change/preview/interface.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
The Fixed Income Index Change module tracks changes to the composition of a fixed-income index between two month-end snapshots. Its primary purpose is to identify which bonds are added or exited, quantify their index weights, and summarize how those changes affect key portfolio dimensions such as country, sector, tenor bucket, rating bucket, currency, spreads, duration measures, and yields.

In portfolio management workflows, the module supports:
- Monitoring monthly index rebalancing by comparing the previous month-end with the selected month-end.
- Analyzing sector rotation effects through dimension-based summaries and charts.
- Tracking credit quality shifts using IG/HY/NR classification and rating bucket movement.
- Preparing exportable change lists and full-position snapshots for downstream analytics or reporting.

The module integrates with Bloomberg BQL through a frozen set of membership and analytics data items. It requests one index universe snapshot per effective date, normalizes identity and classification fields, computes ID-level add/exit differences, and renders an interactive dashboard. Historical snapshots are cached under a field contract so that repeated updates avoid unnecessary BQL calls when the item set has not changed.

**Section sources**
- [28-fi-index-change.md:41-76](file://RAG KB/28-fi-index-change.md#L41-L76)
- [28-fi-index-change.md:78-113](file://RAG KB/28-fi-index-change.md#L78-L113)
- [28-fi-index-change.md:774-791](file://RAG KB/28-fi-index-change.md#L774-L791)

## Project Structure
The module lives under `User scripts/FI Index Change/`. The runtime application is composed of:
- A desktop dashboard controller that builds widgets, handles Update, and renders tables and charts.
- An analytics engine that computes comparisons, transitions, filters, exports, and turnover.
- A data layer that constructs BQL requests, parses responses, retries timeouts, and caches historical snapshots.
- Configuration constants for defaults, filter widths, chart sizing, request splitting, and retry behavior.
- A cache layer that stores CSV snapshots and validates them against a field contract.
- A frozen field library that defines the exact BQL items requested by the app.
- A preview interface that mirrors the app layout and interaction model using local synthetic data.

```mermaid
graph TB
UI["Dashboard Controller<br/>app.py"] --> Engine["Analytics Engine<br/>engine.py"]
UI --> DataLayer["BQL Data Layer<br/>data.py"]
Engine --> FieldLibrary["Frozen Field Library<br/>field_library.py"]
DataLayer --> Cache["CSV Cache<br/>cache.py"]
UI --> Config["Configuration Constants<br/>config.py"]
Preview["Local Preview Interface<br/>interface.html"] --> UI
```

**Diagram sources**
- [app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [config.py:12-16](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L16)
- [cache.py:1-10](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L10)
- [field_library.py:1-18](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L18)
- [interface.html:178-249](file://User scripts/FI Index Change/preview/interface.html#L178-L249)

**Section sources**
- [app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [config.py:12-16](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L16)
- [cache.py:1-10](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L10)
- [field_library.py:1-18](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L18)
- [interface.html:178-249](file://User scripts/FI Index Change/preview/interface.html#L178-L249)

## Core Components
The module’s core components are layered by responsibility:

- Dashboard controller (`app.py`): Builds the index input, month-end dropdown, dimension and bond filters, spread/duration/yield selectors, book selector, headline, status, log, bucket chart, bucket summary table, detail panel, export view, and full-position view. It triggers BQL only on Update and re-renders based on widget interactions.
- Analytics engine (`engine.py`): Computes comparison dates, prepares member snapshots, aligns classification labels across snapshots, diffs IDs into adds and exits, summarizes by dimension, formats export frames, and calculates approximate monthly turnover.
- Data layer (`data.py`): Validates the index ticker, selects allowed month-ends, fetches historical snapshots from cache, builds BQL membership requests, parses response items, merges analytics groups, retries timeout errors once, and finalizes snapshots with normalized columns.
- Field library (`field_library.py`): Freezes the Phase 1 item list, including identity, spreads, duration measures, yields, weight, ISIN, and SEDOL. It also defines analytics groups used when splitting wide requests.
- Configuration (`config.py`): Holds default index and book, country overrides, municipal labeling, filter widths, chart sizing, month-end choice count, request-splitting flag, query attempt count, OAS exclusion threshold, weight scaling rule, display row cap, and cache directory name.
- Cache (`cache.py`): Stores historical CSV snapshots under a manifest, validates required columns and usable identity values, refuses partial or empty snapshots, and invalidates old entries when the field contract changes.
- Runtime authority (`28-fi-index-change.md`): Documents the approved membership request shape, projected-month logic, pandas rules, filter cascade fix, index box behavior, detail panel/export behavior, monthly turnover definition, and cache contract.

**Section sources**
- [app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [config.py:12-16](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L16)
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [28-fi-index-change.md:78-113](file://RAG KB/28-fi-index-change.md#L78-L113)

## Architecture Overview
At runtime, the user enters an index yellow key ending in ` Index`, selects a month-end, and clicks Update. The controller asks the data layer to fetch the selected month-end and the previous month-end. The data layer checks the cache first; if unavailable, it builds a BQL membership request using the frozen field library and executes it. Responses are parsed, merged, validated, and finalized into prepared snapshots. The engine then computes the transition, aligns classification labels, and exposes diff results to the dashboard.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "Dashboard Controller<br/>app.py"
participant Data as "Data Layer<br/>data.py"
participant BQL as "Bloomberg BQL"
participant Cache as "CSV Cache<br/>cache.py"
participant Engine as "Analytics Engine<br/>engine.py"
User->>App : Enter index and month-end, click Update
App->>Data : fetch_index_payload(index_ticker, selected_date)
Data->>Cache : load_historical(previous_date)
alt Cached historical available
Cache-->>Data : Prepared snapshot
else Not cached
Data->>BQL : bq.univ.members(index_ticker, dates=as_of)
BQL-->>Data : Response items
Data->>Data : Parse, merge, validate, finalize
Data->>Cache : save_historical(historical)
end
Data->>Engine : build_transition(snapshots, comparison, statuses)
Engine-->>App : Transition with previous/latest frames
App->>App : Render selection line, charts, tables, detail panel
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

## Detailed Component Analysis

### Dashboard Controller
The dashboard controller owns the user interface lifecycle. It builds:
- Index input and long-name lookup area.
- Month-end dropdown populated from local month-end choices.
- Dimension dropdown (Country, Sector, Tenor, Rating, Currency).
- Bond action dropdown (Add, Exit, Add and Exit).
- Multi-select filters for Country, Sector, Tenor Bucket, Rating Bucket, Currency.
- Spread selector (OAS, Z-Spread, I-Spread).
- Duration selector (Duration, Modified Duration, Effective Duration, OASD).
- Yield selector (Yield, YTM, YTW).
- Book selector (All, Standard, MBS/TBA).
- Headline, caption, status, log, bucket chart, bucket summary table, detail panel, export view, and full-position view.

Update triggers payload fetching, transition building, filter option refresh, error/note logging, license-failure handling, and rendering. View changes redraw loaded rows without sending new BQL requests.

```mermaid
flowchart TD
Start(["Update Clicked"]) --> ValidateIndex["Validate index text"]
ValidateIndex --> FetchPayload["Fetch index payload"]
FetchPayload --> BuildTransition["Build transition"]
BuildTransition --> RefreshFilters["Refresh filter options"]
RefreshFilters --> ShowErrors["Show errors and notes"]
ShowErrors --> CheckLicense["Check membership access failure"]
CheckLicense --> Render["Render dashboard"]
Render --> End(["Idle or Updated"])
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [app.py:740-773](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L773)

**Section sources**
- [app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)
- [app.py:323-577](file://User scripts/FI Index Change/fi_index_change/app.py#L323-L577)
- [app.py:579-660](file://User scripts/FI Index Change/fi_index_change/app.py#L579-L660)
- [app.py:685-773](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L773)

### Analytics Engine
The analytics engine performs all non-BQL calculations:
- Comparison date selection and validation.
- Snapshot preparation, including ID normalization, weight scaling, numeric coercion, blank-text handling, country name overrides, MBS/TBA and Municipal labeling, tenor bucketing, rating bucketing, and AS_OF_DATE tagging.
- Label alignment across snapshots so each ID has one consistent classification for display.
- ID-level add/exit difference computation within the selected book.
- Export frame construction for changes and summary.
- Monthly turnover calculation using the Bloomberg-style formula, currently approximate because index market value is not requested.

```mermaid
flowchart TD
Snapshots["Two snapshots<br/>previous and latest"] --> Prepare["prepare_members()"]
Prepare --> AlignLabels["align_snapshot_labels()"]
AlignLabels --> Diff["diff_members(book)"]
Diff --> Summarize["summarize(dimension, book, filters)"]
Summarize --> Export["change_export_frame() / export_display_frame()"]
Summarize --> Turnover["Monthly turnover (approx)"]
```

**Diagram sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

**Section sources**
- [engine.py:31-63](file://User scripts/FI Index Change/fi_index_change/engine.py#L31-L63)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

### Data Layer and BQL Integration
The data layer is responsible for safe, auditable BQL integration:
- Validates the index ticker must end in ` Index`.
- Chooses allowed month-ends and determines whether the selected date is historical or projected.
- Loads historical snapshots from CSV cache when the field contract matches and Weight is present.
- Builds a membership request using `bq.univ.members(index_ticker, dates=as_of)` and the frozen item dict.
- Parses Arrow-like responses, promotes security IDs, picks value columns, collapses duplicate IDs, and merges item frames on ID only.
- Splits analytics into groups when configured, so a failed group can be reported without discarding identity and other analytics.
- Retries only timeout errors once, preserving the same items and date.
- Finalizes snapshots and marks status as ok, partial, or unavailable.

```mermaid
flowchart TD
Input["index_ticker, selected_date"] --> Compare["comparison_for()"]
Compare --> Jobs["previous_date + selected_date"]
Jobs --> CacheCheck{"Historical cached?"}
CacheCheck --> |Yes| UseCached["Use cached snapshot"]
CacheCheck --> |No| BuildRequest["build_member_items()"]
BuildRequest --> Execute["bq.execute()"]
Execute --> Retry{"Timeout?"}
Retry --> |Yes| ReExecute["Retry once"]
Retry --> |No| Parse["_parse_response()"]
ReExecute --> Parse
Parse --> Merge["_merge_item_frames()"]
Merge --> Finalize["_finalize_snapshot()"]
Finalize --> Status["ok / partial / unavailable"]
```

**Diagram sources**
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [data.py:494-596](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L596)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)

**Section sources**
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [data.py:120-196](file://User scripts/FI Index Change/fi_index_change/data.py#L120-L196)
- [data.py:222-321](file://User scripts/FI Index Change/fi_index_change/data.py#L222-L321)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:494-596](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L596)
- [data.py:604-700](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L700)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)

### Field Library and Request Width
The field library freezes the exact BQL items requested by the app. This prevents dynamic item construction from widget text and makes request width explicit. The current set includes identity fields, spreads, duration measures, yields, weight, ISIN, and SEDOL. When request splitting is enabled, analytics are split into spreads/yields and durations to reduce the chance of BQL timeouts.

Key behaviors:
- All listed items are requested on every Update.
- No optional items remain after Market Value was removed.
- Duration measures come from one builder differentiated by `duration_type`.
- YTM and YTW are parameter forms of `yield_()`, not separate catalog spellings.
- Splitting reduces per-request width but may increase total wall-clock time; it is a trade-off for reliability.

**Section sources**
- [field_library.py:1-18](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L18)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)
- [field_library.py:145-187](file://User scripts/FI Index Change/fi_index_change/field_library.py#L145-L187)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)

### Configuration and Cache Contract
Configuration centralizes defaults and display/runtime behavior:
- Default index and book.
- Country name overrides and municipal labeling.
- Filter widths, gaps, and chart sizing.
- Month-end choice count.
- Request splitting and query attempts.
- OAS exclusion threshold and weight fraction scaling.
- Display row cap and cache directory name.

The cache contract ensures that stored snapshots remain compatible with the current pipeline:
- `FIELD_CONTRACT` derives from the frozen item list and label rules.
- `CACHE_GENERATION` protects against loading poisoned months caused by past merge defects.
- Required columns include identity fields and Weight.
- A cached month with all identity columns empty is refused and re-requested.

**Section sources**
- [config.py:12-16](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L16)
- [config.py:17-47](file://User scripts/FI Index Change/fi_index_change/config.py#L17-L47)
- [config.py:49-86](file://User scripts/FI Index Change/fi_index_change/config.py#L49-L86)
- [config.py:88-121](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L121)
- [cache.py:28-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L28-L57)
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)

### User Interface Layout and Controls
The main dashboard includes:
- Top controls: Index, Month-end, Update.
- Selection line showing loaded vs pending state.
- Status and log panels.
- Dimension and Bonds controls.
- Filter row: Country, Sector, Tenor, Rating, Currency, Spread, Duration, Yield, Book.
- Headline with turnover information.
- Horizontal bar chart showing Add weight and Exit weight by dimension.
- Bucket summary table with Begin, End, +/- measures, Add/Exit counts and weights, and turnover attribution.
- Detail panel with bond list, signed weight chart, bond field table, and selected-bond note.
- Export tab for Changes and Summary.
- Full Position tab for Start date and End date constituent snapshots.

The preview interface mirrors this layout using HTML/CSS/JavaScript and local synthetic data, ensuring that control labels, column order, pinned columns, and click behavior match the app.

**Section sources**
- [app.py:323-577](file://User scripts/FI Index Change/fi_index_change/app.py#L323-L577)
- [app.py:597-660](file://User scripts/FI Index Change/fi_index_change/app.py#L597-L660)
- [interface.html:178-249](file://User scripts/FI Index Change/preview/interface.html#L178-L249)
- [interface.html:251-587](file://User scripts/FI Index Change/preview/interface.html#L251-L587)

### Typical Workflow
A typical workflow proceeds as follows:
1. Select an index yellow key ending in ` Index`.
2. Choose a month-end from the dropdown.
3. Click Update to request the selected month-end and the previous month-end.
4. Review the selection line, status, and log.
5. Inspect the headline, bucket chart, and bucket summary.
6. Use filters to analyze specific countries, sectors, tenors, ratings, currencies, spreads, durations, or yields.
7. Click a bucket or bond to open the detail panel.
8. Export Changes or Summary for analysis.
9. Use Full Position to inspect the complete index constituents at either month-end.

Common use cases include:
- Monitoring monthly index rebalancing by reviewing adds, exits, and turnover.
- Analyzing sector rotation effects by selecting Sector as the dimension and observing Add/Exit weight shifts.
- Tracking credit quality shifts by filtering on Rating Bucket IG/HY/NR and examining rating-related metrics.

**Section sources**
- [28-fi-index-change.md:587-650](file://RAG KB/28-fi-index-change.md#L587-L650)
- [28-fi-index-change.md:656-703](file://RAG KB/28-fi-index-change.md#L656-L703)
- [28-fi-index-change.md:705-773](file://RAG KB/28-fi-index-change.md#L705-L773)

## Dependency Analysis
The module exhibits clear separation of concerns:
- The dashboard controller depends on configuration, data, and engine modules but does not call BQL directly.
- The engine depends on the frozen field library names and configuration constants but contains no network calls.
- The data layer depends on cache, config, engine helpers, and the frozen field library to construct and execute BQL requests.
- The cache depends on engine utilities for identity validation and on the frozen field library for contract derivation.
- The preview interface depends on the same column definitions and filter structure as the app, but runs locally without BQL.

```mermaid
graph LR
App["app.py"] --> Config["config.py"]
App --> Data["data.py"]
App --> Engine["engine.py"]
Data --> Cache["cache.py"]
Data --> FieldLibrary["field_library.py"]
Engine --> FieldLibrary
Cache --> FieldLibrary
Preview["interface.html"] --> App
```

**Diagram sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [interface.html:251-278](file://User scripts/FI Index Change/preview/interface.html#L251-L278)

**Section sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [interface.html:251-278](file://User scripts/FI Index Change/preview/interface.html#L251-L278)

## Performance Considerations
Performance is governed by BQL request width, retry policy, caching, and rendering limits:
- A single wide request can exceed the two-minute Desktop limit; request splitting reduces per-query width at the cost of additional requests.
- Only timeout errors are retried; deterministic failures such as rejected items, entitlement issues, or invalid tickers are not retried.
- Historical snapshots are reused when the field contract matches and Weight is present.
- Identity columns must have usable values; otherwise the month is marked partial and not cached.
- Rendering caps display rows and chart sizes to keep the dashboard responsive.
- Local parsing and rendering are fast compared to BQL latency; timeouts should not be diagnosed as Python hot spots.

Recommendations:
- Keep the frozen item list minimal and aligned with operator requirements.
- Use request splitting only when a dated Desktop timing confirms that a narrower request completes reliably.
- Monitor logs for timeout messages and warm-cache behavior.
- Avoid adding optional items unless their consumer and currency basis are confirmed.

**Section sources**
- [28-fi-index-change.md:214-253](file://RAG KB/28-fi-index-change.md#L214-L253)
- [28-fi-index-change.md:321-332](file://RAG KB/28-fi-index-change.md#L321-L332)
- [28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)
- [config.py:88-121](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L121)
- [data.py:499-596](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L596)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)

## Troubleshooting Guide
Common issues and their diagnostic signals:
- License or entitlement failure: The screen shows a membership access message rather than an empty add/exit list.
- Timeout: Logged as a BQL timeout; the app retries once unchanged. Do not assume Python performance is the cause.
- Missing or null Weight: The snapshot is refused and marked unavailable.
- Partial response: One or more identity columns arrived empty; the month is marked partial and not cached.
- Duplicate IDs: Collapsed to last non-null value per column; logged for audit.
- Blank country/sector/currency on MBS/TBA or Municipal rows: Normalized to book-specific labels.
- Rating bucket mismatch: Alignment ensures one classification per ID; conflicts are checked and logged.
- Filter cascade bug: Detail list must apply every active filter, not only the clicked dimension.

Operational guidance:
- Verify the index yellow key ends in ` Index`.
- Check the status line and log for license, timeout, or partial-response messages.
- Confirm that the selected month-end is in the allowed dropdown.
- If a month times out repeatedly, investigate BQL entitlements and request width before changing code.
- Use Export and Full Position to validate data shapes outside the filtered dashboard view.

**Section sources**
- [28-fi-index-change.md:552-585](file://RAG KB/28-fi-index-change.md#L552-L585)
- [28-fi-index-change.md:587-650](file://RAG KB/28-fi-index-change.md#L587-L650)
- [engine.py:104-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L104-L128)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:607-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L607-L630)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:529-596](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L596)

## Conclusion
The Fixed Income Index Change module provides a disciplined, auditable view of index composition changes. It combines a frozen BQL item set, robust response parsing, safe caching, and a clear dashboard to support portfolio monitoring, rebalance analysis, sector rotation review, and credit quality tracking. Its architecture separates user interaction, analytics, data retrieval, and persistence, making it easier to maintain correctness while integrating with Bloomberg BQL. For reliable operation, users should follow the approved index and month-end inputs, monitor status and logs, and treat timeouts and partial responses as external-data issues rather than dashboard rendering problems.