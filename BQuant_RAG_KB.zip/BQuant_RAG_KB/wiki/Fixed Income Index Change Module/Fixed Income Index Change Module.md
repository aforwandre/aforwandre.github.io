# Fixed Income Index Change Module

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the Fixed Income Index Change module, which tracks month-end changes to a Bloomberg fixed-income index. It covers how index membership is requested and normalized, how month-end effective dates are computed, how MBS/TBA bonds are isolated from Standard bonds, how weights are normalized, how bond adds and exits are detected, and how analytics fields such as spreads, durations, and yields are handled. It also documents the field library that defines the frozen BQL item set, the CSV cache for historical snapshots, the reporting and export capabilities, and the integration with Bloomberg BQL.

The module is designed so that an Update requests only two snapshots: the selected effective month-end and the previous month-end. Adds and exits are ID-level differences inside one book (Standard, MBS/TBA, or All). The dashboard then aggregates those changes by Country, Sector, Tenor Bucket, Rating Bucket, and Currency, while preserving audit notes about missing or blank fields.

## Project Structure
The active implementation lives under `User scripts/FI Index Change/fi_index_change/`. The main runtime files are:

| File | Responsibility |
|---|---|
| `app.py` | User interface controller, widget state, chart rendering, and export tab behavior |
| `data.py` | BQL request orchestration, response parsing, retry logic, and payload assembly |
| `engine.py` | Month-end date math, snapshot normalization, label alignment, change detection, aggregation, and export frame construction |
| `field_library.py` | Frozen Phase 1 BQL items, measure groups, numeric/string column definitions, and item builders |
| `cache.py` | CSV-based historical cache, manifest, contract/versioning, and load/save guards |
| `config.py` | Defaults, display labels, filter widths, timeout/retry settings, and business constants |

```mermaid
graph TB
UI["app.py<br/>UI controller"] --> DATA["data.py<br/>BQL fetch + parse"]
DATA --> FIELD["field_library.py<br/>Frozen BQL items"]
DATA --> CACHE["cache.py<br/>CSV cache"]
DATA --> ENGINE["engine.py<br/>Normalization + diff + summary"]
ENGINE --> CONFIG["config.py<br/>Constants"]
UI --> ENGINE
UI --> CONFIG
```

**Diagram sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-29](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L29)
- [field_library.py:1-18](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L18)
- [cache.py:1-27](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L27)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)

**Section sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-29](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L29)
- [field_library.py:1-18](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L18)
- [cache.py:1-27](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L27)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)

## Core Components
The module separates concerns into six focused layers:

1. **Field Library**: Defines the exact BQL items requested for each index member snapshot. It includes identity columns, spreads, durations, yields, weights, and identifiers.
2. **Data Layer**: Builds the BQL request, executes it with retries, parses heterogeneous responses, merges item frames on security ID, and returns prepared snapshots.
3. **Engine Layer**: Normalizes snapshots, classifies bonds, aligns categorical labels across snapshots, computes adds/exits, aggregates by dimension, and builds export tables.
4. **Cache Layer**: Persists historical snapshots as CSV with a manifest, validates contracts, and refuses incomplete or poisoned data.
5. **Configuration Layer**: Holds defaults, display labels, timeout/retry parameters, bucket limits, and UI sizing constants.
6. **Application Layer**: Wires widgets, handles user input, calls the data layer, builds transitions, renders charts, and exposes Export and Full Position views.

**Section sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [cache.py:40-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L40-L71)
- [config.py:12-122](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L122)
- [app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)

## Architecture Overview
The end-to-end flow starts when the user clicks Update. The app validates the index ticker and month-end, asks the data layer for the selected month and the previous month, normalizes both snapshots, aligns classification labels, detects ID-level changes, and renders the dashboard.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant Cache as "cache.py"
participant Field as "field_library.py"
participant Engine as "engine.py"
participant Config as "config.py"
User->>App : Click Update
App->>Data : fetch_index_payload(index_ticker, selected_date)
Data->>Config : read MONTH_END_CHOICES, SPLIT_REQUESTS, QUERY_ATTEMPTS
Data->>Cache : load_historical(previous_date)
alt cached and valid
Cache-->>Data : historical frame
else not cached
Data->>Field : build_member_items()
Data->>Data : _execute_attempts()
Data->>Data : _parse_response()
Data->>Engine : prepare_members()
Data->>Cache : save_historical()
end
Data->>Engine : align_snapshot_labels(previous, latest)
Data->>Engine : diff_members(previous, latest, book)
Data->>App : IndexPayload(snapshots, statuses, errors, notes)
App->>Engine : build_transition()
App->>App : render dashboard and charts
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)

## Detailed Component Analysis

### Index Membership Processing Pipeline
The pipeline processes one effective date through these stages:

1. **Universe definition**: Uses `bq.univ.members(index_ticker, dates=as_of)` rather than singular `member`, `setdiff`, or ETF-style holdings.
2. **Item building**: Constructs BQL items from the frozen `ITEM_NAMES` list.
3. **Execution**: Executes the request with optional split groups and timeout-aware retries.
4. **Parsing**: Extracts value columns per item, collapses duplicate IDs, merges on `ID`, and drops internal `DATE` columns.
5. **Preparation**: Normalizes strings, numerics, weights, books, ratings, tenors, and derived buckets.
6. **Finalization**: Assigns `AS_OF_DATE` and `SNAPSHOT_KIND`, coerces numeric columns, and marks the snapshot usable or unavailable.

```mermaid
flowchart TD
Start(["Start one effective date"]) --> Universe["Build members universe"]
Universe --> BuildItems["Build frozen BQL items"]
BuildItems --> Execute["Execute with retries"]
Execute --> Parse["Parse response items"]
Parse --> Merge["Merge on ID, collapse duplicates"]
Merge --> Prepare["Normalize weights, labels, buckets"]
Prepare --> Finalize["Assign AS_OF_DATE and SNAPSHOT_KIND"]
Finalize --> Usable{"Weight present and usable?"}
Usable --> |Yes| Snapshot["Return prepared snapshot"]
Usable --> |No| Unavailable["Mark snapshot unavailable"]
```

**Diagram sources**
- [data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

**Section sources**
- [data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

### Month-End Business Day Handling
Month-end handling distinguishes between calendar month ends and business-effective month ends. The system:

- Computes the last weekday on or before a calendar month end.
- Determines the current effective month end and the projected effective month end.
- Generates dropdown choices up to a configured count, labeling the projected date separately.
- Validates the selected month against allowed dropdown values.
- Derives the previous month end for comparison.

```mermaid
flowchart TD
Today["Today normalized"] --> CalendarEnd["Calendar month end"]
CalendarEnd --> Effective["Last weekday <= calendar end"]
Effective --> Projected["Projected effective if today >= this_effective"]
Effective --> Choices["Generate month-end choices"]
Choices --> Validate["Validate selected month"]
Validate --> Previous["Compute previous month end"]
```

**Diagram sources**
- [engine.py:167-193](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L193)
- [engine.py:196-232](file://User scripts/FI Index Change/fi_index_change/engine.py#L196-L232)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)

**Section sources**
- [engine.py:167-193](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L193)
- [engine.py:196-232](file://User scripts/FI Index Change/fi_index_change/engine.py#L196-L232)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)

### MBS/TBA Isolation Logic
MBS/TBA isolation is applied during snapshot preparation and remains independent of the Book filter. A row is classified as MBS/TBA when:

- `Security Type` contains `MBS`, `TBA`, or `Pool`.
- The security ID contains `Mtge`.

For MBS/TBA rows:

- Blank `Country` and `Sector` become `MBS/TBA`.
- Blank `Currency` becomes `USD`.
- Rating is marked not applicable.
- Missing numeric tenor becomes `N.A.` instead of `Missing`.

Standard bonds retain `(blank)` for truly missing text fields and use normal tenor bucket logic. US municipal bonds are identified by an ID suffix and are treated as Standard bonds with `Municipal` country/sector, `USD` currency, and not-applicable rating.

```mermaid
flowchart TD
Row["One prepared row"] --> CheckType["Security Type contains MBS/TBA/Pool?"]
CheckType --> |Yes| TBA["Book = MBS/TBA"]
CheckType --> |No| CheckID["ID contains Mtge?"]
CheckID --> |Yes| TBA
CheckID --> |No| Standard["Book = Standard"]
TBA --> FillBlank["Fill blank Country/Sector/Muni rules"]
Standard --> MunicipalCheck["ID ends with Muni?"]
MunicipalCheck --> |Yes| Municipal["Country/Sector = Municipal, Currency = USD"]
MunicipalCheck --> |No| KeepStandard["Keep Standard labels"]
```

**Diagram sources**
- [engine.py:413-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L461)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

**Section sources**
- [engine.py:413-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L461)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

### Weight Normalization Algorithms
Weights come from `bq.data.id()['weights']` and may arrive as fractions or percent points. The normalization logic:

1. Converts `Weight` to numeric, coercing invalid values to null.
2. Computes the net sum and absolute sum of weights.
3. Chooses the net sum if positive; otherwise falls back to the absolute sum.
4. If the chosen basis is greater than zero and at most `WEIGHT_FRACTION_SUM_MAX`, multiplies all weights by 100 to convert fractions to percent points.
5. Leaves intermediate sums unscaled because they cannot be reliably inferred.

This prevents a snapshot with mixed signs from being misclassified and avoids printing a whole book scaled incorrectly.

```mermaid
flowchart TD
Start(["Weight column present"]) --> Numeric["Convert to numeric"]
Numeric --> NetSum["Compute net weight sum"]
NetSum --> AbsSum["Compute absolute weight sum"]
AbsSum --> Basis{"Net sum > 0?"}
Basis --> |Yes| UseNet["Use net sum as basis"]
Basis --> |No| UseAbs["Use absolute sum as basis"]
UseNet --> ScaleCheck{"0 < basis <= 1.05?"}
UseAbs --> ScaleCheck
ScaleCheck --> |Yes| Multiply["Multiply weights by 100"]
ScaleCheck --> |No| Keep["Keep returned scale"]
```

**Diagram sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

**Section sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

### Change Detection Mechanisms
Change detection is ID-based within one book:

- `All` keeps both Standard and MBS/TBA rows.
- `Standard` filters to Standard bonds.
- `MBS/TBA` filters to MBS/TBA bonds.
- Added securities are those present in the latest snapshot but absent from the previous snapshot.
- Exited securities are those present in the previous snapshot but absent from the latest snapshot.
- Both added and exited sets are sorted by weight descending when available.
- A bond that stays in the index but changes Country or Sector is not an add or exit.

```mermaid
flowchart TD
Start(["Two prepared snapshots"]) --> FilterBook["Filter by selected book"]
FilterBook --> PreviousIDs["Extract previous ID set"]
FilterBook --> LatestIDs["Extract latest ID set"]
PreviousIDs --> Added["Latest minus Previous"]
LatestIDs --> Exited["Previous minus Latest"]
Added --> SortAdded["Sort added by weight"]
Exited --> SortExited["Sort exited by weight"]
SortAdded --> Result["Return previous, latest, added, exited"]
SortExited --> Result
```

**Diagram sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

### Field Library System
The field library centralizes the frozen Phase 1 membership snapshot schema. It defines:

- Spread fields: OAS, Z-Spread, I-Spread.
- Duration fields: Duration, Modified Duration, Effective Duration, OASD.
- Yield fields: Yield, YTM, YTW.
- Identity fields: Name, Issuer, Sector, Country, Currency, Security Type, Maturity, Tenor, Rating, Coupon, Weight, ISIN, SEDOL.
- Analytics grouping for split requests.
- Numeric and string column lists used by parsing and caching.
- Lazy item builders that raise a named error when a frozen item cannot be constructed.

```mermaid
classDiagram
class FieldLibrary {
+SPREAD_FIELDS
+DURATION_FIELDS
+YIELD_FIELDS
+ITEM_NAMES
+ANALYTICS_NAMES
+ANALYTICS_GROUPS
+NUMERIC_COLUMNS
+STRING_COLUMNS
+build_member_items(bq, names)
}
class ItemBuildError {
+item
+cause
}
FieldLibrary --> ItemBuildError : "raises on failed builder"
```

**Diagram sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)

**Section sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)

### Cache System for Historical Index Compositions
The cache stores historical snapshots as CSV files under a project-local cache directory. Each entry is tracked in a manifest JSON file. A cached snapshot is reused only when:

- The manifest entry exists.
- The stored field contract matches the current `FIELD_CONTRACT`.
- The stored generation token matches the current `CACHE_GENERATION`.
- Required columns are present.
- At least one required identity column has a usable value.
- The snapshot has at least one non-null weight.

The field contract combines the frozen item names and label configuration, so changing the item list or country overrides automatically invalidates old entries.

```mermaid
flowchart TD
Load["load_historical(ticker, as_of)"] --> ReadManifest["Read manifest.json"]
ReadManifest --> EntryFound{"Entry exists?"}
EntryFound --> |No| Miss["Return None"]
EntryFound --> |Yes| ContractCheck{"Fields match and has_weight?"}
ContractCheck --> |No| Miss
ContractCheck --> GenCheck{"Generation matches?"}
GenCheck --> |No| Miss
GenCheck --> ColumnsCheck{"Required columns present?"}
ColumnsCheck --> |No| Miss
ColumnsCheck --> ReadCSV["Read CSV"]
ReadCSV --> WeightCheck{"Any non-null Weight?"}
WeightCheck --> |No| Miss
WeightCheck --> IdentityCheck{"Any usable identity column?"}
IdentityCheck --> |No| Miss
IdentityCheck --> Return["Return typed frame"]
```

**Diagram sources**
- [cache.py:31-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L31-L57)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)

**Section sources**
- [cache.py:31-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L31-L57)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)

### Reporting and Export Capabilities
The application provides three tabs:

1. **Main**: Interactive dashboard with selection controls, dimension charts, bucket summaries, and detail panels.
2. **Export**: In-memory copy tables for Changes and Summary. No files are written.
3. **Full Position**: Full constituent list for either the start or end month-end, independent of Book and dimension filters.

Export behavior:

- Changes export includes every Add and Exit in the selected book, with `Action`, identity fields, analytics, and `Weight`.
- Summary export includes the current bucket summary.
- Full Position export includes every constituent at the selected month-end, without the `Action` column.
- Every copy table repeats column names as its first data row so clipboard paste retains headers.
- `Weight` is printed with a percent sign in Changes and Full Position because the stored value is already in percent points.

**Section sources**
- [engine.py:671-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L671-L781)
- [app.py:521-568](file://User scripts/FI Index Change/fi_index_change/app.py#L521-L568)
- [app.py:171-203](file://User scripts/FI Index Change/fi_index_change/app.py#L171-L203)

### Integration with Bloomberg Index Data
Integration is implemented through the BQL service:

- The universe is `bq.univ.members(index_ticker, dates=effective_date)`.
- Items are built from `field_library.build_member_items`.
- Requests use `with_params={'mode': 'cached'}`.
- Response parsing supports multiple response shapes, including Arrow-like responses and combined dataframes.
- Timeout detection retries only genuine timeouts, not deterministic failures such as rejected items or entitlement errors.
- When split requests are enabled, identity items are fetched first, followed by analytics groups.

```mermaid
sequenceDiagram
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Field as "field_library.py"
Data->>Field : build_member_items(ITEM_NAMES)
Field-->>Data : dict of BQL data items
Data->>BQL : execute(Request(universe, items, mode='cached'))
alt timeout
Data->>BQL : retry same request
else success
BQL-->>Data : response with items
end
Data->>Data : parse and merge items
```

**Diagram sources**
- [data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)

**Section sources**
- [data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)

### Bond Types and Sectors
Bond types and sectors are handled through:

- `security_typ()` for raw security type classification.
- MBS/TBA mask based on security type and ID pattern.
- Municipal identification by ID suffix.
- Country name overrides and title-cased display formatting.
- Rating classification into IG, HY, or NR.
- Tenor bucketing from numeric tenor years.

These rules ensure that MBS/TBA and Municipal bonds are displayed consistently even when vendor data is blank or uses different naming conventions.

**Section sources**
- [engine.py:254-298](file://User scripts/FI Index Change/fi_index_change/engine.py#L254-L298)
- [engine.py:306-350](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L350)
- [engine.py:413-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L461)
- [config.py:17-47](file://User scripts/FI Index Change/fi_index_change/config.py#L17-L47)

## Dependency Analysis
The module has clear directional dependencies:

- `app.py` depends on `data.py`, `engine.py`, and `config.py`.
- `data.py` depends on `cache.py`, `config.py`, `engine.py`, and `field_library.py`.
- `engine.py` depends on `field_library.py` and `config.py`.
- `cache.py` depends on `config.py`, `engine.py`, and `field_library.py`.
- `field_library.py` is self-contained except for BQL imports at call time.
- `config.py` has no runtime code dependencies beyond Python standard libraries.

```mermaid
graph LR
APP["app.py"] --> DATA["data.py"]
APP --> ENGINE["engine.py"]
APP --> CONFIG["config.py"]
DATA --> CACHE["cache.py"]
DATA --> CONFIG
DATA --> ENGINE
DATA --> FIELD["field_library.py"]
ENGINE --> FIELD
ENGINE --> CONFIG
CACHE --> CONFIG
CACHE --> ENGINE
CACHE --> FIELD
```

**Diagram sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

**Section sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

## Performance Considerations
Key performance characteristics include:

- **Split requests**: When `SPLIT_REQUESTS` is true, the identity block is fetched first, followed by analytics groups. This reduces the chance of a wide request timing out.
- **Timeout retries**: Only genuine timeouts are retried. Deterministic failures are not retried to avoid wasting time on unrecoverable errors.
- **Cache reuse**: Historical snapshots are reused when the field contract and generation token match, avoiding repeated BQL calls.
- **Response merging**: Duplicate IDs are collapsed using forward-fill and group-by-last semantics to preserve non-null values.
- **Display caps**: The UI caps display rows and chart buckets to keep large universes readable.
- **Local processing budget**: Local parsing and rendering are fast compared to BQL network latency; timeouts are evidence of request or date issues, not Python hot spots.

Optimization strategies:

- Keep `SPLIT_REQUESTS` enabled only when Desktop timing confirms that a single wide request exceeds the limit.
- Avoid adding new items to `ITEM_NAMES` without confirming query width and elapsed time.
- Do not restore optional fields like `Market Value` unless the currency basis is confirmed and the additional request cost is justified.
- Use the cache for historical months and avoid manual edits to `cache/manifest.json`.
- Monitor logs for duration items returning identical values, which indicates that `duration_type` may be ignored.

**Section sources**
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)
- [28-fi-index-change.md:326-332](file://RAG KB/28-fi-index-change.md#L326-L332)

## Troubleshooting Guide

### Date Handling Issues
Symptoms:

- Selected month-end is outside the dropdown.
- Projected month behaves unexpectedly near month boundaries.
- Previous month-end appears wrong.

Checks:

- Ensure the selected date is one of the generated month-end choices.
- Verify that the effective date calculation uses the last weekday on or before the calendar month end.
- Confirm that the previous month end is derived from the selected month, not from today.

Relevant functions:

- `effective_dates`
- `default_month_end`
- `month_end_choices`
- `comparison_for`

**Section sources**
- [engine.py:167-193](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L193)
- [engine.py:196-232](file://User scripts/FI Index Change/fi_index_change/engine.py#L196-L232)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)

### Weight Calculation Issues
Symptoms:

- Weights appear too small or too large.
- Dashboard shows percent points but source data was fractions.
- Mixed-sign weights cause unexpected scaling.

Checks:

- Confirm whether the source weights sum near 1.0 or near 100.
- Check whether the net weight sum is positive.
- Verify that the basis is at most `WEIGHT_FRACTION_SUM_MAX`.
- Inspect notes for the message indicating fraction-to-percent conversion.

Relevant logic:

- Net vs absolute weight basis selection.
- Fraction scaling threshold.
- Percent display suffix.

**Section sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [engine.py:671-674](file://User scripts/FI Index Change/fi_index_change/engine.py#L671-L674)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

### Data Parsing Issues
Symptoms:

- A column is missing from the output.
- A column exists but every value is blank.
- Multiple DATE values appear in response notes.
- Duration columns have identical values.

Checks:

- Look for notes about items that did not parse versus items that arrived with all-null values.
- Check `_returned_shape` diagnostics for the actual columns returned by BQL.
- Confirm that the response was parsed as empty or as a valid frame.
- Review duplicate ID handling and merge key behavior.

Relevant logic:

- `_missing_items`
- `_returned_shape`
- `_parse_response`
- `_merge_item_frames`

**Section sources**
- [data.py:376-405](file://User scripts/FI Index Change/fi_index_change/data.py#L376-L405)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)

### Cache Issues
Symptoms:

- Old cached data is shown after changing field definitions.
- A month is repeatedly re-requested.
- A cached month looks clean but has blank identity columns.

Checks:

- Verify `FIELD_CONTRACT` and `CACHE_GENERATION`.
- Confirm that the manifest entry has `has_weight` and required columns.
- Check whether the cached frame has any usable identity value.
- Avoid editing cache files manually; let the code manage manifest updates.

**Section sources**
- [cache.py:31-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L31-L57)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)

### Bloomberg Access and License Issues
Symptoms:

- The screen reports no data access license.
- A 403 error occurs.
- An empty book is shown.

Checks:

- Distinguish membership access failure from session failure and empty results.
- Confirm that the index yellow key ends with ` Index`.
- Check whether the error contains entitlement, permission, license, unauthorized, or 403 markers.

**Section sources**
- [engine.py:99-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L99-L128)
- [app.py:740-755](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L755)

## Conclusion
The Fixed Income Index Change module implements a disciplined, auditable pipeline for tracking month-end changes to a fixed-income index. It separates BQL integration, response parsing, snapshot normalization, change detection, aggregation, caching, and UI rendering into focused modules. The frozen field library ensures consistent requests, the cache preserves historical snapshots safely, and the engine enforces robust rules for MBS/TBA isolation, weight normalization, rating classification, and ID-based change detection.

For production use, operators should:

- Use the frozen item list and avoid ad hoc BQL queries.
- Rely on the two-snapshot Update model.
- Monitor logs for missing or blank fields.
- Treat timeouts as request/date issues rather than local performance problems.
- Preserve cache integrity and avoid manual edits.
- Reconfirm any change to turnover methodology, index market value inputs, or BQL item semantics before publishing numbers externally.