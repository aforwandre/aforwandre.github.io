# Cache Management and Performance

<cite>
**Referenced Files in This Document**
- [cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [test_cache.py](file://User scripts/ETF Spread Monitoring/tests/test_cache.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [cache.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py)
- [config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [test_cache.py](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the cache management system used across three Bloomberg BQL-based analysis projects to optimize performance for large index universes. The caches reduce redundant Bloomberg BQL calls, improve response times, and provide safe fallbacks when network or terminal queries time out.

There are three related but distinct caching strategies:
- ETF Spread Monitoring stores daily historical series per data kind (quotes, returns, NAVs, flows). It computes only the missing days on each refresh and merges live rows over settled history.
- FI Index Change stores immutable monthly snapshots of index composition fields and weights. A month is reused only if its field contract, generation token, and required columns match.
- FI Spread Movement Monitoring stores complete run results keyed by universe, spread type, window, and ranking width. A cached result replays exactly what one update returned and is presented as cached rather than fresh.

The design avoids heavy external dependencies, uses CSV plus a JSON manifest, and applies multiple invalidation tokens so that schema changes, request-shape changes, and identity changes do not silently serve stale data.

## Project Structure
The cache logic lives in dedicated `cache.py` modules under each project, with configuration constants in sibling `config.py` files. Tests validate cache behavior, gap planning, pruning, identity safety, and round-trip fidelity.

```mermaid
graph TB
subgraph "ETF Spread Monitoring"
ETF_CACHE["etf_spread/cache.py"]
ETF_CONFIG["etf_spread/config.py"]
ETF_TESTS["tests/test_cache.py"]
end
subgraph "FI Index Change"
FI_INDEX_CACHE["fi_index_change/cache.py"]
FI_INDEX_CONFIG["fi_index_change/config.py"]
end
subgraph "FI Spread Movement Monitoring"
FI_SPREAD_CACHE["fi_spread_movement/cache.py"]
FI_SPREAD_CONFIG["fi_spread_movement/config.py"]
FI_SPREAD_TESTS["tests/test_cache.py"]
end
ETF_CACHE --> ETF_CONFIG
ETF_TESTS --> ETF_CACHE
FI_INDEX_CACHE --> FI_INDEX_CONFIG
FI_SPREAD_CACHE --> FI_SPREAD_CONFIG
FI_SPREAD_TESTS --> FI_SPREAD_CACHE
```

**Diagram sources**
- [cache.py:1-583](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L583)
- [config.py:1-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L1-L140)
- [test_cache.py:1-882](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L1-L882)
- [cache.py:1-230](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L230)
- [config.py:1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [cache.py:1-441](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L441)
- [config.py:1-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L389)
- [test_cache.py:1-308](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L308)

**Section sources**
- [cache.py:1-583](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L583)
- [cache.py:1-230](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L230)
- [cache.py:1-441](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L441)

## Core Components
Each project implements a focused cache layer:

| Project | Cache Purpose | Primary Storage Key | Invalidation Tokens | Concurrency / Safety Notes |
|---|---|---|---|---|
| ETF Spread Monitoring | Daily historical series per kind | Kind + fingerprint + generation + column contract | `SERIES_CONTRACT`, `CACHE_GENERATION`, `fingerprint(functions)` | Never raises on read; corrupt or mismatched files fall back to no cache. Identity ledger prevents serving old security rows under a reused ticker. |
| FI Index Change | Monthly index composition snapshots | Index ticker + as-of date | `FIELD_CONTRACT`, `LABEL_CONTRACT`, `CACHE_GENERATION`, required columns | Refuses snapshots without usable weights or missing identity columns. Generation bump clears poisoned months. |
| FI Spread Movement Monitoring | Complete ranked run results | Run key including source, universe, AIM value, spread, dates, top N | `CACHE_GENERATION`, sequence number, file sizes | Pruning keeps newest runs; truncated files are rejected; cached runs are labeled cached, never updated. |

Key behaviors shared across implementations:
- CSV stores raw data; JSON manifests store metadata such as generation, contract, row counts, and file names.
- Read paths create no directories; write paths create directories only when needed.
- Invalid or corrupted cache entries are treated as absent rather than failing the application.
- Generation and contract tokens ensure that code or schema changes invalidate old files.

**Section sources**
- [cache.py:29-61](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L29-L61)
- [cache.py:28-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L28-L57)
- [cache.py:48-58](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L48-L58)

## Architecture Overview
The cache architecture separates three concerns:
1. **Storage format**: CSV data plus a JSON manifest.
2. **Validity policy**: Contract tokens, generation tokens, column checks, weight checks, and identity checks.
3. **Lifecycle operations**: Read, save, merge, plan gaps, prune, and describe.

```mermaid
flowchart TD
Start(["Cache Operation"]) --> CheckManifest["Read manifest.json"]
CheckManifest --> ValidContract{"Contract and generation valid?"}
ValidContract --> |No| Fallback["Treat as no cache"]
ValidContract --> |Yes| LoadData["Load CSV data"]
LoadData --> ValidateSchema["Validate columns, types, and values"]
ValidateSchema --> |Invalid| Fallback
ValidateSchema --> |Valid| ApplyPolicy["Apply project-specific policy"]
ApplyPolicy --> ETF["ETF: fingerprint + identity ledger"]
ApplyPolicy --> FI_INDEX["FI Index: field contract + weight check"]
ApplyPolicy --> FI_SPREAD["FI Spread: run key + size check"]
ETF --> Result(["Return cached frame or None"])
FI_INDEX --> Result
FI_SPREAD --> Result
```

**Diagram sources**
- [cache.py:120-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L164)
- [cache.py:91-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L91-L196)
- [cache.py:75-153](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L75-L153)

**Section sources**
- [cache.py:120-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L164)
- [cache.py:91-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L91-L196)
- [cache.py:75-153](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L75-L153)

## Detailed Component Analysis

### ETF Spread Monitoring Cache
This cache stores daily historical series for four kinds: quotes, returns, navs, and flows. It does not build requests; it stores raw request output and lets derived metrics be recomputed after merging.

#### Storage Format
- One CSV per kind: `quotes.csv`, `returns.csv`, `navs.csv`, `flows.csv`.
- Columns include identifier, date, and kind-specific numeric fields.
- Manifest records contract, generation, series metadata, and an optional identity ledger.

#### Invalidation Strategy
- `SERIES_CONTRACT` encodes stored column names per kind.
- `CACHE_GENERATION` marks the meaning of stored rows.
- `fingerprint(functions)` hashes builder source to detect changes in items, parameters, currency, fill rules, or date arguments.
- Identity ledger maps normalized identifiers to resolved securities; mismatches drop affected rows.

#### Gap Planning and Merge
- `plan_gaps` computes which date ranges still need Bloomberg calls.
- Missing identifiers get the full requested window.
- Late heads and tails get absolute windows so relative windows do not leave gaps.
- Weekend-only gaps are skipped to avoid useless requests.
- `merge` combines stored rows with live frames, letting live rows win on duplicate ID+date keys.

#### Concurrency and Consistency
- Reads never raise; unreadable files become empty cache hits.
- Writes use temporary files and atomic replace where possible.
- Settled rows before a settlement boundary are written; live sessions are not persisted.
- Empty or partially parsed frames are refused to prevent poisoned cache entries.

```mermaid
sequenceDiagram
participant App as "ETF Refresh"
participant Cache as "ETF cache"
participant Disk as "CSV + manifest"
participant BQL as "Bloomberg BQL"
App->>Cache : read_series(kind, root, fingerprint, identities)
Cache->>Disk : read manifest
Disk-->>Cache : series entry or empty
Cache->>Disk : load kind CSV
Disk-->>Cache : validated frame or empty
Cache->>Cache : apply identity ledger
alt No usable cache
Cache->>App : return empty
App->>BQL : request missing gaps
BQL-->>App : live frames
App->>Cache : save(kind, settled_rows, settled_before, fingerprint, identities)
Cache->>Disk : write CSV + manifest
else Usable cache
Cache-->>App : return cached frame
end
```

**Diagram sources**
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

**Section sources**
- [cache.py:1-61](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L61)
- [cache.py:64-108](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L108)
- [cache.py:167-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L167-L231)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)
- [test_cache.py:34-75](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L75)
- [test_cache.py:138-260](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L138-L260)
- [test_cache.py:263-382](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L263-L382)
- [test_cache.py:384-405](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L384-L405)
- [test_cache.py:407-458](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L407-L458)
- [test_cache.py:460-481](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L460-L481)
- [test_cache.py:547-800](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L547-L800)

### FI Index Change Cache
This cache stores monthly index composition snapshots. Historical months are immutable for one field contract. The projected month is not written here.

#### Storage Format
- One CSV per index ticker and as-of date.
- Required columns include identity fields and Weight.
- Manifest records field contract, generation, file name, row count, whether Weight exists, and recorded columns.

#### Invalidation Strategy
- `FIELD_CONTRACT` includes frozen item names and label mapping tokens.
- `LABEL_CONTRACT` includes country overrides, MBS/TBA label, municipal label, and rating-missing sentinel.
- `CACHE_GENERATION` must be bumped when stored snapshots would be wrong under new code.
- Snapshots without usable weights or without any usable identity value are rejected.

#### Load and Save Flow
- `load_historical` validates manifest, generation, required columns, numeric parsing, and identity usability.
- `save_historical` refuses unusable snapshots and writes sanitized string columns plus the manifest entry.

```mermaid
flowchart TD
Load["load_historical(index_ticker, as_of)"] --> ReadManifest["Read manifest"]
ReadManifest --> EntryFound{"Entry exists?"}
EntryFound --> |No| ReturnNone["Return None"]
EntryFound --> |Yes| CheckFields["Check FIELD_CONTRACT and has_weight"]
CheckFields --> CheckGen["Check CACHE_GENERATION"]
CheckGen --> CheckColumns["Check required columns"]
CheckColumns --> LoadCSV["Load CSV"]
LoadCSV --> ValidateNumeric["Parse numeric columns"]
ValidateNumeric --> CheckWeight["Check Weight has values"]
CheckWeight --> CheckIdentity["Check at least one identity column has usable value"]
CheckIdentity --> |Fail| ReturnNone
CheckIdentity --> |Pass| ReturnFrame["Return frame"]
```

**Diagram sources**
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-230](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L230)

**Section sources**
- [cache.py:1-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L57)
- [cache.py:60-84](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L84)
- [cache.py:108-119](file://User scripts/FI Index Change/fi_index_change/cache.py#L108-L119)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-230](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L230)

### FI Spread Movement Monitoring Cache
This cache stores complete run results for one universe, spread type, and window. It is a result cache, not a security master. Cached runs are explicitly labeled cached and are not used as a default speed path during normal updates.

#### Storage Format
- Three CSVs per run: ranked results, descriptors, and spread series.
- Manifest records generation, sequence number, saved timestamp, source, universe, comparison flag, request metadata, row counts, file names, byte sizes, field status, and request log.

#### Run Keying
- `run_key` includes generation, source key, universe key, AIM value, spread code, start date, end date, and top N.
- Including top N prevents serving a narrower cached table when the operator increases the ranking width.

#### Lifecycle Operations
- `save_run` refuses missing or empty ranked results and persists all parts.
- `has_run` checks generation, file existence, and recorded byte sizes to reject truncated writes.
- `load_run` reconstructs a `FetchResult` with typed numeric and date columns.
- `prune` keeps the newest runs by sequence number and removes orphaned CSVs.

```mermaid
sequenceDiagram
participant App as "Spread Monitor App"
participant Cache as "Spread cache"
participant Disk as "CSV + manifest"
App->>Cache : save_run(key, result)
Cache->>Disk : write ranked, descriptors, series
Cache->>Disk : write manifest with seq and bytes
App->>Cache : has_run(key)
Cache->>Disk : read manifest
Cache->>Disk : verify file sizes
Disk-->>Cache : consistent or inconsistent
App->>Cache : load_run(key)
Cache->>Disk : read CSVs
Cache-->>App : FetchResult + info
```

**Diagram sources**
- [cache.py:102-139](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L139)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:257-286](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L286)
- [cache.py:289-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L289-L348)
- [cache.py:379-427](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L427)

**Section sources**
- [cache.py:1-58](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L58)
- [cache.py:63-99](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L63-L99)
- [cache.py:102-153](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L153)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)
- [cache.py:379-441](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L441)
- [test_cache.py:150-303](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L150-L303)

## Dependency Analysis
The cache modules depend on pandas for DataFrame handling, standard library modules for filesystem and JSON operations, and project-specific configuration constants.

```mermaid
graph LR
ETF_CACHE["ETF cache.py"] --> PANDAS["pandas"]
ETF_CACHE --> STD["Python stdlib"]
ETF_CACHE --> ETF_CONFIG["ETF config.py"]
FI_INDEX_CACHE["FI Index cache.py"] --> PANDAS
FI_INDEX_CACHE --> STD
FI_INDEX_CACHE --> FI_INDEX_CONFIG["FI Index config.py"]
FI_SPREAD_CACHE["FI Spread cache.py"] --> PANDAS
FI_SPREAD_CACHE --> STD
FI_SPREAD_CACHE --> FI_SPREAD_CONFIG["FI Spread config.py"]
```

**Diagram sources**
- [cache.py:16-26](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L16-L26)
- [cache.py:6-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L6-L26)
- [cache.py:38-46](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L38-L46)

**Section sources**
- [cache.py:16-26](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L16-L26)
- [cache.py:6-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L6-L26)
- [cache.py:38-46](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L38-L46)

## Performance Considerations
The caches are designed around Bloomberg Desktop’s two-minute query limit and large index universes.

Key performance characteristics:
- ETF Spread Monitoring reduces Bloomberg calls by storing settled daily history and requesting only missing days. It also splits work by identifier coverage and avoids weekend-only gaps.
- FI Index Change avoids repeated full-month requests by reusing immutable snapshots when contracts match.
- FI Spread Movement Monitoring treats the cache as a safety net: normal updates ask Bloomberg first, and cached results are used explicitly or after timeouts.

Configuration-related tuning points:
- ETF Spread Monitoring uses a five-year relative window anchor and a fixed business-day horizon constant.
- FI Index Change enables split requests and bounded query attempts to stay within timeout limits.
- FI Spread Movement Monitoring exposes `CACHE_KEEP_RUNS`, `CACHE_READ_FIRST`, and `QUERY_ATTEMPTS`.

Optimization recommendations:
- Keep `CACHE_KEEP_RUNS` small enough to control disk growth while retaining recent fallback runs.
- Avoid enabling `CACHE_READ_FIRST` unless the operator explicitly wants cached results instead of fresh Bloomberg calls.
- Use generation bumps when pipeline logic changes so old cached outputs cannot masquerade as correct.
- Prefer narrow windows and bounded top-N values to keep ranked results manageable.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Common Cache Symptoms
| Symptom | Likely Cause | Recommended Action |
|---|---|---|
| Cache is ignored after a code change | Generation or contract token changed | Verify `CACHE_GENERATION` and contract constants; bump generation when stored data would be wrong. |
| Old security rows appear under a reused ticker | Identity ledger mismatch was not detected | Ensure current identity resolution is passed to read/save functions; tests show stale identities should drop rows. |
| Corrupted CSV is served forever | Read path did not validate schema or values | Confirm column validation, numeric coercion, and “no value” rejection logic. |
| Truncated CSV is served | File size mismatch was not checked | For FI Spread Movement Monitoring, rely on `has_run` byte-size checks; delete and rerun. |
| Cache directory creation fails on read-only folder | Read path created directories | All three caches avoid creating directories on read; verify write-only creation. |
| Cached run shows fewer rows than expected | Partial write or pruned run | Check manifest sequence and file sizes; prune conservatively and rerun. |

### Diagnostic Steps
1. Inspect `manifest.json` in the project’s `cache` directory.
2. Compare `generation` and contract tokens with current code constants.
3. Verify CSV column names and required fields.
4. For ETF spreads, check identity mappings between stored identifiers and current resolved securities.
5. For FI spreads, confirm the run key includes universe, spread, dates, and top N.
6. Use pruning carefully: it deletes oldest runs by sequence number and removes orphaned CSVs.

**Section sources**
- [test_cache.py:34-75](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L75)
- [test_cache.py:263-382](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L263-L382)
- [cache.py:257-286](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L286)
- [test_cache.py:226-282](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L226-L282)

## Conclusion
The cache management system provides three complementary layers of performance protection for large Bloomberg BQL workflows:
- ETF Spread Monitoring optimizes daily history retrieval through incremental gap filling and identity-safe reuse.
- FI Index Change stabilizes monthly index composition reads through strict field and weight validation.
- FI Spread Movement Monitoring preserves complete run results for transparent fallback after timeouts.

Across all three, correctness is prioritized over speed: invalidation tokens, schema validation, identity checks, and explicit labeling of cached data prevent silent staleness. For large-scale deployments, tune retention via pruning, avoid automatic cache-first reads unless intentional, and bump generation tokens whenever stored outputs could be misinterpreted by newer code.

[No sources needed since this section summarizes without analyzing specific files]