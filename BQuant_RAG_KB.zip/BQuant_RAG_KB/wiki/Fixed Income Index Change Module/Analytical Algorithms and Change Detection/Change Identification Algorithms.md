# Change Identification Algorithms

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [test_engine.py](file://User scripts/FI Index Change/tests/test_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the change identification algorithms used by the Fixed Income Index Change module. The core objective is to compare two index membership snapshots and identify which securities were added, exited, or retained between a previous month-end and a selected month-end.

The implementation distinguishes two security books:
- Standard bonds
- MBS/TBA pass-throughs and related mortgage identifiers

It also handles edge cases such as duplicate IDs, blank or missing identity fields, partial weight changes, security reclassifications across months, and book-specific filtering.

## Project Structure
The relevant code lives under the FI Index Change application:
- `fi_index_change/engine.py` implements membership preparation, label alignment, ID diffing, summary aggregation, and display/export helpers.
- `fi_index_change/data.py` requests Bloomberg BQL data, parses responses, merges item frames, caches historical snapshots, and prepares final member frames.
- `fi_index_change/config.py` defines constants for default books, labels, bucket sizes, request behavior, and weight scaling thresholds.
- `tests/test_engine.py` validates date logic, book separation, ID diffs, label alignment, summaries, export formatting, and chart ordering.

```mermaid
graph TB
Data["data.py<br/>BQL fetch, parse, cache"] --> Engine["engine.py<br/>prepare, align, diff, summarize"]
Config["config.py<br/>constants, defaults"] --> Engine
Tests["tests/test_engine.py<br/>unit contracts"] --> Engine
Engine --> Dashboard["Dashboard / Export"]
```

**Diagram sources**
- [data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [test_engine.py:1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)

**Section sources**
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [test_engine.py:1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)

## Core Components
The change identification pipeline has four main stages:

1. **Snapshot normalization**: Convert raw index membership rows into a prepared frame with normalized IDs, weights, book classification, country/sector/rating buckets, and tenor buckets.
2. **Label alignment**: Ensure that display categories for common IDs are consistent across the previous and latest snapshots.
3. **ID diffing**: Compare ID sets within the selected book to find additions and exits.
4. **Summary and export**: Aggregate changes by dimension and produce export-ready tables.

Key functions:
- `prepare_members`: Normalizes one snapshot and assigns Book, Country, Sector, Currency, Rating Bucket, and Tenor Bucket.
- `align_snapshot_labels`: Aligns display labels for common IDs so a security does not appear under conflicting classifications.
- `diff_members`: Compares ID sets inside a book and returns previous, latest, added, and exited frames.
- `summarize`: Aggregates changes by dimension and computes turnover metrics.
- `change_export_frame`: Produces an export table of Add and Exit rows.

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)

## Architecture Overview
The system separates data acquisition from analytical logic.

```mermaid
sequenceDiagram
participant User as "User"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
participant UI as "Dashboard / Export"
User->>Data : Request selected month and previous month
Data->>BQL : Execute member request(s)
BQL-->>Data : Raw response items
Data->>Data : Parse, merge, collapse duplicates
Data->>Engine : prepare_members()
Engine-->>Data : Prepared snapshot
Data->>Engine : align_snapshot_labels(previous, latest)
Engine-->>Data : Aligned snapshots
Data->>Engine : build_transition()
Engine-->>UI : Transition object
UI->>Engine : diff_members(previous, latest, book)
Engine-->>UI : Added and Exited frames
UI->>Engine : summarize(...)
Engine-->>UI : Summary and headline
```

**Diagram sources**
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

## Detailed Component Analysis

### Snapshot Preparation and Book Classification
`prepare_members` performs the following:
- Drops blank IDs.
- Collapses duplicate IDs while preserving the last non-null value per column.
- Converts weights to numeric and scales fraction-weighted snapshots to percent points when the net or absolute sum indicates fractions.
- Normalizes text columns and applies country name overrides and title-casing.
- Assigns `Book`:
  - MBS/TBA/Pool-like Security Type or IDs containing “Mtge” become `MBS/TBA`.
  - Otherwise, `Standard`.
- Fills MBS/TBA blanks for Country/Sector with the MBS/TBA label and blank Currency with USD.
- Treats US municipal bonds (IDs ending with a configured suffix) as Standard, always USD, and rating-not-applicable.
- Computes Tenor Bucket and Rating Bucket, marking MBS/TBA tenor as not applicable when missing.

```mermaid
flowchart TD
Start(["Input snapshot"]) --> NormalizeID["Normalize ID<br/>drop blanks"]
NormalizeID --> CollapseDup["Collapse duplicate IDs"]
CollapseDup --> NumericWeight["Convert Weight<br/>scale fractions if needed"]
NumericWeight --> TextColumns["Normalize text columns"]
TextColumns --> AssignBook["Assign Book:<br/>MBS/TBA vs Standard"]
AssignBook --> MunicipalFill["Apply Municipal rules"]
MunicipalFill --> TenorBucket["Compute Tenor Bucket"]
TenorBucket --> RatingBucket["Compute Rating Bucket"]
RatingBucket --> End(["Prepared snapshot"])
```

**Diagram sources**
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

**Section sources**
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

### Label Alignment Across Months
`align_snapshot_labels` ensures that display categories for common IDs do not differ between snapshots. It:
- Collapses duplicate IDs before alignment.
- Identifies common IDs.
- For each aligned label column, chooses the latest usable value; if missing, falls back to the previous value.
- Applies special handling for Rating Bucket and Rating text so that NR is treated as a real classification and does not silently inherit an old IG/HY label.

```mermaid
flowchart TD
Start(["Previous and Latest snapshots"]) --> CommonIDs["Find common IDs"]
CommonIDs --> LoopColumns["For each aligned label column"]
LoopColumns --> ChooseLatest{"Latest usable?"}
ChooseLatest --> |Yes| UseLatest["Use latest value"]
ChooseLatest --> |No| CheckPrevious{"Previous usable?"}
CheckPrevious --> |Yes| UsePrevious["Use previous value"]
CheckPrevious --> |No| KeepLatest["Keep latest sentinel"]
UseLatest --> ApplyBoth["Apply mapping to both snapshots"]
UsePrevious --> ApplyBoth
KeepLatest --> ApplyBoth
ApplyBoth --> RatingSpecial["Align Rating Bucket and Rating text"]
RatingSpecial --> End(["Aligned snapshots"])
```

**Diagram sources**
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)

**Section sources**
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)

### Membership Diff Algorithm: `diff_members`
`diff_members` compares bond membership between two prepared snapshots for a selected book. Its inputs are:
- `previous`: prepared snapshot for the previous month-end.
- `latest`: prepared snapshot for the selected month-end.
- `book`: one of `All`, `Standard`, or `MBS/TBA`.

Algorithm steps:
1. Filter each snapshot by book.
2. Build ID sets from the filtered frames.
3. Compute additions as IDs present in latest but not in previous.
4. Compute exits as IDs present in previous but not in latest.
5. Sort added and exited frames by weight descending when available.

Mathematical formulation:
Let:
- \( P \) be the set of IDs in the previous snapshot after book filtering.
- \( L \) be the set of IDs in the latest snapshot after book filtering.

Then:
\[
\text{Additions} = L \setminus P
\]
\[
\text{Exits} = P \setminus L
\]
\[
\text{Retained} = P \cap L
\]

If \( \text{Additions} = \emptyset \) and \( \text{Exits} = \emptyset \), the book is unchanged.

```mermaid
flowchart TD
Start(["previous, latest, book"]) --> FilterPrev["Filter previous by book"]
Start --> FilterLat["Filter latest by book"]
FilterPrev --> SetP["Build ID set P"]
FilterLat --> SetL["Build ID set L"]
SetP --> Additions["Additions = L - P"]
SetL --> Exits["Exits = P - L"]
Additions --> SortAdded["Sort added by Weight desc"]
Exits --> SortExited["Sort exited by Weight desc"]
SortAdded --> Return(["previous_book, latest_book, added, exited"])
SortExited --> Return
```

**Diagram sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

### Book Filtering Logic
The book filter determines whether analysis focuses on:
- All securities
- Standard bonds only
- MBS/TBA pass-throughs and mortgage-related IDs only

Rules:
- Default book is `All`.
- Book assignment uses Security Type patterns and ID patterns.
- MBS/TBA rows receive special treatment for Country, Sector, Currency, Tenor Bucket, and Rating Bucket.
- Municipal bonds remain Standard and are forced to USD with no applicable rating.

Edge case handling:
- If a row’s Security Type contains MBS, TBA, or Pool, it is classified as MBS/TBA.
- If an ID contains “Mtge”, it is classified as MBS/TBA.
- Blank Country/Sector/Currency on MBS/TBA rows are replaced with MBS/TBA or USD rather than treated as missing.
- Tenor Bucket for MBS/TBA is marked N.A. when missing because these instruments settle forward and do not have a conventional maturity-based tenor.

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [config.py:12-15](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L15)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

### Edge Cases

#### Duplicate IDs
Duplicate IDs can arise from multiple response items or multi-column vendor responses. The system collapses duplicates by keeping the last non-null value per column after forward-filling within the group. This avoids accidentally selecting a null row over a populated row.

Behavior:
- Duplicates are detected and logged.
- Forward-fill preserves values before collapsing.
- The result is one row per ID.

**Section sources**
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)
- [data.py:256-262](file://User scripts/FI Index Change/fi_index_change/data.py#L256-L262)

#### Partial Weight Changes
A retained security may change its weight without being an addition or exit. The diff algorithm treats this as retention, not a change. Weight changes affect:
- Begin/End counts and weights in summaries.
- Turnover calculations.
- Weighted analytics such as OAS, spreads, duration, and yield.

Example scenario:
- Previous: ID A, weight 2.0
- Latest: ID A, weight 2.5
- Result: Not added, not exited; retained with a positive weight delta.

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:872-882](file://User scripts/FI Index Change/fi_index_change/engine.py#L872-L882)
- [engine.py:908-950](file://User scripts/FI Index Change/fi_index_change/engine.py#L908-L950)

#### Security Reclassifications
Reclassification includes changes such as:
- Standard to MBS/TBA
- Country or Sector changes
- Rating bucket changes
- Tenor bucket changes

The alignment step prevents a common ID from appearing under conflicting classifications. If the latest snapshot has a usable label, it wins; otherwise, the previous label fills both sides. For MBS/TBA or Municipal rows, NR is treated as a real classification and does not inherit an old IG/HY label.

**Section sources**
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)

#### Blank or Missing Identity Fields
Blank IDs are dropped entirely. Missing or empty identity columns are recorded as notes and may cause a snapshot to be marked partial. Missing numeric fields are coerced to NaN and handled gracefully in weighted averages.

**Section sources**
- [engine.py:371-389](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L389)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

### Change Scenarios

#### Complete Addition
- Previous ID set: {A}
- Latest ID set: {A, B}
- Result: B is added; A is retained.

#### Complete Exit
- Previous ID set: {A, B}
- Latest ID set: {A}
- Result: B is exited; A is retained.

#### Partial Weight Modification
- Previous ID set: {A}, weight 2.0
- Latest ID set: {A}, weight 2.5
- Result: No addition, no exit; retained with changed weight.

#### Mixed Scenario
- Previous: {A, B}
- Latest: {B, C}
- Result: A exited, C added, B retained.

These scenarios are validated by unit tests covering add/exit detection, book separation, and unchanged-book checks.

**Section sources**
- [test_engine.py:264-329](file://User scripts/FI Index Change/tests/test_engine.py#L264-L329)

## Dependency Analysis
The change identification logic depends on several modules:

- `engine.py` imports configuration constants and field library definitions.
- `data.py` imports engine functions for preparing and aligning snapshots.
- `config.py` provides default book, labels, thresholds, and request behavior.
- `tests/test_engine.py` imports engine functions and validates their contracts.

```mermaid
graph LR
Config["config.py"] --> Engine["engine.py"]
FieldLibrary["field_library.py"] --> Engine
Engine --> Data["data.py"]
Engine --> Tests["tests/test_engine.py"]
```

**Diagram sources**
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:16-25](file://User scripts/FI Index Change/fi_index_change/data.py#L16-L25)
- [test_engine.py:22-46](file://User scripts/FI Index Change/tests/test_engine.py#L22-L46)

**Section sources**
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:16-25](file://User scripts/FI Index Change/fi_index_change/data.py#L16-L25)
- [test_engine.py:22-46](file://User scripts/FI Index Change/tests/test_engine.py#L22-L46)

## Performance Considerations
- Duplicate collapsing uses pandas groupby and forward-fill, which is efficient for typical index membership sizes.
- Label alignment computes the common ID mask once and reuses it across columns.
- Weight scaling detects fraction versus percent units using net and absolute sums, avoiding unnecessary multiplication.
- The diff operation uses set membership, giving near-constant-time lookups for ID comparisons.
- Analytics weighting skips nulls, bad weights, and extreme OAS sentinel values.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their signals:

- **No Data Access License**: Membership access failure is detected through keywords such as entitlement, permission, license, unauthorized, or 403.
- **Partial Snapshot**: When required items did not parse or identity columns arrived empty, the snapshot status is marked partial and warnings are attached.
- **Unavailable Comparison**: If either snapshot is missing, empty, or lacks required Weight values, the transition status becomes unavailable.
- **Duplicate IDs**: Logs report how many duplicate IDs were dropped and that the last non-null value was kept.
- **Fraction Weights**: Logs indicate when weights were scaled from fractions to percent points.

Recommended actions:
- Verify Bloomberg BQL entitlements for the index and requested fields.
- Check logs for missing or empty identity columns.
- Confirm that the selected month-end is allowed by the dropdown.
- Inspect the transition status and warnings before interpreting charts.

**Section sources**
- [engine.py:104-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L104-L119)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

## Conclusion
The FI Index Change module identifies membership changes by comparing ID sets across two prepared snapshots, filtered by book. Additions and exits are pure ID differences; retained securities may still change weight and analytics. Label alignment ensures that display categories remain consistent across months, preventing misleading reclassifications. The design separates data acquisition, normalization, alignment, diffing, and summarization, making the change identification logic transparent, testable, and robust against common data quality issues.

[No sources needed since this section summarizes without analyzing specific files]