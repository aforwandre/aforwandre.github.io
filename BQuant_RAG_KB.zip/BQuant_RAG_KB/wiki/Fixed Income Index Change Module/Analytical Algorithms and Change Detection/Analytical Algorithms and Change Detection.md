# Analytical Algorithms and Change Detection

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [test_engine.py](file://User scripts/FI Index Change/tests/test_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the analytical algorithms and change detection mechanisms used by the Fixed Income Index Change module. It focuses on how the system identifies bond additions and exits between index snapshots, how membership changes are compared, how turnover is calculated, and how dimensional filtering supports analysis by country, sector, tenor bucket, rating bucket, currency, book, spreads, duration, and yield. It also documents weight-based metrics, mathematical formulations, and edge cases such as partial weight changes and security reclassifications.

The module compares two month-end snapshots:
- Previous month-end: the prior effective date.
- Selected month-end: the chosen effective date, which may be historical or projected.

Change detection is based on security identifiers rather than display attributes. A bond that remains in the index but changes country, sector, rating, or weight is not treated as an add or exit unless its identifier changes.

## Project Structure
The FI Index Change module is organized into layered components:
- `app.py`: Dashboard controller, widgets, and user-facing logic.
- `data.py`: BQL request orchestration, response parsing, caching, and snapshot assembly.
- `engine.py`: Core analytical algorithms, normalization, comparison, summarization, and export formatting.
- `field_library.py`: Frozen data item contract for Bloomberg BQL requests.
- `config.py`: Operational constants, defaults, and UI layout configuration.
- `tests/test_engine.py`: Unit tests validating scheduling, diffing, alignment, weighting, turnover, and edge cases.

```mermaid
graph TB
App["app.py<br/>Dashboard Controller"] --> Data["data.py<br/>BQL Request & Snapshot Assembly"]
App --> Engine["engine.py<br/>Algorithms & Summarization"]
Data --> FieldLibrary["field_library.py<br/>Frozen Item Contract"]
Data --> Config["config.py<br/>Operational Constants"]
Engine --> Config
Tests["tests/test_engine.py<br/>Algorithm Validation"] --> Engine
Tests --> Data
```

**Diagram sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-30](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L30)
- [field_library.py:1-20](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L20)
- [config.py:1-15](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L15)
- [test_engine.py:1-25](file://User scripts/FI Index Change/tests/test_engine.py#L1-L25)

**Section sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-30](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L30)
- [field_library.py:1-20](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L20)
- [config.py:1-15](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L15)
- [test_engine.py:1-25](file://User scripts/FI Index Change/tests/test_engine.py#L1-L25)

## Core Components
The core analytical engine provides:
- Date selection and schedule validation.
- Snapshot preparation and normalization.
- Label alignment across snapshots.
- Membership difference computation.
- Dimensional filtering and summarization.
- Turnover calculation with optional index market value ratio.
- Export and display formatting.

Key responsibilities:
- `engine.py`: Implements all analytical algorithms and state transitions.
- `data.py`: Orchestrates live and cached data retrieval and merges BQL responses.
- `app.py`: Wires user inputs to the engine and renders charts and tables.
- `field_library.py`: Defines the frozen set of fields requested from Bloomberg.
- `config.py`: Controls defaults, chart sizing, request splitting, and retry behavior.

**Section sources**
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-668](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L668)
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [field_library.py:58-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L75)
- [config.py:12-20](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L20)

## Architecture Overview
The end-to-end flow begins when the user clicks Update:
1. The app validates the index ticker and selected month-end.
2. The data layer fetches the previous and selected snapshots, using cache for historical dates.
3. Responses are parsed, merged, and normalized into prepared member frames.
4. Labels are aligned so classification columns agree across both snapshots.
5. The engine computes membership differences and applies dimension filters.
6. Summaries and turnover metrics are computed per dimension.
7. Charts and tables are rendered; exports are formatted for Excel copy/paste.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant Cache as "cache"
participant Engine as "engine.py"
participant BQL as "Bloomberg BQL"
User->>App : Click Update
App->>App : Validate index and month-end
App->>Data : fetch_index_payload(index, selected_date)
Data->>Cache : load_historical(previous_date)
alt Historical cache hit
Cache-->>Data : Cached frame
else No cache or invalid
Data->>BQL : Request members(previous_date)
BQL-->>Data : Response items
Data->>Data : Parse and merge items
end
Data->>BQL : Request members(selected_date)
BQL-->>Data : Response items
Data->>Data : Parse and merge items
Data->>Engine : build_transition(snapshots, comparison, statuses)
Engine->>Engine : align_snapshot_labels(previous, latest)
Engine->>Engine : diff_members(previous, latest, book)
Engine->>Engine : summarize(transition, dimension, book, filters)
Engine-->>App : Transition + Summary
App-->>User : Render charts, tables, and exports
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:643-668](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L668)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

## Detailed Component Analysis

### Membership Change Detection
Membership changes are determined by comparing security identifiers between the previous and selected snapshots within a selected book. Additions are IDs present in the latest snapshot but absent in the previous snapshot; exits are IDs present in the previous snapshot but absent in the latest snapshot. Sorting by weight places larger changes first.

```mermaid
flowchart TD
Start(["diff_members Entry"]) --> FilterBook["Filter by Book<br/>All / Standard / MBS/TBA"]
FilterBook --> ExtractIDs["Extract ID Sets<br/>Previous IDs, Latest IDs"]
ExtractIDs --> Added["Added = Latest - Previous"]
ExtractIDs --> Exited["Exited = Previous - Latest"]
Added --> SortAdded{"Has Weight?"}
Exited --> SortExited{"Has Weight?"}
SortAdded --> |Yes| SortAddedW["Sort Added by Weight Descending"]
SortAdded --> |No| KeepAdded["Keep Added Order"]
SortExited --> |Yes| SortExitedW["Sort Exited by Weight Descending"]
SortExited --> |No| KeepExited["Keep Exited Order"]
SortAddedW --> Return(["Return Previous, Latest, Added, Exited"])
KeepAdded --> Return
SortExitedW --> Return
KeepExited --> Return
```

**Diagram sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [test_engine.py:264-329](file://User scripts/FI Index Change/tests/test_engine.py#L264-L329)

### Snapshot Preparation and Normalization
Snapshot preparation normalizes raw BQL responses:
- Drops blank or duplicate IDs.
- Scales weights from fractions to percent points when the net sum indicates a fraction basis.
- Converts numeric fields and replaces infinities with nulls.
- Normalizes text fields and applies country name overrides.
- Classifies bonds into books: Standard vs MBS/TBA.
- Assigns special labels for MBS/TBA and Municipal bonds.
- Computes Tenor Bucket and Rating Bucket classifications.

```mermaid
flowchart TD
Start(["prepare_members Entry"]) --> CheckEmpty["Check Empty or Missing ID"]
CheckEmpty --> DropBlank["Drop Blank IDs"]
DropBlank --> CollapseDup["Collapse Duplicate IDs<br/>Last Non-null Wins"]
CollapseDup --> ScaleWeight["Scale Weights if Fraction Basis"]
ScaleWeight --> NumericFields["Convert Numeric Fields<br/>Tenor, Coupon, Spreads, Duration, Yield"]
NumericFields --> TextFields["Normalize Text Fields<br/>Country, Sector, Currency, Security Type, Rating, Name, Issuer"]
TextFields --> CountryOverride["Apply Country Overrides<br/>and Proper Case"]
CountryOverride --> BookClassify["Classify Book<br/>Standard vs MBS/TBA"]
BookClassify --> SpecialLabels["Assign MBS/TBA and Municipal Labels"]
SpecialLabels --> TenorBucket["Compute Tenor Bucket"]
TenorBucket --> RatingBucket["Compute Rating Bucket<br/>IG / HY / NR"]
RatingBucket --> Output(["Normalized Snapshot"])
```

**Diagram sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [engine.py:335-350](file://User scripts/FI Index Change/fi_index_change/engine.py#L335-L350)

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [engine.py:335-350](file://User scripts/FI Index Change/fi_index_change/engine.py#L335-L350)
- [test_engine.py:322-329](file://User scripts/FI Index Change/tests/test_engine.py#L322-L329)
- [test_engine.py:1202-1218](file://User scripts/FI Index Change/tests/test_engine.py#L1202-L1218)

### Label Alignment Across Snapshots
Label alignment ensures that classification columns (Book, Country, Sector, Tenor Bucket, Currency, Rating Bucket) are consistent for common IDs across both snapshots. The latest non-missing label wins; if missing, the previous label fills both sides. This prevents a bond from appearing under multiple rating selections and avoids inheriting IG letters for NR rows.

```mermaid
flowchart TD
Start(["align_snapshot_labels Entry"]) --> CommonIDs["Find Common IDs"]
CommonIDs --> ForEachColumn["For Each Classification Column"]
ForEachColumn --> LatestWins{"Latest Usable Value?"}
LatestWins --> |Yes| UseLatest["Use Latest Value"]
LatestWins --> |No| PreviousFallback{"Previous Usable Value?"}
PreviousFallback --> |Yes| UsePrevious["Use Previous Value"]
PreviousFallback --> |No| Default["Default to Latest"]
UseLatest --> ApplyBoth["Apply Mapping to Both Snapshots"]
UsePrevious --> ApplyBoth
Default --> ApplyBoth
ApplyBoth --> RatingBucketSpecial["Handle Rating Bucket and Raw Rating Consistency"]
RatingBucketSpecial --> Output(["Aligned Snapshots"])
```

**Diagram sources**
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)

**Section sources**
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [test_engine.py:377-433](file://User scripts/FI Index Change/tests/test_engine.py#L377-L433)
- [test_engine.py:1265-1332](file://User scripts/FI Index Change/tests/test_engine.py#L1265-L1332)

### Dimensional Filtering System
Dimensional filtering allows analysis by:
- Country
- Sector
- Tenor Bucket
- Rating Bucket
- Currency
- Book
- Spread fields (OAS, Z-Spread, I-Spread)
- Duration fields (Duration, Modified Duration, Effective Duration, OASD)
- Yield fields (Yield, YTM, YTW)

Filters are applied after membership differences are computed, ensuring that Add and Exit lists reflect the active filter selections.

```mermaid
flowchart TD
Start(["apply_dimension_filters Entry"]) --> CheckFilters{"Filters Provided?"}
CheckFilters --> |No| ReturnOriginal["Return Original Frame"]
CheckFilters --> |Yes| BuildMask["Build Boolean Mask"]
BuildMask --> ForEachFilter["For Each Filter Column"]
ForEachFilter --> ApplyMask["Apply ISIN Selection Mask"]
ApplyMask --> NextFilter{"More Filters?"}
NextFilter --> |Yes| ForEachFilter
NextFilter --> |No| ReturnFiltered["Return Filtered Frame"]
```

**Diagram sources**
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)

**Section sources**
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)
- [app.py:205-212](file://User scripts/FI Index Change/fi_index_change/app.py#L205-L212)

### Turnover Calculation Formulas
Turnover measures rebalancing activity between snapshots. Two definitions are supported:
- Approximate turnover: Used when no index market value ratio is available.
- Official turnover: Uses the index market value ratio when provided.

Formulations:
- Bucket turnover: Exit Weight (previous) + Add Weight (selected) × (Ending Index MV / Beginning Index MV).
- Turnover rate: Bucket turnover / Begin Weight × 100.
- Headline turnover: Sum of Exit Weight and scaled Add Weight across all buckets.
- Headline turnover rate: Headline turnover / Total Begin Weight × 100.

When the index market value ratio is unavailable, the ratio defaults to 1.0, making Add Weight unadjusted.

```mermaid
flowchart TD
Start(["summarize Turnover Computation"]) --> GetRatio["Get Index MV Ratio"]
GetRatio --> EffectiveRatio{"Ratio Valid and Positive?"}
EffectiveRatio --> |Yes| UseOfficial["Use Official Ratio"]
EffectiveRatio --> |No| UseApprox["Use Approx Ratio = 1.0"]
UseOfficial --> BucketTurnover["Bucket Turnover = Exit Weight + Add Weight × Ratio"]
UseApprox --> BucketTurnover
BucketTurnover --> RateCalc{"Begin Weight > 0?"}
RateCalc --> |Yes| TurnoverRate["Turnover Rate = Bucket Turnover / Begin Weight × 100"]
RateCalc --> |No| NaNRate["Turnover Rate = NaN"]
TurnoverRate --> Aggregate["Aggregate Headline Turnover and Rate"]
NaNRate --> Aggregate
Aggregate --> Output(["Summary Row + Headline Metrics"])
```

**Diagram sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

**Section sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [test_engine.py:561-602](file://User scripts/FI Index Change/tests/test_engine.py#L561-L602)

### Weight-Based Metrics and Interpretation
Weight-based metrics include:
- Count: Number of unique IDs.
- Weight: Sum of weights.
- Weighted means for spreads, duration, yield, tenor, and coupon.
- OAS sentinel exclusion: Values at or above a configured threshold are excluded from weighted averages.

Interpretation:
- Weighted means represent the portfolio-level exposure to each metric.
- OAS exclusions prevent outlier vendor artifacts from skewing averages.
- Zero-coupon bonds remain included in weighted averages because zero is a valid coupon value.

```mermaid
flowchart TD
Start(["weighted_mean Entry"]) --> CheckFrame["Check Frame, Column, and Weight Presence"]
CheckFrame --> CoerceValues["Coerce Values and Replace Infinities"]
CoerceValues --> OASSpecial{"Column is OAS?"}
OASSpecial --> |Yes| ExcludeSentinel["Exclude OAS >= Threshold"]
OASSpecial --> |No| SkipExclude["Skip OAS Sentinel"]
ExcludeSentinel --> ValidMask["Valid = Not Null & Weight > 0"]
SkipExclude --> ValidMask
ValidMask --> Denominator["Denominator = Sum of Valid Weights"]
Denominator --> ComputeMean["Weighted Mean = Sum(Value × Weight) / Denominator"]
ComputeMean --> ReturnMean(["Return Weighted Mean or NaN"])
```

**Diagram sources**
- [engine.py:855-869](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L869)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)

**Section sources**
- [engine.py:855-869](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L869)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)
- [test_engine.py:332-345](file://User scripts/FI Index Change/tests/test_engine.py#L332-L345)

### Change Detection Scenarios and Edge Cases
Common scenarios:
- Pure addition: New ID appears only in the latest snapshot.
- Pure exit: ID disappears from the latest snapshot.
- Partial weight change: Same ID remains, but weight increases or decreases; not classified as add/exit.
- Reclassification: Country, sector, rating, or book changes without ID change; not classified as add/exit.
- MBS/TBA and Municipal special handling: Blank country/sector/currency are replaced with book-specific labels; rating is NR.
- Fraction vs percent weights: Fractions are scaled to percent points; small percent sets are not scaled.
- Missing or duplicate IDs: Dropped during preparation; duplicates resolved by last non-null value.
- Incomplete snapshots: Marked partial and not cached if required identity columns are missing or empty.

Examples validated by tests:
- Country change is not an add.
- Fraction weights scale once.
- MBS/TBA missing tenor is labeled N.A.
- Alignment keeps latest applicable label and prevents cross-classification inheritance.
- OAS sentinel exclusion works while preserving zero coupons.

**Section sources**
- [test_engine.py:278-329](file://User scripts/FI Index Change/tests/test_engine.py#L278-L329)
- [test_engine.py:355-376](file://User scripts/FI Index Change/tests/test_engine.py#L355-L376)
- [test_engine.py:377-433](file://User scripts/FI Index Change/tests/test_engine.py#L377-L433)
- [test_engine.py:1066-1104](file://User scripts/FI Index Change/tests/test_engine.py#L1066-L1104)
- [test_engine.py:1202-1218](file://User scripts/FI Index Change/tests/test_engine.py#L1202-L1218)

## Dependency Analysis
The module exhibits clear separation of concerns:
- `app.py` depends on `engine.py` for analytical results and `data.py` for payload retrieval.
- `data.py` depends on `engine.py` for normalization and alignment functions and on `field_library.py` for the frozen item contract.
- `engine.py` depends on `config.py` for operational constants and on `field_library.py` for field groupings.
- `tests/test_engine.py` validates core engine behavior and data pipeline assumptions.

```mermaid
graph TB
App["app.py"] --> Engine["engine.py"]
App --> Data["data.py"]
Data --> Engine
Data --> FieldLibrary["field_library.py"]
Engine --> Config["config.py"]
Engine --> FieldLibrary
Tests["tests/test_engine.py"] --> Engine
Tests --> Data
```

**Diagram sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [config.py:12-20](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L20)
- [test_engine.py:17-46](file://User scripts/FI Index Change/tests/test_engine.py#L17-L46)

**Section sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [config.py:12-20](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L20)
- [test_engine.py:17-46](file://User scripts/FI Index Change/tests/test_engine.py#L17-L46)

## Performance Considerations
- Split requests: Analytics groups are split into separate BQL calls to reduce timeout risk. Identity fields are requested first, followed by spread/yield and duration groups.
- Retry policy: Only timeouts are retried; deterministic errors are not retried to avoid wasting time.
- Caching: Historical snapshots are cached; current effective date snapshots are not cached to avoid stale projections.
- Display caps: Chart rendering limits top buckets and detail rows to maintain responsiveness.
- Weight scaling: Fraction detection uses net sum to avoid misclassifying small percent sets.

Recommendations:
- Keep analytics groups minimal to reduce request width.
- Monitor timeout markers and adjust `QUERY_ATTEMPTS` only with dated evidence.
- Validate new fields against Desktop timing before adding them to the frozen item list.

**Section sources**
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [config.py:88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [engine.py:1134-1175](file://User scripts/FI Index Change/fi_index_change/engine.py#L1134-L1175)
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)

## Troubleshooting Guide
Common issues and resolutions:
- No Data Access License: Detected via error message patterns; screen shows a dedicated access failure message.
- Partial snapshots: Required items missing or identity columns empty; status marked partial and not cached.
- Timeout errors: Retried once; notes indicate warm cache effect.
- Missing ID column: Snapshot rejected; log records missing item details.
- Duplicate IDs: Collapsed to last non-null value; notes report duplicate count.
- Fraction vs percent weights: If weights sum near 1.0, they are scaled to percent points; otherwise left unscaled.
- Rating classification conflicts: Alignment ensures one classification per ID; conflicts function reports violations if alignment is skipped.

Debugging steps:
- Inspect payload notes and errors for item parse failures.
- Verify index ticker ends with " Index".
- Confirm selected month-end is in allowed dropdown choices.
- Check whether the snapshot is historical or projected.
- Review alignment warnings for missing identity columns.

**Section sources**
- [engine.py:104-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L104-L119)
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [engine.py:801-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L801-L840)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [test_engine.py:1118-1128](file://User scripts/FI Index Change/tests/test_engine.py#L1118-L1128)

## Conclusion
The FI Index Change module implements robust analytical algorithms for fixed-income index membership change detection. It distinguishes true membership changes from attribute reclassifications, normalizes and aligns labels across snapshots, and computes turnover using either approximate or official index market value ratios. Dimensional filtering enables granular analysis across country, sector, tenor, rating, currency, book, spreads, duration, and yield. The design emphasizes reliability through careful error handling, caching strategies, and extensive unit test coverage. Users should interpret turnover rates carefully, especially when beginning weights are zero or index market value ratios are unavailable, and rely on the detailed notes and warnings to diagnose partial or incomplete data conditions.