# Turnover Calculation Methods

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
- [project-fi-index-change.md](file://rules/project-fi-index-change.md)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the turnover calculation methods used by the Fixed Income Index Change module. It covers:

- The official Bloomberg-style monthly turnover formula and how it is expressed in weight terms.
- The current implementation, which uses an approximate turnover because index market value data is not requested.
- How turnover is computed for each dimension bucket and at the headline level.
- How book type (Standard vs MBS/TBA) affects membership changes and turnover aggregation.
- Practical examples for common rebalancing scenarios.
- Interpretation guidance for portfolio management.

The documentation is grounded in the repository’s engine, data, application, configuration, field library, RAG knowledge base, project rules, and version log.

## Project Structure
The turnover logic spans several modules:

- `engine.py` computes transitions, membership differences, bucket summaries, headline turnover, and turnover rate.
- `data.py` fetches index snapshots and carries the turnover inputs (`index_mv_ratio`, `turnover_basis`) even though they are currently approximate.
- `app.py` wires the dashboard, displays the turnover formulas, and passes turnover inputs to the transition builder.
- `config.py` documents that turnover remains approximate and guards against publishing an unconfirmed index-market-value basis.
- `field_library.py` defines the BQL items requested; index market value is intentionally excluded.
- `28-fi-index-change.md` records the external Bloomberg turnover definition and the fallback behavior.
- `.trae/rules/project-fi-index-change.md` codifies the approximate turnover rule and its interpretation.
- `VersionLog.md` records the removal of index market value and the resulting approximate turnover.

```mermaid
graph TB
App["app.py<br/>Dashboard controller"] --> Data["data.py<br/>Snapshot loader"]
Data --> Engine["engine.py<br/>Transition & summary"]
Engine --> Config["config.py<br/>Approximate turnover policy"]
Data --> FieldLib["field_library.py<br/>BQL item contract"]
Engine --> Docs["28-fi-index-change.md<br/>External turnover definition"]
Engine --> Rules["project-fi-index-change.md<br/>Approximate turnover rule"]
Engine --> Version["VersionLog.md<br/>Market value removed"]
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [config.py:129-135](file://User scripts/FI Index Change/fi_index_change/config.py#L129-L135)
- [field_library.py:82-88](file://User scripts/FI Index Change/fi_index_change/field_library.py#L82-L88)
- [28-fi-index-change.md:705-738](file://RAG KB/28-fi-index-change.md#L705-L738)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)
- [VersionLog.md:666-678](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [config.py:129-135](file://User scripts/FI Index Change/fi_index_change/config.py#L129-L135)
- [field_library.py:82-88](file://User scripts/FI Index Change/fi_index_change/field_library.py#L82-L88)
- [28-fi-index-change.md:705-738](file://RAG KB/28-fi-index-change.md#L705-L738)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)
- [VersionLog.md:666-678](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Core Components
The turnover system has three main responsibilities:

1. **Membership change detection:** Identify Add and Exit securities between the previous month-end and the selected month-end.
2. **Weighted aggregation:** Sum Add and Exit weights by dimension bucket and at the headline level.
3. **Turnover computation:** Convert Add and Exit weights into a turnover percentage and a turnover rate, using either an official index-market-value ratio or an approximate ratio of 1.0.

Key implementation points:

- `build_transition` validates both snapshots and carries `index_mv_ratio` and `turnover_basis`.
- `summarize` computes per-bucket and headline turnover.
- When no valid index-market-value ratio is available, the effective ratio is forced to 1.0 and the basis becomes approximate.
- Turnover rate is turnover divided by Begin Weight, expressed as a percentage.

**Section sources**
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

## Architecture Overview
The turnover flow starts with user input, proceeds through snapshot loading, then builds a transition and summary.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant Engine as "engine.py"
User->>App : Click Update
App->>Data : fetch_index_payload(index_ticker, selected_date)
Data-->>App : IndexPayload(snapshots, statuses, index_mv_ratio, turnover_basis)
App->>Engine : build_transition(snapshots, comparison, statuses, index_mv_ratio, turnover_basis)
Engine-->>App : Transition(previous, latest, status, warnings)
App->>Engine : summarize(transition, dimension, book, filters)
Engine-->>App : Summary table + Headline(turnover, turnover_rate, turnover_basis)
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

## Detailed Component Analysis

### Official Turnover Formula and Weight Form
The external Bloomberg methodology defines monthly turnover as:

- **Official formula:** Turnover equals beginning-of-period drops plus end-of-period additions, divided by the beginning index market value.
- **Weight form:** Turnover in index percent equals Exit Weight at the previous month-end plus Add Weight at the selected month-end multiplied by the ending-to-beginning index market value ratio.

In this module, the weight-based formula is implemented directly. Per-bond Par, Price, or Accrued fields are not required; only the index-market-value ratio is needed if the official basis is used.

**Section sources**
- [28-fi-index-change.md:705-730](file://RAG KB/28-fi-index-change.md#L705-L730)
- [engine.py:900-923](file://User scripts/FI Index Change/fi_index_change/engine.py#L900-L923)

### Current Fallback: Approximate Turnover
Index market value data is no longer requested. As a result:

- `index_mv_ratio` is not set by the data layer.
- `summarize` treats a missing or invalid ratio as 1.0.
- `turnover_basis` becomes `"approx"`.
- The UI labels the metric as approximate.
- The project rules state that monthly turnover is effectively Add Weight plus Exit Weight when the ratio is fixed at 1.0.

```mermaid
flowchart TD
Start(["Summarize called"]) --> CheckRatio["Check index_mv_ratio"]
CheckRatio --> Valid{"Valid finite positive ratio?"}
Valid --> |Yes| UseOfficial["Use official ratio<br/>turnover_basis = 'official'"]
Valid --> |No| UseApprox["Use ratio = 1.0<br/>turnover_basis = 'approx'"]
UseOfficial --> ComputeBucket["Compute bucket turnover:<br/>Exit Weight + Add Weight × ratio"]
UseApprox --> ComputeBucket
ComputeBucket --> ComputeRate["Compute turnover rate:<br/>bucket turnover / Begin Weight × 100"]
ComputeRate --> End(["Return summary and headline"])
```

**Diagram sources**
- [engine.py:900-923](file://User scripts/FI Index Change/fi_index_change/engine.py#L900-L923)
- [engine.py:955-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L955-L977)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)

**Section sources**
- [data.py:51-57](file://User scripts/FI Index Change/fi_index_change/data.py#L51-L57)
- [engine.py:900-907](file://User scripts/FI Index Change/fi_index_change/engine.py#L900-L907)
- [engine.py:955-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L955-L977)
- [28-fi-index-change.md:732-738](file://RAG KB/28-fi-index-change.md#L732-L738)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)
- [VersionLog.md:666-678](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Membership Changes and Book Types
Turnover depends on correctly identifying Adds and Exits. The module distinguishes two book types:

- **Standard:** Regular fixed-income securities.
- **MBS/TBA:** Mortgage-backed or Treasury-backed securities, identified by security type or ID patterns.

Book classification affects:

- Which rows belong to each book.
- How blank Country, Sector, and Currency values are filled.
- How Tenor Bucket and Rating Bucket are treated for MBS/TBA and Municipal rows.
- How `diff_members` returns Add and Exit frames for the selected book.

```mermaid
classDiagram
class Comparison {
+string previous_date
+string selected_date
+string kind
}
class Transition {
+string label
+string previous_date
+string latest_date
+string kind
+string status
+DataFrame previous
+DataFrame latest
+float index_mv_ratio
+string turnover_basis
+tuple warnings
}
class IndexPayload {
+string index_ticker
+string previous_date
+string selected_date
+string kind
+dict snapshots
+dict statuses
+list errors
+list notes
+float index_mv_ratio
+string turnover_basis
}
Comparison --> Transition : "used by build_transition"
IndexPayload --> Transition : "provides snapshots and turnover inputs"
```

**Diagram sources**
- [engine.py:66-96](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L96)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [data.py:41-57](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L57)

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)

### Turnover Computation Logic
The core turnover logic lives in `summarize`:

1. Filter both snapshots and the Add/Exit sets by book and dimension filters.
2. Compute metrics for each dimension bucket:
   - Count
   - Weight
   - Selected spreads, durations, yields
   - Tenor and Coupon
3. Compute bucket turnover:
   - `bucket_turnover = Exit Weight + Add Weight × effective_ratio`
4. Compute bucket turnover rate:
   - If Begin Weight > 0: `bucket_turnover / Begin Weight × 100`
   - Otherwise: NaN
5. Compute headline turnover:
   - `headline_turnover = total Exit Weight + total Add Weight × effective_ratio`
6. Compute headline turnover rate:
   - If total Begin Weight > 0: `headline_turnover / total Begin Weight × 100`
   - Otherwise: NaN

```mermaid
flowchart TD
Start(["summarize"]) --> Filter["Filter previous, latest, added, exited"]
Filter --> Buckets["Iterate dimension buckets"]
Buckets --> Metrics["Compute before, after, add, exit metrics"]
Metrics --> BucketTurnover["bucket_turnover = Exit Weight + Add Weight × effective_ratio"]
BucketTurnover --> BucketRate{"Begin Weight > 0?"}
BucketRate --> |Yes| RateCalc["bucket_rate = bucket_turnover / Begin Weight × 100"]
BucketRate --> |No| RateNaN["bucket_rate = NaN"]
RateCalc --> NextBucket["Next bucket"]
RateNaN --> NextBucket
NextBucket --> Aggregate["Aggregate headline Add/Exit weights"]
Aggregate --> HeadlineTurnover["headline_turnover = total Exit Weight + total Add Weight × effective_ratio"]
HeadlineTurnover --> HeadlineRate{"Total Begin Weight > 0?"}
HeadlineRate --> |Yes| HeadlineRateCalc["headline_rate = headline_turnover / Total Begin Weight × 100"]
HeadlineRate --> |No| HeadlineRateNaN["headline_rate = NaN"]
HeadlineRateCalc --> Return(["Return summary + headline"])
HeadlineRateNaN --> Return
```

**Diagram sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

**Section sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

### Relationship to Index Rebalancing Activity
Turnover measures rebalancing activity by comparing membership changes across two month-ends:

- **Additions:** Securities present in the selected month-end but absent in the previous month-end.
- **Exits:** Securities present in the previous month-end but absent in the selected month-end.
- **Net change:** The difference between End Weight and Begin Weight.
- **Turnover contribution:** Each dimension bucket contributes its own Add and Exit weight to the total turnover.

When the index grows or shrinks, the official formula would adjust Add Weight by the index-market-value ratio. With the approximate fallback, turnover is simply the sum of Add and Exit weights.

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [28-fi-index-change.md:722-730](file://RAG KB/28-fi-index-change.md#L722-L730)

### Practical Examples

#### Example 1: Pure Additions
Scenario:
- Previous month-end: No exits.
- Selected month-end: New bonds added.
- Add Weight: 1.5%
- Exit Weight: 0%
- Effective ratio: 1.0 (approximate)

Calculations:
- Bucket turnover: 0% + 1.5% × 1.0 = 1.5%
- Headline turnover: 1.5%
- Turnover rate: depends on Begin Weight.

Interpretation:
- Turnover reflects new index exposure.
- Under approximate turnover, the number equals total Add Weight.

#### Example 2: Pure Exits
Scenario:
- Previous month-end: Bonds removed.
- Selected month-end: No additions.
- Exit Weight: 0.8%
- Add Weight: 0%
- Effective ratio: 1.0 (approximate)

Calculations:
- Bucket turnover: 0.8% + 0% × 1.0 = 0.8%
- Headline turnover: 0.8%
- Turnover rate: depends on Begin Weight.

Interpretation:
- Turnover reflects reduced index exposure.
- Under approximate turnover, the number equals total Exit Weight.

#### Example 3: Symmetric Rebalancing
Scenario:
- Exit Weight: 1.0%
- Add Weight: 1.0%
- Effective ratio: 1.0 (approximate)

Calculations:
- Bucket turnover: 1.0% + 1.0% × 1.0 = 2.0%
- Headline turnover: 2.0%
- Net weight change: 0%

Interpretation:
- Even though net exposure did not change, turnover is non-zero because membership changed.
- This is important for monitoring rebalancing activity independent of directional exposure shifts.

#### Example 4: Growth with Additions and Exits
Scenario:
- Exit Weight: 0.5%
- Add Weight: 2.0%
- Effective ratio: 1.0 (approximate)

Calculations:
- Bucket turnover: 0.5% + 2.0% × 1.0 = 2.5%
- Headline turnover: 2.5%
- Net weight change: positive if Begin Weight allows.

Interpretation:
- Higher turnover indicates active rebalancing.
- Positive net weight suggests expansion of exposure.

#### Example 5: Contraction with Larger Exits
Scenario:
- Exit Weight: 2.5%
- Add Weight: 0.5%
- Effective ratio: 1.0 (approximate)

Calculations:
- Bucket turnover: 2.5% + 0.5% × 1.0 = 3.0%
- Headline turnover: 3.0%
- Net weight change: negative if Begin Weight allows.

Interpretation:
- High turnover can signal de-risking or index contraction.
- Portfolio managers should inspect whether turnover is driven by exits rather than churn.

**Section sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)

### Interpretation for Portfolio Management
Turnover metrics should be interpreted alongside:

- **Net weight change:** Indicates directional exposure shift.
- **Begin Weight:** Determines whether turnover rate is meaningful.
- **Dimension breakdown:** Identifies where rebalancing is concentrated.
- **Book type:** Standard vs MBS/TBA may have different rebalancing drivers.
- **Approximate label:** Reminds users that index growth or shrinkage is not adjusted by index-market-value changes.

For passive fixed-income indices, turnover is primarily a proxy for index rebalancing activity rather than trading cost. However, in practice, turnover often correlates with transaction costs, liquidity needs, and tracking-error risk.

**Section sources**
- [engine.py:955-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L955-L977)
- [engine.py:1065-1088](file://User scripts/FI Index Change/fi_index_change/engine.py#L1065-L1088)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)

## Dependency Analysis
Turnover depends on several layers:

- **Snapshot quality:** Both previous and latest snapshots must be usable.
- **Book filtering:** Adds and Exits are computed per book.
- **Dimension filters:** Turnover is aggregated per selected dimension.
- **Index-market-value ratio:** Controls whether turnover is official or approximate.
- **Field contract:** The absence of index market value in the BQL request enforces approximate turnover.

```mermaid
graph LR
Snapshots["Snapshots<br/>previous + latest"] --> Diff["diff_members"]
Diff --> AddExit["Added + Exited frames"]
AddExit --> Summarize["summarize"]
Filters["Dimension + Book filters"] --> Summarize
Ratio["index_mv_ratio"] --> Summarize
Summarize --> Output["Turnover + Turnover Rate"]
```

**Diagram sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [field_library.py:82-88](file://User scripts/FI Index Change/fi_index_change/field_library.py#L82-L88)

## Performance Considerations
Turnover computation itself is lightweight compared to data fetching. Important performance characteristics include:

- Snapshot requests are limited to the selected month-end and the previous month-end.
- Historical snapshots are cached; projected snapshots are not.
- Analytics are split into groups to avoid timeouts.
- Turnover aggregation operates on already prepared member frames.
- The approximate turnover avoids an additional index-market-value request.

**Section sources**
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [field_library.py:82-88](file://User scripts/FI Index Change/fi_index_change/field_library.py#L82-L88)

## Troubleshooting Guide

### Turnover Always Shows Approximate
Cause:
- Index market value is not requested.
- `index_mv_ratio` is not set.
- `turnover_basis` defaults to approximate.

Resolution:
- Confirm that the current design intentionally uses approximate turnover.
- If restoring official turnover, restore index market value in the field contract and verify the currency basis before publishing the ratio.

**Section sources**
- [data.py:51-57](file://User scripts/FI Index Change/fi_index_change/data.py#L51-L57)
- [engine.py:900-907](file://User scripts/FI Index Change/fi_index_change/engine.py#L900-L907)
- [28-fi-index-change.md:732-738](file://RAG KB/28-fi-index-change.md#L732-L738)
- [VersionLog.md:666-678](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Turnover Rate Is Blank
Cause:
- Begin Weight is zero or missing.
- Turnover rate is defined as turnover divided by Begin Weight.

Resolution:
- Inspect Begin Weight for the selected dimension and book.
- A blank turnover rate does not mean turnover is wrong; it means the denominator is unavailable.

**Section sources**
- [engine.py:919-923](file://User scripts/FI Index Change/fi_index_change/engine.py#L919-L923)
- [engine.py:973-976](file://User scripts/FI Index Change/fi_index_change/engine.py#L973-L976)

### Turnover Seems Too Low or Too High
Possible causes:
- Only one side of rebalancing occurred.
- Dimension or book filter narrowed the scope.
- Approximate turnover ignores index growth or shrinkage.

Resolution:
- Compare Add Weight and Exit Weight separately.
- Check the selected dimension and book.
- Remember that approximate turnover equals Add Weight plus Exit Weight under the current implementation.

**Section sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [project-fi-index-change.md:223-240](file://rules/project-fi-index-change.md#L223-L240)

## Conclusion
The FI Index Change module implements turnover as a measure of index rebalancing activity between two month-ends. The official Bloomberg-style formula adjusts Add Weight by the index-market-value ratio, but the current implementation uses an approximate ratio of 1.0 because index market value is not requested. As a result:

- Headline turnover equals total Exit Weight plus total Add Weight.
- Bucket turnover is the contribution of each dimension bucket.
- Turnover rate divides turnover by Begin Weight.
- The approximate label is essential context for interpreting turnover numbers.

For portfolio management, turnover should be read together with net weight change, dimension breakdown, book type, and the approximate label. If official turnover is restored, the same code path supports it through `index_mv_ratio`, provided the index-market-value basis is validated.

## Appendices

### Appendix A: Key Functions and Their Roles

| Function | Responsibility |
|---|---|
| `build_transition` | Validates snapshots and carries turnover inputs |
| `diff_members` | Computes Add and Exit securities by book |
| `summarize` | Computes bucket and headline turnover and turnover rate |
| `_side_metrics` | Aggregates count, weight, spreads, durations, yields, tenor, coupon |
| `caption_html` | Displays turnover formula and approximate label |

**Section sources**
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:855-882](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L882)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [engine.py:1065-1088](file://User scripts/FI Index Change/fi_index_change/engine.py#L1065-L1088)