# Dimensional Analysis Framework

<cite>
**Referenced Files in This Document**   
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the dimensional analysis framework used by the Fixed Income Index Change application to break down index membership changes across five dimensions: Country, Sector, Tenor Bucket, Rating Bucket, and Currency. It covers how bond characteristics are classified, how continuous variables such as tenor and rating text are bucketed, how filters narrow the results, how snapshots are aligned across time periods, and how special cases like MBS/TBA bonds and municipal securities are handled.

The framework is implemented in a small Python package under `User scripts/FI Index Change/fi_index_change`, with supporting runtime rules documented in `RAG KB/28-fi-index-change.md`.

## Project Structure
The dimensional analysis logic is split across four main modules:

| Module | Responsibility |
|---|---|
| `engine.py` | Dimension definitions, classification functions, snapshot preparation, label alignment, ID-based add/exit diffing, summary aggregation, and export formatting. |
| `config.py` | Constants for buckets, labels, filter widths, chart sizing, request behavior, and special-case tokens. |
| `data.py` | BQL membership requests, response parsing, caching, error handling, and payload assembly. |
| `app.py` | User interface, widget state, dimension selection, filter application, charts, tables, and export tabs. |
| `28-fi-index-change.md` | Runtime authority documenting the approved data contract, bucket definitions, alignment rules, and known edge cases. |

```mermaid
graph TB
UI["app.py<br/>Widgets, filters, charts"] --> DataLayer["data.py<br/>BQL requests, cache, payload"]
DataLayer --> Engine["engine.py<br/>Classification, alignment, aggregation"]
Engine --> Config["config.py<br/>Constants, labels, thresholds"]
Engine --> Docs["28-fi-index-change.md<br/>Runtime authority"]
```

**Diagram sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-65](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L65)
- [config.py:1-50](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L50)
- [28-fi-index-change.md:41-76](file://RAG KB/28-fi-index-change.md#L41-L76)

**Section sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-65](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L65)
- [config.py:1-50](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L50)
- [28-fi-index-change.md:41-76](file://RAG KB/28-fi-index-change.md#L41-L76)

## Core Components
The dimensional analysis framework has these core responsibilities:

1. **Dimension definition**: The framework exposes five display dimensions: Country, Sector, Tenor Bucket, Rating Bucket, and Currency.
2. **Snapshot normalization**: Raw Bloomberg membership responses are converted into a consistent frame with identity fields, weights, and derived classification columns.
3. **Bucketing**: Continuous or textual inputs are mapped into fixed categories.
4. **Cross-snapshot alignment**: Classification labels are standardized per security ID so that the same bond cannot appear in different categories on the two month-ends.
5. **Change computation**: Adds and exits are computed as ID-level differences between the previous and selected month-end.
6. **Filtering**: Dimension and analytics filters narrow the displayed set without changing the underlying comparison.
7. **Aggregation**: Changes are summarized by dimension, including counts, weights, spreads, durations, yields, and turnover attribution.

**Section sources**
- [engine.py:57-63](file://User scripts/FI Index Change/fi_index_change/engine.py#L57-L63)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [28-fi-index-change.md:516-543](file://RAG KB/28-fi-index-change.md#L516-L543)

## Architecture Overview
At a high level, the dimensional analysis pipeline proceeds as follows:

1. The user selects an index, month-end, book, and filters.
2. `data.py` requests the previous and selected month-end membership frames from Bloomberg.
3. Each raw frame is parsed, merged, collapsed, and normalized through `prepare_members`.
4. Classification columns are created: Book, Country, Sector, Tenor Bucket, Rating, Rating Bucket, and Currency.
5. `align_snapshot_labels` ensures consistent classification across both snapshots.
6. `diff_members` computes Add and Exit rows by ID.
7. `summarize` and related engine functions aggregate changes by the selected dimension.
8. `app.py` renders charts, tables, and detail panels using the filtered aggregated results.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant Engine as "engine.py"
participant BQL as "Bloomberg BQL"
User->>App : Select index, month-end, filters
App->>Data : fetch_index_payload(index, month_end)
Data->>BQL : members(index, dates=as_of)
BQL-->>Data : Raw membership items
Data->>Engine : prepare_members(frame)
Engine-->>Data : Normalized snapshot
Data->>Engine : align_snapshot_labels(previous, latest)
Engine-->>Data : Aligned snapshots
Data->>Engine : build_transition(snapshots, comparison)
Engine->>Engine : diff_members(previous, latest, book)
Engine->>Engine : summarize(changes, dimension, filters)
Engine-->>App : Aggregated dimensional results
App-->>User : Charts, tables, detail panel
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

## Detailed Component Analysis

### Dimension Categories
The framework defines five primary dimensions for breakdown:

| Dimension | Display name | Source / derivation | Notes |
|---|---|---|---|
| Country | Country | `country_full_name()` | Title-cased; overridden names applied first. |
| Sector | Sector | `classification_name()` | Blank sector on MBS/TBA becomes `MBS/TBA`; municipal becomes `Municipal`. |
| Tenor Bucket | Tenor Bucket | Numeric `mty_years_tdy` | Fixed bins: 0–1Y, 1–3Y, 3–5Y, 5–7Y, 7–10Y, 10–20Y, 20Y+, Missing. |
| Rating Bucket | Rating Bucket | Text `rating()` | Exactly IG, HY, or NR. |
| Currency | Currency | `crncy()` | Blank currency on MBS/TBA defaults to USD. |

These mappings are declared centrally and reused by the UI and aggregation logic.

**Section sources**
- [engine.py:57-63](file://User scripts/FI Index Change/fi_index_change/engine.py#L57-L63)
- [28-fi-index-change.md:87-112](file://RAG KB/28-fi-index-change.md#L87-L112)
- [28-fi-index-change.md:284-303](file://RAG KB/28-fi-index-change.md#L284-L303)

### Snapshot Preparation and Special Cases
`prepare_members` is the central normalization step. It performs several important tasks:

- Drops blank IDs and collapses duplicate IDs while keeping the last non-null value per column.
- Converts numeric fields to numeric types and replaces infinite values with nulls.
- Normalizes text fields to `(blank)` when appropriate.
- Applies country name overrides and title-cases country names.
- Classifies each row as Standard or MBS/TBA based on Security Type and ID patterns.
- Fills missing Country/Sector/Currency for MBS/TBA rows.
- Marks US municipal securities by ID suffix and assigns Municipal Country/Sector and USD Currency.
- Creates Tenor Bucket and Rating Bucket.
- Sets Rating to N.A. for MBS/TBA and Municipal rows.

```mermaid
flowchart TD
Start(["Raw snapshot"]) --> NormalizeID["Normalize and drop blank IDs"]
NormalizeID --> CollapseDupes["Collapse duplicate IDs"]
CollapseDupes --> NumericFields["Convert numeric fields"]
NumericFields --> TextFields["Normalize text fields"]
TextFields --> CountryOverride["Apply country overrides and title-case"]
CountryOverride --> BookClassify["Classify Standard vs MBS/TBA"]
BookClassify --> MBSSpecial["Fill MBS/TBA Country/Sector/Currency"]
MBSSpecial --> MunicipalSpecial["Mark Municipal by ID suffix"]
MunicipalSpecial --> TenorBucket["Compute Tenor Bucket"]
TenorBucket --> RatingBucket["Compute Rating Bucket"]
RatingBucket --> End(["Prepared snapshot"])
```

**Diagram sources**
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)

**Section sources**
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)
- [28-fi-index-change.md:431-446](file://RAG KB/28-fi-index-change.md#L431-L446)
- [28-fi-index-change.md:284-303](file://RAG KB/28-fi-index-change.md#L284-L303)

### Tenor Bucket Algorithm
Tenor is derived from the numeric `mty_years_tdy` field. The algorithm uses fixed bin edges:

| Bucket | Range |
|---|---|
| 0–1Y | Greater than or equal to 0 and less than 1 year |
| 1–3Y | Greater than or equal to 1 and less than 3 years |
| 3–5Y | Greater than or equal to 3 and less than 5 years |
| 5–7Y | Greater than or equal to 5 and less than 7 years |
| 7–10Y | Greater than or equal to 7 and less than 10 years |
| 10–20Y | Greater than or equal to 10 and less than 20 years |
| 20Y+ | Greater than or equal to 20 years |
| Missing | Negative, non-finite, or otherwise unusable tenor |

For MBS/TBA bonds that do not have a usable numeric tenor, the bucket is labeled `N.A.` rather than `Missing`.

```mermaid
flowchart TD
Input["Numeric mty_years_tdy"] --> Valid{"Usable number?"}
Valid --> |No| Missing["Missing"]
Valid --> |Yes| BinCheck["Compare against fixed bin edges"]
BinCheck --> Buckets["0-1Y, 1-3Y, 3-5Y, 5-7Y, 7-10Y, 10-20Y, 20Y+"]
Buckets --> MBSFix{"MBS/TBA with no real tenor?"}
MBSFix --> |Yes| NA["N.A."]
MBSFix --> |No| KeepBucket["Keep normal bucket"]
```

**Diagram sources**
- [engine.py:31-34](file://User scripts/FI Index Change/fi_index_change/engine.py#L31-L34)
- [engine.py:335-350](file://User scripts/FI Index Change/fi_index_change/engine.py#L335-L350)
- [engine.py:449-456](file://User scripts/FI Index Change/fi_index_change/engine.py#L449-L456)
- [28-fi-index-change.md:516-519](file://RAG KB/28-fi-index-change.md#L516-L519)

**Section sources**
- [engine.py:31-34](file://User scripts/FI Index Change/fi_index_change/engine.py#L31-L34)
- [engine.py:335-350](file://User scripts/FI Index Change/fi_index_change/engine.py#L335-L350)
- [engine.py:449-456](file://User scripts/FI Index Change/fi_index_change/engine.py#L449-L456)
- [28-fi-index-change.md:516-519](file://RAG KB/28-fi-index-change.md#L516-L519)

### Rating Bucket Algorithm
Rating classification is intentionally conservative. It maps raw rating text into exactly three buckets:

| Bucket | Meaning |
|---|---|
| IG | Investment grade, including recognized S&P-style and Moody’s-style investment-grade tokens. |
| HY | High yield, including recognized S&P-style and Moody’s-style high-yield tokens. |
| NR | No usable letter grade. Includes blanks, stated NR/WR, vendor numeric scales, and N.A. on MBS/TBA or Municipal rows. |

The implementation does not guess a numeric rating scale. A numeric rating remains visible in the raw Rating column but is classified NR.

```mermaid
flowchart TD
Input["Raw rating text"] --> Clean["Strip whitespace and normalize case"]
Clean --> NumericTest{"Is it numeric?"}
NumericTest --> |Yes| NR["NR"]
NumericTest --> |No| IGCheck{"Recognized IG token?"}
IGCheck --> |Yes| IG["IG"]
IGCheck --> |No| HYCheck{"Recognized HY token?"}
HYCheck --> |Yes| HY["HY"]
HYCheck --> |No| NR
```

**Diagram sources**
- [engine.py:36-55](file://User scripts/FI Index Change/fi_index_change/engine.py#L36-L55)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [28-fi-index-change.md:521-528](file://RAG KB/28-fi-index-change.md#L521-L528)

**Section sources**
- [engine.py:36-55](file://User scripts/FI Index Change/fi_index_change/engine.py#L36-L55)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [28-fi-index-change.md:521-528](file://RAG KB/28-fi-index-change.md#L521-L528)

### Cross-Snapshot Label Alignment
A key requirement is that a bond must belong to exactly one category in any given filter. To enforce this, classification labels are aligned by security ID across the previous and selected snapshots.

Rules:

- If the latest snapshot has a usable label, it wins even if it changed.
- If the latest label is missing, the previous snapshot’s label fills both sides.
- IDs present on only one date keep that date’s label.
- Weights and analytics are never copied across snapshots.
- Rating Bucket alignment also preserves the raw Rating text when it belongs to the same classification.

```mermaid
flowchart TD
Start(["Previous snapshot, Latest snapshot"]) --> CommonIDs["Find common IDs"]
CommonIDs --> PerColumn["For each aligned label column"]
PerColumn --> LatestUsable{"Latest usable?"}
LatestUsable --> |Yes| UseLatest["Use latest"]
LatestUsable --> |No| PreviousUsable{"Previous usable?"}
PreviousUsable --> |Yes| UsePrevious["Use previous on both sides"]
PreviousUsable --> |No| ChooseEither["Choose either (both missing)"]
UseLatest --> Apply["Apply mapping to both snapshots"]
UsePrevious --> Apply
ChooseEither --> Apply
Apply --> RatingBucket["Align Rating Bucket and compatible Rating text"]
RatingBucket --> End(["Consistent classification per ID"])
```

**Diagram sources**
- [engine.py:465-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L465-L605)
- [28-fi-index-change.md:530-539](file://RAG KB/28-fi-index-change.md#L530-L539)

**Section sources**
- [engine.py:465-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L465-L605)
- [28-fi-index-change.md:530-539](file://RAG KB/28-fi-index-change.md#L530-L539)

### Dimensional Filters and Aggregation
Filters are applied after the ID-level membership diff. They affect the displayed breakdown and detail lists, not the underlying Add/Exit computation.

Available filters include:

| Filter group | Options |
|---|---|
| Country | Distinct country values from the loaded snapshot |
| Sector | Distinct sector values from the loaded snapshot |
| Tenor | Tenor Bucket values |
| Rating | Rating Bucket values |
| Currency | Distinct currency values from the loaded snapshot |
| Spread | OAS, Z-Spread, I-Spread |
| Duration | Duration, Modified Duration, Effective Duration, OASD |
| Yield | Yield, YTM, YTW |
| Book | All, Standard, MBS/TBA |

The framework aggregates changes by the selected dimension. For each dimension key, it computes:

- Count
- Begin weight
- End weight
- Weight change
- Add count and Add weight
- Exit count and Exit weight
- Selected spread averages
- Selected duration averages
- Selected yield averages
- Average tenor
- Turnover contribution
- Turnover rate

```mermaid
flowchart TD
Changes["Add and Exit rows"] --> ApplyAllFilters["Apply all active filters"]
ApplyAllFilters --> DimensionKey["Group by selected dimension key"]
DimensionKey --> Metrics["Compute counts, weights, analytics"]
Metrics --> Summary["Dimension summary table"]
Summary --> Chart["Horizontal signed bar chart"]
Chart --> Detail["Detail list and bond chart"]
```

**Diagram sources**
- [app.py:205-212](file://User scripts/FI Index Change/fi_index_change/app.py#L205-L212)
- [app.py:354-432](file://User scripts/FI Index Change/fi_index_change/app.py#L354-L432)
- [28-fi-index-change.md:545-550](file://RAG KB/28-fi-index-change.md#L545-L550)

**Section sources**
- [app.py:205-212](file://User scripts/FI Index Change/fi_index_change/app.py#L205-L212)
- [app.py:354-432](file://User scripts/FI Index Change/fi_index_change/app.py#L354-L432)
- [28-fi-index-change.md:545-550](file://RAG KB/28-fi-index-change.md#L545-L550)

### Example Outputs
Although this document avoids embedding live data, the dimensional analysis output can be understood as follows:

- **Country breakdown**: Shows which countries contributed most to adds and exits, along with weighted average spreads, durations, and yields.
- **Sector breakdown**: Highlights sectors where index composition changed, including MBS/TBA and Municipal as special categories.
- **Tenor Bucket breakdown**: Shows whether additions or exits concentrated in short, intermediate, or long maturities.
- **Rating Bucket breakdown**: Shows whether changes were concentrated in IG, HY, or NR.
- **Currency breakdown**: Shows exposure shifts across currencies, with MBS/TBA defaulting to USD.

Each output includes:

- Signed Add and Exit weights.
- Net change.
- Analytics averages where applicable.
- Turnover attribution at the bucket level.

**Section sources**
- [engine.py:676-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L729)
- [app.py:435-519](file://User scripts/FI Index Change/fi_index_change/app.py#L435-L519)
- [28-fi-index-change.md:489-507](file://RAG KB/28-fi-index-change.md#L489-L507)

### MBS/TBA and Municipal Special Cases
MBS/TBA and municipal securities receive special treatment because their market structure differs from standard corporate or sovereign bonds.

| Case | Treatment |
|---|---|
| MBS/TBA | Identified by Security Type containing MBS, TBA, or Pool, or ID containing Mtge. Blank Country/Sector become `MBS/TBA`; blank Currency becomes USD. Rating is N.A.; Rating Bucket is NR. Tenor Bucket is `N.A.` when no numeric tenor exists. |
| Municipal | Identified by ID ending with `Muni`. Country and Sector become `Municipal`; Currency becomes USD. Rating is N.A.; Rating Bucket is NR. |

These rules ensure that MBS/TBA and municipal bonds do not leak into unexpected Country, Sector, or Rating categories.

**Section sources**
- [engine.py:413-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L461)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)
- [28-fi-index-change.md:284-303](file://RAG KB/28-fi-index-change.md#L284-L303)
- [28-fi-index-change.md:431-446](file://RAG KB/28-fi-index-change.md#L431-L446)

## Dependency Analysis
The dimensional analysis framework has clear layering:

- `app.py` depends on `engine.py` for business logic and on `data.py` for payload retrieval.
- `data.py` depends on `engine.py` for classification and alignment helpers and on `config.py` for request behavior.
- `engine.py` depends on `config.py` for constants and labels.
- `28-fi-index-change.md` documents the authoritative behavior but is not imported at runtime.

```mermaid
graph LR
app["app.py"] --> engine["engine.py"]
app --> data["data.py"]
data --> engine
data --> config["config.py"]
engine --> config
docs["28-fi-index-change.md"] -. documentation .-> engine
docs -. documentation .-> data
```

**Diagram sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [config.py:1-50](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L50)
- [28-fi-index-change.md:41-76](file://RAG KB/28-fi-index-change.md#L41-L76)

**Section sources**
- [app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [data.py:1-35](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L35)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [config.py:1-50](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L50)
- [28-fi-index-change.md:41-76](file://RAG KB/28-fi-index-change.md#L41-L76)

## Performance Considerations
The dimensional analysis framework is designed around Bloomberg’s two-minute query limit and large index universes.

Key performance characteristics:

- Only the selected month-end and the previous month-end are requested.
- Historical snapshots are cached as CSV.
- Requests may be split into identity and analytics groups to avoid timeouts.
- Duplicate IDs are collapsed once and reused.
- Filtering is local after data loading.
- Charts cap the number of displayed buckets and top movers.
- Export tables repeat headers for Excel copy/paste but do not write files.

The runtime authority notes that local processing is fast relative to the Bloomberg timeout; the bottleneck is typically the BQL request, not the Python-side aggregation.

**Section sources**
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [28-fi-index-change.md:326-332](file://RAG KB/28-fi-index-change.md#L326-L332)
- [28-fi-index-change.md:774-783](file://RAG KB/28-fi-index-change.md#L774-L783)

## Troubleshooting Guide
Common issues and their diagnostic signals:

| Symptom | Likely cause | Resolution |
|---|---|---|
| Bond appears under two Rating selections | Detail list did not apply every active filter | Ensure `_filtered_changes` applies all filters before dimension-key filtering. |
| Rating mismatch across snapshots | Classification alignment failed or was bypassed | Check `align_snapshot_labels` and `rating_class_conflicts`. |
| Country/Sector entirely blank | Response item parsed but value column was not picked | Inspect `_pick_value_column` and response column names. |
| MBS/TBA shows Missing tenor instead of N.A. | Missing numeric tenor not treated as not applicable | Confirm MBS/TBA mask and `TENOR_NOT_APPLICABLE` assignment. |
| Municipal bond classified incorrectly | ID suffix rule not applied | Confirm `MUNI_ID_SUFFIX` and municipal override path. |
| Update times out | BQL query too wide or date-dependent | Split requests, retry only on timeout, and verify analytics groups. |
| License error shown | Index membership access denied | Show license message; do not treat as empty changes. |

**Section sources**
- [28-fi-index-change.md:552-585](file://RAG KB/28-fi-index-change.md#L552-L585)
- [engine.py:607-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L607-L630)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [engine.py:413-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L461)

## Conclusion
The dimensional analysis framework provides a robust, operator-verified way to decompose fixed-income index changes across Country, Sector, Tenor Bucket, Rating Bucket, and Currency. Its design emphasizes:

- Clear dimension definitions.
- Conservative classification of continuous and textual inputs.
- Strict cross-snapshot alignment to prevent inconsistent categorization.
- Careful handling of MBS/TBA and municipal securities.
- Local filtering after ID-level membership diffs.
- Transparent aggregation and export behavior.

When extending or debugging the framework, the safest starting points are `engine.py` for classification and aggregation, `data.py` for data ingestion, `config.py` for constants, and `28-fi-index-change.md` for the approved runtime rules.