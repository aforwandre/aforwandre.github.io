# BQL Execution and Retry Management

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [test_cache.py](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py)
- [test_data_request.py](file://User scripts/FI Index Change/tests/test_data_request.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the BQL execution and retry management system used by the fixed-income applications. The central goal is to execute Bloomberg BQL requests safely, distinguish transient timeout failures from permanent entitlement or schema errors, and recover when a warm Bloomberg-side cache makes a second identical request succeed quickly.

The key implementation is `_execute_attempts`, which:
- Executes one BQL request up to a bounded number of attempts.
- Retries only when the failure is classified as a timeout.
- Rebuilds the request per attempt so no stale state is reused.
- Tracks elapsed time for every attempt.
- Reports both success on retry and complete failure with timing details.

The system also documents how `QUERY_ATTEMPTS` controls retry behavior, how `_TIMEOUT_MARKERS` and `_DETERMINISTIC_MARKERS` classify errors, and how successful responses are cached to avoid repeated expensive queries.

## Project Structure
The retry logic lives in the data-access layer of two sibling projects:
- FI Spread Movement Monitoring uses a generic `_execute_attempts(bq, request_factory, label, errors, notes)` interface.
- FI Index Change uses a slightly adapted `_execute_attempts(bq, index_ticker, as_of, items, label, errors, notes)` interface that rebuilds the member request internally.

Both implementations share the same design principles:
- Only timeouts are retried.
- Deterministic failures fail fast.
- Attempts are bounded by configuration.
- Timing and retry notes are recorded for observability.
- Successful results can be cached and later served without live BQL calls.

```mermaid
graph TB
subgraph "FI Spread Movement Monitoring"
SData["fi_spread_movement/data.py"]
STests["tests/test_cache.py"]
end
subgraph "FI Index Change"
IData["fi_index_change/data.py"]
IConfig["fi_index_change/config.py"]
ITests["tests/test_data_request.py"]
end
SData --> |"uses"| STests
IData --> |"uses"| IConfig
IData --> |"tested by"| ITests
```

**Diagram sources**
- [data.py:153-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L153-L215)
- [data.py:529-595](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L595)
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)
- [test_cache.py:56-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L56-L147)
- [test_data_request.py:307-369](file://User scripts/FI Index Change/tests/test_data_request.py#L307-L369)

**Section sources**
- [data.py:153-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L153-L215)
- [data.py:529-595](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L595)
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)

## Core Components
The core components are:
- Timeout classification using marker lists.
- The retry loop in `_execute_attempts`.
- Configuration of maximum attempts.
- Performance tracking through elapsed seconds.
- Caching strategy for successful responses.

Key responsibilities:
- `_TIMEOUT_MARKERS`: identifies transient timeout-like failures.
- `_DETERMINISTIC_MARKERS`: identifies permanent failures that must not be retried.
- `is_timeout(exc)`: applies deterministic markers first, then timeout markers.
- `_execute_attempts(...)`: executes, retries only on timeout, records timing, and returns response plus attempt count.
- `QUERY_ATTEMPTS`: configures the maximum number of attempts.

**Section sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [data.py:502-538](file://User scripts/FI Index Change/fi_index_change/data.py#L502-L538)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)

## Architecture Overview
At runtime, the application builds a BQL request, passes it through `_execute_attempts`, and either receives a usable response or records an error. If the first attempt times out, the same request is rebuilt and sent once more. If the second attempt succeeds, the result is treated as a warm-cache success. If all attempts fail, the last exception and all attempt timings are appended to the error log.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant Executor as "_execute_attempts"
participant Factory as "request_factory"
participant BQL as "bq.execute"
participant Logger as "errors/notes"
Caller->>Executor : Execute request
Executor->>Factory : Build request
Factory-->>Executor : Request object
Executor->>BQL : Execute(request)
alt Timeout on first attempt
BQL-->>Executor : Exception
Executor->>Logger : Record timeout note
Executor->>Factory : Rebuild request
Factory-->>Executor : Same request
Executor->>BQL : Execute(request again)
alt Success on retry
BQL-->>Executor : Response
Executor->>Logger : Record answered-on-retry note
Executor-->>Caller : Response + attempts
else Timeout again
BQL-->>Executor : Exception
Executor->>Logger : Record all-attempts-failed error
Executor-->>Caller : None + attempts
end
else Non-timeout failure
BQL-->>Executor : Exception
Executor->>Logger : Record deterministic error
Executor-->>Caller : None + attempts
end
```

**Diagram sources**
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)

## Detailed Component Analysis

### Timeout Detection: `_TIMEOUT_MARKERS` and `_DETERMINISTIC_MARKERS`
Timeout detection is intentionally conservative:
- Deterministic markers win first. Examples include missing BQL data items, entitlement failures, authorization issues, invalid tickers, unknown fields, and license-related errors.
- Timeout markers include timeout-like strings such as `BQLTimeoutError`, `took too long`, `query timed out`, `timed out`, and `timeout`.

This ordering prevents a field named something like `timeout_field` from being mistakenly retried. A deterministic failure should never be retried because a second identical request cannot fix a schema, entitlement, or input problem.

```mermaid
flowchart TD
Start([Exception received]) --> Normalize["Normalize exception text"]
Normalize --> CheckDeterministic{"Contains deterministic marker?"}
CheckDeterministic --> |Yes| NotTimeout["Return False<br/>Never retry"]
CheckDeterministic --> |No| CheckTimeout{"Contains timeout marker?"}
CheckTimeout --> |Yes| IsTimeout["Return True<br/>Retry allowed"]
CheckTimeout --> |No| NotTimeout
```

**Diagram sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:502-538](file://User scripts/FI Index Change/fi_index_change/data.py#L502-L538)

**Section sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:502-538](file://User scripts/FI Index Change/fi_index_change/data.py#L502-L538)
- [test_cache.py:56-74](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L56-L74)

### Retry Logic: `_execute_attempts`
There are two closely related implementations:

1. **Spread Movement Monitoring**: accepts a `request_factory` callable so the caller owns request construction.
2. **Index Change**: accepts ticker, date, and item dict and rebuilds the member request internally.

Common behavior:
- Read `attempts = max(1, int(config.QUERY_ATTEMPTS))`.
- Loop from attempt 1 through `attempts`.
- Measure elapsed time with high-resolution counters.
- On exception:
  - Record elapsed time.
  - Classify with `is_timeout`.
  - If not a timeout or if this is the final attempt, stop.
  - Otherwise, append a retry note and continue.
- On success:
  - Record elapsed time.
  - If attempt > 1, append a note indicating the answer came on retry.
  - Return `(response, attempt)`.
- On full failure:
  - Append the last exception message.
  - If multiple attempts occurred, append a summary including all elapsed times.
  - Return `(None, len(seconds))`.

```mermaid
flowchart TD
Entry([Start _execute_attempts]) --> ReadAttempts["Read QUERY_ATTEMPTS"]
ReadAttempts --> Init["Initialize seconds list and last exception"]
Init --> Loop{"For attempt in 1..attempts"}
Loop --> |Start| Timer["Record start time"]
Timer --> TryExecute["Call bq.execute(build_request)"]
TryExecute --> |Success| RecordSuccess["Record elapsed time"]
RecordSuccess --> RetryNote{"Attempt > 1?"}
RetryNote --> |Yes| AddRetryNote["Add 'answered on attempt' note"]
RetryNote --> |No| ReturnSuccess["Return response, attempt"]
AddRetryNote --> ReturnSuccess
TryExecute --> |Exception| RecordElapsed["Record elapsed time"]
RecordElapsed --> Classify["Classify with is_timeout"]
Classify --> Decision{"Is timeout AND not last attempt?"}
Decision --> |Yes| AddTimeoutNote["Add timeout retry note"]
AddTimeoutNote --> Loop
Decision --> |No| FinalizeFailure["Append last error and timing summary"]
FinalizeFailure --> ReturnFailure["Return None, attempts_made"]
```

**Diagram sources**
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)

**Section sources**
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [test_cache.py:95-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L95-L147)
- [test_data_request.py:307-369](file://User scripts/FI Index Change/tests/test_data_request.py#L307-L369)

### Configuration: `QUERY_ATTEMPTS`
`QUERY_ATTEMPTS` is set to `2`. This means:
- A timeout-bearing request is attempted once more with the exact same request.
- Deterministic failures are not retried.
- The worst-case cost grows with the number of requests per update, but each individual request is bounded.

The configuration comments explain the operational rationale: pressing Update a second time often succeeds quickly because the first attempt warmed the Bloomberg-side cache. Nothing is dropped from the request during retry; the retry is not a narrower or modified request.

**Section sources**
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)
- [test_cache.py:122-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L122-L147)

### Failure Types and Handling Strategies

#### Timeouts
A timeout is considered transient when:
- The exception text contains a timeout marker.
- It does not contain a deterministic marker.

Handling:
- First attempt may time out.
- Second attempt sends the same request unchanged.
- If the second attempt succeeds, the result is treated as a warm-cache success.
- Notes record the timeout and the retry success.
- If both attempts time out, the error log includes the exception and a summary of all attempt durations.

#### Entitlement and Schema Errors
Examples include:
- Missing BQL data item.
- Not entitled for this account.
- Invalid ticker.
- Unknown field.
- License or authorization errors.

Handling:
- These are classified as deterministic failures.
- No retry occurs.
- The error is recorded immediately.
- The run fails closed rather than hiding a real entitlement or schema problem behind a cached previous result.

**Section sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [test_cache.py:56-74](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L56-L74)
- [test_data_request.py:348-369](file://User scripts/FI Index Change/tests/test_data_request.py#L348-L369)

### Performance Monitoring: Elapsed Time Tracking and Progress Reporting
Each attempt measures elapsed time using a high-resolution timer. The implementation tracks:
- Per-attempt elapsed seconds.
- Whether the response succeeded on retry.
- Whether all attempts failed.
- A summary of all attempt durations when multiple attempts occur.

In the spread movement monitoring path, request-level timing is also captured around the call to `_execute_attempts`, allowing higher layers to report total elapsed time and attempt counts in request logs.

This design ensures that near-limit successes are visible instead of silent, and that operators can distinguish:
- A single fast request.
- A slow first attempt followed by a fast retry.
- Multiple failed attempts with documented durations.

**Section sources**
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [data.py:780-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L800)
- [test_cache.py:122-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L122-L147)

### Caching Strategy and Warm Cache Effect
Successful responses are cached at the application level. The cache strategy has several important properties:
- Cached runs are keyed by inputs such as source, universe, dates, spread type, and other parameters.
- Empty runs are refused; replaying “nothing” would hide the difference between “no data was asked” and “the request returned nothing.”
- Runs with failed fields or incomplete required columns are refused, preventing stale or partial data from being presented as clean.
- A generation token invalidates old cache entries when the pipeline changes.
- A read-only project folder or disk issue cannot turn a good update into a failed one; cache write failures are logged but do not fail the run.
- A cached fallback is used only when the live failure was purely a timeout and a clean cached run exists for the same key.

The warm cache effect is central to the retry design:
- The first request may approach or hit the Desktop query limit.
- The second identical request often answers quickly because Bloomberg’s backend cache was warmed by the first attempt.
- The retry does not drop items or change the request shape; it relies on the backend cache rather than request narrowing.

```mermaid
flowchart TD
LiveRequest["Live BQL request"] --> Result{"Result usable?"}
Result --> |Yes| ValidateCache["Validate required columns and completeness"]
ValidateCache --> |Valid| SaveCache["Save to cache"]
ValidateCache --> |Invalid| RefuseCache["Refuse cache"]
Result --> |No| ErrorPath["Record error and timing"]
SaveCache --> NextRun["Next run may serve from cache"]
RefuseCache --> NextRun
ErrorPath --> FallbackCheck{"Fallback allowed?"}
FallbackCheck --> |Timeout only and clean cache exists| ServeCached["Serve cached result"]
FallbackCheck --> |Otherwise| FailRun["Fail run"]
```

**Diagram sources**
- [test_cache.py:150-303](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L150-L303)
- [DECISION_RECORD.md:842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

**Section sources**
- [test_cache.py:150-303](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L150-L303)
- [DECISION_RECORD.md:842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

## Dependency Analysis
The retry system depends on:
- Configuration constants, especially `QUERY_ATTEMPTS`.
- The BQL client interface (`bq.execute`).
- The timeout classifier (`is_timeout`).
- Higher-level request builders that construct BQL requests.
- Caching modules that store and retrieve successful results.

Coupling and cohesion:
- `_execute_attempts` is cohesive around one responsibility: bounded retry with timeout-only recovery.
- Timeout classification is isolated in marker lists and `is_timeout`, making it testable and reusable.
- Request building is separated from retry logic, allowing different callers to supply their own request factories or internal builders.
- Caching is separate from execution, so cache misses and cache hits do not alter retry semantics.

Potential risks:
- Adding new timeout-like messages without adding them to `_TIMEOUT_MARKERS` could cause missed retries.
- Adding new deterministic error patterns without updating `_DETERMINISTIC_MARKERS` could cause unnecessary retries.
- Changing `QUERY_ATTEMPTS` affects total latency and server load.

```mermaid
graph LR
Config["config.QUERY_ATTEMPTS"] --> Executor["_execute_attempts"]
Markers["Timeout and deterministic markers"] --> Classifier["is_timeout"]
Classifier --> Executor
Builder["Request builder / factory"] --> Executor
Executor --> BQL["bq.execute"]
Executor --> Logger["errors / notes"]
Executor --> Cache["Caching layer"]
```

**Diagram sources**
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)
- [data.py:123-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L215)
- [data.py:502-595](file://User scripts/FI Index Change/fi_index_change/data.py#L502-L595)

**Section sources**
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)
- [data.py:123-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L215)
- [data.py:502-595](file://User scripts/FI Index Change/fi_index_change/data.py#L502-L595)

## Performance Considerations
- Each attempt uses high-resolution timing to measure elapsed seconds.
- The retry is bounded by `QUERY_ATTEMPTS`, preventing unbounded waits.
- Only timeouts trigger retries; deterministic failures fail fast.
- The warm-cache effect means the second attempt is expected to be faster when the first approached the Desktop query limit.
- Splitting analytics groups reduces wide requests, lowering the chance of timeout and improving partial success behavior.
- Caching avoids repeated expensive queries for historical data.

Recommendations:
- Keep `QUERY_ATTEMPTS = 2` unless measured evidence shows a different value improves reliability.
- Monitor logs for “answered on attempt” notes to confirm warm-cache behavior.
- Watch for “all N attempts failed” messages as indicators of persistent timeout conditions.
- Preserve deterministic marker coverage to avoid wasting time on retries that cannot succeed.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Symptom: Query times out once, then succeeds quickly
Likely cause:
- First attempt approached or hit the Desktop query limit.
- Second attempt benefited from a warm Bloomberg-side cache.

What to check:
- Notes containing “timed out after”.
- Notes containing “answered on attempt”.
- Attempt count equal to `QUERY_ATTEMPTS`.

Action:
- Treat as expected warm-cache recovery.
- Verify that the response is complete and cacheable.

**Section sources**
- [data.py:194-206](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L194-L206)
- [data.py:574-586](file://User scripts/FI Index Change/fi_index_change/data.py#L574-L586)
- [test_cache.py:95-109](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L95-L109)

### Symptom: Deterministic error is not retried
Likely cause:
- The error matches a deterministic marker such as missing item, entitlement failure, invalid ticker, or license issue.

What to check:
- Error message content.
- Whether `is_timeout` returns false.

Action:
- Fix the entitlement, field name, ticker, or license issue.
- Do not expect retry to resolve it.

**Section sources**
- [data.py:134-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L134-L162)
- [test_cache.py:65-74](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L65-L74)
- [test_data_request.py:348-369](file://User scripts/FI Index Change/tests/test_data_request.py#L348-L369)

### Symptom: All attempts fail with timeout
Likely cause:
- Persistent timeout condition.
- Backend overload or sustained query limit pressure.

What to check:
- Error message containing the timeout exception.
- Summary line reporting all attempts and their durations.

Action:
- Investigate backend capacity.
- Reduce request width where possible.
- Avoid changing the request shape solely to force retry; the retry is intentionally unchanged.

**Section sources**
- [data.py:208-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L208-L215)
- [data.py:588-595](file://User scripts/FI Index Change/fi_index_change/data.py#L588-L595)
- [test_cache.py:122-132](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L122-L132)
- [test_data_request.py:327-346](file://User scripts/FI Index Change/tests/test_data_request.py#L327-L346)

### Symptom: Cached result appears outdated
Likely cause:
- Pipeline or contract changed.
- Old cache entry was generated under a different code version.

What to check:
- Cache generation token.
- Whether the cached run includes required columns.
- Whether the cache key matches current inputs.

Action:
- Invalidate old cache entries.
- Ensure cache writes and pruning are working.
- Confirm that incomplete or empty runs are refused.

**Section sources**
- [test_cache.py:207-224](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L207-L224)
- [test_cache.py:226-282](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L226-L282)

## Conclusion
The BQL execution and retry management system is designed around a simple but robust principle: only transient timeouts are retried, and the retry is intentionally identical to the original request. Deterministic failures fail fast to avoid wasting time and masking real problems. The system records detailed timing and retry information, enabling operators to observe near-limit successes and diagnose persistent timeouts.

The warm cache effect is central to the design: the first request warms Bloomberg’s backend cache, and the second identical request often completes quickly. Caching further improves performance by serving previously successful runs without live BQL calls, while refusing empty or incomplete results to prevent stale or partial data from being presented as current.

Together, timeout classification, bounded retry, timing instrumentation, and safe caching provide a resilient execution model for BQL workloads in production fixed-income applications.