# BQL Response Parsing and Data Processing

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [data.py](file://User scripts/MDX Scan/mdx_scan/data.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the BQL response parsing and data processing pipeline used across several Bloomberg BQuant user scripts. The pipeline converts raw BQL responses into pandas DataFrames, processes individual item responses, merges multiple items safely, validates results, and prepares snapshot data for downstream analysis.

The core functions analyzed here are:
- `_response_to_frame`: Converts a BQL response into one DataFrame.
- `_item_frame`: Processes one BQL item response, promoting IDs, selecting value columns, handling dates, and normalizing metadata.
- `_merge_item_frames`: Combines multiple item frames while resolving duplicates and date alignment issues.
- `_parse_response`: Validates responses, collects errors and notes, performs weight validation, and determines whether a snapshot is usable.

These patterns appear in multiple modules with small variations depending on the application’s needs.

## Project Structure
The relevant code lives in four Python modules under `User scripts`. Each module implements its own BQL parsing helpers but follows the same conceptual pipeline:

```mermaid
graph TB
subgraph "FI Index Change"
FI_data["fi_index_change/data.py"]
end
subgraph "ETF Capping Monitoring"
ETF_cap_data["etf_capping/data.py"]
end
subgraph "ETF Spread Monitoring"
ETF_spread_data["etf_spread/data.py"]
end
subgraph "MDX Scan"
MDX_data["mdx_scan/data.py"]
end
FI_data --> |"uses"| FI_engine["engine.py<br/>collapse_duplicate_ids, column_has_usable_value"]
ETF_cap_data --> |"uses"| ETF_cap_engine["engine.py<br/>classify_asset"]
ETF_spread_data --> |"uses"| ETF_spread_helpers["helpers for combine/dedupe"]
MDX_data --> |"uses"| MDX_helpers["normalize_id_date, merge_item_frames"]
```

**Diagram sources**
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [data.py:1-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1-L23)
- [data.py:370-450](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L370-L450)
- [data.py:279-341](file://User scripts/MDX Scan/mdx_scan/data.py#L279-L341)

**Section sources**
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [data.py:1-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1-L23)
- [data.py:370-450](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L370-L450)
- [data.py:279-341](file://User scripts/MDX Scan/mdx_scan/data.py#L279-L341)

## Core Components
The BQL response pipeline has four main responsibilities:

| Function | Responsibility | Key Behaviors |
|---|---|---|
| `_response_to_frame` | Convert a BQL response to a DataFrame | Look up named items, iterate items, fall back to `bql.combined_df`, normalize ID and DATE, return empty DataFrame on failure |
| `_item_frame` | Process one item response | Promote index to ID, select value column, keep ID/DATE/value, rename columns, coerce types, deduplicate columns |
| `_merge_item_frames` | Combine multiple item frames | Collapse duplicate IDs, merge by ID (and optionally DATE), track duplicate counts, drop per-item DATE when not part of identity |
| `_parse_response` | Validate and enrich parsed output | Check response type, collect errors/notes, validate Weight presence and nulls, detect missing or blank items, perform quality checks |

**Section sources**
- [data.py:120-253](file://User scripts/FI Index Change/fi_index_change/data.py#L120-L253)
- [data.py:265-348](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L348)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:121-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L121-L183)
- [data.py:186-234](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L186-L234)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)
- [data.py:279-341](file://User scripts/MDX Scan/mdx_scan/data.py#L279-L341)

## Architecture Overview
The overall flow from a BQL response to a validated DataFrame is shown below.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant Parser as "_parse_response"
participant Validator as "_is_response"
participant Converter as "_response_to_frame"
participant ItemProc as "_item_frame"
participant Merger as "_merge_item_frames"
participant BQL as "bql.combined_df"
Caller->>Parser : "response, label, item_names, errors, notes"
Parser->>Validator : "validate response type"
alt Not a valid response
Validator-->>Parser : "False"
Parser->>Parser : "append error"
Parser-->>Caller : "empty DataFrame"
else Valid response
Parser->>Converter : "convert response to frame"
Converter->>ItemProc : "process each item"
ItemProc-->>Converter : "ID + optional DATE + value"
Converter->>Merger : "merge item frames"
alt Multiple items
Merger-->>Converter : "merged frame"
else Single item or fallback
Converter->>BQL : "try combined_df"
BQL-->>Converter : "combined DataFrame"
end
Converter-->>Parser : "DataFrame"
Parser->>Parser : "weight validation and quality checks"
Parser-->>Caller : "validated DataFrame"
end
```

**Diagram sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:222-253](file://User scripts/FI Index Change/fi_index_change/data.py#L222-L253)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:279-325](file://User scripts/MDX Scan/mdx_scan/data.py#L279-L325)

## Detailed Component Analysis

### `_response_to_frame`: Converting BQL Responses to DataFrames
`_response_to_frame` is the entry point for turning a BQL response into a single DataFrame. It supports three strategies:

1. **Named item lookup**: If `item_names` is provided, it tries to find each requested item by name, convert it via `_item_frame`, and merge the results.
2. **Generic item iteration**: If no named items resolve, it iterates over the response items and merges them.
3. **Fallback to `bql.combined_df`**: If item-based parsing fails, it attempts to use Bloomberg’s combined DataFrame helper, then normalizes ID and DATE.

Key behaviors:
- Named items are converted with an explicit output name so that the resulting column matches the request key.
- Generic items are converted without forcing a specific output name; the value column is inferred.
- When using `bql.combined_df`, the function ensures the ID column exists and is coerced to string.
- If all strategies fail, it returns an empty DataFrame.

```mermaid
flowchart TD
Start(["_response_to_frame"]) --> CheckNames{"item_names provided?"}
CheckNames --> |Yes| LookupItems["Lookup each name in response"]
LookupItems --> HasItems{"Any items found?"}
HasItems --> |Yes| ConvertItems["Convert each item via _item_frame"]
ConvertItems --> MergeItems["Merge item frames"]
MergeItems --> ReturnFrame["Return merged frame"]
HasItems --> |No| IterateItems["Iterate response items"]
IterateItems --> HasGeneric{"Any generic items?"}
HasGeneric --> |Yes| ConvertGeneric["Convert generic items"]
ConvertGeneric --> MergeGeneric["Merge generic frames"]
MergeGeneric --> ReturnFrame
HasGeneric --> |No| TryCombined["Try bql.combined_df"]
TryCombined --> CombinedOK{"combined_df succeeded?"}
CombinedOK --> |Yes| NormalizeCombined["Normalize ID and DATE"]
NormalizeCombined --> ReturnFrame
CombinedOK --> |No| ReturnEmpty["Return empty DataFrame"]
```

**Diagram sources**
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:210-234](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L210-L234)
- [data.py:279-305](file://User scripts/MDX Scan/mdx_scan/data.py#L279-L305)

**Section sources**
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:210-234](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L210-L234)
- [data.py:279-305](file://User scripts/MDX Scan/mdx_scan/data.py#L279-L305)

### `_item_frame`: Processing Individual Response Items
`_item_frame` transforms one BQL item response into a normalized DataFrame with:
- A stable `ID` column.
- An optional `DATE` column.
- One value column named after the item or explicitly requested output name.

Important steps:
- **Index promotion**: If the item DataFrame has a non-range index, it promotes the index to a column named `ID` if possible. Multi-level indexes are handled by assigning `ID` to the first unnamed level.
- **Column selection**: It looks for a value column by preferred alias, item name, output name, or `VALUE`. If ambiguous, it prefers the column with the most non-null values.
- **Metadata filtering**: Columns like `ID`, `DATE`, `CURRENCY`, `ORIG_IDS`, and `REVISION_DATE` are treated as metadata and excluded from value selection unless they are needed for identity.
- **Type normalization**: `ID` is coerced to string; `DATE` is coerced to datetime where present.
- **Deduplication**: Duplicate columns are removed after renaming.

```mermaid
flowchart TD
Start(["_item_frame"]) --> CopyRaw["Copy item.df()"]
CopyRaw --> PromoteIndex["Promote index to ID if needed"]
PromoteIndex --> FindColumns["Find ID, DATE, and value columns"]
FindColumns --> ValueFound{"Value column found?"}
ValueFound --> |No| EmptyDF["Return empty DataFrame"]
ValueFound --> |Yes| SelectKeep["Select ID, optional DATE, and value"]
SelectKeep --> RenameCols["Rename to ID, DATE, output_name"]
RenameCols --> CoerceTypes["Coerce ID to string, DATE to datetime"]
CoerceTypes --> DedupColumns["Remove duplicate columns"]
DedupColumns --> ReturnFrame["Return normalized frame"]
```

**Diagram sources**
- [data.py:199-253](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L253)
- [data.py:126-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L126-L183)
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)

**Section sources**
- [data.py:199-253](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L253)
- [data.py:126-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L126-L183)
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)

### `_merge_item_frames`: Combining Multiple Item Responses
`_merge_item_frames` combines multiple item DataFrames into one. Its main concerns are:
- **Duplicate ID handling**: Before merging, it collapses duplicate IDs within each frame.
- **Date alignment**: For snapshot-style data, DATE is not part of the merge key; only ID is used. For time-series data, DATE may be part of the key.
- **Outer merge semantics**: Missing values are preserved; rows from different items are aligned by ID.
- **Notes and diagnostics**: It records how many duplicate IDs were dropped and whether different DATE values appeared across items.

```mermaid
flowchart TD
Start(["_merge_item_frames"]) --> FilterFrames["Filter out None and empty frames"]
FilterFrames --> AnyFrames{"Any frames left?"}
AnyFrames --> |No| ReturnEmpty["Return empty DataFrame"]
AnyFrames --> |Yes| CountDuplicates["Count duplicate IDs before collapse"]
CountDuplicates --> CollapseIDs["Collapse duplicate IDs per frame"]
CollapseIDs --> DetermineKeys["Determine merge keys: ID (+DATE if applicable)"]
DetermineKeys --> OuterMerge["Outer merge frames by keys"]
OuterMerge --> AddNotes["Add notes about duplicates and DATE differences"]
AddNotes --> DropPerItemDate["Drop per-item DATE if not part of identity"]
DropPerItemDate --> DedupColumns["Remove duplicate columns"]
DedupColumns --> ReturnMerged["Return merged frame"]
```

**Diagram sources**
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:186-207](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L186-L207)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)

**Section sources**
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:186-207](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L186-L207)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)

### `_parse_response`: Validation, Error Collection, and Quality Checks
`_parse_response` is the outer validation layer. It ensures:
- The input is a valid BQL response.
- Parsing does not raise unhandled exceptions.
- The result is not empty.
- Weight validation passes when required.
- Missing or blank items are reported through notes.
- Snapshot usability is determined based on weights and required columns.

Weight validation logic:
- If `Weight` is missing or entirely null, the snapshot is rejected.
- Partial nulls in `Weight` are allowed but noted; those rows remain unweighted.
- In some modules, `_normalize_weights` scales fractional weights to percentages when their absolute sum is small.

Snapshot status determination:
- Status can be `ok`, `partial`, or `unavailable`.
- `ok` means all required items arrived and had usable values.
- `partial` means some items are missing or have every value empty.
- `unavailable` means the response could not produce a usable snapshot.

```mermaid
flowchart TD
Start(["_parse_response"]) --> IsValid{"Is response valid?"}
IsValid --> |No| AppendError["Append error"]
AppendError --> ReturnEmpty["Return empty DataFrame"]
IsValid --> |Yes| TryParse["Try _response_to_frame"]
TryParse --> ParseOK{"Parse succeeded?"}
ParseOK --> |No| AppendException["Append exception error"]
AppendException --> ReturnEmpty
ParseOK --> |Yes| NonEmpty{"Frame non-empty?"}
NonEmpty --> |No| AppendEmpty["Append empty-parse error"]
AppendEmpty --> ReturnEmpty
NonEmpty --> |Yes| ValidateWeight["Validate Weight column"]
ValidateWeight --> WeightOK{"Weight usable?"}
WeightOK --> |No| RejectSnapshot["Reject snapshot"]
WeightOK --> |Yes| CheckMissing["Check missing items"]
CheckMissing --> CheckBlanks["Check blank columns"]
CheckBlanks --> QualityChecks["Run additional quality checks"]
QualityChecks --> ReturnFrame["Return validated frame"]
```

**Diagram sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:308-325](file://User scripts/MDX Scan/mdx_scan/data.py#L308-L325)
- [data.py:333-341](file://User scripts/MDX Scan/mdx_scan/data.py#L333-L341)

**Section sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:308-325](file://User scripts/MDX Scan/mdx_scan/data.py#L308-L325)
- [data.py:333-341](file://User scripts/MDX Scan/mdx_scan/data.py#L333-L341)

## Dependency Analysis
The parsing pipeline depends on several internal helpers and external libraries:

| Dependency | Role | Notes |
|---|---|---|
| `pandas` | DataFrame operations | Used for merging, type coercion, deduplication, and validation |
| `bql` | Bloomberg BQL service | Optional; used for `combined_df` fallback and request execution |
| `engine` (FI Index Change) | Business logic helpers | Provides `collapse_duplicate_ids`, `column_has_usable_value`, and other snapshot preparation utilities |
| `config` | Application settings | Controls batch sizes, query attempts, and field definitions |
| `field_library` | Field definitions | Defines ITEM_NAMES, DURATION_FIELDS, NUMERIC_COLUMNS, and item builders |

```mermaid
graph LR
Parser["_parse_response"] --> Converter["_response_to_frame"]
Converter --> ItemProc["_item_frame"]
Converter --> Merger["_merge_item_frames"]
Converter --> BQL["bql.combined_df"]
Merger --> Engine["engine.collapse_duplicate_ids"]
Parser --> Validator["_is_response"]
Parser --> Helpers["_missing_items", "_returned_shape", "_shape_note"]
```

**Diagram sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)

**Section sources**
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)

## Performance Considerations
- **Avoid unnecessary iteration**: `_response_to_frame` prefers named item lookup first because it avoids iterating unknown response shapes.
- **Minimize redundant merges**: `_merge_item_frames` collapses duplicates before merging to reduce join complexity.
- **Use outer joins carefully**: Outer joins preserve missing values but can multiply rows if DATE is incorrectly included as a key for snapshot data.
- **Fallback to `bql.combined_df` cautiously**: The fallback is useful but should not mask item-level parsing problems; callers still need to validate required columns.
- **Type coercion cost**: Coercing `ID` to string and `DATE` to datetime is necessary but adds overhead; apply only when needed.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Common Issues and Resolutions

| Symptom | Likely Cause | Resolution |
|---|---|---|
| Empty DataFrame returned | Invalid response, parsing exception, or empty parsed result | Check `_is_response`, inspect error logs, verify BQL request shape |
| Missing column in output | Item did not parse or value column was not selected | Use `_missing_items` and `_returned_shape` to diagnose which item failed |
| Blank values in expected column | Column existed but every value was null | Inspect `_returned_shape`; distinguish between missing item and blank column |
| Duplicate IDs in merged frame | Multiple rows per security in one or more items | Ensure `_collapse_ids` or equivalent deduplication runs before merge |
| DATE misalignment | DATE used as merge key for snapshot data | Merge by ID only for snapshots; use ID+DATE only for time-series |
| Weight validation failure | Weight column missing or entirely null | Check BQL request includes weights; verify `_normalize_weights` scaling |
| Snapshot marked partial | Required items missing or identity columns fully blank | Review notes for missing items and empty identity columns |

**Section sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:376-405](file://User scripts/FI Index Change/fi_index_change/data.py#L376-L405)
- [data.py:333-341](file://User scripts/MDX Scan/mdx_scan/data.py#L333-L341)

## Conclusion
The BQL response parsing pipeline is designed to be robust against varied response shapes, missing data, and partial failures. It prioritizes:
- Clear separation between response validation, item processing, and merging.
- Explicit handling of ID promotion, column selection, and metadata.
- Careful merge semantics that avoid multiplying rows or losing values.
- Comprehensive error and note collection for operational visibility.
- Weight validation and snapshot status determination to ensure downstream analytics receive reliable inputs.

When extending or debugging the pipeline, focus on:
- Whether `_response_to_frame` finds the correct items.
- Whether `_item_frame` selects the intended value column.
- Whether `_merge_item_frames` uses the correct identity keys.
- Whether `_parse_response` reports missing or blank items accurately.
- Whether weight validation reflects the actual BQL request contract.

[No sources needed since this section summarizes without analyzing specific files]