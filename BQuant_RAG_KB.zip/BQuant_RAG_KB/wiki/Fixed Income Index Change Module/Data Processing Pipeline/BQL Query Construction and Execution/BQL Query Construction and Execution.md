# BQL Query Construction and Execution

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the FI index change module builds, executes, and processes Bloomberg BQL membership queries for fixed-income indices. It focuses on:

- How `_member_request` constructs a universe-based request using `bq.univ.members()` with an effective date.
- How `build_member_items` translates frozen item names into BQL data calls.
- How identity fields and analytics measures are split to reduce timeout risk.
- How responses are parsed, merged, validated, and normalized.
- How failed requests, timeouts, entitlement errors, and deterministic failures are handled.
- How historical snapshots are cached and how projection dates are treated differently from historical months.

The goal is to make the query pipeline understandable without requiring deep familiarity with the surrounding application code.

## Project Structure
The FI index change module is organized around five core files:

| File | Responsibility |
| --- | --- |
| `data.py` | Orchestrates BQL execution, response parsing, retry logic, caching decisions, and snapshot finalization. |
| `field_library.py` | Defines the frozen set of BQL items, their call builders, grouping, and output column metadata. |
| `engine.py` | Normalizes snapshots, aligns labels across dates, computes diffs, and provides classification helpers. |
| `cache.py` | Persists historical snapshots as CSVs with manifest validation, field contract checks, and generation guards. |
| `config.py` | Holds operator-confirmed constants such as month-end choices, split behavior, retry count, and display defaults. |

```mermaid
graph TB
Data["data.py<br/>Request orchestration"] --> FieldLibrary["field_library.py<br/>Frozen BQL items"]
Data --> Engine["engine.py<br/>Normalization & alignment"]
Data --> Cache["cache.py<br/>Historical cache"]
Data --> Config["config.py<br/>Runtime constants"]
Engine --> FieldLibrary
Cache --> FieldLibrary
Cache --> Engine
```

**Diagram sources**
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [field_library.py:18-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L126)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)

**Section sources**
- [data.py:1-39](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L39)
- [field_library.py:1-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L126)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [cache.py:1-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L26)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)

## Core Components
The BQL pipeline has four main responsibilities:

1. **Query construction**: Build a `bql.Request` over an index universe at a specific effective date.
2. **Item mapping**: Convert frozen item names into BQL data calls.
3. **Execution and resilience**: Execute requests, detect timeouts, retry only when safe, and record non-fatal defects.
4. **Response normalization and persistence**: Parse BQL responses into a stable DataFrame, validate required columns, and optionally cache historical snapshots.

Key entry points:

- `fetch_index_payload`: Chooses the previous and selected month-ends, loads or requests snapshots, and returns an `IndexPayload`.
- `_fetch_live`: Builds and executes one live request per effective date.
- `_member_request`: Wraps `bq.univ.members()` and `bql.Request`.
- `build_member_items`: Builds the BQL item dictionary from frozen names.
- `_parse_response`: Validates and normalizes a BQL response into a DataFrame.
- `load_historical` / `save_historical`: Read and write historical snapshots under a field contract.

**Section sources**
- [data.py:41-63](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L63)
- [data.py:494-595](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)

## Architecture Overview
At a high level, each Update asks for two effective dates:

- The previous month-end (historical).
- The selected month-end (historical or projected).

For each date, the system either reads a cached historical snapshot or executes a live BQL request. Historical snapshots are immutable once written; projected snapshots are never cached.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant Data as "data.py"
participant Cache as "cache.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
Caller->>Data : fetch_index_payload(index_ticker, selected_date)
Data->>Data : compute previous_date and kind
Data->>Cache : load_historical(previous_date)
alt Cached historical available
Cache-->>Data : historical frame
Data->>Engine : _finalize_snapshot()
Data->>Data : mark status ok/partial
else No usable cache
Data->>BQL : execute membership request
BQL-->>Data : response
Data->>Data : _parse_response()
Data->>Engine : _finalize_snapshot()
Data->>Cache : save_historical(previous_date) if allowed
end
Data->>Data : repeat for selected_date
Data->>Engine : align_snapshot_labels(previous, latest)
Data-->>Caller : IndexPayload
```

**Diagram sources**
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)

## Detailed Component Analysis

### BQL Request Construction: `_member_request`
`_member_request` is the narrow bridge between this module’s frozen item model and Bloomberg’s BQL API. It takes:

- A BQL service object.
- An index ticker.
- An effective date string.
- A dictionary of BQL data calls.

It then creates a universe from `bq.univ.members(index_ticker, dates=as_of)` and wraps it in a `bql.Request` with `mode="cached"`.

```mermaid
flowchart TD
Start(["_member_request"]) --> Universe["Create universe<br/>bq.univ.members(index_ticker, dates=as_of)"]
Universe --> Request["Build bql.Request(universe, items,<br/>with_params={'mode': 'cached'})"]
Request --> End(["Return request"])
```

**Diagram sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)

**Section sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)

### Item Mapping: `build_member_items`
`build_member_items` converts frozen item names into BQL data calls. The frozen item list includes:

- Identity fields: name, issuer, sector, country, currency, security type, maturity, tenor, rating, coupon, weight, ISIN, SEDOL.
- Analytics fields: spreads, durations, and yields.

The builder validates that every requested name exists in the frozen table and raises a typed error when a name is unknown. When called with a subset of names, it builds only those calls, which is essential for the split-request path.

```mermaid
classDiagram
class FieldLibrary {
+SPREAD_FIELDS
+DURATION_FIELDS
+YIELD_FIELDS
+ITEM_NAMES
+ANALYTICS_NAMES
+ANALYTICS_GROUPS
+NUMERIC_COLUMNS
+STRING_COLUMNS
+build_member_items(bq, names) dict
-_calls(bq, names) dict
}
class ItemBuildError {
+item str
+cause BaseException
}
FieldLibrary --> ItemBuildError : "raises on unknown or failing item"
```

**Diagram sources**
- [field_library.py:18-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L126)
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

**Section sources**
- [field_library.py:18-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L126)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

### Request Splitting: Identity vs Analytics
When `SPLIT_REQUESTS` is enabled, the module separates identity fields from analytics measures:

1. Identity fields are built and executed first.
2. Analytics fields are grouped by family:
   - Spreads and yields.
   - Durations.
3. Each group is executed as its own request.
4. Failed groups are recorded but do not invalidate the entire month.
5. Only complete, parseable results are considered cache-safe.

This design reduces the chance that a single wide request times out and makes it easier to identify which measure family caused a failure.

```mermaid
flowchart TD
Start(["_fetch_live"]) --> CheckSplit{"SPLIT_REQUESTS?"}
CheckSplit --> |No| FullItems["build_member_items(ITEM_NAMES)"]
CheckSplit --> |Yes| IdentityNames["identity_names = ITEM_NAMES minus ANALYTICS_NAMES"]
IdentityNames --> IdentityItems["build_member_items(identity_names)"]
IdentityItems --> IdentityExec["Execute identity request"]
IdentityExec --> IdentityParse["_parse_response(identity)"]
IdentityParse --> AnalyticsGroups["Iterate ANALYTICS_GROUPS"]
AnalyticsGroups --> GroupItems["build_member_items(group)"]
GroupItems --> GroupExec["Execute group request"]
GroupExec --> GroupParse["_response_to_frame(group)"]
GroupParse --> Merge["Merge group into identity frame"]
Merge --> NextGroup{"More groups?"}
NextGroup --> |Yes| AnalyticsGroups
NextGroup --> |No| Result(["Return merged frame and cache_ok"])
FullItems --> FullExec["Execute full request"]
FullExec --> FullParse["_parse_response(full)"]
FullParse --> Result
```

**Diagram sources**
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:102-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L102-L121)

**Section sources**
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:102-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L102-L121)
- [config.py:88-94](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L94)

### Response Parsing and Validation
The response pipeline performs several safety checks before producing a usable DataFrame:

- Detect whether the value is a valid BQL response.
- Extract item frames by name or by iterating response items.
- Promote ID indexes so IDs can be safely reset into a column.
- Pick the correct value column for each item.
- Collapse duplicate IDs while preserving non-null values.
- Merge multiple item frames on ID.
- Require a populated `Weight` column.
- Report missing or empty items without silently treating them as successful.

```mermaid
flowchart TD
Start(["_parse_response"]) --> Valid{"Is response?"}
Valid --> |No| Error["Append error and return empty frame"]
Valid --> |Yes| ToFrame["_response_to_frame()"]
ToFrame --> Empty{"Frame empty?"}
Empty --> |Yes| EmptyNote["Append empty note and return empty frame"]
Empty --> |Yes| WeightCheck["Validate Weight column"]
WeightCheck --> MissingItems["Detect missing item columns"]
MissingItems --> EmptyColumns["Detect columns present but entirely null"]
EmptyColumns --> DurationChecks["Warn about identical duration columns"]
DurationChecks --> Return(["Return parsed frame"])
```

**Diagram sources**
- [data.py:66-97](file://User scripts/FI Index Change/fi_index_change/data.py#L66-L97)
- [data.py:100-117](file://User scripts/FI Index Change/fi_index_change/data.py#L100-L117)
- [data.py:199-253](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L253)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

**Section sources**
- [data.py:66-97](file://User scripts/FI Index Change/fi_index_change/data.py#L66-L97)
- [data.py:199-321](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L321)
- [data.py:324-491](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L491)

### Execution, Timeout Detection, and Retry Logic
The execution layer distinguishes between:

- **Timeouts**: Temporary conditions where a second identical attempt may succeed because Bloomberg-side caching warmed.
- **Deterministic failures**: Invalid item names, missing entitlements, unauthorized access, invalid tickers, or other errors that will not improve on retry.

Only timeouts trigger retries, up to `QUERY_ATTEMPTS`. Every attempt records elapsed time and appends notes describing timing behavior. Non-timeout exceptions are appended to the error list and stop further attempts.

```mermaid
flowchart TD
Start(["_execute_attempts"]) --> Attempts["Read QUERY_ATTEMPTS"]
Attempts --> Loop{"Attempt n"}
Loop --> Execute["Execute _member_request"]
Execute --> Success{"Success?"}
Success --> |Yes| Timing["Record elapsed time"]
Timing --> WarmNote{"Attempt > 1?"}
WarmNote --> |Yes| WarmNoteText["Append warm-cache note"]
WarmNote --> |No| ReturnResp["Return response and attempts"]
WarmNoteText --> ReturnResp
Success --> |No| TimeoutCheck{"is_timeout(exc)?"}
TimeoutCheck --> |No| Fail["Append error and stop"]
TimeoutCheck --> |Yes| LastAttempt{"Last attempt?"}
LastAttempt --> |Yes| Fail
LastAttempt --> |No| Retry["Append timeout note and retry"]
Retry --> Loop
```

**Diagram sources**
- [data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [config.py:96-104](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L104)

**Section sources**
- [data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [config.py:96-104](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L104)

### Caching Mechanisms and Projection Date Handling
Historical snapshots are persisted as CSVs with a JSON manifest. Before loading or saving, the cache enforces:

- Field contract: the stored item list must match the current frozen `ITEM_NAMES`.
- Label contract: country overrides, MBS/TBA label, municipal label, and missing-rating token must match.
- Generation guard: protects against old merge-key bugs that produced mostly blank identity columns.
- Required columns: identity columns plus `Weight` must exist.
- Usable identity values: at least one identity column must carry a real value.
- Weight presence: at least one non-null weight is required.

Projection dates are explicitly excluded from the cache. Historical dates older than today may be saved only when the response is fully parseable and cache-safe.

```mermaid
flowchart TD
Start(["Historical snapshot decision"]) --> Load["load_historical(ticker, as_of)"]
Load --> Manifest["Validate manifest, fields, generation, columns"]
Manifest --> ReadCSV["Read CSV and coerce numeric columns"]
ReadCSV --> WeightCheck{"Has usable Weight?"}
WeightCheck --> |No| Reject["Reject cache entry"]
WeightCheck --> |Yes| IdentityCheck{"Any usable identity column?"}
IdentityCheck --> |No| Reject
IdentityCheck --> |Yes| UseCached["Use cached frame"]
UseCached --> Finalize["_finalize_snapshot(as_of, kind)"]
Finalize --> Status["Set status ok or partial"]
Reject --> Live["Request live data"]
Live --> SaveDecision{"Historical and cache_ok and older than today?"}
SaveDecision --> |Yes| Save["save_historical()"]
SaveDecision --> |No| Skip["Skip cache write"]
```

**Diagram sources**
- [cache.py:28-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L28-L57)
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)
- [data.py:740-820](file://User scripts/FI Index Change/fi_index_change/data.py#L740-L820)

**Section sources**
- [cache.py:28-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L28-L57)
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)
- [data.py:740-820](file://User scripts/FI Index Change/fi_index_change/data.py#L740-L820)

### Snapshot Normalization and Projection Date Semantics
After a response is parsed, `_finalize_snapshot` delegates to `prepare_members`, which:

- Normalizes IDs and removes blank or duplicate rows.
- Scales weights from fractions to percent points when appropriate.
- Coerces numeric analytics columns.
- Blank-fills text columns.
- Applies country-name overrides and proper title casing.
- Labels MBS/TBA and Municipal bonds specially.
- Computes Tenor Bucket and Rating Bucket.
- Adds `AS_OF_DATE` and `SNAPSHOT_KIND`.

The `kind` field distinguishes historical snapshots from projected snapshots. The projection date is requested on every Update and is not cached, because its membership cannot be verified later.

```mermaid
flowchart TD
Start(["_finalize_snapshot"]) --> Prepare["engine.prepare_members(frame)"]
Prepare --> Dates["Add AS_OF_DATE and SNAPSHOT_KIND"]
Dates --> Numeric["Coerce NUMERIC_COLUMNS"]
Numeric --> Return(["Return prepared snapshot"])
```

**Diagram sources**
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [field_library.py:123-142](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L142)

**Section sources**
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [field_library.py:123-142](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L142)

## Dependency Analysis
The following diagram shows how the modules depend on each other during a typical update.

```mermaid
graph LR
Config["config.py"] --> Data["data.py"]
FieldLibrary["field_library.py"] --> Data
FieldLibrary --> Cache
Engine["engine.py"] --> Data
Engine --> Cache
Cache --> Data
Data --> BQL["Bloomberg BQL"]
```

**Diagram sources**
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)

**Section sources**
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)

## Performance Considerations
The module is designed around Bloomberg’s two-minute query limit and the cost of wide membership requests:

- **Split requests**: Enabled by default, splitting identity fields from analytics families reduces the width of each request.
- **Retry only on timeouts**: Deterministic failures are not retried, avoiding wasted time.
- **Warm-cache recovery**: A second identical request may succeed quickly after Bloomberg-side caching warms.
- **Caching historical snapshots**: Once written, historical months avoid repeated network calls.
- **Projection exclusion**: Projected months are not cached, preventing stale or unverifiable projections from becoming permanent.
- **Grouped analytics**: Spreads and yields are grouped together, while durations are separate, reflecting their different computational characteristics.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their handling:

| Symptom | Likely Cause | System Behavior |
| --- | --- | --- |
| Entire month unavailable | Missing or entirely null `Weight` column | Request is marked unavailable and not cached. |
| Month shown as partial | One or more identity columns did not parse or arrived entirely blank | Notes name missing or empty identity columns; cache is refused. |
| Some analytics columns blank | Analytics group failed or returned no values | Group is skipped; month remains usable without that group. |
| Repeated timeout | Wide request near Bloomberg’s two-minute limit | Same request is retried once; notes describe timing. |
| Entitlement or license error | Login lacks access to index or fields | Classified as deterministic; no retry. |
| Unknown item name | Frozen item list changed or caller passed invalid name | Raises `ItemBuildError` with the failing item name. |
| Stale cache showing blank identities | Old cache written before ID-only merge fix | Generation and field contracts reject the old entry. |

Recommended diagnostics:

- Inspect payload `errors` and `notes`.
- Check whether the month is historical or projected.
- Confirm whether `SPLIT_REQUESTS` is enabled.
- Verify that the index ticker ends with ` Index`.
- Review whether the response carried the expected item columns.
- Confirm that the cache manifest matches the current field contract.

**Section sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:529-538](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L538)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:740-820](file://User scripts/FI Index Change/fi_index_change/data.py#L740-L820)
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)

## Conclusion
The FI index change module implements a robust, operator-aware BQL pipeline:

- Queries are built from a frozen item table rather than user input.
- Universe membership is requested per effective date using `bq.univ.members()`.
- Identity and analytics fields are split to reduce timeout risk.
- Responses are carefully parsed, validated, and normalized.
- Timeouts are retried; deterministic failures are not.
- Historical snapshots are cached under strict field and generation contracts.
- Projected snapshots are requested but never cached.

This design prioritizes correctness, observability, and resilience over raw speed, while still taking advantage of Bloomberg-side caching and local historical storage.

[No sources needed since this section summarizes without analyzing specific files]