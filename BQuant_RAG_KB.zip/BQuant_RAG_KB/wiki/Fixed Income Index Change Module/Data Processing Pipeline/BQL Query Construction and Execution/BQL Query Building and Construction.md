# BQL Query Building and Construction

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the FI Index Change module builds Bloomberg BQL queries for fixed-income index membership snapshots. It focuses on:

- How `_member_request` constructs universe-based requests using `bq.univ.members()` with effective dates.
- How `build_member_items` creates field dictionaries from frozen item names and analytics groups.
- The separation between identity fields and analytics measures.
- Request object construction, parameter passing, and response parsing.
- The `SPLIT_REQUESTS` configuration option and its impact on query optimization.
- Error handling during request building, execution, and validation of BQL service availability.

The goal is to make the query-building logic understandable without requiring deep familiarity with the rest of the application.

## Project Structure
The BQL query-building logic lives primarily in three files:

| File | Responsibility |
|---|---|
| `data.py` | Orchestrates BQL service access, request execution, retry behavior, response parsing, caching, and snapshot finalization. |
| `field_library.py` | Defines the frozen set of data items, their BQL builder calls, identity vs analytics classification, and numeric/string column metadata. |
| `config.py` | Holds runtime configuration such as `SPLIT_REQUESTS`, `QUERY_ATTEMPTS`, month-end dropdown size, and display constants. |
| `engine.py` | Normalizes responses into a standard member frame, computes comparisons, summaries, and dashboard metrics. |

```mermaid
graph TB
Data["data.py<br/>Request orchestration"] --> FieldLibrary["field_library.py<br/>Frozen item definitions"]
Data --> Config["config.py<br/>Runtime options"]
Data --> Engine["engine.py<br/>Member normalization"]
FieldLibrary --> Data
Config --> Data
Engine --> Data
```

**Diagram sources**
- [data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [field_library.py:1-127](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L127)
- [config.py:1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)

**Section sources**
- [data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [field_library.py:1-127](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L127)
- [config.py:1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)

## Core Components
The BQL query system has four main responsibilities:

1. **Universe construction**: Select index members at a specific effective date.
2. **Item dictionary construction**: Map requested field names to BQL data calls.
3. **Request execution and retry**: Execute one or more BQL requests with timeout-aware retries.
4. **Response normalization**: Convert BQL responses into a standardized pandas DataFrame with identity and analytics columns.

Key entry points:

| Function | Purpose |
|---|---|
| `_member_request` | Builds a `bql.Request` over an index universe at an effective date. |
| `build_member_items` | Converts a list of item names into a BQL item dictionary. |
| `_fetch_live` | Chooses between a single wide request and split identity/analytics requests. |
| `_execute_attempts` | Executes a request with controlled retries for timeouts. |
| `_parse_response` | Parses a BQL response into a normalized DataFrame and records missing or empty items. |

**Section sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [field_library.py:213-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L213-L215)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

## Architecture Overview
At a high level, the FI Index Change module does not build raw BQL strings. Instead, it composes BQL objects:

1. A universe expression is created with `bq.univ.members(index_ticker, dates=as_of)`.
2. A dictionary of data items is built by `build_member_items`.
3. A `bql.Request` is constructed with the universe, items, and cached mode.
4. The request is executed through `bq.execute`.
5. Responses are parsed into a DataFrame and then normalized by `prepare_members`.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant Data as "data.py"
participant FieldLib as "field_library.py"
participant BQ as "BQL Service"
participant Engine as "engine.py"
Caller->>Data : fetch_index_payload(selected_date)
Data->>FieldLib : build_member_items(ITEM_NAMES)
FieldLib-->>Data : items dict
Data->>Data : _member_request(bq, index_ticker, as_of, items)
Data->>BQ : execute(Request)
BQ-->>Data : response
Data->>Data : _parse_response(response)
Data->>Engine : prepare_members(frame)
Engine-->>Data : normalized snapshot
```

**Diagram sources**
- [data.py:713-759](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L759)
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [field_library.py:213-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L213-L215)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

## Detailed Component Analysis

### Universe-Based Requests with Effective Dates
The `_member_request` function is the central point where a BQL universe and a BQL request are assembled:

- It receives a BQL service instance, an index ticker, an effective date string, and a prebuilt items dictionary.
- It creates a universe with `bq.univ.members(index_ticker, dates=as_of)`.
- It returns a `bql.Request` that includes the universe, the items dictionary, and `with_params={"mode": "cached"}`.

This means every membership snapshot is tied to a specific effective date rather than “today.” Historical months use the historical effective date; the projected month uses the projected effective date.

```mermaid
flowchart TD
Start(["_member_request"]) --> BuildUniverse["Create universe<br/>bq.univ.members(index_ticker, dates=as_of)"]
BuildUniverse --> BuildRequest["Build bql.Request(universe, items,<br/>with_params={'mode': 'cached'})"]
BuildRequest --> Return(["Return Request"])
```

**Diagram sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)

**Section sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)

### Item Dictionary Construction with `build_member_items`
`build_member_items` converts a list of item names into a dictionary mapping each name to a BQL data call. The implementation:

- Uses a frozen internal table `_ITEM_CALLS` that maps each output column name to a lambda calling `bq.data.<field>(...)`.
- Validates requested names against known item names.
- Raises `ItemBuildError` when a specific item cannot be built, preserving the failing item name and underlying exception.
- Returns only the requested subset of items, which is important when splitting identity and analytics requests.

The frozen item set includes:

| Category | Fields |
|---|---|
| Identity and metadata | Name, Issuer, Sector, Country, Currency, Security Type, Maturity, Tenor, Rating, Coupon, Weight, ISIN, SEDOL |
| Spreads | OAS, Z-Spread, I-Spread |
| Durations | Duration, Modified Duration, Effective Duration, OASD |
| Yields | Yield, YTM, YTW |

Identity fields are those required for membership interpretation: security identifiers, descriptive labels, weight, and basic attributes. Analytics fields are derived measures such as spreads, durations, and yields.

```mermaid
classDiagram
class FieldLibrary {
+ITEM_NAMES
+SPREAD_FIELDS
+DURATION_FIELDS
+YIELD_FIELDS
+ANALYTICS_NAMES
+ANALYTICS_GROUPS
+NUMERIC_COLUMNS
+STRING_COLUMNS
+build_member_items(bq, names)
-_calls(bq, names)
-_ITEM_CALLS
}
class ItemBuildError {
+item
+cause
}
FieldLibrary --> ItemBuildError : "raises on failed item"
```

**Diagram sources**
- [field_library.py:18-86](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L86)
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

**Section sources**
- [field_library.py:18-86](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L86)
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

### Query Structure Patterns
The module follows consistent patterns when constructing BQL queries:

| Pattern | Implementation |
|---|---|
| Universe selection | `bq.univ.members(index_ticker, dates=as_of)` |
| Data item mapping | Frozen lambdas under `_ITEM_CALLS` |
| Request composition | `bql.Request(universe, items, with_params={"mode": "cached"})` |
| Execution | `bq.execute(request)` |
| Response handling | Named-item lookup, fallback to iterable items, fallback to combined DataFrame |
| Normalization | `_response_to_frame` → `_merge_item_frames` → `prepare_members` |

The request structure is intentionally declarative: the caller supplies a universe and a dictionary of named data items, and the BQL service resolves them. The code avoids constructing raw query strings, reducing formatting errors and keeping the contract between Python and BQL explicit.

**Section sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)

### Parameter Passing Mechanisms
Parameter passing flows through several layers:

1. `fetch_index_payload` determines the previous and selected effective dates.
2. `_fetch_live` chooses whether to build all items or split identity and analytics.
3. `build_member_items` receives either `ITEM_NAMES` or a subset tuple.
4. `_member_request` receives the resulting items dictionary and passes it to `bql.Request`.
5. `_execute_attempts` rebuilds the request per attempt so no stale state leaks across retries.

```mermaid
flowchart TD
SelectedDate["Selected effective date"] --> Comparison["comparison_for()"]
Comparison --> FetchLive["_fetch_live()"]
FetchLive --> SplitCheck{"SPLIT_REQUESTS?"}
SplitCheck --> |No| AllItems["build_member_items(ITEM_NAMES)"]
SplitCheck --> |Yes| IdentityItems["build_member_items(identity_names)"]
IdentityItems --> IdentityExec["_execute_attempts(identity_items)"]
AllItems --> FullExec["_execute_attempts(all_items)"]
IdentityExec --> GroupedAnalytics["One request per ANALYTICS_GROUPS"]
GroupedAnalytics --> Merge["Merge identity and analytics"]
FullExec --> Parse["_parse_response()"]
Merge --> Parse
Parse --> Normalize["prepare_members()"]
```

**Diagram sources**
- [data.py:713-759](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L759)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)

**Section sources**
- [data.py:713-759](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L759)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)

### Separation of Identity Fields and Analytics Measures
The code explicitly separates identity fields from analytics measures:

- `ITEM_NAMES` contains all required fields.
- `ANALYTICS_NAMES` contains spread, duration, and yield fields.
- `identity_names` is computed as `ITEM_NAMES` minus `ANALYTICS_NAMES`.
- When `SPLIT_REQUESTS` is enabled, the first request asks only for identity fields.
- Subsequent requests ask for analytics families defined in `ANALYTICS_GROUPS`.

This separation improves resilience: if a heavy analytics family fails, the identity data can still be shown with a note naming the missing group.

```mermaid
flowchart TD
AllItems["ITEM_NAMES"] --> Analytics["ANALYTICS_NAMES"]
AllItems --> Identity["identity_names = ITEM_NAMES - ANALYTICS_NAMES"]
Identity --> IdentityRequest["Identity request"]
Analytics --> Groups["ANALYTICS_GROUPS"]
Groups --> SpreadYieldGroup["Spreads + Yields"]
Groups --> DurationGroup["Durations"]
SpreadYieldGroup --> AnalyticsRequest1["Analytics request 1"]
DurationGroup --> AnalyticsRequest2["Analytics request 2"]
IdentityRequest --> MergeFrames["Merge by ID"]
AnalyticsRequest1 --> MergeFrames
AnalyticsRequest2 --> MergeFrames
```

**Diagram sources**
- [field_library.py:58-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L75)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)
- [data.py:637-698](file://User scripts/FI Index Change/fi_index_change/data.py#L637-L698)

**Section sources**
- [field_library.py:58-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L75)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)
- [data.py:637-698](file://User scripts/FI Index Change/fi_index_change/data.py#L637-L698)

### SPLIT_REQUESTS Configuration and Query Optimization
`SPLIT_REQUESTS` controls whether the membership request is sent as one wide request or split into smaller requests:

| Setting | Behavior |
|---|---|
| `False` | One request containing all `ITEM_NAMES`. |
| `True` | One identity request plus one request per analytics group. |

The default is `True`. The rationale is that a single large request can exceed the Desktop two-minute query limit, while splitting by measure family makes failures easier to diagnose and allows partial results to survive.

Analytics groups are:

| Group | Fields |
|---|---|
| Group 1 | Spreads and yields |
| Group 2 | Durations |

Durations are placed last because they are model-evaluated and most likely to time out. If the duration group fails, the month can still show securities, weights, spreads, and yields.

```mermaid
flowchart TD
Start(["_fetch_live"]) --> CheckSplit{"SPLIT_REQUESTS"}
CheckSplit --> |False| SingleRequest["Single request with ITEM_NAMES"]
CheckSplit --> |True| IdentityFirst["Identity request"]
IdentityFirst --> GroupLoop["Loop ANALYTICS_GROUPS"]
GroupLoop --> GroupSuccess{"Group succeeded?"}
GroupSuccess --> |Yes| MergeGroup["Merge group into merged frame"]
GroupSuccess --> |No| RecordFail["Record failed group"]
MergeGroup --> NextGroup["Next group"]
RecordFail --> NextGroup
NextGroup --> Finalize["Finalize merged frame"]
SingleRequest --> Finalize
```

**Diagram sources**
- [config.py:88-94](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L94)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)

**Section sources**
- [config.py:88-94](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L94)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)

### Concrete Examples of BQL Query Syntax and Request Construction
Although the code does not construct raw BQL strings, the logical query shape is clear:

- **Universe**: Index members at a specific effective date.
- **Fields**: A fixed set of descriptor and analytics fields.
- **Mode**: Cached mode via `with_params={"mode": "cached"}`.

Conceptually, this corresponds to a BQL pattern like:

```text
bq.univ.members("INDEX_TICKER Index", dates="YYYY-MM-DD")
```

followed by a request that includes fields such as:

```text
Name
Issuer
Sector
Country
Currency
Security Type
Maturity
Tenor
Rating
Coupon
OAS
Z-Spread
I-Spread
Duration
Modified Duration
Effective Duration
OASD
Yield
YTM
YTW
Weight
ISIN
SEDOL
```

In the split path, the same fields are divided into:

- Identity-only request: Name, Issuer, Sector, Country, Currency, Security Type, Maturity, Tenor, Rating, Coupon, Weight, ISIN, SEDol.
- Analytics request 1: OAS, Z-Spread, I-Spread, Yield, YTM, YTW.
- Analytics request 2: Duration, Modified Duration, Effective Duration, OASD.

These examples describe the logical request shape; the actual implementation uses BQL object APIs rather than string concatenation.

**Section sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [field_library.py:58-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L75)
- [field_library.py:101-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L101-L121)

### Field Mapping and Response Parsing
After a successful BQL execution, the response is converted into a DataFrame through several steps:

1. **Named item lookup**: Try to find a response item by its requested name.
2. **Iterable fallback**: Iterate over response items if named lookup fails.
3. **Combined fallback**: Use `bql.combined_df` when available.
4. **Value column selection**: Pick the best value column per item, preferring documented aliases and populated columns.
5. **ID promotion**: Ensure the index becomes an `ID` column.
6. **Merge**: Outer merge by `ID`, collapsing duplicates while keeping the last non-null value.
7. **Normalization**: Apply `prepare_members` to standardize text, numeric types, book classification, tenor buckets, and rating buckets.

```mermaid
flowchart TD
Response["BQL response"] --> Lookup["_lookup_item(name)"]
Lookup --> Found{"Found named item?"}
Found --> |Yes| ItemFrame["_item_frame()"]
Found --> |No| IterableFallback["_response_items()"]
IterableFallback --> CombinedFallback["bql.combined_df()"]
ItemFrame --> ValuePick["_pick_value_column()"]
CombinedFallback --> NormalizeColumns["Normalize ID and DATE"]
ValuePick --> NormalizeColumns
NormalizeColumns --> Merge["_merge_item_frames()"]
Merge --> Prepare["prepare_members()"]
```

**Diagram sources**
- [data.py:100-117](file://User scripts/FI Index Change/fi_index_change/data.py#L100-L117)
- [data.py:134-196](file://User scripts/FI Index Change/fi_index_change/data.py#L134-L196)
- [data.py:199-253](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L253)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

**Section sources**
- [data.py:100-117](file://User scripts/FI Index Change/fi_index_change/data.py#L100-L117)
- [data.py:134-196](file://User scripts/FI Index Change/fi_index_change/data.py#L134-L196)
- [data.py:199-253](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L253)
- [data.py:265-321](file://User scripts/FI Index Change/fi_index_change/data.py#L265-L321)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

## Dependency Analysis
The BQL query-building layer depends on:

- **BQL service**: Only available inside Bloomberg BQuant Desktop.
- **Frozen field definitions**: Prevent dynamic or widget-driven field construction.
- **Configuration**: Controls retry behavior and request splitting.
- **Engine normalization**: Ensures downstream dashboards receive a stable schema.

```mermaid
graph LR
BQL["BQL Service"] --> DataModule["data.py"]
FieldDefs["field_library.py"] --> DataModule
Config["config.py"] --> DataModule
DataModule --> EngineModule["engine.py"]
```

**Diagram sources**
- [data.py:14-34](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L34)
- [field_library.py:1-127](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L127)
- [config.py:1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)

**Section sources**
- [data.py:14-34](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L34)
- [field_library.py:1-127](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L127)
- [config.py:1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)

## Performance Considerations
The query-building design prioritizes reliability and observability over maximum throughput:

- **Cached mode**: Requests use `with_params={"mode": "cached"}` to reuse Bloomberg-side cache when possible.
- **Split requests**: Defaulting to `SPLIT_REQUESTS=True` reduces the chance of a single oversized request timing out.
- **Timeout-only retries**: Only timeout-like exceptions trigger a second identical attempt. Deterministic failures such as invalid tickers, unknown fields, or entitlement problems are not retried.
- **Partial results**: When analytics groups fail, identity and other analytics groups remain available instead of discarding the entire month.
- **Cache safety**: Months with missing required items or unusable identity columns are marked partial and are not written to the cache.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### BQL Service Availability
If the BQL module is unavailable, the code raises a runtime error indicating that the app must run on Bloomberg BQuant Desktop. This protects local development environments from attempting live BQL calls.

**Section sources**
- [data.py:60-63](file://User scripts/FI Index Change/fi_index_change/data.py#L60-L63)

### Invalid or Unentitled Items
When building item dictionaries, unknown item names raise `KeyError`, and individual item builders raise `ItemBuildError`. These errors include the failing item name and the underlying exception, making it easier to identify rejected or missing BQL data items.

**Section sources**
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [field_library.py:190-210](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L210)

### Timeout Detection and Retries
The code distinguishes between:

- **Timeout markers**: Indicates the Desktop two-minute query limit may have been exceeded.
- **Deterministic markers**: Indicates a failure that will not improve on retry, such as invalid ticker, unknown field, or entitlement problem.

Only timeout-like exceptions are retried up to `QUERY_ATTEMPTS`.

**Section sources**
- [data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [config.py:96-104](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L104)

### Missing or Empty Response Columns
`_parse_response` records detailed notes when:

- The response is not a valid BQL response.
- The response parses but produces an empty frame.
- Required items are missing.
- Items arrive with columns but every value is null.
- Duration items return identical values across rows, suggesting a builder parameter issue.

**Section sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

### Membership License or Access Failure
The engine includes helpers to detect membership license failures. A 403 is treated as a session problem rather than a membership license message. The membership license message is matched against keywords such as entitlement, permission, license, unauthorized, and related terms.

**Section sources**
- [engine.py:99-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L99-L119)

## Conclusion
The FI Index Change module builds BQL membership queries using a layered, defensive design:

- Universes are anchored to effective dates through `bq.univ.members(index_ticker, dates=as_of)`.
- Field dictionaries are frozen and validated before execution.
- Requests are composed as BQL objects with cached mode.
- Identity fields and analytics measures are separated, especially when `SPLIT_REQUESTS` is enabled.
- Errors are classified carefully, with retries reserved for timeouts and deterministic failures reported immediately.
- Responses are normalized into a stable DataFrame schema suitable for comparison, filtering, and dashboard aggregation.

This approach favors predictable behavior, clear diagnostics, and partial result resilience over aggressive optimization.

[No sources needed since this section summarizes without analyzing specific files]