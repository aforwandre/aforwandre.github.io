# Data Processing Pipeline

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the data processing pipeline behind the Fixed Income Index Change module. It focuses on how Bloomberg BQL membership snapshots are requested, parsed, normalized, cached, and compared across two month-end dates to produce index add/exit changes, dashboard summaries, and export tables.

The pipeline is designed for robustness: it validates inputs, isolates MBS/TBA and municipal securities from standard corporate bonds, normalizes weights and labels, aligns classifications between months, retries only recoverable timeouts, and refuses to cache incomplete or potentially stale results.

## Project Structure
The FI Index Change module is organized into focused layers:

- **App layer**: UI controller that wires widgets, triggers updates, and renders charts and tables.
- **Data layer**: Builds and executes BQL requests, parses responses, handles caching, and returns an `IndexPayload`.
- **Engine layer**: Normalizes snapshots, computes differences, aligns labels, summarizes by dimension, and formats exports.
- **Field library**: Frozen list of BQL items and their builders.
- **Config**: Operator-approved defaults, display rules, request behavior, and thresholds.
- **Cache**: CSV-based storage with manifest validation and field-contract checks.

```mermaid
graph TB
App["app.py<br/>UI Controller"] --> Data["data.py<br/>BQL Requests & Cache"]
Data --> FieldLib["field_library.py<br/>Frozen BQL Items"]
Data --> Cache["cache.py<br/>CSV Snapshot Store"]
Data --> Engine["engine.py<br/>Normalization & Comparison"]
Engine --> Config["config.py<br/>Defaults & Rules"]
App --> Engine
App --> Config
```

**Diagram sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [data.py:41-57](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L57)
- [engine.py:66-96](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L96)
- [field_library.py:58-86](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L86)
- [cache.py:1-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L57)
- [config.py:12-120](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L120)

**Section sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [data.py:1-57](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L57)
- [engine.py:1-96](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L96)
- [field_library.py:1-86](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L86)
- [cache.py:1-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L57)
- [config.py:1-120](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L120)

## Core Components
- **`FIIndexChangeApp`**: Wires input widgets, calls `fetch_index_payload`, builds a `Transition`, refreshes filters, and renders charts and tables.
- **`IndexPayload`**: Holds index ticker, previous and selected dates, snapshots, statuses, errors, notes, and optional turnover metadata.
- **`Comparison` / `Transition`**: Encapsulate the selected month-end versus the previous month-end, including status, warnings, and computed change frames.
- **`prepare_members`**: Normalizes one snapshot: ID cleanup, duplicate handling, weight scaling, numeric coercion, country/title formatting, book isolation, rating bucketing, and tenor bucketing.
- **`align_snapshot_labels`**: Ensures consistent classification per ID across both snapshots before computing differences.
- **`diff_members`**: Computes Add and Exit rows inside a chosen book.
- **`summarize`**: Produces bucket-level metrics, turnover, and headline aggregates.
- **`_fetch_live`**: Executes BQL membership requests, optionally split by analytics family, parses responses, and decides cache safety.
- **`load_historical` / `save_historical`**: Persist and validate historical snapshots against field contracts and generation tokens.

**Section sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [data.py:41-57](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L57)
- [engine.py:66-96](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L96)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L630)
- [engine.py:643-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L729)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [cache.py:146-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L229)

## Architecture Overview
The end-to-end flow starts when the user clicks Update. The app validates the index ticker and month-end, fetches the two relevant month-ends, normalizes them, aligns labels, and builds a comparison. The UI then renders dimension charts, bond detail, and export tables.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "FIIndexChangeApp"
participant Data as "data.fetch_index_payload"
participant Cache as "cache.load_historical"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.prepare_members"
participant Transition as "engine.build_transition"
User->>App : Click Update
App->>App : Validate index ticker and month-end
App->>Data : fetch_index_payload(index_ticker, selected_date)
Data->>Cache : load_historical(previous_date)
alt Historical cache hit
Cache-->>Data : Cached frame
Data->>Engine : prepare_members(cached_frame)
else No cache or invalid contract
Data->>BQL : Execute membership request(s)
BQL-->>Data : Response items
Data->>Data : Parse, merge, validate Weight
Data->>Engine : prepare_members(live_frame)
Data->>Cache : save_historical(historical_only)
end
Data->>Data : Align labels across previous and latest
Data-->>App : IndexPayload
App->>Transition : build_transition(snapshots, comparison, statuses)
Transition-->>App : Transition
App->>App : Render charts, summary, and export tables
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [cache.py:146-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L229)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

## Detailed Component Analysis

### Month-End Business Day Handling
The pipeline uses Bloomberg’s effective month-end logic rather than raw calendar month ends. For each selection:

- The current calendar month end is found.
- The last business day on or before that calendar end becomes the effective date.
- If today is before the effective date, the projected effective date equals the current effective date; otherwise, the next month’s projected effective date is returned.
- Dropdown choices include the projected date (when ahead), the current effective date, and historical effective dates.
- Only allowed dropdown values are accepted for comparisons.

```mermaid
flowchart TD
Start(["Input: today"]) --> CalendarEnd["Calendar month end"]
CalendarEnd --> Effective["Last weekday on or before calendar end"]
Effective --> CheckToday{"today < effective?"}
CheckToday --> |Yes| UseCurrent["Use current effective as both current and projected"]
CheckToday --> |No| NextEffective["Compute next month's effective"]
NextEffective --> ReturnProjected["Return current effective and projected effective"]
UseCurrent --> ReturnProjected
ReturnProjected --> Choices["Build dropdown choices: projected, current, historical"]
Choices --> Validate["Reject selections outside allowed dates"]
```

**Diagram sources**
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)

**Section sources**
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)
- [config.py:85-86](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L86)

### Bloomberg BQL Query Construction and Execution
Membership queries are built from a frozen item list. Each item maps to a specific BQL builder call. The app never constructs BQL fields from widget text.

Key behaviors:

- **Frozen item set**: `ITEM_NAMES` includes identity, classification, maturity, coupon, spreads, durations, yields, weights, ISIN, and SEDOL.
- **Builder mapping**: `_ITEM_CALLS` binds each output name to a `bq.data.*` call, including parameterized spread, duration, and yield measures.
- **Request construction**: `_member_request` creates a `bql.Request` over `bq.univ.members(index_ticker, dates=as_of)` with the item dict and cached mode.
- **Execution strategy**:
  - When `SPLIT_REQUESTS` is False, all items are requested together.
  - When `SPLIT_REQUESTS` is True, identity fields are requested first, then analytics are grouped by family: spreads/yields together, then durations separately.
  - Each group is executed independently so a timeout in one family does not invalidate the entire month.
- **Retry policy**: Only timeouts are retried up to `QUERY_ATTEMPTS`. Deterministic failures such as entitlement issues, unknown fields, or invalid tickers are not retried.
- **Response parsing**: Responses are converted to frames, preferred value columns are selected, duplicate IDs are collapsed, and missing or empty identity/analytics columns are reported through notes and status.

```mermaid
flowchart TD
Start(["Start _fetch_live"]) --> SplitCheck{"SPLIT_REQUESTS?"}
SplitCheck --> |No| FullItems["build_member_items(ITEM_NAMES)"]
SplitCheck --> |Yes| IdentityItems["build_member_items(identity_names)"]
FullItems --> ExecuteFull["Execute full request"]
IdentityItems --> ExecuteIdentity["Execute identity request"]
ExecuteIdentity --> AnalyticsGroups["Loop ANALYTICS_GROUPS"]
AnalyticsGroups --> ExecuteGroup["Execute group request"]
ExecuteGroup --> MergeGroup["Parse and merge group frame"]
MergeGroup --> Continue{"More groups?"}
Continue --> |Yes| AnalyticsGroups
Continue --> |No| FinalMerge["Final merged frame"]
ExecuteFull --> ParseFull["Parse response"]
ParseFull --> FinalFrame["Final frame"]
ExecuteIdentity --> ParseIdentity["Parse identity frame"]
ParseIdentity --> AnalyticsGroups
FinalFrame --> ValidateWeight["Validate Weight presence and non-null rows"]
FinalFrame --> MissingCheck["Check required columns"]
MissingCheck --> CacheDecision["Decide cache safety"]
```

**Diagram sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [field_library.py:58-86](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L86)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

**Section sources**
- [field_library.py:58-86](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L86)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)

### MBS/TBA and Municipal Isolation Mechanism
Mortgage-backed securities and treasury-backed agency bonds are separated from standard corporate bonds using explicit rules applied during normalization:

- **Book assignment**: Rows whose security type contains MBS, TBA, or Pool, or whose ID contains Mtge, are labeled `MBS/TBA`; all others are `Standard`.
- **Municipal override**: US municipal bonds have IDs ending with `Muni`. They remain in the Standard book but are forced to show `Municipal` for Country and Sector, USD currency, and no applicable rating.
- **Blank fill for MBS/TBA**: Blank Country, Sector, or Currency on MBS/TBA rows are replaced with `MBS/TBA` or `USD`, respectively, because those attributes are not meaningful for forward-settling mortgage pools.
- **Rating treatment**: MBS/TBA and Municipal rows receive `RATING_NOT_APPLICABLE`, while unrated or numeric-rated bonds receive `NR`.

```mermaid
flowchart TD
Row["One prepared row"] --> SecurityType["Check Security Type"]
SecurityType --> MBSRule{"Contains MBS/TBA/Pool or ID contains Mtge?"}
MBSRule --> |Yes| BookMBS["Book = MBS/TBA"]
MBSRule --> |No| BookStandard["Book = Standard"]
BookMBS --> FillMBS["Fill blank Country/Sector with MBS/TBA<br/>Fill blank Currency with USD"]
BookStandard --> MunicipalCheck{"ID ends with Muni?"}
MunicipalCheck --> |Yes| Municipal["Country=Sector=Municipal<br/>Currency=USD<br/>Rating=N.A."]
MunicipalCheck --> |No| KeepStandard["Keep original attributes"]
FillMBS --> RatingMBS["Rating Bucket = N.A."]
Municipal --> RatingMuni["Rating Bucket = N.A."]
KeepStandard --> RatingNormal["Rating Bucket = IG/HY/NR"]
```

**Diagram sources**
- [engine.py:413-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L462)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

**Section sources**
- [engine.py:413-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L462)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

### Weight Normalization Algorithms
Weights are normalized to ensure consistent portfolio weight interpretation across different index methodologies:

- **Unit detection**: The net sum of weights determines whether the snapshot arrived as fractions or percent points. If the net sum is positive and at most `WEIGHT_FRACTION_SUM_MAX`, weights are multiplied by 100 to convert fractions to percent points.
- **Fallback basis**: If the net sum is not positive, the absolute sum is used as the fallback unit detector.
- **Display format**: Exported weights are printed as percent points without additional rounding, preserving small MBS slices.
- **Weighted aggregation**: Summaries use weighted means for spreads, durations, yields, tenor, and coupon, excluding nulls, infinite values, negative weights, and OAS sentinel values.

```mermaid
flowchart TD
Start(["Snapshot with Weight column"]) --> NetSum["Compute net sum of Weight"]
NetSum --> AbsSum["Compute absolute sum of Weight"]
AbsSum --> Basis{"Net sum > 0 and <= fraction max?"}
Basis --> |Yes| ScaleToPercent["Multiply weights by 100"]
Basis --> |No| KeepAsIs["Keep weights as-is"]
ScaleToPercent --> NumericCoerce["Coerce numeric columns"]
KeepAsIs --> NumericCoerce
NumericCoerce --> Export["Export as percent points"]
```

**Diagram sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [engine.py:855-869](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L869)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

**Section sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [engine.py:855-869](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L869)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

### Index Membership Processing Workflow
The membership workflow transforms raw BQL responses into comparable snapshots:

1. **Validation**: Index ticker must be a valid Bloomberg yellow key ending in ` Index`.
2. **Date selection**: Selected month-end is validated against allowed dropdown values.
3. **Historical cache lookup**: Previous month is loaded from CSV if the field contract and generation token match.
4. **Live request**: If not cached, BQL membership is fetched, parsed, and finalized.
5. **Normalization**: `prepare_members` cleans IDs, collapses duplicates, scales weights, fills blanks, assigns books, classifies ratings, and buckets tenors.
6. **Label alignment**: `align_snapshot_labels` ensures one classification per ID across both snapshots.
7. **Conflict check**: `rating_class_conflicts` verifies that no ID appears under two rating classifications after alignment.
8. **Transition building**: `build_transition` marks the comparison usable, partial, or unavailable and carries warnings.

```mermaid
flowchart TD
Input["Index ticker + selected month-end"] --> ValidateTicker["validate_index_ticker"]
ValidateTicker --> AllowedDates["comparison_for(selected_date, allowed)"]
AllowedDates --> LoadPrevious["Load previous snapshot"]
LoadPrevious --> FetchLatest["Fetch latest snapshot"]
FetchLatest --> Normalize["prepare_members"]
Normalize --> AlignLabels["align_snapshot_labels"]
AlignLabels --> CheckConflicts["rating_class_conflicts"]
CheckConflicts --> BuildTransition["build_transition"]
BuildTransition --> Output["Transition with status, warnings, snapshots"]
```

**Diagram sources**
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

**Section sources**
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

### Data Ingestion, Validation, Transformation, and Output Examples
Below are concrete code paths that demonstrate each stage. These references point to the exact implementation locations rather than embedding source code.

- **Ingestion**: Building and executing BQL membership requests.
  - [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
  - [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
  - [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- **Validation**: Checking index ticker, month-end allowance, and response shape.
  - [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
  - [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
  - [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- **Transformation**: Normalizing members, aligning labels, computing diffs.
  - [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
  - [engine.py:511-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L630)
  - [engine.py:643-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L729)
- **Output formatting**: Export frames, grid display, and copy-friendly headers.
  - [engine.py:704-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L781)
  - [engine.py:980-1002](file://User scripts/FI Index Change/fi_index_change/engine.py#L980-L1002)

**Section sources**
- [data.py:494-496](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L496)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L630)
- [engine.py:643-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L729)
- [engine.py:704-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L781)
- [engine.py:980-1002](file://User scripts/FI Index Change/fi_index_change/engine.py#L980-L1002)

## Dependency Analysis
The module has clear separation of concerns:

- `app.py` depends on `data.py` for payload retrieval and `engine.py` for transition building and rendering helpers.
- `data.py` depends on `engine.py` for normalization and validation functions, `field_library.py` for frozen BQL items, and `cache.py` for persistence.
- `engine.py` depends on `field_library.py` for metric field names and `config.py` for display and threshold constants.
- `cache.py` depends on `config.py` for label contract tokens and `engine.py` for identity-value checks.

```mermaid
graph LR
App["app.py"] --> Data["data.py"]
App --> Engine["engine.py"]
Data --> Engine
Data --> FieldLib["field_library.py"]
Data --> Cache["cache.py"]
Engine --> FieldLib
Engine --> Config["config.py"]
Cache --> Config
Cache --> Engine
```

**Diagram sources**
- [app.py:25-49](file://User scripts/FI Index Change/fi_index_change/app.py#L25-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

**Section sources**
- [app.py:25-49](file://User scripts/FI Index Change/fi_index_change/app.py#L25-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

## Performance Considerations
- **Split requests**: Analytics are split by family to reduce query width and isolate slow duration calculations.
- **Timeout retry**: Only timeouts are retried; deterministic failures are not retried to avoid wasting time.
- **Cache reuse**: Historical snapshots are reused when the field contract and generation token match, avoiding repeated BQL calls.
- **Projection guard**: Projected snapshots are not written to cache because they cannot be verified later.
- **Partial cache refusal**: Snapshots missing required identity columns or carrying entirely empty identity values are refused to prevent stale or poisoned data from being replayed.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their handling:

- **No data access license**: Errors containing entitlement, permission, license, or authorization markers are detected and surfaced as a membership access failure.
- **Invalid index ticker**: Tickers must end in ` Index`; otherwise, a validation error is raised.
- **Month-end not in dropdown**: Selections outside allowed effective dates are rejected.
- **BQL timeout**: Retries are attempted only for timeout-like exceptions; other failures are logged and not retried.
- **Missing or empty Weight**: A response without usable weights is marked unavailable and not cached.
- **Missing or empty identity columns**: Notes report which items did not parse or arrived with every value null; such months are marked partial and not cached.
- **Duplicate IDs**: Duplicate IDs are collapsed by keeping the last non-null value per column, with notes reporting the drop count.
- **Rating classification conflicts**: After alignment, any remaining ID classified differently across months is reported as a conflict.

**Section sources**
- [engine.py:104-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L104-L119)
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [data.py:529-538](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L538)
- [data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)
- [engine.py:607-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L607-L630)

## Conclusion
The FI Index Change pipeline provides a robust, auditable path from Bloomberg BQL membership snapshots to index change analysis. It enforces strict date semantics, isolates MBS/TBA and municipal securities, normalizes weights consistently, aligns classifications across months, and separates successful, partial, and unavailable states. Its split-request design, selective retry policy, and conservative caching strategy make it resilient against timeouts, entitlement failures, and data quality issues while preserving transparency through detailed notes and warnings.

[No sources needed since this section summarizes without analyzing specific files]