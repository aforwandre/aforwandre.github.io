# Weight Normalization and Portfolio Calculations

<cite>
**Referenced Files in This Document**   
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the FI index change module converts raw Bloomberg membership data into a consistent portfolio representation. The focus is on:
- How raw weights are normalized to percent points.
- How duplicate security entries are collapsed and conflicting values resolved.
- How numerical columns are coerced and cleaned.
- How missing or invalid weight values affect downstream analysis.
- How the final Start and End snapshots form the basis for portfolio construction, adds/exits, and dashboard aggregates.

The implementation is intentionally conservative: it does not invent missing weights, it preserves date-specific analytics, and it normalizes only display-oriented classification labels across two month-ends so that comparison tables remain stable.

## Project Structure
The relevant code lives under `User scripts/FI Index Change/fi_index_change`:
- `engine.py` contains the normalization, duplicate collapsing, label alignment, and transition logic used by the dashboard.
- `data.py` orchestrates BQL requests, response parsing, caching, and calls into `engine.prepare_members`.
- `config.py` defines thresholds such as the maximum fraction sum used to infer whether weights are fractions or percent points.
- `field_library.py` defines the frozen set of requested fields, including `Weight`, and groups numeric analytics.

```mermaid
graph TB
Data["data.py<br/>Request orchestration"] --> Engine["engine.py<br/>Normalization & comparison"]
FieldLib["field_library.py<br/>Frozen field list"] --> Data
Config["config.py<br/>Thresholds & constants"] --> Engine
Engine --> Dashboard["Dashboard / Export"]
```

**Diagram sources**
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [field_library.py:1-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L75)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)

**Section sources**
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [field_library.py:1-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L75)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)

## Core Components
The weight normalization and portfolio calculation pipeline has four main responsibilities:
1. Parse and merge Bloomberg membership responses into a single frame per snapshot.
2. Collapse duplicate IDs while preserving non-null values.
3. Normalize text and numeric columns, classify bonds, and scale weights to percent points when appropriate.
4. Align classification labels between previous and latest snapshots so that comparison views are stable.

Key functions:
- `collapse_duplicate_ids`: deduplicates by ID with last-non-null semantics.
- `prepare_members`: cleans, classifies, and scales one snapshot.
- `align_snapshot_labels`: aligns categorical labels across two snapshots without copying weights.
- `_finalize_snapshot`: applies `prepare_members` and coerces numeric columns after request parsing.

**Section sources**
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)

## Architecture Overview
The end-to-end flow from Bloomberg membership to normalized portfolio snapshots is:

```mermaid
sequenceDiagram
participant User as "User"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
User->>Data : Select index and month-end
Data->>BQL : Request members + fields
BQL-->>Data : Response items (ID, Weight, analytics)
Data->>Data : Parse items, merge frames, collapse IDs
Data->>Engine : prepare_members(frame)
Engine->>Engine : Clean ID, collapse duplicates, coerce numerics
Engine->>Engine : Scale weights to percent points if needed
Engine->>Engine : Classify Book/Country/Sector/Rating/Tenor
Engine-->>Data : Prepared snapshot
Data->>Data : Finalize snapshot (AS_OF_DATE, SNAPSHOT_KIND)
Data-->>User : Previous and Latest normalized portfolios
```

**Diagram sources**
- [data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

## Detailed Component Analysis

### Duplicate Resolution: `collapse_duplicate_ids`
A Bloomberg item can return more than one row for the same security. The function ensures exactly one row per ID:
- If there is no `ID` column or no duplicates, the frame is returned unchanged.
- Columns are reordered so `ID` is last before forward-filling.
- Forward-fill propagates real values over null rows belonging to the same ID.
- A group-by-ID `.last()` then keeps the last row, which now carries the most complete non-null values.
- The original column order is restored where possible.

```mermaid
flowchart TD
Start(["Input DataFrame"]) --> CheckID["Has 'ID' column?"]
CheckID --> |No| ReturnOriginal["Return original frame"]
CheckID --> |Yes| CheckDup["Any duplicate IDs?"]
CheckDup --> |No| ReturnOriginal
CheckDup --> |Yes| Reorder["Move 'ID' to last column"]
Reorder --> FFill["Forward-fill each column"]
FFill --> GroupLast["Group by 'ID', keep last row"]
GroupLast --> RestoreCols["Restore original column order"]
RestoreCols --> End(["One row per ID"])
```

**Diagram sources**
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)

Behavioral notes:
- It implements “last value wins” but avoids preferring a null over a real value because of the forward-fill step.
- It is called both during snapshot preparation and during label alignment, making it a shared primitive for duplicate handling.

**Section sources**
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)
- [engine.py:529-530](file://User scripts/FI Index Change/fi_index_change/engine.py#L529-L530)

### Weight Normalization
Raw weights come from Bloomberg’s membership item. They may arrive as:
- Fractions near 1.0.
- Percent points near 100.
- Mixed or malformed values.

The normalization strategy:
1. Convert `Weight` to numeric using coercion; invalid values become NaN.
2. Compute the net sum and the absolute sum of valid weights.
3. Choose the net sum if positive; otherwise use the absolute sum as a fallback.
4. If the chosen sum is greater than zero and at most `WEIGHT_FRACTION_SUM_MAX`, multiply all weights by 100 to convert fractions to percent points.
5. Record a note when scaling occurs.

The threshold `WEIGHT_FRACTION_SUM_MAX` is defined as 1.05. This means:
- A fraction book summing to approximately 1.0 is scaled to percent points.
- A percent-point book summing to approximately 100 is left unchanged.
- Sums between 1.05 and 2.5 are treated as ambiguous and are not scaled.

```mermaid
flowchart TD
Start(["Snapshot with 'Weight'"]) --> Coerce["Coerce 'Weight' to numeric"]
Coerce --> NetSum["Compute net sum of valid weights"]
NetSum --> AbsSum["Compute absolute sum of valid weights"]
AbsSum --> Choose{"Net sum > 0?"}
Choose --> |Yes| BasisNet["Use net sum as basis"]
Choose --> |No| BasisAbs["Use absolute sum as basis"]
BasisNet --> CheckScale{"0 < basis <= 1.05?"}
BasisAbs --> CheckScale
CheckScale --> |Yes| Scale["Multiply weights by 100"]
CheckScale --> |No| Keep["Keep weights unchanged"]
Scale --> Notes["Record scaling note"]
Keep --> Done(["Normalized weights"])
Notes --> Done
```

**Diagram sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

Concrete examples:
- Fraction input: `[0.40, 0.35, 0.25]` → net sum 1.00 → scaled to `[40.0, 35.0, 25.0]`.
- Percent input: `[40.0, 35.0, 25.0]` → net sum 100.0 → kept as percent points.
- Mixed signs: `[1.2, -0.2]` → net sum 1.0 → scaled to `[120.0, -20.0]`; this is why the code uses the net sum rather than the absolute sum for unit inference.
- Ambiguous sum: `[0.6, 0.5]` → net sum 1.1 → not scaled because it exceeds 1.05.

**Section sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)

### Numerical Column Processing and Type Coercion
Beyond `Weight`, several analytical columns must be numeric:
- Tenor
- Coupon
- Spread fields: OAS, Z-Spread, I-Spread
- Duration fields: Duration, Modified Duration, Effective Duration, OASD
- Yield fields: Yield, YTM, YTW

Processing rules:
- Each numeric column is coerced with `errors="coerce"`, turning unparseable text into NaN.
- Infinite values are replaced with NaN to avoid downstream aggregation artifacts.
- After request parsing, `_finalize_snapshot` also coerces every column listed in `NUMERIC_COLUMNS`.

This approach makes the pipeline robust against:
- Textual representations of numbers.
- Missing or blank analytical fields.
- Vendor numeric scales that cannot be interpreted as floats.

**Section sources**
- [engine.py:404-407](file://User scripts/FI Index Change/fi_index_change/engine.py#L404-L407)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [field_library.py:123-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L126)

### Classification and Portfolio Representation
After cleaning and normalization, each bond is assigned display-oriented categories:
- `Book`: MBS/TBA or Standard.
- `Country`: cleaned, overridden, and title-cased.
- `Sector`: cleaned; MBS/TBA blanks become the MBS/TBA label.
- `Currency`: cleaned; MBS/TBA blanks become USD.
- `Rating`: vendor-provided or marked missing/not applicable.
- `Tenor Bucket`: binned tenor or special labels for missing/not applicable.
- `Rating Bucket`: IG, HY, or NR.

Special handling:
- MBS/TBA securities are detected by `Security Type` or ID patterns. Blank country/sector/currency are replaced with domain-appropriate defaults.
- US municipal bonds are detected by an ID suffix and forced into Municipal classification with USD currency and no applicable rating.
- Missing `Rating` results in NR classification and a log note.

These classifications are what make the portfolio view consistent across different index methodologies and Bloomberg response shapes.

**Section sources**
- [engine.py:408-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L408-L462)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

### Label Alignment Across Snapshots
For comparison purposes, categorical labels are aligned between the previous and latest snapshots:
- Only selected label columns are aligned: Book, Country, Sector, Tenor Bucket, Currency, and Rating Bucket.
- For common IDs, the latest usable value wins.
- If the latest value is missing, the previous value fills both snapshots.
- Weights and analytics are never copied across dates.
- Duplicates are collapsed before alignment to avoid reindex errors.

This alignment prevents a bond from appearing under different categories in Start vs End simply because one snapshot had a blank label.

```mermaid
flowchart TD
Start(["Previous and Latest Snapshots"]) --> Collapse["Collapse duplicate IDs"]
Collapse --> CommonIDs["Find common IDs"]
CommonIDs --> LoopColumns["For each aligned label column"]
LoopColumns --> LatestOk{"Latest value usable?"}
LatestOk --> |Yes| UseLatest["Use latest value"]
LatestOk --> |No| PreviousOk{"Previous value usable?"}
PreviousOk --> |Yes| UsePrevious["Use previous value"]
PreviousOk --> |No| Default["Use latest (blank)"]
UseLatest --> Apply["Apply mapping to both snapshots"]
UsePrevious --> Apply
Default --> Apply
Apply --> End(["Aligned labels, date-specific weights"])
```

**Diagram sources**
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)

**Section sources**
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)

### Final Portfolio Construction
The normalized snapshots are the foundation for:
- Adds and exits: computed by comparing ID sets within a selected book.
- Start and End tables: full snapshots for the selected month-ends.
- Dashboard aggregates: turnover, bucket charts, and dimension breakdowns.

Important constraints:
- The export path requires `Weight` on every add and exit.
- Weight is displayed as percent points; the percent sign is a display suffix, not another multiplication.
- Missing or invalid weights remain as NaN and do not create synthetic values.

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:732-756](file://User scripts/FI Index Change/fi_index_change/engine.py#L732-L756)

## Dependency Analysis
The following diagram shows how the core files depend on each other for weight normalization and portfolio construction:

```mermaid
graph LR
FieldLibrary["field_library.py<br/>ITEM_NAMES, NUMERIC_COLUMNS"] --> Data["data.py<br/>_finalize_snapshot, _parse_response"]
Config["config.py<br/>WEIGHT_FRACTION_SUM_MAX"] --> Engine["engine.py<br/>prepare_members, collapse_duplicate_ids"]
Data --> Engine
Engine --> Data
```

**Diagram sources**
- [field_library.py:58-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L75)
- [field_library.py:123-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L126)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)

Coupling observations:
- `data.py` depends on `engine.py` for normalization and validation.
- `engine.py` imports configuration constants and field definitions.
- `field_library.py` is the source of truth for requested fields and numeric columns.
- `config.py` centralizes thresholds so normalization behavior is configurable without changing algorithmic logic.

**Section sources**
- [field_library.py:58-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L75)
- [field_library.py:123-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L126)
- [config.py:117-120](file://User scripts/FI Index Change/fi_index_change/config.py#L117-L120)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)

## Performance Considerations
- Duplicate collapsing uses forward-fill plus group-by-last, which is efficient for typical membership frames but should be reviewed if duplicate counts grow unexpectedly.
- Label alignment computes masks once per pair of snapshots and reuses them across columns, avoiding repeated membership checks.
- Numeric coercion is applied per column; large analytical blocks benefit from the split-request design in `data.py`, which isolates duration evaluation from spread/yield lookups.
- Weight scaling is vectorized through pandas operations and runs once per snapshot.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their signals:

| Symptom | Likely Cause | Evidence / Handling |
|---|---|---|
| All weights appear very small | Weights arrived as fractions but were not scaled | Check notes for fraction scaling; verify net sum is ≤ 1.05 |
| Some weights are blank | Invalid or missing `Weight` values | `pd.to_numeric(..., errors="coerce")` turns bad values into NaN |
| Duplicate IDs cause inconsistent rows | Multiple rows per security in Bloomberg response | `collapse_duplicate_ids` keeps last non-null value |
| Country or Sector appears blank | Missing or blank text fields | `_blank_text` replaces blanks with `(blank)` |
| Rating shows NR everywhere | No `Rating` column or unrated bonds | `prepare_members` marks missing rating as NR and logs it |
| MBS/TBA bonds show wrong country/sector | Blank metadata on MBS/TBA rows | Special fill rules replace blanks with MBS/TBA label and USD currency |
| Comparison table shows different categories for the same bond | Labels differ between snapshots | `align_snapshot_labels` aligns labels using latest-then-previous rule |
| Export fails | Missing `Weight` on adds/exits | `change_export_frame` raises when `Weight` is absent |

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [data.py:426-445](file://User scripts/FI Index Change/fi_index_change/data.py#L426-L445)

## Conclusion
The FI index change module builds a robust, reproducible portfolio representation from raw Bloomberg membership data by:
- Collapsing duplicate IDs with last-non-null semantics.
- Coercing and cleaning numerical and text columns.
- Inferring and converting weight units to percent points when supported by the data.
- Applying domain-specific classification rules for MBS/TBA and municipal bonds.
- Aligning categorical labels across snapshots to ensure stable comparisons.

Missing or invalid weights are preserved as NaN rather than fabricated, and notes are recorded so operators can distinguish incomplete data from clean results. The resulting Start and End snapshots provide a reliable foundation for adds/exits, turnover, and portfolio analytics.

[No sources needed since this section summarizes without analyzing specific files]