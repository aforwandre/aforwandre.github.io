# Date Handling and Business Day Logic

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the month-end business day handling logic used by the Fixed Income Index Change module. It focuses on how user-selected dates are validated, how previous and selected effective dates are derived, how month-end choices are built according to Bloomberg conventions, and how those dates relate to index methodology such as membership changes, turnover, and effective-date locking.

The key behaviors are:
- Month-end selection is restricted to a local dropdown of effective dates.
- The selected date must be one of the allowed values; otherwise the request is rejected early.
- The previous date is always the last weekday of the calendar month before the selected month.
- A projected date may appear when the current month has not yet locked.
- Weekend adjustment uses pandas business-day rules; exchange holidays are not modeled.
- The selected date becomes the “End” snapshot and the previous date becomes the “Begin” snapshot for adds, exits, and turnover calculations.

## Project Structure
The date-handling logic spans three main files:

| File | Responsibility |
|---|---|
| `engine.py` | Core date math, validation, comparison construction, and transition building. |
| `data.py` | Request orchestration, caching, BQL execution, and payload assembly. |
| `app.py` | UI widget setup, dropdown population, and Update workflow coordination. |

```mermaid
graph TB
App["app.py<br/>UI controller"] --> Data["data.py<br/>Request & cache orchestration"]
Data --> Engine["engine.py<br/>Date math & validation"]
Engine --> Config["config constants<br/>MONTH_END_CHOICES, etc."]
Data --> Cache["cache helpers<br/>load/save historical"]
Data --> BQL["BQL service<br/>index members"]
```

**Diagram sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)

**Section sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)

## Core Components
The month-end business day logic centers on these functions and data structures:

| Symbol | Purpose |
|---|---|
| `_weekday_month_end` | Converts a calendar month-end to the last weekday on or before it. |
| `_require_today` | Normalizes the current date and rejects missing values. |
| `effective_dates` | Returns the current effective date and the projected effective date. |
| `default_month_end` | Provides the default dropdown value for today’s effective date. |
| `month_end_choices` | Builds the allowed dropdown list of effective dates. |
| `comparison_for` | Validates a selected date and derives the previous and selected effective dates. |
| `validate_index_ticker` | Ensures the index ticker ends with the required Bloomberg yellow-key suffix. |
| `build_transition` | Wraps snapshots into a Transition object with status, warnings, and labels. |
| `IndexPayload` | Carries requested dates, snapshots, statuses, errors, and notes. |

**Section sources**
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)

## Architecture Overview
The end-to-end flow from user input to a valid comparison is:

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant Engine as "engine.py"
participant Cache as "Cache"
participant BQL as "BQL Service"
User->>App : Select index and month-end
App->>Engine : month_end_choices(today, count)
App->>App : Build dropdown options
User->>App : Click Update
App->>Data : fetch_index_payload(index, selected_date)
Data->>Engine : validate_index_ticker(index)
Data->>Engine : month_end_choices(today, count)
Data->>Engine : comparison_for(selected_date, today, allowed)
Engine-->>Data : Comparison(previous_date, selected_date, kind)
Data->>Cache : load_historical(previous_date) if historical
alt Historical available
Cache-->>Data : cached snapshot
else Not cached
Data->>BQL : members(index, as_of=previous_date)
BQL-->>Data : raw response
Data->>Data : parse & prepare_members
end
Data->>BQL : members(index, as_of=selected_date)
BQL-->>Data : raw response
Data->>Data : parse & prepare_members
Data->>Engine : align_snapshot_labels(previous, latest)
Data->>Engine : build_transition(snapshots, comparison, statuses)
Engine-->>App : Transition(status, label, warnings)
App-->>User : Render dashboard
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

## Detailed Component Analysis

### Business-Day Adjustment and Effective Dates
The system does not use a full exchange holiday calendar. Instead, it adjusts calendar month-ends to the last weekday using pandas business-day rules. This matches the documented Bloomberg convention that rebalancing locks to the last business day of the month.

Key behavior:
- Calendar month-end is normalized.
- If the result falls on Saturday or Sunday, it rolls back to Friday.
- Missing or invalid dates raise explicit errors.
- The effective date is the last weekday of the current calendar month.
- If today is before that effective date, the projected date equals the current effective date.
- If today is on or after that effective date, the projected date moves to the next month’s last weekday.

```mermaid
flowchart TD
Start(["Input: today"]) --> Normalize["Normalize today to midnight"]
Normalize --> CheckToday{"today is valid?"}
CheckToday --> |No| ErrorToday["Raise ValueError('Today is missing.')"]
CheckToday --> |Yes| CalendarEnd["Compute this calendar month-end"]
CalendarEnd --> WeekdayEnd["Roll to last weekday on or before month-end"]
WeekdayEnd --> Compare{"today < this_effective?"}
Compare --> |Yes| ReturnSame["Return (this_effective, this_effective)"]
Compare --> |No| NextMonth["Compute next calendar month-end"]
NextMonth --> Projected["Roll next month to last weekday"]
Projected --> ReturnProjected["Return (this_effective, projected)"]
```

**Diagram sources**
- [engine.py:178-193](file://User scripts/FI Index Change/fi_index_change/engine.py#L178-L193)
- [engine.py:167-175](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L175)

**Section sources**
- [engine.py:167-193](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L193)
- [28-fi-index-change.md:389-414](file://RAG KB/28-fi-index-change.md#L389-L414)

### Month-End Dropdown Construction
`month_end_choices` builds the allowed dropdown entries. It returns pairs of display labels and ISO date strings, newest first.

Rules:
- At least one choice is required.
- The most recent entry is the projected date only when it differs from the locked effective date.
- The locked effective date is included as either projected or historical depending on whether it equals the projected date.
- Older entries are generated by stepping backward through calendar months and converting each month-end to its last weekday.
- Duplicate ISO dates are removed.
- Projected dates receive a “(Projected)” label; historical dates show only the date.

```mermaid
flowchart TD
Start(["Input: today, count"]) --> ValidateCount{"count >= 1?"}
ValidateCount --> |No| ErrorCount["Raise ValueError"]
ValidateCount --> |Yes| GetEffective["Get effective_dates(today)"]
GetEffective --> BuildOrdered["Build ordered list of (date, kind)"]
BuildOrdered --> AddHistorical["Step back calendar months"]
AddHistorical --> Deduplicate["Remove duplicate ISO dates"]
Deduplicate --> Label["Label projected vs historical"]
Label --> Limit["Stop at count"]
Limit --> ReturnChoices["Return [(label, iso), ...]"]
```

**Diagram sources**
- [engine.py:202-232](file://User scripts/FI Index Change/fi_index_change/engine.py#L202-L232)

**Section sources**
- [engine.py:202-232](file://User scripts/FI Index Change/fi_index_change/engine.py#L202-L232)
- [app.py:346-353](file://User scripts/FI Index Change/fi_index_change/app.py#L346-L353)

### Selected Date Validation and Previous Date Derivation
`comparison_for` is the central decision point for the two dates used in the comparison.

Validation rules:
- The selected date is trimmed and compared against the allowed list.
- If the allowed list is not provided, it is computed from `month_end_choices`.
- A selected date outside the dropdown raises an error.
- The previous date is the last weekday of the calendar month immediately before the selected month.
- The kind is “projected” only when the selected date equals the projected effective date; otherwise it is “historical”.

```mermaid
flowchart TD
Start(["Input: selected, today, allowed"]) --> Trim["Trim whitespace"]
Trim --> AllowedCheck{"selected in allowed?"}
AllowedCheck --> |No| Reject["Raise ValueError('not in the dropdown')"]
AllowedCheck --> |Yes| ParseSelected["Parse selected as Timestamp"]
ParseSelected --> PrevMonth["Compute previous calendar month-end"]
PrevMonth --> PrevWeekday["Roll to last weekday"]
PrevWeekday --> KindCheck{"selected == projected?"}
KindCheck --> |Yes| SetProjected["kind = 'projected'"]
KindCheck --> |No| SetHistorical["kind = 'historical'"]
SetProjected --> ReturnComparison["Return Comparison(previous, selected, kind)"]
SetHistorical --> ReturnComparison
```

**Diagram sources**
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)

**Section sources**
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)

### Index Ticker Validation
Index tickers must follow Bloomberg yellow-key conventions. The validator:
- Normalizes spacing.
- Requires the string to end with ` Index`.
- Raises a clear error when the suffix is missing.

This check runs before any BQL request, preventing unnecessary network calls for malformed inputs.

**Section sources**
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [data.py:713-718](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L718)

### Relationship Between Selected Dates and Effective Dates
In this module:
- The **selected date** is the “End” snapshot.
- The **previous date** is the “Begin” snapshot.
- Adds and exits are membership differences between those two snapshots.
- Turnover uses Exit weight at the previous date and Add weight at the selected date.
- When the selected date is projected, the comparison is still computed, but the snapshot is not written to the historical cache because it cannot be verified later.

```mermaid
stateDiagram-v2
[*] --> Idle
Idle --> Validating : "Validate index and selected date"
Validating --> Allowed : "selected in dropdown"
Validating --> Rejected : "selected not in dropdown"
Allowed --> Requesting : "Request previous and selected snapshots"
Requesting --> Prepared : "Parse, normalize, align"
Prepared --> TransitionOK : "Both snapshots usable"
Prepared --> TransitionUnavailable : "Missing or unusable snapshot"
TransitionOK --> Rendering
TransitionUnavailable --> Rendering
Rendering --> Idle
```

**Diagram sources**
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

**Section sources**
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

### Concrete Input Scenarios

| Scenario | Input Behavior | Output Dates | Notes |
|---|---|---|---|
| Today is before the month’s effective date | Dropdown includes the current effective date as projected. Default is that date. | Selected = current effective date. Previous = last weekday of prior month. | The projected row appears only when it differs from the locked effective date. |
| Today is on or after the month’s effective date | Current effective date is historical. Next month’s effective date appears as projected. | Selected can be locked or projected. Previous is always the prior month’s last weekday. | Locking means the current month’s effective date is no longer considered future. |
| Selected date is a weekend calendar month-end | Adjusted to the last weekday before it. | Same rule applies to both selected and previous dates. | Uses pandas business days; weekends roll back. |
| Selected date is a holiday | No special holiday adjustment. | Falls back to the last weekday rule only. | Exchange holidays are not modeled. |
| Selected date is not in the dropdown | Early rejection. | No request is made. | Prevents stale or unauthorized selections. |
| Selected date is projected | Request proceeds, but snapshot is not cached. | Comparison kind is “projected”. | Future effective dates cannot be verified later. |
| Selected date is historical | Request may use cached snapshot if available. | Comparison kind is “historical”. | Cached months are reused when safe. |

These scenarios reflect the implementation:
- Dropdown generation uses `month_end_choices`.
- Selection validation uses `comparison_for`.
- Snapshot retrieval uses `fetch_index_payload`.
- Caching decisions distinguish historical versus projected dates.

**Section sources**
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)
- [28-fi-index-change.md:389-418](file://RAG KB/28-fi-index-change.md#L389-L418)

### Edge Cases and Methodology Implications

| Edge Case | Handling | Methodology Impact |
|---|---|---|
| Blank or missing selected date | Normalization and validation reject invalid inputs. | No comparison is built. |
| Blank or missing today | Explicit error raised. | Date math cannot proceed. |
| Empty allowed list | `comparison_for` rejects any selected date. | Dropdown must provide at least one choice. |
| Duplicate ISO dates in dropdown | Duplicates are removed. | Dropdown remains stable. |
| Holiday month-end | No holiday adjustment beyond weekday rollback. | Follows documented convention: do not invent a holiday calendar. |
| Partial snapshot | Status is “partial”, not “ok”. | Warnings are attached; dimensions may be blank or NR. |
| Unavailable snapshot | Transition status is “unavailable”. | No add/exit computation occurs. |
| Projected snapshot | Not written to historical cache. | Prevents permanent storage of unverifiable future data. |

**Section sources**
- [engine.py:167-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L251)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [data.py:793-819](file://User scripts/FI Index Change/fi_index_change/data.py#L793-L819)
- [28-fi-index-change.md:389-418](file://RAG KB/28-fi-index-change.md#L389-L418)

## Dependency Analysis
The date-handling components have clear directional dependencies:

```mermaid
graph LR
App["app.py"] --> Data["data.py"]
Data --> Engine["engine.py"]
Engine --> Engine
Data --> Cache["cache helpers"]
Data --> BQL["BQL service"]
Engine --> Config["config constants"]
```

Key relationships:
- `app.py` constructs widgets and triggers `fetch_index_payload`.
- `data.py` validates the index ticker, builds allowed dates, computes the comparison, requests snapshots, caches historical data, and builds the payload.
- `engine.py` provides pure date logic, validation, and transition construction without calling BQL directly.
- `data.py` imports `comparison_for`, `month_end_choices`, and `validate_index_ticker` from `engine.py`.

**Diagram sources**
- [app.py:25-49](file://User scripts/FI Index Change/fi_index_change/app.py#L25-L49)
- [data.py:16-25](file://User scripts/FI Index Change/fi_index_change/data.py#L16-L25)
- [engine.py:15-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L15-L28)

**Section sources**
- [app.py:25-49](file://User scripts/FI Index Change/fi_index_change/app.py#L25-L49)
- [data.py:16-25](file://User scripts/FI Index Change/fi_index_change/data.py#L16-L25)
- [engine.py:15-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L15-L28)

## Performance Considerations
- Dropdown generation is local and does not call BQL.
- Only the selected date and its previous date are requested.
- Historical snapshots are cached when safe.
- Projected snapshots are not cached because they cannot be verified later.
- Timeout retries are limited and only applied to timeout-like failures, not deterministic errors.
- The code explicitly warns that timeouts are evidence about the request or date, not Python performance.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

| Symptom | Likely Cause | Resolution |
|---|---|---|
| “Month-end is not in the dropdown” | Selected date was manually edited or the dropdown state is stale. | Rebuild dropdown options and select from the list. |
| “Index must be a Bloomberg index yellow key ending in ' Index'” | Ticker missing the required suffix. | Append ` Index` to the Bloomberg yellow key. |
| “Today is missing” | Invalid or missing `today` argument. | Pass a valid normalized timestamp. |
| “Calendar month-end is missing” | Invalid month-end passed to weekday adjustment. | Ensure a valid calendar month-end is supplied. |
| Comparison unavailable | One or both snapshots are missing, empty, or unusable. | Check logs for BQL errors, entitlement issues, or empty Weight columns. |
| Partial comparison | Some items did not parse or identity columns arrived empty. | Review notes; missing analytics columns reduce dimension fidelity. |
| Projected month not cached | Projected snapshots are intentionally not cached. | Treat projected results as live-only until the month locks. |
| Weekend-adjusted date differs from calendar month-end | Expected behavior under business-day rules. | Confirm the selected date maps to the last weekday. |

**Section sources**
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:167-193](file://User scripts/FI Index Change/fi_index_change/engine.py#L167-L193)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [data.py:713-838](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L838)

## Conclusion
The FI index change module implements a conservative, methodologically consistent approach to month-end business day handling:

- Month-end selection is constrained to a locally generated list of effective dates.
- The previous date is always the last weekday of the prior calendar month.
- Weekend adjustment follows pandas business-day rules; exchange holidays are not modeled.
- Projected dates are supported but not cached.
- Validation is strict: invalid tickers and out-of-range dates are rejected before data requests.
- Selected and previous dates map directly to End and Begin snapshots used for membership changes and turnover.

This design keeps the comparison predictable, auditable, and aligned with Bloomberg’s rebalance boundary while avoiding assumptions about unmodeled holiday calendars.

[No sources needed since this section summarizes without analyzing specific files]