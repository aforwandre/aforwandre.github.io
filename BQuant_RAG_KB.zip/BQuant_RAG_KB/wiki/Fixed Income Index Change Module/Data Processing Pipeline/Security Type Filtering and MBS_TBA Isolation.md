# Security Type Filtering and MBS/TBA Isolation

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [test_engine.py](file://User scripts/FI Index Change/tests/test_engine.py)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the FI index change module isolates mortgage-backed securities (MBS) and treasury-backed agency bonds (TBA) from standard corporate bonds, and how that isolation affects index composition analysis and change detection. The central mechanism is the `prepare_members` function, which classifies each security into a book: either Standard or MBS/TBA. It also normalizes related fields such as Country, Sector, Currency, Tenor Bucket, and Rating Bucket so that downstream comparison logic can distinguish roll-driven TBA changes from genuine credit index turnover.

The filtering criteria are intentionally conservative and rule-based:
- Security Type contains MBS, TBA, or Pool.
- ID contains Mtge.
- US municipal IDs ending with Muni are treated separately but remain Standard.
- Blank attributes on MBS/TBA rows are replaced with stable display labels rather than treated as missing data.

Weight adjustment is not a separate “MBS/TBA weight algorithm.” Instead, weights are normalized to percent points when they arrive as fractions, and then used unchanged for all summaries, exports, and add/exit calculations. The key transformation is book-level separation, not per-book scaling.

## Project Structure
The relevant implementation lives under the FI Index Change user script:

```mermaid
graph TB
DataLayer["fi_index_change/data.py<br/>BQL request parsing and snapshot assembly"] --> EngineLayer["fi_index_change/engine.py<br/>prepare_members, diff, alignment, summary"]
ConfigLayer["fi_index_change/config.py<br/>labels, thresholds, defaults"] --> EngineLayer
TestsLayer["tests/test_engine.py<br/>isolation and normalization tests"] --> EngineLayer
DocsLayer["RAG KB/28-fi-index-change.md<br/>Pandas rules and Book behavior"] --> EngineLayer
```

**Diagram sources**
- [data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [test_engine.py:1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)
- [28-fi-index-change.md:431-451](file://RAG KB/28-fi-index-change.md#L431-L451)

**Section sources**
- [data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [config.py:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [test_engine.py:1-46](file://User scripts/FI Index Change/tests/test_engine.py#L1-L46)
- [28-fi-index-change.md:431-451](file://RAG KB/28-fi-index-change.md#L431-L451)

## Core Components
- `prepare_members`: Normalizes one membership snapshot, computes the Book classification, fills MBS/TBA and Municipal metadata, assigns Tenor Bucket and Rating Bucket, and scales weights if needed.
- `diff_members`: Computes Add and Exit by ID within a selected Book; All includes both Standard and MBS/TBA.
- `align_snapshot_labels`: Aligns classification labels across previous and latest snapshots so an ID cannot appear in two rating or dimension buckets at once.
- `rating_bucket`: Maps raw rating text to IG, HY, or NR.
- Configuration constants: `MBS_TBA_LABEL`, `MUNICIPAL_ID_SUFFIX`, `MUNICIPAL_LABEL`, `TENOR_NOT_APPLICABLE`, `WEIGHT_FRACTION_SUM_MAX`.

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)

## Architecture Overview
The data flow for MBS/TBA isolation is:

```mermaid
sequenceDiagram
participant BQL as "BQL members() response"
participant Data as "data.py"
participant Engine as "engine.prepare_members"
participant Diff as "engine.diff_members"
participant UI as "Dashboard / Export"
BQL->>Data : Raw item frames
Data->>Data : Parse, merge, collapse duplicate IDs
Data->>Engine : Prepared frame + notes
Engine->>Engine : Normalize ID, Weight, text columns
Engine->>Engine : Compute MBS/TBA mask
Engine->>Engine : Assign Book, fill Country/Sector/Currency
Engine->>Engine : Assign Tenor Bucket and Rating Bucket
Engine-->>Data : Finalized snapshot with Book
Data->>Diff : Previous and latest snapshots
Diff->>Diff : Filter by selected Book
Diff-->>UI : Adds, exits, begin/end sets
```

**Diagram sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

## Detailed Component Analysis

### prepare_members: Security Type Classification and Book Assignment
`prepare_members` is the entry point for snapshot normalization. Its responsibilities include:
- Dropping blank or invalid IDs.
- Collapsing duplicate IDs while preserving the last non-null value per column.
- Converting numeric analytics fields and replacing infinities with NaN.
- Normalizing text fields to a consistent blank sentinel.
- Classifying each row into Standard or MBS/TBA.
- Filling MBS/TBA-specific Country, Sector, and Currency values.
- Treating US municipal IDs as Standard with fixed metadata.
- Computing Tenor Bucket and Rating Bucket.
- Scaling fraction weights to percent points when appropriate.

#### MBS/TBA Mask Logic
The MBS/TBA mask is computed using two independent conditions combined with logical OR:
1. `Security Type` contains MBS, TBA, or Pool.
2. `ID` contains Mtge.

If either condition matches, the row’s Book becomes MBS/TBA; otherwise it is Standard.

```mermaid
flowchart TD
Start(["Input snapshot"]) --> CleanID["Normalize and drop blank IDs"]
CleanID --> Collapse["Collapse duplicate IDs"]
Collapse --> Numeric["Convert numeric fields"]
Numeric --> Text["Normalize text fields"]
Text --> SecType["Read Security Type"]
SecType --> Mask["Compute MBS/TBA mask:<br/>Security Type contains MBS|TBA|Pool<br/>OR ID contains Mtge"]
Mask --> Book["Assign Book = MBS/TBA or Standard"]
Book --> FillMBS["Fill blank Country/Sector with MBS/TBA label<br/>Fill blank Currency with USD"]
FillMBS --> Municipal["Detect Municipal IDs ending with Muni"]
Municipal --> Ratings["Set Rating and Rating Bucket"]
Ratings --> Tenor["Compute Tenor Bucket"]
Tenor --> MBSMissing["Replace Missing tenor for MBS/TBA with N.A."]
MBSMissing --> Scale["Scale fraction weights to percent points"]
Scale --> End(["Normalized snapshot"])
```

**Diagram sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)

#### Filtering Criteria Summary
| Criterion | Rule | Result |
|---|---|---|
| Security Type | Contains MBS, TBA, or Pool | Book = MBS/TBA |
| ID | Contains Mtge | Book = MBS/TBA |
| ID suffix | Ends with Muni | Book = Standard; Country/Sector = Municipal; Currency = USD; Rating = NR |
| Blank Country/Sector on MBS/TBA | Replaced with MBS/TBA label | Prevents false Missing classification |
| Blank Currency on MBS/TBA | Replaced with USD | Reflects settlement currency convention |
| Missing Tenor on MBS/TBA | Tenor Bucket set to N.A. | Not treated as bad data |

**Section sources**
- [engine.py:413-456](file://User scripts/FI Index Change/fi_index_change/engine.py#L413-L456)
- [config.py:26-47](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L47)
- [28-fi-index-change.md:431-451](file://RAG KB/28-fi-index-change.md#L431-L451)

### Weight Adjustment Algorithms
There is no separate MBS/TBA weight adjustment algorithm. Weight handling is uniform across books:

1. If the Weight column exists, convert it to numeric.
2. Compute net sum and absolute sum.
3. Use net sum when positive; otherwise use absolute sum.
4. If the resulting basis is greater than 0 and less than or equal to `WEIGHT_FRACTION_SUM_MAX`, multiply all weights by 100.
5. Record a note indicating fraction-to-percent conversion.

This means:
- Fractional inputs near 1.0 become percent points near 100.
- Percent-point inputs near 100 are left unchanged.
- Ambiguous sums are not scaled.
- Negative weights do not trigger automatic scaling unless the absolute sum falls in the fraction range.

```mermaid
flowchart TD
WStart(["Weight column present?"]) --> Convert["Convert to numeric"]
Convert --> NetSum["Compute net sum"]
NetSum --> AbsSum["Compute absolute sum"]
AbsSum --> Basis{"Use net sum if positive,<br/>else absolute sum"}
Basis --> Check{"Is basis > 0 and <= 1.05?"}
Check --> |Yes| Scale["Multiply weights by 100"]
Check --> |No| Keep["Keep original units"]
Scale --> WEnd(["Weights ready"])
Keep --> WEnd
```

**Diagram sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)

**Section sources**
- [engine.py:390-403](file://User scripts/FI Index Change/fi_index_change/engine.py#L390-L403)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)
- [test_engine.py:322-329](file://User scripts/FI Index Change/tests/test_engine.py#L322-L329)

### MBS/TBA Isolation and Change Detection
After `prepare_members` assigns Book, change detection operates on ID differences within the selected book:
- Selecting Standard excludes MBS/TBA roll codes.
- Selecting MBS/TBA excludes Standard corporate bonds.
- Selecting All includes both books.
- Add and Exit are computed only by ID membership, not by attribute changes.

```mermaid
flowchart TD
Snapshots["Previous and Latest Snapshots"] --> SelectBook["Select Book: All, Standard, or MBS/TBA"]
SelectBook --> FilterPrev["Filter previous by Book"]
SelectBook --> FilterLatest["Filter latest by Book"]
FilterPrev --> PrevIDs["Extract previous ID set"]
FilterLatest --> LatestIDs["Extract latest ID set"]
PrevIDs --> Diff["Compute ID differences"]
LatestIDs --> Diff
Diff --> Adds["Add = latest - previous"]
Diff --> Exits["Exit = previous - latest"]
Adds --> Output["Return filtered previous, latest, adds, exits"]
Exits --> Output
```

**Diagram sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [test_engine.py:301-320](file://User scripts/FI Index Change/tests/test_engine.py#L301-L320)
- [28-fi-index-change.md:440-451](file://RAG KB/28-fi-index-change.md#L440-L451)

### Municipal Bond Handling
US municipal bonds are not classified as MBS/TBA. They are identified by an ID suffix and treated as Standard bonds with fixed metadata:
- Country = Municipal
- Sector = Municipal
- Currency = USD
- Rating = NR
- Rating Bucket = NR

This prevents municipal yellow keys from being misclassified as MBS/TBA while still removing them from credit-grade analysis where applicable.

**Section sources**
- [engine.py:430-447](file://User scripts/FI Index Change/fi_index_change/engine.py#L430-L447)
- [config.py:26-36](file://User scripts/FI Index Change/fi_index_change/config.py#L26-L36)
- [test_engine.py:1240-1249](file://User scripts/FI Index Change/tests/test_engine.py#L1240-L1249)

### Tenor Bucket and Rating Bucket Behavior for Isolated Types
- MBS/TBA rows with a missing numeric tenor receive Tenor Bucket = N.A., not Missing.
- MBS/TBA and Municipal rows receive Rating = NR and Rating Bucket = NR.
- A real numeric tenor on an MBS/TBA row remains in its normal bucket.
- NR is a real classification, not a missing marker, so it does not inherit a previous month’s IG/HY label.

```mermaid
flowchart TD
Input["Tenor and Rating fields"] --> TenorBucket["Compute Tenor Bucket"]
TenorBucket --> MBSTenor{"Row is MBS/TBA and Tenor Bucket is Missing?"}
MBSTenor --> |Yes| SetNA["Set Tenor Bucket to N.A."]
MBSTenor --> |No| KeepTenor["Keep computed bucket"]
SetNA --> RatedCat{"Row is MBS/TBA or Municipal?"}
KeepTenor --> RatedCat
RatedCat --> |Yes| SetNR["Set Rating and Rating Bucket to NR"]
RatedCat --> |No| MapRating["Map Rating to IG, HY, or NR"]
```

**Diagram sources**
- [engine.py:449-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L449-L461)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)

**Section sources**
- [engine.py:449-461](file://User scripts/FI Index Change/fi_index_change/engine.py#L449-L461)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [test_engine.py:368-375](file://User scripts/FI Index Change/tests/test_engine.py#L368-L375)
- [test_engine.py:1240-1249](file://User scripts/FI Index Change/tests/test_engine.py#L1240-L1249)

### Cross-Snapshot Label Alignment
Because MBS/TBA isolation changes classification semantics, the code aligns Book, Country, Sector, Tenor Bucket, Currency, and Rating Bucket across snapshots:
- The latest usable value wins.
- If the latest value is missing, the previous value fills both sides.
- IDs existing on only one date keep that date’s values.
- NR is treated as a real classification and does not silently inherit a prior letter grade.

```mermaid
flowchart TD
Start(["Align snapshots"]) --> CommonIDs["Find common IDs"]
CommonIDs --> Columns["Iterate aligned columns"]
Columns --> LatestOK{"Latest value usable?"}
LatestOK --> |Yes| ChooseLatest["Choose latest"]
LatestOK --> |No| PreviousOK{"Previous value usable?"}
PreviousOK --> |Yes| ChoosePrevious["Choose previous"]
PreviousOK --> |No| Default["Default to latest"]
ChooseLatest --> Apply["Apply mapping to both snapshots"]
ChoosePrevious --> Apply
Default --> Apply
Apply --> End(["Aligned labels"])
```

**Diagram sources**
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)

**Section sources**
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)
- [test_engine.py:377-433](file://User scripts/FI Index Change/tests/test_engine.py#L377-L433)

## Dependency Analysis
The MBS/TBA isolation depends on several modules:

```mermaid
graph LR
Config["config.py<br/>MBS_TBA_LABEL, MUNICIPAL_ID_SUFFIX,<br/>TENOR_NOT_APPLICABLE, WEIGHT_FRACTION_SUM_MAX"] --> Engine["engine.py<br/>prepare_members, diff_members,<br/>align_snapshot_labels, rating_bucket"]
FieldLibrary["field_library.py<br/>SPREAD_FIELDS, DURATION_FIELDS,<br/>YIELD_FIELDS"] --> Engine
Data["data.py<br/>_finalize_snapshot, _fetch_live"] --> Engine
Tests["tests/test_engine.py<br/>isolation, weighting, alignment tests"] --> Engine
```

**Diagram sources**
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:14-25](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L25)
- [config.py:12-47](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L47)
- [test_engine.py:17-46](file://User scripts/FI Index Change/tests/test_engine.py#L17-L46)

**Section sources**
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:14-25](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L25)
- [config.py:12-47](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L47)
- [test_engine.py:17-46](file://User scripts/FI Index Change/tests/test_engine.py#L17-L46)

## Performance Considerations
- The MBS/TBA mask is computed once per snapshot using vectorized string operations.
- Duplicate ID collapsing uses forward-fill before groupby-last to avoid preferring nulls.
- Weight scaling is O(n) and applied only when the inferred unit is unambiguous.
- Book filtering in `diff_members` avoids unnecessary cross-book comparisons.
- Label alignment computes common-ID masks once and reuses them across columns.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their signals:

| Symptom | Likely Cause | Resolution |
|---|---|---|
| MBS/TBA roll codes appear as added/exited in Standard analysis | MBS/TBA isolation was not applied or Book filter was wrong | Ensure `prepare_members` ran and select Standard to exclude MBS/TBA |
| MBS/TBA rows show Missing Tenor Bucket | Tenor field is absent or invalid | MBS/TBA missing tenor should be N.A.; verify Book assignment |
| Municipal bonds appear unrated in credit analysis | Municipal IDs are forced to NR | Confirm ID ends with Muni and Book is Standard |
| Weights look too small | Fractions were not scaled | Check notes for fraction scaling and confirm sum near 100 |
| Same bond appears in two Rating selections | Label alignment failed or filters leaked | Check `align_snapshot_labels` and filter cascade behavior |

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-604](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L604)
- [test_engine.py:301-329](file://User scripts/FI Index Change/tests/test_engine.py#L301-L329)
- [test_engine.py:368-433](file://User scripts/FI Index Change/tests/test_engine.py#L368-L433)
- [28-fi-index-change.md:431-451](file://RAG KB/28-fi-index-change.md#L431-L451)

## Conclusion
The FI index change module isolates MBS/TBA securities through explicit pattern matching on Security Type and ID, then applies stable metadata overrides and classification rules. This isolation prevents roll-month TBA churn from contaminating standard credit change detection. Weight normalization is uniform across books and driven by the overall weight sum, not by security type. Cross-snapshot label alignment ensures that isolated types do not create inconsistent classifications between months. Together, these mechanisms make the index change output suitable for both broad portfolio views and focused credit analysis.

[No sources needed since this section summarizes without analyzing specific files]