# Field Library and Bond Attributes

<cite>
**Referenced Files in This Document**   
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the field library system that manages bond attributes and metadata for the Fixed Income Index Change application. It covers:
- The standardized bond attribute names used across the app.
- How Bloomberg BQL data fields are mapped to those names.
- Data type handling, validation rules, and fallback behavior for missing or invalid data.
- Examples of how custom field definitions can be extended.
- How the field definitions connect to visualization components such as filters, tables, charts, and detail panels.

The system is intentionally frozen around a small set of verified Phase 1 items so that request width, caching, UI columns, and analytics remain consistent.

## Project Structure
The relevant code lives under `User scripts/FI Index Change/fi_index_change`:
- `field_library.py` defines the canonical list of bond attributes and their BQL builders.
- `data.py` builds and executes BQL requests, parses responses, merges item frames, and finalizes snapshots.
- `engine.py` normalizes, validates, buckets, aligns, summarizes, and exports bond data.
- `app.py` owns the Jupyter widgets, filter controls, charts, and detail views.
- `config.py` holds operational defaults, labels, thresholds, and display constants.

```mermaid
graph TB
App["app.py<br/>UI, filters, charts, detail"] --> Engine["engine.py<br/>validation, buckets, summary, export"]
App --> Data["data.py<br/>BQL execution, parsing, merging"]
Data --> FieldLib["field_library.py<br/>bond attribute definitions"]
Engine --> Config["config.py<br/>defaults, labels, thresholds"]
App --> Config
```

**Diagram sources**
- [app.py:26-49](file://User scripts/FI Index Change/fi_index_change/app.py#L26-L49)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [config.py:12-121](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L121)

**Section sources**
- [field_library.py:1-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L1-L75)
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [engine.py:1-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L1-L28)
- [app.py:1-49](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L49)
- [config.py:1-121](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L121)

## Core Components
The field library defines the canonical bond attributes:
- Identity and classification: Name, Issuer, Sector, Country, Currency, Security Type, Maturity, Tenor, Rating, ISIN, SEDOL.
- Pricing and risk: Coupon, OAS, Z-Spread, I-Spread, Duration, Modified Duration, Effective Duration, OASD, Yield, YTM, YTW.
- Membership weight: Weight.
- Snapshot metadata: AS_OF_DATE, SNAPSHOT_KIND.

These names are central:
- They define the BQL request width.
- They determine which columns are numeric versus string.
- They drive UI column lists, filter options, export columns, and chart metrics.

Key definitions:
- Spread fields: OAS, Z-Spread, I-Spread.
- Duration fields: Duration, Modified Duration, Effective Duration, OASD.
- Yield fields: Yield, YTM, YTW.
- Numeric columns include Weight, Tenor, Coupon, all spread/duration/yield fields.
- String columns include identity, classification, identifiers, and snapshot metadata.

**Section sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [field_library.py:123-142](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L142)

## Architecture Overview
The data flow from Bloomberg to the dashboard follows these steps:
1. The app collects user inputs (index ticker, month-end, filters).
2. `data.fetch_index_payload` requests the selected month-end and the previous month-end.
3. For each date, `field_library.build_member_items` creates BQL item builders for the requested fields.
4. Responses are parsed, merged by security ID, and finalized into normalized snapshots.
5. `engine.prepare_members` applies validation, normalization, bucketing, and fallback logic.
6. `engine.build_transition` compares two snapshots and computes changes, summaries, and exports.
7. `app.FIIndexChangeApp` renders filters, charts, and detail panels based on the transition.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant FieldLib as "field_library.py"
participant Engine as "engine.py"
User->>App : Click Update
App->>Data : fetch_index_payload(index, month)
Data->>FieldLib : build_member_items(bq, names)
FieldLib-->>Data : BQL item builders
Data->>Data : execute, parse, merge, finalize
Data-->>App : IndexPayload(snapshots, statuses, notes)
App->>Engine : build_transition(previous, latest)
Engine-->>App : Transition(summary, warnings)
App-->>User : Render filters, charts, detail
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [field_library.py:190-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L190-L215)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

## Detailed Component Analysis

### Field Library: Bond Attribute Definitions and BQL Mapping
The field library is the single source of truth for bond attributes. It exposes:
- Frozen tuples for spreads, durations, yields, and the full item name list.
- A mapping from each standard field name to a BQL builder function.
- Groupings for analytics families to split wide requests.
- Numeric and string column classifications.

Bloomberg mappings:
- Name → `bq.data.name()`
- Issuer → `bq.data.long_comp_name()`
- Sector → `bq.data.classification_name()`
- Country → `bq.data.country_full_name()`
- Currency → `bq.data.crncy()`
- Security Type → `bq.data.security_typ()`
- Maturity → `bq.data.maturity()`
- Tenor → `bq.data.mty_years_tdy()`
- Rating → `bq.data.rating()`
- Coupon → `bq.data.cpn()`
- Spreads → `bq.data.spread(spread_type="OAS"/"Z"/"I")`
- Durations → `bq.data.duration(duration_type="MODIFIED"/"EFFECTIVE"/"SPREAD")`, with default `duration()`
- Yields → `bq.data.yield_(yield_type="YTM"/"YTW")`, with default `yield_()`
- Weight → `bq.data.id()["weights"]`
- Identifiers → `bq.data.id_isin()["value"]`, `bq.data.id_sedol1()["value"]`

Validation and error handling:
- Unknown field names raise a clear key error.
- Builder failures wrap the original exception in `ItemBuildError`, preserving the failing item name.

Extension points:
- Add a new field by appending its name to the appropriate tuple (`SPREAD_FIELDS`, `DURATION_FIELDS`, `YIELD_FIELDS`, or `ITEM_NAMES`).
- Add a builder entry in `_ITEM_CALLS`.
- Update `NUMERIC_COLUMNS` if the field is numeric.
- Update `STRING_COLUMNS` if the field is text.
- If it belongs to an analytics family, add it to `ANALYTICS_GROUPS` when splitting requests.

```mermaid
classDiagram
class FieldLibrary {
+tuple SPREAD_FIELDS
+tuple DURATION_FIELDS
+tuple YIELD_FIELDS
+tuple ITEM_NAMES
+tuple NUMERIC_COLUMNS
+tuple STRING_COLUMNS
+tuple ANALYTICS_GROUPS
+build_member_items(bq, names) dict
+ItemBuildError(item, cause)
}
```

**Diagram sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [field_library.py:123-142](file://User scripts/FI Index Change/fi_index_change/field_library.py#L123-L142)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

**Section sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [field_library.py:147-215](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L215)

### Data Layer: Request Building, Parsing, and Finalization
Responsibilities:
- Build BQL requests using the field library.
- Execute requests with retry-only-on-timeout logic.
- Parse responses robustly, selecting value columns even when response shapes vary.
- Merge multiple item frames by security ID.
- Finalize snapshots with normalized types and metadata.

Key behaviors:
- Split requests: When enabled, identity fields are fetched separately, then analytics groups (spreads/yields vs durations) are fetched independently. This reduces timeout risk and isolates failures.
- Response parsing: Prefers explicit aliases (e.g., `BASE_RATING` for `Rating`), then picks the most populated candidate column among known names, then falls back to unique non-metadata columns.
- Missing items: Reports which requested item names did not appear in the parsed frame.
- Empty values: Reports when a column exists but every value is null.
- Duplicate IDs: Collapses duplicates while keeping the last non-null value per column after forward-filling.
- Finalization: Adds `AS_OF_DATE` and `SNAPSHOT_KIND`, coerces numeric columns, and delegates normalization to `engine.prepare_members`.

```mermaid
flowchart TD
Start(["Fetch index payload"]) --> BuildItems["Build BQL items from field_library"]
BuildItems --> Execute["Execute request with timeout retry"]
Execute --> Parse["Parse response to DataFrame"]
Parse --> Merge["Merge item frames by ID"]
Merge --> Finalize["Finalize snapshot<br/>types, dates, kind"]
Finalize --> Normalize["engine.prepare_members"]
Normalize --> Status["Mark status ok/partial/unavailable"]
```

**Diagram sources**
- [data.py:494-698](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L698)
- [data.py:701-800](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L800)

**Section sources**
- [data.py:125-196](file://User scripts/FI Index Change/fi_index_change/data.py#L125-L196)
- [data.py:222-321](file://User scripts/FI Index Change/fi_index_change/data.py#L222-L321)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:529-595](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L595)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [data.py:701-800](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L800)

### Engine: Validation Rules, Fallbacks, and Bucketing
Normalization and validation:
- Blank text normalization: Converts NaN, None, NaT, and empty strings to `(blank)` for display consistency.
- Numeric coercion: Coerces Weight, Tenor, Coupon, spreads, durations, and yields; replaces infinities with NaN.
- Book assignment: Assigns `MBS/TBA` for MBS/TBA-like securities and `Standard` otherwise.
- MBS/TBA and Municipal overrides:
  - MBS/TBA rows get Country/Sector set to `MBS/TBA` when blank; Currency defaults to USD when blank.
  - Municipal bonds (ID ending with `Muni`) get Country/Sector set to `Municipal`, Currency set to USD, and Rating marked not applicable.
- Rating handling:
  - Raw Rating text is preserved.
  - Rating Bucket is IG, HY, or NR. Numeric vendor scales and blanks map to NR.
  - If the Rating column is absent, every bond is classified NR and a note records the missing item.
- Tenor bucketing: Maps numeric tenor years to fixed buckets; negative/non-finite values stay Missing; MBS/TBA with Missing tenor becomes N.A.
- Label alignment: Aligns classification labels between previous and latest snapshots so one ID has one classification per dimension.

Fallback mechanisms:
- Missing Rating column → NR classification with a log note.
- Missing Tenor → Missing bucket; MBS/TBA → N.A.
- Missing currency on MBS/TBA → USD.
- Missing country/sector on MBS/TBA → `MBS/TBA`.
- Partial snapshots → status `partial`; cache refused for problematic identity columns.

Summary and metrics:
- Weighted means skip nulls, bad weights, and extreme OAS sentinel values.
- Summary includes counts, weights, begin/end/+/- for spreads, durations, yields, tenor, coupon, turnover, and turnover rate.

```mermaid
flowchart TD
Input(["Normalized snapshot"]) --> NumericCoerce["Coerce numeric columns<br/>Weight, Tenor, Coupon, spreads, durations, yields"]
NumericCoerce --> BookAssign["Assign Book: Standard or MBS/TBA"]
BookAssign --> MBSCountrySector["MBS/TBA overrides<br/>Country/Sector/Currency"]
MBSCountrySector --> MunicipalCheck["Municipal override<br/>Country/Sector/Currency/Rating"]
MunicipalCheck --> RatingBucket["Compute Rating Bucket<br/>IG/HY/NR"]
RatingBucket --> TenorBucket["Compute Tenor Bucket<br/>Missing/N.A./ranges"]
TenorBucket --> AlignLabels["Align labels across snapshots"]
AlignLabels --> Output(["Validated snapshot"])
```

**Diagram sources**
- [engine.py:301-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L301-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)

**Section sources**
- [engine.py:301-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L301-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:855-882](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L882)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

### App: Visualization and Field Relationships
The app connects field definitions to UI components:
- Filter controls: Country, Sector, Tenor, Rating, Currency, Spread, Duration, Yield, Book.
- Spread options: OAS, Z-Spread, I-Spread.
- Duration fields: Duration, Modified Duration, Effective Duration, OASD.
- Yield fields: Yield, YTM, YTW.
- Detail panel: Displays a vertical bond field table ordered by `DETAIL_FIELDS`.
- Charts: Horizontal bar charts for add/exit weight by dimension and top add/exit bonds.
- Export: Copy-friendly frames with repeated headers and formatted cells.

Field-to-visualization mapping:
- `BOND_COLUMNS` defines the main grid columns.
- `DETAIL_FIELDS` defines the detail panel order.
- `POSITION_COLUMNS` defines the full position export.
- `FILTER_COLUMNS` maps widget labels to engine column names.
- `DURATION_LABELS` and `YIELD_LABELS` provide human-readable labels for select widgets.

```mermaid
graph TB
Filters["Filters<br/>Country, Sector, Tenor, Rating, Currency, Spread, Duration, Yield, Book"] --> Grid["Main Grid<br/>BOND_COLUMNS"]
Filters --> Charts["Charts<br/>Dimension and Detail"]
Grid --> Detail["Detail Panel<br/>DETAIL_FIELDS"]
Grid --> Export["Export Frames<br/>EXPORT_COLUMNS / POSITION_COLUMNS"]
Charts --> Detail
```

**Diagram sources**
- [app.py:73-102](file://User scripts/FI Index Change/fi_index_change/app.py#L73-L102)
- [app.py:107-137](file://User scripts/FI Index Change/fi_index_change/app.py#L107-L137)
- [app.py:171-212](file://User scripts/FI Index Change/fi_index_change/app.py#L171-L212)
- [app.py:380-432](file://User scripts/FI Index Change/fi_index_change/app.py#L380-L432)

**Section sources**
- [app.py:73-102](file://User scripts/FI Index Change/fi_index_change/app.py#L73-L102)
- [app.py:107-137](file://User scripts/FI Index Change/fi_index_change/app.py#L107-L137)
- [app.py:171-212](file://User scripts/FI Index Change/fi_index_change/app.py#L171-L212)
- [app.py:380-432](file://User scripts/FI Index Change/fi_index_change/app.py#L380-L432)

## Dependency Analysis
Coupling and cohesion:
- `field_library.py` is low-level and cohesive: it defines immutable field sets and BQL builders.
- `data.py` depends on `field_library` for item builders and on `engine` for normalization helpers.
- `engine.py` depends on `field_library` only for field group names and on `config.py` for labels and thresholds.
- `app.py` depends on `engine` for business logic and on `data` for payload retrieval.

External dependencies:
- Bloomberg BQL service is required at runtime; local authoring tolerates its absence.
- Pandas and NumPy are used for data manipulation and numeric handling.
- Plotly and ipywidgets power the dashboard visuals.

Potential circular dependencies:
- No direct cycles exist; dependencies flow from app → data → field_library and app → engine.

```mermaid
graph LR
FieldLib["field_library.py"] --> Data["data.py"]
FieldLib -.-> Engine["engine.py"]
Config["config.py"] --> Engine
Data --> Engine
Engine --> App["app.py"]
Data --> App
```

**Diagram sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [app.py:26-49](file://User scripts/FI Index Change/fi_index_change/app.py#L26-L49)

**Section sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [app.py:26-49](file://User scripts/FI Index Change/fi_index_change/app.py#L26-L49)

## Performance Considerations
- Request splitting: Analytics are grouped into spreads/yields and durations to reduce timeout risk. Durations are requested last so partial results still show identity, spreads, and yields.
- Retry policy: Only timeouts are retried; deterministic errors (entitlement, unknown field, invalid ticker) are not retried.
- Cache safety: Historical snapshots are cached only when they contain usable identity columns and no failed analytics groups.
- Display caps: Row caps and chart limits prevent heavy rendering on large universes.
- Numeric rounding: Grid frames round floats to four decimals and format dates safely to avoid JavaScript serialization errors.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Unknown field name: Ensure the field exists in `ITEM_NAMES` and has a builder in `_ITEM_CALLS`.
- Builder failure: Check `ItemBuildError.item` to identify the failing field; verify the BQL API spelling and parameters.
- Missing columns: Inspect notes for “item(s) did not parse” and “arrived with a column but every value null”.
- Duration duplication warning: If duration fields return identical values across all rows, one builder may ignore `duration_type`; treat them as one measure until confirmed.
- Partial snapshots: Indicates missing or entirely empty identity columns; the month is not cached and will be re-requested.
- License/access errors: The app detects membership/license messages and displays a clear access failure banner.

Operational checks:
- Validate index ticker ends with ` Index`.
- Confirm month-end selection is within allowed choices.
- Review `OAS_EXCLUDE_AT_OR_ABOVE` when OAS outliers distort weighted means.
- Verify `WEIGHT_FRACTION_SUM_MAX` when weights arrive as fractions versus percent points.

**Section sources**
- [field_library.py:89-100](file://User scripts/FI Index Change/fi_index_change/field_library.py#L89-L100)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:529-595](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L595)
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:800-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L800-L840)

## Conclusion
The field library system centralizes bond attribute definitions and ensures consistent mapping from Bloomberg BQL fields to standardized names. It enforces strict validation, robust fallbacks, and clear diagnostics. The architecture separates concerns cleanly: field definitions, request execution and parsing, normalization and validation, and visualization. Extending the system requires updating the frozen field sets, adding builders, and aligning UI and export definitions. This design keeps the dashboard reliable, auditable, and extensible while minimizing performance risks through request splitting and targeted retries.

[No sources needed since this section summarizes without analyzing specific files]