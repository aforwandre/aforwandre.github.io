# Reporting and Export Capabilities

<cite>
**Referenced Files in This Document**
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [interface.html](file://User scripts/FI Index Change/preview/interface.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the reporting and export capabilities of the Fixed Income Index Change module. It focuses on how change summaries, audit-ready data, and full position snapshots are prepared for copy-to-Excel workflows, CSV persistence, and structured programmatic consumption. It also documents customization options such as column selection, filtering, and report layout behavior, along with validation rules that protect data integrity during caching and export.

The module does not write Excel files directly from the dashboard. Instead, it prepares display-friendly frames whose first row repeats column names so that a user can select the whole table, copy it, and paste it into Excel while retaining headers. Programmatic consumers can use the same frame structures to build CSV exports, integrate with external systems, or generate compliance documentation.

## Project Structure
The reporting and export functionality spans four main layers:

- Application layer: builds the dashboard UI, manages user selections, and exposes Export and Full Position tabs.
- Engine layer: computes changes, summaries, export frames, and grid-safe display frames.
- Data layer: requests historical and projected index membership, parses responses, and coordinates cache usage.
- Cache layer: persists validated historical snapshots and export file paths.

```mermaid
graph TB
App["Application Layer<br/>app.py"] --> Engine["Engine Layer<br/>engine.py"]
App --> Data["Data Layer<br/>data.py"]
Data --> Cache["Cache Layer<br/>cache.py"]
Engine --> FieldLibrary["Field Library<br/>field_library.py"]
Engine --> Config["Configuration<br/>config.py"]
Preview["Preview Interface<br/>interface.html"] --> App
```

**Diagram sources**
- [app.py:307-660](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L660)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:122-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L122-L143)
- [interface.html:235-248](file://User scripts/FI Index Change/preview/interface.html#L235-L248)

**Section sources**
- [app.py:307-660](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L660)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:122-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L122-L143)
- [interface.html:235-248](file://User scripts/FI Index Change/preview/interface.html#L235-L248)

## Core Components
The reporting and export system is built around these core components:

- Export frames: tabular outputs for Changes and Summary, plus Full Position snapshots.
- Display formatting: header-repeat rows and safe cell serialization for Excel copy/paste.
- Grid frames: sanitized views for interactive tables and detail panels.
- Historical cache: validated snapshots used for fast reloads and audit trails.
- Export path generation: deterministic CSV filenames for changes and summary outputs.
- Validation and integrity checks: required columns, weight presence, identity value checks, and contract tokens.

Key responsibilities by file:

| Component | Primary File | Responsibility |
|---|---|---|
| Dashboard export controls | [app.py](file://User scripts/FI Index Change/fi_index_change/app.py) | Manages Export and Full Position tabs, selects Changes or Summary, renders copyable grids. |
| Change and summary computation | [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py) | Builds transitions, diffs adds/exits, summarizes dimensions, formats export frames. |
| Data fetching and parsing | [data.py](file://User scripts/FI Index Change/fi_index_change/data.py) | Requests BQL membership, parses items, handles timeouts, marks partial results. |
| Snapshot cache | [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py) | Validates, loads, saves historical snapshots; generates CSV export paths. |
| Field definitions | [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py) | Defines item names, analytics groups, numeric/string columns. |
| Configuration | [config.py](file://User scripts/FI Index Change/fi_index_change/config.py) | Controls month-end choices, display caps, filter widths, and business constants. |
| Preview interface | [interface.html](file://User scripts/FI Index Change/preview/interface.html) | Mirrors app behavior for local preview, including Export and Full Position tabs. |

**Section sources**
- [app.py:521-576](file://User scripts/FI Index Change/fi_index_change/app.py#L521-L576)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:122-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L122-L143)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [interface.html:235-248](file://User scripts/FI Index Change/preview/interface.html#L235-L248)

## Architecture Overview
The export workflow begins when the user clicks Update. The application fetches two month-ends, validates them, builds a transition, and then prepares both visual summaries and export frames.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "FIIndexChangeApp<br/>app.py"
participant Data as "fetch_index_payload<br/>data.py"
participant Cache as "load_historical/save_historical<br/>cache.py"
participant Engine as "build_transition/export_display_frame<br/>engine.py"
User->>App : Click Update
App->>Data : Request previous and selected month-end
Data->>Cache : Load historical snapshot if available
Cache-->>Data : Validated frame or None
Data->>Data : Parse response, mark ok/partial/unavailable
Data-->>App : IndexPayload with snapshots and statuses
App->>Engine : Build transition and compute comparison
Engine-->>App : Transition with previous/latest frames
App->>Engine : Prepare Changes and Summary export frames
Engine-->>App : Copy-ready frames with repeated headers
App-->>User : Render Export and Full Position tabs
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)

## Detailed Component Analysis

### Export Formats Supported
The module supports three primary export modes:

| Export Mode | Output Type | Use Case | Header Behavior |
|---|---|---|---|
| Changes | Tabular frame with Action, ID, Name, Weight, classification fields, spreads, duration, yield, maturity, book, security type, and AS_OF_DATE | Audit trail of constituent additions and exits | First data row repeats column names for Excel copy/paste |
| Summary | Dimension-level aggregation with counts, weights, turnover, spread/duration/yield deltas, and add/exit contributions | Change summary and compliance reporting | Column set derived from active dimension and analytics selections |
| Full Position | Constituent list at Start date or End date without Action | Baseline positions for reconciliation and compliance | Same columns as CSV export minus Action; AS_OF_DATE identifies month-end |

The dashboard explicitly instructs users to select the whole table, copy it, and paste it into Excel. No file is written by the dashboard itself. Programmatic consumers should treat the returned pandas frames as the canonical export format.

**Section sources**
- [app.py:521-576](file://User scripts/FI Index Change/fi_index_change/app.py#L521-L576)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)

### Report Templates: Change Summaries, Audit Trails, and Compliance Documentation
The module provides two built-in templates:

- Changes template: every added or exited bond in the selected book, sorted by action and weight. It includes identity fields, classification buckets, analytics measures, and metadata such as Book and AS_OF_DATE.
- Summary template: one row per dimension category (for example Country, Sector, Tenor Bucket, Rating Bucket, Currency), with Begin and End counts and weights, turnover calculations, spread/duration/yield deltas, and Add/Exit contribution metrics.

For compliance documentation, consumers can combine:

- Changes frame as an audit trail of membership movement.
- Summary frame as a high-level change report.
- Full Position frame as a baseline snapshot for reconciliation.
- Cache manifest and generated CSV filenames as evidence of historical availability and reproducibility.

**Section sources**
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [cache.py:220-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L220-L229)

### Customization Options: Layouts, Columns, and Filtering
Customization is controlled through dashboard controls and engine configuration:

- Dimension selection: Country, Sector, Tenor, Rating, Currency.
- Bond selection: Add, Exit, or Add and Exit.
- Filters: Country, Sector, Tenor Bucket, Rating Bucket, Currency, Spread, Duration, Yield, and Book.
- Analytics selection: Spread fields, Duration fields, and Yield fields can be toggled to include or exclude measures from the summary and detail views.
- Column ordering: EXPORT_COLUMNS defines the canonical order for change exports; POSITION_COLUMNS defines the canonical order for full position exports.
- Row cap: DISPLAY_ROW_CAP limits displayed rows to avoid oversized grids.

Filtering applies before computing summaries and change lists. The scope line in the headline shows the active book and filters, which is important for compliance traceability.

```mermaid
flowchart TD
Start["User Selections"] --> Dimension["Dimension Filter"]
Start --> Bonds["Bond Filter: Add / Exit / Both"]
Start --> Filters["Dimensional Filters: Country, Sector, Tenor, Rating, Currency"]
Start --> Analytics["Analytics Selection: Spread, Duration, Yield"]
Dimension --> Compute["Compute Summary and Changes"]
Bonds --> Compute
Filters --> Compute
Analytics --> Compute
Compute --> ExportFrame["Prepare Export Frame"]
Compute --> GridFrame["Prepare Grid Frame"]
ExportFrame --> Display["Export Tab"]
GridFrame --> MainView["Main View"]
```

**Diagram sources**
- [app.py:354-432](file://User scripts/FI Index Change/fi_index_change/app.py#L354-L432)
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

**Section sources**
- [app.py:354-432](file://User scripts/FI Index Change/fi_index_change/app.py#L354-L432)
- [app.py:951-998](file://User scripts/FI Index Change/fi_index_change/app.py#L951-L998)
- [engine.py:676-701](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L701)
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

### Automated Report Generation Workflows
Automated workflows should consume the programmatic frames rather than rely on clipboard behavior:

1. Trigger an update for a specific index ticker and month-end.
2. Retrieve the transition and snapshots from the payload.
3. Generate the Changes frame using the current book.
4. Generate the Summary frame using the selected dimension.
5. Generate the Full Position frame for Start or End date.
6. Persist frames to CSV using the exported column sets.
7. Record the cache manifest entry and generated filenames for audit purposes.

```mermaid
sequenceDiagram
participant Scheduler as "Scheduler"
participant App as "FIIndexChangeApp<br/>app.py"
participant Engine as "engine.py"
participant Cache as "cache.py"
participant System as "External System"
Scheduler->>App : Request update(index_ticker, month_end)
App->>Engine : Build transition and compute frames
Engine-->>App : Changes, Summary, Full Position frames
App->>Cache : Resolve export_paths(previous_date, latest_date, book)
Cache-->>App : CSV paths for changes and summary
App->>System : Write CSVs or send structured frames
System-->>Scheduler : Acknowledge export completion
```

**Diagram sources**
- [app.py:1423-1449](file://User scripts/FI Index Change/fi_index_change/app.py#L1423-L1449)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [cache.py:122-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L122-L143)

**Section sources**
- [app.py:1423-1449](file://User scripts/FI Index Change/fi_index_change/app.py#L1423-L1449)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [cache.py:122-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L122-L143)

### Integration with External Systems
Integration points include:

- Structured data output: pandas frames with consistent column sets make it straightforward to serialize to CSV, JSON, or database tables.
- CSV persistence: cache.py writes historical snapshots to CSV and maintains a manifest describing field contracts, generation version, file name, row count, and recorded columns.
- Export path generation: deterministic filenames encode index ticker, previous date, latest date, and book label, making automated retrieval and auditing reliable.
- Preview compatibility: the preview interface mirrors the app’s Export and Full Position behavior, helping validate integration logic without Bloomberg connectivity.

When integrating externally, prefer consuming the frame objects produced by `change_export_frame`, `export_display_frame`, and the Full Position view functions. Avoid parsing HTML tables unless absolutely necessary.

**Section sources**
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)
- [cache.py:122-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L122-L143)
- [interface.html:727-749](file://User scripts/FI Index Change/preview/interface.html#L727-L749)

### Export Validation Processes and Data Integrity Checks
Validation is layered across data loading, caching, and export preparation:

- Required columns: snapshots must carry identity columns and Weight. Missing identity values cause the month to be marked partial and refused for cache storage.
- Weight validation: snapshots without usable Weight values are rejected.
- Identity value checks: cached frames with all identity columns empty are treated as unusable and re-requested.
- Contract tokens: field contract and cache generation tokens prevent stale or incompatible snapshots from being loaded after pipeline changes.
- Export requirements: change export requires Action and Weight; missing columns raise errors rather than silently producing incomplete reports.
- Grid safety: datetime columns are converted to strings to avoid browser serialization failures; helper columns are excluded from grid views.

```mermaid
flowchart TD
Load["Load Snapshot"] --> CheckColumns["Check Required Columns"]
CheckColumns --> WeightValid{"Weight Usable?"}
WeightValid --> |No| Reject["Reject Snapshot"]
WeightValid --> |Yes| IdentityCheck["Check Identity Values"]
IdentityCheck --> IdentityOk{"Identity Populated?"}
IdentityOk --> |No| Reject
IdentityOk --> |Yes| ContractCheck["Validate Field Contract and Generation"]
ContractCheck --> ContractOk{"Contract Matches?"}
ContractOk --> |No| Reject
ContractOk --> |Yes| Accept["Accept Snapshot"]
Accept --> Export["Generate Export Frames"]
Export --> ValidateExport{"Action and Weight Present?"}
ValidateExport --> |No| ExportError["Raise Export Error"]
ValidateExport --> |Yes| Ready["Ready for CSV or Copy/Paste"]
```

**Diagram sources**
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:980-1002](file://User scripts/FI Index Change/fi_index_change/engine.py#L980-L1002)

**Section sources**
- [cache.py:60-71](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L71)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:980-1002](file://User scripts/FI Index Change/fi_index_change/engine.py#L980-L1002)

### Report Scheduling and Distribution Mechanisms
The module itself does not implement scheduling or email distribution. However, its design supports automation:

- Scheduling: an external scheduler can invoke the update flow for a fixed schedule, for example monthly on effective dates.
- Distribution: after generating frames, an orchestrator can write CSVs to a shared location, upload to a data lake, or send structured payloads to downstream systems.
- Auditability: the cache manifest and deterministic export filenames provide a reproducible trail for scheduled runs.
- Status handling: the payload carries status values such as ok, partial, unavailable, and membership access failures, allowing schedulers to route alerts or retries appropriately.

Recommended scheduling practices:

- Run only on valid month-ends from the allowed dropdown.
- Retry only timeout-related failures; deterministic entitlement or field-name failures should not be retried blindly.
- Log notes about partial snapshots, missing items, and identical duration measures.
- Capture the generated CSV paths and manifest entries for each run.

**Section sources**
- [data.py:499-595](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L595)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [cache.py:220-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L220-L229)

## Dependency Analysis
The reporting and export subsystem depends on several modules:

- app.py depends on engine.py for computation and on data.py for payload retrieval.
- engine.py depends on field_library.py for item and analytics definitions and on config.py for business constants.
- data.py depends on cache.py for historical snapshots and on engine.py for normalization and alignment helpers.
- cache.py depends on engine.py for identity-value checks and on field_library.py for column definitions.

```mermaid
graph LR
App["app.py"] --> Engine["engine.py"]
App --> Data["data.py"]
Data --> Cache["cache.py"]
Engine --> FieldLibrary["field_library.py"]
Engine --> Config["config.py"]
Cache --> Engine
Cache --> FieldLibrary
```

**Diagram sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

**Section sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

## Performance Considerations
- Historical cache reuse avoids repeated BQL calls for locked months.
- Split request mode separates identity fields from analytics groups, improving resilience when some measure families fail.
- Timeout detection prevents retrying deterministic failures.
- Display row caps reduce rendering overhead for large grids.
- Export frames avoid heavy formatting until needed; copy-ready frames are lightweight text conversions.

Best practices:

- Prefer cached months where available.
- Keep analytics group requests grouped to minimize network round trips.
- Limit displayed rows and analytics fields when exploring large indices.
- Use programmatic frames for automation instead of parsing rendered HTML.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their implications for reporting and export:

- Membership license failure: the login cannot read the index. The screen shows a clear error, and no comparison is computed. Export frames remain empty.
- Partial snapshot: one or more required items did not parse. The comparison still computes, but warnings indicate affected dimensions may be blank or classified NR.
- Unavailable snapshot: either month-end is missing or invalid. The transition status becomes unavailable and export tables show no data.
- Missing identity values: a cached frame with all identity columns empty is rejected and re-requested to recover from previously poisoned snapshots.
- Export validation failure: missing Action or Weight in change export raises an error rather than producing a misleading report.

Operational steps:

1. Inspect the status line and log for membership, entitlement, or timeout messages.
2. Check whether the month is marked ok, partial, or unavailable.
3. Verify that required identity columns and Weight are present.
4. Review cache manifest entries for field contract mismatches or generation changes.
5. Regenerate exports after a successful update rather than relying on stale cached frames.

**Section sources**
- [engine.py:99-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L99-L119)
- [engine.py:800-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L800-L840)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)

## Conclusion
The FI Index Change module provides robust reporting and export capabilities centered on change summaries, audit-ready constituent lists, and full position snapshots. Its design emphasizes data integrity through layered validation, deterministic cache contracts, and explicit status reporting. While the dashboard uses copy-to-Excel for manual workflows, the underlying pandas frames and CSV paths support automated scheduling, external system integration, and compliance documentation. Users and integrators should consume the programmatic frames, respect the validation rules, and record cache artifacts for reproducibility.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Export Column Reference
- Changes export columns include Action, identity fields, classification buckets, Weight, spreads, duration, yield, maturity, Book, Security Type, and AS_OF_DATE.
- Summary export columns depend on the selected dimension and active analytics selections.
- Full Position export columns match the CSV export columns except Action, with AS_OF_DATE identifying the month-end.

**Section sources**
- [engine.py:676-701](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L701)
- [app.py:171-203](file://User scripts/FI Index Change/fi_index_change/app.py#L171-L203)