# Export Formats and Data Structures

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [test_engine.py](file://User scripts/FI Index Change/tests/test_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the export formats produced by the Fixed Income Index Change module. It focuses on:
- The CSV-compatible change table structure, including every required column.
- The Excel-compatible display format that repeats headers so copied tables retain column names.
- The structured data outputs for changes (Add and Exit transitions) and summary statistics.
- Examples of each export shape.
- The validation and normalization steps that protect data integrity during export.

The module does not write files to disk; it prepares pandas DataFrames that can be copied from the dashboard into Excel or consumed programmatically.

## Project Structure
The export logic is primarily implemented in the engine layer, with supporting definitions in the field library and application layer.

```mermaid
graph TB
App["fi_index_change/app.py<br/>Dashboard controller"] --> Engine["fi_index_change/engine.py<br/>Comparison, exports, summaries"]
Engine --> FieldLibrary["fi_index_change/field_library.py<br/>Field contracts"]
Engine --> Config["fi_index_change/config.py<br/>Defaults and constants"]
Data["fi_index_change/data.py<br/>BQL payload and snapshots"] --> Engine
Tests["tests/test_engine.py<br/>Export contract tests"] --> Engine
```

**Diagram sources**
- [app.py:26-49](file://User scripts/FI Index Change/fi_index_change/app.py#L26-L49)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [config.py:12-120](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L120)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [test_engine.py:22-46](file://User scripts/FI Index Change/tests/test_engine.py#L22-L46)

**Section sources**
- [app.py:26-49](file://User scripts/FI Index Change/fi_index_change/app.py#L26-L49)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [config.py:12-120](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L120)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [test_engine.py:22-46](file://User scripts/FI Index Change/tests/test_engine.py#L22-L46)

## Core Components
The export system revolves around three responsibilities:
- Preparing normalized member snapshots.
- Deriving Add and Exit rows from membership differences.
- Formatting those rows for Excel-friendly copying.

Key components:
- `prepare_members`: Normalizes raw snapshot data, classifies books, countries, sectors, ratings, tenor buckets, currencies, and adds `AS_OF_DATE`.
- `diff_members`: Computes Add and Exit rows per book.
- `change_export_frame`: Builds the CSV-compatible change table.
- `export_display_frame`: Prepares an Excel-compatible copy frame with a repeated header row.
- `summarize`: Produces aggregated bucket-level statistics and headline metrics.

**Section sources**
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:759-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L759-L781)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

## Architecture Overview
The end-to-end export flow starts with BQL snapshots, proceeds through normalization and comparison, and ends with formatted output frames.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "FIIndexChangeApp"
participant Data as "fetch_index_payload"
participant Engine as "build_transition / change_export_frame"
participant Output as "Excel / CSV consumer"
User->>App : Click Update
App->>Data : Request previous and selected month-end
Data-->>App : Snapshots with AS_OF_DATE
App->>Engine : Build transition and compute diffs
Engine-->>App : Transition with previous/latest/add/exited
App->>Engine : request change_export_frame(transition, book)
Engine-->>App : DataFrame with Action, ID, Weight, analytics
App->>Engine : request export_display_frame(frame, columns)
Engine-->>Output : Header-repeated frame ready for copy/paste
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:759-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L759-L781)

## Detailed Component Analysis

### CSV Export Structure
The change export table represents every security added or exited between two month-ends within the selected book. Its canonical column order is defined centrally and includes identity, classification, weighting, analytics, metadata, and the snapshot date.

Canonical export columns:
- Action
- ID
- Name
- Issuer
- ISIN
- SEDOL
- Country
- Sector
- Weight
- Tenor Bucket
- Tenor
- Rating
- Rating Bucket
- Currency
- Coupon
- OAS
- Z-Spread
- I-Spread
- Duration
- Modified Duration
- Effective Duration
- OASD
- Yield
- YTM
- YTW
- Maturity
- Book
- Security Type
- AS_OF_DATE

Important rules:
- Only Add and Exit rows are included.
- Weight is required and must be numeric.
- Rows are sorted by Action first, then by Weight descending.
- Missing values become blank strings in the Excel-compatible view.
- Dates are exported as ISO text (`YYYY-MM-DD`).
- Weight is displayed as percent points without rounding, with a trailing percent sign.

Example shape (textual):
- Header row: `Action,ID,Name,Issuer,ISIN,SEDOL,Country,Sector,Weight,Tenor Bucket,Tenor,Rating,Rating Bucket,Currency,Coupon,OAS,Z-Spread,I-Spread,Duration,Modified Duration,Effective Duration,OASD,Yield,YTM,YTW,Maturity,Book,Security Type,AS_OF_DATE`
- Sample Add row: `Add,US1234567890,Company A Bond,Company A,US1234567890,,United States,Corporate,2.50%,3-5Y,4.20,AA-,IG,USD,3.50,120.0,115.0,108.0,4.10,4.05,3.95,3.80,5.20,5.15,5.10,2028-06-15,Standard,GLOBAL,2026-10-30`
- Sample Exit row: `Exit,DE9876543210,Bank B Note,Bank B,DE9876543210,,Germany,Financials,1.80%,1-3Y,2.10,Ba1,HY,EUR,2.00,210.0,205.0,195.0,2.30,2.25,2.20,2.15,3.10,3.05,3.00,2027-03-20,Standard,GLOBAL,2026-09-30`

Validation guarantees:
- If the transition is unavailable, the export returns an empty frame with the correct columns.
- If Weight is missing from Add or Exit rows, the function raises a validation error.
- Weight is coerced to numeric before sorting.

**Section sources**
- [engine.py:676-701](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L701)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [engine.py:732-756](file://User scripts/FI Index Change/fi_index_change/engine.py#L732-L756)
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)

### Excel-Compatible Format with Repeated Headers
The Excel-compatible format is designed for copy-and-paste workflows where the clipboard may not carry column headers. The function prepends a header row that repeats the column names, followed by the data rows converted to safe text.

Behavior:
- The first row contains the requested column names.
- Every subsequent row contains stringified values.
- Numeric values are trimmed to avoid unnecessary trailing zeros.
- Percent columns receive a percent sign.
- Date-like values are formatted as ISO text.
- NaN and null values become blank cells.
- If no matching columns exist, only the header row is returned.

Example shape (textual):
- Row 1: `Action,ID,Weight,Maturity`
- Row 2: `Add,US1234567890,2.50%,2028-06-15`
- Row 3: `Exit,DE9876543210,1.80%,2027-03-20`

Tests verify:
- The first data row repeats the header.
- Weight is printed as a percent without rounding.
- Other numeric columns do not receive a percent sign.
- Empty frames still return the header row.
- Frames with none of the requested columns return only the header row instead of raising.

**Section sources**
- [engine.py:759-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L759-L781)
- [test_engine.py:643-689](file://User scripts/FI Index Change/tests/test_engine.py#L643-L689)

### Changes Data: Add and Exit Transitions
Changes data is derived from membership differences between the previous month-end and the selected month-end.

Processing steps:
1. Filter both snapshots by the selected book.
2. Compute IDs present only in the latest snapshot (Add).
3. Compute IDs present only in the previous snapshot (Exit).
4. Attach the `Action` label to each side.
5. Combine Add and Exit rows.
6. Validate that Weight exists and is numeric.
7. Sort by Action and Weight descending.

Example transformation (textual):
- Input: Previous snapshot contains IDs A and B; Latest snapshot contains IDs B and C.
- Output: Add row for C; Exit row for A.

Edge cases:
- Empty snapshots produce empty Add/Exit frames.
- Sorting preserves largest weight at the top within each Action group.
- Book filtering ensures MBS/TBA and Standard securities are evaluated separately unless All is selected.

**Section sources**
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:704-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L704-L729)
- [test_engine.py:264-329](file://User scripts/FI Index Change/tests/test_engine.py#L264-L329)

### Summary Data: Aggregated Statistics
Summary data aggregates metrics by a chosen dimension such as Country, Sector, Tenor Bucket, Rating Bucket, or Currency.

For each dimension value, the summary includes:
- Count metrics: Begin Count, End Count, +/- Count, Add Count, Exit Count.
- Weight metrics: Begin Weight, End Weight, +/- Weight, Add Weight, Exit Weight.
- Turnover metrics: Turnover (index %), Turnover Rate (%).
- Spread metrics: Begin OAS, End OAS, +/- OAS; same pattern for Z-Spread and I-Spread.
- Duration metrics: Begin/End/+/- for Duration, Modified Duration, Effective Duration, OASD.
- Yield metrics: Begin/End/+/- for Yield, YTM, YTW.
- Tenor metrics: Begin Tenor, End Tenor, +/- Tenor.

Headline metrics include:
- Overall status and message.
- Aggregated metrics for previous, latest, added, and exited sets.
- Total turnover and turnover rate.
- Whether index-MV ratio was used (`official`) or approximated (`approx`).

Example shape (textual):
- Header row: `Country,Begin Count,End Count,+/- Count,Begin Weight,End Weight,+/- Weight,Turnover (index %),Turnover Rate (%),Begin OAS,End OAS,+/- OAS,...,Begin Tenor,End Tenor,+/- Tenor,Add Count,Exit Count,Add Weight,Exit Weight`
- Sample row: `United States,1,1,0,10.0,30.0,20.0,20.0,200.0,100.0,120.0,110.0,-10.0,...,4.20,4.10,-0.10,1,1,20.0,10.0`

Validation and robustness:
- Unavailable transitions return an empty table with status and message.
- OAS excludes sentinel values above a configured threshold when computing weighted means.
- Turnover uses the index-MV ratio when available; otherwise it falls back to approximate turnover.

**Section sources**
- [engine.py:855-882](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L882)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)
- [test_engine.py:435-601](file://User scripts/FI Index Change/tests/test_engine.py#L435-L601)

### Data Validation and Integrity During Export
Several layers validate and normalize data before export:

Snapshot preparation:
- Blank or invalid IDs are dropped.
- Duplicate IDs are collapsed, keeping the last non-null value per column.
- Weight is coerced to numeric; fractions are scaled to percent points when the net sum indicates a fraction basis.
- Text fields are standardized, including country name overrides and Excel PROPER-style formatting.
- Book classification is assigned based on security type and ID patterns.
- MBS/TBA and Municipal bonds receive special handling for Country, Sector, Currency, and Rating.
- Tenor Bucket is computed from Tenor, with Missing and N.A. semantics.
- Rating Bucket is classified as IG, HY, or NR.

Label alignment:
- Classification labels across snapshots are aligned per ID so comparisons remain consistent.
- Latest usable values win; missing values fall back to previous values.
- Rating Bucket and Rating text are aligned together to avoid mismatched classifications.

Export-specific checks:
- Change export requires Weight and Action.
- Display export converts dates and numbers to safe text.
- Grid export avoids hidden helper columns and NaT timestamps.

Cache and request validation:
- Responses are parsed carefully, noting missing items, empty columns, and duplicate duration measures.
- Historical snapshots are refused if required identity columns are absent or entirely blank.
- Timeout retries are limited to actual timeouts, not deterministic failures.

**Section sources**
- [engine.py:353-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:732-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L732-L781)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:701-800](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L800)

## Dependency Analysis
The export pipeline depends on frozen field contracts and configuration defaults.

```mermaid
graph LR
FieldLibrary["field_library.py<br/>SPREAD_FIELDS, DURATION_FIELDS, YIELD_FIELDS, ITEM_NAMES"] --> Engine["engine.py<br/>EXPORT_COLUMNS, prepare_members, summarize"]
Config["config.py<br/>WEIGHT_FRACTION_SUM_MAX, OAS_EXCLUDE_AT_OR_ABOVE"] --> Engine
Data["data.py<br/>_parse_response, _finalize_snapshot"] --> Engine
App["app.py<br/>BOND_COLUMNS, POSITION_COLUMNS, export UI"] --> Engine
```

**Diagram sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [engine.py:676-701](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L701)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [app.py:73-102](file://User scripts/FI Index Change/fi_index_change/app.py#L73-L102)

**Section sources**
- [field_library.py:18-75](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L75)
- [engine.py:676-701](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L701)
- [config.py:116-120](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L120)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [app.py:73-102](file://User scripts/FI Index Change/fi_index_change/app.py#L73-L102)

## Performance Considerations
- Export frames are prepared in memory and intended for copy/paste rather than file I/O.
- Weight formatting avoids rounding to preserve small slices.
- Summary aggregation computes weighted means efficiently and excludes invalid OAS values.
- Splitting BQL requests reduces timeout risk, improving the reliability of snapshots that feed exports.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their signals:
- No comparison loaded: Indicates either no Update has run or the update failed.
- Membership license failure: The Bloomberg login lacks entitlement for the index.
- Partial snapshots: One or more required items did not parse; dimensions may be blank or classified NR.
- Missing Weight: Snapshot rejected because Weight is absent or entirely null.
- Empty identity columns: Columns arrived but every value is blank; the month is marked partial and not cached.
- Duplicate duration measures: Multiple duration builders returned identical values, suggesting one builder may ignore its parameter.

Recommended actions:
- Verify the index ticker ends with ` Index`.
- Confirm the selected month-end is in the allowed dropdown.
- Check the log for item parsing notes and missing fields.
- Retry after a timeout; deterministic errors will not improve on retry.
- Inspect the Export tab instructions and ensure the whole table is copied so the repeated header is preserved.

**Section sources**
- [engine.py:104-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L104-L128)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [app.py:740-773](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L773)

## Conclusion
The FI Index Change module provides two primary export surfaces:
- A CSV-compatible change table listing Add and Exit transitions with full identity, classification, weighting, analytics, and metadata.
- An Excel-compatible display format that repeats headers so copied tables retain column names.

Behind these outputs, the system normalizes snapshots, aligns classification labels, validates critical fields, and computes robust summary statistics. The design emphasizes clarity, reproducibility, and resilience against incomplete or malformed data, while keeping the user workflow simple: select the comparison, choose Changes or Summary, copy the table, and paste it into Excel.

[No sources needed since this section summarizes without analyzing specific files]