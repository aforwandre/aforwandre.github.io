# Report Templates and Layouts

<cite>
**Referenced Files in This Document**   
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [field_library.py](file://User scripts/FI Index Change/fi_index_change/field_library.py)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the report templates and layout customization options implemented by the FI index change module. It focuses on:
- The change summary template that displays add and exit transitions, weight calculations, and turnover metrics.
- The audit trail template that provides chronological tracking of index composition changes through snapshots and export tables.
- The compliance documentation template that includes regulatory reporting fields and validation checks surfaced in logs, status lines, and footnotes.
- Layout customization options including column selection, field ordering, and filtering criteria.
- Examples of generated reports under different template configurations.
- Guidance for extending existing templates to meet specific business requirements.

The module is an update-only dashboard that compares two month-end snapshots of a fixed-income index, computes membership differences, summarizes weighted analytics, and exposes copyable output tables for downstream reporting.

## Project Structure
The FI index change implementation is organized into five core modules:
- `app.py`: UI controller, widget construction, rendering, and user-facing report panels.
- `engine.py`: Business logic for comparisons, summaries, exports, chart rows, and formatting.
- `data.py`: BQL request orchestration, response parsing, caching, and payload assembly.
- `config.py`: Display, layout, and runtime constants.
- `field_library.py`: Frozen data item definitions and request groups.

```mermaid
graph TB
App["app.py<br/>UI controller and report panels"] --> Engine["engine.py<br/>Comparison, summary, export, charts"]
App --> Data["data.py<br/>BQL requests, parsing, cache"]
Engine --> FieldLibrary["field_library.py<br/>Frozen items and groups"]
Engine --> Config["config.py<br/>Layout and runtime constants"]
Data --> FieldLibrary
Data --> Config
```

**Diagram sources**
- [app.py:307-660](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L660)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [field_library.py:58-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L121)
- [config.py:12-122](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L122)

**Section sources**
- [app.py:307-660](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L660)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [field_library.py:58-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L121)
- [config.py:12-122](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L122)

## Core Components
The report system is built around three primary outputs:
- Change Summary Template: A bucketed view showing Begin/End counts and weights, plus Add/Exit contributions, turnover, and selected spread/duration/yield measures.
- Audit Trail Template: Chronological snapshots with AS_OF_DATE, full constituent lists, and change rows carrying Action, ID, Name, Weight, and classification fields.
- Compliance Documentation Template: Status lines, warnings, footnotes, and log notes that capture license failures, partial responses, missing or empty identity columns, and turnover basis.

Key responsibilities:
- `app.py` builds widgets, renders Main/Export/Full Position tabs, and formats headline text and detail panels.
- `engine.py` computes transitions, summaries, export frames, grid display frames, signed chart values, and caption footnotes.
- `data.py` fetches historical and projected snapshots, parses BQL responses, applies retries, and assembles an `IndexPayload`.
- `config.py` defines default index/book, filter widths, chart sizing, row caps, split-request behavior, and retry attempts.
- `field_library.py` defines the frozen set of requested items and analytics groups.

**Section sources**
- [app.py:307-660](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L660)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [config.py:12-122](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L122)
- [field_library.py:58-121](file://User scripts/FI Index Change/fi_index_change/field_library.py#L58-L121)

## Architecture Overview
The end-to-end flow from Update to rendered report is:

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "FIIndexChangeApp"
participant Data as "data.fetch_index_payload"
participant Cache as "cache.load_historical/save_historical"
participant BQL as "BQL service"
participant Engine as "engine.build_transition/summarize"
participant View as "Main/Export/Full Position"
User->>App : Click Update
App->>Data : fetch_index_payload(index_ticker, selected_date)
Data->>Cache : load_historical(previous_date)
alt Historical hit
Cache-->>Data : cached frame
else No hit
Data->>BQL : execute members(request)
BQL-->>Data : response
Data->>Data : parse_response/_fetch_live
Data->>Cache : save_historical(historical)
end
Data->>Data : fetch selected/projected snapshot
Data-->>App : IndexPayload(snapshots, statuses, errors, notes)
App->>Engine : build_transition(snapshots, comparison, statuses, index_mv_ratio)
Engine-->>App : Transition(status, previous, latest, warnings)
App->>Engine : summarize(transition, dimension, book, filters)
Engine-->>App : summary DataFrame + headline
App->>View : render Main tab (headline, chart, bucket summary)
App->>View : refresh Export/Full Position tables
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [engine.py:784-840](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L840)
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)

## Detailed Component Analysis

### Change Summary Template
The change summary template is the central report view. It shows:
- Dimension key (Country, Sector, Tenor Bucket, Rating Bucket, Currency).
- Begin Count / End Count / +/- Count.
- Begin Weight / End Weight / +/- Weight.
- Turnover (index %) and Turnover Rate (%).
- Selected spread blocks: Begin/End/+/- OAS, Z-Spread, I-Spread.
- Selected duration blocks: Begin/End/+/- Duration, Modified Duration, Effective Duration, OASD.
- Selected yield blocks: Begin/End/+/- Yield, YTM, YTW.
- Add Count / Exit Count / Add Weight / Exit Weight.

Weight handling:
- Weights are normalized to percent points when the net or absolute sum indicates a fraction-based input.
- OAS values at or above 9000 are excluded from weighted averages.
- Null and non-positive weights are skipped in weighted means.

Turnover calculation:
- Official basis uses ending/beginning index market value ratio when available.
- Approximate basis fixes the ratio at 1.0 and labels results as `(approx)`.

Column ordering and visibility:
- `_summary_columns` orders the visible columns based on current spreads, durations, and yields selections.
- The first column is always the dimension key; other blocks follow a fixed order.

```mermaid
flowchart TD
Start(["Summarize Entry"]) --> CheckStatus{"Transition status ok?"}
CheckStatus --> |No| ReturnEmpty["Return empty summary with status/message"]
CheckStatus --> |Yes| Diff["diff_members(previous, latest, book)"]
Diff --> FilterPrevious["apply_dimension_filters(previous)"]
FilterPrevious --> FilterLatest["apply_dimension_filters(latest)"]
FilterLatest --> FilterAdded["apply_dimension_filters(added)"]
FilterAdded --> FilterExited["apply_dimension_filters(exited)"]
FilterExited --> Keys["Collect dimension keys across frames"]
Keys --> LoopKeys["For each key: slice frames"]
LoopKeys --> Metrics["_side_metrics(before, after, added, exited)"]
Metrics --> Turnover["bucket_turnover = Exit Weight + Add Weight * effective_ratio"]
Turnover --> Row["Build row: counts, weights, turnover, rate, spreads, durations, yields, tenor, add/exit"]
Row --> Sort["Sort by Add Weight + Exit Weight"]
Sort --> Headline["Compute headline metrics and turnover basis"]
Headline --> End(["Return summary DataFrame and headline"])
```

**Diagram sources**
- [engine.py:885-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L885-L977)
- [engine.py:855-882](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L882)
- [engine.py:643-662](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L662)
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)

**Section sources**
- [engine.py:855-977](file://User scripts/FI Index Change/fi_index_change/engine.py#L855-L977)
- [app.py:961-986](file://User scripts/FI Index Change/fi_index_change/app.py#L961-L986)
- [config.py:116-121](file://User scripts/FI Index Change/fi_index_change/config.py#L116-L121)

### Audit Trail Template
The audit trail template is provided by:
- Snapshot frames with `AS_OF_DATE` and `SNAPSHOT_KIND`, used to track chronological composition.
- Full Position tab listing every constituent at Start date or End date.
- Changes export table listing every Add and Exit with Action, ID, Name, Weight, and classification fields.

Chronology and identity:
- Each snapshot carries `AS_OF_DATE` and `SNAPSHOT_KIND` (`historical` or `projected`).
- Full Position tables use `POSITION_COLUMNS` and include `AS_OF_DATE` to identify the month-end.
- Changes export uses `EXPORT_COLUMNS` and sorts by Action then Weight.

Copy-to-Excel behavior:
- `export_display_frame` repeats column names as the first data row so copying from the grid preserves headers.
- Dates are formatted as ISO strings; numeric cells are rounded or formatted without trailing zeros.

```mermaid
classDiagram
class IndexPayload {
+string index_ticker
+string previous_date
+string selected_date
+string kind
+dict snapshots
+dict statuses
+list errors
+list notes
+float index_mv_ratio
+string turnover_basis
}
class Transition {
+string label
+string previous_date
+string latest_date
+string kind
+string status
+string message
+DataFrame previous
+DataFrame latest
+float index_mv_ratio
+string turnover_basis
+tuple warnings
}
class EngineExports {
+EXPORT_COLUMNS
+change_export_frame()
+export_display_frame()
+grid_display_frame()
}
IndexPayload --> Transition : "build_transition"
Transition --> EngineExports : "change_export_frame"
```

**Diagram sources**
- [data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [engine.py:66-97](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L97)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)

**Section sources**
- [data.py:701-710](file://User scripts/FI Index Change/fi_index_change/data.py#L701-L710)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [app.py:171-203](file://User scripts/FI Index Change/fi_index_change/app.py#L171-L203)

### Compliance Documentation Template
Compliance documentation is not a separate file but is embedded in:
- Status lines indicating phase, environment activity, and error conditions.
- Headline info boxes showing unavailable comparisons, warnings about partial snapshots, and scope details.
- Caption footnotes explaining as-of weight dates, rating bucket definitions, and turnover formula.
- Log notes capturing missing items, empty identity columns, duplicate IDs, and timeout retries.

Validation checks:
- `membership_access_failure` detects entitlement/license errors.
- `rating_class_conflicts` verifies consistent rating classification across snapshots.
- `column_has_usable_value` ensures identity columns carry real values before marking a month usable.
- `_missing_items` and `_returned_shape` distinguish missing parsed items from blank columns.

Regulatory reporting fields:
- Identity fields: ID, Name, Issuer, ISIN, SEDOL, Country, Sector, Currency, Security Type.
- Classification fields: Tenor Bucket, Rating Bucket, Book.
- Analytics fields: Weight, Coupon, OAS, Z-Spread, I-Spread, Duration, Modified Duration, Effective Duration, OASD, Yield, YTM, YTW.
- Metadata fields: Maturity, AS_OF_DATE, SNAPSHOT_KIND.

```mermaid
flowchart TD
Start(["Update Response"]) --> Parse["_parse_response"]
Parse --> MissingItems{"Missing items?"}
MissingItems --> |Yes| NoteMissing["Log missing items and returned shapes"]
MissingItems --> |No| EmptyIdentity{"Empty identity columns?"}
EmptyIdentity --> |Yes| PartialStatus["Mark snapshot partial and refuse cache"]
EmptyIdentity --> |No| DurationCheck{"Duration duplicates?"}
DurationCheck --> |Yes| NoteDuplicates["Log identical duration columns"]
DurationCheck --> |No| Ready["Frame ready for prepare_members"]
NoteMissing --> Ready
PartialStatus --> Ready
NoteDuplicates --> Ready
```

**Diagram sources**
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [engine.py:607-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L607-L630)
- [engine.py:481-494](file://User scripts/FI Index Change/fi_index_change/engine.py#L481-L494)

**Section sources**
- [app.py:740-773](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L773)
- [engine.py:104-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L104-L128)
- [engine.py:607-630](file://User scripts/FI Index Change/fi_index_change/engine.py#L607-L630)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

### Layout Customization Options
The app supports extensive layout customization through configuration and widget state:

Column selection:
- Spread, Duration, and Yield selectors allow selecting one or more measure blocks.
- `_current_spreads`, `_current_durations`, and `_current_yields` derive active blocks from widget values.
- `_detail_list_columns` inserts selected analytics blocks after Weight in the detail list.

Field ordering:
- `_summary_columns` enforces a stable order: dimension key, counts, weights, turnover, selected spreads, selected durations, selected yields, tenor deltas, add/exit counts and weights.
- `DETAIL_FIELDS` and `POSITION_COLUMNS` define ordered views for bond detail and full position tables.

Filtering criteria:
- Dimension filters: Country, Sector, Tenor, Rating, Currency.
- Book filter: All, Standard, MBS/TBA.
- Filters apply to displayed buckets and detail lists; they do not alter exported data.
- `_current_filters` converts widget selections into a dictionary passed to `apply_dimension_filters`.

Display constraints:
- `DISPLAY_ROW_CAP` limits grid rows to avoid excessive rendering.
- Chart width is capped at 80% of a 1,920 px viewport.
- First column pinning and row-header gutter widths are configurable.

```mermaid
flowchart TD
Widgets["Widget Selections"] --> CurrentSpreads["_current_spreads()"]
Widgets --> CurrentDurations["_current_durations()"]
Widgets --> CurrentYields["_current_yields()"]
Widgets --> CurrentFilters["_current_filters()"]
CurrentSpreads --> SummaryColumns["_summary_columns()"]
CurrentDurations --> SummaryColumns
CurrentYields --> SummaryColumns
CurrentFilters --> ApplyFilters["apply_dimension_filters()"]
SummaryColumns --> RenderGrid["Render Main/Export grids"]
ApplyFilters --> DetailList["Detail list and charts"]
```

**Diagram sources**
- [app.py:926-959](file://User scripts/FI Index Change/fi_index_change/app.py#L926-L959)
- [app.py:961-998](file://User scripts/FI Index Change/fi_index_change/app.py#L961-L998)
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)
- [config.py:49-83](file://User scripts/FI Index Change/fi_index_change/config.py#L49-L83)

**Section sources**
- [app.py:926-998](file://User scripts/FI Index Change/fi_index_change/app.py#L926-L998)
- [engine.py:843-852](file://User scripts/FI Index Change/fi_index_change/engine.py#L843-L852)
- [config.py:49-83](file://User scripts/FI Index Change/fi_index_change/config.py#L49-L83)

### Examples of Generated Reports
Below are conceptual examples of how different template configurations appear. These describe structure rather than reproduce content.

- Change Summary with all spreads, durations, and yields:
  - Columns include Begin/End/+/- for OAS, Z-Spread, I-Spread, Duration, Modified Duration, Effective Duration, OASD, Yield, YTM, YTW, plus Tenor deltas and Add/Exit counts and weights.
  - Turnover (index %) and Turnover Rate (%) are shown; if no index-MV ratio is available, results are labeled `(approx)`.

- Change Summary filtered to IG only:
  - Only bonds classified IG appear in the bucket summary and charts.
  - Headline shows `(filtered)` and scope line indicates Rating: IG.

- Export Changes with Standard book:
  - Rows contain Action, ID, Name, Issuer, ISIN, SEDOL, Country, Sector, Weight, Tenor Bucket, Tenor, Rating, Rating Bucket, Currency, Coupon, OAS, Z-Spread, I-Spread, Duration, Modified Duration, Effective Duration, OASD, Yield, YTM, YTW, Maturity, Book, Security Type, AS_OF_DATE.
  - Sorted by Action then Weight.

- Full Position End date:
  - Lists every constituent at the selected month-end, including Standard and MBS/TBA.
  - Same columns as CSV export minus Action; AS_OF_DATE identifies the month-end.

These examples align with the column definitions and export functions in the codebase.

**Section sources**
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [app.py:171-203](file://User scripts/FI Index Change/fi_index_change/app.py#L171-L203)
- [app.py:1398-1494](file://User scripts/FI Index Change/fi_index_change/app.py#L1398-L1494)

### Extending Existing Templates
To extend templates for specific business requirements:

- Add new analytics fields:
  - Extend `SPREAD_FIELDS`, `DURATION_FIELDS`, or `YIELD_FIELDS` in `field_library.py`.
  - Add corresponding builders in `_ITEM_CALLS`.
  - Update `ANALYTICS_NAMES` and `ANALYTICS_GROUPS` if splitting requests.
  - Ensure `NUMERIC_COLUMNS` includes the new field.

- Add new identity fields:
  - Add to `ITEM_NAMES` and `_ITEM_CALLS`.
  - Include in `STRING_COLUMNS` if textual.
  - Update `EXPORT_COLUMNS`, `POSITION_COLUMNS`, and `DETAIL_FIELDS` where needed.

- Customize layout:
  - Modify `_summary_columns` to reorder or insert new blocks.
  - Adjust `_detail_list_columns` to place new analytics fields in the detail list.
  - Update `FILTER_COLUMNS` and `FILTER_LABELS` to expose new dimension filters.

- Customize compliance checks:
  - Extend `rating_bucket` or add new classification rules in `engine.py`.
  - Add validation messages in `data.py` parsing or `engine.py` alignment.
  - Surface warnings via `Transition.warnings` and headline info boxes.

- Customize export format:
  - Extend `EXPORT_COLUMNS` and `PERCENT_COLUMNS`.
  - Modify `_export_cell` for custom number/date formatting.
  - Add new tabs or dropdown options in `app.py` for additional report views.

**Section sources**
- [field_library.py:18-126](file://User scripts/FI Index Change/fi_index_change/field_library.py#L18-L126)
- [field_library.py:147-216](file://User scripts/FI Index Change/fi_index_change/field_library.py#L147-L216)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [engine.py:676-781](file://User scripts/FI Index Change/fi_index_change/engine.py#L676-L781)
- [app.py:961-998](file://User scripts/FI Index Change/fi_index_change/app.py#L961-L998)

## Dependency Analysis
The module exhibits clear separation between UI, business logic, data access, and configuration:

- `app.py` depends on `engine` for computation and `data` for payload retrieval.
- `engine.py` depends on `field_library` for item definitions and `config` for constants.
- `data.py` depends on `engine` for normalization and alignment, and on `field_library` for item building.
- `config.py` is consumed by both `app.py` and `engine.py` for layout and runtime behavior.
- `field_library.py` is the single source of truth for BQL items and request groups.

```mermaid
graph LR
App["app.py"] --> Engine["engine.py"]
App --> Data["data.py"]
Engine --> FieldLibrary["field_library.py"]
Engine --> Config["config.py"]
Data --> Engine
Data --> FieldLibrary
Data --> Config
```

**Diagram sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)

**Section sources**
- [app.py:11-49](file://User scripts/FI Index Change/fi_index_change/app.py#L11-L49)
- [engine.py:14-28](file://User scripts/FI Index Change/fi_index_change/engine.py#L14-L28)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)

## Performance Considerations
- Split requests reduce per-query width by separating identity items from analytics families.
- Timeout retries are limited to two attempts and only for timeout errors.
- Caching avoids re-fetching historical snapshots when the field contract matches.
- Grid row caps prevent excessive rendering for large indices.
- Chart widths are constrained to maintain readability on wide filter rows.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their indicators:

- License or entitlement failure:
  - Status line shows membership/license error.
  - Headline info box states no data access license.
  - `membership_access_failure` detects keywords like entitlement, permission, license, unauthorized.

- Partial snapshot:
  - Status marked `partial` when required items did not parse or identity columns arrived empty.
  - Notes explain which items are missing or empty.
  - Cache refuses partial frames to force re-request.

- Timeout:
  - Errors mention BQLTimeoutError or query timed out.
  - Logs show attempt timing and retry behavior.
  - Only timeouts are retried; deterministic failures are not.

- Duplicate or blank IDs:
  - Notes report dropped blank IDs and duplicate IDs kept last non-null.
  - Merge uses ID alone; DATE is not part of identity.

- Duration measure duplication:
  - Notes indicate identical values across duration columns, suggesting builder parameter ignored.

**Section sources**
- [app.py:740-773](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L773)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:529-595](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L595)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)

## Conclusion
The FI index change module provides a robust, configurable reporting framework for fixed-income index composition changes. Its templates cover change summaries with weighted analytics and turnover, audit trails through chronological snapshots and export tables, and compliance documentation via status lines, warnings, and validation checks. Layout customization allows precise control over column selection, field ordering, and filtering. Extensions can be made by updating frozen item definitions, engine computations, and app rendering logic while preserving the separation of concerns between UI, business logic, data access, and configuration.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Key Configuration Constants
- Default index and book: `DEFAULT_INDEX`, `DEFAULT_BOOK`.
- Filter widths and gaps: `FILTER_WIDTHS`, `FILTER_GAP_PX`, `FILTER_ROW_WIDTH_PX`.
- Chart sizing: `SCREEN_WIDTH_PX`, `CHART_MAX_SCREEN_RATIO`, `CHART_WIDTH_PX`.
- Row cap and pinning: `DISPLAY_ROW_ROW_CAP`, `PIN_FIRST_COLUMN`, `PIN_DETAIL_COLUMN`.
- Request behavior: `SPLIT_REQUESTS`, `QUERY_ATTEMPTS`.
- Weight scaling and OAS exclusion: `WEIGHT_FRACTION_SUM_MAX`, `OAS_EXCLUDE_AT_OR_ABOVE`.

**Section sources**
- [config.py:12-122](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L122)

### RAG Authority Notes
- Membership request shape, weekend month-end rule, MBS/TBA mask, and duration/yield provenance are documented in the RAG authority card.
- These rules govern how snapshots are fetched, parsed, and aligned before reporting.

**Section sources**
- [28-fi-index-change.md:78-154](file://RAG KB/28-fi-index-change.md#L78-L154)
- [28-fi-index-change.md:389-430](file://RAG KB/28-fi-index-change.md#L389-L430)
- [28-fi-index-change.md:509-540](file://RAG KB/28-fi-index-change.md#L509-L540)