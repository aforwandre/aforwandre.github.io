# Automation and Integration Workflows

<cite>
**Referenced Files in This Document**
- [17-scheduling.md](file://RAG KB/17-scheduling.md)
- [05-get-started.md](file://RAG KB/05-get-started.md)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [config.py](file://User scripts/FI Index Change/fi_index_change/config.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [app.py](file://User scripts/MDX Scan/mdx_scan/app.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the BQuant Desktop applications in this repository generate reports, export data, and integrate with external systems under the constraints of a Desktop-only environment. The key design principle is that all live Bloomberg queries run only after an explicit user action inside BQuant Desktop; there is no built-in cron or enterprise scheduler available for this project.

The most important automation boundary is:
- Manual trigger: A user clicks Update, Refresh, or Run All.
- Programmatic trigger: Notebook code calls the same update functions that the UI uses.
- External scheduling: Not available on BQuant Desktop; recurring schedules are Enterprise-only.

The repository provides strong patterns for idempotent report generation, local caching, copy-to-Excel exports, timeout handling, retry behavior, and clear status logging. These patterns can be reused to build automated workflows such as daily index change monitoring, weekly compliance reporting, and monthly audit generation, while respecting platform limits.

## Project Structure
The relevant automation surface lives under `User scripts`, where each monitoring app follows a similar shape:
- An application controller (`app.py`) that owns widgets, state, and the update handler.
- A computation engine (`engine.py` or equivalent) that transforms snapshots into comparisons, rankings, and display frames.
- Configuration constants (`config.py`) that control defaults, request splitting, retries, and display rules.
- Data access modules (`data.py`) that call BQL and normalize responses.
- Local cache helpers (`cache.py`) that persist results to avoid repeated expensive requests.

```mermaid
graph TB
subgraph "FI Index Change"
FI_App["fi_index_change/app.py"]
FI_Engine["fi_index_change/engine.py"]
FI_Config["fi_index_change/config.py"]
FI_Data["fi_index_change/data.py"]
FI_Cache["fi_index_change/cache.py"]
end
subgraph "ETF Capping Monitoring"
ETF_App["etf_capping/app.py"]
end
subgraph "ETF Spread Monitoring"
ES_App["etf_spread/app.py"]
ES_Cache["etf_spread/cache.py"]
end
subgraph "FI Spread Movement Monitoring"
FSM_App["fi_spread_movement/app.py"]
FSM_Data["fi_spread_movement/data.py"]
end
subgraph "MDX Scan"
MDX_App["mdx_scan/app.py"]
end
FI_App --> FI_Engine
FI_App --> FI_Data
FI_App --> FI_Config
FI_App --> FI_Cache
ES_App --> ES_Cache
FSM_App --> FSM_Data
MDX_App --> MDX_App
```

**Diagram sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [engine.py:66-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L119)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [cache.py:219-219](file://User scripts/FI Index Change/fi_index_change/cache.py#L219-L219)
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [cache.py:560-560](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L560-L560)
- [app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)
- [data.py:1544-1544](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1544-L1544)
- [app.py:89-101](file://User scripts/MDX Scan/mdx_scan/app.py#L89-L101)

**Section sources**
- [05-get-started.md:23-86](file://RAG KB/05-get-started.md#L23-L86)
- [17-scheduling.md:15-31](file://RAG KB/17-scheduling.md#L15-L31)

## Core Components
The core automation components are consistent across apps:

| Component | Responsibility | Automation Relevance |
|---|---|---|
| Application controller | Builds UI, binds events, runs updates, renders results | Entry point for manual and programmatic triggers |
| Engine | Computes comparisons, diffs, rankings, and export frames | Business logic for report generation |
| Config | Defaults, month-end selection, request splitting, retry budget | Controls performance and reliability |
| Data layer | Calls BQL, normalizes payloads, handles entitlements | Source of live data |
| Cache | Persists historical or settled results locally | Enables fast reloads and fallbacks |
| Export helpers | Build copy-to-Excel frames or CSV files | Output integration without external APIs |

Key automation behaviors observed in the codebase:
- Live BQL runs only after an explicit button click or notebook call.
- Exports are designed for copy-to-Excel or local CSV, not direct email or database insertion.
- Timeouts are detected and retried only when appropriate.
- Status lines distinguish idle, processing, updated, cached, refused, and error states.
- Logs capture request metadata, errors, and diagnostic notes.

**Section sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [engine.py:66-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L119)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)
- [app.py:89-101](file://User scripts/MDX Scan/mdx_scan/app.py#L89-L101)

## Architecture Overview
The automation architecture is event-driven within the Jupyter kernel rather than externally scheduled.

```mermaid
sequenceDiagram
participant User as "BQuant Desktop User"
participant App as "Application Controller"
participant Data as "Data Layer"
participant Engine as "Engine"
participant Cache as "Local Cache"
participant Excel as "Copy-to-Excel / CSV"
User->>App : Click Update or Refresh
App->>Cache : Load saved run if requested
Cache-->>App : Cached result or miss
App->>Data : Fetch index, positions, spreads, or scan payload
Data-->>App : Normalized payload with errors and notes
App->>Engine : Build comparison, transition, or ranked movers
Engine-->>App : Frames, summaries, warnings
App->>Excel : Build export frame or write CSV
Excel-->>App : Ready for paste or file output
App-->>User : Updated status, charts, tables, logs
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)
- [cache.py:219-219](file://User scripts/FI Index Change/fi_index_change/cache.py#L219-L219)
- [app.py:988-988](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L988-L988)
- [app.py:1166-1166](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1166-L1166)

## Detailed Component Analysis

### FI Index Change: Monthly Membership Diff and Export
The FI Index Change app is the clearest example of a monthly report workflow:
- The operator selects an index and a month-end.
- The app fetches two snapshots: previous month-end and selected month-end.
- The engine computes adds and exits by ID difference.
- The app builds dimension charts, bucket summaries, detail rows, and export frames.
- Exports are copy-to-Excel frames with repeated headers, not direct file writes from the main dashboard.

```mermaid
flowchart TD
Start(["Update clicked"]) --> Validate["Validate index ticker<br/>and month-end"]
Validate --> Fetch["Fetch index payload<br/>and snapshots"]
Fetch --> Normalize["Normalize snapshots<br/>and classify members"]
Normalize --> Compare["Build comparison<br/>and transition"]
Compare --> Filter["Apply book and dimension filters"]
Filter --> Charts["Build dimension chart<br/>and bucket summary"]
Charts --> Export["Build export frame<br/>for changes or summary"]
Export --> Done(["Updated status<br/>with dates and kind"])
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:196-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L196-L251)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:643-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L729)

**Section sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [engine.py:66-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L119)
- [engine.py:196-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L196-L251)
- [engine.py:643-729](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L729)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)

### ETF Capping Monitoring: Position-Based Compliance Checks
The ETF Capping Monitoring app focuses on fund-level capping limits, account aggregation, and alert statuses. It integrates AIM position inputs, reference data, approved USD pricing, and company aggregation before applying dynamic capping thresholds.

Automation-relevant points:
- BQL runs only after Update.
- CSV export writes to project Files.
- Status distinguishes Breach, Near Limit, OK, and Data Issue.
- Diagnostics capture request, mapping, reference, price, and calculation issues.

```mermaid
flowchart LR
AIM["AIM positions<br/>Current or Projected"] --> Reference["Reference data<br/>names and market status"]
Reference --> Pricing["Approved USD pricing<br/>including cash FX"]
Pricing --> Valuation["Position valuation<br/>quantity × USD price"]
Valuation --> Aggregation["Company aggregation<br/>and weights"]
Aggregation --> Capping["Rank + dynamic limit<br/>Breach / Near / OK"]
Capping --> Output["Monitor alerts<br/>Full positions<br/>Diagnostics"]
```

**Diagram sources**
- [app.py:323-406](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L323-L406)
- [app.py:531-603](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L531-L603)
- [app.py:667-685](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L667-L685)

**Section sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:323-685](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L323-L685)

### ETF Spread Monitoring: Book, Peers, and Flow Heatmap
The ETF Spread Monitoring app loads HSBC ETF data, peer histories, and flow heatmaps. It supports history ranges, cache usage, custom date windows, and multiple visualization tabs.

Automation-relevant points:
- Refresh loads book, peer history, and flows.
- Cache can serve settled history and request only missing days.
- CSV export is supported through the app’s export buttons.
- Status and settings text help operators understand what was loaded.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "ETFSpreadMonitor"
participant Cache as "Local Cache"
participant Data as "Parallel History and Peer Data"
participant View as "Book and Flow Views"
User->>App : Click Refresh
App->>Cache : Use cache option
Cache-->>App : Cached or partial data
App->>Data : Fetch parallel histories, peers, flows
Data-->>App : Source results with notes
App->>View : Build book, peer, and flow views
View-->>App : Tables, charts, heatmap
App-->>User : Refreshed status and outputs
```

**Diagram sources**
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [cache.py:560-560](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L560-L560)

**Section sources**
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [cache.py:560-560](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L560-L560)

### FI Spread Movement Monitoring: Ranked Movers and Fallbacks
The FI Spread Movement Monitoring app ranks spread movers, validates arithmetic, and supports both single-universe and comparison modes. It includes detailed stage logging, field-level failure detection, and a “Load saved” fallback.

Automation-relevant points:
- Update stages are named: request, prepare, check, render.
- Timeout-only failures are treated specially for fallback behavior.
- Failed fields are surfaced without hiding behind a green Updated state.
- Export Excel tab includes per-field request metadata.

```mermaid
flowchart TD
Start(["Update clicked"]) --> Request["Request universe and series"]
Request --> Prepare["Prepare ranked movers"]
Prepare --> Check["Check change arithmetic"]
Check --> Render["Render tables and charts"]
Render --> Status{"Only timeouts failed?"}
Status --> |Yes| Fallback["Offer saved cache load"]
Status --> |No| Error["Show refusal or error"]
Fallback --> Saved["Load saved run"]
Saved --> Done(["Cached or Updated status"])
Error --> Done
```

**Diagram sources**
- [app.py:81-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L81-L86)
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)

**Section sources**
- [app.py:81-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L81-L86)
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)
- [data.py:1544-1544](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1544-L1544)

### MDX Scan: Daily Event-Driven Scan Loop
The MDX Scan app demonstrates an internal event-driven loop using ipywidgets Play and interval controls. It refreshes BQL data at a configurable interval while the user leaves the notebook open.

Automation-relevant points:
- Auto-play drives periodic refreshes inside the running kernel.
- Refresh pulls live HSI members and OHLCV data.
- Errors and request notes are logged.
- This pattern is useful for near-real-time dashboards but is not a system-wide scheduler.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "MDXScanApp"
participant Data as "Scan Payload"
participant Engine as "Universe Computation"
User->>App : Set interval and start auto-play
App->>App : On auto tick
App->>Data : Fetch scan payload
Data-->>App : OHLCV, members, errors
App->>Engine : Compute universe and snapshot
Engine-->>App : Bars and latest signal snapshot
App-->>User : Live status, grid, and chart
```

**Diagram sources**
- [app.py:124-146](file://User scripts/MDX Scan/mdx_scan/app.py#L124-L146)
- [app.py:378-388](file://User scripts/MDX Scan/mdx_scan/app.py#L378-L388)
- [app.py:412-447](file://User scripts/MDX Scan/mdx_scan/app.py#L412-L447)
- [app.py:449-492](file://User scripts/MDX Scan/mdx_scan/app.py#L449-L492)

**Section sources**
- [app.py:89-101](file://User scripts/MDX Scan/mdx_scan/app.py#L89-L101)
- [app.py:124-146](file://User scripts/MDX Scan/mdx_scan/app.py#L124-L146)
- [app.py:378-492](file://User scripts/MDX Scan/mdx_scan/app.py#L378-L492)

## Dependency Analysis
The automation dependencies follow a layered model:

```mermaid
graph TB
UI["UI Controllers<br/>ipywidgets apps"] --> Logic["Engines<br/>comparisons, rankings, exports"]
UI --> Data["Data Layer<br/>BQL payloads"]
UI --> Config["Configuration<br/>defaults, retries, splits"]
UI --> Cache["Local Cache<br/>CSV persistence"]
Logic --> Config
Data --> Config
Cache --> UI
```

**Diagram sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [engine.py:66-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L119)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [cache.py:219-219](file://User scripts/FI Index Change/fi_index_change/cache.py#L219-L219)

Coupling and cohesion observations:
- UI controllers depend on engines for business logic, keeping computation separate from widget rendering.
- Engines depend on configuration constants for display, filtering, and request behavior.
- Data layers return normalized payloads so UI and engine logic remain stable across BQL response variations.
- Cache modules provide persistence without coupling the UI directly to file paths.

Potential circular dependencies are avoided by separating concerns:
- `app.py` imports `engine`, `data`, `config`, and sometimes `cache`.
- `engine.py` does not import `app.py`.
- `config.py` contains constants and helper mappings.
- `data.py` encapsulates BQL calls.
- `cache.py` persists frames.

**Section sources**
- [app.py:307-738](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L738)
- [engine.py:66-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L66-L119)
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [cache.py:219-219](file://User scripts/FI Index Change/fi_index_change/cache.py#L219-L219)

## Performance Considerations
The codebase implements several performance-oriented strategies suitable for automated workflows:

| Strategy | Implementation Pattern | Why It Matters |
|---|---|---|
| Request splitting | Split analytics groups to avoid oversized requests | Reduces timeout risk on large universes |
| Retry budget | Limited retry attempts for timeouts only | Avoids wasting upload windows on deterministic failures |
| Local cache | Persist historical or settled results | Enables fast reloads and fallbacks |
| Idempotent updates | Update handlers guard against re-entry | Prevents duplicate work during rapid triggers |
| Narrow universes | Prefer tight filters and bounded dates | Respects Desktop download limits |
| Copy-to-Excel frames | Header row repeated for clipboard paste | Avoids heavy file I/O in interactive dashboards |

Important platform constraints:
- BQuant Desktop has download limits and a 2-minute BQL timeout.
- Recurring schedules are not available on Desktop.
- Only BQL, Pandas, Plotly, and ipywidgets should be used.
- External internet APIs must not be called from notebooks or apps.

**Section sources**
- [config.py:85-122](file://User scripts/FI Index Change/fi_index_change/config.py#L85-L122)
- [05-get-started.md:130-143](file://RAG KB/05-get-started.md#L130-L143)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

## Troubleshooting Guide

### Scheduling and Automation Limits
- Recurring schedules, cron-like patterns, and `.py` scheduling are Enterprise-only.
- For this project, automation must rely on manual Run All, notebook-triggered updates, or internal kernel loops such as MDX Scan’s auto-play.
- Automated nightly or periodic jobs are not available on Desktop; keep notebook logic idempotent for manual execution.

**Section sources**
- [17-scheduling.md:15-31](file://RAG KB/17-scheduling.md#L15-L31)
- [05-get-started.md:99-143](file://RAG KB/05-get-started.md#L99-L143)

### Common Integration Issues

| Symptom | Likely Cause | Recommended Action |
|---|---|---|
| Green Updated screen but data looks stale | Cached run was loaded instead of fresh data | Verify phase label; use Load saved intentionally or refresh again |
| Timeout errors | Large universe, wide date range, or slow Bloomberg side | Narrow inputs, split requests, rely on retry budget, then retry |
| Refused or membership error | Missing entitlement or license issue | Check Terminal session, BBG ID, and index membership |
| Export table has no header | Clipboard paste without repeating header | Use the provided export frames that repeat column names |
| File save error | Project file exceeds 256 MB or temporary artifacts too large | Move generated output to `/tmp`, reduce artifact size |
| Kernel stuck or unresponsive | Competing sessions or workload timeout | Restart kernel/workload, avoid competing tabs |

### Retry and Fallback Strategies
- FI Index Change retries timed-out month-end requests up to a configured attempt count, but does not retry rejected items, missing entitlements, or bad universes.
- FI Spread Movement Monitoring detects whether only timeouts caused failures and offers a saved-cache fallback.
- ETF Spread Monitoring supports cache-enabled history retrieval and selective refresh of missing days.
- ETF Capping Monitoring writes CSV exports to project Files and records diagnostics for request and mapping issues.

**Section sources**
- [config.py:96-114](file://User scripts/FI Index Change/fi_index_change/config.py#L96-L114)
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [app.py:667-685](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L667-L685)

### Logging and Monitoring
Recommended monitoring practices based on the codebase:
- Watch the phase line: Idle, Loading, Updated, Cached, Refused, Error.
- Watch the Environment line: Processing vs Idle.
- Inspect the step log for request totals, per-field descriptors, and FAILED entries.
- Use diagnostics tabs or panels for request, mapping, reference, price, and calculation issues.
- For automated workflows, wrap notebook update calls in try/except blocks and record timestamps, inputs, status, and error messages.

**Section sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [app.py:81-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L81-L86)
- [app.py:412-447](file://User scripts/MDX Scan/mdx_scan/app.py#L412-L447)

## Conclusion
This repository provides robust patterns for automated report generation and external-system integration within BQuant Desktop constraints. The recommended automation model is:

- Trigger updates manually or programmatically from notebook code.
- Use engines to compute comparisons, rankings, and exports.
- Rely on local cache for fast reloads and fallbacks.
- Export via copy-to-Excel frames or CSV files.
- Handle timeouts, entitlement failures, and data issues explicitly.
- Log phases, steps, and diagnostics for monitoring.

For recurring automation outside the running kernel, do not assume cron or enterprise scheduling. If Enterprise capabilities become available, validate entitlements and current scheduling documentation before designing recurring workflows. Until then, keep workflows idempotent, observable, and safe for repeated manual or notebook-triggered execution.