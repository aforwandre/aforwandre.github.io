# Getting Started Guide

<cite>
**Referenced Files in This Document**
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md](file://RAG KB/05-get-started.md)
- [README.md (ETF Capping Monitoring)](file://User scripts/ETF Capping Monitoring/README.md)
- [README.md (ETF Spread Monitoring)](file://User scripts/ETF Spread Monitoring/README.md)
- [README.md (FI Index Change preview)](file://User scripts/FI Index Change/preview/README.md)
- [README.md (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/README.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This guide helps new users set up and run the Bloomberg BQuant applications in this repository on Bloomberg Desktop. It covers:
- The required development environment, including Python 3.11 and Jupyter notebook usage.
- How to install each of the five main applications into a BQuant project.
- First-run procedures, kernel restarts, and basic navigation.
- The difference between local development and production deployment.
- Common setup issues such as Terminal connectivity, AIM account configuration, and entitlement requirements.
- Verification steps before running analytical queries.

The repository contains user-facing application documentation under `User scripts/<Application>/README.md`, operational instructions under `instruction.md`, and platform-level guidance under `RAG KB/05-get-started.md`.

**Section sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-87](file://RAG KB/05-get-started.md#L21-L87)

## Project Structure
At a high level, the workspace is organized around:
- Operational instructions at the root.
- Five main application projects under `User scripts/`.
- A RAG knowledge base with platform and data guidance.

```mermaid
graph TB
Root["Repository Root"]
Instructions["instruction.md"]
Apps["User scripts/"]
ETF_Capping["ETF Capping Monitoring"]
ETF_Spread["ETF Spread Monitoring"]
FI_Index["FI Index Change"]
FI_Spread["FI Spread Movement Monitoring"]
MDX["MDX Scan"]
KB["RAG KB/"]
GetStarted["05-get-started.md"]
Root --> Instructions
Root --> Apps
Root --> KB
Apps --> ETF_Capping
Apps --> ETF_Spread
Apps --> FI_Index
Apps --> FI_Spread
Apps --> MDX
KB --> GetStarted
```

**Diagram sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-87](file://RAG KB/05-get-started.md#L21-L87)

**Section sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-87](file://RAG KB/05-get-started.md#L21-L87)

## Core Components
The five main applications are:
1. **ETF Capping Monitoring**: Converts AIM positions into company-level weights and monitors capping limits.
2. **ETF Spread Monitoring**: Analyzes historical ETF bid-ask spreads, peer comparisons, and fund flows.
3. **FI Index Change**: Monitors index membership changes and weighted turnover for fixed-income indices.
4. **FI Spread Movement Monitoring**: Ranks spread movers across an index, AIM account, or single bond.
5. **MDX Scan**: Scans MDX-related inputs through a dedicated notebook interface.

Each application follows the same pattern:
- Copy the listed runtime files into a BQuant project.
- Open `MAIN.ipynb`.
- Restart the kernel.
- Run the first cell.
- Click **Update** or **Refresh** to execute Bloomberg requests.

**Section sources**
- [instruction.md:13-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (ETF Capping Monitoring):13-29](file://User scripts/ETF Capping Monitoring/README.md#L13-L29)
- [README.md (ETF Spread Monitoring):21-45](file://User scripts/ETF Spread Monitoring/README.md#L21-L45)
- [README.md (FI Index Change preview):1-19](file://User scripts/FI Index Change/preview/README.md#L1-L19)
- [README.md (FI Spread Movement Monitoring):45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)

## Architecture Overview
BQuant Desktop runs on Bloomberg-managed infrastructure. Local Cursor is used for design and review; live BQL execution happens only inside BQuant or Terminal-connected kernels.

```mermaid
flowchart LR
Local["Local Cursor<br/>Design and review"] --> Copy["Copy code to BQuant project"]
Copy --> Kernel["BQuant Desktop<br/>Python 3.11 kernel"]
Kernel --> BQL["BQL / Bloomberg connection"]
Kernel --> Notebook["Jupyter notebook interface"]
Notebook --> App["Application UI<br/>Update / Refresh controls"]
```

**Diagram sources**
- [05-get-started.md:21-87](file://RAG KB/05-get-started.md#L21-L87)

**Section sources**
- [05-get-started.md:21-87](file://RAG KB/05-get-started.md#L21-L87)

## Detailed Component Analysis

### Environment Setup on Bloomberg Desktop
Before installing any application, confirm the desktop environment:
- Launch BQuant Desktop from Bloomberg Terminal.
- Create or open a project.
- Confirm the kernel is Python 3.11.
- Use the managed package workflow; do not use `pip`.
- Keep dependencies limited to BQL, Pandas, Plotly, and ipywidgets unless explicitly approved.

First-session verification:
1. Import pandas and initialize the BQL service.
2. Run a minimal request against a known index.
3. Inspect the returned DataFrame.

If the kernel shows `Connecting`, `No Kernel`, or cells do nothing, select or restart the kernel and verify the workload is active.

**Section sources**
- [05-get-started.md:41-69](file://RAG KB/05-get-started.md#L41-L69)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [05-get-started.md:225-248](file://RAG KB/05-get-started.md#L225-L248)

### Application 1: ETF Capping Monitoring
Purpose:
- Convert Current or Projected AIM positions into company-level portfolio weights.
- Monitor account-specific capping limits.

Required files:
- `MAIN.ipynb`
- `etf_capping/__init__.py`
- `etf_capping/config.py`
- `etf_capping/engine.py`
- `etf_capping/data.py`
- `etf_capping/app.py`

Setup procedure:
1. Create a BQuant project.
2. Copy the six files listed above.
3. Open `MAIN.ipynb`.
4. Restart the kernel.
5. Run the notebook cell.
6. Click **Update** to start the request.

Important notes:
- Do not copy `ETF Capping Formula.xlsx` into BQuant; it remains in the repository folder.
- The app does not query BQL until **Update** is clicked.
- Validate one account across Current and Projected AIM positions, pricing modes, hard overrides, Thai mappings, suspended names, and missing prices before relying on full results.

```mermaid
sequenceDiagram
participant User as "User"
participant Notebook as "MAIN.ipynb"
participant App as "etf_capping app"
participant BQL as "Bloomberg BQL"
User->>Notebook : Open and restart kernel
User->>Notebook : Run first cell
Note over Notebook : Imports package; no request yet
User->>App : Click Update
App->>BQL : Request AIM positions and reference data
BQL-->>App : Response
App-->>User : Display monitor, alerts, and full positions
```

**Diagram sources**
- [README.md (ETF Capping Monitoring):13-29](file://User scripts/ETF Capping Monitoring/README.md#L13-L29)
- [README.md (ETF Capping Monitoring):182-210](file://User scripts/ETF Capping Monitoring/README.md#L182-L210)

**Section sources**
- [instruction.md:13-18](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (ETF Capping Monitoring):13-33](file://User scripts/ETF Capping Monitoring/README.md#L13-L33)
- [README.md (ETF Capping Monitoring):182-216](file://User scripts/ETF Capping Monitoring/README.md#L182-L216)

### Application 2: ETF Spread Monitoring
Purpose:
- Analyze historical ETF share-class bid-ask spreads.
- Compare peers.
- View HSBC book taxonomy and fund flows.

Required files:
- `MAIN.ipynb`
- `etf_spread/__init__.py`
- `etf_spread/app.py`
- `etf_spread/book_view.py`
- `etf_spread/cache.py`
- `etf_spread/data.py`
- `etf_spread/engine.py`
- `etf_spread/flow_view.py`
- `etf_spread/metrics.py`
- `etf_spread/peers.py`

Setup procedure:
1. Copy the Python modules and `MAIN.ipynb`.
2. Open `MAIN.ipynb`.
3. Restart the kernel.
4. Run the first cell.
5. Click **Refresh** to load data.

Important notes:
- `cache.py` is required because `app.py` imports it at module load.
- Leave `Use cache` checked for incremental history updates.
- The first refresh writes quote, return, NAV, flow, and manifest files beside `MAIN.ipynb`.
- Do not copy `tests/` or `upload/` into the Desktop project.

```mermaid
flowchart TD
Start["Open MAIN.ipynb"] --> Kernel["Restart kernel"]
Kernel --> Cell["Run first cell"]
Cell --> Controls["Select strategy and period"]
Controls --> Refresh["Click Refresh"]
Refresh --> Cache{"Use cache?"}
Cache --> |Yes| Reuse["Reuse settled rows"]
Cache --> |No| Full["Request full window"]
Reuse --> Merge["Merge missing days"]
Full --> Merge
Merge --> Display["Display spreads, returns, flows, peers"]
```

**Diagram sources**
- [README.md (ETF Spread Monitoring):21-45](file://User scripts/ETF Spread Monitoring/README.md#L21-L45)
- [README.md (ETF Spread Monitoring):128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)

**Section sources**
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (ETF Spread Monitoring):21-54](file://User scripts/ETF Spread Monitoring/README.md#L21-L54)
- [README.md (ETF Spread Monitoring):128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)

### Application 3: FI Index Change
Purpose:
- Track index membership changes.
- Compute weighted turnover and change summaries.
- Support standard and MBS/TBA books.

Required files:
- `MAIN.ipynb`
- `fi_index_change/__init__.py`
- `fi_index_change/app.py`
- `fi_index_change/cache.py`
- `fi_index_change/config.py`
- `fi_index_change/data.py`
- `fi_index_change/engine.py`
- `fi_index_change/field_library.py`

Setup procedure:
1. Create `MAIN.ipynb` and the `fi_index_change` folder.
2. Copy the seven runtime files from `User scripts/FI Index Change/Upload/`, removing `.txt`.
3. Do not copy `tests/` or `cache/`.
4. Open `MAIN.ipynb`.
5. Restart the kernel.
6. Run the first cell.
7. Click **Update** to fetch data.

Important notes:
- Default index is `LEGATRUU Index`; default book is `(All)`.
- Narrowing `Book` to `Standard` or `MBS/TBA` filters display without rebuilding the request.
- The app splits analytics so no single request carries more than six measures.
- After changing package files, run `python3 refresh_local.py` from the project folder.
- Local preview is served at `http://127.0.0.1:8770/interface.html`.

```mermaid
sequenceDiagram
participant User as "User"
participant Notebook as "MAIN.ipynb"
participant Engine as "fi_index_change engine"
participant BQL as "Bloomberg BQL"
User->>Notebook : Open and restart kernel
User->>Notebook : Run first cell
User->>Engine : Select month-end and book
User->>Engine : Click Update
Engine->>BQL : Split analytics into small requests
BQL-->>Engine : Responses
Engine-->>User : Summary, changes, full positions
```

**Diagram sources**
- [instruction.md:25-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (FI Index Change preview):1-19](file://User scripts/FI Index Change/preview/README.md#L1-L19)

**Section sources**
- [instruction.md:25-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (FI Index Change preview):1-19](file://User scripts/FI Index Change/preview/README.md#L1-L19)

### Application 4: FI Spread Movement Monitoring
Purpose:
- Rank Top 10 spread increases and decreases.
- Support multiple universes: index, AIM account, AIM vs index, and single bond.

Required files:
- `MAIN.ipynb`
- `fi_spread_movement/__init__.py`
- `fi_spread_movement/config.py`
- `fi_spread_movement/data.py`
- `fi_spread_movement/engine.py`
- `fi_spread_movement/charts.py`
- `fi_spread_movement/cache.py`
- `fi_spread_movement/app.py`

Setup procedure:
1. Copy the seven runtime files and `MAIN.ipynb` from `Upload/`, removing `.txt`.
2. Open `MAIN.ipynb`.
3. Restart the kernel.
4. Run the first cell.
5. Choose a universe source.
6. Fill required fields.
7. Click **Update**.

Important notes:
- One book sends 10 Bloomberg requests; `AIM vs Index` sends 12.
- Duration measures share one request.
- Windows are bounded and validated; weekend end dates are refused before requesting.
- Timeouts trigger retry and cached fallback behavior.
- Local tests run via `python3 -m unittest discover -s tests -v`.
- Local layout preview uses port `8775`.

```mermaid
flowchart TD
Start["Open MAIN.ipynb"] --> Kernel["Restart kernel"]
Kernel --> Universe["Choose universe"]
Universe --> Fields["Fill universe-specific fields"]
Fields --> Dates["Choose spread type and dates"]
Dates --> Update["Click Update"]
Update --> Validate["Validate inputs and window"]
Validate --> Requests["Send ranking, descriptors, duration, series"]
Requests --> Check{"Timeout?"}
Check --> |Yes| Retry["Retry once"]
Retry --> Fallback{"Clean cache exists?"}
Fallback --> |Yes| ShowCached["Show Cached result"]
Fallback --> |No| Error["Show error"]
Check --> |No| Display["Display rankings, charts, export"]
```

**Diagram sources**
- [README.md (FI Spread Movement Monitoring):45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)
- [README.md (FI Spread Movement Monitoring):365-396](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L396)

**Section sources**
- [instruction.md:55-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (FI Spread Movement Monitoring):45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)
- [README.md (FI Spread Movement Monitoring):365-440](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L440)

### Application 5: MDX Scan
Purpose:
- Provide a notebook-based interface for scanning MDX-related inputs.

Setup procedure:
1. Open `User scripts/MDX Scan/MAIN.ipynb` on Desktop.
2. Do not merge this notebook into the ETF capping project.

Important notes:
- The instruction treats this as a separate, standalone notebook.
- No additional package structure is documented for MDX scan in this repository.

**Section sources**
- [instruction.md:20-23](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Dependency Analysis
The applications depend on:
- BQL for Bloomberg data access.
- Pandas for tabular processing.
- Plotly and ipywidgets for interactive notebooks and charts.
- Application-specific modules for data, engine, configuration, caching, and UI logic.

```mermaid
graph TB
Notebook["MAIN.ipynb"]
AppModule["Application package"]
Data["data.py"]
Engine["engine.py"]
Config["config.py"]
Cache["cache.py"]
Charts["charts.py"]
BQL["BQL"]
Notebook --> AppModule
AppModule --> Data
AppModule --> Engine
AppModule --> Config
AppModule --> Cache
AppModule --> Charts
Data --> BQL
Engine --> BQL
```

**Diagram sources**
- [README.md (ETF Capping Monitoring):13-29](file://User scripts/ETF Capping Monitoring/README.md#L13-L29)
- [README.md (ETF Spread Monitoring):21-45](file://User scripts/ETF Spread Monitoring/README.md#L21-L45)
- [README.md (FI Index Change preview):1-19](file://User scripts/FI Index Change/preview/README.md#L1-L19)
- [README.md (FI Spread Movement Monitoring):45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [README.md (ETF Spread Monitoring):21-45](file://User scripts/ETF Spread Monitoring/README.md#L21-L45)
- [README.md (FI Spread Movement Monitoring):45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)

## Performance Considerations
Key constraints for all applications:
- Desktop BQL requests can time out after two minutes.
- Keep universes and date ranges narrow.
- Prefer cached mode where supported.
- Avoid unbounded pulls.
- Limit concurrent projects to the allowed Desktop limit.
- Use split requests when many analytics are needed.
- Record timing, row counts, and column sets for every run.

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [instruction.md:29-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (FI Spread Movement Monitoring):365-396](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L396)

## Troubleshooting Guide

### Bloomberg Terminal Connectivity
Symptoms:
- Kernel stays on `Connecting`.
- BQL queries do not execute.
- 403 errors appear.

Actions:
- Confirm Bloomberg Terminal is logged in.
- Verify the BBA/session connection has not changed.
- Reconnect before changing code.
- Use Network Diagnostics if WebSockets are failing.

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### AIM Account Configuration
Symptoms:
- AIM account returns empty results.
- Ranking requests are refused.
- AIM vs Index comparison fails.

Actions:
- Enter exactly one AIM code.
- Leave `AIM_PXNUM` at its frozen default unless explicitly instructed otherwise.
- Leave `AIM_PROFILE` at `DEFAULT_PROFILE` unless explicitly instructed otherwise.
- For `AIM vs Index`, fill both the AIM code and the index ticker.
- If ranking requests are refused by BQL, treat the screen as blocked rather than interpreting an empty result as an empty book.

**Section sources**
- [instruction.md:61-66](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (FI Spread Movement Monitoring):93-124](file://User scripts/FI Spread Movement Monitoring/README.md#L93-L124)

### Permission and Entitlement Requirements
Symptoms:
- Field name errors.
- Missing columns.
- Refused items.
- Incomplete results.

Actions:
- Exact-search uncertain BQL data-item names in the knowledge base first.
- Use Terminal FLDS only for absent or ambiguous names, parameters, metadata, entitlement, or runtime behavior.
- Never probe ESG, GHG, climate, or sustainable-finance items.
- Obtain HelpDesk confirmation before changing BQL calls involving separately licensed data.

**Section sources**
- [05-get-started.md:61-69](file://RAG KB/05-get-started.md#L61-L69)
- [instruction.md:7-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [README.md (ETF Capping Monitoring):3-7](file://User scripts/ETF Capping Monitoring/README.md#L3-L7)
- [README.md (ETF Spread Monitoring):3-7](file://User scripts/ETF Spread Monitoring/README.md#L3-L7)
- [README.md (FI Spread Movement Monitoring):3-7](file://User scripts/FI Spread Movement Monitoring/README.md#L3-L7)

### Kernel and Notebook Issues
Symptoms:
- `NameError`.
- Cells do nothing.
- Kernel shows `No Kernel`.

Actions:
- Move definition cells before their usage.
- Restart the kernel.
- Run All after reordering cells.
- Shut down and reopen the workload if necessary.

**Section sources**
- [05-get-started.md:73-79](file://RAG KB/05-get-started.md#L73-L79)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### File and Package Issues
Symptoms:
- `ModuleNotFoundError`.
- Upload mirror drift.
- Preview page mismatch.

Actions:
- Copy required modules in the documented order.
- Remove `.txt` suffixes from uploaded runtime files.
- Run `python3 sync_upload.py --check` for FI Spread Movement Monitoring.
- Run `python3 refresh_local.py` for FI Index Change.
- Regenerate preview pages after code changes.

**Section sources**
- [README.md (ETF Spread Monitoring):21-54](file://User scripts/ETF Spread Monitoring/README.md#L21-L54)
- [README.md (FI Index Change preview):59-84](file://User scripts/FI Index Change/preview/README.md#L59-L84)
- [README.md (FI Spread Movement Monitoring):75-80](file://User scripts/FI Spread Movement Monitoring/README.md#L75-L80)

## Conclusion
To get started with Bloomberg BQuant in this repository:
- Use local Cursor for design and review.
- Execute BQL only on Bloomberg Desktop.
- Install each application by copying the documented runtime files into a BQuant project.
- Restart the kernel and run the first cell before clicking **Update** or **Refresh**.
- Validate connectivity, AIM configuration, and field entitlements before trusting results.
- Record timing, coverage, units, and anomalies before widening windows or promoting to production.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### First-Run Verification Checklist
- Confirm Python 3.11 kernel.
- Import pandas and initialize BQL.
- Run a minimal index request.
- Confirm the kernel is idle after the request.
- Copy the correct application files.
- Restart the kernel.
- Run the first cell.
- Click **Update** or **Refresh**.
- Inspect status, logs, and output tables.
- Compare key values with Terminal where applicable.

**Section sources**
- [05-get-started.md:41-69](file://RAG KB/05-get-started.md#L41-L69)
- [README.md (ETF Capping Monitoring):182-210](file://User scripts/ETF Capping Monitoring/README.md#L182-L210)
- [README.md (FI Spread Movement Monitoring):423-439](file://User scripts/FI Spread Movement Monitoring/README.md#L423-L439)