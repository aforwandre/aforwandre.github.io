# Historical Cache System

<cite>
**Referenced Files in This Document**
- [cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [test_cache.py](file://User scripts/ETF Spread Monitoring/tests/test_cache.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the historical cache management system used by the ETF spread monitoring workflow. The cache stores daily history for four data kinds: quotes, returns, NAVs, and flows. Its purpose is to avoid re-requesting settled historical rows from Bloomberg BQuant while still allowing live updates for missing days. It also protects against stale or corrupted cache entries, mismatched request definitions, and identifier-to-security changes.

The design is intentionally conservative:
- Stored frames are raw request outputs, not derived metrics.
- A manifest records contract shape, generation version, per-kind file metadata, and optional identity tokens.
- Reads never raise; unreadable or incompatible files are treated as “no cache.”
- Writes are atomic and refuse invalid or empty data.
- Gap planning requests only the missing dates per identifier.

## Project Structure
The historical cache lives under the ETF spread monitoring script package. The primary implementation is a dedicated cache module, which is consumed by the data-fetching layer that orchestrates parallel quote, return, flow, and NAV requests. Tests validate manifest behavior, gap planning, merge semantics, fingerprint stability, and end-to-end wiring.

```mermaid
graph TB
App["Application UI / Notebook"] --> DataLayer["Parallel History Fetcher"]
DataLayer --> CacheAPI["Cache API"]
CacheAPI --> Manifest["manifest.json"]
CacheAPI --> CSVFiles["quotes.csv<br/>returns.csv<br/>navs.csv<br/>flows.csv"]
DataLayer --> BQL["Bloomberg BQuant Service"]
```

**Diagram sources**
- [data.py:2227-2415](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2415)
- [cache.py:110-117](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L110-L117)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

**Section sources**
- [cache.py:1-62](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L62)
- [data.py:2216-2252](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2216-L2252)

## Core Components
The cache system exposes a focused API around four history kinds:

| Kind | Stored Columns | Purpose |
|---|---|---|
| `quotes` | `Bid`, `Ask`, `Mid` | Daily price levels for share classes |
| `returns` | `Level` | Total-return series |
| `navs` | `Level` | Fund NAV series |
| `flows` | `Flow` | Fund flow series |

Key responsibilities:
- **Contract and generation validation**: Ensures stored files match the current column schema and code generation.
- **Request fingerprinting**: Derives a stable token from the builder source so changed items, parameters, currencies, or date arguments invalidate old rows.
- **Identity ledger**: Records the security resolved for each identifier so a ticker change does not serve another instrument’s history.
- **Gap planning**: Computes per-identifier windows that still need to be requested.
- **Merge strategy**: Combines cached and live rows with live rows winning on duplicate keys.
- **Window trimming**: Returns only the dates the caller asked for.
- **Atomic persistence**: Uses temporary files and manifest updates to avoid partial writes.

**Section sources**
- [cache.py:32-56](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L32-L56)
- [cache.py:64-108](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L108)
- [cache.py:167-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L167-L231)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:468-489](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L468-L489)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

## Architecture Overview
The cache integrates into the parallel history fetcher. On each refresh:
1. The fetcher computes a request token based on the builders’ source.
2. If caching is enabled, it reads existing series for all four kinds.
3. It plans gaps per kind and identifier.
4. It executes only the missing windows through BQuant.
5. It merges cached and live results before computing derived fields such as spread.
6. It persists only settled rows older than the current session boundary.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "App Layer"
participant Data as "fetch_parallel_histories"
participant Cache as "cache module"
participant Disk as "CSV + manifest.json"
participant BQL as "Bloomberg BQuant"
User->>App : Trigger Refresh
App->>Data : Call with IDs, window, as_of, use_cache
Data->>Data : Compute request token
alt Cache enabled
Data->>Cache : read_series(kind, root, token, identities)
Cache->>Disk : Read manifest and CSV
Disk-->>Cache : Usable frame or empty
Cache-->>Data : Cached frame
else Cache disabled
Data-->>Data : No cache read
end
Data->>Cache : plan_gaps(kind, identifiers, cached, start, end)
Cache-->>Data : Missing windows per identifier
Data->>BQL : Execute only missing windows
BQL-->>Data : Live frames
Data->>Cache : merge(kind, cached, live_frames)
Cache-->>Data : Merged frame
Data->>Cache : save(kind, settled_rows, settled_before, token, identities)
Cache->>Disk : Write CSV and manifest atomically
Data-->>App : SourceResult objects
```

**Diagram sources**
- [data.py:2216-2415](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2216-L2415)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

## Detailed Component Analysis

### Cache Storage Mechanism
The cache stores one CSV per history kind under a project-scoped `cache` directory. A JSON manifest tracks:
- Contract signature built from the expected columns per kind.
- Generation version.
- Per-kind metadata including filename, row count, unique ID count, and request fingerprint.
- Optional identity ledger mapping normalized identifiers to security tokens.

Read paths are defensive:
- Missing directories are not created on read.
- Corrupt or mislabeled CSVs are ignored.
- Frames with no usable values are treated as absent.
- Dates are normalized and deduplicated per identifier.

Write paths are strict:
- Empty frames, missing columns, or frames with no numeric values are refused.
- Only rows strictly before the settlement boundary are persisted.
- CSV and manifest updates are written via temporary files and atomic replacement.

```mermaid
flowchart TD
Start(["Save Entry"]) --> ValidateKind["Validate kind and columns"]
ValidateKind --> NormalizeDates["Normalize DATE and drop invalid dates"]
NormalizeDates --> FilterSettled["Keep rows before settled_before"]
FilterSettled --> HasValues{"Any value in stored columns?"}
HasValues --> |No| RefuseEmpty["Raise ValueError"]
HasValues --> |Yes| MergeExisting["Merge with existing fingerprint-scoped rows"]
MergeExisting --> Deduplicate["Deduplicate by ID+DATE, keep last"]
Deduplicate --> Serialize["Serialize DATE and numeric cells"]
Serialize --> AtomicCSV["Write .csv.tmp then replace"]
AtomicCSV --> UpdateManifest["Update manifest with series and identity ledger"]
UpdateManifest --> End(["Return stored row count"])
```

**Diagram sources**
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

**Section sources**
- [cache.py:110-117](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L110-L117)
- [cache.py:120-132](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L132)
- [cache.py:135-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L135-L164)
- [cache.py:234-252](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L234-L252)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

### Data Serialization Formats
- **CSV files**: One file per kind (`quotes.csv`, `returns.csv`, `navs.csv`, `flows.csv`).
- **Columns**: Common `ID` and `DATE`, plus kind-specific numeric columns.
- **Date format**: Stored as `YYYY-MM-DD`.
- **Numeric format**: Converted to Python float text representation; blanks remain blank rather than becoming NaN strings.
- **Manifest format**: JSON with contract, generation, series metadata, and optional identity ledger.

Serialization safeguards include:
- Reading CSVs as strings with default NA disabled.
- Coercing dates and numeric columns with error tolerance.
- Rejecting frames where all stored numeric columns are missing.
- Dropping empty identifiers and invalid dates.

**Section sources**
- [cache.py:255-264](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L255-L264)
- [cache.py:292-305](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L292-L305)
- [cache.py:552-555](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L552-L555)
- [cache.py:578-582](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L578-L582)

### Retrieval Strategies
Retrieval is per kind and per identifier:
- `read_series` loads the manifest entry for the requested kind and validates contract, generation, and fingerprint.
- It normalizes identifiers, dates, and numeric values.
- It drops identifiers whose current security token differs from the recorded token.
- It returns an empty frame when no usable cache exists.

Gap planning determines what must still be requested:
- For unknown identifiers, the full caller window is requested.
- For known identifiers, head and tail gaps are computed relative to the stored coverage.
- Weekend-only gaps are skipped to avoid useless requests.

```mermaid
flowchart TD
ReadStart(["Read Series"]) --> CheckKind["Check kind is supported"]
CheckKind --> LoadManifest["Load manifest and check contract/generation"]
LoadManifest --> CheckFingerprint["Check per-kind fingerprint if provided"]
CheckFingerprint --> LoadCSV["Load CSV and validate columns"]
LoadCSV --> CleanData["Clean ID, DATE, numeric columns"]
CleanData --> CheckValues{"Any usable values?"}
CheckValues --> |No| ReturnEmpty["Return empty frame"]
CheckValues --> |Yes| IdentityCheck["Drop stale identifiers"]
IdentityCheck --> SortDedup["Sort by DATE,ID and deduplicate by ID+DATE"]
SortDedup --> ReturnFrame["Return cleaned frame"]
```

**Diagram sources**
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:135-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L135-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)

**Section sources**
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:336-349](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L336-L349)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)

### Querying Cached Data
To query cached data:
1. Choose the kind: `quotes`, `returns`, `navs`, or `flows`.
2. Call the cache read function with the project root, optional request fingerprint, and optional identity map.
3. Inspect the returned DataFrame for `ID`, `DATE`, and the kind-specific columns.
4. Use subset helpers to filter by identifiers if needed.

Example usage patterns (described without code):
- Load quotes for a fund and peer set.
- Load NAVs using the same identifiers as returns.
- Load flows only when a valid flow window is available.
- Trim the merged result to the exact window requested by the user.

**Section sources**
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:326-333](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L326-L333)
- [cache.py:468-489](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L468-L489)

### Updating Cache Entries
To update cache entries:
1. Build the merged frame from cached and live data.
2. Determine the settlement boundary, typically the current normalized date.
3. Persist only rows strictly before that boundary.
4. Provide the request fingerprint and identity map for the identifiers being saved.
5. Handle errors: empty frames, missing columns, or frames with no values raise explicit errors.

Important behaviors:
- Existing rows for the same identifier are replaced, not duplicated.
- Rows for other identifiers are preserved.
- The manifest is updated with new series metadata and identity ledger entries.

**Section sources**
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

### Cache Invalidation Policies
Invalidation occurs at multiple levels:

| Policy | Behavior |
|---|---|
| Contract mismatch | All stored series are ignored because the column schema changed. |
| Generation bump | All stored series are ignored to force a rebuild. |
| Request fingerprint mismatch | Per-kind stored rows are ignored because the builder source changed. |
| Identity mismatch | Rows for identifiers now pointing at different securities are dropped. |
| Corrupt or empty CSV | Treated as no cache; the window is requested again. |
| No usable values | Stored frame is rejected so repair can run. |

These policies prevent stale, poisoned, or semantically incorrect data from being served.

**Section sources**
- [cache.py:42-51](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L42-L51)
- [cache.py:64-108](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L108)
- [cache.py:135-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L135-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:292-311](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L292-L311)

### Expiration and Lifecycle Management
There is no time-based expiration. Instead, lifecycle control relies on:
- Settlement boundaries: Only past sessions are persisted.
- Fingerprint and generation checks: Code or schema changes invalidate old rows.
- Identity checks: Identifier-to-security mismatches invalidate affected rows.
- Manual override: Disabling cache forces a full request without writing.

The five-year relative window is used as a default anchor for gap planning, but the actual stored coverage is per identifier.

**Section sources**
- [cache.py:53-56](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L53-L56)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

### Memory Management Techniques
The cache avoids heavy memory pressure by:
- Storing raw daily rows rather than precomputed derived metrics.
- Using pandas DataFrames with minimal extra copies during read/write.
- Sorting and deduplicating by small key sets (`ID`, `DATE`).
- Keeping the manifest lightweight with metadata rather than embedding large payloads.
- Avoiding creation of the cache directory on read-only projects.

There is no automatic pruning of old series files in this component. Pruning is handled by other cache implementations in related scripts; the ETF spread historical cache focuses on correctness and incremental updates.

**Section sources**
- [cache.py:110-117](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L110-L117)
- [cache.py:292-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L292-L323)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

### Fallback Mechanisms
When cache data is unavailable or corrupted:
- Reads return empty frames instead of raising exceptions.
- Gap planning falls back to requesting the full caller window.
- The application logs that history was served from local cache only when no network request was made.
- Stale identity mismatches cause the affected identifiers to be fully re-requested.

This ensures robustness even when disk state is inconsistent or incomplete.

**Section sources**
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [data.py:2338-2364](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2338-L2364)
- [data.py:2410-2415](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2410-L2415)

## Dependency Analysis
The cache module is consumed by the data layer, which coordinates BQuant requests and result merging. The tests exercise both the cache internals and the integration between cache and fetcher.

```mermaid
graph LR
TestCache["tests/test_cache.py"] --> CacheModule["etf_spread/cache.py"]
TestData["etf_spread/data.py"] --> CacheModule
AppLayer["ETF Spread App"] --> TestData
CacheModule --> Pandas["pandas"]
CacheModule --> JSON["JSON manifest"]
CacheModule --> CSV["Per-kind CSV files"]
```

**Diagram sources**
- [test_cache.py:1-800](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L1-L800)
- [data.py:2216-2415](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2216-L2415)
- [cache.py:1-62](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L62)

**Section sources**
- [test_cache.py:34-75](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L34-L75)
- [test_cache.py:138-260](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L138-L260)
- [test_cache.py:384-458](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L384-L458)
- [test_cache.py:547-770](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L547-L770)

## Performance Considerations
- **Cache sizing**: Each kind has one CSV file. Row growth is proportional to the number of identifiers and days stored. Since only settled rows are persisted, recent days are not repeatedly rewritten.
- **Indexing strategy**: There is no database index. Lookup is driven by manifest metadata and pandas operations over small key sets. For very large identifier sets, consider limiting active identifiers or splitting workloads.
- **Concurrent access patterns**: The implementation uses atomic file replacement for CSV and manifest updates. However, there is no explicit locking mechanism. Concurrent writers should serialize writes to the same cache root.
- **Network efficiency**: Gap planning minimizes BQuant calls by requesting only missing dates per identifier.
- **Computation placement**: Derived columns such as spread are computed after merging raw rows, avoiding redundant recomputation across cached and live segments.

Recommendations:
- Keep the active identifier list reasonable.
- Avoid frequent manual edits to builder functions unless you intend to invalidate the cache.
- Monitor manifest size and CSV sizes as identifier counts grow.
- Use cache disable mode for controlled warm-up or troubleshooting runs.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Cache Synchronization Issues
Symptoms:
- Repeated full-window requests despite existing cache.
- Mixed old and new data appearing unexpectedly.

Checks:
- Verify the manifest contract and generation match expectations.
- Confirm the request fingerprint matches the current builder source.
- Ensure the settlement boundary is correctly passed to `save`.
- Check that identity tokens are supplied when identifiers may resolve to different securities.

Relevant logic:
- Contract and generation checks reject unusable manifests.
- Fingerprint checks reject per-kind rows built by different request definitions.
- Identity checks drop rows for identifiers whose security changed.

**Section sources**
- [cache.py:42-51](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L42-L51)
- [cache.py:64-108](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L108)
- [cache.py:135-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L135-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

### Data Consistency Problems
Symptoms:
- Wrong numbers replayed after changing an item or currency.
- A ticker serving another instrument’s history.

Root causes:
- Builder source changed but column names stayed the same.
- Identifier now points to a different security class.

Resolutions:
- Change the builder source intentionally to move the fingerprint.
- Supply current identity mappings so stale identifiers are discarded.
- Disable cache temporarily to rebuild consistent data.

**Section sources**
- [cache.py:64-108](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L108)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [data.py:2216-2252](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2216-L2252)

### Performance Bottlenecks
Symptoms:
- Slow refreshes due to excessive network requests.
- Large CSV files slowing reads.

Diagnoses:
- Check whether gap planning is generating many small windows.
- Verify that identifiers have stable coverage.
- Confirm that derived computations are not being repeated unnecessarily.

Mitigations:
- Reduce the number of active identifiers.
- Avoid unnecessary builder edits.
- Use cache mode for warm runs and disable cache only for controlled cold runs.

**Section sources**
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [data.py:2365-2415](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2365-L2415)

### Error Handling Patterns
- `read_series` never raises; unreadable or incompatible data becomes an empty frame.
- `save` raises `ValueError` for empty frames, missing columns, or frames with no values.
- Manifest and CSV writes use temporary files and atomic replacement.
- Tests assert refusal rules and fallback behavior.

**Section sources**
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)
- [test_cache.py:110-135](file://User scripts/ETF Spread Monitoring/tests/test_cache.py#L110-L135)

## Conclusion
The historical cache system is a pragmatic, safety-first design for storing and retrieving daily quote, return, NAV, and flow histories. It prioritizes correctness over convenience: contract and generation checks, request fingerprinting, identity ledger validation, and defensive read paths ensure that stale or corrupted data is not served. Gap planning reduces network load, while merge and trim utilities keep derived calculations correct and scoped to the requested window.

For production use, treat the cache as a durable but versioned artifact. When changing data builders, identifiers, or business assumptions, rely on the built-in invalidation mechanisms. When diagnosing issues, inspect the manifest, CSV integrity, settlement boundaries, and identity mappings. For performance, manage identifier scope and avoid unnecessary cache invalidation.

[No sources needed since this section summarizes without analyzing specific files]