# Visualization Components and User Interface

<cite>
**Referenced Files in This Document**   
- [app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [book_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py)
- [flow_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py)
- [metrics.py](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py)
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [peer_map.py](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py)
- [peers.py](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the visualization components and user interface for ETF spread monitoring, fund-flow analysis, and peer comparison. It focuses on:
- The book view that displays bid-ask spreads with severity-aware formatting and interactive selection.
- The flow view heatmap that visualizes net fund flows across time buckets.
- Interactive chart components for daily spread and return paths.
- Responsive design patterns, accessibility considerations, performance optimization, and extension guidelines.

The implementation is a Jupyter-based dashboard using `ipywidgets`, pandas data processing, and Plotly heatmaps. Data preparation, period handling, and metrics are separated from UI rendering to keep visualization logic reusable and testable.

## Project Structure
The ETF Spread Monitoring module is organized by responsibility:
- UI orchestration and widget layout: `app.py`
- Book table, London session rules, and per-share-class chart frames: `book_view.py`
- Fund-flow matrix construction and row labeling: `flow_view.py`
- Period returns, peer averages, and chart series alignment: `metrics.py`
- Observation cleaning, period windows, and summary/chart views: `engine.py`
- Configuration for share classes, ISIN book, and observation schema: `config.py`
- Data fetching, placeholder sources, and BQL response normalization: `data.py`
- Manual peer mapping and primary ISIN resolution: `peer_map.py`
- Peer detail table composition and grouping controls: `peers.py`

```mermaid
graph TB
UI["ETFSpreadMonitor<br/>Widgets and tabs"] --> BookView["Book View<br/>Table and per-share-class frames"]
UI --> FlowView["Flow View<br/>Fund-flow matrices"]
UI --> Metrics["Metrics<br/>Returns, peers, benchmarks"]
UI --> Engine["Engine<br/>Observations and period windows"]
UI --> Config["Config<br/>ISIN book and schema"]
UI --> Data["Data<br/>Placeholder/Bloomberg adapters"]
UI --> PeerMap["Peer Map<br/>Manual peer list"]
UI --> Peers["Peers<br/>Detail table and grouping"]
```

**Diagram sources**
- [app.py:306-564](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L564)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [config.py:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L115-L139)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [peer_map.py:64-82](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L64-L82)
- [peers.py:398-500](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L398-L500)

**Section sources**
- [app.py:306-564](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L564)
- [config.py:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L115-L139)

## Core Components
- **ETFSpreadMonitor**: Main controller that wires widgets, manages refresh state, coordinates data loading, and renders the HSBC ETF table, Flows heatmap, and Peers Details tab.
- **Book View**: Builds the displayed book frame, computes average spread percentages over preset or custom periods, and prepares per-share-class daily spread charts.
- **Flow View**: Aggregates fund flows into weekly or monthly buckets, groups by fund name or peer group, and produces a Plotly heatmap.
- **Metrics**: Computes period returns, peer averages, benchmark comparisons, and aligns series to HSBC quote dates.
- **Engine**: Cleans observations, defines period bounds, summarizes spread statistics, and builds chart-ready frames.
- **Config**: Defines the live ISIN book, share class directory, and observation columns.
- **Data**: Provides placeholder and Bloomberg adapters, normalizes BQL responses, and fetches parallel histories.
- **Peer Map**: Holds manual peer mappings and resolves primary ISINs.
- **Peers**: Composes the peer detail table, merges facts, and applies grouping controls.

**Section sources**
- [app.py:306-564](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L564)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [config.py:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L115-L139)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [peer_map.py:64-82](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L64-L82)
- [peers.py:398-500](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L398-L500)

## Architecture Overview
The dashboard follows a layered architecture:
- UI layer (`ETFSpreadMonitor`) orchestrates user interactions and renders outputs.
- Presentation layer formats tables, charts, and heatmaps.
- Analytics layer computes spreads, returns, peer averages, and flow matrices.
- Data layer fetches and normalizes source data.

```mermaid
sequenceDiagram
participant User as "Operator"
participant UI as "ETFSpreadMonitor"
participant Data as "Data Layer"
participant Book as "Book View"
participant Flow as "Flow View"
participant Metrics as "Metrics"
participant Engine as "Engine"
User->>UI : Click Refresh
UI->>Data : Fetch directory, quotes, returns, flows, NAV
Data-->>UI : SourceResult frames and notes
UI->>Book : Build book display and averages
UI->>Flow : Slice cached flows and build matrix
UI->>Metrics : Compute peer averages and chart series
UI->>Engine : Prepare observations and period windows
UI-->>User : Render HSBC ETF table, Flows heatmap, Peers Details
```

**Diagram sources**
- [app.py:846-1002](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L846-L1002)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

## Detailed Component Analysis

### Book View Component
The book view renders a table of typed HSBC ETF share classes with:
- Bid, Ask, Last, Absolute Spread, Percent Spread.
- Average spread percentages for preset periods (1M, 3M, 6M, YTD, 1Y, 3Y, 5Y) and Custom.
- London trading-day alignment and carry-forward of quotes when needed.
- Optional peer-average and benchmark-return columns via metrics integration.

Key behaviors:
- Missing market text is normalized and blanked rather than treated as zero.
- Mid price resolution prefers explicit mid; otherwise it uses positive bid/ask averages.
- Spread percent is computed only when absolute spread and mid are valid.
- Period windows respect London sessions and avoid weekend/bank-holiday artifacts.

```mermaid
classDiagram
class BookView {
+display_columns() list
+book_display(directory, history, custom_start, custom_end) DataFrame
+history_averages(history, as_of, custom_start, custom_end) DataFrame
+carry_london_quotes(group, as_of) DataFrame
+share_class_chart(history, ticker, period, as_of, custom_start, custom_end) DataFrame
}
```

**Diagram sources**
- [book_view.py:431-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L431-L496)
- [book_view.py:375-428](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L375-L428)
- [book_view.py:265-337](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L265-L337)
- [book_view.py:499-551](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L499-L551)

**Section sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [book_view.py:121-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L160)
- [book_view.py:265-337](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L265-L337)
- [book_view.py:375-428](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L375-L428)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [book_view.py:499-551](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L499-L551)

### Flow View Heatmap Component
The flow view generates a heatmap of net fund flows:
- Short periods (1M, 3M) use weekly buckets; longer periods use monthly buckets.
- Rows represent funds grouped by typed fund name; labels prefer long names and disambiguate duplicates.
- Two modes: HSBC ETF only and HSBC + Peers combined.
- Uses Plotly `go.Heatmap` with a diverging colorscale centered at zero.

```mermaid
flowchart TD
Start(["Flow Matrix Request"]) --> ValidatePeriod["Validate period and bounds"]
ValidatePeriod --> BucketRule{"Short period?"}
BucketRule --> |Yes| Weekly["Use weekly buckets"]
BucketRule --> |No| Monthly["Use monthly buckets"]
Weekly --> GroupBy["Group flows by ID_KEY and Category"]
Monthly --> GroupBy
GroupBy --> SumPresent["Sum present values per bucket"]
SumPresent --> Unstack["Unstack buckets into matrix"]
Unstack --> Reindex["Reindex rows by typed order"]
Reindex --> RenderHeatmap["Render Plotly heatmap"]
RenderHeatmap --> End(["Return figure"])
```

**Diagram sources**
- [flow_view.py:37-43](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L37-L43)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [flow_view.py:325-389](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L325-L389)
- [app.py:1821-1856](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1821-L1856)

**Section sources**
- [flow_view.py:23-34](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L23-L34)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [flow_view.py:152-185](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L152-L185)
- [flow_view.py:241-299](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L241-L299)
- [flow_view.py:325-389](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L325-L389)
- [app.py:1821-1856](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1821-L1856)

### Interactive Chart Components
Interactive charts visualize:
- Daily spread percent for a selected share class.
- Peer-average spread percent aligned to HSBC quote dates.
- Return percent paths for anchor, peers, and benchmark.

Behavior:
- Charts are built from cached history without additional requests.
- Period selection drives both HSBC ETF and Peers Details charts.
- Row click or dropdown selection updates the active ticker and redraws charts.

```mermaid
sequenceDiagram
participant User as "Operator"
participant UI as "ETFSpreadMonitor"
participant Metrics as "Metrics"
participant Output as "Plotly Output"
User->>UI : Select share class row
UI->>Metrics : spread_comparison(anchor, peers, period, as_of)
Metrics-->>UI : DataFrame(DATE, Percent Spread, Peer Spread %)
UI->>Output : Render line chart
User->>UI : Change Chart Period
UI->>Metrics : return_comparison(levels, anchor, peers, period, as_of)
Metrics-->>UI : DataFrame(DATE, Return %, Peer Return %, Bmk Return %)
UI->>Output : Render return path chart
```

**Diagram sources**
- [app.py:1578-1600](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1578-L1600)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)
- [metrics.py:624-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L624-L670)

**Section sources**
- [app.py:1428-1456](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1428-L1456)
- [app.py:1458-1474](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1458-L1474)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)
- [metrics.py:624-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L624-L670)

### Book View Severity Indicators and Formatting
Severity and formatting are handled through:
- Missing market text detection and cleaning.
- Numeric conversion with zero masking for prices.
- Spread percent computation only when valid.
- Display formatting preserving quote precision for prices and three decimals for spreads.

```mermaid
flowchart TD
Input["Raw cell value"] --> CheckMissing{"Missing market text?"}
CheckMissing --> |Yes| Blank["Return empty string"]
CheckMissing --> |No| ParseNumber["Parse numeric value"]
ParseNumber --> PriceColumn{"Price column?"}
PriceColumn --> |Yes| QuotePrecision["Format with quote precision"]
PriceColumn --> |No| SpreadCheck{"Spread column?"}
SpreadCheck --> |Yes| ThreeDecimals["Format with 3 decimal places"]
SpreadCheck --> |No| TwoDecimals["Format with 2 decimal places"]
QuotePrecision --> Output["Formatted text"]
ThreeDecimals --> Output
TwoDecimals --> Output
```

**Diagram sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [app.py:114-137](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L114-L137)

**Section sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [app.py:114-137](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L114-L137)

### Responsive Design Patterns
Responsive behavior includes:
- Dynamic grid height based on row count.
- Column width fitting to content length.
- Frozen first column for Fund Name.
- Conditional display of chart row dropdown when grid click is unavailable.

```mermaid
flowchart TD
Start(["Render Table"]) --> FitWidths["Fit column widths"]
FitWidths --> GridAvailable{"ipydatagrid available?"}
GridAvailable --> |Yes| GridHeight["Compute dynamic height"]
GridAvailable --> |No| FrozenTable["Render frozen HTML table"]
GridHeight --> ClickHandler["Attach row click handler"]
ClickHandler --> ShowChartRow{"Grid supports click?"}
ShowChartRow --> |No| DropdownFallback["Show chart row dropdown"]
ShowChartRow --> |Yes| HideDropdown["Hide chart row dropdown"]
FrozenTable --> End(["Display table"])
DropdownFallback --> End
HideDropdown --> End
```

**Diagram sources**
- [app.py:1336-1400](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1336-L1400)
- [app.py:1402-1420](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1402-L1420)

**Section sources**
- [app.py:1336-1400](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1336-L1400)
- [app.py:1402-1420](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1402-L1420)

### Accessibility Features
Accessibility considerations implemented:
- High-contrast dark theme for readability.
- Sticky headers and frozen first column for navigation clarity.
- Clear status messages indicating environment activity and phase.
- Tooltips and descriptive labels for controls.

**Section sources**
- [app.py:82-96](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L82-L96)
- [app.py:350-356](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L350-L356)
- [app.py:292-303](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L292-L303)

## Dependency Analysis
Component dependencies:
- `app.py` depends on `book_view`, `flow_view`, `metrics`, `config`, `data`, `peer_map`, and `peers`.
- `book_view` depends on `engine` for period bounds.
- `flow_view` depends on `book_view` for London period bounds and preferred long names.
- `metrics` depends on `book_view` and `engine` for period windows and helpers.
- `engine` depends on `config` for observation schema and enabled share classes.
- `data` depends on `config`, `peer_map`, and `book_view`.
- `peers` depends on `book_view` and `metrics`.

```mermaid
graph LR
app["app.py"] --> bv["book_view.py"]
app --> fv["flow_view.py"]
app --> mt["metrics.py"]
app --> cfg["config.py"]
app --> dt["data.py"]
app --> pm["peer_map.py"]
app --> pr["peers.py"]
bv --> en["engine.py"]
fv --> bv
mt --> bv
mt --> en
en --> cfg
dt --> cfg
dt --> pm
dt --> bv
pr --> bv
pr --> mt
```

**Diagram sources**
- [app.py:12-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L12-L54)
- [book_view.py:10-10](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L10-L10)
- [flow_view.py:7-8](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L8)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [engine.py:15-15](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L15)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)

**Section sources**
- [app.py:12-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L12-L54)
- [book_view.py:10-10](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L10-L10)
- [flow_view.py:7-8](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L8)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [engine.py:15-15](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L15)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)

## Performance Considerations
Optimization strategies used:
- Cached data slicing avoids re-fetching for chart and heatmap updates.
- Parallel history fetching reduces latency for quotes, returns, flows, and NAV.
- Pandas vectorized operations for spread calculations and aggregations.
- Efficient grouping and deduplication for flow matrices and peer lists.
- Conditional rendering of heavy components (grid vs frozen table).
- Plotly heatmap sizing adapts to label lengths to prevent overflow.

Recommendations:
- Prefer precomputed aggregates for large universes.
- Use lazy evaluation for optional features (e.g., peer details).
- Limit visible columns based on user preferences.
- Batch updates to reduce widget redraws.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- No book rows returned: Verify ISIN book configuration and strategy filter.
- Unknown period or bounds: Ensure period keys match supported presets and custom date ranges are valid.
- Crossed quotes: These are left blank; check bid/ask validity.
- Missing flow data: Confirm flow IDs and period bounds; ensure fund-flow cache has rows.
- Peer mapping failures: Populate manual peer map and ensure primary ISIN resolution succeeds.

**Section sources**
- [app.py:987-1002](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L987-L1002)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:358-360](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L358-L360)
- [flow_view.py:81-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L81-L107)
- [peer_map.py:85-129](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L85-L129)

## Conclusion
The ETF Spread Monitoring visualization suite provides a robust, modular interface for analyzing bid-ask spreads, fund flows, and peer performance. Its separation of concerns—UI orchestration, presentation formatting, analytics computation, and data fetching—enables responsive interaction, clear error reporting, and extensibility for new chart types and metrics.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Usage Examples
- Configure the book: Update `ISIN_BOOK` in `config.py` with live ETF entries.
- Set peer mappings: Add `PeerMapEntry` rows in `peer_map.py` for each HSBC fund.
- Run refresh: Instantiate `ETFSpreadMonitor()` and call `render()` to display tabs.
- Customize colors: Modify Plotly heatmap colorscale in `_show_heatmap` if needed.
- Interact with dynamic data: Select rows or change periods to update charts and heatmaps without network calls.

**Section sources**
- [config.py:107-125](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L107-L125)
- [peer_map.py:38-42](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L38-L42)
- [app.py:488-564](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L488-L564)
- [app.py:1821-1856](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1821-L1856)

### Extending Visualization Components
To add new chart types:
- Create a new function in `metrics.py` or `book_view.py` to compute the desired series.
- Integrate with `ETFSpreadMonitor` by adding a new output widget and event handler.
- Use existing helpers for period windows, London session alignment, and peer anchoring.
- Follow the pattern of conditional rendering and fallbacks for compatibility.

**Section sources**
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)
- [book_view.py:499-551](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L499-L551)
- [app.py:1578-1600](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1578-L1600)