# ETF Spread Monitoring Module

<cite>
**Referenced Files in This Document**
- [README.md](file://User scripts/ETF Spread Monitoring/README.md)
- [app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [book_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py)
- [flow_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py)
- [metrics.py](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py)
- [peer_map.py](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py)
- [peers.py](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
The ETF Spread Monitoring module is a BQuant Desktop validation build for historical ETF share-class bid-ask spreads, peer comparison, and HSBC book taxonomy plus fund-flow views. It currently runs with placeholder data sources while the Bloomberg route card for spread history is approved. The operator-selected field set includes HSBC book-style share classes, bid/ask/mid/last prices, share-class taxonomy, fund AUM, class AUM, expense ratio, tracking error, NAV tracking error, fund flows, and benchmark peers.

Key behaviors:
- The HSBC ETF tab shows exactly the typed `ISIN_BOOK` rows in typed order.
- Spread is `PX_ASK - PX_BID`; spread percent is `(PX_ASK - PX_BID) / PX_MID * 100`.
- Return uses a USD total-return index level; NAV return uses NAV levels.
- Peer comparisons use a manual peer map resolved to one primary listing per peer fund.
- Fund flows are visualized as a heatmap grouped by fund name, weekly for 1M/3M and monthly for longer periods.
- A local cache stores raw quote, return, NAV, and flow series so daily Refreshes request only missing days.

**Section sources**
- [README.md:9-19](file://User scripts/ETF Spread Monitoring/README.md#L9-L19)
- [README.md:73-116](file://User scripts/ETF Spread Monitoring/README.md#L73-L116)
- [README.md:117-184](file://User scripts/ETF Spread Monitoring/README.md#L117-L184)

## Project Structure
The module is organized by responsibility rather than by layer:
- Configuration and book definition: `config.py`, `peer_map.py`
- Data fetching and response handling: `data.py`
- Cache management: `cache.py`
- Pure table logic: `engine.py`, `book_view.py`, `metrics.py`, `peers.py`, `flow_view.py`
- Interactive UI orchestration: `app.py`

```mermaid
graph TB
App["app.py<br/>UI controller"] --> BookView["book_view.py<br/>Book table, averages, charts"]
App --> Metrics["metrics.py<br/>Return, peer averages, benchmarks"]
App --> Peers["peers.py<br/>Peer detail table"]
App --> FlowView["flow_view.py<br/>Flow heatmap"]
App --> Data["data.py<br/>Placeholder/Bloomberg adapters"]
App --> Config["config.py<br/>ISIN book, period keys"]
App --> PeerMap["peer_map.py<br/>Manual peer mapping"]
Data --> Cache["cache.py<br/>Quote/return/NAV/flow cache"]
BookView --> Engine["engine.py<br/>Spread stats, period bounds"]
```

**Diagram sources**
- [app.py:12-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L12-L54)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [book_view.py:10-11](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L10-L11)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)
- [flow_view.py:7-8](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L8)
- [engine.py:15](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15)

**Section sources**
- [README.md:21-45](file://User scripts/ETF Spread Monitoring/README.md#L21-L45)
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)

## Core Components
- **HSBC book configuration**: `ISIN_BOOK` defines one primary share class per fund, including fund name, ISIN, listing ticker, order, and strategy.
- **Spread engine**: Computes valid bid-ask spreads, quote status, windowed summaries, and chart frames from prepared observations.
- **Data adapters**: Placeholder sources generate deterministic synthetic history; Bloomberg adapters are placeholders until route card approval.
- **Cache system**: Stores raw `Bid`/`Ask`/`Mid`, `Level`, and `Flow` series keyed by identifier and date, with contract, generation, and source fingerprints.
- **Book view**: Builds the displayed HSBC table, London-session-aligned averages, and interactive daily spread charts.
- **Metrics**: Calculates total-return and NAV returns, peer averages, benchmark returns, and aligned time-series comparisons.
- **Peer mapping**: Manual `PEER_MAP` maps HSBC fund names to peer ISINs, resolved to one primary listing per peer fund.
- **Peers details**: Renders HSBC anchor rows followed by each fund’s Top 5 peers with their own metrics.
- **Flow view**: Aggregates fund flows into weekly or monthly buckets and renders a heatmap.

**Section sources**
- [config.py:35-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L35-L140)
- [engine.py:48-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L48-L152)
- [data.py:135-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L254)
- [cache.py:29-51](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L29-L51)
- [book_view.py:121-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L160)
- [metrics.py:38-139](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L38-L139)
- [peer_map.py:30-130](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L30-L130)
- [peers.py:121-170](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L121-L170)
- [flow_view.py:68-108](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L108)

## Architecture Overview
The application follows a clear separation between UI state, pure analytics, data acquisition, and persistence.

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "ETFSpreadMonitor<br/>app.py"
participant Data as "data.py"
participant Cache as "cache.py"
participant View as "book_view.py / metrics.py / flow_view.py"
participant Engine as "engine.py"
User->>App : Click Refresh
App->>Data : fetch_spread_payload(today, sources)
Data->>Cache : plan_gaps(kind, identifiers, cached, windows)
Data->>Cache : read_series(kind, fingerprint, identities)
Data-->>App : SpreadPayload(observations, errors)
App->>View : book_display(directory, quote_history)
App->>View : return_percents(levels)
App->>View : hsbc_flow_matrix(flows, book, period, as_of)
View->>Engine : period_bounds, history_averages
Engine-->>View : SpreadView summary/chart
App->>Cache : save(kind, settled_rows, settled_before)
App-->>User : Tables, charts, heatmap, status
```

**Diagram sources**
- [app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [metrics.py:357-385](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L357-L385)
- [flow_view.py:241-261](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L241-L261)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

## Detailed Component Analysis

### HSBC Book Integration
The HSBC book is defined by `ISIN_BOOK`, where each entry represents one primary share class per fund. The app reads this frame to populate strategy filters, fund dropdowns, and the HSBC ETF table. The live screen uses the typed `ISIN_BOOK` rows only; legacy `SHARE_CLASSES` remains a placeholder.

Key responsibilities:
- Provide fund name, ISIN, listing ticker, order, and strategy.
- Supply the canonical identity used for quote requests and cache keys.
- Drive the fund menu and strategy filtering without exposing strategy as a visible column.

```mermaid
classDiagram
class IsinEntry {
+string fund_name
+string isin
+string ticker
+string order
+string strategy
}
class ShareClass {
+string share_class_id
+string etf_id
+string label
+string listing_ticker
+string currency
+string peer_group_id
+bool enabled
}
class Config {
+PERIOD_KEYS
+HISTORY_BUSINESS_DAYS
+BOOK_SOURCE
+PEER_SOURCE
+OBSERVATION_COLUMNS
+enabled_share_classes()
+isin_book_frame()
}
Config --> IsinEntry : "reads"
Config --> ShareClass : "reads"
```

**Diagram sources**
- [config.py:35-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L35-L140)

**Section sources**
- [config.py:15-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L140)
- [README.md:56-71](file://User scripts/ETF Spread Monitoring/README.md#L56-L71)

### Bid-Ask Spread Calculation Methodology
Spread calculations are intentionally conservative: invalid, crossed, non-positive, or non-numeric quotes remain blank rather than being zero-filled.

Core rules:
- Absolute spread: `PX_ASK - PX_BID` when both quotes are positive and ask is at least bid.
- Percent spread: absolute spread divided by mid, multiplied by 100. If mid is blank, it is reconstructed from bid and ask.
- Quote status tracks missing, ok, and crossed states.
- London-session alignment carries previous quotes across weekdays but does not fill before the first quote.

```mermaid
flowchart TD
Start(["Spread Input"]) --> Clean["Clean Bid/Ask/Mid"]
Clean --> Valid{"Both positive<br/>and Ask >= Bid?"}
Valid --> |No| Blank["Leave blank"]
Valid --> |Yes| AbsSpread["Compute Ask - Bid"]
AbsSpread --> MidCheck{"Mid positive?"}
MidCheck --> |No| ReconstructMid["Reconstruct Mid from Bid/Ask"]
MidCheck --> |Yes| UseMid["Use provided Mid"]
ReconstructMid --> PctSpread["Percent = (Abs / Mid) * 100"]
UseMid --> PctSpread
PctSpread --> Status["Mark Quote Status"]
Blank --> End(["Output"])
Status --> End
```

**Diagram sources**
- [book_view.py:121-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L160)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)

**Section sources**
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [README.md:93-115](file://User scripts/ETF Spread Monitoring/README.md#L93-L115)

### Peer Benchmarking System
Peer benchmarking combines three layers:
1. Manual peer mapping from HSBC fund names to peer ISINs.
2. Resolution of peer ISINs to one primary listing per peer fund.
3. Comparison of spread, return, NAV return, and benchmark return against the HSBC anchor.

Peer selection:
- `PEER_MAP` contains `PeerMapEntry(fund_name, peer_isin)` rows.
- `choose_primary_isins` resolves peer ISINs to a single primary listing using company and primary mappings.
- `member_tickers` builds the average member list, optionally including the HSBC anchor.

Benchmark comparison:
- Benchmark ID comes from the long name of the fund’s primary benchmark index.
- Return paths align peer and benchmark values to the HSBC quote dates on or before each London weekday.

```mermaid
sequenceDiagram
participant Map as "peer_map.py"
participant Data as "data.py"
participant Metrics as "metrics.py"
participant View as "peers.py"
Map->>Map : map_rows()
Map->>Data : choose_primary_isins(peer_isins, company_of, primaries_of)
Data-->>Map : chosen_primary_tickers, notes
Metrics->>Metrics : member_tickers(anchor, peers, include_anchor)
Metrics->>Metrics : return_comparison(anchor, peers, period, benchmark_id)
View->>View : peer_detail_rows(hsbc, links, histories, facts)
```

**Diagram sources**
- [peer_map.py:64-130](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L64-L130)
- [metrics.py:38-58](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L38-L58)
- [metrics.py:624-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L624-L670)
- [peers.py:398-500](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L398-L500)

**Section sources**
- [peer_map.py:1-130](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L1-L130)
- [metrics.py:38-58](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L38-L58)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)
- [peers.py:398-500](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L398-L500)

### Fund Flow Analysis Engine
The flow engine aggregates fund flows into a heatmap:
- One row per fund name.
- Weekly aggregation for 1M and 3M; monthly aggregation for 6M through 5Y.
- Two modes: HSBC ETF only and HSBC + Peers, where peer flows are added onto the same fund line.
- Ticker deduplication ensures another share class of the same fund is not counted twice.

```mermaid
flowchart TD
Start(["Fund Flows + Book"]) --> Groups["Build Category Groups"]
Groups --> Period["Select Period Window"]
Period --> Bucket["Weekly or Monthly Bucket"]
Bucket --> Filter["Filter Dates and IDs"]
Filter --> DailySum["Daily Sum per Ticker"]
DailySum --> GroupSum["Group Sum per Category + Bucket"]
GroupSum --> Matrix["Unstack to Heatmap Matrix"]
Matrix --> Order["Reindex to Typed Book Order"]
Order --> End(["Heatmap Output"])
```

**Diagram sources**
- [flow_view.py:68-108](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L108)
- [flow_view.py:325-389](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L325-L389)

**Section sources**
- [flow_view.py:10-108](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L10-L108)
- [flow_view.py:188-204](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L188-L204)
- [flow_view.py:241-322](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L241-L322)
- [flow_view.py:325-389](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L325-L389)

### Historical Cache Management
The cache stores raw request outputs for four kinds:
- Quotes: `Bid`, `Ask`, `Mid`
- Returns: `Level`
- NAV: `Level`
- Flows: `Flow`

Safety features:
- Contract token validates stored columns.
- Generation token invalidates rows when semantics change.
- Source fingerprint hashes builder function source to prevent replaying wrong requests under new code.
- Identity ledger records which security an identifier resolved to; changed securities trigger full re-pull.
- Only rows older than the last completed London session are written; recent prints can still move.

```mermaid
flowchart TD
Start(["Refresh Cycle"]) --> Read["Read manifest + series"]
Read --> Fingerprint["Compute request fingerprint"]
Fingerprint --> Coverage["Compute coverage per ID"]
Coverage --> Gaps["Plan head/tail/full gaps"]
Gaps --> Fetch["Fetch missing data"]
Fetch --> Merge["Merge cached + live"]
Merge --> Trim["Trim to requested window"]
Trim --> Save["Write settled rows < last London day"]
Save --> Manifest["Update manifest.json"]
```

**Diagram sources**
- [cache.py:120-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

**Section sources**
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [cache.py:29-81](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L29-L81)
- [cache.py:135-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L135-L231)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)
- [README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)

### Visualization Components
The module provides:
- **Treemaps**: Not implemented in the current codebase. The README describes a heatmap and tables; there is no treemap component.
- **Heatmaps**: Implemented via `flow_view.py`, rendering fund flows by week or month.
- **Interactive charts**: Daily spread charts for selected share classes and peer comparisons, driven by `book_view.share_class_chart` and `metrics.spread_comparison`/`return_comparison`.

Visualization behavior:
- Book table supports frozen first column, custom column widths, and styled HSBC anchor rows.
- Charts plot daily spread percent and return percent aligned to London trading days.
- Heatmap sizing adapts to fund name length and number of rows.

**Section sources**
- [app.py:114-137](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L114-L137)
- [app.py:222-303](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L222-L303)
- [book_view.py:499-551](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L499-L551)
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)
- [flow_view.py:23-34](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L23-L34)

## Dependency Analysis
The module has low coupling between UI and analytics, with data and cache as shared dependencies.

```mermaid
graph LR
Config["config.py"] --> App["app.py"]
PeerMap["peer_map.py"] --> Data["data.py"]
PeerMap --> Metrics["metrics.py"]
PeerMap --> FlowView["flow_view.py"]
Data --> Cache["cache.py"]
Engine["engine.py"] --> BookView["book_view.py"]
BookView --> App
Metrics --> App
Peers["peers.py"] --> App
FlowView --> App
```

**Diagram sources**
- [app.py:12-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L12-L54)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [book_view.py:10-11](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L10-L11)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)
- [flow_view.py:7-8](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L8)

**Section sources**
- [app.py:12-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L12-L54)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)

## Performance Considerations
- Placeholder sources generate deterministic synthetic data; Bloomberg adapters are stubs until route card approval.
- Cache reduces Bloomberg requests to missing days after the last completed London session.
- History averaging computes mean spread percent per preset window; absolute averages are intentionally not computed because price levels differ across funds.
- London-session alignment avoids exchange-holiday mismatches by carrying previous quotes.
- Peer and benchmark comparisons align to HSBC quote dates to avoid future-looking bias.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Data Synchronization Issues
Symptoms:
- Missing spread or return values.
- Peer rows showing blank benchmark returns.
- Flow heatmap showing “No fund-flow rows yet.”

Checks:
- Verify `ISIN_BOOK` entries have valid fund names, ISINs, and tickers.
- Confirm `PEER_MAP` entries match HSBC fund names exactly.
- Ensure Bloomberg route card 27 is approved; otherwise placeholder diagnostics appear.
- Check that quote history has London sessions; otherwise “Data as of unavailable” appears.

**Section sources**
- [README.md:9-19](file://User scripts/ETF Spread Monitoring/README.md#L9-L19)
- [README.md:73-116](file://User scripts/ETF Spread Monitoring/README.md#L73-L116)
- [data.py:149-160](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L149-L160)
- [data.py:183-194](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L183-L194)
- [book_view.py:211-251](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L211-L251)

### Cache Management Problems
Symptoms:
- Old data persists after changing fields or parameters.
- Full window is requested repeatedly.
- Identifier points to a different security but old rows are served.

Resolution:
- Delete `cache/` or uncheck `Use cache` to rebuild.
- Change in request builders changes the fingerprint and invalidates old files.
- Changed ISIN resolution triggers stale identity detection and full re-pull.
- Write failures are logged as notes and do not fail the Refresh.

**Section sources**
- [README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)
- [cache.py:44-81](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L44-L81)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

### Performance Optimization
Recommendations:
- Keep `Use cache` enabled for daily runs.
- Avoid unnecessary history range changes; the cache serves settled rows.
- Limit visible periods to reduce table width and computation.
- Use HSBC-only flow mode when peer flows are not required.
- Prefer preset periods over Custom unless exact date ranges are necessary.

**Section sources**
- [README.md:128-184](file://User scripts/ETF Spread Monitoring/README.md#L128-L184)
- [book_view.py:375-428](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L375-L428)
- [metrics.py:357-385](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L357-L385)

### Best Practices for Peer Groups and Spread Anomalies
Peer group configuration:
- Use consistent fund names in `IsinEntry.fund_name` and `PEER_MAP.fund_name`.
- Map multiple peer ISINs to one primary listing per peer fund.
- Validate that umbrella IDs and primary listings resolve correctly.

Spread anomaly analysis:
- Inspect quote status for crossed or missing quotes.
- Compare spread percent against peer average and benchmark return.
- Use the daily chart to identify isolated spikes versus sustained widening.
- Review London-session alignment and carry behavior for holiday effects.

**Section sources**
- [peer_map.py:1-130](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L1-L130)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)
- [book_view.py:265-337](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L265-L337)

## Conclusion
The ETF Spread Monitoring module provides a robust framework for HSBC book spread monitoring, peer benchmarking, and fund flow visualization. Its design separates configuration, data acquisition, analytics, caching, and UI concerns, making it maintainable and extensible. The current placeholder data sources allow validation of logic and interface behavior while Bloomberg integration awaits route card approval. Operators should focus on accurate book and peer configuration, leverage the cache for efficient daily runs, and use the spread, return, NAV, and flow views together to detect anomalies and compare performance against peers and benchmarks.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### API and Function Reference Summary
- Spread calculation: `absolute_quote_spread`, `percent_quote_spread`, `resolved_mid`
- Period logic: `period_bounds`, `london_period_bounds`, `history_averages`
- Return logic: `return_percents`, `return_comparison`, `peer_member_returns`
- Flow logic: `hsbc_flow_matrix`, `combined_flow_matrix`, `flow_request_tickers`
- Cache logic: `read_series`, `plan_gaps`, `merge`, `save`
- Peer logic: `map_rows`, `choose_primary_isins`, `member_tickers`

**Section sources**
- [book_view.py:121-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L160)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [metrics.py:357-385](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L357-L385)
- [flow_view.py:188-204](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L188-L204)
- [cache.py:267-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L414)
- [peer_map.py:64-130](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L64-L130)