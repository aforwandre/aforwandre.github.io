# Data Processing and HSBC Integration

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [book_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py)
- [metrics.py](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the ETF spread data processing layer used by the ETF Spread Monitoring application. It covers how raw market data is ingested from Bloomberg BQuant, cleaned, transformed into standardized spreads and mid-prices, and then summarized for analysis. The documentation focuses on:

- HSBC book integration architecture
- Bid-ask spread calculation methodology
- Data validation and missing-data handling
- Transformation pipeline from raw quotes to analytical outputs
- Error handling for stale, missing, or malformed inputs
- Performance considerations for large datasets and real-time streaming
- Troubleshooting guidance for common ingestion and validation failures

The system separates concerns across configuration, book/table logic, engine/view logic, metrics, and a central data ingestion module that orchestrates Bloomberg requests, caching, and result assembly.

## Project Structure
The relevant code lives under `User scripts/ETF Spread Monitoring/etf_spread`. The key modules are:

- `config.py`: Configuration constants, share-class registry, period presets, and observation schema.
- `book_view.py`: Market text cleaning, quote math, London session alignment, and display table construction.
- `engine.py`: Observation preparation, period windowing, summary statistics, and chart frame generation.
- `metrics.py`: Period returns, peer averages, benchmark alignment, and comparison views.
- `data.py`: Bloomberg request orchestration, response normalization, FX conversion, history caching, and final dataset assembly.

```mermaid
graph TB
Config["config.py<br/>Periods, columns, share classes"] --> Data["data.py<br/>Bloomberg ingestion, cache, transforms"]
BookView["book_view.py<br/>Text cleaning, quote math, London days"] --> Data
Engine["engine.py<br/>Observation prep, windows, summaries"] --> Metrics["metrics.py<br/>Returns, peers, benchmarks"]
Data --> Engine
Data --> Metrics
BookView --> Engine
BookView --> Metrics
```

**Diagram sources**
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [metrics.py:115-187](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L115-L187)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)

**Section sources**
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [metrics.py:115-187](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L115-L187)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)

## Core Components
- Configuration and schema:
  - Period keys, default period, business-day history length, source selection, and observation column names.
  - Share class registry and ISIN book entries.
- Book view utilities:
  - Missing-market text detection and cleaning.
  - Numeric parsing with zero-handling rules.
  - Absolute spread, mid resolution, and percent spread.
  - London trading day helpers and quote carrying.
- Engine view:
  - Observation validation and deduplication.
  - Spread and status computation.
  - Period bounds and summary statistics.
- Metrics:
  - Return percent from levels.
  - Peer and benchmark alignment on HSBC quote dates.
  - Comparison charts and averages.
- Data ingestion:
  - Typed HSBC book enrichment via Bloomberg.
  - Quote, return, NAV, and fund flow history fetching.
  - FX conversion and AUM normalization.
  - Local cache planning, merging, and persistence.

**Section sources**
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [book_view.py:63-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L160)
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [metrics.py:115-187](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L115-L187)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)

## Architecture Overview
The data pipeline has two major paths:

1. Snapshot path (HSBC book):
   - Resolve umbrella IDs and linked share classes.
   - Overlay quotes, tracking errors, expense ratios, and AUM.
   - Convert currency amounts to USD millions.
   - Compute absolute spread, mid, and percent spread.
   - Project onto the typed book and attach order/strategy/benchmark metadata.

2. History path (quotes, returns, NAV, flows):
   - Build parallel Bloomberg requests for quotes, total-return index, NAV levels, and daily flows.
   - Use local cache to reuse stored rows and only request gaps.
   - Merge live and stored frames, compute derived columns once, and persist settled data.

```mermaid
sequenceDiagram
participant App as "Application"
participant Data as "data.py"
participant BQ as "Bloomberg BQuant"
participant Cache as "Local Cache"
participant View as "engine.py / metrics.py"
App->>Data : fetch_share_class_directory()
Data->>BQ : Umbrella ID + share-class requests
BQ-->>Data : Linked share classes
Data->>BQ : Quotes, tracking error, expense ratio, AUM
BQ-->>Data : Snapshot fields
Data->>Data : FX convert, spread/mid/percent spread
Data-->>App : Typed book snapshot
App->>Data : fetch_parallel_histories(...)
Data->>Cache : Read stored series
Data->>BQ : Parallel quote/return/NAV/flow requests
BQ-->>Data : Live frames
Data->>Cache : Merge and save settled rows
Data-->>View : Cleaned history frames
View-->>App : Summaries, charts, comparisons
```

**Diagram sources**
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [data.py:2227-2502](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2502)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)

## Detailed Component Analysis

### HSBC Book Integration Architecture
The HSBC book is not a raw Bloomberg universe dump. It is anchored by a typed list (`ISIN_BOOK`) and enriched through Bloomberg:

- Seed funds by representative ISINs.
- Resolve each fund’s umbrella company ID.
- Pull active primary share classes per umbrella.
- Overlay latest quotes, tracking error, NAV tracking error, expense ratio, and fund AUM.
- Convert share-class AUM to USD millions using spot rates.
- Compute absolute spread, mid, and percent spread.
- Mark primary share classes and project onto the typed book.
- Attach benchmark names and strategy text.

Key responsibilities:

- `fetch_share_class_directory` builds the full directory and enriches it.
- `_apply_book_snapshots` batches Bloomberg requests for quotes and analytics.
- `_spot_rates_to_usd` resolves non-USD FX pairs and converts amounts.
- `keep_primary_listing` selects one listing per fund/ISIN with preferred quoting behavior.
- `project_onto_typed_book` ensures only typed rows appear in the app output.

```mermaid
flowchart TD
Start(["Start"]) --> Seeds["Resolve umbrella IDs for seed ISINs"]
Seeds --> Shares["Pull linked share classes per umbrella"]
Shares --> Snapshots["Overlay quotes, tracking error, expense ratio, AUM"]
Snapshots --> FX["Convert share-class AUM to USD millions"]
FX --> Spreads["Compute Mid, Absolute Spread, Percent Spread"]
Spreads --> Primary["Mark primary share classes"]
Primary --> Project["Project onto typed book"]
Project --> Benchmark["Attach benchmark names and strategy"]
Benchmark --> End(["Typed book snapshot"])
```

**Diagram sources**
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [data.py:1098-1191](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1098-L1191)
- [data.py:855-920](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L855-L920)
- [data.py:1418-1478](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1418-L1478)
- [data.py:1675-1756](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1675-L1756)

**Section sources**
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [data.py:1098-1191](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1098-L1191)
- [data.py:855-920](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L855-L920)
- [data.py:1418-1478](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1418-L1478)
- [data.py:1675-1756](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1675-L1756)

### Bid-Ask Spread Calculation Methodology
Spread calculations are consistent across snapshots and history:

- Absolute spread: ask minus bid when both are positive and ask is at least bid; otherwise blank.
- Mid price: prefer a positive vendor mid if present; otherwise average of positive bid and ask.
- Percent spread: absolute spread divided by mid, multiplied by 100; blank if mid is not positive.

These functions are centralized in `book_view.py`, while the engine also computes a placeholder midpoint spread in basis points for internal observations.

```mermaid
flowchart TD
Inputs["Bid, Ask, optional Mid"] --> Validate["Validate numeric values<br/>Reject zeros and negatives"]
Validate --> AbsSpread["Absolute Spread = Ask - Bid<br/>Only if Ask >= Bid > 0"]
AbsSpread --> MidCalc["Mid = Max(positive vendor Mid,<br/>average of positive Bid/Ask)"]
MidCalc --> PctSpread["Percent Spread = (Absolute Spread / Mid) * 100"]
Validate --> Status["Quote Status: ok, crossed, missing"]
```

**Diagram sources**
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)

**Section sources**
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)

### Data Validation Processes
Validation occurs at multiple layers:

- Text normalization:
  - Missing tokens such as “N/A”, “null”, “none”, “nan”, and various dash patterns are treated as missing.
  - Cleaned text becomes empty strings rather than NaN-like placeholders.
- Numeric parsing:
  - Vendor numbers are converted safely; infinities become NaN.
  - Zero handling differs by context: prices and AUM treat zero as missing; some computed returns allow zero.
- Column and schema checks:
  - Observation frames must contain required columns; otherwise an exception is raised.
  - Response frames require usable ID columns and date columns where applicable.
- Quote validity:
  - Crossed quotes (ask < bid), negative quotes, or non-numeric quotes are flagged and excluded from spread calculations.

```mermaid
flowchart TD
Raw["Raw cell value"] --> TextCheck{"Missing token?"}
TextCheck --> |Yes| Empty["Return empty string"]
TextCheck --> |No| NumParse["Convert to numeric"]
NumParse --> InfCheck{"Inf/-Inf?"}
InfCheck --> |Yes| NaN["Replace with NaN"]
InfCheck --> |No| ZeroRule{"Zero allowed?"}
ZeroRule --> |No| MaskZero["Mask zero as missing"]
ZeroRule --> |Yes| Keep["Keep zero"]
MaskZero --> Valid["Valid number or NaN"]
Keep --> Valid
NaN --> Valid
Empty --> Invalid["Invalid or missing"]
```

**Diagram sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)

**Section sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)

### Data Transformation Pipeline
The transformation pipeline converts HSBC quote data into standardized spreads, mid-prices, and volume-related metrics:

1. Ingestion:
   - Typed book rows are projected from the configured ISIN list.
   - Bloomberg responses are normalized to ID+DATE frames with one named value column.
   - Currency lines are collapsed to match share-class currency.
2. Enrichment:
   - FX rates are resolved for non-USD currencies.
   - Share-class AUM is converted to USD millions.
   - Fund AUM is stamped per fund and copied to each share class row.
3. Derivation:
   - Mid, absolute spread, and percent spread are computed.
   - Tracking error and expense ratio are normalized to display scales.
4. Output:
   - Final table includes taxonomy fields, AUM, last price, bid/ask, spreads, and averages over preset periods.

```mermaid
flowchart TD
RawQuotes["Raw Bloomberg quotes"] --> Normalize["Normalize ID/DATE/value columns"]
Normalize --> Collapse["Collapse publication lines by currency"]
Collapse --> FX["FX convert share-class AUM to USD millions"]
FX --> Derive["Derive Mid, Absolute Spread, Percent Spread"]
Derive --> Enrich["Overlay tracking error, expense ratio, fund AUM"]
Enrich --> Project["Project onto typed book"]
Project --> Output["Standardized analytical table"]
```

**Diagram sources**
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)
- [data.py:647-663](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L647-L663)
- [data.py:832-920](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L832-L920)
- [data.py:1888-1898](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1888-L1898)
- [data.py:1675-1756](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1675-L1756)

**Section sources**
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)
- [data.py:647-663](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L647-L663)
- [data.py:832-920](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L832-L920)
- [data.py:1888-1898](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1888-L1898)
- [data.py:1675-1756](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1675-L1756)

### Concrete Examples of Spread Calculations
The following examples illustrate how spreads are calculated using actual code paths:

- Placeholder midpoint spread in basis points:
  - Input: bid and ask series.
  - Logic: compute mid, validate positivity and ordering, then calculate `(ask - bid) / mid * 10000`.
  - Reference: [engine.py:97-109](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L109)

- Absolute quote spread:
  - Input: bid and ask series.
  - Logic: keep ask minus bid only when both are positive and ask is at least bid.
  - Reference: [book_view.py:121-130](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L130)

- Resolved mid:
  - Input: bid, ask, optional vendor mid.
  - Logic: prefer positive vendor mid; otherwise average of positive bid and ask.
  - Reference: [book_view.py:133-148](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L133-L148)

- Percent quote spread:
  - Input: absolute spread and mid.
  - Logic: divide absolute spread by mid and multiply by 100; blank if mid is not positive.
  - Reference: [book_view.py:151-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L151-L160)

- History-derived spreads:
  - Input: ID, DATE, Bid, Ask, Mid.
  - Logic: clean numeric fields, resolve mid, compute spread and percent spread, then select standard columns.
  - Reference: [data.py:1999-2014](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1999-L2014)

**Section sources**
- [engine.py:97-109](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L109)
- [book_view.py:121-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L160)
- [data.py:1999-2014](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1999-L2014)

### Error Handling for Missing Data, Stale Quotes, and Malformed Inputs
Error handling is explicit and layered:

- Missing market text:
  - Recognizes many vendor tokens and normalizes them to empty strings.
  - Prevents false positives like “NA US Equity” being treated as missing.
- Numeric safety:
  - Converts safely, replaces infinities, and applies zero-handling rules per context.
- Schema validation:
  - Raises exceptions when required columns are missing from observation frames.
- Response validation:
  - Checks for usable ID columns, date columns, and single-value columns.
  - Rejects row-number indexes without an ID column.
- Quote status:
  - Flags crossed quotes and leaves them blank in spread calculations.
- Cache identity changes:
  - Detects when identifiers now resolve to different securities and discards stale history.

```mermaid
flowchart TD
Input["Input data"] --> TextClean["Clean missing tokens"]
TextClean --> NumSafe["Safe numeric conversion"]
NumSafe --> SchemaCheck["Validate required columns"]
SchemaCheck --> ResponseCheck["Validate ID/date/value structure"]
ResponseCheck --> QuoteCheck["Validate bid/ask positivity/ordering"]
QuoteCheck --> Status["Assign quote status"]
Status --> Output["Derived spreads and metrics"]
```

**Diagram sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)

**Section sources**
- [book_view.py:63-118](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L63-L118)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)

## Dependency Analysis
The modules have clear dependencies:

- `engine.py` depends on `config.py` for observation columns and period keys.
- `book_view.py` depends on `engine.py` for period bounds.
- `metrics.py` depends on `book_view.py` for quote math and London session helpers, and on `engine.py` for period bounds.
- `data.py` depends on `config.py`, `peer_map.py`, and `cache.py`, and uses `book_view.py` for quote math and London session logic.

```mermaid
graph LR
Config["config.py"] --> Engine["engine.py"]
Engine --> Metrics["metrics.py"]
BookView["book_view.py"] --> Engine
BookView --> Metrics
Data["data.py"] --> BookView
Data --> Engine
Data --> Metrics
```

**Diagram sources**
- [engine.py:15-15](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L15)
- [book_view.py:10-10](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L10-L10)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)

**Section sources**
- [engine.py:15-15](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L15)
- [book_view.py:10-10](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L10-L10)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)

## Performance Considerations
- Batched Bloomberg requests:
  - Requests are grouped into waves of up to eight identifiers to avoid timeouts and reduce overhead.
- Local caching:
  - Stored series are reused; only gaps are requested.
  - Cache writes are limited to settled data before the last completed London session.
- Efficient merging:
  - Responses are combined on real ID+DATE keys to avoid positional misalignment.
- London session alignment:
  - Business-day ranges are used without filtering exchange holidays, ensuring aligned schedules across funds.
- Derived columns computed once:
  - Spread and percent spread are built after merging live and stored frames to minimize redundant computation.

Recommendations for real-time streaming:

- Prefer incremental updates:
  - Use cache gap planning to append only new sessions.
- Limit request scope:
  - Request only the identifiers needed for the current view.
- Monitor cache identity changes:
  - When identifiers re-point to different securities, force full refresh for those series.
- Avoid blocking operations:
  - Keep progress callbacks lightweight and avoid heavy computations inside request loops.

**Section sources**
- [data.py:573-601](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L573-L601)
- [data.py:2227-2502](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2502)
- [book_view.py:221-232](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L221-L232)

## Troubleshooting Guide
Common issues and resolutions:

- No enabled share classes:
  - Symptom: placeholder book returns no observations and reports missing configuration.
  - Action: verify `enabled_share_classes()` and ensure at least one enabled row exists.
  - Reference: [data.py:135-147](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L147)

- Unknown book or peer source:
  - Symptom: ValueError for unsupported source name.
  - Action: use “placeholder” or “bloomberg”; update configuration accordingly.
  - Reference: [data.py:197-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L197-L210)

- Missing observation columns:
  - Symptom: KeyError during observation preparation.
  - Action: ensure the input frame contains all required columns defined in configuration.
  - Reference: [engine.py:122-128](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L128)

- Crossed or invalid quotes:
  - Symptom: spread remains blank; notes report crossed quotes.
  - Action: inspect bid/ask values; confirm vendor data integrity.
  - Reference: [engine.py:358-360](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L358-L360)

- Bloomberg unavailable:
  - Symptom: messages indicating bql is unavailable outside Desktop.
  - Action: run pulls on Bloomberg BQuant Desktop or provide mock data for testing.
  - Reference: [data.py:2284-2299](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2284-L2299)

- Identifier identity change:
  - Symptom: stored history discarded due to identifier now resolving to a different security.
  - Action: accept full refresh for affected identifiers; review mapping in peer map or book.
  - Reference: [data.py:2337-2355](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2337-L2355)

- FX rate missing:
  - Symptom: share-class AUM stays blank for non-USD currencies.
  - Action: verify spot rates for the currency pair; check Bloomberg availability.
  - Reference: [data.py:913-920](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L913-L920)

- Custom period invalid:
  - Symptom: custom start after end or missing bounds.
  - Action: adjust start/end dates; ensure they are valid timestamps.
  - Reference: [engine.py:166-173](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L166-L173)

**Section sources**
- [data.py:135-147](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L147)
- [data.py:197-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L197-L210)
- [engine.py:122-128](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L128)
- [engine.py:358-360](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L358-L360)
- [data.py:2284-2299](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2284-L2299)
- [data.py:2337-2355](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2337-L2355)
- [data.py:913-920](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L913-L920)
- [engine.py:166-173](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L166-L173)

## Conclusion
The ETF spread data processing layer provides a robust, validated pipeline for transforming raw Bloomberg market data into standardized spreads, mid-prices, and analytical metrics. It integrates the HSBC book through typed configuration, enriches it with Bloomberg snapshots, and aligns historical data using London session logic. The system emphasizes safe numeric handling, explicit error reporting, and performance-conscious batching and caching. For operational reliability, maintain accurate configuration, monitor cache identity changes, and ensure Bloomberg connectivity for live data.