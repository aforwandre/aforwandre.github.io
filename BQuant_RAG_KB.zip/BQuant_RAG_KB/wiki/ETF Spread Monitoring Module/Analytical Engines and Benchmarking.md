# Analytical Engines and Benchmarking

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [metrics.py](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py)
- [peers.py](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py)
- [peer_map.py](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [flow_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py)
- [README.md](file://User scripts/ETF Spread Monitoring/README.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the analytical engines behind ETF spread monitoring, peer benchmarking, fund flow analysis, and spread anomaly detection. The system is built around a small set of focused modules:

- **Data ingestion and caching**: loads or synthesizes book quotes, peer quotes, total-return levels, NAV levels, and fund flows.
- **Engine**: prepares observations, computes windowed spread statistics, and builds summary and chart tables for selected share classes and their peer groups.
- **Metrics**: aligns spreads and returns to London trading days, computes period return percentages, peer averages, benchmark comparisons, and per-member series.
- **Peer mapping**: defines manual peer relationships between HSBC funds and peer ISINs, resolves primary listings, and supplies ticker lists for comparison.
- **Peers view**: assembles a peer comparison table with current quotes, historical averages, and period returns.
- **Flow view**: aggregates daily fund flows into weekly or monthly buckets and produces heatmaps by strategy or peer group.
- **Configuration**: defines enabled share classes, periods, observation schema, and placeholder data sources.

The documentation focuses on how these components work together, how peer groups are constructed and ranked, how flows are calculated, and how spread metrics are computed. It also provides best practices for interpreting results and identifying meaningful anomalies.

## Project Structure
The ETF Spread Monitoring project is organized by functional module rather than by layer. Each Python file has a clear responsibility:

```mermaid
graph TB
Config["config.py<br/>Share classes, periods, constants"] --> Data["data.py<br/>Placeholder/Bloomberg sources,<br/>BQL combiners, cache helpers"]
PeerMap["peer_map.py<br/>Manual peer list,<br/>primary ISIN resolution"] --> Data
Data --> Engine["engine.py<br/>Observation preparation,<br/>spread stats, views"]
Data --> Metrics["metrics.py<br/>Return %, peer/benchmark alignment,<br/>comparison series"]
Data --> PeersView["peers.py<br/>Peer table assembly"]
Data --> FlowView["flow_view.py<br/>Fund-flow heatmap"]
Engine --> App["app.py (not analyzed here)"]
Metrics --> App
PeersView --> App
FlowView --> App
```

**Diagram sources**
- [config.py:15-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L85)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [peer_map.py:30-42](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L30-L42)
- [engine.py:15-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L16)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)
- [flow_view.py:7-12](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L12)

**Section sources**
- [README.md:21-45](file://User scripts/ETF Spread Monitoring/README.md#L21-L45)
- [config.py:15-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L85)

## Core Components
The analytical pipeline can be understood as four stages:

1. **Source selection and data loading**
   - Placeholder sources generate deterministic synthetic bid-ask history for testing.
   - Bloomberg adapters are defined but do not connect until route cards are approved.
   - BQL-based data handling normalizes responses, merges multi-item outputs, and converts vendor units.

2. **Observation preparation**
   - Observations are cleaned, deduplicated, sorted by date, and converted into midpoint spread in basis points.
   - Quote status is recorded as missing, ok, or crossed.

3. **Windowed analytics**
   - Period bounds are computed from preset windows or custom start/end dates.
   - Summary statistics include last, mean, median, min, max, number of observations, and number of priced days.
   - Chart frames align book and peer series for time-series visualization.

4. **Benchmarking and flow aggregation**
   - Peer tickers are derived from a manual map and resolved to primary listings.
   - Returns and spreads are aligned to London trading days using the anchor fund’s quote dates.
   - Fund flows are grouped by fund or peer group and summed by week or month.

**Section sources**
- [data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:193-205](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L193-L205)
- [metrics.py:357-385](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L357-L385)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)

## Architecture Overview
The end-to-end flow starts with configuration and peer mapping, proceeds through data loading, and ends with analytical views.

```mermaid
sequenceDiagram
participant User as "Operator"
participant Config as "config.py"
participant PeerMap as "peer_map.py"
participant Data as "data.py"
participant Engine as "engine.py"
participant Metrics as "metrics.py"
participant View as "peers.py / flow_view.py"
User->>Config : Select share classes and periods
User->>PeerMap : Load manual peer mappings
User->>Data : Fetch book and peer history
Data-->>User : Observations, errors, sources
User->>Engine : Build spread view
Engine-->>User : Summary and chart frames
User->>Metrics : Compute returns, peer averages, benchmarks
Metrics-->>User : Comparison series and period columns
User->>View : Render peer table or flow heatmap
View-->>User : Final analytical output
```

**Diagram sources**
- [config.py:15-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L85)
- [peer_map.py:64-82](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L64-L82)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [peers.py:121-170](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L121-L170)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)

## Detailed Component Analysis

### Peer Benchmarking System
The peer benchmarking system connects three pieces:

- **Peer mapping**: a manually maintained list of HSBC fund names and peer ISINs.
- **Primary listing resolution**: maps peer ISINs to one primary listing per peer fund when possible.
- **Comparison logic**: selects anchor and peer tickers, aligns them to London trading days, and computes peer averages and benchmark returns.

#### Peer Mapping Logic
The peer map stores entries keyed by fund name and peer ISIN. Duplicate pairs are removed, and blank values are ignored. When multiple peer ISINs resolve to the same primary listing, duplicates are collapsed. If a peer fund has zero or more than one primary listing, it is skipped with a diagnostic note.

```mermaid
flowchart TD
Start(["Load PEER_MAP"]) --> Clean["Clean fund name and peer ISIN"]
Clean --> Dedup{"Duplicate pair?"}
Dedup --> |Yes| SkipPair["Skip duplicate pair"]
Dedup --> |No| AddPair["Add to map rows"]
AddPair --> Resolve["Resolve peer ISINs to primary listings"]
Resolve --> PrimaryCheck{"Exactly one primary ISIN?"}
PrimaryCheck --> |Yes| KeepPrimary["Keep primary ISIN"]
PrimaryCheck --> |No| NoteIssue["Record diagnostic note"]
KeepPrimary --> UniquePrimary["Deduplicate primary ISINs"]
NoteIssue --> UniquePrimary
UniquePrimary --> End(["Chosen peer tickers"])
```

**Diagram sources**
- [peer_map.py:30-42](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L30-L42)
- [peer_map.py:64-82](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L64-L82)
- [peer_map.py:85-129](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L85-L129)

#### Peer Group Construction and Ranking
Peer groups are derived from the enabled share classes’ `Peer Group ID`. For each selected share class, the engine identifies its peer group, then includes both the book series and the corresponding peer series. Peer rows are labeled as `Peer <group_id>` and summarized alongside book rows.

Ranking is primarily by series type and label:

- Book rows appear before peer rows.
- Within each series type, rows are sorted by label.
- Peer currency labels are aggregated across members; mixed currencies produce a `Mixed` label.

```mermaid
classDiagram
class ShareClass {
+string share_class_id
+string etf_id
+string label
+string listing_ticker
+string currency
+string peer_group_id
+bool enabled
}
class PreparedObservations {
+DataFrame frame
+int dropped_rows
}
class SpreadView {
+DataFrame summary
+DataFrame chart
+Timestamp as_of
+Timestamp window_start
+Timestamp window_end
+list notes
}
ShareClass --> PreparedObservations : "used by engine"
PreparedObservations --> SpreadView : "input to build_view"
```

**Diagram sources**
- [config.py:35-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L35-L85)
- [engine.py:48-61](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L48-L61)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:217-272](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L272)

**Section sources**
- [peer_map.py:30-129](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L30-L129)
- [engine.py:217-272](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L272)
- [metrics.py:38-58](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L38-L58)

### Fund Flow Analysis Engine
The fund flow engine transforms daily flow records into readable heatmaps. It supports:

- Aggregation by strategy or peer group.
- Weekly bucketing for short windows (`1M`, `3M`).
- Monthly bucketing for longer windows (`6M` through `5Y`).
- Combined HSBC and peer flows per fund.
- HSBC-only and peer-group-only views.

#### Flow Calculation Methodology
Daily flows are normalized, filtered to the requested period, and grouped by identifier and date. Missing or non-numeric flows are excluded. Each category’s daily totals are then aggregated into weekly or monthly buckets. Blank buckets remain blank rather than being forced to zero.

```mermaid
flowchart TD
Start(["Input flows, book, links, period, as_of"]) --> Validate["Validate period and required columns"]
Validate --> Bounds["Compute London period bounds"]
Bounds --> Bucket["Choose weekly or monthly bucket"]
Bucket --> GroupTickers["Build category mapping from book or links"]
GroupTickers --> Filter["Filter flows to period and known categories"]
Filter --> DailySum["Sum flows per ticker per day"]
DailySum --> BucketSum["Sum flows per category per bucket"]
BucketSum --> Matrix["Unstack into category-by-bucket matrix"]
Matrix --> Order["Reindex rows by typed fund order"]
Order --> Notes["Attach notes about missing or unmatched data"]
Notes --> End(["Heatmap matrix and notes"])
```

**Diagram sources**
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [flow_view.py:325-389](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L325-L389)

**Section sources**
- [flow_view.py:10-12](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L10-L12)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [flow_view.py:241-322](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L241-L322)
- [flow_view.py:325-389](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L325-L389)

### Spread Anomaly Detection Algorithms
Spread anomaly detection in this codebase is implemented as statistical summarization and alignment rather than automated outlier classification. The key techniques are:

- **Quote validation**: only positive bids and asks where ask is at least bid produce valid spreads. Crossed or non-positive quotes are marked and left blank.
- **Basis-point spread calculation**: spread percent is `(Ask - Bid) / Mid * 100`; midpoint fallback is used when mid is missing.
- **Windowed statistics**: last, mean, median, min, max, observation count, and priced-day count.
- **London-aligned peer averaging**: peer spreads are snapped to the anchor fund’s quote dates and averaged per weekday.
- **Return anchoring**: return windows are anchored to the anchor fund’s first usable quote inside the requested period, preventing peers or benchmarks from starting earlier than the fund.

```mermaid
flowchart TD
Start(["Bid, Ask, Mid"]) --> Numeric["Convert to numeric, replace infinities"]
Numeric --> Validity{"Bid > 0 and Ask >= Bid and Mid > 0?"}
Validity --> |No| Blank["Leave spread blank"]
Validity --> |Yes| Spread["Compute Ask - Bid"]
Spread --> Percent["Compute (Ask - Bid) / Mid * 100"]
Percent --> Status["Mark quote status: ok, crossed, missing"]
Status --> Window["Apply period window"]
Window --> Stats["Compute last, mean, median, min, max"]
Stats --> Align["Align to London weekdays via anchor quote dates"]
Align --> PeerAvg["Average peer percent spreads"]
PeerAvg --> Output(["Summary, chart, and comparison series"])
```

**Diagram sources**
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:193-205](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L193-L205)
- [metrics.py:571-581](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L571-L581)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)

**Section sources**
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:193-205](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L193-L205)
- [metrics.py:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L115-L139)
- [metrics.py:274-325](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L274-L325)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)

### Metrics Computation Engine
The metrics engine computes:

- **Period return percentages**: `(end level / start level - 1) * 100`, using total-return index levels.
- **Peer average spread percent**: daily percent spreads for anchor and peers, snapped to anchor quote dates, then averaged.
- **Benchmark return percent**: total-return index change over the anchored window.
- **NAV return percent**: same logic applied to NAV levels.
- **Visible column composition**: identity columns, taxonomy columns, and metric columns based on selected periods and display modes.

```mermaid
sequenceDiagram
participant Anchor as "Anchor Ticker"
participant Peers as "Peer Tickers"
participant Levels as "Total-Return Levels"
participant Quotes as "Quote History"
participant Bench as "Benchmark Index"
participant Metrics as "metrics.py"
Metrics->>Levels : Build level index by ID
Metrics->>Quotes : Build quote print index by ID
Metrics->>Metrics : Compute period window
Metrics->>Metrics : Anchor window to quote dates
Metrics->>Levels : Compute anchor return %
Metrics->>Levels : Compute peer return %
Metrics->>Bench : Compute benchmark return %
Metrics->>Quotes : Snap peer percent spreads to anchor dates
Metrics->>Metrics : Average peer percent spreads
Metrics-->>Anchor : Return %, Peer Avg Return %, Bmk Return %
Metrics-->>Peers : Peer member series
```

**Diagram sources**
- [metrics.py:68-87](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L68-L87)
- [metrics.py:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L115-L139)
- [metrics.py:190-235](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L190-L235)
- [metrics.py:274-325](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L274-L325)
- [metrics.py:357-385](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L357-L385)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)

**Section sources**
- [metrics.py:68-87](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L68-L87)
- [metrics.py:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L115-L139)
- [metrics.py:357-385](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L357-L385)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)
- [metrics.py:584-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L670)

### Configuration Options
Configuration controls the following:

- **Enabled share classes**: the live book keys, labels, currencies, and peer group IDs.
- **Period presets**: `1M`, `3M`, `6M`, `YTD`, `1Y`, `3Y`, `5Y`, and `Custom`.
- **History length**: business-day range for placeholder data.
- **Data sources**: placeholder or Bloomberg for book and peer history.
- **Observation schema**: required columns for spread history.
- **ISIN book**: primary share class per fund, including order and strategy.

These options allow customization of peer groups through `Peer Group ID`, time windows through period presets or custom bounds, and statistical thresholds indirectly through the choice of window length and alignment rules.

**Section sources**
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [config.py:35-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L35-L85)
- [config.py:88-125](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L125)
- [config.py:128-139](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L128-L139)

## Dependency Analysis
The analytical engines have clear dependencies:

- `engine.py` depends on `config.py` for observation columns, period keys, and enabled share classes.
- `metrics.py` depends on `book_view` utilities, `engine.period_bounds`, and `peer_map.fund_name_key`.
- `peers.py` depends on `book_view`, `metrics.return_percents`, and `peer_map.fund_name_key`.
- `flow_view.py` depends on `book_view.london_period_bounds` and `peer_map.fund_name_key`.
- `data.py` depends on `config.py`, `peer_map.py`, and `book_view` utilities.

```mermaid
graph LR
Config["config.py"] --> Engine["engine.py"]
Config --> Data["data.py"]
PeerMap["peer_map.py"] --> Data
PeerMap --> Metrics["metrics.py"]
PeerMap --> Peers["peers.py"]
PeerMap --> Flow["flow_view.py"]
Engine --> Metrics
Data --> Metrics
Data --> Peers
Data --> Flow
```

**Diagram sources**
- [engine.py:15-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L16)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)
- [flow_view.py:7-12](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L12)
- [data.py:27-36](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L36)

**Section sources**
- [engine.py:15-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L16)
- [metrics.py:17-31](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L17-L31)
- [peers.py:7-18](file://User scripts/ETF Spread Monitoring/etf_spread/peers.py#L7-L18)
- [flow_view.py:7-12](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L7-L12)
- [data.py:27-36](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L36)

## Performance Considerations
- **Placeholder vs Bloomberg sources**: placeholder sources are deterministic and fast; Bloomberg sources are currently disconnected and return diagnostics.
- **Business-day history**: placeholder history uses a fixed 1,400 business-day window, which is long enough for five-year presets but may be excessive for quick iteration.
- **Groupby operations**: peer grouping, quote indexing, and flow aggregation use pandas groupby and sort operations; large peer sets can increase memory and CPU usage.
- **Alignment cost**: snapping peer spreads and returns to anchor quote dates requires repeated lookups; keeping precomputed indices helps avoid redundant work.
- **Cache behavior**: the README describes a cache that writes raw request output and recomputes derived fields after merge, reducing repeated Bloomberg calls while preserving formula flexibility.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their likely causes:

- **Unknown period**: selecting an unsupported period key returns empty results and a diagnostic note.
- **Custom period invalid**: missing start/end or start after end produces a blank view.
- **No observations**: empty or all-null date columns result in a blank view.
- **No peer rows**: if peer data is missing from the loaded cache, a note indicates no peer rows are available.
- **Crossed quotes**: crossed bid-ask pairs are left blank and counted in notes.
- **Missing flow columns**: flow matrices require `ID`, `DATE`, and `Flow`; missing columns produce error notes.
- **No HSBC ETF or peer group**: combined flow matrices require at least one HSBC ticker or peer group mapping.
- **Primary listing ambiguity**: peer ISINs with zero or multiple primary listings are skipped with diagnostic notes.

**Section sources**
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [flow_view.py:68-107](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L68-L107)
- [flow_view.py:241-322](file://User scripts/ETF Spread Monitoring/etf_spread/flow_view.py#L241-L322)
- [peer_map.py:85-129](file://User scripts/ETF Spread Monitoring/etf_spread/peer_map.py#L85-L129)

## Conclusion
The ETF spread monitoring system combines configurable book definitions, manual peer mapping, robust observation cleaning, London-aligned benchmarking, and flexible flow aggregation. Its design emphasizes clarity and safety: invalid quotes stay blank, peer mappings are explicit, and derived metrics are computed after data loading so formulas can evolve without breaking cached inputs.

For meaningful spread analysis:

- Use appropriate windows: short windows capture recent liquidity conditions; longer windows smooth noise.
- Inspect peer group construction: ensure peer ISINs resolve to single primary listings and match the intended peer funds.
- Compare spread percent, not just absolute spread: percent spread accounts for price level differences.
- Watch for crossed or missing quotes: they indicate illiquid or problematic sessions rather than zero spreads.
- Interpret flow heatmaps alongside spread changes: outflows often widen spreads, while inflows can tighten them.
- Treat peer averages as context, not guarantees: peer performance does not imply causation for the anchor fund.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Best Practices for Interpreting Results
- Prefer spread percent for cross-price-level comparisons.
- Use anchored return windows to avoid comparing assets over mismatched start dates.
- Review notes for data quality warnings such as unknown periods, missing columns, or ambiguous peer resolutions.
- Combine spread, return, NAV return, and flow signals before labeling an anomaly.
- Validate peer mappings regularly, especially when fund structures or primary listings change.

[No sources needed since this section provides general guidance]