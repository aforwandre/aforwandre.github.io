# BQL Error Handling and Troubleshooting

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [cache.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py)
- [test_cache.py](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py)
- [DECISION_RECORD.md](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md)
- [05-get-started.md](file://RAG KB/05-get-started.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the Bloomberg BQL error handling, retry logic, fallback mechanisms, monitoring, and troubleshooting strategies are implemented in the FI Spread Movement Monitoring project. It focuses on:
- Common error types: network timeouts, rate-limit-like or entitlement failures, authentication-related errors, and data unavailability.
- Retry behavior: bounded retries for timeouts only, with deterministic failure detection to avoid useless re-execution.
- Fallback strategy: a CSV-based result cache that can be served after a timeout when a clean previous run exists.
- Monitoring and logging: per-request timing, attempt counts, field-level status, and step logs.
- Diagnostics: clear stage labels, response diagnostics, empty-response handling, and guidance for reducing request breadth.

The patterns here are production-oriented for BQuant Desktop, where individual BQL requests can time out after two minutes and download limits apply.

## Project Structure
The error-handling surface is concentrated in three modules:
- `fi_spread_movement/data.py`: BQL request building, execution, timeout classification, retry loop, response parsing, and per-field status tracking.
- `fi_spread_movement/app.py`: UI controller, phase/status display, cached fallback decision, and user-visible diagnostics.
- `fi_spread_movement/cache.py`: durable CSV+JSON cache for complete runs, keying by inputs and generation token.

```mermaid
graph TB
App["app.py<br/>UI controller, status, fallback"] --> Data["data.py<br/>BQL access, retry, parsing"]
App --> Cache["cache.py<br/>CSV/JSON run cache"]
Data --> BQL["Bloomberg BQL API<br/>Desktop runtime"]
Tests["tests/test_cache.py<br/>timeout/retry/cache tests"] --> Data
Tests --> Cache
```

**Diagram sources**
- [app.py:1-120](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1-L120)
- [data.py:123-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L215)
- [cache.py:1-56](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L56)
- [test_cache.py:1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)

**Section sources**
- [data.py:1-49](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1-L49)
- [app.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1-L24)
- [cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)

## Core Components
- Timeout classifier and retry loop:
  - `is_timeout` distinguishes recoverable timeouts from deterministic failures such as missing items, entitlement issues, invalid tickers, license problems, and 403 responses.
  - `_execute_attempts` retries only timeouts, rebuilds the request per attempt, records elapsed time and attempts, and appends notes/errors.
- Response normalization and diagnostics:
  - `_item_frame`, `_combined_item`, `_response_item`, and `_normalize_frame` handle multiple Desktop response shapes, including Arrow-style responses without item names.
  - `EmptyResponseError` separates “no rows” from “rejected item.”
- Per-field status and request log:
  - Each request writes a log entry with label, elapsed seconds, attempts, row count, and column summary.
  - Field-level statuses record success, partial availability, or failure without aborting the whole run.
- Cached fallback:
  - `save_run`, `has_run`, `load_run`, and `prune` persist ranked results, descriptors, series, field status, and request logs under a stable key.
  - The app shows a distinct `Cached` phase when serving a previous run after a timeout.

**Section sources**
- [data.py:123-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L215)
- [data.py:470-553](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L470-L553)
- [data.py:780-842](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L842)
- [cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)

## Architecture Overview
The system follows a layered approach:
- UI layer (`app.py`) controls phases, displays status, and decides whether to fall back to cache.
- Data layer (`data.py`) builds BQL requests, executes them with bounded retries, parses responses, and tracks per-field outcomes.
- Persistence layer (`cache.py`) stores complete runs keyed by inputs and pipeline generation.

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "app.py"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Cache as "cache.py"
User->>App : Click Update
App->>Data : fetch_movers(...)
Data->>BQL : bq.execute(Request)
alt Timeout
BQL-->>Data : raises timeout
Data->>Data : is_timeout() + _execute_attempts retry
Data->>BQL : bq.execute(Request) again
BQL-->>Data : response or final failure
else Deterministic failure
BQL-->>Data : raises entitlement/field/ticker error
Data->>Data : no retry
end
Data-->>App : FetchResult with frames, errors, notes, request_log
alt Only timeout failures and clean cache exists
App->>Cache : load_run(key)
Cache-->>App : cached FetchResult + info
App-->>User : Phase "Cached" with reason
else Success or non-timeout failure
App-->>User : Phase "Updated" or "Refused"/"Error"
end
```

**Diagram sources**
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [data.py:153-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L153-L215)
- [cache.py:289-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L289-L348)

## Detailed Component Analysis

### Timeout Classification and Retry Logic
Timeout classification uses explicit markers:
- Recoverable timeout indicators include BQL timeout messages and generic timeout text.
- Deterministic failure indicators include missing data items, entitlement/authorization issues, 403, license problems, invalid tickers, unknown fields, and existence checks.

Retry behavior:
- Only timeouts are retried.
- The request factory is called once per attempt so no stale request state is reused.
- Attempts are bounded by configuration; all failures and elapsed times are recorded.
- Successful retries produce notes indicating which attempt answered.

```mermaid
flowchart TD
Start(["Execute Request"]) --> Try["Call bq.execute(request_factory())"]
Try --> |Success| ReturnOK["Return response and attempt count"]
Try --> |Exception| Classify["is_timeout(exc)?"]
Classify --> |No| RecordFail["Append error and stop"]
Classify --> |Yes| CheckAttempts{"More attempts left?"}
CheckAttempts --> |No| RecordAll["Append all-attempts error"]
CheckAttempts --> |Yes| NoteTimeout["Log timed-out attempt"]
NoteTimeout --> Rebuild["request_factory() again"]
Rebuild --> Try
RecordFail --> End(["Done"])
RecordAll --> End
ReturnOK --> End
```

**Diagram sources**
- [data.py:153-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L153-L215)
- [test_cache.py:95-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L95-L147)

**Section sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [test_cache.py:56-74](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L56-L74)
- [test_cache.py:95-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L95-L147)

### Fallback Mechanism and Cache Strategy
The cache protects against timeouts by serving a previously successful run when:
- The current run failed only due to timeouts.
- A clean cached run exists for the same key.
- The cached run has ranked rows and no failed fields.

Key design points:
- Run keys include source, universe, AIM value, spread code, start/end dates, and TOP_N.
- Generation tokens invalidate old stored results if the pipeline changes.
- Empty runs and runs with failed fields are refused for caching.
- Cache reads never create directories, avoiding read-only project-folder failures.
- Pruning keeps the newest runs and removes orphaned CSV files.

```mermaid
flowchart TD
Run["Run completes"] --> HasErrors{"errors or FAILED fields?"}
HasErrors --> |No| Save["save_run(key, result)"]
HasErrors --> |Yes| IsTimeoutOnly{"_result_is_timeout(result)?"}
IsTimeoutOnly --> |No| Fail["Show Refused/Error"]
IsTimeoutOnly --> |Yes| CheckCache["has_run(key)"]
CheckCache --> |No| Fail
CheckCache --> |Yes| Load["load_run(key)"]
Load --> Serve["Phase 'Cached' with info"]
Save --> Done["Phase 'Updated'"]
Fail --> Done
Serve --> Done
```

**Diagram sources**
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)
- [DECISION_RECORD.md:842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

**Section sources**
- [cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)
- [cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)
- [cache.py:379-427](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L427)
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [DECISION_RECORD.md:842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

### Response Parsing and Partial Data Handling
The parser supports multiple Desktop response shapes:
- Named item lookup via `.get(name)` and index access.
- Combined frame fallback using `bql.combined_df(response)` when item names are not exposed.
- Strict validation for single-value columns to avoid mislabeling measures.
- Empty responses are distinguished from naming mismatches.

Partial data handling:
- Descriptor and duration-family requests continue even if some fields fail.
- Missing columns remain absent rather than being filled with zeros.
- Duplicate IDs are handled safely, keeping the last value per ID.
- Merge failures degrade gracefully and are recorded as per-field failures.

```mermaid
flowchart TD
Resp["BQL response"] --> GetItem["_response_item(name)"]
GetItem --> |Found| Normalize["_normalize_frame(df)"]
GetItem --> |Not found| Combined["bql.combined_df(response)"]
Combined --> OneValue{"Exactly one value column?"}
OneValue --> |Yes| Normalize
OneValue --> |No| RaiseName["Raise ValueError with diagnostics"]
Normalize --> EmptyCheck{"len(response)==0?"}
EmptyCheck --> |Yes| EmptyErr["EmptyResponseError"]
EmptyCheck --> |No| Finalize["Finalize ID/date/value"]
EmptyErr --> Continue["Continue run with 0-row frame"]
Finalize --> Done
```

**Diagram sources**
- [data.py:470-553](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L470-L553)
- [data.py:610-742](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L610-L742)
- [data.py:745-777](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L745-L777)

**Section sources**
- [data.py:470-553](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L470-L553)
- [data.py:610-742](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L610-L742)
- [data.py:745-777](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L745-L777)
- [data.py:863-915](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L863-L915)

### Monitoring, Logging, and Status Reporting
Monitoring includes:
- Per-request log entries with label, elapsed time, attempts, row count, and columns.
- Field-level status strings describing returned rows, null counts, or failures.
- Notes for diagnostic context, such as duplicate IDs, empty responses, and effective-date checks.
- UI phases: Idle, Loading, Updated, Refused, Error, and Cached.
- Step log lines for each update stage: request, prepare, check, render.

Best practices visible in the code:
- Never hide a failed field behind a green Updated status.
- Always name the failing stage.
- Preserve original request inputs for labeling cached screens.
- Keep request metadata separate from displayed data.

**Section sources**
- [data.py:780-842](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L842)
- [data.py:1092-1168](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1092-L1168)
- [app.py:63-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L63-L86)
- [app.py:185-222](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L185-L222)
- [app.py:1394-1432](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1394-L1432)

### Diagnostic Tools and Techniques
Useful diagnostics:
- `_exception_site` extracts the innermost traceback location for banner messages.
- `_explain_ranking_error` adds readable context for BQL refusal messages.
- `_note_empty_universe` suggests next steps for empty rankings based on source type and date anchors.
- Response diagnostics print response type, item count, and available names.

Techniques for debugging:
- Inspect `FetchResult.errors`, `FetchResult.notes`, and `FetchResult.request_log`.
- Use the Export Excel tab to review request receipts and field statuses.
- Reduce universe size, date range, or item breadth when timeouts recur.
- Prefer cached mode where supported and split wide requests into families.

**Section sources**
- [app.py:89-105](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L89-L105)
- [data.py:1322-1360](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1322-L1360)
- [data.py:1505-1589](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1505-L1589)
- [data.py:451-467](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L451-L467)

## Dependency Analysis
The main dependencies and relationships are:
- `app.py` depends on `data.py` for fetching, timeout classification, and normalization.
- `app.py` depends on `cache.py` for manual cache loading and automatic fallback decisions.
- `data.py` depends on the BQL service and pandas for DataFrame operations.
- Tests validate timeout classification, retry bounds, and cache round-trips.

```mermaid
graph LR
Test["tests/test_cache.py"] --> DataMod["data.py"]
Test --> CacheMod["cache.py"]
AppMod["app.py"] --> DataMod
AppMod --> CacheMod
DataMod --> BQL["bql.Service / bql.Request"]
```

**Diagram sources**
- [test_cache.py:1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)
- [app.py:38-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L38-L61)
- [data.py:65-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L65-L70)

**Section sources**
- [test_cache.py:1-26](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L1-L26)
- [app.py:38-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L38-L61)
- [data.py:65-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L65-L70)

## Performance Considerations
- Desktop BQL requests can time out after two minutes; reduce universes, date ranges, and item breadth.
- Split wide requests into families; the duration family is already grouped into one request.
- Prefer `with_params={'mode': 'cached'}` where supported.
- Avoid unbounded pulls and keep candidate lists bounded by ranking.
- Cache complete runs to avoid repeated expensive work after timeouts.
- Monitor request logs to identify slow or broad requests.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Common Error Types and Handling Strategies
- Network timeouts:
  - Detected by timeout markers.
  - Retried up to the configured number of attempts.
  - If only timeouts occurred and a clean cache exists, serve the cached run with phase `Cached`.
- Rate limiting or entitlement failures:
  - Marked as deterministic by markers such as entitlement, authorization, 403, license, invalid ticker, unknown field, or missing data item.
  - No retry is attempted.
  - Field-level status records the failure; the run continues if other fields succeed.
- Authentication failures:
  - Treated as deterministic; do not retry.
  - Verify Terminal session, BBA/session connection, and entitlements.
- Data unavailability:
  - Empty responses are reported distinctly from rejected item names.
  - Missing values remain absent; zero is not fabricated.
  - Empty rankings include contextual notes suggesting date-anchor fixes.

**Section sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:470-553](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L470-L553)
- [data.py:863-915](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L863-L915)
- [data.py:1505-1589](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1505-L1589)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### Retry Behavior Reference
- Only timeouts are retried.
- Deterministic failures are never retried.
- Requests are rebuilt per attempt.
- All attempts and elapsed times are logged.

**Section sources**
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [test_cache.py:95-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L95-L147)

### Fallback Behavior Reference
- Automatic fallback fires only for timeout-only failures.
- Mixed failures (timeout plus deterministic failure) are treated as deterministic.
- Cached runs are labeled `Cached`, never `Updated`.
- Manual cache loading is available through the UI.

**Section sources**
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [DECISION_RECORD.md:842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

### Monitoring and Logging Checklist
- Inspect the status bar phase and environment line.
- Review the detail box for request totals and errors.
- Read the step log for stage-specific messages.
- Export Excel to inspect per-field status and request receipts.
- Track `elapsed_sec`, `attempts`, `rows`, and `columns` in request logs.

**Section sources**
- [app.py:63-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L63-L86)
- [app.py:185-222](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L185-L222)
- [data.py:780-842](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L842)

### Best Practices for Bloomberg API Limitations
- Keep universes and filters tight.
- Split wide requests into families.
- Use bounded candidate lists derived from ranking.
- Prefer cached mode where supported.
- Treat empty answers as data facts, not field spelling errors.
- Do not widen universes after entitlement or mapping failures.
- Do not silently substitute different product-family proxies.

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [DECISION_RECORD.md:842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

## Conclusion
The FI Spread Movement Monitoring project implements robust BQL error handling tailored for BQuant Desktop constraints. Timeouts are retried with bounded attempts, while deterministic failures are immediately surfaced without wasteful retries. Partial data failures are preserved transparently, and a durable cache provides a safe fallback after timeouts. Monitoring and logging are detailed at the request and field levels, and the UI clearly communicates phases, stages, and reasons. Following these patterns helps operators diagnose failures quickly, respect Bloomberg’s API limitations, and maintain reliable, observable workflows.