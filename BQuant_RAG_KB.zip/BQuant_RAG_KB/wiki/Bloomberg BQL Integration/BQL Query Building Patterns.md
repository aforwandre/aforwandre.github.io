# BQL Query Building Patterns

<cite>
**Referenced Files in This Document**
- [01-bql-for-equities.md](file://RAG KB/01-bql-for-equities.md)
- [02-bql-for-fixed-income.md](file://RAG KB/02-bql-for-fixed-income.md)
- [07-pybql-api-reference.md](file://RAG KB/07-pybql-api-reference.md)
- [08-bql-data-items.md](file://RAG KB/08-bql-data-items.md)
- [12-bql-fixed-income-screening.md](file://RAG KB/12-bql-fixed-income-screening.md)
- [data.py (ETF Capping Monitoring)](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [data.py (ETF Spread Monitoring)](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [data.py (FI Index Change)](file://User scripts/FI Index Change/fi_index_change/data.py)
- [data.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains Bloomberg BQL query building patterns used across the platform’s equity, fixed income, portfolio, and monitoring applications. It covers:
- Common query structures for portfolio analysis, market data retrieval, and reference data lookups.
- Field selection strategies, filtering with `univ.filter`, and aggregation through group-prefix functions.
- Pagination and batch processing using chunked requests and `execute_many`.
- Complex multi-source queries combining universes, index series, FX, and derived calculations.
- Optimization techniques such as field minimization, efficient filtering, caching, and request splitting.
- Error handling, graceful degradation, and debugging practices for constructing and testing BQL queries.

The guidance is grounded in both canonical knowledge-base recipes and production application code that executes real BQL requests on Bloomberg BQuant Desktop.

## Project Structure
The repository contains two complementary layers:
- Knowledge-base recipes describing canonical BQL patterns for equities, fixed income, screening, API semantics, and data-item traps.
- Production application modules implementing those patterns for ETF capping, ETF spread monitoring, FI index change tracking, and FI spread movement monitoring.

```mermaid
graph TB
KB_Equity["Equity BQL Recipes"]
KB_FI["Fixed Income BQL Recipes"]
KB_API["PyBQL API Reference"]
KB_Semantics["Data Item Semantics"]
KB_Screen["Fixed Income Screening"]
App_Cap["ETF Capping Monitoring"]
App_Spread["ETF Spread Monitoring"]
App_Index["FI Index Change"]
App_Move["FI Spread Movement Monitoring"]
KB_Equity --> App_Cap
KB_FI --> App_Index
KB_FI --> App_Move
KB_API --> App_Cap
KB_API --> App_Spread
KB_API --> App_Index
KB_API --> App_Move
KB_Semantics --> App_Cap
KB_Semantics --> App_Spread
KB_Screen --> App_Index
KB_Screen --> App_Move
```

**Diagram sources**
- [01-bql-for-equities.md:15-28](file://RAG KB/01-bql-for-equities.md#L15-L28)
- [02-bql-for-fixed-income.md:15-28](file://RAG KB/02-bql-for-fixed-income.md#L15-L28)
- [07-pybql-api-reference.md:15-38](file://RAG KB/07-pybql-api-reference.md#L15-L38)
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [12-bql-fixed-income-screening.md:15-47](file://RAG KB/12-bql-fixed-income-screening.md#L15-L47)

**Section sources**
- [01-bql-for-equities.md:15-28](file://RAG KB/01-bql-for-equities.md#L15-L28)
- [02-bql-for-fixed-income.md:15-28](file://RAG KB/02-bql-for-fixed-income.md#L15-L28)
- [07-pybql-api-reference.md:15-38](file://RAG KB/07-pybql-api-reference.md#L15-L38)
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [12-bql-fixed-income-screening.md:15-47](file://RAG KB/12-bql-fixed-income-screening.md#L15-L47)

## Core Components
At the center of every BQL workflow are three PyBQL namespaces and their execution contract:
- `bq.data` for data items such as prices, spreads, yields, ratings, identifiers, and classifications.
- `bq.func` for transformations such as ranges, time-series changes, grouping, ranking, z-scores, logic, and string operations.
- `bq.univ` for universe construction such as index members, bond chains, holdings, holders, screens, and list-based universes.
- `bql.Request` encapsulates a universe plus requested items and optional global parameters.
- `bql.Service.execute` / `execute_many` execute one or many requests and return response objects that must be converted to DataFrames.

```mermaid
flowchart LR
S["bq = bql.Service()"] --> D["bq.data.*"]
S --> F["bq.func.*"]
S --> U["bq.univ.*"]
D --> R["bql.Request(universe, items)"]
F --> R
U --> R
R --> E["bq.execute(...)"]
E --> DF["item.df() / pd.concat(...)"]
```

**Diagram sources**
- [07-pybql-api-reference.md:28-38](file://RAG KB/07-pybql-api-reference.md#L28-L38)
- [07-pybql-api-reference.md:96-136](file://RAG KB/07-pybql-api-reference.md#L96-L136)

Key responsibilities:
- Universe definition determines which securities are queried.
- Data items determine which fields are returned.
- Functions transform values, dates, groups, ranks, and predicates.
- Requests package everything for execution.
- Responses are normalized into stable DataFrame shapes before analytics.

**Section sources**
- [07-pybql-api-reference.md:28-38](file://RAG KB/07-pybql-api-reference.md#L28-L38)
- [07-pybql-api-reference.md:96-136](file://RAG KB/07-pybql-api-reference.md#L96-L136)

## Architecture Overview
The platform follows a layered architecture:
- Recipe layer: canonical BQL patterns for equities, fixed income, screening, API signatures, and data-item semantics.
- Application layer: production modules that build requests, execute them in batches, parse responses, handle errors, and present results.
- Bloomberg layer: BQL server returns item responses, sometimes as Arrow-backed response objects with non-standard iteration behavior.

```mermaid
graph TB
subgraph "Recipe Layer"
RE["Equity Recipes"]
RF["Fixed Income Recipes"]
RA["PyBQL API"]
RS["Data Item Semantics"]
end
subgraph "Application Layer"
AC["ETF Capping Monitoring"]
AS["ETF Spread Monitoring"]
AI["FI Index Change"]
AM["FI Spread Movement Monitoring"]
end
subgraph "Bloomberg Layer"
BQ["BQL Service"]
SRV["BQL Server"]
end
RE --> AC
RF --> AI
RF --> AM
RA --> AC
RA --> AS
RA --> AI
RA --> AM
RS --> AC
RS --> AS
AC --> BQ
AS --> BQ
AI --> BQ
AM --> BQ
BQ --> SRV
```

**Diagram sources**
- [01-bql-for-equities.md:15-28](file://RAG KB/01-bql-for-equities.md#L15-L28)
- [02-bql-for-fixed-income.md:15-28](file://RAG KB/02-bql-for-fixed-income.md#L15-L28)
- [07-pybql-api-reference.md:15-38](file://RAG KB/07-pybql-api-reference.md#L15-L38)
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)

## Detailed Component Analysis

### Portfolio Analysis Patterns
Portfolio analysis commonly combines:
- A portfolio or holdings universe.
- Static identifiers and weights.
- Market or fundamental fields.
- Weight-aware aggregations.

Common patterns:
- Use `bq.univ.members(..., type='PORT')` or `bq.univ.holdings(...)` for portfolio inputs.
- Extract weights via `bq.data.id()['WEIGHTS']` for holdings/portfolios, and `bq.data.id()['weights']` for index members.
- Combine price, volume, name, and weight columns by concatenating per-item DataFrames.
- Use group-weighted averages when computing portfolio-level metrics.

```mermaid
sequenceDiagram
participant User as "Portfolio Analyst"
participant App as "Portfolio Adapter"
participant BQL as "bql.Request"
participant Service as "bq.execute"
participant DF as "DataFrame Merge"
User->>App : "Portfolio ID or holdings"
App->>BQL : "members(type='PORT') or holdings()"
BQL-->>Service : "Request with Name, Price, Weights"
Service-->>App : "Response items"
App->>DF : "Concat + merge static fields"
DF-->>User : "Weighted portfolio view"
```

**Diagram sources**
- [01-bql-for-equities.md:259-279](file://RAG KB/01-bql-for-equities.md#L259-L279)
- [02-bql-for-fixed-income.md:261-280](file://RAG KB/02-bql-for-fixed-income.md#L261-L280)

Practical notes:
- Do not assume lowercase and uppercase weight keys are interchangeable.
- Keep universe branch and weight recipe together because shape contracts differ between `members()` and `holdings()`.
- For portfolio attribution, use verified member weights rather than market-cap weights unless explicitly intended.

**Section sources**
- [01-bql-for-equities.md:259-279](file://RAG KB/01-bql-for-equities.md#L259-L279)
- [02-bql-for-fixed-income.md:261-280](file://RAG KB/02-bql-for-fixed-income.md#L261-L280)
- [08-bql-data-items.md:97-108](file://RAG KB/08-bql-data-items.md#L97-L108)

### Market Data Retrieval Patterns
Market data retrieval typically involves:
- Point-in-time prices or time series.
- Date ranges built with `bq.func.range`.
- Missing-day handling with `fill='prev'` and `dropna`.
- Percent or net changes over bounded windows.

Typical flow:
- Define universe and date range.
- Request price or yield series.
- Apply `.pct_chg()`, `.net_chg()`, or `.diff()` where appropriate.
- Concatenate multiple items and align on ID and DATE.

```mermaid
flowchart TD
Start(["Start"]) --> Univ["Define universe"]
Univ --> Range["Build bq.func.range(start, end)"]
Range --> Item["Select bq.data.px_last / yield_ / spread"]
Item --> Transform["Apply pct_chg / net_chg / dropna"]
Transform --> Execute["bq.execute(Request)"]
Execute --> Normalize["Normalize ID/DATE/value"]
Normalize --> End(["Return DataFrame"])
```

**Diagram sources**
- [01-bql-for-equities.md:104-140](file://RAG KB/01-bql-for-equities.md#L104-L140)
- [02-bql-for-fixed-income.md:144-177](file://RAG KB/02-bql-for-fixed-income.md#L144-L177)
- [07-pybql-api-reference.md:379-410](file://RAG KB/07-pybql-api-reference.md#L379-L410)

**Section sources**
- [01-bql-for-equities.md:104-140](file://RAG KB/01-bql-for-equities.md#L104-L140)
- [02-bql-for-fixed-income.md:144-177](file://RAG KB/02-bql-for-fixed-income.md#L144-L177)
- [07-pybql-api-reference.md:379-410](file://RAG KB/07-pybql-api-reference.md#L379-L410)

### Reference Data Lookup Patterns
Reference data lookups include:
- Company names, classifications, currencies, IDs, and status.
- Fundamental ticker mapping.
- Capital structure parent mappings and Bloomberg company identifiers.
- Thai local pricing identity fallbacks for special cases.

Recommended approach:
- Use exact mnemonic discovery in the data-item catalog.
- Prefer `bq.data.name()` and `bq.data.market_status()` for descriptors.
- Map companies via `bq.data.id().value(bq.univ.fundamentalticker(), mapby='lineage')` to preserve input rows.
- Avoid substituting unrelated identifiers such as CAST parent tickers or integer company IDs for pricing identities.

```mermaid
flowchart TD
Input["Input Ticker"] --> Desc["Name + Market Status"]
Input --> Fund["Fundamental Ticker Mapping"]
Fund --> Validate{"Same company?"}
Validate --> |Yes| Local["Use validated local pricing ticker"]
Validate --> |No| Fallback["Fallback mapping or unresolved state"]
Desc --> Output["Descriptor DataFrame"]
Local --> Output
Fallback --> Output
```

**Diagram sources**
- [08-bql-data-items.md:241-276](file://RAG KB/08-bql-data-items.md#L241-L276)
- [08-bql-data-items.md:316-414](file://RAG KB/08-bql-data-items.md#L316-L414)

**Section sources**
- [08-bql-data-items.md:241-276](file://RAG KB/08-bql-data-items.md#L241-L276)
- [08-bql-data-items.md:316-414](file://RAG KB/08-bql-data-items.md#L316-L414)

### Filtering Techniques Using WHERE Clauses
BQL filtering uses `univ.filter` with chained logical predicates:
- Equality, membership, and range tests.
- `and_()` for intersections.
- `or_()` for unions.
- Group-prefix filters such as `grouprank`, `groupzscore`, and `groupmedian`.

Patterns:
- Build boolean expressions from data items.
- Chain predicates with trailing underscore methods.
- Apply group-relative thresholds before requesting output fields.

```mermaid
flowchart TD
Base["Base Universe"] --> Pred1["Predicate 1"]
Base --> Pred2["Predicate 2"]
Pred1 --> And["and_()"]
Pred2 --> And
And --> Filter["univ.filter(combined_predicate)"]
Filter --> Items["Request filtered universe"]
```

**Diagram sources**
- [01-bql-for-equities.md:323-487](file://RAG KB/01-bql-for-equities.md#L323-L487)
- [12-bql-fixed-income-screening.md:88-107](file://RAG KB/12-bql-fixed-income-screening.md#L88-L107)

**Section sources**
- [01-bql-for-equities.md:323-487](file://RAG KB/01-bql-for-equities.md#L323-L487)
- [12-bql-fixed-income-screening.md:88-107](file://RAG KB/12-bql-fixed-income-screening.md#L88-L107)

### Aggregation Functions
Aggregations are expressed through group-prefix functions:
- `group().avg()`, `wavg()`, `sum()`, `median()`.
- `groupzscore()`, `grouprank()`, `groupsort()`.
- `cut()` and `ungroup()` for quantile buckets.
- `rolling()` for time-sliced evaluation.

Best practices:
- Group by classification, rating, maturity bucket, or sector.
- Use weights only when the universe supports them.
- Winsorize before averaging when outliers matter.
- Ungroup when per-ID projection is required.

```mermaid
flowchart TD
Values["Value Series"] --> Group["group(by=category)"]
Group --> Stats["avg / sum / median / zscore / rank"]
Stats --> Ungrp["ungroup() if per-ID needed"]
Ungrp --> Output["Grouped metric per ID"]
```

**Diagram sources**
- [01-bql-for-equities.md:282-319](file://RAG KB/01-bql-for-equities.md#L282-L319)
- [02-bql-for-fixed-income.md:293-438](file://RAG KB/02-bql-for-fixed-income.md#L293-L438)
- [07-pybql-api-reference.md:256-342](file://RAG KB/07-pybql-api-reference.md#L256-L342)

**Section sources**
- [01-bql-for-equities.md:282-319](file://RAG KB/01-bql-for-equities.md#L282-L319)
- [02-bql-for-fixed-income.md:293-438](file://RAG KB/02-bql-for-fixed-income.md#L293-L438)
- [07-pybql-api-reference.md:256-342](file://RAG KB/07-pybql-api-reference.md#L256-L342)

### Pagination Handling and Batch Processing
Large datasets are handled by:
- Chunking identifier lists into small batches.
- Building one `bql.Request` per batch.
- Executing batches with `bq.execute_many`.
- Parsing each response independently.
- Merging results locally after successful execution.

Production examples:
- ETF capping monitors AIM accounts and security descriptors in chunks.
- ETF spread monitoring splits share-class requests and merges ID+DATE frames.
- FI index change tracks historical snapshots and retries only timeouts.
- FI spread movement monitoring limits candidate series and avoids widening universes.

```mermaid
sequenceDiagram
participant App as "Application"
participant Chunk as "Chunker"
participant Many as "execute_many"
participant Parser as "Response Parser"
participant Merge as "Local Merge"
App->>Chunk : "Split IDs/accounts/batches"
loop For each batch
Chunk->>Many : "List of bql.Request"
Many-->>Parser : "Responses per batch"
Parser-->>Merge : "Normalized frames"
end
Merge-->>App : "Final dataset"
```

**Diagram sources**
- [data.py (ETF Capping Monitoring):48-54](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L48-L54)
- [data.py (ETF Capping Monitoring):259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py (ETF Spread Monitoring):573-601](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L573-L601)
- [data.py (FI Index Change):637-698](file://User scripts/FI Index Change/fi_index_change/data.py#L637-L698)
- [data.py (FI Spread Movement Monitoring):329-331](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L329-L331)

**Section sources**
- [data.py (ETF Capping Monitoring):48-54](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L48-L54)
- [data.py (ETF Capping Monitoring):259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py (ETF Spread Monitoring):573-601](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L573-L601)
- [data.py (FI Index Change):637-698](file://User scripts/FI Index Change/fi_index_change/data.py#L637-L698)
- [data.py (FI Spread Movement Monitoring):329-331](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L329-L331)

### Complex Multi-Source Queries
Complex queries combine:
- Equity universes and bond chains.
- Index constituents at point-in-time.
- Cash flows, spreads, yields, durations, and ratings.
- FX conversions and derived calculations.
- Index-level series injected via `bq.func.value`.

Examples:
- A/H dual-listing premium: map H to A, retrieve both prices, fetch FX, merge on DATE, compute premium, then rolling statistics.
- Index attribution: freeze index membership, group by classification, inject index level, compute breadth and contribution.
- Issuer curve comparison: pull issuer bonds, apply currency/rating/maturity filters, fit regression against sector benchmark.
- Securitised product screen: narrow mortgage universe, then drill into single-security cashflows and scenarios.

```mermaid
flowchart TD
U1["Equity Universe"] --> Chain["Bond Chain / Debt Universe"]
U2["Index Members"] --> Attr["Attribution / Breadth"]
CF["Cashflows"] --> Agg["Aggregate by Year/Month"]
FX["FX Rates"] --> Conv["Currency Conversion"]
Derive["Derived Metrics"] --> Final["Final Analytics Frame"]
Chain --> Derive
Attr --> Derive
Agg --> Derive
Conv --> Derive
```

**Diagram sources**
- [01-bql-for-equities.md:741-761](file://RAG KB/01-bql-for-equities.md#L741-L761)
- [01-bql-for-equities.md:710-739](file://RAG KB/01-bql-for-equities.md#L710-L739)
- [02-bql-for-fixed-income.md:513-559](file://RAG KB/02-bql-for-fixed-income.md#L513-L559)
- [02-bql-for-fixed-income.md:561-591](file://RAG KB/02-bql-for-fixed-income.md#L561-L591)

**Section sources**
- [01-bql-for-equities.md:710-761](file://RAG KB/01-bql-for-equities.md#L710-L761)
- [02-bql-for-fixed-income.md:513-591](file://RAG KB/02-bql-for-fixed-income.md#L513-L591)

### Query Optimization Techniques
Optimization focuses on minimizing network and server work while preserving analytical correctness:
- Field minimization: request only the fields needed for the current step.
- Efficient filtering: push filters into `univ.filter` before requesting heavy analytics.
- Cached mode: use `with_params={'mode': 'cached'}` for large screens, broad universes, and repeated snapshots.
- Request splitting: separate identity fields from expensive analytics families.
- Bounded date ranges: avoid unbounded histories; prefer relative ranges and explicit start/end.
- Local deduplication and merging: normalize ID and DATE before joining.

Evidence in production:
- ETF capping uses cached mode for fundamentals and descriptor batches.
- ETF spread monitoring merges sparse time-series and static frames on ID+DATE.
- FI index change splits identity and analytics groups and refuses cache when required columns are missing.
- FI spread movement monitoring caps candidate series and avoids widening universes.

**Section sources**
- [data.py (ETF Capping Monitoring):503-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L503-L531)
- [data.py (ETF Spread Monitoring):466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)
- [data.py (FI Index Change):637-698](file://User scripts/FI Index Change/fi_index_change/data.py#L637-L698)
- [data.py (FI Spread Movement Monitoring):1-49](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1-L49)

### Error Handling and Graceful Degradation
Robust BQL code distinguishes:
- Successful but empty responses.
- Valid response objects that are not iterable.
- Deterministic failures such as invalid tickers, unknown fields, or entitlement issues.
- Timeouts that may recover on retry due to warmed server-side caches.

Production patterns:
- Check whether a value looks like a response without requiring iteration.
- Try named access, index access, and `combined_df` fallback.
- Parse each response into a normalized frame and record errors separately.
- Retry only timeout-like exceptions; do not retry deterministic failures.
- Return partial results when some measure groups fail, rather than failing the whole run.

```mermaid
flowchart TD
Exec["Execute Request"] --> Resp{"Looks like response?"}
Resp --> |No| LogErr["Log error tuple / exception"]
Resp --> |Yes| Access["Try .get(name), index, combined_df"]
Access --> Parse["Normalize to ID(+DATE)+value"]
Parse --> Empty{"Empty or missing key columns?"}
Empty --> |Yes| Partial["Record note / partial status"]
Empty --> |No| Success["Return usable frame"]
LogErr --> Timeout{"Timeout marker?"}
Timeout --> |Yes| Retry["Retry once"]
Timeout --> |No| Fail["Fail closed"]
```

**Diagram sources**
- [data.py (ETF Capping Monitoring):57-98](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L57-L98)
- [data.py (ETF Capping Monitoring):237-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L284)
- [data.py (FI Index Change):499-595](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L595)
- [data.py (FI Spread Movement Monitoring):123-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L215)

**Section sources**
- [data.py (ETF Capping Monitoring):57-98](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L57-L98)
- [data.py (ETF Capping Monitoring):237-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L284)
- [data.py (FI Index Change):499-595](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L595)
- [data.py (FI Spread Movement Monitoring):123-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L215)

### Debugging Techniques for Constructing and Testing BQL Queries
Debugging should follow a disciplined path:
- Verify universe syntax before adding data items.
- Confirm exact data-item mnemonics in the catalog.
- Inspect response column names and index structure.
- Separate parsing defects from blank values.
- Test with small batches before scaling to full universes.
- Use request strings and response diagnostics to identify mismatches.

Recommended steps:
- Print or log `request.to_string()` when available.
- Capture response type and exposed item names.
- Normalize frames to a common ID and DATE schema.
- Record missing items, empty columns, and duplicate IDs.
- Avoid assuming that a column exists just because it was requested.

**Section sources**
- [07-pybql-api-reference.md:102-111](file://RAG KB/07-pybql-api-reference.md#L102-L111)
- [08-bql-data-items.md:37-49](file://RAG KB/08-bql-data-items.md#L37-L49)
- [data.py (ETF Spread Monitoring):378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)
- [data.py (FI Index Change):351-405](file://User scripts/FI Index Change/fi_index_change/data.py#L351-L405)

## Dependency Analysis
The main dependency relationships are:
- Applications depend on canonical recipes for correct universe and field usage.
- Applications depend on PyBQL API semantics for request/response behavior.
- Applications depend on data-item semantics for metadata, traps, and identity rules.
- Production parsers depend on robust response inspection because Desktop Arrow responses can be valid but non-iterable.

```mermaid
graph LR
AppC["ETF Capping Monitoring"] --> KB01["Equity Recipes"]
AppC --> KB07["PyBQL API"]
AppC --> KB08["Data Item Semantics"]
AppS["ETF Spread Monitoring"] --> KB07
AppS --> KB08
AppI["FI Index Change"] --> KB02["Fixed Income Recipes"]
AppI --> KB12["FI Screening"]
AppI --> KB07
AppM["FI Spread Movement Monitoring"] --> KB02
AppM --> KB12
AppM --> KB07
```

**Diagram sources**
- [01-bql-for-equities.md:15-28](file://RAG KB/01-bql-for-equities.md#L15-L28)
- [02-bql-for-fixed-income.md:15-28](file://RAG KB/02-bql-for-fixed-income.md#L15-L28)
- [07-pybql-api-reference.md:15-38](file://RAG KB/07-pybql-api-reference.md#L15-L38)
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [12-bql-fixed-income-screening.md:15-47](file://RAG KB/12-bql-fixed-income-screening.md#L15-L47)

**Section sources**
- [01-bql-for-equities.md:15-28](file://RAG KB/01-bql-for-equities.md#L15-L28)
- [02-bql-for-fixed-income.md:15-28](file://RAG KB/02-bql-for-fixed-income.md#L15-L28)
- [07-pybql-api-reference.md:15-38](file://RAG KB/07-pybql-api-reference.md#L15-L38)
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [12-bql-fixed-income-screening.md:15-47](file://RAG KB/12-bql-fixed-income-screening.md#L15-L47)

## Performance Considerations
To keep BQL workflows fast and reliable:
- Minimize fields: request only what is needed for the current step.
- Push filters early: use `univ.filter` with cheap static fields before expensive analytics.
- Use cached mode for large screens and repeated snapshots.
- Split requests: separate identity columns from expensive analytics families.
- Bound dates: use relative ranges and explicit windows instead of open-ended histories.
- Normalize and deduplicate locally: avoid positional concatenation when ID/DATE alignment matters.
- Retry cautiously: retry only timeouts, not deterministic failures.

These patterns appear consistently across ETF capping, ETF spread monitoring, FI index change, and FI spread movement monitoring.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common problems and resolutions:
- Invalid universe grammar: pass function objects such as `bq.univ.members(...)`, not Python strings containing function calls.
- Wrong weight key case: `members()` uses lowercase `'weights'`; `holdings()` and portfolios use uppercase `'WEIGHTS'`.
- Missing ID or DATE: normalize frames to a stable ID and DATE schema before merging.
- Non-iterable response: treat Arrow-backed responses as valid even when they cannot be iterated directly.
- Unknown field or entitlement error: do not retry; fix the mnemonic or entitlement.
- Blank values vs missing columns: distinguish parsed-but-empty columns from items that did not arrive.
- Month-end index membership: use last business day, not calendar month-end on weekends.
- MBS/TBA noise: isolate mortgage-backed and TBA rows using security type and ID masks.

**Section sources**
- [07-pybql-api-reference.md:96-101](file://RAG KB/07-pybql-api-reference.md#L96-L101)
- [08-bql-data-items.md:97-108](file://RAG KB/08-bql-data-items.md#L97-L108)
- [02-bql-for-fixed-income.md:639-683](file://RAG KB/02-bql-for-fixed-income.md#L639-L683)
- [data.py (ETF Capping Monitoring):57-98](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L57-L98)
- [data.py (FI Index Change):499-595](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L595)

## Conclusion
Effective BQL query building in this platform balances canonical correctness with production resilience. The best patterns:
- Use canonical recipes for universe and field semantics.
- Keep requests narrow and filter-heavy.
- Normalize responses into stable ID/DATE/value shapes.
- Batch and split requests for large datasets.
- Cache safely and refuse incomplete snapshots.
- Handle errors explicitly and degrade gracefully.
- Debug systematically by validating universes, mnemonics, response shapes, and parser assumptions.

When these patterns are followed, BQL queries become predictable, auditable, and scalable across equity portfolios, fixed income screens, reference data lookups, and complex multi-source analytics.

[No sources needed since this section summarizes without analyzing specific files]