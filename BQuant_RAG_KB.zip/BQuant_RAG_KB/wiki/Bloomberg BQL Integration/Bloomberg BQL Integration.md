# Bloomberg BQL Integration

<cite>
**Referenced Files in This Document**   
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md](file://RAG KB/05-get-started.md)
- [06-get-data-overview.md](file://RAG KB/06-get-data-overview.md)
- [07-pybql-api-reference.md](file://RAG KB/07-pybql-api-reference.md)
- [08-bql-data-items.md](file://RAG KB/08-bql-data-items.md)
- [01-bql-for-equities.md](file://RAG KB/01-bql-for-equities.md)
- [02-bql-for-fixed-income.md](file://RAG KB/02-bql-for-fixed-income.md)
- [13-bql-for-economics.md](file://RAG KB/13-bql-for-economics.md)
- [14-bql-for-port-prep.md](file://RAG KB/14-bql-for-port-prep.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains how Bloomberg Query Language (BQL) is integrated into the platform through the PyBQL client, BQuant Desktop runtime, and the project’s domain-specific recipes for equities, fixed income, economics, and portfolio reporting. It covers service configuration, authentication assumptions, connection management, query-building patterns, data item semantics, error handling, retry behavior, caching, performance optimization, debugging guidance, and example workflows for portfolio analysis, market data retrieval, and reference data lookups.

The workspace enforces a strict boundary: design and review code locally in Cursor, but execute BQL only on the Bloomberg-managed Desktop environment. Desktop has download limits, a two-minute request timeout, and concurrency constraints that shape every production pattern.

**Section sources**
- [instruction.md:1-10](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-51](file://RAG KB/05-get-started.md#L21-L51)

## Project Structure
The repository organizes BQL knowledge and usage around canonical topic files rather than a single application module:

- `RAG KB/05-get-started.md` defines the Desktop workflow, kernel state rules, and hard limits.
- `RAG KB/06-get-data-overview.md` documents the universal Request flow and field discovery policy.
- `RAG KB/07-pybql-api-reference.md` provides the PyBQL object model: `Service`, `Request`, `Response`, `data`, `func`, `univ`.
- `RAG KB/08-bql-data-items.md` curates data-item semantics, traps, and exceptions.
- `RAG KB/01-bql-for-equities.md`, `RAG KB/02-bql-for-fixed-income.md`, `RAG KB/13-bql-for-economics.md`, and `RAG KB/14-bql-for-port-prep.md` provide asset-class and portfolio recipes.
- `instruction.md` contains operational guardrails, including Desktop-only execution and project-scoped development.

```mermaid
flowchart LR
Local["Local Cursor<br/>Design & Review"] --> Copy["Copy to BQuant Desktop"]
Copy --> Execute["Run BQL Requests"]
Execute --> Response["PyBQL Response"]
Response --> DataFrame["Pandas DataFrame"]
```

**Diagram sources**
- [05-get-started.md:25-36](file://RAG KB/05-get-started.md#L25-L36)

**Section sources**
- [instruction.md:1-10](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-51](file://RAG KB/05-get-started.md#L21-L51)
- [06-get-data-overview.md:22-45](file://RAG KB/06-get-data-overview.md#L22-L45)

## Core Components
The integration centers on four layers:

| Layer | Responsibility | Key Artifacts |
|---|---|---|
| Runtime environment | Executes Python 3.11 notebooks inside Bloomberg BQuant Desktop | Kernel, JupyterLab, BQL connectivity |
| Service layer | Manages BQL connections and request execution | `bql.Service`, `execute`, `execute_many` |
| Query builder | Encapsulates universe, items, parameters, and preferences | `bql.Request`, `bq.data.*`, `bq.func.*`, `bq.univ.*` |
| Data consumer | Converts responses into Pandas DataFrames and applies business logic | `SingleItemResponse.df()`, `combined_df`, local merges |

### Service Configuration and Authentication
- The service is initialized as `bq = bql.Service()` inside a Desktop notebook.
- Authentication is assumed to be provided by the active Bloomberg Terminal session; the workspace does not implement custom credentials or token management.
- Preferences can be passed at service construction or per-request via `with_params` and `preferences`.

### Connection Management
- A single `bql.Service` instance is reused across requests within a notebook kernel.
- Notebook cells share global kernel state; variables must be defined before use.
- Desktop workloads have a maximum runtime and may shut down after inactivity.

**Section sources**
- [05-get-started.md:41-51](file://RAG KB/05-get-started.md#L41-L51)
- [05-get-started.md:73-86](file://RAG KB/05-get-started.md#L73-L86)
- [07-pybql-api-reference.md:119-136](file://RAG KB/07-pybql-api-reference.md#L119-L136)

## Architecture Overview
The end-to-end BQL architecture maps local design to Desktop execution and response consumption.

```mermaid
graph TB
Dev["Developer<br/>Cursor Design"] --> Workspace["BQuant Desktop<br/>Python 3.11 Kernel"]
Workspace --> Service["bql.Service"]
Service --> Builder["bql.Request<br/>Universe + Items + Params"]
Builder --> Execute["bq.execute / execute_many"]
Execute --> Response["bql.Response / ArrowExecuteResponse"]
Response --> DF["Pandas DataFrame<br/>Per-item or combined"]
DF --> Analysis["Domain Logic<br/>Equity / FI / Economics / PORT"]
```

**Diagram sources**
- [05-get-started.md:25-36](file://RAG KB/05-get-started.md#L25-L36)
- [06-get-data-overview.md:22-45](file://RAG KB/06-get-data-overview.md#L22-L45)
- [07-pybql-api-reference.md:28-38](file://RAG KB/07-pybql-api-reference.md#L28-L38)

## Detailed Component Analysis

### PyBQL API Model
The PyBQL model separates concerns between service access, query construction, and result handling.

```mermaid
classDiagram
class Service {
+data
+func
+univ
+execute(request, callback, error_callback)
+execute_many(requests, on_request_error, num_retries)
}
class Request {
+universe
+items
+with_params
+preferences
+to_string()
}
class Response {
+single()
+__getitem__(index)
+get(name)
}
class SingleItemResponse {
+name
+df()
}
Service --> Request : "executes"
Request --> Service : "built with bq.data / bq.func / bq.univ"
Service --> Response : "returns"
Response --> SingleItemResponse : "contains"
```

**Diagram sources**
- [07-pybql-api-reference.md:96-136](file://RAG KB/07-pybql-api-reference.md#L96-L136)
- [07-pybql-api-reference.md:119-136](file://RAG KB/07-pybql-api-reference.md#L119-L136)

**Section sources**
- [07-pybql-api-reference.md:28-38](file://RAG KB/07-pybql-api-reference.md#L28-L38)
- [07-pybql-api-reference.md:96-136](file://RAG KB/07-pybql-api-reference.md#L96-L136)

### Request Building Pattern
Every BQL pull follows the same pattern: define a universe, define data items, build a `Request`, execute it, and convert responses to DataFrames.

```mermaid
flowchart TD
Start(["Build Request"]) --> Universe["Define Universe<br/>members / bonds / countries / list"]
Universe --> Items["Define Data Items<br/>bq.data.name(), px_last(), spread(), etc."]
Items --> Params["Optional Parameters<br/>dates, fill, mode, currency"]
Params --> Execute["bq.execute(Request)"]
Execute --> Result{"Single or Multiple Items?"}
Result --> |Single| SingleDF["response[0].df()"]
Result --> |Multiple| MultiDF["pd.concat([item.df()[item.name] for item in response], axis=1)"]
SingleDF --> End(["DataFrame Ready"])
MultiDF --> End
```

**Diagram sources**
- [06-get-data-overview.md:22-45](file://RAG KB/06-get-data-overview.md#L22-L45)
- [01-bql-for-equities.md:42-49](file://RAG KB/01-bql-for-equities.md#L42-L49)

**Section sources**
- [06-get-data-overview.md:22-45](file://RAG KB/06-get-data-overview.md#L22-L45)
- [01-bql-for-equities.md:42-49](file://RAG KB/01-bql-for-equities.md#L42-L49)

### Field Selection, Filtering, and Aggregation Patterns
Across asset classes, the same building blocks are reused:

- **Field selection:** Use exact mnemonics from the catalog; avoid inventing names.
- **Filtering:** Apply predicates at the universe level using `.filter()` or row-level filtering with `matches()`.
- **Aggregation:** Use `group()`, `ungroup()`, and group helpers such as `groupavg`, `grouprank`, `groupzscore`, `groupsum`, `groupvwap`.

```mermaid
flowchart TD
Universe["Universe"] --> Filter["Filter Predicate<br/>and_ / or_ / matches / between / in_"]
Universe --> Group["Group By<br/>sector / rating / maturity / country"]
Filter --> Items["Data Items"]
Group --> Items
Items --> Aggregate["Aggregate<br/>avg / sum / rank / zscore / cut"]
Aggregate --> Request["bql.Request"]
Request --> Execute["bq.execute"]
Execute --> DataFrame["DataFrame Output"]
```

**Diagram sources**
- [01-bql-for-equities.md:282-319](file://RAG KB/01-bql-for-equities.md#L282-L319)
- [01-bql-for-equities.md:323-400](file://RAG KB/01-bql-for-equities.md#L323-L400)
- [07-pybql-api-reference.md:256-342](file://RAG KB/07-pybql-api-reference.md#L256-L342)

**Section sources**
- [01-bql-for-equities.md:282-319](file://RAG KB/01-bql-for-equities.md#L282-L319)
- [01-bql-for-equities.md:323-400](file://RAG KB/01-bql-for-equities.md#L323-L400)
- [07-pybql-api-reference.md:256-342](file://RAG KB/07-pybql-api-reference.md#L256-L342)

### Equities Query Patterns
Equity workflows emphasize index membership, peer sets, fundamentals, time series, and grouped analytics.

Key patterns include:
- Index members and backdated membership.
- Peers and relative-index outperformance.
- Global equity screens with cached mode.
- Point-in-time fundamentals and estimates.
- Grouped metrics, ranking, and z-scores.

**Section sources**
- [01-bql-for-equities.md:172-279](file://RAG KB/01-bql-for-equities.md#L172-L279)
- [01-bql-for-equities.md:282-319](file://RAG KB/01-bql-for-equities.md#L282-L319)
- [01-bql-for-equities.md:323-506](file://RAG KB/01-bql-for-equities.md#L323-L506)

### Fixed Income Query Patterns
Fixed income adds bond chains, index analytics, spreads, yields, ratings, cashflows, and duration measures.

Important behaviors:
- `universe_type='projected'` vs `'returns'` for index analytics.
- Spread types: OAS, ASW, I-spread.
- Duration selector via `duration(duration_type=...)`.
- Metadata-safe index membership differences instead of `setdiff()`.
- MBS/TBA isolation and month-end business-day correction.

**Section sources**
- [02-bql-for-fixed-income.md:108-140](file://RAG KB/02-bql-for-fixed-income.md#L108-L140)
- [02-bql-for-fixed-income.md:283-330](file://RAG KB/02-bql-for-fixed-income.md#L283-L330)
- [08-bql-data-items.md:141-180](file://RAG KB/08-bql-data-items.md#L141-L180)
- [02-bql-for-fixed-income.md:606-683](file://RAG KB/02-bql-for-fixed-income.md#L606-L683)

### Economics Query Patterns
Economic queries focus on country universes, macro time series, period transforms, estimates, and release calendars.

Key elements:
- Country identifiers such as `'US Country'`.
- Period ranges, offsets, and transforms like `period_over_period`.
- Calendar views, surprise filtering, and group aggregation.

**Section sources**
- [13-bql-for-economics.md:30-86](file://RAG KB/13-bql-for-economics.md#L30-L86)
- [13-bql-for-economics.md:88-113](file://RAG KB/13-bql-for-economics.md#L88-L113)
- [13-bql-for-economics.md:221-296](file://RAG KB/13-bql-for-economics.md#L221-L296)

### Portfolio Reporting and Portfolio Library
Portfolio Reporting uses string BQL for report queries, while Portfolio Library provides programmatic portfolio operations.

- PREP requires string syntax for `port_info` and `port_all`.
- Portfolio Library supports listing, loading, updating, and saving portfolios.
- Write operations require version checks and careful staging.

**Section sources**
- [14-bql-for-port-prep.md:15-25](file://RAG KB/14-bql-for-port-prep.md#L15-L25)
- [14-bql-for-port-prep.md:62-162](file://RAG KB/14-bql-for-port-prep.md#L62-L162)
- [14-bql-for-port-prep.md:264-331](file://RAG KB/14-bql-for-port-prep.md#L264-L331)

## Dependency Analysis
The integration depends on a small, controlled stack:

- **PyBQL client:** `bql.Service`, `bql.Request`, `bql.Response`.
- **Pandas:** DataFrame construction, merging, grouping, and post-processing.
- **Plotly and ipywidgets:** UI and visualization where used by applications.
- **Bloomberg Desktop runtime:** Python 3.11, managed extensions, and BQL connectivity.

```mermaid
graph TB
PyBQL["PyBQL Client"] --> Service["bql.Service"]
Service --> Request["bql.Request"]
Request --> Response["bql.Response"]
Response --> Pandas["Pandas DataFrame"]
Pandas --> Apps["Equity / FI / Economics / PORT Applications"]
```

**Diagram sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [06-get-data-overview.md:22-45](file://RAG KB/06-get-data-overview.md#L22-L45)

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [06-get-data-overview.md:22-45](file://RAG KB/06-get-data-overview.md#L22-L45)

## Performance Considerations
Performance is shaped by Desktop limits and BQL server behavior:

- **Two-minute timeout:** Narrow universes, split requests, or use cached mode where supported.
- **Download limits:** Prefer tight filters, bounded date ranges, and `with_params={'mode': 'cached'}` for large screens.
- **Concurrency limit:** At most two running projects concurrently.
- **File size limit:** Individual project files limited to 256 MB; move temporary artifacts to `/tmp`.
- **Batch execution:** Use `execute_many` for multiple requests when appropriate.
- **Response handling:** Avoid unnecessary copies; prefer index-aligned concatenation and explicit column selection.

Caching strategies observed in the workspace include:
- Request-level cached mode for broad screens.
- Application-level CSV manifests for ETF spread monitoring history.
- Cache invalidation based on request fingerprints and identifier changes.

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [01-bql-for-equities.md:51-57](file://RAG KB/01-bql-for-equities.md#L51-L57)
- [02-bql-for-fixed-income.md:561-582](file://RAG KB/02-bql-for-fixed-income.md#L561-L582)

## Troubleshooting Guide

### BQL Timeouts
Symptoms:
- Query timed out messages.
- Partial results for one measure group while others fail.

Recommended actions:
- Reduce universe breadth.
- Split heavy analytics into separate requests.
- Use cached mode where documented.
- For fixed income, suspect duration-related measures first because they can be expensive.

**Section sources**
- [instruction.md:29-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### Rate Limiting and Download Limits
Symptoms:
- Large screens failing or timing out.
- Broad fundamental pulls exceeding limits.

Recommended actions:
- Apply `with_params={'mode': 'cached'}` for supported fields.
- Narrow universes with precise filters.
- Avoid unbounded pulls.

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [06-get-data-overview.md:62-63](file://RAG KB/06-get-data-overview.md#L62-L63)

### Network Failures and Authentication Issues
Symptoms:
- Queries do not execute.
- 403 errors.
- Kernel stuck connecting.

Recommended actions:
- Confirm Bloomberg Terminal session is logged in.
- Check BBA/session connection.
- Reconnect before changing code.
- Run network diagnostics if the kernel remains connecting.

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### Error Handling and Retry Strategy
Observed behavior:
- `execute_many` supports an `on_request_error` callback and optional retries.
- Some applications retry a failed request once.
- Cached fallbacks are used only for clean runs under specific conditions; failures that indicate rejected fields or missing entitlements are not served from cache.

```mermaid
flowchart TD
Start(["Execute Request"]) --> Try["Attempt Execution"]
Try --> Success{"Success?"}
Success --> |Yes| Return["Return Response"]
Success --> |No| Classify["Classify Failure"]
Classify --> Timeout{"Timeout?"}
Timeout --> |Yes| Retry["Retry Once"]
Retry --> RetrySuccess{"Retry Success?"}
RetrySuccess --> |Yes| Return
RetrySuccess --> |No| Fallback{"Saved Clean Run Available?"}
Fallback --> |Yes| ShowCached["Show Cached Result"]
Fallback --> |No| ReportError["Report Live Error"]
Timeout --> |No| ReportError
```

**Diagram sources**
- [07-pybql-api-reference.md:124-136](file://RAG KB/07-pybql-api-reference.md#L124-L136)
- [instruction.md:67-67](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [07-pybql-api-reference.md:124-136](file://RAG KB/07-pybql-api-reference.md#L124-L136)
- [instruction.md:67-67](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Debugging BQL Queries
Best practices:
- Exact-search data-item mnemonics in the catalog before assuming availability.
- Use Terminal FLDS only for ambiguous names, unresolved signatures, parameters, metadata, or entitlement questions.
- Inspect response shapes: ID index, DATE column behavior on Desktop Arrow timeseries, and multi-item concatenation.
- Log request counts, timings, units, effective dates, and coverage.

**Section sources**
- [06-get-data-overview.md:83-96](file://RAG KB/06-get-data-overview.md#L83-L96)
- [08-bql-data-items.md:37-49](file://RAG KB/08-bql-data-items.md#L37-L49)
- [01-bql-for-equities.md:579-606](file://RAG KB/01-bql-for-equities.md#L579-L606)

### Interpreting Response Formats
Guidance:
- Single-item responses: use `response[0].df()`.
- Multi-item responses: concatenate value columns safely when IDs/dates live in the index.
- Desktop Arrow timeseries may expose DATE as a column; avoid assuming a uniform schema across all items.
- Use `bql.combined_df` as a fallback when Arrow iteration is unavailable.

**Section sources**
- [07-pybql-api-reference.md:83-111](file://RAG KB/07-pybql-api-reference.md#L83-L111)
- [06-get-data-overview.md:252-283](file://RAG KB/06-get-data-overview.md#L252-L283)

## Conclusion
Bloomberg BQL integration in this platform is built around disciplined request construction, strict Desktop runtime constraints, and asset-class-specific recipes. Reliable operation depends on:

- Using `bql.Service` and `bql.Request` consistently.
- Selecting fields from the official catalog and validating semantics.
- Respecting Desktop timeouts, download limits, and concurrency rules.
- Applying cached mode, request splitting, and batch execution where appropriate.
- Treating errors as actionable signals rather than silent failures.
- Keeping local design separate from Desktop execution.

When extending the system, follow the existing patterns: narrow universes, validate mnemonics, preserve metadata, and record operational evidence before widening scope.

## Appendices

### Example Workflows

#### Portfolio Analysis
- Build an index or fund universe.
- Attach weights carefully (`members` lowercase `weights`, `holdings` uppercase `WEIGHTS`).
- Compute grouped metrics, rankings, and sector-relative values.
- Combine price, volume, and static descriptors safely.

**Section sources**
- [01-bql-for-equities.md:172-279](file://RAG KB/01-bql-for-equities.md#L172-L279)
- [01-bql-for-equities.md:282-319](file://RAG KB/01-bql-for-equities.md#L282-L319)

#### Market Data Retrieval
- Retrieve last price, volume, or yield over a bounded range.
- Use `fill='prev'` for non-trading days when justified.
- Convert to pandas and compute periodic or net changes.

**Section sources**
- [01-bql-for-equities.md:104-139](file://RAG KB/01-bql-for-equities.md#L104-L139)
- [02-bql-for-fixed-income.md:144-177](file://RAG KB/02-bql-for-fixed-income.md#L144-L177)

#### Reference Data Lookups
- Use identity fields such as name, ISIN, SEDOL, CUSIP, currency, classification, and maturity.
- Map company-level identities through `fundamentalticker()` lineage when required.
- Avoid substituting unrelated identifiers such as CAST parent tickers or integer company IDs for pricing keys.

**Section sources**
- [08-bql-data-items.md:97-139](file://RAG KB/08-bql-data-items.md#L97-L139)
- [08-bql-data-items.md:241-276](file://RAG KB/08-bql-data-items.md#L241-L276)