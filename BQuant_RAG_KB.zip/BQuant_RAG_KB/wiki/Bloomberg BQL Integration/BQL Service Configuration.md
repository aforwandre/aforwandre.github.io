# BQL Service Configuration

<cite>
**Referenced Files in This Document**
- [05-get-started.md](file://RAG KB/05-get-started.md)
- [07-pybql-api-reference.md](file://RAG KB/07-pybql-api-reference.md)
- [08-bql-data-items.md](file://RAG KB/08-bql-data-items.md)
- [probe_ticker.py](file://User scripts/ETF Capping Monitoring/probe_ticker.py)
- [config.py (ETF Capping Monitoring)](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [config.py (ETF Spread Monitoring)](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [config.py (FI Index Change)](file://User scripts/FI Index Change/fi_index_change/config.py)
- [config.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [README.md (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/README.md)
- [DECISION_RECORD.md (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md)
- [data.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [test_cache.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how Bloomberg BQL is configured and used across the projects in this repository. It focuses on:

- How to initialize the BQL client and establish a connection through BQuant Desktop.
- Authentication and session behavior as observed in the codebase.
- Connection parameters such as timeout, retry, caching, and request shaping.
- Environment-specific configuration files for development versus production-like usage.
- Security considerations for sensitive data and credentials.
- Troubleshooting guidance for common connection and authentication failures.

The repository does not implement its own API-key management or terminal credential storage. Instead, it relies on the Bloomberg-managed BQuant Desktop environment and the `bql.Service()` object provided by the installed PyBQL runtime.

## Project Structure
The relevant BQL configuration and setup information is spread across:

- RAG knowledge base documents describing platform constraints, initialization, and troubleshooting.
- Small utility scripts that demonstrate BQL client initialization and request execution.
- Per-project configuration modules that define timeouts, retries, cache behavior, and operational limits.
- Data-layer logic that classifies timeout versus deterministic failures and implements bounded retries.

```mermaid
graph TB
Dev["Local Cursor<br/>Design and review"] --> Copy["Copy to BQuant Desktop"]
Copy --> Kernel["BQuant Desktop kernel<br/>Python 3.11 + bql"]
Kernel --> Service["bql.Service()"]
Service --> Requests["bql.Request + bq.execute"]
Requests --> Terminal["Bloomberg Terminal / BQL backend"]
```

**Diagram sources**
- [05-get-started.md:21-59](file://RAG KB/05-get-started.md#L21-L59)

**Section sources**
- [05-get-started.md:21-86](file://RAG KB/05-get-started.md#L21-L86)

## Core Components
The core BQL setup pattern in this repository is:

1. Import `bql`.
2. Create `bq = bql.Service()`.
3. Build requests with `bql.Request(universe, items, with_params=...)`.
4. Execute with `bq.execute(request)` or `bq.execute_many(...)`.
5. Convert responses to pandas DataFrames where needed.

Key observations from the repository:

- Initialization is shown in multiple places, including the official quickstart documentation and a small probe script.
- The `with_params={"mode": "cached"}` parameter is used to reduce load and avoid large downloads on Desktop.
- There is no explicit API key, username, password, proxy URL, or endpoint configuration in these project files; those are expected to be managed by the Bloomberg-managed environment.

**Section sources**
- [05-get-started.md:41-59](file://RAG KB/05-get-started.md#L41-L59)
- [07-pybql-api-reference.md:124-141](file://RAG KB/07-pybql-api-reference.md#L124-L141)
- [probe_ticker.py:9-17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L9-L17)

## Architecture Overview
At runtime, the application layer builds BQL requests and executes them through the BQL service. The repository’s applications add resilience through:

- Request splitting.
- Bounded retries for timeouts.
- Local result caching.
- Automatic fallback to cached results when a live run times out.

```mermaid
sequenceDiagram
participant App as "Application Layer"
participant Config as "Project config.py"
participant Data as "Data layer"
participant BQL as "bql.Service"
participant Backend as "Bloomberg Backend"
App->>Config : Read timeout, retry, cache settings
App->>Data : Start update
Data->>BQL : execute(bql.Request(...))
alt Timeout
Data->>Data : Detect timeout markers
Data->>BQL : Retry identical request once
opt Cached run exists
Data-->>App : Return cached table
end
else Success
BQL-->>Data : Response
Data-->>App : DataFrame
end
```

**Diagram sources**
- [config.py (FI Spread Movement Monitoring):347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)
- [data.py (FI Spread Movement Monitoring):114-154](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L114-L154)
- [README.md (FI Spread Movement Monitoring):371-395](file://User scripts/FI Spread Movement Monitoring/README.md#L371-L395)

## Detailed Component Analysis

### BQL Client Initialization and Session Handling
The repository initializes the BQL client using `bql.Service()`. This is the standard entry point for accessing BQL data from Python inside BQuant Desktop.

Observed patterns:

- Official setup cell: import pandas, import bql, create `bq = bql.Service()`, then build and execute a simple request.
- Probe script: imports `bql`, creates `bq=bql.Service()`, builds a request, and prints results.
- No explicit connection string, API key, token, or proxy argument is passed to `Service()` in these files.

Authentication and session handling are therefore delegated to the Bloomberg-managed runtime. The troubleshooting notes indicate that a logged-in Terminal session and an active BBA/session connection are required.

```mermaid
flowchart TD
Start(["Start notebook or app"]) --> Import["Import bql"]
Import --> Service["Create bq = bql.Service()"]
Service --> Request["Build bql.Request"]
Request --> Execute["Call bq.execute"]
Execute --> Result["Convert response to DataFrame"]
```

**Diagram sources**
- [05-get-started.md:41-59](file://RAG KB/05-get-started.md#L41-L59)
- [probe_ticker.py:9-17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L9-L17)

**Section sources**
- [05-get-started.md:41-59](file://RAG KB/05-get-started.md#L41-L59)
- [probe_ticker.py:9-17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L9-L17)

### Authentication Methods and Credential Storage
The repository does not contain custom API-key management, credential files, or secret loaders. Instead:

- Authentication is expected to come from the Bloomberg Terminal session and the BQuant Desktop runtime.
- A 403 or authorization failure indicates that the Terminal session may be logged out, disconnected, or missing entitlements.
- Projects explicitly check for unavailable `bql` at runtime and raise a clear error if executed outside BQuant Desktop.

Security implications:

- Do not hardcode API keys, tokens, usernames, passwords, or proxy credentials into notebooks or scripts.
- Keep any sensitive configuration separate from shared outputs.
- Use desensitized copies when sharing examples or reports.

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [data.py (FI Spread Movement Monitoring):114-120](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L114-L120)
- [config.py (ETF Capping Monitoring):1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)

### Connection Parameters: Timeouts, Retries, and Caching
There are no direct network-level timeout arguments visible in the initialization calls. Instead, the repository manages connection behavior at the application level:

- Desktop BQL requests can time out after two minutes.
- Applications split wide requests.
- Timeouts are retried once with the same request.
- Successful runs are optionally cached.
- Cached runs can be loaded automatically after a timeout or manually via a UI action.

Important configuration constants:

| Setting | Meaning | Typical Value / Behavior |
|---|---|---|
| Desktop timeout | Maximum allowed time for a single BQL request | Two minutes |
| QUERY_ATTEMPTS | Number of attempts for a timed-out request | 2 |
| CACHE_DIR_NAME | Directory name for cached runs | `"cache"` |
| CACHE_KEEP_RUNS | Number of cached runs retained | 12 |
| CACHE_READ_FIRST | Whether Update reads cache before live request | Off by default |
| SPLIT_REQUESTS | Whether analytics are split across requests | True in FI Index Change |

These values appear in the fixed-income monitoring projects and are documented alongside their rationale.

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [config.py (FI Spread Movement Monitoring):347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)
- [README.md (FI Spread Movement Monitoring):371-395](file://User scripts/FI Spread Movement Monitoring/README.md#L371-L395)

### Proxy Settings and External Network Access
The repository enforces a closed environment:

- Only BQL, Pandas, Plotly, and ipywidgets are intended dependencies.
- External internet APIs should not be called from BQuant notebooks or apps.
- Network diagnostics and connectivity issues should be handled through Bloomberg tools rather than custom networking code.

Therefore, there is no project-level proxy configuration file. Any proxy or network policy is expected to be part of the Bloomberg-managed Desktop environment.

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [05-get-started.md:235-238](file://RAG KB/05-get-started.md#L235-L238)

### Environment-Specific Configuration: Development vs Production
Development and production-like usage are separated by workflow rather than by separate credential files:

- Local Cursor is for design, authoring, and review.
- Live BQL execution happens only on the Bloomberg machine inside BQuant or Terminal-connected kernels.
- Some projects maintain a redacted output copy for sharing while keeping the live configuration local.

Examples:

- ETF Capping Monitoring keeps a live `config.py` and a desensitized `config_redacted.py` for shareable output.
- Fixed-income projects use operator-driven configuration constants and cache directories under the project folder.

```mermaid
flowchart LR
Local["Local Cursor<br/>Design and review"] --> Share["Shareable output<br/>Desensitized config"]
Local --> Desktop["Bloomberg Desktop<br/>Live BQL execution"]
Desktop --> Cache["Project-local cache"]
```

**Diagram sources**
- [config.py (ETF Capping Monitoring):1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)
- [config.py (FI Spread Movement Monitoring):347-362](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L362)

**Section sources**
- [05-get-started.md:81-86](file://RAG KB/05-get-started.md#L81-L86)
- [config.py (ETF Capping Monitoring):1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)
- [config.py (FI Spread Movement Monitoring):347-362](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L362)

### Initializing the BQL Client and Managing Sessions
Initialization and basic session usage are demonstrated in the repository:

- Import `bql`.
- Create `bq = bql.Service()`.
- Build a request with `bql.Request`.
- Execute with `bq.execute`.
- Optionally pass `with_params={"mode": "cached"}` for supported fields.

A minimal example path is:

- [probe_ticker.py:9-17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L9-L17)

For broader context:

- [05-get-started.md:41-59](file://RAG KB/05-get-started.md#L41-L59)
- [07-pybql-api-reference.md:124-141](file://RAG KB/07-pybql-api-reference.md#L124-L141)

**Section sources**
- [probe_ticker.py:9-17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L9-L17)
- [05-get-started.md:41-59](file://RAG KB/05-get-started.md#L41-L59)
- [07-pybql-api-reference.md:124-141](file://RAG KB/07-pybql-api-reference.md#L124-L141)

### Retry Logic and Timeout Classification
The fixed-income monitoring projects implement robust retry logic:

- Only timeout errors are retried.
- Deterministic failures such as invalid tickers, missing data items, entitlement problems, license issues, and 403 errors are not retried.
- Each attempt rebuilds the request so stale state is not reused.
- The attempt count is recorded in logs.

```mermaid
flowchart TD
Exec["Execute request"] --> Check{"Exception?"}
Check --> |No| Success["Return result"]
Check --> |Yes| Classify["Classify error"]
Classify --> Timeout{"Timeout?"}
Classify --> Deterministic{"Deterministic failure?"}
Deterministic --> |Yes| Report["Report immediately"]
Timeout --> |Yes| Retry["Retry identical request once"]
Retry --> Done["Done"]
Timeout --> |No| Report
```

**Diagram sources**
- [data.py (FI Spread Movement Monitoring):123-154](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L154)
- [test_cache.py (FI Spread Movement Monitoring):93-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L93-L147)

**Section sources**
- [data.py (FI Spread Movement Monitoring):123-154](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L154)
- [test_cache.py (FI Spread Movement Monitoring):93-147](file://User scripts/FI Spread Movement Monitoring/tests/test_cache.py#L93-L147)
- [DECISION_RECORD.md (FI Spread Movement Monitoring):842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)

### Result Caching and Fallback
Caching protects against empty screens after timeouts:

- Clean runs are written to a project-local cache directory.
- Cache entries are keyed by inputs such as universe, spread type, dates, and display breadth.
- Old runs are pruned according to `CACHE_KEEP_RUNS`.
- If a live run times out and a clean cached run exists for the same key, the application can show the cached result with a distinct status.
- Manual loading of saved results is also supported.

```mermaid
flowchart TD
Run["Run update"] --> Save{"Run successful?"}
Save --> |Yes| WriteCache["Write cache entry"]
Save --> |No| CheckCache{"Clean cached run exists?"}
CheckCache --> |Yes| Fallback["Show cached result"]
CheckCache --> |No| Error["Show live error"]
```

**Diagram sources**
- [README.md (FI Spread Movement Monitoring):371-395](file://User scripts/FI Spread Movement Monitoring/README.md#L371-L395)
- [DECISION_RECORD.md (FI Spread Movement Monitoring):842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)
- [config.py (FI Spread Movement Monitoring):347-362](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L362)

**Section sources**
- [README.md (FI Spread Movement Monitoring):371-395](file://User scripts/FI Spread Movement Monitoring/README.md#L371-L395)
- [DECISION_RECORD.md (FI Spread Movement Monitoring):842-901](file://User scripts/FI Spread Movement Monitoring/DECISION_RECORD.md#L842-L901)
- [config.py (FI Spread Movement Monitoring):347-362](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L362)

### Request Shaping and Cached Mode
Several projects use request shaping to stay within Desktop limits:

- Splitting analytics or descriptor families across multiple requests.
- Using `with_params={"mode": "cached"}` for supported data items.
- Avoiding unbounded universes and date ranges.
- Preferring cached mode for large screens.

Example paths:

- [probe_ticker.py:17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L17)
- [08-bql-data-items.md:97-180](file://RAG KB/08-bql-data-items.md#L97-L180)

**Section sources**
- [probe_ticker.py:17](file://User scripts/ETF Capping Monitoring/probe_ticker.py#L17)
- [08-bql-data-items.md:97-180](file://RAG KB/08-bql-data-items.md#L97-L180)

## Dependency Analysis
The main runtime dependency is the external `bql` package provided by BQuant Desktop. The application layers depend on:

- `bql.Service` for connection and execution.
- `bql.Request` for building queries.
- `bq.data.*` for data items.
- `pandas` for DataFrame conversion and analysis.
- Project-specific `config.py` modules for operational constants.

```mermaid
graph TB
App["Application module"] --> Config["Project config.py"]
App --> Data["Data layer"]
Data --> BQL["bql"]
Data --> Pandas["pandas"]
Config --> Constants["Timeouts, retries, cache, UI constants"]
```

**Diagram sources**
- [07-pybql-api-reference.md:124-141](file://RAG KB/07-pybql-api-reference.md#L124-L141)
- [config.py (FI Spread Movement Monitoring):347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)

**Section sources**
- [07-pybql-api-reference.md:124-141](file://RAG KB/07-pybql-api-reference.md#L124-L141)
- [config.py (FI Spread Movement Monitoring):347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)

## Performance Considerations
To keep BQL requests reliable on Desktop:

- Keep universes and filters tight.
- Split wide requests into smaller groups.
- Use `with_params={"mode": "cached"}` where supported.
- Respect the two-minute Desktop timeout.
- Use bounded retries only for timeouts.
- Use caches to avoid repeated expensive work.
- Avoid unnecessary external network calls.

These practices are reflected in the project configuration and documentation.

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [config.py (FI Spread Movement Monitoring):347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)

## Troubleshooting Guide

### Common Connection Issues
Symptoms and recommended checks:

| Symptom | Likely Cause | Recommended Action |
|---|---|---|
| Kernel stays connecting | WebSocket or workload issue | Run network diagnostics, verify kernel, restart workload |
| No kernel or cells do nothing | Kernel selection or workload state | Select or restart kernel; reopen workload if needed |
| BQL timeout after two minutes | Large universe, wide request, or slow backend | Narrow request, split analytics, use cached mode |
| BQL 403 or queries do not execute | Terminal session or BBA/session connection problem | Ensure Terminal is logged in; reconnect before changing code |
| File save error | Project file too large or temporary artifacts too big | Keep files under 256 MB; move temp artifacts to `/tmp` |

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### Authentication and Entitlement Failures
If you see authorization-related errors:

- Confirm the Bloomberg Terminal session is active.
- Confirm the BBA/session connection has not changed.
- Reconnect before changing code.
- Check whether the requested field or product requires additional entitlements.
- Do not retry entitlement or license failures; they are treated as deterministic failures.

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [data.py (FI Spread Movement Monitoring):134-150](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L134-L150)

### Timeout Recovery
When a request times out:

1. The system detects timeout markers.
2. It retries the identical request once.
3. If a clean cached run exists for the same inputs, it can fall back to the cached result.
4. Deterministic failures are reported immediately without retry.

**Section sources**
- [data.py (FI Spread Movement Monitoring):123-154](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L154)
- [README.md (FI Spread Movement Monitoring):371-395](file://User scripts/FI Spread Movement Monitoring/README.md#L371-L395)

### Security Checklist
- Do not embed API keys, tokens, usernames, passwords, or proxy credentials in notebooks or scripts.
- Keep live configuration files local to the Bloomberg machine.
- Use desensitized copies for sharing.
- Treat restricted data categories as documentation-only unless explicitly authorized.
- Follow the closed-environment rule: do not call external internet APIs from BQuant notebooks or apps.

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [config.py (ETF Capping Monitoring):1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)
- [08-bql-data-items.md:19-22](file://RAG KB/08-bql-data-items.md#L19-L22)

## Conclusion
In this repository, BQL service configuration is primarily environmental rather than code-based. The BQL client is initialized through `bql.Service()` inside BQuant Desktop, and authentication, sessions, and network policy are managed by the Bloomberg runtime. Operational reliability comes from:

- Careful request shaping.
- Bounded retries for timeouts.
- Project-local caching.
- Clear separation between local design and live execution.
- Desensitized outputs for sharing.

For new setups, start with the official initialization pattern, respect Desktop limits, and use the existing retry and cache patterns when building larger fixed-income or equity workflows.