# BQL Data Items Reference

<cite>
**Referenced Files in This Document**   
- [08-bql-data-items.md](file://RAG KB/08-bql-data-items.md)
- [01-bql-for-equities.md](file://RAG KB/01-bql-for-equities.md)
- [02-bql-for-fixed-income.md](file://RAG KB/02-bql-for-fixed-income.md)
- [13-bql-for-economics.md](file://RAG KB/13-bql-for-economics.md)
- [24-etf-field-migration-incident.md](file://RAG KB/24-etf-field-migration-incident.md)
- [25-etf-capping-monitor.md](file://RAG KB/25-etf-capping-monitor.md)
- [27-etf-spread-monitor.md](file://RAG KB/27-etf-spread-monitor.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document is a comprehensive reference for Bloomberg BQL data items across equities, fixed income, ETFs, and economics. It consolidates field semantics, usage patterns, availability constraints, and production-safe behaviors documented in the repository’s canonical knowledge base.

The scope includes:
- Equities: price, fundamentals, corporate actions, market statistics, universes, aggregation, and point-in-time behavior.
- Fixed income: bond characteristics, yield curves, credit spreads, issuer information, cashflows, ratings, and index membership.
- ETFs: composition, holdings, expense ratios, tracking metrics, bid-ask quotes, fund flows, and runtime pricing rules.
- Economics: macro indicators, interest rates, currency, forecasts, and economic calendar events.

For every data item discussed here, the documentation provides:
- Field description and purpose.
- Typical data type or unit where available.
- Frequency and historical depth considerations.
- Usage examples through referenced code paths.
- Availability, entitlement, and substitution guidance.

**Section sources**
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [01-bql-for-equities.md:15-29](file://RAG KB/01-bql-for-equities.md#L15-L29)
- [02-bql-for-fixed-income.md:15-29](file://RAG KB/02-bql-for-fixed-income.md#L15-L29)
- [13-bql-for-economics.md:15-20](file://RAG KB/13-bql-for-economics.md#L15-L20)

## Project Structure
The repository organizes BQL domain knowledge into topic-based markdown files under `RAG KB`. The most relevant files for this reference are:

| File | Role | Asset Class Coverage |
|---|---|---|
| `08-bql-data-items.md` | Canonical data-item semantics, traps, Second Measure, CDE, catalog exceptions | Cross-asset reference |
| `01-bql-for-equities.md` | Equity universes, fundamentals, returns, screening, aggregation | Equities |
| `02-bql-for-fixed-income.md` | Bond snapshots, index analytics, spreads, ratings, cashflows, ownership | Fixed Income |
| `13-bql-for-economics.md` | Country-level macro series, estimates, calendar | Economics |
| `24-etf-field-migration-incident.md` | Company mapping, Thai pricing, restricted-data safety | ETF / Equities |
| `25-etf-capping-monitor.md` | AIM positions, last-price fallback, dynamic capping | ETF / Equities |
| `27-etf-spread-monitor.md` | ETF quote fields, expense ratio, tracking error, fund flow | ETF |

```mermaid
graph TB
Core["BQL Data Item Semantics<br/>08-bql-data-items.md"] --> Equities["Equity Recipes<br/>01-bql-for-equities.md"]
Core --> FixedIncome["Fixed Income Recipes<br/>02-bql-for-fixed-income.md"]
Core --> Economics["Economics Recipes<br/>13-bql-for-economics.md"]
Equities --> ETF_Capping["ETF Capping Runtime<br/>25-etf-capping-monitor.md"]
Equities --> ETF_Migration["ETF Mapping Incident<br/>24-etf-field-migration-incident.md"]
ETF_Capping --> ETF_Spread["ETF Spread Monitoring<br/>27-etf-spread-monitor.md"]
FixedIncome --> ETF_Spread
Economics --> ETF_Spread
```

**Diagram sources**
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [01-bql-for-equities.md:15-29](file://RAG KB/01-bql-for-equities.md#L15-L29)
- [02-bql-for-fixed-income.md:15-29](file://RAG KB/02-bql-for-fixed-income.md#L15-L29)
- [13-bql-for-economics.md:15-20](file://RAG KB/13-bql-for-economics.md#L15-L20)
- [24-etf-field-migration-incident.md:39-49](file://RAG KB/24-etf-field-migration-incident.md#L39-L49)
- [25-etf-capping-monitor.md:49-78](file://RAG KB/25-etf-capping-monitor.md#L49-L78)
- [27-etf-spread-monitor.md:31-51](file://RAG KB/27-etf-spread-monitor.md#L31-L51)

**Section sources**
- [08-bql-data-items.md:15-49](file://RAG KB/08-bql-data-items.md#L15-L49)
- [01-bql-for-equities.md:15-29](file://RAG KB/01-bql-for-equities.md#L15-L29)
- [02-bql-for-fixed-income.md:15-29](file://RAG KB/02-bql-for-fixed-income.md#L15-L29)
- [13-bql-for-economics.md:15-20](file://RAG KB/13-bql-for-economics.md#L15-L20)
- [24-etf-field-migration-incident.md:39-49](file://RAG KB/24-etf-field-migration-incident.md#L39-L49)
- [25-etf-capping-monitor.md:49-78](file://RAG KB/25-etf-capping-monitor.md#L49-L78)
- [27-etf-spread-monitor.md:31-51](file://RAG KB/27-etf-spread-monitor.md#L31-L51)

## Core Components
This section summarizes the core BQL data-item families used across asset classes.

### Equities
- Price and volume: `name()`, `px_last()`, `px_volume()`.
- Valuation and size: `pe_ratio()`, `cur_mkt_cap()`.
- Fundamentals: `sales_rev_turn()`, `ebitda()`, `is_eps()`, `net_income()`, `fcf_ev_yield()`, `return_com_eqy()`, `return_on_inv_capital()`.
- Corporate actions: `dividends()`, `stock_divs()`, `stock_splits()`, `rights_offerings()`, `spinoffs()`.
- Returns: `total_return()`, `day_to_day_tot_return_gross_dvds()`.
- Classification: `classification_name(classification_scheme=...)`.
- Universes: `univ.members()`, `univ.peers()`, `univ.equitiesuniv()`, `univ.savedlist()`.

Typical units:
- Prices: local currency unless converted.
- Volume: shares traded.
- P/E: dimensionless multiple.
- Market cap: currency units; often normalized to billions/trillions in analysis.
- Returns: percentage or decimal depending on transformation.

Availability and frequency:
- Time-series prices use trading calendars; weekends/holidays require `fill='prev'` when chaining transforms.
- Fundamentals use fiscal period parameters such as `fa_period_type`, `fa_period_offset`, and `fa_period_reference`.
- Point-in-time backtesting requires backdating both universe membership and factor observations.

**Section sources**
- [01-bql-for-equities.md:61-77](file://RAG KB/01-bql-for-equities.md#L61-L77)
- [01-bql-for-equities.md:143-168](file://RAG KB/01-bql-for-equities.md#L143-L168)
- [01-bql-for-equities.md:172-279](file://RAG KB/01-bql-for-equities.md#L172-L279)
- [01-bql-for-equities.md:282-506](file://RAG KB/01-bql-for-equities.md#L282-L506)
- [01-bql-for-equities.md:579-606](file://RAG KB/01-bql-for-equities.md#L579-L606)
- [01-bql-for-equities.md:610-740](file://RAG KB/01-bql-for-equities.md#L610-L740)

### Fixed Income
- Bond descriptors: `name()`, `issue_dt()`, `maturity()`, `company_corp_ticker()`, `payment_rank()`, `cntry_of_risk()`, `cpn_typ()`, `crncy()`, `security_typ()`, `classification_name()`.
- Pricing and analytics: `px_last()`, `yield_()`, `spread(spread_type=...)`, `disc_margin()`, `duration(duration_type=...)`.
- Issuer and capital structure: `issuer()`, `bb_composite()`, `amt_outstanding()`, `amt_issued()`.
- Cashflows: `cashflows()` with date filtering and scenario/settle controls.
- Ratings: `rating()` with metadata columns and normalization.
- Index analytics: `market_value()`, `member_count()`, `total_return(universe_type=..., calc_interval=...)`.

Typical units:
- Yield: annualized percentage.
- Spread: basis points or percentage depending on item and source.
- Coupon: percentage.
- Duration: years or sensitivity measure.
- Amount outstanding/issued: currency units.

Availability and frequency:
- Index analytics distinguish projected daily eligible sets versus static monthly return sets.
- Spreads include OAS, ASW, and I-spread.
- Cashflows can be projected or historical via settle date.
- MBS/TBA members may have missing classification names and require isolation.

**Section sources**
- [02-bql-for-fixed-income.md:61-104](file://RAG KB/02-bql-for-fixed-income.md#L61-L104)
- [02-bql-for-fixed-income.md:108-140](file://RAG KB/02-bql-for-fixed-income.md#L108-L140)
- [02-bql-for-fixed-income.md:181-279](file://RAG KB/02-bql-for-fixed-income.md#L181-L279)
- [02-bql-for-fixed-income.md:283-331](file://RAG KB/02-bql-for-fixed-income.md#L283-L331)
- [02-bql-for-fixed-income.md:334-438](file://RAG KB/02-bql-for-fixed-income.md#L334-L438)
- [02-bql-for-fixed-income.md:639-683](file://RAG KB/02-bql-for-fixed-income.md#L639-L683)

### ETF-Specific Fields
- Composition and holdings: `fund_open_shr_class()`, `id_isin()`, `id_bb_company()`, `long_comp_name()`, `fund_comp_name()`, `fund_benchmark_prim()`.
- Expense ratio: `fund_expense_ratio()`.
- Tracking metrics: `tracking_error()`, `nav_tracking_error()`.
- Quotes: `px_bid()`, `px_ask()`, `px_mid()`, `px_last()`.
- Assets: `fund_total_assets(currency='USD')`, `fund_class_assets()`.
- Currency: `crncy()`.
- Flows: `fund_flow(dates=..., currency='USD')`.
- NAV levels: `fund_net_asset_val(dates=..., currency='USD', fill='prev')`.
- Total return: `tot_return_index_gross_dvds(dates=..., currency='USD', fill='prev')`.

Typical units:
- Expense ratio: vendor scale; observed values are displayed as percentages without dividing by 100.
- Tracking error: vendor value multiplied by 100 for display as percent.
- Fund assets: full dollar amount divided by one million for display in millions.
- Quote spread: absolute difference between ask and bid; percent spread uses midpoint.

Availability and frequency:
- Quote history uses cached requests over multi-year ranges without `fill`.
- Period averages carry previous quotes onto weekdays without quotes.
- Fund flows are requested per fund ticker, not summed across share classes.
- Peer listing and benchmark resolution follow strict identity rules.

**Section sources**
- [27-etf-spread-monitor.md:123-149](file://RAG KB/27-etf-spread-monitor.md#L123-L149)
- [27-etf-spread-monitor.md:201-233](file://RAG KB/27-etf-spread-monitor.md#L201-L233)
- [27-etf-spread-monitor.md:235-296](file://RAG KB/27-etf-spread-monitor.md#L235-L296)
- [27-etf-spread-monitor.md:298-376](file://RAG KB/27-etf-spread-monitor.md#L298-L376)
- [27-etf-spread-monitor.md:378-393](file://RAG KB/27-etf-spread-monitor.md#L378-L393)

### Economic Data Items
- Macro indicators: `cpi()`, `gdp()`, `policy_rate()`, `pmi()`, `unemployment()`, `consumer_confidence()`, `retail_sales()`, `exports()`, `imports()`, `current_account_percent_gdp()`, `government_debt_percent_gdp()`, `budget_balance_percent_gdp()`, `business_confidence()`.
- Estimates and forward periods: `period_reference`, `period_offset`, `act_est_data`.
- Calendar: `calendar(dates=..., view=..., relevancy=..., subtype=...)`.

Typical units:
- CPI: usually YoY percent by default; transformable to MoM/QoQ.
- GDP: growth rate or level depending on transform.
- Policy rate: percentage.
- Debt/balance ratios: percent of GDP.

Availability and frequency:
- Country universes include `'US Country'`, `'DE Country'`, `'JP Country'`, and region groups.
- Series support point-in-time, period ranges, and relative offsets.
- Calendar supports standard, condensed, and extended views with relevance filters.

**Section sources**
- [13-bql-for-economics.md:41-86](file://RAG KB/13-bql-for-economics.md#L41-L86)
- [13-bql-for-economics.md:88-113](file://RAG KB/13-bql-for-economics.md#L88-L113)
- [13-bql-for-economics.md:115-131](file://RAG KB/13-bql-for-economics.md#L115-L131)
- [13-bql-for-economics.md:133-219](file://RAG KB/13-bql-for-economics.md#L133-L219)
- [13-bql-for-economics.md:221-298](file://RAG KB/13-bql-for-economics.md#L221-L298)

## Architecture Overview
BQL data access follows a consistent request-response pattern across asset classes. The canonical workflow is:

1. Define a universe: equity tickers, bond chains, index members, country codes, or ETF share-class identifiers.
2. Construct data items using `bq.data.*` functions with appropriate parameters.
3. Execute a `bql.Request` and materialize responses into Pandas frames.
4. Apply transformations, groupings, filters, and aggregations locally.
5. Handle missing data, status codes, and fallback rules according to asset-specific contracts.

```mermaid
sequenceDiagram
participant User as "User Code"
participant Service as "bql.Service"
participant Request as "bql.Request"
participant Response as "Response Frame"
participant Pandas as "Pandas Transform"
User->>Service : Create service
User->>Request : Build universe + data_items
User->>Service : execute(Request)
Service-->>Response : Return BQL response
User->>Response : Convert to DataFrame
User->>Pandas : Filter/group/aggregate
Pandas-->>User : Final analytical frame
```

**Diagram sources**
- [01-bql-for-equities.md:33-49](file://RAG KB/01-bql-for-equities.md#L33-L49)
- [02-bql-for-fixed-income.md:51-57](file://RAG KB/02-bql-for-fixed-income.md#L51-L57)
- [13-bql-for-economics.md:21-28](file://RAG KB/13-bql-for-economics.md#L21-L28)

**Section sources**
- [01-bql-for-equities.md:33-49](file://RAG KB/01-bql-for-equities.md#L33-L49)
- [02-bql-for-fixed-income.md:51-57](file://RAG KB/02-bql-for-fixed-income.md#L51-L57)
- [13-bql-for-economics.md:21-28](file://RAG KB/13-bql-for-economics.md#L21-L28)

## Detailed Component Analysis

### Equities Data Items
Equity data items cover pricing, fundamentals, corporate actions, market statistics, and universe construction.

#### Price and Market Statistics
- `name()`: Security name.
- `px_last()`: Last price; supports dates, ranges, and fill.
- `px_volume()`: Trading volume.
- `pe_ratio()`: Price-to-earnings ratio.
- `cur_mkt_cap()`: Current market capitalization.

Usage example path:
- Single equity request combining name, price, volume, P/E, and market cap.

Availability:
- Daily trading frequency.
- Cached mode recommended for large screens.

**Section sources**
- [01-bql-for-equities.md:61-77](file://RAG KB/01-bql-for-equities.md#L61-L77)
- [01-bql-for-equities.md:51-57](file://RAG KB/01-bql-for-equities.md#L51-L57)

#### Fundamentals and Estimates
- `sales_rev_turn()`: Sales/revenue turnover.
- `ebitda()`: Earnings before interest, taxes, depreciation, and amortization.
- `is_eps()`: Earnings per share; supports adjusted and estimate windows.
- `net_income()`: Net income.
- `fcf_ev_yield()`, `return_com_eqy()`, `return_on_inv_capital()`: Profitability and valuation factors.

Parameters:
- `fa_period_type`: Quarterly, annual, backward annual, etc.
- `fa_period_offset`: Relative fiscal window.
- `fa_period_reference`: Absolute fiscal period range.
- `fa_adjusted`: Adjusted vs unadjusted statements.

Usage example path:
- Annual sales, EBITDA estimates, EPS estimates, and index-member fundamentals.

Historical depth:
- Fiscal periods determine available history.
- Point-in-time backtesting requires backdated membership and statement observation dates.

**Section sources**
- [01-bql-for-equities.md:143-168](file://RAG KB/01-bql-for-equities.md#L143-L168)
- [01-bql-for-equities.md:610-675](file://RAG KB/01-bql-for-equities.md#L610-L675)

#### Corporate Actions
- `dividends(ex_date=...)`: Cash dividends.
- `stock_divs(effective_date=...)`: Stock dividends.
- `stock_splits(effective_date=...)`: Splits.
- `rights_offerings(effective_date=...)`: Rights offerings.
- `spinoffs(effective_date=...)`: Spinoffs.

Usage example path:
- Counting corporate actions over a date range for peer screens.

**Section sources**
- [01-bql-for-equities.md:402-422](file://RAG KB/01-bql-for-equities.md#L402-L422)

#### Universe Construction and Aggregation
- `univ.members(index, dates=...)`: Index constituents with optional backdating.
- `univ.peers(ticker, type=...)`: Peer universes.
- `univ.equitiesuniv(scopes)`: Global equity screen base.
- `group().avg()/wavg()`, `groupzscore()`, `grouprank()`: Grouped analytics.

Usage example path:
- Sector-relative medians, z-scores, top EPS growers, and PIT factor backtests.

**Section sources**
- [01-bql-for-equities.md:172-279](file://RAG KB/01-bql-for-equities.md#L172-L279)
- [01-bql-for-equities.md:282-506](file://RAG KB/01-bql-for-equities.md#L282-L506)

### Fixed Income Data Items
Fixed income data items focus on bond characteristics, yield/spread analytics, issuer information, and index membership.

#### Bond Characteristics
- `issue_dt()`: Issue date.
- `maturity()`: Maturity date.
- `company_corp_ticker()`: Issuer equity ticker.
- `payment_rank()`: Payment rank.
- `cntry_of_risk()`: Country of risk.
- `cpn_typ()`: Coupon type.
- `crncy()`: Currency.
- `security_typ()`: Security type, including MBS/TBA distinctions.
- `classification_name()`: Sector/classification name.

Usage example path:
- Single bond snapshot and multi-ID requests.

**Section sources**
- [02-bql-for-fixed-income.md:61-87](file://RAG KB/02-bql-for-fixed-income.md#L61-L87)
- [02-bql-for-fixed-income.md:91-104](file://RAG KB/02-bql-for-fixed-income.md#L91-L104)

#### Yield, Spread, and Duration
- `yield_()`: Yield; supports time series and net change.
- `spread(spread_type='OAS'|'ASW'|'I')`: Credit spread measures.
- `disc_margin()`: Discount margin.
- `duration(duration_type='MODIFIED'|'EFFECTIVE'|'SPREAD')`: Duration sensitivity.

Units and semantics:
- Yield: annualized percentage.
- Spread: basis points or percentage depending on source.
- Duration: sensitivity measure; bare form has unresolved default semantics.

Usage example path:
- Weekly yield change, median yield by rating, rolling weighted discount margin.

**Section sources**
- [02-bql-for-fixed-income.md:144-177](file://RAG KB/02-bql-for-fixed-income.md#L144-L177)
- [02-bql-for-fixed-income.md:283-301](file://RAG KB/02-bql-for-fixed-income.md#L283-L301)
- [02-bql-for-fixed-income.md:421-438](file://RAG KB/02-bql-for-fixed-income.md#L421-L438)
- [08-bql-data-items.md:141-180](file://RAG KB/08-bql-data-items.md#L141-L180)

#### Issuer and Index Analytics
- `issuer()`: Issuer identifier.
- `bb_composite()`: Composite rating.
- `amt_outstanding()`, `amt_issued()`: Outstanding and issued amounts.
- `market_value(universe_type=...)`, `member_count(universe_type=...)`: Index-level metrics.
- `total_return(universe_type=..., calc_interval=...)`: Index total return decomposition.

Usage example path:
- Projected vs returns universe types, global active bond screens, and index member filters.

**Section sources**
- [02-bql-for-fixed-income.md:108-140](file://RAG KB/02-bql-for-fixed-income.md#L108-L140)
- [02-bql-for-fixed-income.md:231-259](file://RAG KB/02-bql-for-fixed-income.md#L231-L259)

#### Cashflows and Ratings
- `cashflows()`: Principal and interest cashflow streams; supports settle date and date-window filtering.
- `rating()`: Rating with metadata columns; supports grouping and normalization.

Usage example path:
- Single-bond cashflows, index-member principal/interest aggregation by year, median yield by rating.

**Section sources**
- [02-bql-for-fixed-income.md:293-331](file://RAG KB/02-bql-for-fixed-income.md#L293-L331)

### ETF-Specific Data Items
ETF data items span composition, holdings, expense ratios, tracking metrics, quotes, assets, currency, flows, and NAV/return levels.

#### Composition and Holdings
- `fund_open_shr_class()`: Open-end share class.
- `id_isin()['value']`: ISIN number.
- `id_bb_company()['value']`: Bloomberg company identifier.
- `long_comp_name()['value']`: Long company name.
- `fund_comp_name()['value']`: Fund company name.
- `fund_benchmark_prim()['value']`: Primary benchmark identifier.

Usage example path:
- HelpDesk share-class list, peer mapping, and benchmark resolution.

**Section sources**
- [27-etf-spread-monitor.md:298-346](file://RAG KB/27-etf-spread-monitor.md#L298-L346)
- [27-etf-spread-monitor.md:378-393](file://RAG KB/27-etf-spread-monitor.md#L378-L393)

#### Expense Ratio
- `fund_expense_ratio()['value']`: Expense ratio.

Units:
- Vendor scale; observed values are displayed as percentages without dividing by 100.

Usage example path:
- Share-class request returning numeric expense ratio.

**Section sources**
- [27-etf-spread-monitor.md:201-233](file://RAG KB/27-etf-spread-monitor.md#L201-L233)

#### Tracking Metrics
- `tracking_error()['value']`: PX_LAST-based tracking error.
- `nav_tracking_error()['value']`: NAV-based tracking error.

Units:
- Vendor value multiplied by 100 for display as percent.

Usage example path:
- Separate cached requests for HSBC book and peers.

**Section sources**
- [27-etf-spread-monitor.md:370-376](file://RAG KB/27-etf-spread-monitor.md#L370-L376)
- [27-etf-spread-monitor.md:380-393](file://RAG KB/27-etf-spread-monitor.md#L380-L393)

#### Quotes and Spread
- `px_bid()`, `px_ask()`, `px_mid()`, `px_last()`: Bid, ask, mid, and last quotes.

Spread calculation:
- Absolute spread: ask minus bid.
- Percent spread: difference over midpoint times 100.

Usage example path:
- Five-year cached quote history without `fill`; weekday averages carry previous quotes.

**Section sources**
- [27-etf-spread-monitor.md:123-149](file://RAG KB/27-etf-spread-monitor.md#L123-L149)
- [27-etf-spread-monitor.md:378-393](file://RAG KB/27-etf-spread-monitor.md#L378-L393)

#### Assets and Currency
- `fund_total_assets(currency='USD')`: Fund-level assets in USD.
- `fund_class_assets()`: Share-class assets already in millions.
- `crncy()`: Currency.

Units:
- Fund assets: full dollars divided by one million for display.
- Class assets: millions.
- Currency: display attribute; not an asset classifier.

Usage example path:
- Separate fund AUM request; share-class assets ride with quote request.

**Section sources**
- [27-etf-spread-monitor.md:378-393](file://RAG KB/27-etf-spread-monitor.md#L378-L393)
- [27-etf-spread-monitor.md:265-296](file://RAG KB/27-etf-spread-monitor.md#L265-L296)

#### Flows and NAV/Return
- `fund_flow(dates=..., currency='USD')`: Net fund flow.
- `fund_net_asset_val(dates=..., currency='USD', fill='prev')`: NAV levels.
- `tot_return_index_gross_dvds(dates=..., currency='USD', fill='prev')`: Total return.

Usage example path:
- Flow heatmap, NAV return, and benchmark return calculations.

**Section sources**
- [27-etf-spread-monitor.md:348-376](file://RAG KB/27-etf-spread-monitor.md#L348-L376)
- [27-etf-spread-monitor.md:378-393](file://RAG KB/27-etf-spread-monitor.md#L378-L393)

### Economic Data Items
Economic data items provide country-level macro series, estimates, and calendar events.

#### Macro Indicators
- `cpi()`: Consumer price index.
- `gdp()`: Gross domestic product.
- `policy_rate()`: Central bank policy rate.
- `pmi()`: Purchasing managers’ index.
- `unemployment()`: Unemployment rate.
- `consumer_confidence()`: Consumer confidence.
- `retail_sales()`: Retail sales.
- `exports()`, `imports()`: Trade flows.
- `current_account_percent_gdp()`, `government_debt_percent_gdp()`, `budget_balance_percent_gdp()`: Macroeconomic balances.

Usage example path:
- Single-country multi-item requests and multi-country comparisons.

**Section sources**
- [13-bql-for-economics.md:41-86](file://RAG KB/13-bql-for-economics.md#L41-L86)

#### Estimates and Forward Periods
- `period_reference`: Absolute period range.
- `period_offset`: Relative period window.
- `act_est_data`: Actual vs estimate selection.

Usage example path:
- CPI estimate windows and multi-country z-score summaries.

**Section sources**
- [13-bql-for-economics.md:115-131](file://RAG KB/13-bql-for-economics.md#L115-L131)

#### Economic Calendar
- `calendar(dates=..., view=..., relevancy=..., subtype=...)`: Economic release calendar.

Usage example path:
- Standard, condensed, and extended views; surprise filtering; average surprise by country and event.

**Section sources**
- [13-bql-for-economics.md:221-298](file://RAG KB/13-bql-for-economics.md#L221-L298)

## Dependency Analysis
BQL data items depend on three layers:

1. **Universe layer**: Determines which securities, countries, funds, or indices are queried.
2. **Data-item layer**: Defines the metric, descriptor, or time series.
3. **Runtime layer**: Handles caching, fill behavior, batch size, and fallback rules.

```mermaid
graph LR
Universe["Universe Layer<br/>members / bonds / debt / countries / fundsuniv"] --> DataItem["Data-Item Layer<br/>px_last / yield_ / spread / fund_flow"]
DataItem --> Runtime["Runtime Layer<br/>cached mode / fill / batches / fallback"]
Runtime --> Output["Output Layer<br/>DataFrame / diagnostics / zero fallback"]
```

**Diagram sources**
- [01-bql-for-equities.md:172-279](file://RAG KB/01-bql-for-equities.md#L172-L279)
- [02-bql-for-fixed-income.md:181-279](file://RAG KB/02-bql-for-fixed-income.md#L181-L279)
- [13-bql-for-economics.md:133-219](file://RAG KB/13-bql-for-economics.md#L133-L219)
- [27-etf-spread-monitor.md:394-413](file://RAG KB/27-etf-spread-monitor.md#L394-L413)

Key dependency relationships:
- Equity universes feed fundamental and return data items.
- Fixed income universes feed yield, spread, rating, and cashflow data items.
- ETF runtime depends on quote, asset, expense, tracking, and flow data items.
- Economic universes feed macro series and calendar data items.

**Section sources**
- [01-bql-for-equities.md:172-279](file://RAG KB/01-bql-for-equities.md#L172-L279)
- [02-bql-for-fixed-income.md:181-279](file://RAG KB/02-bql-for-fixed-income.md#L181-L279)
- [13-bql-for-economics.md:133-219](file://RAG KB/13-bql-for-economics.md#L133-L219)
- [27-etf-spread-monitor.md:394-413](file://RAG KB/27-etf-spread-monitor.md#L394-L413)

## Performance Considerations
Best practices for selecting fields and optimizing query performance:

- Use exact mnemonic search in the canonical catalog before inventing or substituting fields.
- Prefer cached mode for large screens and fundamentals.
- Batch requests:
  - ETF spread monitoring uses batches of eight identifiers for quote history.
  - ETF capping monitor uses AIM account batches and security-level caches.
- Avoid unnecessary broad universes; filter before requesting sensitive or expensive fields.
- Do not pass `mode=cached` on descriptor requests like `market_status()` or `name()` when live status is required.
- Use `fill='prev'` only where justified by calendar gaps; do not assume it applies to all quote histories.
- Keep universe shape and weight key casing correct:
  - `bq.univ.members()` → lowercase `'weights'`.
  - `bq.univ.holdings()` / portfolios → uppercase `'WEIGHTS'`.
- Separate identity layers: position ticker, pricing ticker, company key, and issuer key must not be conflated.

**Section sources**
- [08-bql-data-items.md:37-49](file://RAG KB/08-bql-data-items.md#L37-L49)
- [08-bql-data-items.md:316-334](file://RAG KB/08-bql-data-items.md#L316-L334)
- [01-bql-for-equities.md:51-57](file://RAG KB/01-bql-for-equities.md#L51-L57)
- [01-bql-for-equities.md:278-279](file://RAG KB/01-bql-for-equities.md#L278-L279)
- [02-bql-for-fixed-income.md:279-279](file://RAG KB/02-bql-for-fixed-income.md#L279-L279)
- [25-etf-capping-monitor.md:122-136](file://RAG KB/25-etf-capping-monitor.md#L122-L136)
- [27-etf-spread-monitor.md:123-149](file://RAG KB/27-etf-spread-monitor.md#L123-L149)

## Troubleshooting Guide
Common issues and their documented resolutions:

### Market Status and Zero-Price Fallback
- `market_status()` with `mode=cached` can return stale status; avoid cached mode for descriptor fetches.
- Official empty-market statuses do not skip `px_last(..., fill='prev')`.
- If last price is empty, non-numeric, infinite, or error, set that holding’s price and market value to zero while preserving sibling weights.

**Section sources**
- [08-bql-data-items.md:316-334](file://RAG KB/08-bql-data-items.md#L316-L334)
- [25-etf-capping-monitor.md:79-113](file://RAG KB/25-etf-capping-monitor.md#L79-L113)
- [25-etf-capping-monitor.md:122-136](file://RAG KB/25-etf-capping-monitor.md#L122-L136)

### Thai Foreign-Line Pricing Safety
- Preserve original AIM ticker and quantity for `/F TB Equity` and `-R TB Equity`.
- Resolve local Thai pricing through approved overrides, deterministic strip validation, and leftover HelpDesk DRSK mapping.
- Never use CAST parent ticker or integer company ID as a local pricing ticker.
- Unresolved mapping must fail closed; do not reuse sparse foreign-line price.

**Section sources**
- [24-etf-field-migration-incident.md:68-98](file://RAG KB/24-etf-field-migration-incident.md#L68-L98)
- [24-etf-field-migration-incident.md:176-237](file://RAG KB/24-etf-field-migration-incident.md#L176-L237)
- [24-etf-field-migration-incident.md:279-304](file://RAG KB/24-etf-field-migration-incident.md#L279-L304)

### ETF Quote and Spread Handling
- Invalid quotes stay blank; crossed quotes stay blank; do not zero-fill missing spreads.
- Absolute spread is ask minus bid; percent spread uses midpoint.
- Quote history uses cached requests without `fill`; weekday averages carry previous quotes.

**Section sources**
- [27-etf-spread-monitor.md:63-84](file://RAG KB/27-etf-spread-monitor.md#L63-L84)
- [27-etf-spread-monitor.md:123-149](file://RAG KB/27-etf-spread-monitor.md#L123-L149)
- [27-etf-spread-monitor.md:378-393](file://RAG KB/27-etf-spread-monitor.md#L378-L393)

### Restricted Data and Substitution Safety
- ESG, GHG, climate, and sustainable-finance data items are documentation-only; execution can trigger account suspension.
- Catalog existence does not authorize semantic equivalence or entitlement.
- Route Excel/API migrations through due diligence before catalog search.

**Section sources**
- [08-bql-data-items.md:19-23](file://RAG KB/08-bql-data-items.md#L19-L23)
- [08-bql-data-items.md:221-239](file://RAG KB/08-bql-data-items.md#L221-L239)
- [24-etf-field-migration-incident.md:101-130](file://RAG KB/24-etf-field-migration-incident.md#L101-L130)

## Conclusion
This reference consolidates Bloomberg BQL data items across equities, fixed income, ETFs, and economics based on the repository’s canonical knowledge base. The most important operational principles are:

- Use exact catalog mnemonics and official recipes rather than inventing fields.
- Respect universe shapes, weight-key casing, and identity-layer separation.
- Apply asset-specific availability, frequency, and fallback rules.
- Optimize performance through caching, batching, and narrow universes.
- Treat restricted data and cross-product proxies as high-risk substitutions.

These guidelines ensure safe, reproducible, and production-ready BQL workflows.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Appendix A: Field Selection Checklist
- Confirm exact mnemonic in canonical catalog.
- Verify signature and parameters via FLDS when unresolved.
- Check entitlement and restricted-data boundaries.
- Choose universe and filter before requesting expensive fields.
- Align frequency, fill, and historical depth with business intent.
- Validate output units and scaling before display.

**Section sources**
- [08-bql-data-items.md:37-49](file://RAG KB/08-bql-data-items.md#L37-L49)
- [27-etf-spread-monitor.md:146-149](file://RAG KB/27-etf-spread-monitor.md#L146-L149)

### Appendix B: Common Traps
- Stale descriptor status from cached mode.
- Wrong weight-key casing for index vs holdings universes.
- Using company-level fundamental ticker as pricing ticker.
- Assuming catalog presence equals semantic approval.
- Zero-filling missing quotes instead of keeping blanks.

**Section sources**
- [08-bql-data-items.md:316-334](file://RAG KB/08-bql-data-items.md#L316-L334)
- [01-bql-for-equities.md:278-279](file://RAG KB/01-bql-for-equities.md#L278-L279)
- [24-etf-field-migration-incident.md:176-237](file://RAG KB/24-etf-field-migration-incident.md#L176-L237)
- [27-etf-spread-monitor.md:63-84](file://RAG KB/27-etf-spread-monitor.md#L63-L84)