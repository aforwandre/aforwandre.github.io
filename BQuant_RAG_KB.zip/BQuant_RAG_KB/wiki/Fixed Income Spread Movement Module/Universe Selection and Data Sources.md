# Universe Selection and Data Sources

<cite>
**Referenced Files in This Document**
- [README.md](file://User scripts/FI Spread Movement Monitoring/README.md)
- [config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [engine.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py)
- [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the universe selection system used by the FI spread movement monitoring application. The app ranks the top 10 spread increases and decreases for a user-selected universe, then enriches those movers with descriptors, duration measures, and a bounded series check.

There are four universe sources:
- Index-based analysis: a Bloomberg index ticker whose membership is evaluated as of an end date.
- AIM account holdings: one AIM account code whose holdings become the universe through the frozen AIM request shape.
- AIM vs Index comparison: both an AIM account and an index ticker; each book is ranked separately but descriptors and series are requested once over the union of candidate IDs.
- Individual bond monitoring: one typed bond ticker queried through a private list universe.

The data pipeline normalizes inputs, builds BQL universes, executes ranking requests, merges descriptors and duration measures, validates effective observation dates, and finally renders tables and charts. Error handling distinguishes timeouts from deterministic failures such as invalid tickers or missing entitlements, and the system retries only timeout-bound requests while preserving failed fields without hiding them.

**Section sources**
- [README.md:9-15](file://User scripts/FI Spread Movement Monitoring/README.md#L9-L15)
- [README.md:93-167](file://User scripts/FI Spread Movement Monitoring/README.md#L93-L167)
- [README.md:365-421](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L421)

## Project Structure
The universe selection logic is split across configuration, data access, engine processing, and the interactive controller:

| File | Responsibility |
|---|---|
| `config.py` | Universe source keys, spread types, descriptor fields, duration measures, window limits, cache settings, and chart/filter constants. |
| `data.py` | Input normalization, BQL universe construction, request execution, response parsing, descriptor/duration/series fetching, and change validation. |
| `engine.py` | Pure pandas ranking preparation, descriptor merging, dimension enrichment, bucketing, comparison summaries, and export helpers. |
| `app.py` | Desktop UI controller that wires controls to normalization, fetch, rendering, caching, and status display. |

```mermaid
graph TB
App["app.py<br/>UI controller"] --> Config["config.py<br/>Settings and constants"]
App --> Data["data.py<br/>BQL access and normalization"]
App --> Engine["engine.py<br/>Ranking and enrichment"]
Data --> Config
Engine --> Config
Data --> |"BQL responses"| Data
```

**Diagram sources**
- [app.py:37-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L37-L61)
- [data.py:51-99](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L99)
- [engine.py:1-21](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1-L21)
- [config.py:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)

**Section sources**
- [config.py:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)
- [data.py:51-99](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L99)
- [engine.py:1-21](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1-L21)
- [app.py:37-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L37-L61)

## Core Components
The universe selection system has five core responsibilities:

1. **Input normalization**: Convert dropdown choices and typed values into validated source keys and universe identifiers.
2. **Universe construction**: Build the correct BQL universe expression for index members, AIM holdings, a single bond, or a two-book comparison.
3. **Request execution**: Execute ranking, descriptor, duration, and series requests with retry-only-on-timeout behavior and per-field receipts.
4. **Normalization and enrichment**: Convert heterogeneous BQL frames into unified ID-keyed tables, attach descriptors, compute buckets, and validate changes.
5. **Comparison handling**: Keep AIM and Index books separate, deduplicate by `(Universe, ID)`, and merge descriptor/series data over the union of candidates.

Key configuration entries include:
- `UNIVERSE_SOURCES`: maps display labels to stored keys `index`, `aim`, `aim_vs_index`, and `bond`.
- `SPREAD_TYPES`: maps display labels to BQL spread codes `OAS`, `Z`, and `I`.
- `DESCRIPTOR_FIELDS`: name, country, sector, rating, currency, and maturity.
- `DURATION_FIELDS`: duration family built from one `duration()` builder.
- `AIM_PXNUM` and `AIM_PROFILE`: frozen AIM pricing number and profile.
- `MAX_RANGE_DAYS`: validation cap on the spread window.

**Section sources**
- [config.py:46-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L46-L96)
- [config.py:104-182](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L104-L182)
- [config.py:193-196](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L193-L196)
- [data.py:308-347](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L308-L347)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)

## Architecture Overview
The update flow starts at the UI, moves through normalization and BQL execution, then passes results to the engine for ranking preparation and enrichment.

```mermaid
sequenceDiagram
participant Operator as "Operator"
participant App as "FISpreadMovementApp"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
Operator->>App : Click Update
App->>Data : normalize_universe() or normalize_comparison()
Data-->>App : (source_key, universe_key)
App->>Data : fetch_movers() or fetch_comparison()
Data->>BQL : bq.univ.members / bq.univ.list
BQL-->>Data : Ranking responses
Data->>BQL : Descriptor, duration, series requests
BQL-->>Data : Normalized frames
Data->>Engine : prepare_ranked_movers()
Engine-->>Data : Ranked sides + notes
Data->>Engine : validate_candidate_changes()
Engine-->>Data : Series validation frame
Data-->>App : FetchResult
App->>Engine : enrich_ranked(), bucket_table(), spread_levels()
Engine-->>App : Display-ready frames
App-->>Operator : Tables, charts, status
```

**Diagram sources**
- [app.py:656-720](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L720)
- [data.py:1419-1488](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1419-L1488)
- [data.py:1592-1600](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1592-L1600)
- [engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

## Detailed Component Analysis

### Index-Based Analysis
Index-based analysis uses a typed Bloomberg index ticker. The input must be text, non-empty after whitespace cleanup, and must end with the required `Index` asset-class suffix. This prevents a bare ticker from being silently resolved to a different universe.

The universe is constructed as index membership keyed on the end date. The spread item is built with the selected spread type and a dated range, then transformed through `net_chg()`, filtered by direction, capped with `grouprank()`, and sorted with `groupsort()`.

```mermaid
flowchart TD
Start(["Index input"]) --> Normalize["Normalize index ticker"]
Normalize --> Valid{"Ends with 'Index'?"}
Valid --> |No| Refuse["Refuse: not an index ticker"]
Valid --> |Yes| BuildUniverse["Build bq.univ.members(index, dates=end)"]
BuildUniverse --> SpreadItem["Build spread(spread_type, dates=range)"]
SpreadItem --> NetChange["Apply net_chg()"]
NetChange --> Rank["Filter by sign, grouprank <= TOP_N, groupsort"]
Rank --> Candidates["Collect candidate IDs"]
Candidates --> Descriptors["Fetch descriptors, duration, series"]
```

**Diagram sources**
- [data.py:227-246](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L227-L246)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)
- [data.py:1273-1320](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1273-L1320)

Concrete example paths:
- Index validation: `_as_index` rejects empty, non-string, whitespace-only, and non-`Index`-suffixed values.
- Index universe construction: `_build_universe` returns `bq.univ.members(universe_key, dates=end)` for the `index` source.
- Index ranking: `_rank_movers` applies direction filtering, `grouprank`, and `groupsort`.

**Section sources**
- [data.py:227-246](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L227-L246)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)
- [data.py:1273-1320](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1273-L1320)

### AIM Account Holdings
AIM account holdings use a frozen contract: `bq.univ.members(type="AIM")` with `with_params` containing `accounts`, `pxnum`, and `profile`. No dates are attached to the members call, and no position item is requested because this app needs spread ranking rather than portfolio valuation.

The AIM code is normalized by trimming whitespace, rejecting internal spaces, and upper-casing the token. The frozen `AIM_PXNUM` defaults to `1377`, and `AIM_PROFILE` defaults to `DEFAULT_PROFILE`.

```mermaid
flowchart TD
AIMInput(["AIM account code"]) --> Clean["Strip whitespace, reject internal spaces"]
Clean --> Upper["Upper-case token"]
Upper --> Params["Build with_params(accounts=[code], pxnum, profile)"]
Params --> AIMUniverse["bq.univ.members(type='AIM')"]
AIMUniverse --> Ranking["Same spread ranking as index/bond"]
```

**Diagram sources**
- [data.py:284-305](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L284-L305)
- [data.py:361-392](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L361-L392)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)

Concrete example paths:
- AIM normalization: `_as_aim_account` raises for empty, non-string, blank-after-strip, and whitespace-containing values.
- AIM parameters: `_aim_with_params` returns the frozen block with `accounts=[account]`, `_aim_pxnum()`, and `AIM_PROFILE`.
- AIM universe: `_build_universe` returns `bq.univ.members(type="AIM")` plus the `with_params` dict.

Important behavior:
- Cash and equity lines can appear in AIM holdings; they return no spread and are excluded by diagnostics rather than by an unverified security-type filter.
- A ranking failure on the AIM path may indicate a universe-compatibility issue where BQL refuses the filter expression before evaluation.

**Section sources**
- [data.py:284-305](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L284-L305)
- [data.py:361-392](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L361-L392)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)
- [data.py:1322-1360](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1322-L1360)

### Individual Bond Monitoring
Individual bond monitoring takes exactly one typed bond ticker. It is wrapped in `bq.univ.list([one_ticker])`. A comma, semicolon, newline, or index-like suffix is refused so the universe cannot accidentally widen past the single security.

The same spread ranking and enrichment pipeline runs on the one-security universe, producing a one-row screen when the bond qualifies.

```mermaid
flowchart TD
BondInput(["Bond ticker"]) --> Validate["Reject lists, index suffix, empty value"]
Validate --> ListUniverse["bq.univ.list([ticker])"]
ListUniverse --> Ranking["Top 10 increases / decreases on one bond"]
Ranking --> Enrich["Descriptors, duration, series, validation"]
```

**Diagram sources**
- [data.py:249-281](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L249-L281)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)

Concrete example paths:
- Bond normalization: `_as_bond` rejects empty, non-string, whitespace-only, forbidden tokens, and index-suffixed values.
- Bond universe: `_build_universe` returns `bq.univ.list([universe_key])` for the `bond` source.
- Bond mode in UI: `_set_bond_mode` hides bucket and Top 10 charts because a single-bond run has no grouping surface.

**Section sources**
- [data.py:249-281](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L249-L281)
- [data.py:1255-1270](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1255-L1270)
- [app.py:978-990](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L978-L990)

### AIM vs Index Comparison
The comparison source requires both an AIM account and an index ticker. Both fields are validated together; a blank on either side is a refusal, never a one-sided run. The returned pair order preserves the operator’s left-to-right intent: AIM first, then Index.

Each book is ranked separately, producing four ranking requests in total. However, descriptors, duration measures, and the bounded series are requested once over the union of both candidate ID lists. Row identity is `(Universe, ID)`, so a bond that is both an index member and an AIM holding appears twice, once per book.

```mermaid
flowchart TD
Inputs(["AIM code + Index ticker"]) --> ValidateBoth["normalize_comparison()"]
ValidateBoth --> AIMBook["Rank AIM book"]
ValidateBoth --> IndexBook["Rank Index book"]
AIMBook --> UnionIDs["Union of candidate IDs"]
IndexBook --> UnionIDs
UnionIDs --> SharedRequests["One descriptor set + one duration family + one series"]
SharedRequests --> Merge["Attach descriptors and series by ID"]
Merge --> Compare["Compare AIM vs Index per book"]
```

**Diagram sources**
- [data.py:333-347](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L333-L347)
- [data.py:1363-1416](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1363-L1416)

Concrete example paths:
- Comparison validation: `normalize_comparison` validates AIM first, then index, returning `(("index", ticker), ("aim", code))`.
- Candidate union: `_candidate_ids` collects IDs from both sides and deduplicates them.
- Shared validation: `_validate_candidates` builds `bq.univ.list(candidate_ids)` once and runs descriptor, duration, and series requests.

**Section sources**
- [data.py:333-347](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L333-L347)
- [data.py:1363-1416](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1363-L1416)

### Normalization Pipeline
All source formats are converted into a unified data structure centered on `ID`. The main result object is `FetchResult`, which carries:
- `increases` and `decreases` ranking frames.
- `descriptors` merged by `ID`.
- `series` with `ID`, `DATE`, and `Spread`.
- `field_status` for per-field success or failure.
- `request_log` for elapsed time, attempts, rows, and columns.
- `errors` and `notes` for higher-level diagnostics.
- `universe`, `source`, `comparison`, and `cache_request` metadata.

Response normalization supports multiple BQL shapes:
- Security-ID index.
- `ID` column.
- `ID`/`DATE` MultiIndex.
- `DATE` column.
- Wide date-column series.

Row-number indexes are rejected to avoid fake IDs. Missing values stay missing; there is no fill, interpolation, zero substitution, or silent fallback.

```mermaid
flowchart TD
Raw["Raw BQL response"] --> ItemLookup["_response_item() or combined_df()"]
ItemLookup --> Frame["DataFrame"]
Frame --> NormalizeFrame["_normalize_frame()"]
NormalizeFrame --> Finalize["_finalize_id()"]
Finalize --> Unified["ID (+ optional DATE) + value"]
```

**Diagram sources**
- [data.py:76-106](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L106)
- [data.py:526-553](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L526-L553)
- [data.py:610-742](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L610-L742)
- [data.py:745-777](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L745-L777)

**Section sources**
- [data.py:76-106](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L106)
- [data.py:526-553](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L526-L553)
- [data.py:610-742](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L610-L742)
- [data.py:745-777](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L745-L777)

### Integration with Bloomberg BQL
The module imports `bql` conditionally so it remains importable outside BQuant Desktop. Requests are executed through `bql.Request` and `bq.execute`, with a wrapper that records timing, attempts, rows, and columns.

Integration points:
- `bq.univ.members(index, dates=end_date)` for index membership.
- `bq.univ.members(type="AIM")` with frozen `with_params` for AIM holdings.
- `bq.univ.list([ticker])` for individual bonds and candidate ID lists.
- `bq.data.spread(spread_type, dates=range(...))` for spread items.
- `spread.net_chg().grouprank().groupsort()` for change-based ranking.
- `bq.data.name()`, `rating()`, `crncy()`, `maturity()`, and `duration()` for descriptors and duration measures.
- `bql.combined_df(response)` as a documented fallback when the response does not expose `.get(name)` or item names.

**Section sources**
- [data.py:65-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L65-L70)
- [data.py:780-842](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L842)
- [data.py:1081-1168](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1081-L1168)
- [data.py:1171-1228](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1171-L1228)
- [data.py:1273-1320](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1273-L1320)

### Error Handling
Error handling is layered:

| Failure type | Behavior |
|---|---|
| Invalid index ticker | Refused before any request; error message names the expected suffix. |
| Invalid AIM code | Refused if empty, non-string, blank after strip, or containing whitespace. |
| Invalid bond ticker | Refused if empty, non-string, contains forbidden tokens, or looks like an index. |
| Unsupported spread type | Refused during window validation. |
| End date in the future | Refused. |
| Window wider than configured maximum | Refused. |
| Timeout | Retried once unchanged; cached fallback may serve a previous clean run. |
| Missing entitlement or invalid ticker | Deterministic failure; not retried. |
| Empty response | Logged as zero rows; not treated as a rejected field. |
| Failed descriptor field | Per-field `FAILED` status; other fields still render. |
| Change-arithmetic mismatch | Diagnostic note; tables remain readable. |

Timeout detection checks for timeout markers while excluding deterministic markers such as missing items, entitlement problems, unauthorized errors, invalid tickers, unknown fields, and license errors.

**Section sources**
- [data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [data.py:1231-1252](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1231-L1252)
- [data.py:801-842](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L801-L842)
- [app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)

### Performance Characteristics
The design avoids widening universes unnecessarily:
- Rankings are change-based and capped by `TOP_N`.
- Descriptors, duration measures, and series run on a bounded candidate ID list, not the full index.
- Duration measures are grouped into one request using one `duration()` builder with parameter values.
- In AIM vs Index mode, descriptors and series are requested once over the union of candidate IDs.
- The bounded series request also supplies `Start Spread` and `End Spread` without adding another data item.

Cache and retry protect against the Desktop two-minute timeout:
- `QUERY_ATTEMPTS` allows one retry for timeout-bound failures.
- `CACHE_KEEP_RUNS` keeps a small number of clean runs.
- Automatic fallback serves a cached run after a timeout, labeled `Cached` rather than `Updated`.
- `CACHE_READ_FIRST` can read the cache before asking Bloomberg, though it is off by default.

**Section sources**
- [config.py:138-160](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L138-L160)
- [config.py:349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)
- [data.py:1363-1416](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1363-L1416)
- [data.py:918-1055](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L918-L1055)
- [README.md:365-395](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L395)

## Dependency Analysis
The following diagram shows how the modules depend on each other and on Bloomberg BQL.

```mermaid
graph LR
Config["config.py"] --> Data["data.py"]
Config --> Engine["engine.py"]
Config --> App["app.py"]
Data --> |"bql.Request / bq.execute"| BQL["Bloomberg BQL"]
App --> Data
App --> Engine
Engine --> Config
```

**Diagram sources**
- [config.py:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)
- [data.py:63-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L63-L70)
- [app.py:37-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L37-L61)
- [engine.py:18-19](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L18-L19)

Coupling and cohesion observations:
- `config.py` is a low-coupling configuration layer consumed by all other modules.
- `data.py` is the highest-coupling module because it owns BQL integration, normalization, and request orchestration.
- `engine.py` is cohesive around pandas transformations and deliberately avoids importing BQL.
- `app.py` coordinates UI state, caching, and rendering while delegating data and ranking logic to `data.py` and `engine.py`.

Potential risks:
- If BQL response shapes change, `_normalize_frame`, `_response_item`, and `_combined_item` are the likely adaptation points.
- If AIM entitlement or universe compatibility changes, `_explain_ranking_error` and the AIM `with_params` block are the relevant areas.
- If descriptor or duration field semantics change, `config.DESCRIPTOR_FIELDS` and `config.DURATION_FIELDS` should be reviewed before changing request construction.

**Section sources**
- [data.py:395-510](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L395-L510)
- [data.py:610-742](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L610-L742)
- [data.py:1322-1360](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1322-L1360)
- [engine.py:1-7](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1-L7)

## Performance Considerations
For large portfolios and broad indices:
- Prefer the AIM vs Index comparison mode when comparing two universes; it shares descriptor and series requests instead of duplicating them.
- Keep the spread window narrow until timing evidence justifies widening; the build caps the window at 31 days.
- Use the bounded candidate universe for descriptors and series rather than evaluating duration over the entire index.
- Rely on the automatic retry and cached fallback for transient timeouts, but do not treat them as a way to hide deterministic failures.
- Monitor the request log for elapsed time, attempt count, row count, and column names.
- Avoid adding new descriptor or duration fields without measuring their cost across multi-currency index membership.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Common Universe Selection Problems

| Symptom | Likely cause | Recommended action |
|---|---|---|
| Index field refuses input | Ticker does not end with `Index` or is empty/whitespace | Type a Bloomberg index ticker with the required suffix. |
| AIM field refuses input | Code is empty, contains spaces, or is not text | Type one uppercase AIM account code without spaces. |
| Bond field refuses input | Value contains a separator, is empty, or looks like an index | Type one bond ticker; use the Index source for an index. |
| AIM vs Index refuses input | One or both fields are blank | Fill both the AIM code and the index ticker. |
| Date window refused | End date is in the future, start is not earlier than end, or window exceeds maximum | Choose two business days within the configured range. |
| Zero-ranked results | Membership not published, weekend/holiday anchor, quiet week, or wrong universe | Check the end date, business-day anchor, and universe key. |
| Descriptor column shows `(unavailable)` | Descriptor request failed | Inspect per-field status in Export Excel → Request detail. |
| Descriptor column shows `(blank)` | Bloomberg returned no value for that bond | Treat as missing data; do not infer a different field. |
| Cached screen appears | Live run timed out and a clean cached run exists | Review the amber `Cached` status and live error. |
| Change arithmetic mismatch | Effective dates shifted, stale observation, or unit/item difference | Copy affected rows into decision records and compare endpoints in Terminal. |

### Reading Failure Messages
- `Requesting the data failed` means the request was built or sent incorrectly.
- `Preparing the ranked tables failed` or `Drawing the figures failed` means data arrived but local processing failed.
- `0 row(s)` means a completed request matched nothing; it is not a rejected field.
- Per-field receipts are request metadata and appear under Export Excel → Request detail; only `FAILED` fields write to the step log.

### AIM-Specific Diagnostics
- AIM holdings can include cash and equity lines that carry no spread.
- A predicate rejection inside `FILTER(MEMBERS(type='AIM'), ...)` is a universe-compatibility finding, not proof that the account holds nothing.
- Do not retry an AIM predicate refusal unchanged; record it as a G4 universe-compatibility question.

### Index-Specific Diagnostics
- Index membership is keyed on the end date.
- A weekend or today’s date can produce an empty or moving cohort.
- The helper suggests the last business day on or before the problematic end date.

### Bond-Specific Diagnostics
- A private one-security universe that matches nothing produces no row.
- A valid bond with no change in the window also produces no ranked row.
- Confirm the ticker in Terminal before widening the window.

**Section sources**
- [data.py:227-305](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L227-L305)
- [data.py:1231-1252](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1231-L1252)
- [data.py:1505-1589](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1505-L1589)
- [data.py:1322-1360](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1322-L1360)
- [README.md:397-421](file://User scripts/FI Spread Movement Monitoring/README.md#L397-L421)

## Conclusion
The FI spread movement universe selection system cleanly separates configuration, BQL access, pandas processing, and UI control. Its three primary universe sources—index membership, AIM holdings, and individual bond monitoring—share the same spread-ranking and enrichment pipeline, while the AIM vs Index comparison adds a second book with shared descriptor and series requests.

The most important design principles are:
- Validate inputs before building requests.
- Keep universes bounded by ranking and candidate IDs.
- Normalize heterogeneous BQL responses into a unified ID-centric format.
- Preserve missing values and failed fields without silent substitution.
- Distinguish timeouts from deterministic failures.
- Log request metadata separately from displayed data.
- Use cached fallbacks only for transient timeouts.

Before production use, operators should verify units, entitlements, coverage, and endpoint behavior in Terminal, and record outcomes in the project’s decision and verification records.

[No sources needed since this section summarizes without analyzing specific files]