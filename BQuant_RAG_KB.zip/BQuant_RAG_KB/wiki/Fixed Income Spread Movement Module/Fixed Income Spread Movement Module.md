# Fixed Income Spread Movement Module

<cite>
**Referenced Files in This Document**
- [README.md](file://User scripts/FI Spread Movement Monitoring/README.md)
- [MAIN.ipynb](file://User scripts/FI Spread Movement Monitoring/MAIN.ipynb)
- [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [engine.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py)
- [data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [charts.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py)
- [cache.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py)
- [config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the Fixed Income Spread Movement monitoring module: how it selects a universe, calculates spread changes, ranks top movers, applies dimensional filters, visualizes results, caches historical runs, exports reporting tables, and integrates with Bloomberg data through BQL. It is based on the project’s runtime code and documentation rather than external assumptions.

The module is an update-driven BQuant Desktop application. It does not query Bloomberg until the operator clicks Update. The supported universe sources are:
- Index: a typed Bloomberg index ticker.
- AIM account: a typed AIM portfolio code whose holdings become the universe.
- AIM vs Index: both fields required; AIM and Index are ranked separately in one run.
- Bond: one typed bond ticker for targeted analysis.

Spread choices are OAS, Z-Spread, and I-Spread. Changes are shown in source spread units and are not labelled as basis points or percentages until verified against Terminal.

**Section sources**
- [README.md:9-39](file://User scripts/FI Spread Movement Monitoring/README.md#L9-L39)
- [README.md:82-167](file://User scripts/FI Spread Movement Monitoring/README.md#L82-L167)
- [config.py:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)
- [config.py:104-117](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L104-L117)

## Project Structure
The runnable package consists of seven modules plus a thin notebook entry point:
- `__init__.py`: package marker.
- `config.py`: operator settings, universe sources, spread types, descriptors, chart geometry, cache policy, and timeout behaviour.
- `data.py`: BQL access, input validation, request execution, retry logic, response parsing, and normalized frames.
- `engine.py`: pure pandas ranking preparation, descriptor merging, change validation, dimension buckets, and export helpers.
- `charts.py`: chart specifications and Plotly/SVG rendering.
- `cache.py`: CSV-based result cache with manifest, pruning, and fallback support.
- `app.py`: UI controller, status bar, filter handling, table rendering, and orchestration of data, engine, charts, and cache.
- `MAIN.ipynb`: imports the app and displays its interface without fetching data.

```mermaid
graph TB
Notebook["MAIN.ipynb"] --> App["app.py"]
App --> Config["config.py"]
App --> Data["data.py"]
App --> Engine["engine.py"]
App --> Charts["charts.py"]
App --> Cache["cache.py"]
Data --> Config
Engine --> Config
Charts --> Config
Cache --> Config
```

**Diagram sources**
- [MAIN.ipynb:10-24](file://User scripts/FI Spread Movement Monitoring/MAIN.ipynb#L10-L24)
- [app.py:26-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L26-L61)
- [data.py:51-63](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L63)
- [engine.py:9-18](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L9-L18)
- [charts.py:14-20](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L14-L20)
- [cache.py:38-46](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L38-L46)
- [config.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)

**Section sources**
- [README.md:45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)
- [MAIN.ipynb:10-24](file://User scripts/FI Spread Movement Monitoring/MAIN.ipynb#L10-L24)

## Core Components
- Universe selection: validated by `data.py` and driven by `config.UNIVERSE_SOURCES`.
- Spread change calculation: BQL-side ranking using `spread(...).net_chg()` over the selected date range, followed by local validation and enrichment.
- Top mover ranking: positive and negative sides prepared separately, deduplicated per book when comparing AIM and Index, and truncated to `TOP_N` per direction.
- Dimensional filtering: Country, Sector, Tenor, Rating, Currency applied locally over already-fetched frames.
- Visualization: bucket counts, signed change bars, diverging comparison bars, and a selected-bond spread path.
- Cache: persisted clean runs keyed by universe, spread type, dates, `TOP_N`, and generation token.
- Export: filtered ranked tables and request metadata copied into Excel without writing files.

Key responsibilities:
- `app.py`: user controls, status phases, event binding, orchestration, and display formatting.
- `data.py`: input normalization, BQL request construction, retry, response normalization, and candidate series retrieval.
- `engine.py`: side preparation, descriptor merge, spread-level attachment, change validation, dimension buckets, and export frame preparation.
- `charts.py`: specification creation and Plotly/SVG rendering.
- `cache.py`: save/load/prune/describe for cached runs.
- `config.py`: constants and operator decisions.

**Section sources**
- [app.py:656-720](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L720)
- [data.py:76-106](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L106)
- [engine.py:40-57](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L40-L57)
- [charts.py:143-171](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L143-L171)
- [cache.py:9-35](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L9-L35)
- [config.py:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)

## Architecture Overview
The application follows a layered flow: UI controller → data adapter → BQL → pandas engine → chart specs → renderers. Caching sits alongside the controller to protect against timeouts.

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "FISpreadMovementApp"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
participant Charts as "charts.py"
participant Cache as "cache.py"
User->>App : Click Update
App->>Cache : Check saved run (optional)
alt Cached load requested or automatic fallback
Cache-->>App : FetchResult + info
App->>Engine : Prepare and validate
Engine-->>App : Ranked frames + notes
App->>Charts : Build specs
Charts-->>App : Figures/specs
App-->>User : Updated/Cached screen
else Normal live run
App->>Data : Normalize inputs and build requests
Data->>BQL : Execute ranking, descriptors, duration family, series
BQL-->>Data : Responses
Data-->>App : FetchResult
App->>Engine : Prepare ranked movers and attach levels
Engine-->>App : Ranked frames + validation notes
App->>Charts : Build specs
Charts-->>App : Figures/specs
App->>Cache : Save clean run
App-->>User : Updated screen
end
```

**Diagram sources**
- [app.py:656-720](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L720)
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)

## Detailed Component Analysis

### Universe Selection Options
The four universe sources are configured in `config.py` and validated in `data.py`:
- Index: requires a ticker ending with the configured suffix.
- AIM account: uses the frozen contract from the knowledge base, including `accounts`, `pxnum`, and profile parameters attached via `with_params`.
- AIM vs Index: validates both fields together; neither can be blank. Each book keeps its own ranking and top-N cut.
- Bond: accepts exactly one ticker; list separators and index-like values are refused.

```mermaid
flowchart TD
Start(["Update inputs"]) --> Source{"Universe source"}
Source --> |Index| ValidateIndex["Validate index ticker<br/>must end with 'Index'"]
Source --> |AIM account| ValidateAIM["Trim, upper-case,<br/>no inner whitespace"]
Source --> |AIM vs Index| ValidateBoth["Validate AIM first,<br/>then Index; both required"]
Source --> |Bond| ValidateBond["One ticker;<br/>refuse list/index tokens"]
ValidateIndex --> BuildRequest["Build BQL universe"]
ValidateAIM --> BuildRequest
ValidateBoth --> BuildComparison["Build two universes<br/>and rank separately"]
ValidateBond --> BuildRequest
```

**Diagram sources**
- [config.py:49-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L49-L55)
- [data.py:227-347](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L227-L347)

**Section sources**
- [README.md:93-130](file://User scripts/FI Spread Movement Monitoring/README.md#L93-L130)
- [config.py:49-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L49-L96)
- [data.py:227-347](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L227-L347)

### Spread Change Calculation Methodology
Spread change is calculated as the net change over the selected date range. The app:
- Requests the chosen spread type (`OAS`, `Z`, or `I`) over `range(start, end)`.
- Uses `net_chg()` for ranking.
- Does not add fill; missing values stay missing.
- Validates that the effective start/end dates and the arithmetic match the bounded candidate series.

```mermaid
flowchart TD
Dates["Start and end dates"] --> Range["BQL date range"]
SpreadType["Spread type: OAS / Z / I"] --> Item["spread(spread_type,...)"]
Range --> Item
Item --> NetChange["net_chg()"]
NetChange --> Rank["grouprank/groupsort"]
Rank --> Candidates["Top increases and decreases"]
Candidates --> SeriesCheck["Bounded candidate series check"]
SeriesCheck --> Validation["Effective dates and Change = Last - First"]
```

**Diagram sources**
- [data.py:28-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L28-L36)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

**Section sources**
- [README.md:131-167](file://User scripts/FI Spread Movement Monitoring/README.md#L131-L167)
- [README.md:319-363](file://User scripts/FI Spread Movement Monitoring/README.md#L319-L363)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

### Top Movers Ranking Algorithms
Ranking is performed in two stages:
1. BQL-side ranking returns candidates with `ID` and `Change`.
2. `engine._prepare_side` cleans IDs, removes invalid rows, handles duplicates, enforces direction, sorts by magnitude, and truncates to `TOP_N`. In comparison mode, the cut is per book.

```mermaid
flowchart TD
Raw["Ranked response"] --> Clean["Normalize ID and Change"]
Clean --> Invalid["Drop blank ID or non-finite Change"]
Invalid --> Duplicates{"Duplicate ID?"}
Duplicates --> |Yes| Dedup["Keep last row per key<br/>(book,ID) in comparison"]
Duplicates --> |No| Direction["Filter wrong sign"]
Dedup --> Direction
Direction --> Sort["Sort by absolute Change"]
Sort --> Cut["Truncate to TOP_N<br/>per direction"]
Cut --> Output["Prepared side"]
```

**Diagram sources**
- [engine.py:81-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L81-L176)

**Section sources**
- [engine.py:81-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L81-L176)
- [engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)

### Dimensional Filtering Capabilities
Filters are local views over the frames returned by the last Update:
- Country and Sector come from requested descriptors.
- Tenor is derived from `Maturity` and the end date.
- Rating is bucketed into IG, HY, NR/Missing, Numeric unmapped, and Other.
- Currency comes from the returned currency field.

A picked value with no matching row produces an empty view rather than falling back to all data.

```mermaid
flowchart TD
Loaded["Loaded ranked frames"] --> Filters["Country, Sector, Tenor, Rating, Currency"]
Filters --> Bucket["Group by selected dimension"]
Bucket --> Chart["Bucket mover counts"]
Bucket --> Table["Full bucket table"]
Filters --> Signed["Signed change per mover"]
Signed --> Detail["Selected security detail"]
```

**Diagram sources**
- [engine.py:597-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L597-L800)
- [config.py:202-279](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L202-L279)

**Section sources**
- [README.md:168-241](file://User scripts/FI Spread Movement Monitoring/README.md#L168-L241)
- [engine.py:597-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L597-L800)
- [config.py:202-279](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L202-L279)

### Chart Visualization System
The visualization system separates data computation from rendering:
- `engine.py` computes ranked movers, buckets, spread levels, and daily observations.
- `charts.py` creates plain-dict specifications for buckets, signed changes, paths, and comparisons.
- Plotly `FigureWidget` objects are updated in place on Desktop; otherwise, an HTML/SVG fallback renders the same spec.

Supported charts:
- Movers by bucket: horizontal grouped bars counting increases and decreases.
- Signed change per mover: ordered by magnitude, colour-coded by direction or book.
- AIM vs Index diverging comparison: symmetric zero line, direction hue, book depth.
- Spread path: one selected bond across observation dates.

```mermaid
classDiagram
class Charts {
+bucket_spec(labels, increases, decreases, dimension, total_movers) dict
+change_spec(frame, side, spread_label, top_n) dict
+path_spec(wide, spread_label, start, end, selected, note) dict
+comparison_spec(labels, increases, decreases, books, dimension, total_movers, ...) dict
+plotly_available() bool
+html_fallback(spec) str
}
class PlotlyRenderer {
+bucket_figure(spec) FigureWidget
+apply_bucket(figure, spec) void
+change_figure(spec) FigureWidget
+apply_change(figure, spec) void
+comparison_figure(spec) FigureWidget
+apply_comparison(figure, spec) void
+path_figure(spec) FigureWidget
+apply_paths(figure, spec) void
}
Charts <.. PlotlyRenderer : "specifications"
```

**Diagram sources**
- [charts.py:147-434](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L147-L434)
- [charts.py:530-766](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L530-L766)

**Section sources**
- [README.md:197-288](file://User scripts/FI Spread Movement Monitoring/README.md#L197-L288)
- [charts.py:1-12](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L1-L12)
- [charts.py:147-434](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L147-L434)
- [charts.py:530-766](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L530-L766)

### Cache System for Historical Spread Data
The cache stores one clean run per key:
- Key includes generation token, source, universe, AIM value, spread code, start, end, and `TOP_N`.
- Only successful runs with ranked rows are saved.
- Runs are pruned by sequence number, keeping the most recent `CACHE_KEEP_RUNS`.
- Automatic fallback serves a cached run only after a timeout and when a clean run exists for the same key.

```mermaid
flowchart TD
Run["Successful Update"] --> Storable{"Has ranked rows?"}
Storable --> |No| Skip["Do not cache"]
Storable --> |Yes| Write["Write ranked, descriptors, series, manifest"]
Write --> Prune["Prune oldest beyond CACHE_KEEP_RUNS"]
Timeout["Timeout failure"] --> Fallback{"Clean cached run exists?"}
Fallback --> |Yes| Serve["Serve Cached screen"]
Fallback --> |No| Error["Show error"]
```

**Diagram sources**
- [cache.py:9-35](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L9-L35)
- [cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:379-427](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L427)

**Section sources**
- [README.md:365-396](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L396)
- [cache.py:9-35](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L9-L35)
- [cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)
- [cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [cache.py:379-427](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L427)

### Export Capabilities for Reporting
Export supports:
- Top 10 increases.
- Top 10 decreases.
- Request log.

Every exported table repeats column names as the first data row so copy-paste into Excel preserves headers. The request log is request metadata and is not filterable.

**Section sources**
- [README.md:290-317](file://User scripts/FI Spread Movement Monitoring/README.md#L290-L317)
- [config.py:324-337](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L324-L337)

### Integration with Multiple Data Sources
Integration points:
- Bloomberg indices: `bq.univ.members(index, dates=end_date)` membership as of the end date.
- AIM portfolios: frozen contract with `type="AIM"`, `accounts=[one code]`, `pxnum`, and profile parameters.
- Individual bonds: `bq.univ.list([one_ticker])`.
- Spread measures: `spread(spread_type=..., dates=range(start,end)).net_chg()` with grouprank/groupsort.
- Descriptors and duration family: requested once per candidate set, with duration measures parameterized under one builder.

**Section sources**
- [README.md:102-130](file://User scripts/FI Spread Movement Monitoring/README.md#L102-L130)
- [data.py:1-49](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1-L49)
- [data.py:380-392](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L380-L392)
- [config.py:138-182](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L138-L182)

## Dependency Analysis
The main dependency relationships are:
- `app.py` depends on `config`, `data`, `engine`, `charts`, and `cache`.
- `data.py` depends on `config` and the Bloomberg BQL environment.
- `engine.py` depends only on `config` and pandas/numpy.
- `charts.py` depends on `config` and optionally Plotly/ipywidgets.
- `cache.py` depends on `config` and pandas.

```mermaid
graph LR
App["app.py"] --> Config["config.py"]
App --> Data["data.py"]
App --> Engine["engine.py"]
App --> Charts["charts.py"]
App --> Cache["cache.py"]
Data --> Config
Engine --> Config
Charts --> Config
Cache --> Config
```

**Diagram sources**
- [app.py:26-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L26-L61)
- [data.py:51-63](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L63)
- [engine.py:9-18](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L9-L18)
- [charts.py:14-20](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L14-L20)
- [cache.py:38-46](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L38-L46)

**Section sources**
- [app.py:26-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L26-L61)
- [data.py:51-63](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L63)
- [engine.py:9-18](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L9-L18)
- [charts.py:14-20](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L14-L20)
- [cache.py:38-46](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L38-L46)

## Performance Considerations
- Request budget: one-book runs use ten requests; AIM vs Index uses twelve. Descriptor and series requests run once on the union of candidate lists.
- Duration measures: three extra duration columns share one existing request instead of adding new calls.
- Retry: timed-out requests are retried once; deterministic failures are not retried.
- Cache: avoids repeated expensive queries after a successful run.
- Local filters: interactive filters do not rebuild requests.

Recommendations:
- Keep windows narrow during validation.
- Prefer AIM vs Index only when needed; it doubles ranking requests.
- Use Display Top to reduce chart rendering load without changing what was fetched.
- Monitor the request log for elapsed time and row/column counts.

**Section sources**
- [README.md:82-140](file://User scripts/FI Spread Movement Monitoring/README.md#L82-L140)
- [README.md:168-188](file://User scripts/FI Spread Movement Monitoring/README.md#L168-L188)
- [config.py:138-182](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L138-L182)
- [config.py:347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)

## Troubleshooting Guide

### Data Quality Issues
- Missing values stay missing; there is no fill, interpolation, zero substitution, or silent spread-type fallback.
- A failed descriptor leaves `(unavailable)` for that bond; a blank Bloomberg value shows as `(blank)`.
- If the bounded series check reports mismatches, inspect effective dates and endpoint spreads in Terminal before widening the window.

**Section sources**
- [README.md:163-167](file://User scripts/FI Spread Movement Monitoring/README.md#L163-L167)
- [README.md:319-363](file://User scripts/FI Spread Movement Monitoring/README.md#L319-L363)
- [engine.py:179-240](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L179-L240)

### Ranking Accuracy
- Duplicate detection uses `(book, ID)` in comparison mode so the same bond appearing in both AIM and Index is not dropped.
- Wrong-sign rows are excluded after cleaning.
- Ties at the cutoff are handled deterministically; truncation notes explain whether fewer rows were available.

**Section sources**
- [engine.py:117-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L117-L176)
- [engine.py:274-301](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L274-L301)

### Performance Optimization
- Avoid unnecessary wide windows; default is seven days and maximum is thirty-one days.
- Use the cache for repeat diagnostics after a successful run.
- Rely on local filters; they do not trigger additional Bloomberg requests.
- Watch for retries: only timeouts are retried, so deterministic errors should be fixed immediately.

**Section sources**
- [config.py:193-196](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L193-L196)
- [config.py:347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)
- [README.md:168-188](file://User scripts/FI Spread Movement Monitoring/README.md#L168-L188)

### Status and Failure Interpretation
- Refused: input validation failed; no request was sent.
- Error: request or local processing failed; diagnostics remain visible.
- Incomplete: some requests failed but partial data may still be useful.
- Cached: served from disk after a timeout; never labelled Updated.

**Section sources**
- [README.md:397-421](file://User scripts/FI Spread Movement Monitoring/README.md#L397-L421)
- [app.py:63-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L63-L86)

## Conclusion
The Fixed Income Spread Movement module provides a controlled, validated workflow for detecting, ranking, and visualizing spread movers across multiple universe sources. Its design emphasizes fail-visible diagnostics, bounded request breadth, local-only interactivity, and a robust cache fallback. Operators should treat the output as a validation tool until entitlement, field semantics, and units are confirmed in Terminal.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Configuration Summary
- Top N: 10.
- Spread types: OAS, Z-Spread, I-Spread.
- Default window: seven calendar days; maximum thirty-one days.
- Dimensions: Country, Sector, Tenor, Rating, Currency.
- Cache: keep up to twelve runs; read-first off by default.
- Query attempts: two for timeout recovery.

**Section sources**
- [config.py:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)
- [config.py:104-117](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L104-L117)
- [config.py:193-196](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L193-L196)
- [config.py:202-279](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L202-L279)
- [config.py:347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)

### Best Practices for Universe Selection and Signal Interpretation
- Always type the universe explicitly; placeholders are examples only.
- For AIM vs Index, provide both fields; the comparison is per book, not a merged universe.
- For Bond, enter exactly one ticker; do not paste lists.
- Inspect the bounded series check notes before trusting units or endpoints.
- Treat source-unit changes as unverified until Terminal confirms basis-point or percentage conventions.
- Use filters to understand distribution across country, sector, tenor, rating, and currency, but remember they are local views.

**Section sources**
- [README.md:93-130](file://User scripts/FI Spread Movement Monitoring/README.md#L93-L130)
- [README.md:319-363](file://User scripts/FI Spread Movement Monitoring/README.md#L319-L363)
- [README.md:423-457](file://User scripts/FI Spread Movement Monitoring/README.md#L423-L457)