# Data Processing Pipeline and Cache System

<cite>
**Referenced Files in This Document**
- [cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [cache.py](file://User scripts/FI Index Change/fi_index_change/cache.py)
- [data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the data processing pipeline and cache management system used by two Bloomberg BQL-based applications:

- ETF Spread Monitoring: a daily history pipeline that loads book and peer market data, validates responses, normalizes them into consistent structures, merges cached and live rows, computes spreads, and exports reporting views.
- FI Index Change: a fixed-income index membership pipeline that requests historical month-end snapshots, parses multi-item BQL responses, classifies bonds, compares previous and selected dates, and persists validated snapshots.

The documentation focuses on:
- How raw Bloomberg BQL responses are ingested and validated.
- How data is normalized into stable ID/date/value schemas.
- How file-based caches store settled history and how they are invalidated when contracts or identities change.
- How automatic fallbacks avoid stale or poisoned data.
- How Excel export and request logging support debugging and reporting.
- How lifecycle, expiration, and performance policies keep long-running sessions reliable.

## Project Structure
The relevant code lives under `User scripts`, with two main application packages sharing similar patterns:

```mermaid
graph TB
subgraph "ETF Spread Monitoring"
ETF_APP["app.py"]
ETF_DATA["data.py"]
ETF_ENGINE["engine.py"]
ETF_CACHE["cache.py"]
end
subgraph "FI Index Change"
FI_DATA["data.py"]
FI_CACHE["cache.py"]
end
ETF_APP --> ETF_DATA
ETF_APP --> ETF_ENGINE
ETF_APP --> ETF_CACHE
ETF_DATA --> ETF_CACHE
FI_DATA --> FI_CACHE
```

**Diagram sources**
- [app.py:1-55](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L55)
- [data.py:1-48](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1-L48)
- [engine.py:1-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L1-L16)
- [cache.py:1-40](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L40)
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [cache.py:1-27](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L27)

**Section sources**
- [app.py:1-55](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L55)
- [data.py:1-48](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1-L48)
- [engine.py:1-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L1-L16)
- [cache.py:1-40](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L40)
- [data.py:1-33](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L33)
- [cache.py:1-27](file://User scripts/FI Index Change/fi_index_change/cache.py#L1-L27)

## Core Components
The pipeline has four major responsibilities:

1. **Data ingestion layer**: Builds or adapts Bloomberg BQL requests, executes them through `bql.Service`, and converts Arrow-style responses into pandas DataFrames.
2. **Validation and normalization layer**: Checks response shapes, selects value columns safely, deduplicates IDs, aligns dates, and converts vendor scales to consistent units.
3. **Cache layer**: Stores settled history as CSV files plus a JSON manifest, validates contract tokens, fingerprints, identity ledgers, and coverage windows.
4. **View and export layer**: Computes spreads, summaries, charts, and Excel-ready frames from normalized data without re-requesting Bloomberg.

Key design principles:
- Fail-closed: unreadable or malformed cache files read as empty; the pipeline requests fresh data instead of serving corrupted results.
- Contract-aware: stored data is rejected if column contracts, generation tokens, or request fingerprints change.
- Identity-aware: identifiers are bound to security tokens so ticker reuse or share-class re-pointing does not silently replay old rows.
- Settled-only writes: only dates before the last completed session are persisted; moving prints stay live.

**Section sources**
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [data.py:334-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L334-L458)
- [data.py:466-527](file:// User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)
- [data.py:573-636](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L573-L636)
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)

## Architecture Overview
The ETF Spread Monitoring pipeline follows this flow:

```mermaid
sequenceDiagram
participant UI as "ETFSpreadMonitor<br/>app.py"
participant Data as "data.py"
participant Cache as "cache.py"
participant BQL as "Bloomberg BQL Service"
participant Disk as "CSV + manifest.json"
UI->>Data : fetch_parallel_histories(today, use_cache)
Data->>Cache : plan_gaps(kind, ids, cached, window)
alt Cache hit for settled days
Cache-->>Data : subset of stored rows
else Missing or invalid cache
Data->>BQL : execute prepared history requests
BQL-->>Data : ArrowExecuteResponse items
Data->>Data : normalize, combine, validate
Data->>Disk : save(settled rows, fingerprint, identities)
end
Data-->>UI : merged observations + errors + notes
UI->>Engine : build_view(observations, period)
Engine-->>UI : summary + chart + window metadata
```

**Diagram sources**
- [app.py:306-377](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L377)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

The FI Index Change pipeline is simpler but more sensitive to response shape:

```mermaid
flowchart TD
Start(["Update"]) --> Decide["Historical snapshot available?"]
Decide --> |Yes| Load["load_historical(index_ticker, as_of)"]
Load --> ValidateContract{"Contract, generation,<br/>required columns OK?"}
ValidateContract --> |No| Request["Request members via BQL"]
ValidateContract --> |Yes| Finalize["_finalize_snapshot()"]
Decide --> |No| Request
Request --> Parse["_parse_response()"]
Parse --> SplitMode{"Split analytics groups?"}
SplitMode --> |No| MergeAll["Merge all ITEM_NAMES"]
SplitMode --> |Yes| MergeIdentity["Fetch identity group"]
MergeIdentity --> MergeAnalytics["Fetch analytics groups separately"]
MergeAll --> CheckWeight["Weight present and usable?"]
MergeAnalytics --> CheckWeight
CheckWeight --> Status["Set status ok/partial/unavailable"]
Status --> Save["save_historical() if safe"]
Save --> End(["Payload ready"])
```

**Diagram sources**
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [data.py:408-491](file:// User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:604-698](file://User scripts/FI Index Change/fi_index_change/data.py#L604-L698)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)

## Detailed Component Analysis

### ETF Spread Monitoring: Ingestion and Normalization
The ETF spread pipeline separates placeholder/live source adapters from normalization logic. The current default sources return deterministic placeholder data, while Bloomberg adapter classes reserve the integration path.

Key behaviors:
- Placeholder sources generate reproducible bid/ask series keyed by share class and peer group.
- Bloomberg source adapters currently report diagnostics rather than executing requests.
- Multi-item BQL responses are converted to a unified frame with an explicit `ID` column and optional `DATE`.
- Time-series items merge on `ID+DATE`; static items merge on `ID`.
- Duplicate keys are collapsed deterministically, keeping the last row after sorting.
- Currency-sensitive listings preserve response currency and drop mismatched lines.

```mermaid
classDiagram
class SourceResult {
+DataFrame observations
+list errors
}
class PlaceholderBookSource {
+fetch(today) SourceResult
}
class BloombergBookSource {
+fetch(today) SourceResult
}
class PlaceholderPeerSource {
+fetch(today) SourceResult
}
class BloombergPeerSource {
+fetch(today) SourceResult
}
class _item_frame_for_combine {
+normalize(item.df()) DataFrame
}
class _combine_items {
+merge_time_series()
+merge_static()
}
PlaceholderBookSource --> SourceResult : "returns"
BloombergBookSource --> SourceResult : "returns"
PlaceholderPeerSource --> SourceResult : "returns"
BloombergPeerSource --> SourceResult : "returns"
_combine_items --> _item_frame_for_combine : "uses"
```

**Diagram sources**
- [data.py:50-66](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L50-L66)
- [data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [data.py:378-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L378-L458)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)

**Section sources**
- [data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [data.py:334-458](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L334-L458)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)
- [data.py:639-663](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L639-L663)

### ETF Spread Monitoring: Cache Architecture
The ETF history cache stores one CSV per data kind (`quotes`, `returns`, `navs`, `flows`) and a shared `manifest.json`. It is designed around append-only settled rows and per-identifier coverage.

Important properties:
- **File layout**: `cache/{kind}.csv` plus `cache/manifest.json`.
- **Contract token**: derived from stored column names per kind.
- **Generation token**: manual bump when stored semantics change.
- **Request fingerprint**: hash of executable builder source, excluding docstrings and comments.
- **Identity ledger**: maps normalized identifier strings to resolved security tokens.
- **Coverage tracking**: first and last date per identifier, used to compute missing heads and tails.
- **Window trimming**: returned data is trimmed to the requested window even if the stored file is wider.

```mermaid
flowchart TD
Read["read_series(kind, root, fingerprint, identities)"] --> Manifest{"contract + generation match?"}
Manifest --> |No| Empty["Return empty frame"]
Manifest --> |Yes| FileCheck{"CSV exists and readable?"}
FileCheck --> |No| Empty
FileCheck --> |Yes| Parse["Parse CSV, coerce types, normalize DATE"]
Parse --> StaleCheck{"stale_identities() changed?"}
StaleCheck --> |Yes| DropStale["Drop changed identifiers"]
StaleCheck --> |No| SortDedup["Sort + deduplicate by ID+DATE"]
DropStale --> Trim["trim_to_window(start, end)"]
SortDedup --> Trim
Trim --> Result["Return normalized frame"]
```

**Diagram sources**
- [cache.py:124-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L124-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:468-489](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L468-L489)

**Section sources**
- [cache.py:29-61](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L29-L61)
- [cache.py:64-117](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L117)
- [cache.py:120-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L164)
- [cache.py:167-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L167-L231)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:336-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L336-L414)
- [cache.py:435-489](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L489)
- [cache.py:492-583](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L583)

### ETF Spread Monitoring: Data Refresh Strategy
The refresh strategy distinguishes between:
- **Cached rows**: settled rows already written to disk.
- **Live rows**: newly fetched data for missing dates.
- **Computed metrics**: spreads, percent spreads, and other derived values computed after merging.

Refresh steps:
1. Determine the frozen relative window (for example five years).
2. Compute per-identifier coverage from the cache.
3. Plan gap jobs: full window for new identifiers, absolute head/tail windows for late starts or early stops.
4. Fetch missing data through the data layer.
5. Merge cached and live rows, letting live rows win on duplicate `(ID, DATE)` keys.
6. Trim the final result to the requested window.
7. Write only settled rows back to disk.

```mermaid
flowchart TD
Start(["Refresh"]) --> Coverage["coverage(cached)"]
Coverage --> Plan["plan_gaps(kind, identifiers, cached, start, end)"]
Plan --> Jobs{"Jobs returned?"}
Jobs --> |No| MergeOnly["merge(cached, [])"]
Jobs --> |Yes| Fetch["Fetch missing windows"]
Fetch --> Merge["merge(cached, live_frames)"]
MergeOnly --> Trim["trim_to_window(requested window)"]
Merge --> Trim
Trim --> Save["save(settled rows)"]
Save --> End(["Ready"])
```

**Diagram sources**
- [cache.py:336-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L336-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-583](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L583)

**Section sources**
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-583](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L583)

### ETF Spread Monitoring: View Building and Export
The view layer is pure table logic: it does not fetch data. It cleans observations, computes spreads, applies period windows, summarizes statistics, and prepares chart frames.

Key outputs:
- Summary table with last, mean, median, min, max spread, observation counts, and window bounds.
- Chart table with date, series name, spread, and series type.
- Notes describing dropped rows, crossed quotes, missing peers, and unavailable history.

```mermaid
flowchart TD
Input["observations DataFrame"] --> Prepare["prepare_observations()"]
Prepare --> Select["Select share classes and peer groups"]
Select --> Window["period_bounds(period_key, as_of)"]
Window --> Slice["Filter to window"]
Slice --> Stats["_summarize()"]
Slice --> Chart["_chart_frame()"]
Stats --> View["SpreadView(summary, chart, as_of, windows, notes)"]
Chart --> View
```

**Diagram sources**
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:217-291](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L291)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

**Section sources**
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:217-291](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L291)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

### FI Index Change: Response Parsing and Validation
The FI Index Change pipeline is stricter about response shape because a wrong column selection can make every bond appear blank while the request itself was valid.

Parsing rules:
- Promote index levels to a named `ID` column.
- Prefer documented aliases such as `BASE_RATING` when available.
- Choose the most populated candidate column among known names.
- Collapse duplicate IDs before merging.
- Merge items on `ID` only; `DATE` is not part of the snapshot identity.
- Report missing items, empty identity columns, and identical duration measures.

```mermaid
flowchart TD
Item["BQL item"] --> Promote["_promote_id_index()"]
Promote --> Pick["_pick_value_column()"]
Pick --> Frame["ID (+DATE) + value column"]
Frame --> Collapse["_collapse_ids()"]
Collapse --> Merge["_merge_item_frames()"]
Merge --> Validate["_parse_response()"]
Validate --> WeightCheck["Weight present and usable?"]
WeightCheck --> Status["ok / partial / unavailable"]
```

**Diagram sources**
- [data.py:199-253](file://User scripts/FI Index Change/fi_index_change/data.py#L199-L253)
- [data.py:256-321](file://User scripts/FI Index Change/fi_index_change/data.py#L256-L321)
- [data.py:324-348](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L348)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)

**Section sources**
- [data.py:125-196](file://User scripts/FI Index Change/fi_index_change/data.py#L125-L196)
- [data.py:199-321](file:// User scripts/FI Index Change/fi_index_change/data.py#L199-L321)
- [data.py:324-491](file://User scripts/FI Index Change/fi_index_change/data.py#L324-L491)

### FI Index Change: Retry and Timeout Handling
The retry policy is intentionally narrow: only true timeouts are retried. Deterministic failures such as unentitled fields, invalid tickers, or unknown items are not retried because repeating them wastes time and cannot recover.

Timeout markers include generic timeout text, while deterministic markers explicitly exclude entitlement and authorization errors.

```mermaid
flowchart TD
Execute["bq.execute(member_request)"] --> Success{"Response received?"}
Success --> |Yes| Return["Return response"]
Success --> |No| Classify["Classify exception"]
Classify --> Deterministic{"Deterministic failure?"}
Deterministic --> |Yes| Fail["Record error, stop retries"]
Deterministic --> |No| Timeout{"Timeout marker?"}
Timeout --> |Yes| Retry{"Attempts remaining?"}
Retry --> |Yes| Execute
Retry --> |No| Fail
Timeout --> |No| Fail
```

**Diagram sources**
- [data.py:494-596](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L596)

**Section sources**
- [data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [data.py:541-596](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L596)

### FI Index Change: Snapshot Cache
The FI Index Change cache stores validated monthly snapshots keyed by `(index_ticker, as_of)`. Unlike the ETF cache, which stores daily series per kind, this cache stores one complete snapshot per month.

Cache validation includes:
- Field contract based on item names and label overrides.
- Generation token for pipeline changes that do not alter the field list.
- Required columns including identity and weight.
- Usable numeric conversion.
- Rejection of snapshots where identity columns are entirely blank.

```mermaid
flowchart TD
Load["load_historical(index_ticker, as_of)"] --> ManifestEntry{"Manifest entry exists?"}
ManifestEntry --> |No| Miss["Return None"]
ManifestEntry --> |Yes| Contract{"fields + generation + required_columns OK?"}
Contract --> |No| Miss
Contract --> |Yes| Read["Read CSV"]
Read --> Numeric["Coerce NUMERIC_COLUMNS"]
Numeric --> WeightCheck{"Weight has usable values?"}
WeightCheck --> |No| Miss
WeightCheck --> IdentityCheck{"Any identity column has usable value?"}
IdentityCheck --> |No| Miss
IdentityCheck --> |Yes| Return["Return frame"]
```

**Diagram sources**
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)

**Section sources**
- [cache.py:28-57](file://User scripts/FI Index Change/fi_index_change/cache.py#L28-L57)
- [cache.py:60-84](file://User scripts/FI Index Change/fi_index_change/cache.py#L60-L84)
- [cache.py:108-143](file://User scripts/FI Index Change/fi_index_change/cache.py#L108-L143)
- [cache.py:146-196](file://User scripts/FI Index Change/fi_index_change/cache.py#L146-L196)
- [cache.py:199-229](file://User scripts/FI Index Change/fi_index_change/cache.py#L199-L229)

## Dependency Analysis
The ETF Spread Monitoring package shows clear separation between UI, data loading, computation, and caching:

```mermaid
graph LR
App["app.py"] --> Data["data.py"]
App --> Engine["engine.py"]
App --> Cache["cache.py"]
Data --> Cache
Data --> BookView["book_view module"]
Data --> PeerMap["peer_map module"]
Engine --> Config["config module"]
Cache --> Pandas["pandas"]
```

**Diagram sources**
- [app.py:1-55](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L55)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [engine.py:15-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L16)
- [cache.py:26-26](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L26-L26)

The FI Index Change package ties request execution directly to parsing and caching:

```mermaid
graph LR
Data["data.py"] --> Cache["cache.py"]
Data --> Engine["engine module"]
Data --> FieldLibrary["field_library module"]
Data --> Config["config module"]
Cache --> FieldLibrary
Cache --> Engine
```

**Diagram sources**
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

**Section sources**
- [app.py:1-55](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L55)
- [data.py:27-47](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L27-L47)
- [engine.py:15-16](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L16)
- [data.py:14-33](file://User scripts/FI Index Change/fi_index_change/data.py#L14-L33)
- [cache.py:13-26](file://User scripts/FI Index Change/fi_index_change/cache.py#L13-L26)

## Performance Considerations
- **Append-only settled rows**: ETF history avoids rewriting settled days, reducing Bloomberg calls on repeated Refreshes.
- **Per-identifier coverage**: Only missing identifiers or missing date ranges trigger new requests.
- **Absolute gap windows**: Head and tail gaps use absolute dates so relative windows do not accidentally skip weekends or holidays.
- **Fail-closed reads**: Corrupt or incompatible cache files are ignored, avoiding expensive recovery loops.
- **Atomic writes**: CSV and manifest writes use temporary files and `os.replace`, preventing half-written artifacts.
- **Narrow retry scope**: FI Index Change retries only timeouts, avoiding repeated waits on deterministic failures.
- **Batched requests**: ETF data uses batch sizes and wave execution to respect Desktop timeout limits.
- **Memory-only views**: Engine functions operate on in-memory DataFrames without network I/O.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Cache Corruption
Symptoms:
- A stored file is ignored and the full window is re-requested.
- A mislabeled or schema-mismatched file reads as empty.
- A file with no value columns is treated as absent.

Recovery:
- Do not manually edit `manifest.json` unless you understand contract and generation tokens.
- Toggle `Use cache` off to force a full re-request and rewrite the cache.
- Verify that the stored columns match the expected kind contract.

**Section sources**
- [cache.py:124-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L124-L164)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:492-583](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L583)

### Data Staleness
Symptoms:
- Old rows serve for a ticker that now points to a different security.
- A fund added later receives a full window while existing funds receive only recent days.
- A 1Y view returns five years of data.

Recovery:
- The identity ledger detects mismatches between stored identifiers and current security tokens.
- New identifiers have no coverage and get their own full-window request.
- Results are trimmed to the requested window.

**Section sources**
- [cache.py:167-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L167-L231)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:468-489](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L468-L489)

### Memory Management in Long-Running Sessions
Guidance:
- Keep computed metrics out of the cache; only raw request output is stored.
- Avoid storing display frames or derived spreads in persistent files.
- Use filters and periods to limit in-memory views rather than repeatedly fetching wide histories.
- Monitor CSV growth per identifier; the cache does not prune removed identifiers automatically.

**Section sources**
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [VersionLog.md:35-58](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Excel Export
Export functionality appears in related monitoring applications and is driven by in-memory frames rather than live requests. The key idea is:
- Export tabs render from loaded runs.
- Export keys include run tokens, frame names, row counts, dimensions, and active filters.
- Export receipts show whether any frames were produced, even after failed or empty runs.

**Section sources**
- [VersionLog.md:700-719](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Request Logging and Diagnostics
Logging patterns include:
- Progress callbacks during data loading.
- Notes about skipped rows, missing items, empty identity columns, and duration measure duplication.
- Error messages distinguishing timeout retries from deterministic failures.
- Status labels such as `ok`, `partial`, and `unavailable`.

**Section sources**
- [data.py:66-97](file://User scripts/FI Index Change/fi_index_change/data.py#L66-L97)
- [data.py:408-491](file://User scripts/FI Index Change/fi_index_change/data.py#L408-L491)
- [data.py:541-596](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L596)
- [data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)

## Conclusion
The pipeline combines robust ingestion, strict normalization, and conservative caching to protect against stale, corrupted, or misaligned data. The ETF Spread Monitoring cache focuses on daily series with per-identifier coverage, request fingerprints, and identity ledgers. The FI Index Change cache focuses on immutable monthly snapshots with strong contract and weight validation. Both systems prefer fail-closed behavior, atomic writes, and explicit diagnostics over silent correctness.

For production operation:
- Treat cache corruption as recoverable by re-requesting.
- Treat identity mismatches as reasons to refresh the affected identifier.
- Use `Use cache` off as the controlled recovery path for suspected back-dated changes.
- Inspect notes and errors rather than assuming green status means fully parsed data.
- Keep derived metrics out of persistent storage so formula changes remain effective.

[No sources needed since this section summarizes without analyzing specific files]