# Spread Change Calculation and Ranking Engine

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py)
- [data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [README.md](file://User scripts/FI Spread Movement Monitoring/README.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the core analytical engine behind FI Spread Movement Monitoring. It focuses on how spread movements are calculated, how top movers are ranked, how daily observations are validated, and how display dimensions such as Country, Sector, Tenor, Rating, and Currency are derived and filtered. It also documents the SeriesValidation class, the enrichment process that adds duration measures and maturity-based buckets, and best practices for configuring ranking thresholds and interpreting spread movement signals.

The engine is intentionally split into three layers:
- Data layer: builds Bloomberg BQL requests, handles retries, normalizes responses, and fetches rankings, descriptors, duration measures, and a bounded candidate series.
- Engine layer: pure pandas logic for ranking preparation, validation, enrichment, filtering, bucketing, and export formatting.
- App layer: user interface, state management, chart rendering, and orchestration of data and engine steps.

**Section sources**
- [README.md:83-166](file://User scripts/FI Spread Movement Monitoring/README.md#L83-L166)
- [README.md:319-363](file://User scripts/FI Spread Movement Monitoring/README.md#L319-L363)

## Project Structure
The relevant code lives under `fi_spread_movement`:
- `config.py` holds operator settings, universe options, spread types, descriptor fields, duration measure family, filter configuration, chart settings, cache behavior, and timeout/retry policy.
- `data.py` implements BQL access, request execution with retry, response normalization, ranking requests, descriptor fetching, duration-family fetching, candidate-series fetching, and comparison flows.
- `engine.py` implements ranking preparation, change validation, spread-level extraction, dimension enrichment, filters, bucket summaries, charts data preparation, daily observation processing, and export helpers.
- `app.py` implements the Desktop UI controller, status bar, widgets, local view filtering, chart interaction, and end-to-end update flow.

```mermaid
graph TB
App["app.py<br/>UI controller"] --> Data["data.py<br/>BQL access"]
App --> Engine["engine.py<br/>pandas analytics"]
Engine --> Config["config.py<br/>settings"]
Data --> Config
App --> Charts["charts.py<br/>Plotly/SVG specs"]
```

**Diagram sources**
- [app.py:37-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L37-L61)
- [data.py:51-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L70)
- [engine.py:18-19](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L18-L19)
- [config.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)

**Section sources**
- [config.py:26-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L244)
- [data.py:51-107](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L51-L107)
- [engine.py:40-57](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L40-L57)
- [app.py:656-720](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L720)

## Core Components
- RankedMovers: holds prepared increases and decreases frames plus notes.
- SeriesValidation: holds the validation frame comparing BQL-ranked changes to the bounded series, plus diagnostic notes.
- FetchResult: carries increases, decreases, descriptors, series, per-field status, request log, errors, notes, universe metadata, and cache inputs.
- FISpreadMovementApp: orchestrates Update, caching, fallback, local filtering, and visualization.

Key responsibilities:
- `prepare_ranked_movers()` validates and orders BQL-ranked candidates, merges descriptors, and enforces per-book Top-N cuts.
- `validate_candidate_changes()` compares each ranked `Change` to `Last Spread - First Spread` from the bounded candidate series, checks effective start/end dates, and records mismatches.
- `enrich_ranked()` derives Country, Sector, Currency, Rating Bucket, and Tenor Bucket from already-requested descriptors.
- `apply_dimension_filters()` applies interactive filters over loaded frames without building new requests.
- `daily_spread_rows()` and `spread_paths()` prepare daily observation tables and pivot paths for selected securities.

**Section sources**
- [engine.py:40-57](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L40-L57)
- [engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)
- [engine.py:853-914](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L853-L914)
- [engine.py:948-981](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L948-L981)
- [engine.py:1323-1363](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1323-L1363)
- [engine.py:1373-1404](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1373-L1404)
- [data.py:76-107](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L107)

## Architecture Overview
The update flow starts at the app, which validates inputs, calls the data layer to build and execute BQL requests, then passes results to the engine for ranking preparation, validation, enrichment, and visualization.

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "FISpreadMovementApp"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
User->>App : Click Update
App->>Data : fetch_movers(...) or fetch_comparison(...)
Data->>BQL : Build spread(...).net_chg()
BQL-->>Data : Ranking responses (increases/decreases)
Data->>BQL : Descriptor + Duration family + Candidate series
BQL-->>Data : Descriptors, durations, dated spread series
Data-->>App : FetchResult(increases, decreases, descriptors, series)
App->>Engine : prepare_ranked_movers(...)
Engine-->>App : RankedMovers
App->>Engine : validate_candidate_changes(...)
Engine-->>App : SeriesValidation
App->>Engine : enrich_ranked(...)
Engine-->>App : Enriched frames
App->>App : Apply filters, render charts and tables
```

**Diagram sources**
- [app.py:1189-1218](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1189-L1218)
- [data.py:1419-1488](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1419-L1488)
- [data.py:1592-1599](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1592-L1599)
- [engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

## Detailed Component Analysis

### Spread Change Calculation Methodology
Spread change is based on the source spread type chosen by the operator: OAS, Z-Spread, or I-Spread. The data layer constructs a dated spread item and computes its net change over the requested window. Rankings are built separately for increases and decreases using directional filters and group-aware ranking.

- Start and end spread levels are not computed from a separate endpoint query; they are extracted from the same bounded candidate series used for arithmetic validation.
- Bid-ask spread computation is not part of this engine. The engine works with the spread values returned by the configured spread item.
- Directional change detection separates positive changes (widening/increase) from negative changes (tightening/decrease), then sorts and truncates per direction.

```mermaid
flowchart TD
Start(["Start"]) --> ValidateWindow["Validate spread type and date window"]
ValidateWindow --> BuildSpread["Build spread(spread_type, dates=range(start,end))"]
BuildSpread --> NetChange["Compute net_chg()"]
NetChange --> RankIncreases["Rank increases: net_chg > 0, grouprank <= TOP_N"]
NetChange --> RankDecreases["Rank decreases: net_chg < 0, grouprank <= TOP_N"]
RankIncreases --> PrepareSideA["Prepare side: clean ID, numeric Change, drop invalids"]
RankDecreases --> PrepareSideB["Prepare side: clean ID, numeric Change, drop invalids"]
PrepareSideA --> SortAndCutA["Sort by Change, truncate to TOP_N"]
PrepareSideB --> SortAndCutB["Sort by Change, truncate to TOP_N"]
SortAndCutA --> End(["End"])
SortAndCutB --> End
```

**Diagram sources**
- [data.py:1273-1320](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1273-L1320)
- [engine.py:81-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L81-L176)

**Section sources**
- [data.py:1464-1476](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1464-L1476)
- [data.py:1273-1320](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1273-L1320)
- [engine.py:81-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L81-L176)
- [config.py:112-117](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L112-L117)

### Ranking Algorithms for Top Movers
Ranking uses two BQL requests per book: one for top increases and one for top decreases. The engine then prepares each side by:
- Normalizing IDs and Change values.
- Dropping rows with blank IDs or non-finite Change values.
- Handling duplicate identities: in comparison mode, identity is `(Universe, ID)`; otherwise it is `ID`.
- Filtering out rows with the wrong sign for the side.
- Sorting by Change and applying Top-N truncation, with per-book grouping when comparing AIM vs Index.

```mermaid
classDiagram
class RankedMovers {
+increases : DataFrame
+decreases : DataFrame
+notes : list
}
class SeriesValidation {
+frame : DataFrame
+notes : list
}
class FetchResult {
+increases : DataFrame
+decreases : DataFrame
+descriptors : DataFrame
+series : DataFrame
+field_status : dict
+request_log : list
+errors : list
+notes : list
+universe : str
+source : str
+comparison : bool
+cache_request : dict
}
RankedMovers --> SeriesValidation : "validation output"
FetchResult --> RankedMovers : "input to engine"
```

**Diagram sources**
- [engine.py:40-57](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L40-L57)
- [data.py:76-107](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L107)

**Section sources**
- [engine.py:81-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L81-L176)
- [engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [data.py:1273-1320](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1273-L1320)

### Dimensional Filtering Capabilities
The app supports five display dimensions:
- Country: from `country_full_name()`.
- Sector: from `classification_name()`.
- Tenor: derived from `maturity()` relative to the end date, bucketed into fixed ranges.
- Rating: from `rating()`, mapped to IG/HY/NR/Missing/Numeric(unmapped)/Other.
- Currency: from `crncy()`.

Filtering is purely local over the frames returned by the last Update. Filters use normalized labels so invisible spaces and case differences do not break matching. Missing or unavailable descriptor values are explicitly labeled rather than silently dropped.

```mermaid
flowchart TD
Load["Loaded enriched frames"] --> Normalize["Normalize text labels"]
Normalize --> Options["Build filter options"]
Options --> Pick["Operator picks values"]
Pick --> Apply["apply_dimension_filters()"]
Apply --> View["Filtered frames for charts and tables"]
```

**Diagram sources**
- [engine.py:648-704](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L648-L704)
- [engine.py:917-981](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L917-L981)
- [config.py:202-218](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L202-L218)

**Section sources**
- [engine.py:746-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L746-L800)
- [engine.py:805-835](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L805-L835)
- [engine.py:853-914](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L853-L914)
- [engine.py:917-981](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L917-L981)
- [config.py:129-136](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L129-L136)
- [config.py:202-218](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L202-L218)

### Daily Observation Processing and Spread Path Validation
The bounded candidate series request returns `ID`, `DATE`, and `Spread` for the ranked candidates across the requested window. The engine:
- Cleans IDs, parses dates, coerces spreads to numeric, drops unusable rows, deduplicates by `(ID, DATE)`, and sorts by date.
- Computes first and last observed spread per ID.
- Compares `Series Change = Last Spread - First Spread` to the BQL-ranked `Change` using approximate equality.
- Reports effective start/end shifts, missing series, and mismatches.

Daily observation rows show each observation date, the spread value, and the change versus the previous observation. Spread paths pivot the series to `DATE x ID` for line charts while preserving real dates and gaps.

```mermaid
flowchart TD
Series["Candidate series: ID, DATE, Spread"] --> Clean["Clean ID/date/spread"]
Clean --> Dedup["Deduplicate by (ID, DATE)"]
Dedup --> Group["Group by ID"]
Group --> FirstLast["First Spread / Last Spread"]
FirstLast --> Compute["Series Change = Last - First"]
Compute --> Compare{"Matches BQL Change?"}
Compare --> |Yes| OK["All checked IDs satisfy Change = Last - First"]
Compare --> |No| Anomaly["Mismatch: inspect endpoints and units"]
```

**Diagram sources**
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)
- [engine.py:508-551](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L508-L551)
- [engine.py:1323-1363](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1323-L1363)
- [engine.py:1373-1404](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1373-L1404)

**Section sources**
- [data.py:1171-1228](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1171-L1228)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)
- [engine.py:508-551](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L508-L551)
- [engine.py:1323-1363](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1323-L1363)
- [engine.py:1373-1404](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1373-L1404)

### SeriesValidation Class and Data Integrity Role
`SeriesValidation` encapsulates:
- A validation frame with columns for ID, Side, BQL Change, First Spread, Last Spread, Effective Start, Effective End, Series Change, and Matches BQL.
- Diagnostic notes describing duplicate series rows, effective-date shifts, missing series, and mismatches.

Its role is to ensure that the ranking arithmetic matches the actual dated series returned for the same window, and to expose whether effective start/end dates shifted due to weekends, holidays, or sparse quotes.

```mermaid
classDiagram
class SeriesValidation {
+frame : DataFrame
+notes : list
}
class VALIDATION_COLUMNS {
+ID
+Side
+BQL Change
+First Spread
+Last Spread
+Effective Start
+Effective End
+Series Change
+Matches BQL
}
SeriesValidation --> VALIDATION_COLUMNS : "uses"
```

**Diagram sources**
- [engine.py:27-37](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L27-L37)
- [engine.py:51-57](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L51-L57)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

**Section sources**
- [engine.py:27-37](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L27-L37)
- [engine.py:51-57](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L51-L57)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

### Enrichment Process: Duration Measures, Maturity, and Analytical Attributes
Enrichment attaches display dimensions to ranked sides:
- Country, Sector, Currency are normalized text dimensions.
- Rating is cleaned and mapped to IG/HY/NR/Missing/Numeric(unmapped)/Other.
- Tenor Bucket is derived from Maturity and the end date using fixed tenor bins.
- Duration measures come from a single grouped request returning Duration, Modified Duration, Effective Duration, and OASD. Collisions and duplicates are detected and noted.

```mermaid
flowchart TD
Ranked["Ranked side: ID, Change"] --> MergeDesc["Merge descriptors"]
MergeDesc --> AddDuration["Add duration family"]
AddDuration --> TextDims["Normalize Country/Sector/Currency"]
TextDims --> RatingBucket["Map rating to bucket"]
RatingBucket --> TenorBucket["Derive Tenor Bucket from Maturity"]
TenorBucket --> Output["Enriched frame for filters/charts"]
```

**Diagram sources**
- [engine.py:853-914](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L853-L914)
- [engine.py:746-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L746-L800)
- [engine.py:805-835](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L805-L835)
- [data.py:918-930](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L918-L930)
- [data.py:933-982](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L933-L982)
- [data.py:1058-1079](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1058-L1079)

**Section sources**
- [engine.py:853-914](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L853-L914)
- [engine.py:746-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L746-L800)
- [engine.py:805-835](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L805-L835)
- [data.py:918-930](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L918-L930)
- [data.py:933-982](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L933-L982)
- [data.py:1058-1079](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1058-L1079)
- [config.py:138-191](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L138-L191)

## Dependency Analysis
The main dependencies are:
- `app.py` depends on `data.py` for fetching and on `engine.py` for analytics.
- `data.py` depends on `config.py` for spread types, descriptor fields, duration measures, timeouts, and universe handling.
- `engine.py` depends on `config.py` for dimension mappings, tenor bins, and display constants.

```mermaid
graph LR
App["app.py"] --> Data["data.py"]
App --> Engine["engine.py"]
Data --> Config["config.py"]
Engine --> Config
```

**Diagram sources**
- [app.py:37-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L37-L61)
- [data.py:63-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L63-L70)
- [engine.py:18-19](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L18-L19)

**Section sources**
- [app.py:37-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L37-L61)
- [data.py:63-70](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L63-L70)
- [engine.py:18-19](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L18-L19)

## Performance Considerations
- Request budget: a one-book run sends two ranking requests, six descriptor requests, one duration-measure family request, and one candidate-series request. A two-book comparison sends four ranking requests but still only one descriptor set and one series request over the union of candidate IDs.
- Duration measures cost no extra request because all four measures are built from the same `duration()` builder call.
- Local filtering and chart updates do not rebuild requests; they operate over frames already in memory.
- Timeout protection includes one retry for identical requests and an automatic fallback to a cached run when the failure is a timeout and a clean cached run exists for the same key.

Best practices:
- Keep windows narrow until timing is measured; the default is seven calendar days and the build caps at 31 days.
- Prefer index membership as of a published business day to avoid empty universes.
- Use the Export Excel tab to review request logs and per-field receipts instead of relying on screen-only diagnostics.

**Section sources**
- [README.md:83-166](file://User scripts/FI Spread Movement Monitoring/README.md#L83-L166)
- [README.md:365-392](file://User scripts/FI Spread Movement Monitoring/README.md#L365-L392)
- [config.py:193-196](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L193-L196)
- [config.py:347-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L347-L371)
- [data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)

## Troubleshooting Guide
Common issues and their meanings:
- Empty ranking: can be caused by an index membership keyed on an unpublished or weekend end date, an AIM account with no spread-bearing holdings, or a bond ticker that matches nothing.
- Arithmetic mismatch: may be due to different endpoints caused by effective-date shifts, stale or missing observations, or a real unit/item difference between the ranking item and the series item.
- Failed descriptor field: leaves the column as `(unavailable)` and is recorded in per-field status; it does not abort the whole run.
- Duplicate duration columns: if multiple duration measures return identical values, the engine notes a possible duplication.

Operational guidance:
- Check the step log and Export Excel → Request detail for per-field receipts and request counts.
- Do not widen the window or add fill to force a match; copy anomaly rows and compare endpoint spreads in Terminal.
- If a timeout occurs and a clean cached run exists for the same inputs, the app can automatically serve the cached result with a distinct status.

**Section sources**
- [README.md:319-363](file://User scripts/FI Spread Movement Monitoring/README.md#L319-L363)
- [README.md:397-421](file://User scripts/FI Spread Movement Monitoring/README.md#L397-L421)
- [data.py:1505-1589](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1505-L1589)
- [data.py:1058-1079](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1058-L1079)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)

## Conclusion
The FI Spread Movement Monitoring engine provides a robust, auditable pipeline for computing spread changes, ranking top movers, validating arithmetic against dated series, and enriching results with display dimensions. Its design keeps data fetching separate from pandas analytics, ensures transparency through detailed notes and request logs, and protects against timeouts via retry and cached fallback. For reliable interpretation, users should verify units and entitlements in Terminal, keep windows within validated bounds, and treat mismatches as Incomplete findings until resolved.

## Appendices

### Best Practices for Ranking Thresholds and Signal Interpretation
- Configure `TOP_N` conservatively; the default is 10. The Display Top control is a view setting and cannot invent rows beyond what was fetched.
- Treat widening and tightening as signed changes; do not cancel them into zero when summarizing buckets.
- Interpret Tenor Bucket as an approximation derived from Maturity and the end date; it is not a Bloomberg tenor item.
- Interpret Rating Bucket as a display mapping; numeric ratings remain unmapped unless established by evidence.
- Use the bounded series check as the primary arithmetic validator; effective-date shifts are expected when requested dates are not observation dates.

**Section sources**
- [config.py:26-40](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L40)
- [config.py:275-279](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L275-L279)
- [engine.py:746-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L746-L800)
- [engine.py:805-835](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L805-L835)
- [engine.py:351-505](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L351-L505)