# Chart Visualization and Interactive Components

<cite>
**Referenced Files in This Document**   
- [charts.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py)
- [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [engine.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py)
- [README.md](file://User scripts/FI Spread Movement Monitoring/README.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the chart visualization and interactive components used by the FI Spread Movement Monitoring application. It focuses on:

- The Top 10 charts for spread increases and decreases.
- Bar chart rendering, color coding, and interactive selection.
- The security detail panel that shows ranked rows and daily observations when users click chart bars or table rows.
- Chart specifications, configuration options, styling parameters, and responsive layout behavior.
- Customization points, annotations, and export behavior.
- Coordination between charts and tables through local filtering and selection.
- Fallback mechanisms when `ipydatagrid` is unavailable and the HTML table renderer.
- Performance guidance for large datasets and common rendering issues.

The system separates data preparation from presentation: engine functions prepare pandas frames, `charts.py` converts them into library-neutral specifications, and `app.py` renders either Plotly figures or HTML/SVG fallbacks.

## Project Structure
The visualization layer lives in one package under the FI Spread Movement Monitoring script:

```mermaid
graph TB
App["app.py<br/>UI controller, widgets, events"] --> Charts["charts.py<br/>specifications + renderers"]
App --> Engine["engine.py<br/>ranking, validation, bucketing"]
App --> Config["config.py<br/>colors, sizes, defaults"]
Charts --> Config
Engine --> Config
```

**Diagram sources**
- [app.py:1-62](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1-L62)
- [charts.py:1-21](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L1-L21)
- [engine.py:1-19](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1-L19)
- [config.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)

**Section sources**
- [README.md:45-73](file://User scripts/FI Spread Movement Monitoring/README.md#L45-L73)
- [app.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1-L24)

## Core Components
The visualization system has four main responsibilities:

| Component | Responsibility | Key files |
|---|---|---|
| UI controller | Builds widgets, wires clicks, manages selection state, coordinates charts and tables | [app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py) |
| Chart specification | Produces plain dictionaries describing buckets, changes, paths, and comparisons | [charts.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py) |
| Renderers | Convert specs to Plotly `FigureWidget` objects or HTML/SVG fallbacks | [charts.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py) |
| Configuration | Centralizes colors, dimensions, defaults, and chart labels | [config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py) |

The Top 10 increase and decrease charts are rendered as horizontal bar charts with one bar per security, ordered by absolute change magnitude. In a single-book run, blue means widening (increase) and orange means tightening (decrease). In a two-book comparison, the same side chart uses book-specific colors so AIM and Index can be distinguished even though both books sit on the same side of the axis.

**Section sources**
- [charts.py:185-285](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L185-L285)
- [config.py:301-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L301-L318)
- [README.md:205-228](file://User scripts/FI Spread Movement Monitoring/README.md#L205-L228)

## Architecture Overview
The runtime flow is event-driven and layered:

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "FISpreadMovementApp"
participant Charts as "charts.py"
participant Engine as "engine.py"
participant Plotly as "Plotly FigureWidget"
User->>App : Click Update
App->>Engine : Prepare ranked movers and series
Engine-->>App : Ranked frames + validation notes
App->>Charts : Build specs for buckets, changes, path
alt Plotly available
App->>Plotly : Create/update figures in place
Plotly-->>App : Live figures
else No Plotly
App->>Charts : html_fallback(spec)
Charts-->>App : HTML table representation
end
User->>App : Click chart bar or table row
App->>App : _show_security(identifier)
App->>Charts : path_spec(selected=identifier)
App->>Engine : daily_spread_rows(series, identifier)
App->>App : Render detail panel and daily table
```

**Diagram sources**
- [app.py:1189-1243](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1189-L1243)
- [app.py:1245-1292](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1245-L1292)
- [app.py:2163-2247](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2163-L2247)
- [charts.py:23-33](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L23-L33)
- [charts.py:48-139](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L48-L139)

## Detailed Component Analysis

### Top 10 Increase and Decrease Charts
The Top 10 charts are signed horizontal bar charts. Each spec contains:

- A list of rows with ID, label, value, and formatted text.
- A color list derived from direction or book.
- A title including the requested display count.
- Axis titles using the loaded spread type.
- An empty flag when no valid data is present.

```mermaid
flowchart TD
Start(["change_spec(frame, side, spread_label, top_n)"]) --> Validate["Validate frame has ID and Change"]
Validate --> |Invalid| EmptySpec["Return empty changes spec"]
Validate --> Numeric["Convert Change to numeric"]
Numeric --> Sort["Sort by absolute change"]
Sort --> BookOrder{"Two-book comparison?"}
BookOrder --> |Yes| GroupByBook["Group by book order: AIM then Index"]
BookOrder --> |No| SingleBook["Single book ordering"]
GroupByBook --> BuildRows["Build rows with book-prefixed labels"]
SingleBook --> BuildRows
BuildRows --> Colors{"Two books?"}
Colors --> |Yes| BookColors["Use CHART_BOOK_COLORS"]
Colors --> |No| DirectionColors["Use CHART_INCREASE_COLOR / CHART_DECREASE_COLOR"]
BookColors --> ReturnSpec["Return changes spec"]
DirectionColors --> ReturnSpec
EmptySpec --> ReturnSpec
```

**Diagram sources**
- [charts.py:185-285](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L185-L285)
- [config.py:301-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L301-L318)

Key behaviors:

- The chart keeps the sign of the change, so widening and tightening do not cancel into zero.
- In a two-book run, each chart still shows only one side: the increase chart shows increases for both books, and the decrease chart shows decreases for both books.
- Labels may include a book prefix such as `AIM · Security Name` or `Index · Security Name`.
- The `Display Top` control is a view-only setting: it does not request more rows from Bloomberg; it slices what is already in memory.

**Section sources**
- [charts.py:185-285](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L185-L285)
- [config.py:26-40](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L40)
- [README.md:214-228](file://User scripts/FI Spread Movement Monitoring/README.md#L214-L228)

### Bar Rendering and Color Coding
There are three relevant color models:

| Context | Meaning of color | Source |
|---|---|---|
| One-book Top 10 change chart | Direction: widening vs tightening | [config.py:301-302](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L301-L302) |
| Two-book Top 10 change chart | Book identity: AIM vs Index | [config.py:315-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L315-L318) |
| Diverging bucket charts | Direction for one book; depth within hue for two books | [config.py:303-314](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L303-L314) |

The Plotly renderer creates `FigureWidget` objects once and updates traces in place using `batch_update()`. This avoids rebuilding the widget tree and preserves interactivity.

```mermaid
classDiagram
class Charts {
+plotly_available() bool
+html_fallback(spec) str
+bucket_spec(...) dict
+change_spec(...) dict
+path_spec(...) dict
+comparison_spec(...) dict
+bucket_figure(spec) FigureWidget
+apply_bucket(figure, spec) void
+change_figure(spec) FigureWidget
+apply_change(figure, spec) void
+comparison_figure(spec) FigureWidget
+apply_comparison(figure, spec) void
+path_figure(spec) FigureWidget
+apply_paths(figure, spec) void
}
class Config {
+TOP_N int
+DEFAULT_DISPLAY_TOP int
+CHART_WIDTH_PX int
+CHART_HEIGHT_PX int
+CHART_DETAIL_HEIGHT_PX int
+CHART_INCREASE_COLOR string
+CHART_DECREASE_COLOR string
+CHART_DIRECTION_COLORS tuple
+CHART_COMPARE_COLORS dict
+CHART_BOOK_COLORS dict
}
class App {
+increase_figure FigureWidget
+decrease_figure FigureWidget
+path_figure_widget FigureWidget
+_render_chart_shell() void
+_on_chart_click(trace, points, state) void
+_show_security(identifier) void
}
Charts --> Config : "uses"
App --> Charts : "builds and updates"
```

**Diagram sources**
- [charts.py:23-33](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L23-L33)
- [charts.py:530-600](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L530-L600)
- [charts.py:602-676](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L602-L676)
- [charts.py:698-765](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L698-L765)
- [config.py:26-40](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L40)
- [config.py:281-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L281-L318)
- [app.py:821-860](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L821-L860)

**Section sources**
- [charts.py:442-527](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L442-L527)
- [charts.py:530-600](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L530-L600)
- [config.py:281-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L281-L318)

### Interactive Selection and Security Detail Panel
Selection flows from three entry points:

1. Clicking a chart bar or line.
2. Clicking a row in the Top 10 increase or decrease table.
3. Clicking a row in the full bucket table to scope the Top 10 charts.

```mermaid
sequenceDiagram
participant User as "Operator"
participant Chart as "Plotly FigureWidget"
participant App as "FISpreadMovementApp"
participant Detail as "Detail Panel"
participant PathChart as "Path Chart"
participant DailyTable as "Daily Table"
User->>Chart : Click bar or line
Chart->>App : on_click(trace, points)
App->>App : _point_identifier(trace, points)
App->>App : _show_security(identifier)
App->>Detail : Render selected security rows
App->>PathChart : path_spec(selected=identifier)
App->>DailyTable : daily_spread_rows(series, identifier)
PathChart-->>User : Spread path for selected bond
DailyTable-->>User : Daily observations
```

**Diagram sources**
- [app.py:1221-1274](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1221-L1274)
- [app.py:1276-1377](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1276-L1377)
- [app.py:2163-2247](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2163-L2247)

The detail panel shows:

- The selected identifier.
- Any matching ranked rows for increases and decreases.
- In a two-book run, every matching row is shown under its book heading.
- Spread observations from the bounded series, if available.
- A note when the selected ID is hidden by current filters but still exists in the loaded run.

The path chart draws at most one trace: the spread path for the selected security across real observation dates. If nothing is selected, it displays a prompt instead of drawing all candidates.

**Section sources**
- [app.py:1221-1377](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1221-L1377)
- [charts.py:288-338](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L288-L338)
- [charts.py:698-765](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L698-L765)
- [README.md:229-246](file://User scripts/FI Spread Movement Monitoring/README.md#L229-L246)

### Bucket Charts and Coordinated Filtering
The bucket area includes:

- A diverging chart counting movers by bucket.
- A diverging chart summing signed spread change by bucket.
- A full bucket table underneath.

A bucket pick narrows the Top 10 increase and decrease charts without building a new request. The filter is applied through the same function used by the five dimension boxes, keeping coordinated filtering consistent.

```mermaid
flowchart TD
BucketClick["Bucket row clicked"] --> Scoped["Apply bucket to visible frames"]
Scoped --> UpdateTop10["Rebuild Top 10 specs with scoped data"]
UpdateTop10 --> ApplyChange["apply_change(increase/decrease figures)"]
ApplyChange --> Redraw["Update chart titles, axes, bars"]
Scoped --> Headline["Update headline count"]
```

**Diagram sources**
- [app.py:1580-1594](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1580-L1594)
- [app.py:1682-1741](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1682-L1741)
- [charts.py:341-434](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L341-L434)

**Section sources**
- [README.md:197-204](file://User scripts/FI Spread Movement Monitoring/README.md#L197-L204)
- [README.md:248-271](file://User scripts/FI Spread Movement Monitoring/README.md#L248-L271)
- [charts.py:341-434](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L341-L434)

### HTML Table Rendering and ipydatagrid Fallback
When `ipydatagrid` is unavailable, the app falls back to an HTML table. The `_PickTable` class:

- Renders a clickable grid when possible.
- Falls back to plain HTML when the import fails.
- Adds a visible note explaining that row clicks cannot reach the detail panel in notebook mode without `ipydatagrid`.
- Preserves the same frame content and headings in both modes.

```mermaid
flowchart TD
Render["Render table block"] --> GridAvailable{"ipydatagrid available?"}
GridAvailable --> |Yes| TryGrid["Create DataGrid with column widths"]
TryGrid --> ClickWired{"on_cell_click supported?"}
ClickWired --> |Yes| Clickable["Clickable grid"]
ClickWired --> |No| HTMLFallback["HTML table + note"]
GridAvailable --> |No| HTMLFallback
HTMLFallback --> Note["Show GRID_NO_CLICK_NOTE"]
```

**Diagram sources**
- [app.py:364-377](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L364-L377)
- [app.py:435-627](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L435-L627)

For chart data, `charts.html_fallback` renders:

- Movers by bucket as a simple table.
- Top 10 changes as a security-to-change table.
- Spread paths as an ID, observation count, and first-to-last summary.
- Comparison data as a per-bucket, per-book table.

**Section sources**
- [app.py:364-377](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L364-L377)
- [app.py:435-627](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L435-L627)
- [charts.py:48-139](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L48-L139)

### Chart Configuration Options and Styling
Configuration controls chart appearance and layout:

| Option | Purpose | Example value or behavior |
|---|---|---|
| `TOP_N` | Default number of ranked movers per direction | `10` |
| `DEFAULT_DISPLAY_TOP` | Default rows shown in each Top 10 panel | `10` |
| `DISPLAY_TOP_MAX` | Maximum allowed Display Top value | `50` |
| `CHART_WIDTH_PX` | Fixed chart width aligned with filter boxes | Sum of filter widths plus gaps |
| `CHART_HEIGHT_PX` | Standard chart height | `360` px |
| `CHART_DETAIL_HEIGHT_PX` | Shorter height for the path chart | `300` px |
| `CHART_FONT_COLOR` | Title and tick text color | Light gray |
| `CHART_MUTED_COLOR` | Axis label and legend text color | Muted gray |
| `CHART_GRID_COLOR` | Grid line color | Dark gray |
| `CHART_ZERO_COLOR` | Zero-line color | Medium gray |
| `CHART_INCREASE_COLOR` | Widening color | Blue |
| `CHART_DECREASE_COLOR` | Tightening color | Orange |
| `CHART_BOOK_COLORS` | Book identity colors for Top 10 comparison charts | Distinct hues for AIM and Index |

Responsive considerations:

- Charts use fixed pixel widths to align with the five dimension selection boxes.
- The HBox wrapper carries `width=CHART_WIDTH_PX`, while the Plotly layout also sets `autosize=False` and a fixed width.
- The path chart uses a shorter height and tighter margins through `_detail_layout`.
- Column widths for `ipydatagrid` are estimated from header length and displayed numeric precision, clamped between minimum and maximum pixel values.

**Section sources**
- [config.py:26-40](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L40)
- [config.py:224-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L224-L244)
- [config.py:281-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L281-L318)
- [app.py:386-432](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L386-L432)
- [charts.py:474-527](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L474-L527)
- [charts.py:679-695](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L679-L695)

### Customizing Chart Appearances
Customization should go through configuration and specifications rather than mutating Plotly internals directly:

- Change colors via `config.CHART_INCREASE_COLOR`, `config.CHART_DECREASE_COLOR`, `config.CHART_BOOK_COLORS`, or `config.CHART_COMPARE_COLORS`.
- Adjust size via `config.CHART_WIDTH_PX`, `config.CHART_HEIGHT_PX`, and margin constants.
- Modify titles and axis labels by changing the spec passed to `change_spec`, `bucket_spec`, `comparison_spec`, or `path_spec`.
- Add annotations to the path chart by providing a non-empty `note` in `path_spec`; the renderer places a centered annotation when there are no traces.

Annotations example concept:

- Provide a note such as `"Select a bond to view its spread path"` or a diagnostic message.
- The path renderer shows the annotation when the chart has no traces.
- For other charts, update the spec title or x/y titles through the spec builder.

Export behavior:

- The Export Excel tab copies the filtered Main view, not the Display Top slice.
- Tables repeat column names as the first data row so copying and pasting into Excel retains headers.
- No file is written; the user selects, copies, and pastes.

**Section sources**
- [config.py:281-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L281-L318)
- [charts.py:288-338](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L288-L338)
- [charts.py:709-765](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L709-L765)
- [README.md:290-317](file://User scripts/FI Spread Movement Monitoring/README.md#L290-L317)

### Integration Between Charts and Tables
Charts and tables share the same underlying frames:

- Filters apply to both the Top 10 charts and their tables.
- A bucket pick scopes the Top 10 charts and their tables.
- A security selection reads from the loaded frames, not the filtered view, so a hidden security can still be inspected.
- The detail panel warns when a selected ID is hidden by filters but still exists in the loaded run.

```mermaid
flowchart TD
LoadedFrames["Loaded ranked frames"] --> Filters["Dimension filters"]
Filters --> VisibleFrames["Visible frames"]
VisibleFrames --> Charts["Top 10 charts"]
VisibleFrames --> Tables["Top 10 tables"]
SelectedID["Selected ID"] --> DetailPanel["Security detail panel"]
SelectedID --> PathChart["Spread path chart"]
SelectedID --> DailyTable["Daily observations table"]
```

**Diagram sources**
- [app.py:1580-1594](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1580-L1594)
- [app.py:1276-1377](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1276-L1377)
- [app.py:2163-2247](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2163-L2247)

**Section sources**
- [app.py:1580-1594](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1580-L1594)
- [app.py:1303-1334](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1303-L1334)
- [README.md:168-195](file://User scripts/FI Spread Movement Monitoring/README.md#L168-L195)

## Dependency Analysis
The visualization dependencies are intentionally shallow:

```mermaid
graph LR
App["app.py"] --> Charts["charts.py"]
App --> Engine["engine.py"]
App --> Config["config.py"]
Charts --> Config
Engine --> Config
Charts --> Plotly["Plotly (optional)"]
App --> IPyWidgets["ipywidgets (required)"]
App --> IPyDataGrid["ipydatagrid (optional)"]
```

**Diagram sources**
- [app.py:33-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L33-L61)
- [charts.py:14-20](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L14-L20)

Coupling characteristics:

- `charts.py` depends only on `pandas` and `config`, keeping plotting logic isolated.
- `app.py` owns widget lifecycle, event wiring, and state management.
- `engine.py` is pure pandas and does not depend on UI libraries.
- Optional dependencies (`plotly`, `ipywidgets`, `ipydatagrid`) are checked lazily so the module remains importable in environments where they are missing.

Potential circular dependencies:

- None are introduced by design: `charts.py` imports `config`, and `app.py` imports both `charts` and `engine`.
- `engine.py` imports only `config`.

External integration points:

- BQL/Bloomberg data comes through `data.py` and `engine.py`, outside this documentation’s focus.
- Desktop rendering uses `ipywidgets` and Plotly `FigureWidget`.
- Local preview and fallback rendering use HTML and SVG-compatible representations.

**Section sources**
- [charts.py:1-12](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L1-L12)
- [app.py:33-61](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L33-L61)
- [engine.py:1-19](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L1-L19)

## Performance Considerations
Optimization guidance based on the implementation:

| Area | Guidance | Reason |
|---|---|---|
| Large Top N values | Keep `Display Top` near `TOP_N` unless necessary | The table and chart must render every row; very large values increase DOM and plot trace cost. |
| Many buckets | Use grouping and filters before inspecting details | Bucket aggregation is computed over loaded frames; fewer buckets reduce chart and table work. |
| Repeated updates | Prefer Refresh for Display Top and local filters | These redraw from memory and do not rebuild requests. |
| Plotly updates | Mutate traces in place | The code uses `batch_update()` and mutates `figure.data[i].x/y/marker.color` rather than replacing `figure.data`. |
| ipydatagrid sizing | Let `_grid_column_widths` estimate widths | It rounds numeric display precision and clamps column widths to avoid extreme resizing. |
| Series inspection | Select one security at a time | The path chart draws at most one trace; selecting many IDs would defeat the design. |

Known performance-sensitive patterns:

- `apply_comparison` and `apply_paths` add traces only when needed and empty unused traces instead of dropping them, avoiding stale lines while keeping the figure object stable.
- `_grid_column_widths` measures numeric columns at display precision and uses vectorized operations where possible.
- The app avoids rebuilding chart containers when possible through `_slot_reuse`.

**Section sources**
- [charts.py:614-676](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L614-L676)
- [charts.py:709-765](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L709-L765)
- [app.py:386-432](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L386-L432)
- [app.py:1075-1099](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1075-L1099)

## Troubleshooting Guide

### Chart Bars Do Not Update After Filter Change
Check whether Plotly is available and whether the figure was created once and updated in place.

Symptoms:
- Tables show numbers but charts remain blank.
- A filter change appears to have no visual effect on the chart.

Likely causes:
- Plotly or `ipywidgets` is unavailable, so the HTML fallback is used.
- The figure container was rebuilt instead of reused.
- The renderer replaced `figure.data` instead of mutating existing traces.

Actions:
- Confirm `charts.plotly_available()` returns true.
- Verify the app uses `_chart_slot` and `_slot_reuse`.
- Ensure `apply_change`, `apply_comparison`, and `apply_paths` mutate traces inside `batch_update()`.

**Section sources**
- [charts.py:23-33](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L23-L33)
- [charts.py:614-676](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L614-L676)
- [app.py:1064-1099](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1064-L1099)

### Row Click Does Not Select a Security
If clicking a table row does nothing:

- Check whether `ipydatagrid` is available.
- Check whether `on_cell_click` is supported.
- Check whether `primary_key_row` is an integer position or a label.

The app handles these cases by falling back to HTML and warning the user that clicks cannot reach the detail panel in notebook mode.

**Section sources**
- [app.py:364-377](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L364-L377)
- [app.py:565-627](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L565-L627)
- [app.py:630-646](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L630-L646)

### Selected Bond Shows No Path
If the path chart shows a prompt or a missing-series message:

- Confirm a security was selected.
- Confirm the selected ID exists in the loaded series frame.
- Confirm the date window includes observation dates for that ID.

The path spec distinguishes “nothing selected” from “selected ID has no series.”

**Section sources**
- [charts.py:288-338](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L288-L338)
- [charts.py:709-765](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L709-L765)
- [README.md:229-234](file://User scripts/FI Spread Movement Monitoring/README.md#L229-L234)

### Colors Look Wrong in Two-Book Mode
In a two-book run:

- The Top 10 increase and decrease charts use book colors, not direction colors.
- The diverging bucket charts use direction colors, separating books by depth within those hues.

If colors appear swapped, check whether the chart is a Top 10 change chart or a diverging bucket chart.

**Section sources**
- [config.py:303-318](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L303-L318)
- [README.md:261-271](file://User scripts/FI Spread Movement Monitoring/README.md#L261-L271)
- [charts.py:256-275](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/charts.py#L256-L275)

### Export Table Differs From Screen
The Export Excel tab exports the filtered Main view, not the Display Top slice.

If the exported table has more rows than the screen:
- Remember that Display Top is a view-only slice.
- Export always copies the filtered run, not the narrowed panel.

**Section sources**
- [README.md:214-228](file://User scripts/FI Spread Movement Monitoring/README.md#L214-L228)
- [README.md:290-317](file://User scripts/FI Spread Movement Monitoring/README.md#L290-L317)

## Conclusion
The chart visualization system is built around a clear separation of concerns:

- `engine.py` prepares validated, ranked, and bucketed data.
- `charts.py` produces neutral specifications and renders them as Plotly figures or HTML/SVG fallbacks.
- `app.py` manages user interaction, selection state, and coordination between charts and tables.
- `config.py` centralizes styling and behavioral defaults.

The Top 10 increase and decrease charts provide a readable, interactive view of spread movement. Their color model adapts to single-book and two-book contexts, and their interaction model connects chart bars, table rows, and the security detail panel. When interactive libraries are unavailable, the system degrades gracefully to HTML tables while preserving the data.

For production use, prefer configuration-based customization, keep Display Top reasonable, rely on local filtering for responsiveness, and validate units and entitlements against Terminal before trusting returned values.