# ETF Capping Monitoring Module

<cite>
**Referenced Files in This Document**   
- [README.md](file://User scripts/ETF Capping Monitoring/README.md)
- [25-etf-capping-monitor.md](file://RAG KB/25-etf-capping-monitor.md)
- [config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [test_engine.py](file://User scripts/ETF Capping Monitoring/tests/test_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
The ETF Capping Monitoring module is a BQuant Desktop application that converts Current or Projected AIM portfolio positions into company-level weights and monitors account-specific capping limits. It integrates with Bloomberg AIM position data, reference data, and pricing through BQL, then applies a fixed calculation order: preserve the exact AIM ticker and quantity, obtain an approved USD price, calculate position market value and security weight, attach a company key, and aggregate by company only for the final capping test.

The module supports:
- AIM Current and Projected positions.
- Company grouping via hard exceptions, `fundamentalticker()` lineage mapping, and original-ticker fallback.
- Dynamic limit selection using Rank 1 `Largest` when available, otherwise `Capping`.
- Breach and Near Limit alerts at 100% and 98% of the dynamic limit.
- Thai foreign-line pricing overrides and validation.
- Cash conversion to USD via `USD{CCY} BGNL Curncy`.
- Interactive monitoring, Full Positions audit tables, diagnostics, CSV export, and documentation tabs.

**Section sources**
- [README.md:9-11](file://User scripts/ETF Capping Monitoring/README.md#L9-L11)
- [README.md:43-67](file://User scripts/ETF Capping Monitoring/README.md#L43-L67)
- [25-etf-capping-monitor.md:49-64](file://RAG KB/25-etf-capping-monitor.md#L49-L64)

## Project Structure
The module is organized as a small Python package under `User scripts/ETF Capping Monitoring/`:

| File | Responsibility |
|---|---|
| `config.py` | Static runbook: AIM codes, fund names, capping/largest limits, exception rules, Thai pricing overrides, status colors, batch sizes, and display configuration. |
| `data.py` | BQL retrieval layer: AIM positions, descriptors, fundamental tickers, Thai pricing resolution, USD equity prices, cash FX rates, and normalized `MonitorPayload`. |
| `engine.py` | Pure-Pandas processing: asset classification, position valuation, security weights, company aggregation, dynamic limit calculation, alert generation, and monitor filtering. |
| `app.py` | BQuant Desktop dashboard: widgets, tab rendering, interactive filters, charts, CSV export, and user-facing documentation. |
| `tests/test_engine.py` | Local unit tests using synthetic Pandas data without executing BQL. |
| `README.md` | Operational rules, validation checklist, and workbook compatibility notes. |
| `RAG KB/25-etf-capping-monitor.md` | Runtime authority document freezing last-price behavior, AIM request shape, classifier rules, dynamic limit logic, and desktop hazards. |

```mermaid
graph TB
User["BQuant Desktop User"] --> App["ETFCappingMonitor app.py"]
App --> Data["fetch_monitor_payload data.py"]
App --> Engine["calculate_monitor engine.py"]
Data --> Config["account_rules_frame config.py"]
Engine --> Config
Data --> BQL["Bloomberg BQL Service"]
App --> Output["Monitor / Full Positions / Diagnostics / CSV"]
```

**Diagram sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [data.py:1168-1187](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1187)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:186-201](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L201)

**Section sources**
- [README.md:13-33](file://User scripts/ETF Capping Monitoring/README.md#L13-L33)
- [25-etf-capping-monitor.md:297-314](file://RAG KB/25-etf-capping-monitor.md#L297-L314)

## Core Components
The module has four main runtime components:

1. **Configuration (`config.py`)**  
   Defines the 54-account runbook, exception mappings, Thai pricing overrides, warning ratio, batch sizes, and status colors. It exposes DataFrame constructors so the engine and app can read static rules without importing raw tuples directly.

2. **Data Layer (`data.py`)**  
   Implements the frozen AIM request contract, batches account requests, fetches reference data and prices, resolves Thai local pricing, converts cash to USD, and returns a normalized `MonitorPayload` containing positions and request errors.

3. **Engine (`engine.py`)**  
   Performs all pure-Pandas calculations: validates inputs, classifies assets, computes USD market values and security weights, attaches company keys, aggregates by company, calculates dynamic limits, and produces alerts and diagnostics.

4. **Application (`app.py`)**  
   Provides the interactive UI, runs data only on Update, renders Monitor and Full Positions tables, shows Account Summary and Diagnostics, exports CSVs, and includes a built-in documentation tab describing the implemented workflow.

**Section sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [config.py:26-50](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L26-L50)
- [data.py:34-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L34-L45)
- [engine.py:52-58](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L52-L58)
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)

## Architecture Overview
The end-to-end flow is intentionally strict:

```mermaid
flowchart LR
A["AIM Runbook + Position Mode"] --> B["AIM Positions"]
B --> C["Name + Market Status + Fundamental Ticker"]
C --> D["Thai Pricing Validation"]
D --> E["Approved USD Price"]
E --> F["Position MV + Security Weight"]
F --> G["Company Key Mapping"]
G --> H["Company Group Aggregation"]
H --> I["Rank + Dynamic Limit"]
I --> J["Monitor / Full Positions / Alerts / Diagnostics"]
```

**Diagram sources**
- [app.py:323-406](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L323-L406)
- [data.py:1168-1378](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1378)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

### AIM Request Contract
The AIM request is frozen from Desktop tests:

- Universe: `bq.univ.members(type="AIM")`.
- `accounts`, `pxnum=1377`, and `profile="DEFAULT_PROFILE"` stay on `with_params`.
- Do not move them onto `members()`.
- Do not add dates.
- Do not use `ts_position()`.
- Current uses `position_without_pending()["value"]`.
- Projected is Current plus `pending_position()["value"]`.

```mermaid
sequenceDiagram
participant App as "ETFCappingMonitor"
participant Data as "data.fetch_monitor_payload"
participant BQ as "BQL Service"
participant Engine as "engine.calculate_monitor"
App->>Data : fetch_monitor_payload(position_mode, accounts, today)
Data->>BQ : execute_many(AIM accounts, Position item)
BQ-->>Data : Arrow response frames
Data->>Data : normalize positions, descriptors, prices
Data-->>App : MonitorPayload(positions, errors)
App->>Engine : calculate_monitor(normalized_positions, position_mode)
Engine-->>App : MonitorResult(positions, groups, alerts, diagnostics)
```

**Diagram sources**
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:1168-1187](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1187)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

**Section sources**
- [25-etf-capping-monitor.md:201-221](file://RAG KB/25-etf-capping-monitor.md#L201-L221)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)

## Detailed Component Analysis

### AIM Position Processing Pipeline
The pipeline preserves the legal AIM holding identity before any aggregation:

1. Fetch AIM positions per account in batches of 8.
2. Normalize returned columns to `AIM Code`, `Ticker`, `Quantity`.
3. Sum duplicate holdings by exact `AIM Code + Ticker`.
4. Attach the runbook rule for each AIM code.
5. Classify assets by yellow-key suffix.
6. Resolve reference data and Thai pricing.
7. Request USD prices with the correct as-of date and `fill="prev"`.
8. Convert cash balances to USD.
9. Compute position market value and security weight.
10. Attach company key after valuation.
11. Aggregate by company for capping.

```mermaid
flowchart TD
Start(["AIM Input"]) --> Batch["Batch AIM Accounts<br/>AIM_ACCOUNT_BATCH = 8"]
Batch --> Positions["Normalize Columns<br/>AIM Code + Ticker + Quantity"]
Positions --> Rules["Attach Runbook Rule"]
Rules --> Classify["Classify Asset"]
Classify --> Reference["Fetch Name + Market Status"]
Reference --> Thai["Resolve Thai Pricing Ticker"]
Thai --> Prices["Request USD Price<br/>Last Close or Real Time"]
Prices --> Cash["Convert Cash to USD"]
Cash --> Values["Compute MV and Weight"]
Values --> Company["Attach Company Key"]
Company --> Aggregate["Aggregate by Company"]
Aggregate --> End(["Monitor Result"])
```

**Diagram sources**
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:927-1069](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L927-L1069)
- [data.py:1072-1165](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1072-L1165)
- [engine.py:233-400](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L400)

**Section sources**
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:1168-1378](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1378)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

### Company Group Aggregation Logic
Company grouping follows a strict precedence:

1. Hard Exception override.
2. Lineage-mapped `fundamentalticker()`.
3. Original held ticker fallback.

Grouping is performed by `AIM Code + Parent/Issuer Ticker`. The output includes:

- Aggregated market value.
- `Agg Wgt (incl cash)` = company MV / account total MV.
- `Agg Wgt (ex cash)` = company MV / total equity MV.
- Listing count and listing tickers.
- Whether the group contains equity.

```mermaid
flowchart TD
Pos["Security Rows"] --> Map["Exception → Fundamental → Original"]
Map --> Group["Group by AIM Code + Parent/Issuer Ticker"]
Group --> Incl["Sum MV / Account Total MV"]
Group --> Ex["Sum MV / Equity Total MV"]
Incl --> Stats["Rank, Dynamic Limit, Headroom, Utilisation"]
Ex --> Stats
Stats --> Output["Groups + Alerts"]
```

**Diagram sources**
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)

**Section sources**
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [test_engine.py:214-267](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L214-L267)

### Dynamic Limit Calculation Algorithm
Dynamic limit selection matches the Excel workbook:

1. Rank every parent group within an AIM by `Agg Wgt (incl cash)`, descending.
2. If Rank equals 1 and `Largest` is present, use `Largest`; otherwise use `Capping`.
3. Observed Weight is the maximum of including-cash and excluding-cash company weight.
4. Headroom = Dynamic Limit − Observed Weight.
5. Utilisation = Observed Weight / Dynamic Limit.
6. Breach if Observed Weight ≥ Dynamic Limit.
7. Near Limit if Observed Weight ≥ 0.98 × Dynamic Limit.
8. OK otherwise.
9. Non-equity rows are forced to OK.
10. Final Status is Capping Status unless OK, in which case it becomes Data Quality.

```mermaid
flowchart TD
Start(["Company Groups"]) --> Rank["Rank by Agg Wgt incl cash"]
Rank --> Limit{"Rank == 1<br/>and Largest present?"}
Limit --> |Yes| UseLargest["Dynamic Limit = Largest"]
Limit --> |No| UseCap["Dynamic Limit = Capping"]
UseLargest --> Observed["Observed Weight = max(Incl Cash, Ex Cash)"]
UseCap --> Observed
Observed --> Breach{"Observed ≥ Dynamic Limit?"}
Breach --> |Yes| BreachStatus["Capping Status = Breach"]
Breach --> |No| Near{"Observed ≥ 0.98 × Dynamic Limit?"}
Near --> |Yes| NearStatus["Capping Status = Near Limit"]
Near --> |No| OkStatus["Capping Status = OK"]
BreachStatus --> Final["Final Status"]
NearStatus --> Final
OkStatus --> Final
Final --> NonEquity{"Is Equity?"}
NonEquity --> |No| ForceOK["Force OK"]
NonEquity --> |Yes| Keep["Keep Capping Status"]
```

**Diagram sources**
- [engine.py:505-537](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L505-L537)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)

**Section sources**
- [engine.py:505-537](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L505-L537)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)
- [test_engine.py:319-391](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L391)

### Regulatory Compliance Checking System
The compliance check compares observed company exposure against configured limits:

- Limits come from `ACCOUNT_RULES`: `Capping` and `Largest`.
- Thresholds are defined by `WARNING_RATIO = 0.98`.
- Alerts include both Breach and Near Limit names.
- For the default Monitor Alerts view, the Rank 1 equity name of flagged funds is also included so the largest holding can be compared even when it sits between Largest and Capping.
- Incomplete accounts still show Breach or Near Limit names on Alerts; other within-limit names remain on Diagnostics and the Data Issue filter.

```mermaid
classDiagram
class AccountRule {
+aim_code
+fund_name
+capping
+largest
+level
+price_type
}
class ExceptionRule {
+ticker
+name
+parent_ticker
+parent_name
}
class ThaiPricingRule {
+foreign_ticker
+local_ticker
+reason
}
class MonitorResult {
+positions
+groups
+alerts
+diagnostics
}
AccountRule <.. Engine : "used for limits"
ExceptionRule <.. Engine : "company mapping"
ThaiPricingRule <.. Data : "pricing override"
MonitorResult --> Engine : "produced by"
```

**Diagram sources**
- [config.py:26-50](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L26-L50)
- [engine.py:52-58](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L52-L58)

**Section sources**
- [config.py:52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [engine.py:602-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L602-L615)
- [engine.py:642-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L642-L684)
- [test_engine.py:393-447](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L393-L447)

### Alert System Implementation
Alerts are derived from the grouped results:

- `Capping Status` determines Breach or Near Limit.
- `Status` combines Capping Status and Data Quality.
- `select_monitor_groups` filters Monitor output:
  - `Alerts`: Breach and Near Limit, plus Rank 1 context.
  - `Breach`: only Breach, plus Rank 1 context.
  - `Near Limit`: only Near Limit, plus Rank 1 context.
  - `Data Issue`: equity rows where `Data Quality` is Data Issue.
  - Default: all equity rows.

```mermaid
flowchart TD
Groups["Grouped Results"] --> Filter{"Filter Type"}
Filter --> |Alerts| OverLimit["Capping Status in Breach/Near Limit"]
Filter --> |Breach| BreachOnly["Capping Status = Breach"]
Filter --> |Near Limit| NearOnly["Capping Status = Near Limit"]
Filter --> |Data Issue| DataIssue["Data Quality = Data Issue"]
Filter --> |All| AllEquity["All Equity Rows"]
OverLimit --> Context["Add Rank 1 Equity Context"]
BreachOnly --> Context
NearOnly --> Context
Context --> Output["Filtered Monitor Rows"]
```

**Diagram sources**
- [engine.py:642-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L642-L684)

**Section sources**
- [engine.py:602-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L602-L615)
- [engine.py:642-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L642-L684)
- [test_engine.py:393-447](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L393-L447)

### Configuration Options
Configuration is centralized in `config.py`:

| Option | Purpose | Example Value |
|---|---|---|
| `WARNING_RATIO` | Near Limit threshold | `0.98` |
| `AIM_ACCOUNT_BATCH` | AIM account request batch size | `8` |
| `SECURITY_BATCH` | Security-level BQL batch size | `150` |
| `ACCOUNT_RULES` | AIM code, fund name, capping, largest, level, price type | 54 accounts |
| `EXCEPTION_RULES` | Hard company-group overrides | SK Inc group |
| `THAI_PRICING_RULES` | Approved Thai foreign-to-local pricing overrides | `CPNREI/F TB Equity` → `CPNREIT TB Equity` |
| `PRIMARY_FM_BY_AIM` | Display-only Primary FM mapping | Fund manager names |

**Section sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [config.py:52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [config.py:110-124](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L110-L124)
- [config.py:128-183](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L128-L183)

### Integration with AIM Portfolio Data
The AIM integration is isolated in `data.py`:

- One AIM account per BQL request.
- `execute_many` batches accounts in groups of 8.
- Current uses `position_without_pending()["value"]`.
- Projected adds `pending_position()["value"]`.
- Returned positions are grouped by exact `AIM Code + Ticker`.
- Missing AIM responses are recorded as errors rather than silently producing OK results.

**Section sources**
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:1168-1199](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1199)

### Excel Workbook Compatibility
The module is designed to match the `ETF Capping Formula.xlsx` workbook:

- Calculation order matches the workbook: AIM identity first, pricing second, company mapping third, aggregation fourth.
- Index futures and FFX contribute zero market value.
- Last Close uses the previous weekday; Real Time uses the live calendar date.
- CSV export writes UTF-8-with-BOM so Excel opens cleanly.
- Native `.xlsx` export is not enabled; the formula source remains external.
- `Level` is displayed but does not change grouping.
- `Primary FM` is display-only and copied from the Excel runbook.

**Section sources**
- [README.md:31-33](file://User scripts/ETF Capping Monitoring/README.md#L31-L33)
- [README.md:146-180](file://User scripts/ETF Capping Monitoring/README.md#L146-L180)
- [README.md:182-210](file://User scripts/ETF Capping Monitoring/README.md#L182-L210)
- [25-etf-capping-monitor.md:148-154](file://RAG KB/25-etf-capping-monitor.md#L148-L154)

## Dependency Analysis

```mermaid
graph TB
Config["config.py"] --> Data["data.py"]
Config --> Engine["engine.py"]
Config --> App["app.py"]
Data --> Engine
Data --> App
Engine --> App
```

**Diagram sources**
- [data.py:16-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L16-L23)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)

### Coupling and Cohesion
- `config.py` is the least coupled file: it defines immutable runbook data and helper constructors.
- `engine.py` depends only on `config.py` and pandas/numpy; it is the most reusable component because it performs pure calculations.
- `data.py` depends on `config.py` and `engine.py` for asset classification, and on BQL for live data.
- `app.py` depends on all three modules and on ipywidgets/ipydatagrid/plotly for the dashboard.

### External Dependencies
- Bloomberg BQL service for AIM positions, reference data, and pricing.
- Pandas and numpy for data processing.
- ipywidgets and ipydatagrid for the Desktop dashboard.
- plotly for charts.

**Section sources**
- [data.py:25-28](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L25-L28)
- [engine.py:7-10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L7-L10)
- [app.py:10-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L10-L39)

## Performance Considerations
The module implements several performance safeguards for large portfolios:

| Area | Strategy |
|---|---|
| AIM accounts | Batched in groups of 8 via `AIM_ACCOUNT_BATCH`. |
| Security-level BQL calls | Batched in groups of 150 via `SECURITY_BATCH`. |
| Descriptors | Cached per-request; `market_status()` and `name()` are not requested with cached mode. |
| Fundamental tickers | Only equities are requested; mapped in batches. |
| Thai leftover mappings | Only unresolved Thai foreign lines trigger HelpDesk DRSK lookup. |
| Prices | Last Close uses cached mode; Real Time does not. |
| Cash FX | Skips malformed tickers; USD cash is hardcoded to 1.0. |
| UI interactions | Dropdowns, searches, tab changes, and CSV exports operate on cached DataFrames. |
| Vega expressions | Row color expressions are capped to avoid oversized expressions. |

Recommended optimization strategies:

- Avoid calling `load_on_start()`; data should load only on Update.
- Prefer filtered views over full recomputation.
- Keep `config_redacted.py` out of production imports.
- Restart kernel and rerun after replacing Python files to avoid stale module state.
- Validate one account across Current/Projected, Last Close/Real Time, Thai mapping, and missing-price scenarios before running the full book.

**Section sources**
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [data.py:48-51](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L48-L51)
- [data.py:507-510](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L507-L510)
- [data.py:970-985](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L970-L985)
- [data.py:1098-1113](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1098-L1113)
- [25-etf-capping-monitor.md:177-187](file://RAG KB/25-etf-capping-monitor.md#L177-L187)
- [25-etf-capping-monitor.md:277-283](file://RAG KB/25-etf-capping-monitor.md#L277-L283)

## Troubleshooting Guide

### Position Data Parsing Issues
Symptoms:
- Empty positions table.
- Missing `AIM Code`, `Ticker`, or `Quantity`.
- AIM accounts returning no usable rows.

Checks:
- Confirm the notebook called `Update` after selecting Current or Projected.
- Verify the AIM account list is valid.
- Check Diagnostics for AIM response parsing errors.
- Ensure `PARSER_VERSION` appears in logs after restart and rerun.

Relevant behavior:
- `_parse_response` records failed or empty AIM responses.
- `_fetch_positions` requires `ID` and `Position` columns and normalizes them to `Ticker` and `Quantity`.
- Missing accounts are appended to the error list.

**Section sources**
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:1188-1199](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1188-L1199)

### Limit Calculation Issues
Symptoms:
- Wrong Rank 1 limit.
- Near Limit not triggered at 98%.
- Non-equity rows showing non-OK capping status.
- Incorrect inclusion/exclusion of Rank 1 context in alerts.

Checks:
- Confirm `Largest` is present for Rank 1.
- Confirm `WARNING_RATIO` is 0.98.
- Confirm observed weight uses the maximum of including-cash and excluding-cash.
- Confirm non-equity rows are forced to OK.
- Confirm `select_monitor_groups` is used with the intended filter.

**Section sources**
- [engine.py:505-537](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L505-L537)
- [engine.py:642-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L642-L684)
- [test_engine.py:319-391](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L391)

### Alert Generation Issues
Symptoms:
- Breach or Near Limit names missing from Alerts.
- Rank 1 context missing for flagged funds.
- Data Issue names appearing on Alerts when they should be hidden.

Checks:
- Confirm `Capping Status` is Breach or Near Limit.
- Confirm `Status` is not overriding a legitimate breach/near-limit flag.
- Confirm `select_monitor_groups` is called with `Alerts`, `Breach`, `Near Limit`, or `Data Issue`.
- Confirm incomplete accounts still surface over-limit names.

**Section sources**
- [engine.py:602-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L602-L615)
- [engine.py:642-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L642-L684)
- [test_engine.py:393-447](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L393-L447)

### Price and Reference Data Issues
Symptoms:
- Zero price for active securities.
- Stale market status.
- Missing fundamental ticker.
- Thai foreign line remaining unpriced.

Checks:
- Confirm `market_status()` and `name()` are not requested with cached mode.
- Confirm `px_last(..., fill="prev", currency="USD")` is used for priced equities.
- Confirm official empty-market statuses do not force missing-price diagnostics when a numeric last price exists.
- Confirm unresolved Thai foreign lines blank the foreign prefilled price and fall back to zero rather than reusing sparse foreign pricing.
- Confirm `Reference Data Issue` is set only for equities without usable Name or Market Status.

**Section sources**
- [data.py:493-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L493-L531)
- [data.py:599-804](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L804)
- [data.py:927-1069](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L927-L1069)
- [data.py:1303-1328](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1303-L1328)
- [engine.py:23-49](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L23-L49)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [25-etf-capping-monitor.md:79-135](file://RAG KB/25-etf-capping-monitor.md#L79-L135)

### Desktop Copy-Paste Hazards
Common issues after copying Python into BQuant Desktop:

- `AttributeError: module 'numpy' has no attribute 'infinite'` means hand-copied code used `np.infinite` instead of `np.isfinite`.
- Production engine avoids this token by using `replace([np.inf, -np.inf], np.nan)`.
- After replacing `app.py`, `data.py`, or `engine.py`, restart the kernel, run all, then click Update.
- Include/Exclude percentage cells must not use VegaExpr text coloring on Desktop; they should remain visible Python percent strings.

**Section sources**
- [25-etf-capping-monitor.md:177-191](file://RAG KB/25-etf-capping-monitor.md#L177-L191)
- [engine.py:238-240](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L238-L240)

## Conclusion
The ETF Capping Monitoring module provides a controlled, auditable pipeline from AIM portfolio data to company-level capping compliance. Its design separates concerns clearly: static configuration, BQL data retrieval, pure-Pandas calculation, and interactive dashboard rendering. The implementation prioritizes safety and reproducibility by preserving AIM holding identity, enforcing a fixed calculation order, handling missing data explicitly, and matching the Excel workbook’s business rules.

For reliable operation:

- Treat `config.py` as the single source of truth for runbook limits and display metadata.
- Never import `config_redacted.py` in production.
- Always validate AIM request shapes, last-price fallback behavior, and dynamic limit selection.
- Use the Diagnostics tab to investigate data quality rather than assuming OK results.
- Validate representative accounts across Current/Projected, Last Close/Real Time, Thai pricing, and missing-price scenarios before trusting full-book outputs.