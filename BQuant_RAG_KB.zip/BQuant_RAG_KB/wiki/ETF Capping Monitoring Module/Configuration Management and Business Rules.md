# Configuration Management and Business Rules

<cite>
**Referenced Files in This Document**   
- [config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [config_redacted.py](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py)
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [README.md](file://User scripts/ETF Capping Monitoring/README.md)
- [test_engine.py](file://User scripts/ETF Capping Monitoring/tests/test_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the configuration management system and business rules engine behind the ETF Capping Monitoring application. It focuses on:

- The three configuration tables exposed to users and tests: `account_rules_frame`, `exception_rules_frame`, and `thai_pricing_rules_frame`.
- The 54-account runbook, including capping limits, largest position limits, display levels, and pricing types.
- The exception handling mechanism for company mappings.
- Thai local-pricing overrides for foreign-line tickers.
- The `WARNING_RATIO` constant and `STATUS_COLORS` configuration used for alert thresholds and visual presentation.
- Validation logic for configuration data and error handling for invalid or missing rules.
- How business rules are separated from application logic so operators can configure accounts, exceptions, and pricing without changing code.

## Project Structure
The relevant implementation lives under the ETF Capping Monitoring user script:

```mermaid
graph TB
app["app.py<br/>Dashboard UI and documentation"] --> config["config.py<br/>Runbook, exceptions, Thai pricing, constants"]
app --> engine["engine.py<br/>Position weighting, capping, alerts"]
app --> data["data.py<br/>BQL payload fetcher (referenced)"]
config --> engine
tests["tests/test_engine.py<br/>Runbook and threshold tests"] --> engine
tests --> config
readme["README.md<br/>Monitoring rules and policy"] --> engine
```

**Diagram sources**
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)
- [config.py:186-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L268)
- [test_engine.py:19](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L19)

**Section sources**
- [app.py:1-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1-L39)
- [config.py:1-11](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L11)
- [engine.py:1-11](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L1-L11)

## Core Components
The configuration system is built around three frozen dataclasses and three DataFrame-producing functions:

| Dataclass | Purpose | Key Fields |
|---|---|---|
| `AccountRule` | Defines one AIM account’s capping policy | `aim_code`, `fund_name`, `capping`, `largest`, `level`, `price_type` |
| `ExceptionRule` | Overrides a ticker’s parent company mapping | `ticker`, `name`, `parent_ticker`, `parent_name` |
| `ThaiPricingRule` | Maps a Thai foreign-line ticker to an approved local price ticker | `foreign_ticker`, `local_ticker`, `reason` |

The three public table functions are:

| Function | Output Columns | Business Meaning |
|---|---|---|
| `account_rules_frame()` | `AIM Code`, `Fund Name`, `Capping`, `Largest`, `Level`, `Type`, `Primary FM` | 54-account runbook with per-fund capping limits, largest-name limit, grouping level, pricing type, and primary fund manager attribution. |
| `exception_rules_frame()` | `Ticker`, `Name`, `Parent Ticker`, `Parent Name` | Hard override table that forces specific tickers to group under a reviewed parent company. |
| `thai_pricing_rules_frame()` | `Foreign Ticker`, `Local Price Ticker`, `Reason` | Approved list of Thai foreign-line tickers that must price off a local `TB Equity` line. |

These frames are read-only views over the underlying rule tuples. They are consumed by the dashboard UI, the calculation engine, and tests.

**Section sources**
- [config.py:26-49](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L26-L49)
- [config.py:186-230](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L230)
- [app.py:26-32](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L32)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)

## Architecture Overview
At runtime, the application follows this flow:

```mermaid
sequenceDiagram
participant User as "User"
participant App as "ETFCappingMonitor"
participant Config as "config.py"
participant Engine as "engine.py"
participant Data as "data.py"
User->>App : Select Current or Projected and click Update
App->>Data : Fetch positions and reference data
Data-->>App : Normalized position DataFrame
App->>Engine : calculate_monitor(positions, mode, runbook, exceptions)
Engine->>Config : account_rules_frame()
Engine->>Config : exception_rules_frame()
Engine->>Engine : Attach runbook, compute MV/Weight, attach company mapping
Engine->>Engine : Group by company, rank, dynamic limit, status
Engine-->>App : MonitorResult(positions, groups, alerts, diagnostics)
App-->>User : Render Monitor, Full Positions, Diagnostics, Runbook, Exceptions
```

**Diagram sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:186-230](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L230)

## Detailed Component Analysis

### Account Rules Frame: 54-Account Runbook
The `ACCOUNT_RULES` tuple contains 54 AIM accounts. Each row defines:

- **AIM Code**: The Bloomberg AIM identifier used to join positions to the runbook.
- **Fund Name**: Human-readable fund name shown in the dashboard and diagnostics.
- **Capping**: The default maximum allowed company weight for ranks after Rank 1.
- **Largest**: Optional stricter or different limit applied only when the company is Rank 1 within its AIM account.
- **Level**: Display grouping label; currently either `Issuer` or `Stock`. It does not change aggregation behavior.
- **Type**: Pricing source policy, either `Real Time` or `Last Close`.
- **Primary FM**: Fund manager attribution derived from `PRIMARY_FM_BY_AIM`.

The frame is generated by converting each `AccountRule` into a dictionary and building a pandas DataFrame. Missing `Primary FM` values become empty strings rather than failing the run.

#### Runbook Columns and Semantics
| Column | Type | Required | Notes |
|---|---:|---:|---|
| `AIM Code` | string | Yes | Unique per account; duplicates raise a validation error. |
| `Fund Name` | string | Yes | Used for display and diagnostic reporting. |
| `Capping` | float | Yes | Decimal percentage, such as `0.10` for 10%. |
| `Largest` | float | No | If present and Rank 1, it replaces `Capping` as the dynamic limit. |
| `Level` | string | Yes | Display value; currently `Issuer` or `Stock`. |
| `Type` | string | Yes | `Real Time` or `Last Close`; controls pricing calendar behavior. |
| `Primary FM` | string | No | Derived from `PRIMARY_FM_BY_AIM`; defaults to empty if missing. |

#### Example Runbook Entries
The live runbook includes global equity, ESG-screened, regional, thematic, and pooled funds. Examples include:

- Global equity soft Islamic and sustainable mandates with 10% capping and 10% largest limits.
- Regional EM and Asia-Pacific ETFs with 20% capping and 35% largest limits.
- Pooled index and multi-manager funds with 10%, 20%, or 35% capping depending on mandate.
- Some funds use `Issuer` grouping; others use `Stock` grouping.
- Pricing type alternates between `Real Time` and `Last Close` based on mandate requirements.

**Section sources**
- [config.py:51-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L51-L107)
- [config.py:127-183](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L127-L183)
- [config.py:186-201](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L201)
- [README.md:104-125](file://User scripts/ETF Capping Monitoring/README.md#L104-L125)

### Exception Rules Frame: Company Mapping Overrides
The `EXCEPTION_RULES` tuple provides hard overrides for company grouping. Its purpose is to force related tickers—such as multiple listings, ADRs, or subsidiaries—to group under one reviewed parent company key.

The engine applies exceptions in this order:

1. Hard exception override by cleaned, uppercased ticker.
2. Lineage-mapped fundamental ticker.
3. Original held ticker as a fallback.

When no fundamental ticker is available, the engine records a diagnostic explaining that the original ticker was used as the company key.

#### Exception Columns and Semantics
| Column | Meaning |
|---|---|
| `Ticker` | The held AIM ticker being overridden. |
| `Name` | Human-readable name for the overridden ticker. |
| `Parent Ticker` | The parent company ticker used for grouping. |
| `Parent Name` | Human-readable parent company name. |

The current live exceptions group several Korean equities and an ADR under a single SK Inc parent key.

**Section sources**
- [config.py:110-116](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L110-L116)
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [README.md:62-67](file://User scripts/ETF Capping Monitoring/README.md#L62-L67)

### Thai Pricing Rules Frame: Local-Price Overrides
Thai foreign-line tickers ending in `/F TB Equity` or `-R TB Equity` retain their AIM identity but must price off an approved local `TB Equity` line before market value is calculated.

The `THAI_PRICING_RULES` tuple lists approved mappings. The engine validates them through `thai_pricing_overrides()`:

- The foreign key must end in `/F TB EQUITY` or `-R TB EQUITY`.
- The local ticker must end in ` TB EQUITY`.
- The local ticker must not contain `/F` or `-R`.
- Duplicate foreign keys are rejected.

If no approved override exists, the engine attempts a deterministic stripped candidate, then HelpDesk-confirmed DRSK fallback. Unresolved Thai mappings produce diagnostics and remove the price rather than reusing a sparse foreign-line price.

**Section sources**
- [config.py:118-124](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L118-L124)
- [config.py:233-258](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L233-L258)
- [engine.py:233-346](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L346)
- [README.md:68-90](file://User scripts/ETF Capping Monitoring/README.md#L68-L90)

### WARNING_RATIO and STATUS_COLORS
Two top-level configuration constants control alert thresholds and visual presentation:

| Constant | Value | Purpose |
|---|---:|---|
| `WARNING_RATIO` | `0.98` | Near-limit threshold. Observed weight at or above 98% of the dynamic limit becomes `Near Limit`. |
| `STATUS_COLORS` | Dictionary mapping status text to hex color | Breach, Near Limit, OK, and Data Issue colors used by the dashboard. |

The engine uses `WARNING_RATIO` directly when computing `Capping Status` and when coloring monitor weight cells. The dashboard imports both constants and uses them to render status chips and background/text colors.

```mermaid
flowchart TD
Start(["Observed Weight"]) --> CompareLimit["Compare to Dynamic Limit"]
CompareLimit --> Breach{"≥ 100%?"}
Breach --> |Yes| SetBreach["Status = Breach"]
Breach --> |No| NearCheck["Compare to WARNING_RATIO × Dynamic Limit"]
NearCheck --> Near{"≥ 98%?"}
Near --> |Yes| SetNear["Status = Near Limit"]
Near --> |No| SetOK["Status = OK"]
SetBreach --> Color["Apply STATUS_COLORS"]
SetNear --> Color
SetOK --> Color
```

**Diagram sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [engine.py:522-536](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L536)
- [engine.py:618-639](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L618-L639)
- [app.py:235-254](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L235-L254)

**Section sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [engine.py:522-536](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L536)
- [engine.py:618-639](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L618-L639)
- [app.py:235-254](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L235-L254)

### Validation Logic and Error Handling
The configuration and engine layers enforce strict validation:

| Validation | Behavior |
|---|---|
| Missing required position columns | Raises `KeyError` with the missing column names. |
| Invalid `position_mode` | Raises `ValueError`; only `Current` or `Projected` are accepted. |
| Missing runbook columns | Raises `KeyError` listing required runbook columns. |
| Duplicate AIM codes in runbook | Raises `ValueError` with duplicate codes. |
| Blank exception tickers | Raises `ValueError`. |
| Duplicate exception tickers | Raises `ValueError` with duplicate tickers. |
| Invalid Thai pricing override format | Raises `ValueError` indicating non-foreign or non-local line. |
| Duplicate Thai foreign-line override | Raises `ValueError`. |
| Missing runbook rule for an AIM account | Adds a `Missing Runbook` diagnostic instead of crashing. |
| Missing quantity, price, or reference data | Records diagnostics and falls back to zero where safe. |
| Zero account total market value | Records diagnostics and marks the account incomplete. |

The engine separates hard failures (configuration errors) from soft failures (data issues). Hard failures stop execution; soft failures surface diagnostics while allowing other holdings to calculate safely.

```mermaid
flowchart TD
Input["Raw Positions"] --> ValidateCols["Validate Required Columns"]
ValidateCols --> ValidCols{"Columns Valid?"}
ValidCols --> |No| RaiseKey["Raise KeyError"]
ValidCols --> |Yes| AttachRunbook["Attach Runbook"]
AttachRunbook --> ValidRunbook{"Runbook Valid?"}
ValidRunbook --> |No| RaiseRunbook["Raise KeyError / ValueError"]
ValidRunbook --> |Yes| ComputeMV["Compute Market Value and Weight"]
ComputeMV --> MapCompany["Attach Company Mapping"]
MapCompany --> ValidExceptions{"Exceptions Valid?"}
ValidExceptions --> |No| RaiseException["Raise ValueError"]
ValidExceptions --> |Yes| GroupRank["Group, Rank, Dynamic Limit"]
GroupRank --> Status["Compute Capping Status and Alerts"]
Status --> Diagnostics["Collect Diagnostics"]
```

**Diagram sources**
- [engine.py:95-101](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L101)
- [engine.py:117-147](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L117-L147)
- [engine.py:150-171](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L171)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:233-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L233-L268)

**Section sources**
- [engine.py:95-101](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L101)
- [engine.py:117-147](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L117-L147)
- [engine.py:150-171](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L171)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:233-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L233-L268)

### Separation Between Business Rules and Application Logic
The design intentionally separates:

- **Business rules**: Stored in `config.py` as frozen dataclasses and tuples. These define which accounts exist, what limits apply, how companies map, and which Thai lines are approved.
- **Application logic**: Implemented in `engine.py` and `app.py`. These consume the rules, fetch data, compute weights, render dashboards, and expose read-only configuration tables.

Operators should edit `config.py` for production rules and keep `config_redacted.py` synchronized as a desensitized output copy. Tests import from `config.py` and validate behavior such as Rank 1 using `Largest` and later ranks using `Capping`.

**Section sources**
- [config.py:1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)
- [config_redacted.py:1-6](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py#L1-L6)
- [test_engine.py:319-357](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L357)

## Dependency Analysis
The main dependency relationships are:

```mermaid
graph LR
Config["config.py"] --> Engine["engine.py"]
Config --> App["app.py"]
Engine --> App
Tests["tests/test_engine.py"] --> Engine
Tests --> Config
Readme["README.md"] --> Engine
```

- `app.py` imports `STATUS_COLORS`, `WARNING_RATIO`, and the three `_rules_frame` functions from `config.py`, plus calculation helpers from `engine.py`.
- `engine.py` imports `WARNING_RATIO`, `account_rules_frame`, and `exception_rules_frame` from `config.py`.
- Tests import `ACCOUNT_RULES`, `PRIMARY_FM_BY_AIM`, `account_rules_frame`, and `thai_pricing_overrides` from `config.py`.

**Diagram sources**
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)
- [test_engine.py:19](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L19)

**Section sources**
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)
- [test_engine.py:19](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L19)

## Performance Considerations
- Account requests are batched in groups of eight.
- Security requests are batched in groups of 150.
- Dropdowns, searches, tab changes, and CSV exports are local operations and do not rerun BQL.
- The dashboard avoids expensive Vega expressions when they exceed size limits and falls back to Python-based row coloring.
- Configuration frames are lightweight pandas DataFrames created from small tuples.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Adding a New Account
To add a new AIM account without changing application logic:

1. Add a new `AccountRule` entry to `ACCOUNT_RULES` in `config.py`.
2. Include:
   - `aim_code`: the Bloomberg AIM identifier.
   - `fund_name`: the fund name displayed in the dashboard.
   - `capping`: the default company weight limit as a decimal.
   - `largest`: optional Rank 1 limit; omit or leave equal to `capping` if not needed.
   - `level`: `Issuer` or `Stock`.
   - `price_type`: `Real Time` or `Last Close`.
3. Add the AIM code to `PRIMARY_FM_BY_AIM` if fund manager attribution is required.
4. Regenerate `config_redacted.py` as a desensitized output copy.
5. Verify uniqueness: `account_codes()` raises `ValueError` for duplicate AIM codes.

Expected validation outcomes:

- Duplicate AIM code → `ValueError` during configuration validation.
- Missing runbook rule for an AIM account → `Missing Runbook` diagnostic and incomplete-account flag.

**Section sources**
- [config.py:51-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L51-L107)
- [config.py:127-183](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L127-L183)
- [config.py:261-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L261-L268)
- [engine.py:117-147](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L117-L147)

### Setting Up a Company Exception
To force a ticker to group under a reviewed parent company:

1. Add an `ExceptionRule` entry to `EXCEPTION_RULES` in `config.py`.
2. Provide:
   - `ticker`: the exact held ticker to override.
   - `name`: human-readable name for the ticker.
   - `parent_ticker`: the parent company ticker used for grouping.
   - `parent_name`: human-readable parent company name.
3. Ensure the ticker is unique among exceptions; duplicate exception tickers raise `ValueError`.
4. Confirm the override appears in the `Exceptions` grid via `exception_rules_frame()`.

The engine applies exceptions before fundamental ticker mapping and records the mapping source.

**Section sources**
- [config.py:110-116](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L110-L116)
- [config.py:204-216](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L204-L216)
- [engine.py:150-171](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L171)
- [engine.py:187-199](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L187-L199)

### Modifying Thai Pricing Rules
To approve a new Thai foreign-line pricing override:

1. Add a `ThaiPricingRule` entry to `THAI_PRICING_RULES` in `config.py`.
2. Ensure:
   - `foreign_ticker` ends in `/F TB Equity` or `-R TB Equity`.
   - `local_ticker` ends in ` TB Equity`.
   - `local_ticker` does not contain `/F` or `-R`.
3. Avoid duplicate foreign keys; duplicates raise `ValueError`.
4. Confirm the mapping appears in `thai_pricing_rules_frame()` and passes `thai_pricing_overrides()`.

If validation fails, the engine leaves the Thai foreign line unresolved, removes the price, and records a diagnostic.

**Section sources**
- [config.py:118-124](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L118-L124)
- [config.py:219-230](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L219-L230)
- [config.py:233-258](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L233-L258)
- [engine.py:233-346](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L346)

### Adjusting Alert Thresholds and Colors
To adjust alert thresholds:

- Change `WARNING_RATIO` in `config.py` to modify the near-limit threshold.
- Update `STATUS_COLORS` to change Breach, Near Limit, OK, and Data Issue colors.

Note that changing `WARNING_RATIO` affects:

- `Capping Status` computation.
- Monitor weight tone coloring.
- Dashboard status rendering.

Tests confirm that the warning threshold is inclusive and that a near-limit holding triggers an alert.

**Section sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [engine.py:522-536](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L536)
- [engine.py:618-639](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L618-L639)
- [test_engine.py:359-391](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L359-L391)

## Conclusion
The ETF Capping Monitoring system cleanly separates business rules from application logic. Operators can manage the 54-account runbook, company exceptions, and Thai local-pricing overrides through configuration tables without modifying application code. The engine enforces strong validation, surfaces diagnostics for incomplete or missing data, and applies consistent capping logic using `WARNING_RATIO` and `STATUS_COLORS`. This design supports safe, auditable changes to capping policy, company grouping, and pricing behavior while keeping the dashboard and calculation pipeline stable.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Runbook Setup Summary
- Use `account_rules_frame()` to view or export the 54-account runbook.
- Use `exception_rules_frame()` to review hard company mapping overrides.
- Use `thai_pricing_rules_frame()` to review approved Thai foreign-line pricing overrides.
- Use `account_codes()` to validate unique AIM codes.
- Use `thai_pricing_overrides()` to validate Thai override format and uniqueness.

**Section sources**
- [config.py:186-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L268)
- [app.py:1108-1112](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1108-L1112)
- [app.py:2505-2544](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2505-L2544)