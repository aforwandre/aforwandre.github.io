# AIM Position Processing Pipeline

<cite>
**Referenced Files in This Document**   
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [README.md](file://User scripts/ETF Capping Monitoring/README.md)
- [test_engine.py](file://User scripts/ETF Capping Monitoring/tests/test_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the AIM position processing pipeline used by the ETF Capping Monitoring application. The system ingests portfolio data from Bloomberg’s Asset Investment Manager (AIM), covering Current and Projected positions across 54 accounts defined in the bundled runbook. It constructs BQL requests against `position_without_pending()` and `pending_position()`, filters AIM members, aggregates quantities by AIM Code plus Ticker, enriches holdings with reference data and USD pricing, validates quantity and price completeness, and produces company-level weights for capping monitoring.

The pipeline is intentionally frozen around a specific Desktop contract:
- Current uses `position_without_pending()["value"]`.
- Projected uses `position_without_pending()["value"] + pending_position()["value"]`.
- Account filtering uses `Members(Type=AIM)` with one account per request.
- Parameters `accounts`, `pxnum=1377`, and `profile="DEFAULT_PROFILE"` are passed through `with_params` and must not be moved onto `members()`.

## Project Structure
The AIM pipeline lives under the ETF Capping Monitoring user script:

```mermaid
graph TB
subgraph "ETF Capping Monitoring"
APP["app.py<br/>UI orchestration and status display"]
DATA["data.py<br/>BQL ingestion, normalization, enrichment"]
ENGINE["engine.py<br/>Validation, valuation, grouping, capping"]
CONFIG["config.py<br/>Runbook, exceptions, batch sizes"]
TESTS["tests/test_engine.py<br/>Pure-Pandas validation cases"]
end
APP --> DATA
APP --> ENGINE
DATA --> CONFIG
ENGINE --> CONFIG
TESTS --> ENGINE
```

**Diagram sources**
- [app.py:408-440](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L408-L440)
- [data.py:1168-1378](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1378)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [test_engine.py:659-700](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L659-L700)

**Section sources**
- [README.md:9-11](file://User scripts/ETF Capping Monitoring/README.md#L9-L11)
- [README.md:35-67](file://User scripts/ETF Capping Monitoring/README.md#L35-L67)
- [README.md:146-180](file://User scripts/ETF Capping Monitoring/README.md#L146-L180)

## Core Components
- **BQL ingestion layer**: Builds and executes AIM position requests, descriptor requests, fundamental ticker/name requests, Thai local-line mappings, and USD pricing requests.
- **Normalization layer**: Converts raw BQL responses into structured pandas DataFrames with consistent columns such as `AIM Code`, `Ticker`, `Quantity`, `Price USD`, and `Price Date`.
- **Validation and enrichment layer**: Checks required fields, flags missing or malformed data, resolves Thai foreign lines to approved local pricing tickers, and attaches reference data.
- **Capping engine**: Calculates market values, security weights, company aggregation, dynamic limits, utilization, and breach/near-limit alerts.
- **Configuration layer**: Defines the 54 AIM accounts, capping rules, exception mappings, Thai pricing overrides, and batching parameters.

**Section sources**
- [data.py:34-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L34-L45)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [engine.py:13-23](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L13-L23)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [config.py:52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)

## Architecture Overview
The pipeline follows a staged flow:

```mermaid
sequenceDiagram
participant User as "User"
participant App as "app.py"
participant Data as "data.py"
participant BQL as "Bloomberg BQL Service"
participant Engine as "engine.py"
User->>App : Select Current or Projected
App->>Data : fetch_monitor_payload(position_mode, accounts, today)
Data->>BQL : Members(Type=AIM) + position_without_pending / pending_position
BQL-->>Data : Raw AIM response
Data->>Data : Normalize to DataFrame<br/>Aggregate by AIM Code + Ticker
Data->>BQL : Descriptors, fundamentals, Thai mapping
BQL-->>Data : Reference data frames
Data->>BQL : px_last USD prices
BQL-->>Data : Price frames
Data->>Engine : calculate_monitor(normalized_positions, position_mode)
Engine->>Engine : Validate, value, weight, group, cap
Engine-->>App : MonitorResult
App-->>User : Updated status, diagnostics, tables
```

**Diagram sources**
- [app.py:408-440](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L408-L440)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:1168-1378](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1378)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

## Detailed Component Analysis

### AIM Request Construction and Account Filtering
The AIM request is isolated in `_aim_request`:
- Universe: `bq.univ.members(type="AIM")`.
- Item: `_position_item(bq, position_mode)`.
- Parameters: `accounts=[one AIM code]`, `pxnum=1377`, `profile="DEFAULT_PROFILE"`.

`_position_item` implements the frozen contract:
- Current: `bq.data.position_without_pending()["value"]`.
- Projected: `bq.data.position_without_pending()["value"] + bq.data.pending_position()["value"]`.

Account filtering is applied per account, not as a bulk list on `members()`. The README explicitly documents that this translation from the workbook’s `Members(Type=AIM), Accounts=[...]` is frozen and must not change item names, dates, or parameter placement.

```mermaid
flowchart TD
Start(["Build AIM Request"]) --> Mode{"Position Mode?"}
Mode --> |Current| CurrentItem["position_without_pending()['value']"]
Mode --> |Projected| ProjectedItem["position_without_pending()['value'] + pending_position()['value']"]
CurrentItem --> Request["bql.Request(Members(Type=AIM), {'Position': item}, with_params={accounts, pxnum=1377, profile='DEFAULT_PROFILE'})"]
ProjectedItem --> Request
Request --> End(["Return Request"])
```

**Diagram sources**
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [README.md:207-210](file://User scripts/ETF Capping Monitoring/README.md#L207-L210)

**Section sources**
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [README.md:52-56](file://User scripts/ETF Capping Monitoring/README.md#L52-L56)
- [README.md:207-210](file://User scripts/ETF Capping Monitoring/README.md#L207-L210)

### Position Ingestion and Aggregation
`_fetch_positions` performs the following steps:
1. Build labeled requests for each selected AIM account.
2. Execute requests in batches of `AIM_ACCOUNT_BATCH` (default 8).
3. Parse each response into a DataFrame with at least `ID` and `Position`.
4. Rename `ID` to `Ticker` and `Position` to `Quantity`.
5. Attach `AIM Code`.
6. Concatenate rows and aggregate `Quantity` by `AIM Code` + `Ticker`.

```mermaid
flowchart TD
A["Selected AIM accounts"] --> B["Create labeled requests"]
B --> C["Batch execute via _execute_many"]
C --> D{"Response valid?"}
D --> |No| E["Append error"]
D --> |Yes| F["Extract ID and Position columns"]
F --> G["Rename to Ticker and Quantity"]
G --> H["Attach AIM Code"]
H --> I["Concatenate all rows"]
I --> J["Sum Quantity by AIM Code + Ticker"]
J --> K["Return aggregated positions DataFrame"]
```

**Diagram sources**
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)

**Section sources**
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)

### Response Parsing and Error Handling for Malformed BQL Responses
The parsing layer is defensive:
- `_is_response` distinguishes real BQL responses from tuples, lists, dicts, strings, bytes, DataFrames, exceptions, or empty results.
- `_response_items` extracts item responses without requiring Arrow response iteration.
- `_lookup_item` finds named items flexibly by name, uppercase, lowercase, or function-call form.
- `_item_frame` normalizes index levels, identifies ID/date/value columns, and returns a clean DataFrame.
- `_parse_response` records errors when the response is invalid, parsing fails, or the result is empty.
- `_execute_many` tracks mismatched response counts and appends diagnostic messages.

```mermaid
flowchart TD
R["Raw BQL response"] --> Check["_is_response(response)"]
Check --> |False| Err["Record request failure"]
Check --> |True| Items["_response_items(response)"]
Items --> Lookup["_lookup_item(name)"]
Lookup --> Frame["_item_frame(item)"]
Frame --> Merge["_merge_item_frames(frames)"]
Merge --> Valid{"DataFrame non-empty?"}
Valid --> |No| EmptyErr["Record empty response"]
Valid --> |Yes| Return["Return normalized DataFrame"]
```

**Diagram sources**
- [data.py:57-98](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L57-L98)
- [data.py:101-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L101-L183)
- [data.py:210-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L210-L256)
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)

**Section sources**
- [data.py:57-98](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L57-L98)
- [data.py:101-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L101-L183)
- [data.py:210-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L210-L256)
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)

### Reference Data and Thai Pricing Resolution
Reference data resolution includes:
- Basic descriptors: `name()` and `market_status()`.
- Fundamental ticker mapping: `id().value(fundamentalticker(), mapby="lineage")`.
- Thai foreign-line handling:
  - Approved overrides in `THAI_PRICING_RULES`.
  - Deterministic stripping of `/F TB Equity` or `-R TB Equity`.
  - Validation that the candidate has usable reference data and matches the same fundamental ticker.
  - Leftover unresolved foreign lines use `bb_default_risk_obligor_ticker(mode="cached")`.

```mermaid
flowchart TD
T["AIM Ticker"] --> CheckThai{"Is Thai foreign line?"}
CheckThai --> |No| Normal["Use original ticker"]
CheckThai --> |Yes| Override["Check approved override"]
Override --> FoundOverride{"Override found?"}
FoundOverride --> |Yes| UseOverride["Use approved local ticker"]
FoundOverride --> |No| Strip["Strip /F or -R suffix"]
Strip --> CandidateValid{"Candidate has Name or Market Status?"}
CandidateValid --> |Yes| FundMatch{"Same fundamental ticker?"}
FundMatch --> |Yes| UseStrip["Use validated stripped local ticker"]
FundMatch --> |No| DRSK["Try HelpDesk DRSK mapping"]
DRSK --> DRSKValid{"DRSK is local TB Equity with reference data?"}
DRSKValid --> |Yes| UseDRSK["Use DRSK local ticker"]
DRSKValid --> |No| Unresolved["Mark as Unresolved"]
Normal --> Done["Proceed with pricing"]
UseOverride --> Done
UseStrip --> Done
UseDRSK --> Done
Unresolved --> Done
```

**Diagram sources**
- [data.py:373-411](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L373-L411)
- [data.py:599-698](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L698)
- [data.py:701-804](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L701-L804)
- [README.md:68-84](file://User scripts/ETF Capping Monitoring/README.md#L68-L84)

**Section sources**
- [data.py:493-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L493-L531)
- [data.py:534-596](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L534-L596)
- [data.py:599-804](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L804)
- [README.md:68-84](file://User scripts/ETF Capping Monitoring/README.md#L68-L84)

### USD Pricing Integration
USD pricing is fetched separately for:
- Non-cash, non-index-future, non-FFX securities using `px_last(dates=..., currency="USD", fill="prev")`.
- Cash balances where the currency is extracted from short yellow keys like `USD Curncy` or `EUR Curncy`; non-USD cash uses FX rates such as `USD{CUR} BGNL Curncy`.

Pricing behavior:
- Last Close uses the previous weekday; Real Time uses today.
- `mode="cached"` is used for Last Close pricing; Real Time pricing does not force cached mode.
- Ambiguous pricing tickers produce an error and leave the price unresolved.
- Missing or zero FX rates are recorded as errors.

```mermaid
flowchart TD
P["Positions with Type and Pricing Ticker"] --> Classify["Classify asset type"]
Classify --> Security{"Security price needed?"}
Security --> |Yes| PxLast["Request px_last USD"]
Security --> |No| Skip["Skip or set zero"]
Classify --> Cash{"Cash balance?"}
Cash --> |Yes| FX{"Non-USD currency?"}
FX --> |No| OneToOne["Set Price USD = 1.0"]
FX --> |Yes| FXRate["Request USD per Local FX rate"]
FXRate --> RateValid{"Rate present and non-zero?"}
RateValid --> |Yes| Convert["Price USD = 1 / FX rate"]
RateValid --> |No| FXError["Record FX error"]
PxLast --> Map["Map Pricing Ticker back to Ticker"]
Map --> Output["Attach Price Date and Price USD"]
Convert --> Output
OneToOne --> Output
Skip --> Output
```

**Diagram sources**
- [data.py:927-1069](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L927-L1069)
- [data.py:1072-1165](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1072-L1165)

**Section sources**
- [data.py:927-1069](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L927-L1069)
- [data.py:1072-1165](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1072-L1165)

### Validation Logic for Quantity, Pricing, and Reference Data Completeness
The engine enforces strict validation:
- Required position columns: `AIM Code`, `Ticker`, `Quantity`.
- Quantity is coerced to numeric; missing quantities are flagged.
- `Price USD` is coerced to numeric; infinite values become NaN.
- For official empty-market statuses, missing Bloomberg last price is expected and falls back to zero rather than being treated as a missing-price error.
- Unresolved Thai pricing leaves `Price USD` as NaN and records a diagnostic.
- Missing reference data for equities marks the row as incomplete.
- Missing prices for non-zero holdings are recorded as diagnostics.
- Index futures and FFX have zero market value.
- Row-level issues propagate to account-level `Has Data Issue`.

```mermaid
flowchart TD
V["Normalized positions"] --> CheckCols["Validate required columns"]
CheckCols --> Quant["Coerce Quantity to numeric"]
Quant --> Price["Coerce Price USD to numeric"]
Price --> MarketStatus{"Official empty-market status?"}
MarketStatus --> |Yes| ZeroPrice["Set Price USD = 0.0"]
MarketStatus --> |No| ThaiCheck{"Thai pricing unresolved?"}
ThaiCheck --> |Yes| LeaveNaN["Leave Price USD NaN"]
ThaiCheck --> |No| RefCheck{"Reference data available?"}
RefCheck --> |No| MarkRef["Mark Reference Data Issue"]
RefCheck --> |Yes| MissingPrice{"Non-zero holding needs price?"}
MissingPrice --> |Yes & Missing| MarkMissing["Mark Missing Price"]
MissingPrice --> |No| MV["Calculate Market Value USD"]
ZeroPrice --> MV
LeaveNaN --> MV
MarkRef --> MV
MarkMissing --> MV
MV --> RowIssue["Mark Row Data Issue"]
RowIssue --> AccountIssue["Propagate to account Has Data Issue"]
```

**Diagram sources**
- [engine.py:95-100](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L100)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [test_engine.py:659-700](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L659-L700)
- [test_engine.py:1033-1067](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1033-L1067)

**Section sources**
- [engine.py:95-100](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L100)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [test_engine.py:659-700](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L659-L700)
- [test_engine.py:1033-1067](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1033-L1067)

### Position Data Transformation Examples
The transformation from raw AIM responses to structured pandas DataFrames can be described as follows:

1. **Raw AIM response shape**: Each BQL item returns a DataFrame-like object with columns including `ID`, `Position`, and possibly `DATE`, `CURRENCY`, `ORIG_IDS`, `REVISION_DATE`.
2. **Column normalization**:
   - `ID` becomes `Ticker`.
   - `Position` becomes `Quantity`.
   - `AIM Code` is attached from the account label.
3. **Aggregation**:
   - Rows are concatenated across accounts.
   - `Quantity` is summed by `AIM Code` + `Ticker`.
4. **Enrichment**:
   - Descriptors add `Name` and `Market Status`.
   - Fundamental mapping adds `Fundamental Ticker` and optionally `Fundamental Name`.
   - Thai pricing adds `Thai Local Pricing Ticker`, `Thai Price Mapping`, `Pricing Market Status`, and `Thai Mapping Note`.
   - USD pricing adds `Price Date` and `Price USD`.
5. **Final normalized shape**:
   - Core columns: `AIM Code`, `Ticker`, `Quantity`.
   - Enriched columns: `Name`, `Market Status`, `Fundamental Ticker`, `Fundamental Name`, `Thai Local Pricing Ticker`, `Thai Price Mapping`, `Pricing Market Status`, `Thai Mapping Note`, `Pricing Ticker`, `Price Mapping`, `Price Date`, `Price USD`.

These transformations are implemented in:
- `_item_frame` and `_response_to_frame` for generic BQL normalization.
- `_fetch_positions` for AIM-specific reshaping and aggregation.
- `fetch_monitor_payload` for end-to-end enrichment and merging.

**Section sources**
- [data.py:126-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L126-L183)
- [data.py:210-234](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L210-L234)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:1168-1378](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1378)

### Error Handling for Missing Account Data and Incomplete Position Records
- **Missing account data**: If selected AIM accounts return no usable position rows, `fetch_monitor_payload` records an error listing the missing accounts.
- **Malformed BQL responses**: `_parse_response` records failures when the response is not a valid BQL response, when parsing raises an exception, or when the parsed frame is empty.
- **Incomplete position records**: Engine diagnostics record missing quantities, missing prices, unresolved Thai pricing, missing reference data, zero account totals, and missing runbook entries.
- **UI feedback**: The app displays completion state, account count, position count, latest price date, and the number of BQL notes when errors exist.

```mermaid
flowchart TD
A["AIM request executed"] --> B{"Response valid?"}
B --> |No| E1["Record request failure"]
B --> |Yes| C{"Frame non-empty?"}
C --> |No| E2["Record empty response"]
C --> |Yes| D["Normalize and aggregate"]
D --> E{"Required columns present?"}
E --> |No| E3["Record missing columns"]
E --> |Yes| F["Enrich with reference data and prices"]
F --> G{"Reference data complete?"}
G --> |No| E4["Mark Reference Data Issue"]
G --> |Yes| H["Calculate values and weights"]
H --> I{"Any missing quantity or price?"}
I --> |Yes| E5["Record Missing Quantity or Missing Price"]
I --> |No| J["Complete"]
```

**Diagram sources**
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:466-479](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L466-L479)
- [data.py:1190-1198](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1190-L1198)
- [engine.py:321-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L321-L399)
- [app.py:1319-1345](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1319-L1345)

**Section sources**
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:466-479](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L466-L479)
- [data.py:1190-1198](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1190-L1198)
- [engine.py:321-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L321-L399)
- [app.py:1319-1345](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1319-L1345)

### Integration Patterns with Bloomberg’s Position Services
The integration pattern is explicit and frozen:
- Universe: `bq.univ.members(type="AIM")`.
- Position item: `position_without_pending()["value"]` for Current; sum with `pending_position()["value"]` for Projected.
- Parameters: `accounts=[one AIM code]`, `pxnum=1377`, `profile="DEFAULT_PROFILE"`.
- Execution: `bq.execute_many` with `on_request_error=_on_request_error` and `num_retries=1`.
- Response handling: Defensive extraction of item DataFrames without assuming Arrow iteration semantics.

```mermaid
classDiagram
class DataLayer {
+_require_bql()
+_execute_many(bq, labeled_requests, item_names, errors)
+_fetch_positions(bq, accounts, position_mode, errors, progress)
+_aim_request(bq, account, position_mode)
+_position_item(bq, position_mode)
}
class BQLService {
+execute_many(requests, on_request_error, num_retries)
+univ.members(type)
+data.position_without_pending()
+data.pending_position()
+data.px_last(dates, currency, fill)
+data.name()
+data.market_status()
+data.id()
+data.fundamentalticker()
+data.bb_default_risk_obligor_ticker(mode)
}
DataLayer --> BQLService : "constructs and executes requests"
```

**Diagram sources**
- [data.py:40-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L40-L45)
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)

**Section sources**
- [data.py:40-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L40-L45)
- [data.py:259-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L319)
- [README.md:52-56](file://User scripts/ETF Capping Monitoring/README.md#L52-L56)

### Caching Mechanisms Used for Performance Optimization
Caching appears in two forms:
1. **BQL-level caching**: Some requests pass `with_params={"mode": "cached"}`, notably for fundamental tickers, fundamental names, Thai DRSK mappings, and Last Close pricing.
2. **In-memory pandas caching**: The pipeline concatenates and deduplicates intermediate DataFrames, reuses descriptor caches, and avoids redundant requests by tracking existing tickers before fetching additional reference data.

Important constraints:
- `market_status()` is intentionally requested without `mode="cached"` because Desktop returned stale `Delisted` for some tickers while live data showed `Active`.
- Last Close pricing uses `mode="cached"`; Real Time pricing does not force cached mode.
- The README warns against using cached `market_status()` due to observed staleness.

**Section sources**
- [data.py:507-509](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L507-L509)
- [data.py:561-572](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L561-L572)
- [data.py:725-736](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L725-L736)
- [data.py:896-903](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L896-L903)
- [data.py:970-985](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L970-L985)
- [README.md:91-94](file://User scripts/ETF Capping Monitoring/README.md#L91-L94)

## Dependency Analysis
The pipeline has clear separation between ingestion, normalization, enrichment, and calculation:

```mermaid
graph LR
Config["config.py<br/>ACCOUNT_RULES, EXCEPTION_RULES, THAI_PRICING_RULES"] --> Data["data.py"]
Config --> Engine["engine.py"]
Data --> Engine
App["app.py"] --> Data
App --> Engine
Tests["tests/test_engine.py"] --> Engine
```

Key dependencies:
- `data.py` depends on `config.py` for batch sizes and account rules.
- `engine.py` depends on `config.py` for warning ratio, account rules, and exception rules.
- `app.py` orchestrates user interaction and calls both `data.py` and `engine.py`.
- `tests/test_engine.py` validates engine logic with synthetic pandas data and does not execute BQL.

**Diagram sources**
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [config.py:52-116](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L116)
- [data.py:16-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L16-L23)
- [engine.py:10-10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10-L10)
- [app.py:408-440](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L408-L440)

**Section sources**
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [config.py:52-116](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L116)
- [data.py:16-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L16-L23)
- [engine.py:10-10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10-L10)
- [app.py:408-440](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L408-L440)

## Performance Considerations
- **Account batching**: AIM position requests are batched in groups of 8 (`AIM_ACCOUNT_BATCH`).
- **Security batching**: Descriptor, fundamental, Thai DRSK, and price requests are batched in groups of 150 (`SECURITY_BATCH`).
- **Minimized redundant requests**: Existing tickers are tracked before requesting additional descriptors or fundamentals.
- **Selective caching**: Cached mode is used where confirmed safe; `market_status()` is deliberately not cached.
- **Local operations**: Dropdowns, searches, tab changes, and CSV exports are local and do not rerun BQL.

**Section sources**
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [data.py:510-516](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L510-L516)
- [data.py:725-742](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L725-L742)
- [data.py:970-985](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L970-L985)
- [README.md:171-180](file://User scripts/ETF Capping Monitoring/README.md#L171-L180)

## Troubleshooting Guide
Common issues and their handling:

| Issue | Symptom | Handling |
|---|---|---|
| Malformed BQL response | Request fails or returns unexpected type | Recorded as request failure; normalized frame is empty |
| Empty BQL response | No rows after parsing | Recorded as empty response |
| Missing position columns | Response lacks `ID` or `Position` | Error appended with missing column names |
| Missing account data | Selected AIM account returns no usable rows | Error lists missing accounts |
| Missing quantity | Quantity is non-numeric or NaN | Diagnostic records Missing Quantity; market value becomes zero |
| Missing price | Non-zero holding has no USD price | Diagnostic records Missing Price; market value becomes zero |
| Official empty-market status | No Bloomberg last price | Price set to zero without missing-price error |
| Unresolved Thai pricing | Foreign line cannot resolve to local ticker | Price left NaN; diagnostic records Thai Pricing Unresolved |
| Missing reference data | Equity lacks Name and Market Status | Reference Data Issue marked; price and capping status remain unresolved |
| Zero account total | All holdings have zero market value | Diagnostics record Zero Denominator and Account Incomplete |
| UI completion with issues | Header shows Completed with issues | Displays number of BQL notes and prompts review of Diagnostics |

**Section sources**
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:466-479](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L466-L479)
- [data.py:1190-1198](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1190-L1198)
- [engine.py:275-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L275-L399)
- [app.py:1319-1345](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1319-L1345)

## Conclusion
The AIM position processing pipeline is a carefully constrained integration between Bloomberg’s AIM position services and a pandas-based capping engine. Its design prioritizes contract stability, defensive parsing, explicit diagnostics, and transparent data-quality signaling. Current and Projected positions are distinguished by the frozen AIM contract, account filtering is isolated per AIM member, and position aggregation preserves exact held-ticker identity until final company-level grouping. Errors for malformed responses, missing accounts, and incomplete records are surfaced rather than silently converted into OK results, ensuring that users can inspect Diagnostics and maintain confidence in capping outputs.