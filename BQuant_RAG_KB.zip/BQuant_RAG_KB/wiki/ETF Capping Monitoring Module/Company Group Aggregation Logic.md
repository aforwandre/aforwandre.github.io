# Company Group Aggregation Logic

<cite>
**Referenced Files in This Document**   
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [test_engine.py](file://User scripts/ETF Capping Monitoring/tests/test_engine.py)
- [24-etf-field-migration-incident.md](file://RAG KB/24-etf-field-migration-incident.md)
- [23-bql-substitution-due-diligence.md](file://RAG KB/23-bql-substitution-due-diligence.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the company group aggregation logic used by the ETF Capping Monitor to consolidate individual security positions into issuer-level holdings. It covers:

- How a company key is resolved through exception overrides, `fundamentalticker()` lineage mapping, and original ticker fallback.
- How Market Value (MV) is calculated at the position level and aggregated at the company level.
- How incl-cash and ex-cash weights are computed and how cash affects aggregate weights.
- The relationship between stock-level and issuer-level grouping strategies and why Runbook Level influences display but not aggregation.
- Special handling for Thai foreign-line positions.
- Concrete examples of combining multiple securities from the same company.
- Performance considerations for large portfolios and optimization strategies for repeated aggregations.

## Project Structure
The relevant implementation lives under the ETF Capping Monitor project:

- `etf_capping/engine.py`: Pure-Pandas weighting, company mapping attachment, and company-group aggregation.
- `etf_capping/data.py`: BQL data retrieval, reference caching, Thai pricing resolution, and price loading.
- `etf_capping/app.py`: UI documentation, column wiring, and business rules exposed to users.
- `tests/test_engine.py`: Contract tests validating exception priority, MV aggregation, and weight behavior.
- RAG knowledge base documents record HelpDesk decisions, rejected alternatives, and Thai pricing policy.

```mermaid
graph TB
DataLayer["data.py<br/>BQL retrieval, Thai pricing, prices"] --> EngineLayer["engine.py<br/>Position values, weights, company mapping, aggregation"]
EngineLayer --> AppLayer["app.py<br/>UI, documentation, column rendering"]
Tests["tests/test_engine.py<br/>Aggregation and weight tests"] --> EngineLayer
Knowledge["RAG KB<br/>Thai pricing and field migration decisions"] --> DataLayer
Knowledge --> EngineLayer
```

**Diagram sources**
- [engine.py:1-685](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L1-L685)
- [data.py:1-1379](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1-L1379)
- [app.py:531-600](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L531-L600)
- [test_engine.py:260-302](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L260-L302)

**Section sources**
- [engine.py:1-685](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L1-L685)
- [data.py:1-1379](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1-L1379)
- [app.py:531-600](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L531-L600)

## Core Components
The aggregation pipeline has four main stages:

1. **Position normalization and asset classification**: AIM tickers are classified as Equity, Cash, FFX, Index Future, or Others.
2. **Position-level MV and security weight calculation**: `Quantity × Price USD` becomes Position MV; security weight divides Position MV by Account Total MV.
3. **Company identity attachment**: Exception override → `fundamentalticker()` → original ticker fallback.
4. **Company-group aggregation**: Summing MV by `(AIM Code, Parent/Issuer Ticker)` and computing incl-cash and ex-cash weights.

Key responsibilities:

| Component | Responsibility |
|---|---|
| `data.fetch_monitor_payload` | Loads AIM positions, descriptors, fundamental mappings, Thai pricing candidates, DRSK leftovers, and USD prices. |
| `engine.calculate_monitor` | Orchestrates validation, runbook attachment, position MV, security weights, company mapping, and company aggregation. |
| `_attach_company_mapping` | Resolves company key with exception priority and records diagnostics. |
| `_group_positions` | Computes group MV, incl-cash/ex-cash weights, rank, dynamic limit, observed weight, headroom, utilization, and capping status. |

**Section sources**
- [data.py:1168-1379](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1379)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)

## Architecture Overview
The end-to-end flow starts with raw AIM positions and ends with issuer-level groups that can be ranked against capping limits.

```mermaid
sequenceDiagram
participant User as "Monitor User"
participant Data as "data.py"
participant Engine as "engine.py"
participant BQL as "Bloomberg BQL"
User->>Data : fetch_monitor_payload(position_mode, accounts)
Data->>BQL : Load AIM positions
Data->>BQL : Load Name, Market Status
Data->>BQL : Load fundamentalticker()
Data->>Data : Resolve Thai local pricing candidates
Data->>BQL : Load leftover Thai DRSK mappings
Data->>BQL : Load USD prices
Data-->>Engine : Normalized positions with Price USD, Fundamental Ticker, Pricing Ticker
Engine->>Engine : classify_asset, attach_runbook
Engine->>Engine : calculate_position_values
Engine->>Engine : calculate_security_weights
Engine->>Engine : attach_company_mapping
Engine->>Engine : group_positions
Engine-->>User : positions, groups, alerts, diagnostics
```

**Diagram sources**
- [data.py:1168-1379](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1379)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

## Detailed Component Analysis

### Company Key Resolution Process
The company key determines which securities belong to the same issuer for aggregation. The resolution order is strict:

1. **Exception override**: A reviewed hard override takes priority over every Bloomberg company mapping.
2. **Fundamental ticker**: If no exception exists, use the lineage-mapped `fundamentalticker()` company key.
3. **Original ticker fallback**: If neither override nor fundamental mapping is available, retain the original held ticker as the company key and emit a diagnostic.

Implementation details:

- Exception tickers are normalized to uppercase and validated for duplicates.
- `Parent/Issuer Ticker` is filled from exceptions first, then fundamental mapping, then original ticker.
- `Mapping Source` records whether the row came from Exception, Fundamental Ticker, or Original Ticker.
- For equity rows falling back to original ticker, a diagnostic is recorded.

```mermaid
flowchart TD
Start(["Row enters _attach_company_mapping"]) --> CheckOverride["Check reviewed exception override"]
CheckOverride --> |Found| UseOverride["Use Parent Ticker from exception"]
CheckOverride --> |Not found| CheckFundamental["Check Fundamental Ticker"]
CheckFundamental --> |Available| UseFundamental["Use lineage-mapped fundamental ticker"]
CheckFundamental --> |Not available| UseOriginal["Use original Ticker as company key"]
UseOriginal --> RecordFallback["Record Fundamental Ticker Fallback diagnostic"]
UseOverride --> AttachNames["Attach Parent/Issuer Name"]
UseFundamental --> AttachNames
AttachNames --> End(["Company key and names attached"])
```

**Diagram sources**
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)

**Section sources**
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [app.py:546-567](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L546-L567)
- [test_engine.py:534-572](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L534-L572)

### MV Aggregation Calculations

#### Position-Level MV
Before company aggregation, each position gets its own market value:

- `Position MV = Quantity × Price USD`
- Index Future and FFX positions have their MV explicitly set to zero.
- Missing or invalid quantity and price produce diagnostics and zero MV so sibling holdings still weight correctly.
- Account Total MV is the sum of all Position MV across the account.
- Security Weight is `Position MV / Account Total MV`.

#### Company-Level MV and Weights
After company key attachment, positions are grouped by `(AIM Code, Parent/Issuer Ticker)`:

- `Company MV = Σ Position MV for the same AIM Code and company key`
- `Agg Wgt (incl cash) = Company MV / Account Total MV`
- `Agg Wgt (ex cash) = Company MV / Total Equity MV`
- `Total Equity MV` is the sum of Position MV where `Asset == Equity`, excluding cash, FFX, Index Future, and others.

Cash positions affect the denominator differently:

- Incl-cash weight uses the full account total, so cash reduces the relative weight of equities.
- Ex-cash weight uses only equity MV, so cash does not dilute equity exposure.
- Observed Weight is the maximum of incl-cash and ex-cash weights, making the monitor conservative when cash changes the ranking.

```mermaid
flowchart TD
Positions["Positions with Quantity and Price USD"] --> CalcMV["Calculate Position MV"]
CalcMV --> ZeroSpecial["Set Index Future and FFX MV to 0"]
ZeroSpecial --> AccountTotal["Compute Account Total MV"]
AccountTotal --> SecurityWeight["Compute Security Weight"]
SecurityWeight --> CompanyKey["Attach Parent/Issuer Ticker"]
CompanyKey --> GroupMV["Group by AIM Code + Company Key"]
GroupMV --> InclCash["Agg Wgt incl cash = Group MV / Account Total MV"]
GroupMV --> ExCash["Agg Wgt ex cash = Group MV / Total Equity MV"]
InclCash --> Observed["Observed Weight = max(incl cash, ex cash)"]
ExCash --> Observed
```

**Diagram sources**
- [engine.py:233-400](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L400)
- [engine.py:407-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L440)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)

**Section sources**
- [engine.py:233-400](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L400)
- [engine.py:407-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L440)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [app.py:531-567](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L531-L567)

### Stock-Level vs Issuer-Level Grouping Strategy
The system distinguishes between:

- **Stock-level grouping**: Individual holdings keep their original AIM ticker, quantity, price, and security weight.
- **Issuer-level grouping**: Multiple listings from the same company are consolidated using the resolved company key.

Runbook Level (`Stock` or `Issuer`) is displayed but does not change the aggregation method. The same reviewed company key is used for final aggregation regardless of Level. Level is carried into the output and used for display context, not for selecting a different grouping strategy.

```mermaid
classDiagram
class Position {
+string AIM_Code
+string Ticker
+number Quantity
+number Price_USD
+string Asset
+number Market_Value_USD
+number Weight
+string Parent_Issuer_Ticker
+number Agg_Wgt_Incl_Cash
+number Agg_Wgt_Ex_Cash
}
class CompanyGroup {
+string AIM_Code
+string Parent_Issuer_Ticker
+number Market_Value_USD
+number Agg_Wgt_Incl_Cash
+number Agg_Wgt_Ex_Cash
+number Rank
+number Dynamic_Limit
+number Observed_Weight
+string Capping_Status
}
Position --> CompanyGroup : "aggregated by AIM Code + Parent/Issuer Ticker"
```

**Diagram sources**
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)

**Section sources**
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [app.py:563-567](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L563-L567)

### Thai Foreign-Line Positions
Thai foreign-line positions use special pricing logic without changing the company key:

- Original AIM tickers ending `/F TB Equity` or `-R TB Equity` are detected.
- The original ticker and quantity are preserved.
- Local Thai pricing candidates are built from:
  1. Reviewed `THAI_PRICING_RULES` override.
  2. Deterministic removal of `/F` or `-R`.
- The candidate must:
  - End in `TB Equity`.
  - Not contain `/F`.
  - Not itself be a `-R` line.
  - Return usable reference data (`Name` or `Market Status`).
  - Share the same non-empty fundamental mapping as the original.
- Leftover unresolved Thai foreign lines may use HelpDesk-confirmed `bb_default_risk_obligor_ticker()` only as a Pricing Ticker identity.
- The company key remains Exception → `fundamentalticker()` → original ticker; DRSK is never used as the company key.

```mermaid
flowchart TD
Start(["Thai foreign-line detected"]) --> Override["Check approved Thai pricing override"]
Override --> |Valid| UseOverride["Use approved local Thai ticker"]
Override --> |Invalid or missing| Strip["Strip /F or -R deterministically"]
Strip --> ValidateCandidate{"Candidate valid and same fundamental?"}
ValidateCandidate --> |Yes| UseStrip["Use validated strip"]
ValidateCandidate --> |No| Drsk["Leftover HelpDesk DRSK mapping"]
Drsk --> DrskValid{"DRSK returns local TB Equity with reference data?"}
DrskValid --> |Yes| UseDrsk["Use DRSK as Pricing Ticker only"]
DrskValid --> |No| Unresolved["Leave Pricing Ticker empty and record diagnostic"]
UseOverride --> PricingOnly["Pricing Ticker only; company key unchanged"]
UseStrip --> PricingOnly
UseDrsk --> PricingOnly
Unresolved --> PricingOnly
```

**Diagram sources**
- [data.py:373-412](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L373-L412)
- [data.py:599-704](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L704)
- [data.py:701-804](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L701-L804)
- [24-etf-field-migration-incident.md:216-252](file://RAG KB/24-etf-field-migration-incident.md#L216-L252)
- [23-bql-substitution-due-diligence.md:253-281](file://RAG KB/23-bql-substitution-due-diligence.md#L253-L281)

**Section sources**
- [data.py:373-412](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L373-L412)
- [data.py:599-704](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L704)
- [data.py:701-804](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L701-L804)
- [data.py:1230-1260](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1230-L1260)
- [24-etf-field-migration-incident.md:216-252](file://RAG KB/24-etf-field-migration-incident.md#L216-L252)
- [23-bql-substitution-due-diligence.md:253-281](file://RAG KB/23-bql-substitution-due-diligence.md#L253-L281)

### Concrete Examples

#### Example 1: Combining Multiple Securities from the Same Company
Suppose an account holds:

| Ticker | Quantity | Price USD | Fundamental Ticker |
|---|---:|---:|---|
| SKM US Equity | 30 | 1 | DIFFERENT US |
| 017670 KS Equity | 20 | 1 | ANOTHER KS |
| USD Curncy | 950 | 1 | — |

With an exception mapping both SKM US Equity and 017670 KS Equity to parent `034730 KS Equity`, the two equity positions combine into one issuer group. The test validates that the exception override has priority over the fundamental ticker and that cash is included in the account total while equity-only exposure drives ex-cash weight.

Result interpretation:

- Both equity listings map to the same parent.
- Their MVs are summed into one company group.
- Incl-cash weight includes USD cash in the denominator.
- Ex-cash weight excludes USD cash from the denominator.
- The test asserts listing count, incl-cash weight, ex-cash weight, rank, dynamic limit, and capping status.

**Section sources**
- [test_engine.py:534-572](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L534-L572)
- [test_engine.py:260-267](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L260-L267)

#### Example 2: Impact of Cash on Aggregate Weights
If a portfolio contains:

- Two equity positions from the same company with combined MV equal to part of the account.
- A large USD cash balance.

Then:

- `Agg Wgt (incl cash)` will be lower because cash increases the account total denominator.
- `Agg Wgt (ex cash)` will be higher because cash is excluded from the equity-only denominator.
- `Observed Weight` takes the larger of the two, so cash can make the monitor more conservative about near-limit or breach status.

**Section sources**
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [app.py:558-567](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L558-L567)
- [test_engine.py:479-502](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L479-L502)

## Dependency Analysis
The aggregation logic depends on clean inputs from the data layer and produces outputs consumed by the UI and alerting logic.

```mermaid
graph LR
RawPositions["Raw AIM Positions"] --> DataFetch["data.fetch_monitor_payload"]
DataFetch --> Descriptors["Name, Market Status"]
DataFetch --> Fundamentals["Fundamental Ticker"]
DataFetch --> ThaiPricing["Thai Local Pricing Ticker"]
DataFetch --> Prices["Price USD"]
Descriptors --> EngineCalc["engine.calculate_monitor"]
Fundamentals --> EngineCalc
ThaiPricing --> EngineCalc
Prices --> EngineCalc
EngineCalc --> PositionsOut["Position-level results"]
EngineCalc --> GroupsOut["Company-group results"]
GroupsOut --> Alerts["Alerts and Monitor views"]
```

**Diagram sources**
- [data.py:1168-1379](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1379)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

**Section sources**
- [data.py:1168-1379](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1168-L1379)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

## Performance Considerations
Large portfolios benefit from batching, caching, and avoiding unnecessary BQL calls:

- **Batched requests**: Positions, descriptors, fundamental tickers, prices, and DRSK mappings are requested in chunks controlled by `SECURITY_BATCH` and `AIM_ACCOUNT_BATCH`.
- **Reference caching**: Descriptors and fundamental mappings are merged into a single cache to avoid duplicate lookups.
- **Filtered universes**: Fundamental tickers are requested only for equity tickers; Thai pricing candidates are derived before requesting extra reference data.
- **Leftover DRSK scope**: `bb_default_risk_obligor_ticker()` is called only for unresolved Thai foreign lines, not for mixed HK/US/cash/index universes.
- **Cached mode**: Fundamental ticker and name requests use `mode="cached"` where appropriate.
- **Duplicate handling**: Responses deduplicate by ID or ticker, keeping the last value to stabilize repeated runs.

Optimization strategies for repeated aggregations:

1. **Reuse normalized positions**: If the underlying AIM book has not changed, reuse the payload returned by `fetch_monitor_payload`.
2. **Cache exceptions and runbook**: Pass preloaded `exceptions` and `runbook` frames to `calculate_monitor` instead of reloading them.
3. **Avoid recomputing company mapping**: If only weights or display filters change, reuse the engine result rather than re-fetching BQL data.
4. **Limit account scope**: Filter to active accounts before calling the data layer.
5. **Separate heavy I/O from pure Pandas math**: Keep BQL calls in `data.py` and keep aggregation logic in `engine.py`.

**Section sources**
- [data.py:48-50](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L48-L50)
- [data.py:534-596](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L534-L596)
- [data.py:701-764](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L701-L764)
- [data.py:819-866](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L819-L866)
- [data.py:1200-1260](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1200-L1260)

## Troubleshooting Guide

### Common Diagnostics
| Diagnostic Category | Meaning | Typical Cause |
|---|---|---|
| Fundamental Ticker Fallback | Original ticker was used as company key | No exception and no fundamental mapping |
| Zero Price Market Status | Price and MV were set to zero | Expected market status with no Bloomberg price |
| Thai Pricing Unresolved | No verified local Thai pricing ticker was available | Override failed, strip failed, and DRSK did not resolve |
| Reference Data Missing | Neither Name nor Market Status was available | Incomplete reference data for equity |
| Missing Quantity | Position MV was set to zero | Non-numeric AIM quantity |
| Missing Price | Position MV was set to zero | USD price unavailable for non-zero position |
| Zero Denominator | Weights cannot be calculated | Account Total MV is zero |
| Account Incomplete | At least one required input is missing | Missing runbook, quantity, price, or reference data |

**Section sources**
- [engine.py:103-115](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L103-L115)
- [engine.py:215-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L215-L230)
- [engine.py:272-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L272-L399)
- [engine.py:416-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L416-L440)

### Validation Checklist
- Confirm exception tickers are unique and non-blank.
- Verify that reviewed Thai pricing overrides return valid local `TB Equity` references.
- Ensure DRSK is used only for leftover Thai foreign lines and not as a general company mapper.
- Check that `fundamentalticker()` is used for company identity, not as a Pricing Ticker.
- Inspect `Mapping Source` to understand whether aggregation used Exception, Fundamental Ticker, or Original Ticker.
- Compare `Agg Wgt (incl cash)` and `Agg Wgt (ex cash)` to understand cash impact.
- Review `Capping Status` and `Status` to distinguish Breach/Near Limit from Data Issue.

**Section sources**
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [data.py:599-704](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L704)
- [24-etf-field-migration-incident.md:169-188](file://RAG KB/24-etf-field-migration-incident.md#L169-L188)
- [23-bql-substitution-due-diligence.md:253-303](file://RAG KB/23-bql-substitution-due-diligence.md#L253-L303)

## Conclusion
The company group aggregation logic prioritizes human-reviewed control over automated mapping:

- Exception overrides take absolute priority.
- `fundamentalticker()` provides the default issuer identity.
- Original ticker fallback preserves safety when mapping is unavailable.
- MV aggregation sums all positions sharing the same company key.
- Incl-cash and ex-cash weights provide complementary views of exposure, with cash affecting denominators differently.
- Thai foreign-line pricing is handled carefully as a pricing identity issue, not a company-key issue.
- Runbook Level is a display attribute, not a grouping switch.
- Batched BQL calls, reference caching, and filtered request scopes keep the pipeline efficient for large portfolios.