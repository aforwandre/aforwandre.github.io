# User Interface Components and Interactions

<cite>
**Referenced Files in This Document**
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [main.ipynb](file://User scripts/ETF Capping Monitoring/main.ipynb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the interactive user interface built for ETF position capping monitoring using `ipywidgets` and `IPyDataGrid`. The dashboard provides seven main tabs: Monitor, Full Positions, Account Summary, Runbook, Exceptions, Diagnostics, and Documentation. It is designed for Bloomberg BQuant Desktop users who need to monitor fund-level capping breaches, inspect full security positions, review account summaries, and investigate data-quality issues.

The interface follows a strict interaction model: BQL requests run only when the user clicks Update. Dropdown filters, text search, Primary FM filtering, and advanced column filters are local operations that do not re-run BQL. Real-time updates are triggered by the Update button, while live partial-name search and dropdown changes refresh the displayed tables locally.

## Project Structure
The dashboard is implemented as a stateful Python class inside the ETF Capping Monitoring application. The notebook entry point imports the class and displays its rendered widget container.

```mermaid
graph TB
Notebook["main.ipynb"] --> AppClass["ETFCappingMonitor<br/>app.py"]
AppClass --> DataLayer["fetch_monitor_payload<br/>data.py"]
AppClass --> Engine["calculate_monitor<br/>engine.py"]
AppClass --> Config["account_rules_frame / exception_rules_frame / thai_pricing_rules_frame<br/>config.py"]
AppClass --> Grid["IPyDataGrid<br/>ipydatagrid"]
AppClass --> Plotly["Plotly FigureWidget<br/>plotly.graph_objects"]
```

**Diagram sources**
- [main.ipynb:19-25](file://User scripts/ETF Capping Monitoring/main.ipynb#L19-L25)
- [app.py:13-24](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L13-L24)
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)
- [data.py:16-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L16-L23)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)

**Section sources**
- [main.ipynb:1-45](file://User scripts/ETF Capping Monitoring/main.ipynb#L1-L45)
- [app.py:701-970](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L970)

## Core Components
The primary component is the `ETFCappingMonitor` class. It owns all widgets, caches results, binds event handlers, and renders the tabbed dashboard. Key responsibilities include:

- Building the top control bar with AIM Position mode, Update button, Account filter, Status filter, Find text box, and Primary FM filter.
- Rendering seven tabs through an `ipywidgets.Tab`.
- Managing a cached result object returned by the engine.
- Filtering and rendering IPyDataGrid tables for Monitor, Full Positions, Account Summary, Runbook, Exceptions, and Diagnostics.
- Rendering documentation HTML in the Documentation tab.
- Exporting current table contents to UTF-8 CSV files in project Files.

```mermaid
classDiagram
class ETFCappingMonitor {
-bool _events_bound
-bool _loading
-bool _fixing_filter
-MonitorResult _result
-list _request_errors
-DataFrame _visible_groups
-DataFrame _summary_frame
-DataFrame _full_positions_cache
-tuple _selected_key
+__init__()
+render()
+load_on_start()
-_build_widgets()
-_bind_events()
-_render_static_tabs()
-_refresh()
-_render_all()
-_render_monitor()
-_render_full_positions()
-_render_summary()
-_render_diagnostics()
-_on_update()
-_on_local_filter()
-_on_full_positions_filter()
-_on_export_csv()
}
```

**Diagram sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:999-1004](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L999-L1004)
- [app.py:1183-1365](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1183-L1365)

**Section sources**
- [app.py:701-970](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L970)
- [app.py:972-1004](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L972-L1004)

## Architecture Overview
The dashboard separates UI logic from data retrieval and calculation logic.

- UI layer: `ETFCappingMonitor` builds widgets, handles events, formats display values, and renders IPyDataGrid tables.
- Data layer: `fetch_monitor_payload` retrieves AIM positions, descriptors, fundamental tickers, Thai pricing mappings, and USD prices through BQL.
- Engine layer: `calculate_monitor` performs pure-Pandas calculations for asset classification, position valuation, company aggregation, ranking, dynamic limits, and alert status.
- Configuration layer: static runbook rules, exception overrides, Thai pricing overrides, status colors, warning thresholds, and Primary FM mapping.

```mermaid
sequenceDiagram
participant User as "User"
participant UI as "ETFCappingMonitor"
participant Data as "fetch_monitor_payload"
participant Engine as "calculate_monitor"
participant Grid as "IPyDataGrid"
participant Plotly as "FigureWidget"
User->>UI : Click Update
UI->>UI : Disable button, set loading status
UI->>Data : fetch_monitor_payload(mode)
Data-->>UI : MonitorPayload(positions, errors)
UI->>Engine : calculate_monitor(positions, mode)
Engine-->>UI : MonitorResult(groups, positions, alerts, diagnostics)
UI->>UI : Render cards, Monitor, Full Positions, Summary, Diagnostics
UI->>Grid : Render IPyDataGrid tables
UI->>Plotly : Render detail chart
UI->>UI : Re-enable button, update title/status
```

**Diagram sources**
- [app.py:1183-1365](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1183-L1365)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

## Detailed Component Analysis

### Dashboard Tabs

| Tab | Purpose | Main Widgets | Interaction Model |
|---|---|---|---|
| Monitor | High company weights for capping monitoring | IPyDataGrid, alert chips, detail header, detail chart, listing grid | Local filters; row click opens selected holdings breakdown |
| Full Positions | All security-level rows | Fund dropdown, NAME search, Primary FM dropdown, advanced column filters, IPyDataGrid | Live NAME search; dropdown and advanced filters applied locally |
| Account Summary | One-row-per-account alert and data-quality summary | IPyDataGrid | Row click navigates to Monitor with account preselected |
| Runbook | Read-only 54-account limits, levels, and price types | IPyDataGrid | No runtime calculation; static view |
| Exceptions | Hard overrides and Thai local-pricing overrides | Two IPyDataGrid tables | No runtime calculation; static view |
| Diagnostics | Request, mapping, reference, price, and calculation issues | IPyDataGrid | Populated after Update; exportable |
| Documentation | Implemented-logic reference | HTML widget | Read-only; does not run BQL |

**Section sources**
- [app.py:897-919](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L897-L919)
- [app.py:274-687](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L274-L687)

### Widget Interactions

#### Dropdown Filters
- **AIM Position**: Current or Projected. Changing this clears previous results and prompts the user to click Update.
- **Account**: Dynamically populated from the latest result. Supports “All Accounts” and individual AIM accounts.
- **Show**: Alerts, Breach, Near Limit, Data Issue, All. Controls which company groups appear in the Monitor table.
- **Primary FM**: Derived from the bundled runbook. Available in both Monitor and Full Positions.

These dropdowns bind to `_on_local_filter` for Monitor and `_on_full_positions_filter` for Full Positions. They do not trigger BQL calls.

**Section sources**
- [app.py:725-787](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L725-L787)
- [app.py:972-997](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L972-L997)
- [app.py:1186-1204](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1186-L1204)

#### Search Functionality
- **Find (Monitor)**: Searches across AIM Code, Fund Name, Parent/Issuer Ticker, Parent/Issuer Name, and Listing Tickers. Case-insensitive substring match.
- **NAME (Full Positions)**: Partial keyword search against the security name column. Uses `continuous_update=True`, so it refreshes the table as the user types.

**Section sources**
- [app.py:753-780](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L753-L780)
- [app.py:1452-1469](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1452-L1469)
- [app.py:1743-1765](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1743-L1765)

#### Advanced Filtering for Full Positions
Advanced Column Filters provide per-column expressions for remaining columns not exposed in the top-level controls.

- Text columns support case-insensitive contains matches.
- Numeric columns accept operators: `=`, `==`, `!=`, `>`, `>=`, `<`, `<=`.
- Percentage columns accept `%` suffix input.
- Blank matching supports `<blank>` or `(blank)` for missing values.
- Multiple filters combine with AND.
- Apply Filters and Clear Filters buttons manage state without rerunning BQL.

```mermaid
flowchart TD
Start(["Apply Advanced Filter"]) --> GetColumns["Read active column filters"]
GetColumns --> ForEachColumn{"For each non-empty filter"}
ForEachColumn --> IsNumeric{"Is numeric column?"}
IsNumeric --> |No| TextMatch["Case-insensitive contains match"]
IsNumeric --> |Yes| ParseQuery["Parse operator, value, optional %"]
ParseQuery --> PercentCheck{"% used on percentage column?"}
PercentCheck --> |No| NumericOp["Apply numeric comparison"]
PercentCheck --> |Yes| NormalizePercent["Divide target by 100"]
NormalizePercent --> NumericOp
TextMatch --> Combine["Combine masks with AND"]
NumericOp --> Combine
Combine --> ApplyMask["Apply mask to frame"]
ApplyMask --> UpdateSummary["Update filter summary and shown count"]
UpdateSummary --> End(["Render filtered IPyDataGrid"])
```

**Diagram sources**
- [app.py:1006-1085](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1006-L1085)
- [app.py:1684-1765](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1684-L1765)

**Section sources**
- [app.py:1006-1085](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1006-L1085)
- [app.py:1684-1786](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1684-L1786)

#### Real-Time Updates Triggered by Update
The Update button is the single entry point for BQL execution. Its flow:

1. Prevents duplicate runs via `_loading`.
2. Disables the button and sets a loading status message.
3. Logs the start time and parser version.
4. Calls `fetch_monitor_payload` with the selected AIM Position mode.
5. Validates that positions were returned.
6. Calls `calculate_monitor` to compute groups, alerts, and diagnostics.
7. Updates account options, clears selection state, and renders all tabs.
8. Sets success or error headers and status messages.

```mermaid
sequenceDiagram
participant Button as "Update Button"
participant Monitor as "ETFCappingMonitor._refresh"
participant Data as "fetch_monitor_payload"
participant Engine as "calculate_monitor"
Button->>Monitor : on_click
Monitor->>Monitor : Set _loading = True
Monitor->>Monitor : Disable button
Monitor->>Data : Fetch positions and metadata
Data-->>Monitor : MonitorPayload
Monitor->>Engine : Calculate monitor result
Engine-->>Monitor : MonitorResult
Monitor->>Monitor : Render all tabs
Monitor->>Monitor : Set _loading = False
Monitor->>Button : Re-enable button
```

**Diagram sources**
- [app.py:1183-1184](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1183-L1184)
- [app.py:1289-1365](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1289-L1365)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

**Section sources**
- [app.py:1183-1365](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1183-L1365)

### Responsive Design Elements

#### Color-Coded Status Indicators
Status values are color-coded consistently across the dashboard:

| Status | Meaning | Typical Use |
|---|---|---|
| Breach | Observed weight at or above dynamic limit | Monitor Status, Account Summary, header cards |
| Near Limit | Observed weight at or above 98% of dynamic limit | Monitor Status, Account Summary, header cards |
| OK | Within normal range | Background default |
| Data Issue | Missing required input, incomplete account, or zero total market value | Monitor Status, Account Summary, Diagnostics |

The configuration defines `STATUS_COLORS`, and the renderer applies Vega expression-based text and background colors where supported.

**Section sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [app.py:157-159](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L157-L159)
- [app.py:235-254](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L235-L254)

#### Formatted Number Displays
Number formatting is handled through IPyDataGrid renderers and helper functions:

- Percentages use `.2%` or `.4%` depending on context.
- Quantities and market values use thousands separators.
- USD Price uses six decimal places in Full Positions.
- Rank is formatted as an integer.
- Dates are formatted as `YYYY-MM-DD`.

**Section sources**
- [app.py:72-95](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L72-L95)
- [app.py:1788-1816](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1788-L1816)
- [app.py:2480-2483](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2480-L2483)

#### Vega Expression-Based Row Coloring
The dashboard attempts to use Vega expressions for efficient row coloring. If Vega is unavailable or the generated expression exceeds the size limit, it falls back to IPyDataGrid’s `Expr` syntax. If both fail, row coloring is disabled rather than breaking the table.

Key behaviors:

- Monitor weight cells use tone-based coloring: Breach, Near Limit, or OK.
- Status cells use Vega expressions for text color and background color.
- Fallback paths ensure robustness when `VegaExpr` or `Expr` is unavailable.

```mermaid
flowchart TD
Start(["Build row color source"]) --> CheckTones{"Tones available?"}
CheckTones --> |No| ReturnNone["Return None"]
CheckTones --> |Yes| BuildVega["Build Vega tree expression"]
BuildVega --> VegaSize{"Within size limit?"}
VegaSize --> |No| BuildPython["Build Python Expr fallback"]
VegaSize --> |Yes| TryVega["Try VegaExpr(source)"]
TryVega --> VegaSuccess{"VegaExpr succeeded?"}
VegaSuccess --> |Yes| ReturnVega["Return VegaExpr"]
VegaSuccess --> |No| BuildPython
BuildPython --> PythonSize{"Within size limit?"}
PythonSize --> |No| ReturnNone
PythonSize --> |Yes| TryExpr["Try Expr(python_source)"]
TryExpr --> ExprSuccess{"Expr succeeded?"}
ExprSuccess --> |Yes| ReturnExpr["Return Expr"]
ExprSuccess --> |No| ReturnNone
```

**Diagram sources**
- [app.py:181-232](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L181-L232)

**Section sources**
- [app.py:181-232](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L181-L232)
- [app.py:235-271](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L235-L271)

### Common User Workflows

#### Monitoring Breaches
1. Select Current or Projected.
2. Click Update.
3. Review the top cards for Breaches and Near Limit counts.
4. Use Show to filter to Alerts, Breach, Near Limit, or Data Issue.
5. Use Find to narrow by fund, AIM code, company, or ticker.
6. Use Primary FM to focus on a specific portfolio manager.
7. Click an alert chip to jump directly to the affected account and company.
8. Click a Monitor row to open the holding contribution chart and listing breakdown.

**Section sources**
- [app.py:1478-1543](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1478-L1543)
- [app.py:1916-1977](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1916-L1977)
- [app.py:1979-2078](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1979-L2078)

#### Analyzing Full Positions
1. After Update, switch to Full Positions.
2. Select a Fund from the dropdown.
3. Type into NAME to perform a live partial-name search.
4. Use Primary FM to filter by portfolio manager.
5. Expand Advanced Column Filters to apply additional conditions.
6. Review the shown-count summary indicating how many rows remain.
7. Export the filtered table to CSV if needed.

**Section sources**
- [app.py:845-881](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L845-L881)
- [app.py:1585-1682](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1585-L1682)
- [app.py:1743-1891](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1743-L1891)

#### Exporting Data
Each tab has an Export CSV button. Exports save UTF-8 CSV files into project Files.

- Monitor exports the currently visible Monitor table.
- Full Positions exports the fully filtered Full Positions table.
- Account Summary exports the one-row-per-account summary.
- Runbook exports the bundled runbook.
- Exceptions exports hard exceptions and Thai pricing overrides.
- Diagnostics exports recorded diagnostics.

Exports do not refresh BQL.

**Section sources**
- [app.py:1087-1181](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1087-L1181)
- [app.py:1106-1147](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1106-L1147)

## Dependency Analysis
The UI depends on three supporting layers:

- `data.py`: Builds BQL requests, batches them, parses responses, resolves Thai foreign-line pricing, and returns normalized positions.
- `engine.py`: Performs pandas-based calculations for asset classification, position valuation, company grouping, ranking, dynamic limits, and alert status.
- `config.py`: Provides static runbook rules, exception rules, Thai pricing overrides, status colors, warning ratio, batch sizes, and Primary FM mapping.

```mermaid
graph LR
UI["ETFCappingMonitor<br/>app.py"] --> DATA["BQL payload builder<br/>data.py"]
UI --> ENGINE["Pandas calculations<br/>engine.py"]
UI --> CONFIG["Static rules and colors<br/>config.py"]
DATA --> CONFIG
ENGINE --> CONFIG
```

**Diagram sources**
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)
- [data.py:16-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L16-L23)
- [engine.py:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)
- [config.py:18-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L18-L23)

**Section sources**
- [app.py:26-39](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L39)
- [data.py:1-28](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L1-L28)
- [engine.py:1-13](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L1-L13)
- [config.py:1-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L23)

## Performance Considerations
The dashboard is optimized for large datasets through several mechanisms:

- **BQL runs only on Update**: Dropdowns, search, tab switches, and CSV exports are local operations.
- **Result caching**: `_result`, `_visible_groups`, `_summary_frame`, and `_full_positions_cache` avoid recomputation during local filtering.
- **Batched BQL requests**: AIM accounts are requested in batches of eight; security descriptors and other items are batched in groups of 150.
- **Efficient IPyDataGrid rendering**: Tables use explicit renderers, column widths, dark theme renderers, and fixed base row sizes.
- **Vega expression optimization**: Row coloring prefers compact Vega trees and falls back gracefully when expressions are too large or unsupported.
- **Partial-name search**: NAME search uses substring matching on already loaded frames.
- **Conditional rendering**: Empty states and clear-result flows prevent stale data from being displayed after mode changes.

Virtual scrolling is not explicitly configured in the analyzed code. IPyDataGrid itself may provide virtualization depending on the environment, but the implementation focuses on result caching, batched requests, and efficient local filtering rather than custom virtual scroll logic.

**Section sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:1289-1365](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1289-L1365)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:493-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L493-L531)
- [app.py:1494-1531](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1494-L1531)
- [app.py:1862-1891](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1862-L1891)
- [app.py:181-232](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L181-L232)

## Troubleshooting Guide

### Update Does Nothing
- Verify that the kernel is running on Bloomberg BQuant Desktop.
- Confirm that AIM entitlements exist for the selected accounts.
- Check the log area for request notes or errors.
- Ensure the AIM Position dropdown is set before clicking Update.

**Section sources**
- [data.py:40-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L40-L45)
- [app.py:1289-1365](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1289-L1365)

### No Rows in Monitor
- Change Show to All to verify whether any equity groups exist.
- Clear Find and Primary FM filters.
- Switch between Alerts, Breach, Near Limit, and Data Issue.
- Check Diagnostics for Account Incomplete or Missing Runbook entries.

**Section sources**
- [app.py:1439-1476](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1439-L1476)
- [engine.py:642-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L642-L684)

### Full Positions Shows No Matches
- Confirm that Update has been run.
- Try selecting All Funds.
- Clear NAME search and advanced column filters.
- Use Clear Filters to reset advanced column inputs.

**Section sources**
- [app.py:1844-1891](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1844-L1891)
- [app.py:1206-1223](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1206-L1223)

### CSV Export Fails
- Check whether the tab has data to export.
- Verify that project Files is writable.
- Review the status message next to the Export CSV button.
- Check the log area for the exception type and message.

**Section sources**
- [app.py:1149-1181](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L1149-L1181)

### Diagnostics Shows Data Issues
- Review Diagnostics for categories such as Missing Quantity, Missing Price, Zero Price Market Status, Thai Pricing Unresolved, Reference Data Missing, and Account Incomplete.
- Do not assume a Data Issue means every row is invalid; breach and near-limit names can still appear on Monitor alerts.
- Investigate the underlying cause in Diagnostics before changing filters.

**Section sources**
- [engine.py:321-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L321-L399)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [app.py:2576-2605](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2576-L2605)

## Conclusion
The ETF Capping Monitoring dashboard provides a structured, interactive workflow for monitoring fund-level capping limits, inspecting full positions, reviewing account summaries, and diagnosing data-quality problems. Its architecture cleanly separates UI interactions from BQL data retrieval and pandas-based calculations. The most important operational rule is that BQL runs only when Update is clicked; all dropdowns, searches, and advanced filters are local optimizations. The interface emphasizes readable status indicators, consistent number formatting, robust Vega expression fallbacks, and exportable outputs suitable for further analysis outside the notebook.