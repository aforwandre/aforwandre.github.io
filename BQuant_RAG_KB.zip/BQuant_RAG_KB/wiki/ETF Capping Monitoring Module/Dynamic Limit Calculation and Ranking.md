# Dynamic Limit Calculation and Ranking

<cite>
**Referenced Files in This Document**
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [test_engine.py](file://User scripts/ETF Capping Monitoring/tests/test_engine.py)
- [25-etf-capping-monitor.md](file://RAG KB/25-etf-capping-monitor.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the dynamic limit calculation and ranking system used by the ETF Capping Monitoring application. The system ranks company groups within each account, selects a dynamic limit based on rank and runbook configuration, computes observed exposure from both including-cash and excluding-cash weights, and derives headroom, utilization ratio, and alert status. It also documents how data quality issues interact with breach and near-limit conditions, how rounding and display formatting are handled, and how the implementation is optimized for large datasets.

## Project Structure
The dynamic limit logic lives primarily in the ETF Capping Monitoring package:
- `engine.py` implements pure-Pandas position weighting, aggregation, ranking, dynamic limit selection, headroom/utilization computation, status determination, and alert filtering.
- `config.py` defines the warning threshold, account runbook, exception rules, and display colors.
- `app.py` renders the user interface, formats percent strings, applies color coding, and exposes helper functions that depend on engine outputs.
- `test_engine.py` validates ranking behavior, limit selection, status thresholds, data-quality handling, and UI formatting contracts.
- `25-etf-capping-monitor.md` documents the intended Excel-equivalent behavior for dynamic limits, ranking, and status.

```mermaid
graph TB
Engine["engine.py<br/>Position processing, ranking,<br/>dynamic limit, status"]
Config["config.py<br/>WARNING_RATIO,<br/>runbook, exceptions"]
App["app.py<br/>UI rendering,<br/>percent formatting,<br/>color helpers"]
Tests["test_engine.py<br/>Ranking, limits,<br/>status, display tests"]
KB["25-etf-capping-monitor.md<br/>Excel parity rules"]
Config --> Engine
Engine --> App
Tests --> Engine
KB --> Engine
KB --> App
```

**Diagram sources**
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [app.py:2300-2499](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2300-L2499)
- [test_engine.py:319-493](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L493)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)

**Section sources**
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [app.py:2300-2499](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2300-L2499)
- [test_engine.py:319-493](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L493)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)

## Core Components
The core components are:
- Position normalization and market value calculation.
- Security-level weight computation.
- Company grouping across multiple listings.
- Rank-based dynamic limit selection.
- Observed weight derivation from incl-cash and ex-cash aggregates.
- Headroom and utilization ratio calculation.
- Status determination: Breach, Near Limit, OK, Data Issue.
- Alert selection with Rank 1 context preservation.

Key behaviors:
- Rank 1 uses the Largest limit when present; all other ranks use Capping.
- Observed Weight equals the maximum of Agg Wgt (incl cash) and Agg Wgt (ex cash).
- Non-equity rows are forced to OK for capping status but may still show Data Issue at the account level.
- WARNING_RATIO is 0.98, making ≥98% of the dynamic limit Near Limit and ≥100% Breach.

**Section sources**
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [engine.py:618-684](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L618-L684)
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)

## Architecture Overview
The pipeline processes raw positions through several stages before producing monitor-ready groups and alerts.

```mermaid
flowchart TD
Start(["Raw Positions"]) --> Normalize["Normalize AIM/Ticker<br/>Classify Asset"]
Normalize --> Runbook["Attach Runbook<br/>Capping/Largest/Level/Type"]
Runbook --> Values["Calculate Market Value USD<br/>Handle Missing Prices"]
Values --> Weights["Compute Security Weight<br/>per Account Total"]
Weights --> Mapping["Attach Parent/Issuer Mapping<br/>Exceptions > Fundamental > Original"]
Mapping --> Group["Aggregate by Parent Ticker<br/>incl cash vs ex cash"]
Group --> Rank["Rank Groups by Agg Wgt (incl cash)"]
Rank --> Limit["Select Dynamic Limit:<br/>Rank 1 + Largest ? Largest : Capping"]
Limit --> Observed["Observed Weight = max(incl cash, ex cash)"]
Observed --> Metrics["Headroom = Dynamic Limit - Observed<br/>Utilisation = Observed / Dynamic Limit"]
Metrics --> Status["Status: Breach/Near Limit/OK/Data Issue"]
Status --> Alerts["Filter Alerts with Rank 1 Context"]
Alerts --> End(["Monitor Groups + Alerts"])
```

**Diagram sources**
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)

**Section sources**
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

## Detailed Component Analysis

### Rank-Based Limit Selection
- Every parent group in an account is ranked by Agg Wgt (incl cash), descending, using pandas rank with method="min".
- If Rank equals 1 and the Largest field is present, Dynamic Limit equals Largest; otherwise, Dynamic Limit equals Capping.
- This preserves legacy Excel behavior where cash and other assets participate in ranking even though only equity rows are shown in the final Monitor view.

```mermaid
flowchart TD
A["Grouped Parent Tickers"] --> B["Rank by Agg Wgt (incl cash)"]
B --> C{"Rank == 1 and Largest present?"}
C --> |Yes| D["Dynamic Limit = Largest"]
C --> |No| E["Dynamic Limit = Capping"]
```

**Diagram sources**
- [engine.py:505-514](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L505-L514)
- [25-etf-capping-monitor.md:258-261](file://RAG KB/25-etf-capping-monitor.md#L258-L261)

**Section sources**
- [engine.py:505-514](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L505-L514)
- [test_engine.py:319-357](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L357)
- [25-etf-capping-monitor.md:258-261](file://RAG KB/25-etf-capping-monitor.md#L258-L261)

### Observed Weight and Headroom
- Agg Wgt (incl cash) divides aggregated group market value by total account market value.
- Agg Wgt (ex cash) divides aggregated group market value by equity-only account market value.
- Observed Weight is the row-wise maximum of these two aggregates.
- Headroom equals Dynamic Limit minus Observed Weight.
- Utilization equals Observed Weight divided by Dynamic Limit, with safe division returning NaN for zero or missing denominators.

```mermaid
flowchart TD
A["Agg Wgt (incl cash)"] --> B["max(incl cash, ex cash)"]
C["Agg Wgt (ex cash)"] --> B
B --> D["Observed Weight"]
E["Dynamic Limit"] --> F["Headroom = Dynamic Limit - Observed Weight"]
D --> F
D --> G["Utilisation = Observed Weight / Dynamic Limit"]
E --> G
```

**Diagram sources**
- [engine.py:461-462](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L461-L462)
- [engine.py:515-521](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L515-L521)

**Section sources**
- [engine.py:461-462](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L461-L462)
- [engine.py:515-521](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L515-L521)

### Status Determination Logic
Status is determined in two layers:
1. Capping Status:
   - Breach if Observed Weight ≥ Dynamic Limit.
   - Near Limit if Observed Weight ≥ WARNING_RATIO × Dynamic Limit.
   - OK otherwise.
2. Final Status:
   - If Capping Status is not OK, Status equals Capping Status.
   - Otherwise, Status equals Data Quality, which is Data Issue when any required input is missing for the account.
   - Non-equity rows are forced to OK for Capping Status.

```mermaid
flowchart TD
A["Observed Weight"] --> B{"≥ Dynamic Limit?"}
B --> |Yes| C["Breach"]
B --> |No| D{"≥ 0.98 × Dynamic Limit?"}
D --> |Yes| E["Near Limit"]
D --> |No| F["OK"]
F --> G{"Is Equity?"}
G --> |No| H["Force Capping Status = OK"]
G --> |Yes| I["Keep OK"]
C --> J["Final Status = Capping Status"]
E --> J
H --> K["Final Status = Data Quality"]
I --> K
```

**Diagram sources**
- [engine.py:522-536](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L536)
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)

**Section sources**
- [engine.py:522-536](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L536)
- [25-etf-capping-monitor.md:265-269](file://RAG KB/25-etf-capping-monitor.md#L265-L269)

### Interaction Between Incl-Cash and Ex-Cash Weights
- Both Agg Wgt (incl cash) and Agg Wgt (ex cash) are computed per parent ticker.
- Observed Weight takes the larger of the two, ensuring the most conservative exposure measure is compared against the dynamic limit.
- In the UI, incl-cash and ex-cash columns are displayed as formatted percent strings, while their numeric values drive color tone calculations independently.
- When incl-cash is below the warning threshold but ex-cash exceeds it, the ex-cash cell can be flagged as Breach while incl-cash remains Near Limit or OK.

```mermaid
sequenceDiagram
participant Engine as "engine.py"
participant App as "app.py"
participant UI as "Monitor Grid"
Engine->>Engine : Compute Agg Wgt (incl cash)
Engine->>Engine : Compute Agg Wgt (ex cash)
Engine->>Engine : Observed Weight = max(incl, ex)
Engine->>App : Provide groups with incl/ex weights
App->>App : Format incl/ex as percent strings
App->>UI : Render cells with independent tone coloring
```

**Diagram sources**
- [engine.py:461-462](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L461-L462)
- [engine.py:515-517](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L515-L517)
- [app.py:2300-2499](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2300-L2499)

**Section sources**
- [engine.py:461-462](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L461-L462)
- [engine.py:515-517](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L515-L517)
- [test_engine.py:479-531](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L479-L531)

### Mathematical Precision, Rounding Rules, and Edge Cases
- Ratios are computed with pandas vectorized division and wrapped in a safe-ratio helper that replaces zero denominators with NaN and converts infinite results to NaN.
- Headroom is exact subtraction between Dynamic Limit and Observed Weight.
- Utilization is a direct ratio without explicit rounding; display formatting occurs in the UI layer.
- Threshold comparisons are inclusive:
  - Breach includes equality with Dynamic Limit.
  - Near Limit includes equality with 0.98 × Dynamic Limit.
- Edge cases covered by tests:
  - Zero account market value produces NaN weights and marks the account as Data Issue.
  - Missing prices fall back to zero for non-applicable statuses, preserving sibling weights while logging diagnostics.
  - Special market statuses such as delisted/unlisted/suspended are handled explicitly.
  - Thai pricing mappings can force unresolved pricing into a data issue.

```mermaid
flowchart TD
A["Observed Weight"] --> B["Compare with Dynamic Limit"]
B --> C{"≥ 100%?"}
C --> |Yes| D["Breach"]
C --> |No| E{"≥ 98%?"}
E --> |Yes| F["Near Limit"]
E --> |No| G["OK"]
H["Zero denominator"] --> I["NaN Utilization"]
J["Missing price"] --> K["Price → 0 for allowed statuses"]
L["Special market status"] --> M["Handled via ZERO_PRICE_MARKET_STATUSES"]
```

**Diagram sources**
- [engine.py:402-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L402-L404)
- [engine.py:522-529](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L529)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)

**Section sources**
- [engine.py:402-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L402-L404)
- [engine.py:522-529](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L522-L529)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [test_engine.py:1010-1031](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1010-L1031)
- [test_engine.py:703-814](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L703-L814)

### Examples of Limit Configuration Effects on Alerts
- Rank 1 with Largest present:
  - Example: largest=0.20, capping=0.10. Rank 1 uses 0.20; Rank 2 uses 0.10.
  - If Rank 1 observed weight is 0.15, it is OK under Largest but would be Breach under Capping.
- Rank 2 or later:
  - Always uses Capping regardless of Largest presence.
  - If observed weight is 0.098 and capping is 0.10, status is Near Limit because 0.098 ≥ 0.98 × 0.10.
- Incomplete accounts:
  - Data Issue applies at the account level, but names already at or above the dynamic limit retain Breach or Near Limit in the Monitor.

These scenarios are validated by unit tests covering rank-one limit selection, warning-threshold inclusivity, and incomplete-account alert behavior.

**Section sources**
- [test_engine.py:319-357](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L357)
- [test_engine.py:359-391](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L359-L391)
- [test_engine.py:393-447](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L393-L447)

## Dependency Analysis
The dynamic limit system depends on:
- Configuration constants and runbook data.
- Pandas operations for grouping, ranking, and vectorized math.
- UI formatting for percent strings and color codes.

```mermaid
graph LR
Config["config.py"] --> Engine["engine.py"]
Engine --> App["app.py"]
Tests["test_engine.py"] --> Engine
KB["25-etf-capping-monitor.md"] --> Engine
KB --> App
```

**Diagram sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [app.py:2300-2499](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2300-L2499)
- [test_engine.py:319-493](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L493)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)

**Section sources**
- [config.py:14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [app.py:2300-2499](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L2300-L2499)
- [test_engine.py:319-493](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L319-L493)
- [25-etf-capping-monitor.md:252-276](file://RAG KB/25-etf-capping-monitor.md#L252-L276)

## Performance Considerations
Optimization techniques used in the implementation:
- Vectorized pandas operations for market value, weights, grouping, ranking, and status assignment avoid Python loops over rows.
- Groupby aggregations compute incl-cash and ex-cash weights efficiently.
- Rank is computed per AIM Code using pandas rank with method="min", minimizing tie-handling complexity.
- Lookup tables built from MultiIndex reindexing propagate Rank, Dynamic Limit, and Status back to position rows without repeated merges.
- Safe ratio helper prevents division-by-zero and inf/nan propagation issues.
- Display formatting is separated from calculation logic, keeping the engine fast and testable.

For large datasets:
- Prefer pre-aggregated groups for summary views.
- Use filters like select_monitor_groups to reduce UI payload size.
- Avoid recomputing weights; reuse engine outputs across tabs and charts.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and their signals:
- Missing runbook entries:
  - Diagnostics include Missing Runbook; affected rows may lack Fund Name and related fields.
- Missing quantity or price:
  - Missing Quantity sets market value to zero and logs diagnostics.
  - Missing Price falls back to zero for allowed statuses and logs diagnostics.
- Zero account total:
  - Weights become NaN; account is marked Data Issue with Zero Denominator diagnostics.
- Reference data missing:
  - Rows with Reference Data Issue have price set to NaN and are treated as data issues.
- Thai pricing unresolved:
  - Unresolved Thai mapping forces price to zero and marks the account as Data Issue.
- Special market statuses:
  - Delisted/unlisted/suspended prices are preserved or zeroed according to predefined status lists.

Action steps:
- Check diagnostics for categories such as Missing Runbook, Missing Quantity, Missing Price, Zero Denominator, Reference Data Missing, Thai Pricing Unresolved, and Zero Price Market Status.
- Confirm whether the name is still Breach or Near Limit despite Data Issue; those alerts remain visible.
- Validate runbook and exception mappings for correct Parent/Issuer Ticker and Name resolution.

**Section sources**
- [engine.py:117-147](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L117-L147)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [engine.py:407-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L440)
- [test_engine.py:659-701](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L659-L701)
- [test_engine.py:950-1008](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L950-L1008)
- [test_engine.py:1010-1067](file://User scripts/ETF Capping Monitoring/tests/test_engine.py#L1010-L1067)

## Conclusion
The ETF Capping Monitoring system implements a robust, Excel-parity dynamic limit and ranking mechanism. It ranks all parent groups by incl-cash exposure, selects Largest for Rank 1 when available, and uses Capping for other ranks. Observed exposure is derived from the maximum of incl-cash and ex-cash aggregates, enabling accurate breach and near-limit detection. Headroom and utilization provide clear quantitative signals, while status logic cleanly separates capping breaches from data-quality issues. The implementation prioritizes performance through vectorized pandas operations and maintains precision by avoiding premature rounding and handling edge cases explicitly.

[No sources needed since this section summarizes without analyzing specific files]