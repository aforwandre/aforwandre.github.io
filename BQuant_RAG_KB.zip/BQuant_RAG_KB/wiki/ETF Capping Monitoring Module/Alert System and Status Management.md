# Alert System and Status Management

<cite>
**Referenced Files in This Document**
- [app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [book_view.py](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py)
- [metrics.py](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the alert system and status management behavior for the ETF Spread Monitoring application. It focuses on how the interface classifies data quality, how visual indicators communicate alert levels, how filtering and sorting shape the default Alerts view, and how status propagates across AIM accounts and over-limit names. It also covers real-time update mechanics, threshold configuration concepts, and interaction between different status types.

The application does not implement a separate “Breach / Near Limit / Data Issue / OK” engine as a single module. Instead, alert-like behavior emerges from:
- Missing or invalid market data handling.
- Spread and return calculations.
- Peer comparison logic.
- UI state and color markup.
- Refresh-driven data loading and caching.

## Project Structure
The alert-related behavior is distributed across several modules:
- `app.py` orchestrates user interactions, refresh flows, table rendering, charting, and status messages.
- `book_view.py` defines missing-market detection, quote carrying, period windows, and book display columns.
- `metrics.py` computes peer averages, spread comparisons, return paths, and visible column selection.
- `data.py` handles data sources, BQL requests, history fetching, identity mapping, and cache-aware parallel loads.
- `config.py` defines typed book entries, share-class configuration, and constants used by other modules.

```mermaid
graph TB
App["ETFSpreadMonitor<br/>app.py"] --> BookView["Book View<br/>book_view.py"]
App --> Metrics["Metrics & Comparisons<br/>metrics.py"]
App --> Data["Data Sources & History<br/>data.py"]
App --> Config["Configuration<br/>config.py"]
Metrics --> BookView
Data --> BookView
```

**Diagram sources**
- [app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [book_view.py:431-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L431-L496)
- [metrics.py:399-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L399-L546)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [config.py:88-125](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L125)

**Section sources**
- [app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [book_view.py:431-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L431-L496)
- [metrics.py:399-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L399-L546)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [config.py:88-125](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L125)

## Core Components
The alert system is best understood as a combination of data-quality checks, computed metrics, and UI presentation:

- Missing-market detection:
  - Blank cells, vendor tokens such as “N/A”, “null”, “none”, and similar markers are treated as missing.
  - Missing values are converted to blank text in the UI rather than zero.

- Quote and spread computation:
  - Absolute spread is derived from Bid and Ask when both are positive and Ask is at least Bid.
  - Percent spread is absolute spread divided by Mid, multiplied by 100.
  - If Mid is missing, it is estimated from Bid and Ask.

- Period windows and averages:
  - Preset periods (1M, 3M, 6M, YTD, 1Y, 3Y, 5Y) are mapped to London trading-day windows.
  - Average spread percent per period is computed after carrying quotes forward across holidays.

- Peer comparison:
  - Peer average spread and return are aligned to HSBC anchor quote dates.
  - The app can include the HSBC anchor in the peer average (“HSBC + Peers”) or show peers only.

- UI alert-like signals:
  - Environment and phase colors indicate Processing vs Idle vs Refreshed.
  - HSBC rows in the Peers Details table are visually emphasized.
  - Missing data produces blank cells or explicit notes rather than misleading zeros.

**Section sources**
- [book_view.py:12-83](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L12-L83)
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [book_view.py:265-337](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L265-L337)
- [book_view.py:375-428](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L375-L428)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)
- [metrics.py:624-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L624-L670)
- [app.py:82-96](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L82-L96)
- [app.py:1322-1334](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1322-L1334)

## Architecture Overview
The alert and status flow begins with user actions and ends with rendered tables, charts, and status messages.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "ETFSpreadMonitor<br/>app.py"
participant Data as "data.py"
participant BookView as "book_view.py"
participant Metrics as "metrics.py"
User->>App : Click Refresh
App->>Data : fetch_share_class_directory()
Data-->>App : SourceResult with directory + errors
App->>Data : fetch_parallel_histories()
Data-->>App : quote, return, NAV, flow results
App->>BookView : book_display(directory, history)
BookView-->>App : book frame with averages
App->>Metrics : peer_metric_frame()
Metrics-->>App : peer averages merged into book
App->>App : _redraw_table(), _draw_spread_chart()
App-->>User : Updated table, charts, status
```

**Diagram sources**
- [app.py:846-1002](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L846-L1002)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)

## Detailed Component Analysis

### Multi-Tier Alert Classification Concept
The repository does not define an explicit enum named “Breach”, “Near Limit”, “Data Issue”, or “OK”. However, the following mechanisms produce equivalent alert-like classification:

| Conceptual Alert | Code-Level Signal | Interpretation |
|---|---|---|
| Data Issue | Missing market text, blank spreads, failed BQL requests, empty history, stale identifiers | Data quality is insufficient; values are blank or accompanied by diagnostic notes. |
| Breach | Positive absolute spread where Bid and Ask are valid, or spread percent present but outside desired range | A spread exists; whether it is a breach depends on configured thresholds. |
| Near Limit | Spread percent present but close to a threshold boundary | Proximity to a limit requires threshold configuration to classify. |
| OK | Valid spread or return with no missing data and within acceptable ranges | Healthy data and acceptable metric values. |

Because thresholds are not defined in the analyzed files, “Breach” and “Near Limit” must be implemented by adding threshold rules around the computed spread percent and related metrics.

**Section sources**
- [book_view.py:12-83](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L12-L83)
- [book_view.py:121-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L121-L160)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)

### Visual Indicators and Color Coding
The UI communicates status through HTML markup and row styling:

- Environment line:
  - Processing is red.
  - Idle is green.

- Phase label:
  - Idle and Please Click Refresh are red.
  - Refreshed is green.
  - Other phases are bold without special color.

- HSBC row emphasis:
  - In the Peers Details grid, HSBC rows are bold with a darker background.

- Missing data:
  - Missing market text becomes empty strings in formatted cells.
  - Notes are appended to status lines when data sources fail or return incomplete results.

```mermaid
flowchart TD
Start(["UI Rendering"]) --> Phase["Phase Markup"]
Phase --> PhaseIdle{"Phase is Idle or Please Click Refresh?"}
PhaseIdle --> |Yes| RedPhase["Red Phase Label"]
PhaseIdle --> |No| GreenPhase["Green Phase Label if Refreshed"]
Phase --> Env["Environment Markup"]
Env --> Busy{"Busy or View Busy?"}
Busy --> |Yes| RedEnv["Red Environment"]
Busy --> |No| GreenEnv["Green Environment"]
Start --> RowStyle["Row Styling"]
RowStyle --> HSBC{"Is HSBC Row?"}
HSBC --> |Yes| BoldRow["Bold Row + Dark Background"]
HSBC --> |No| NormalRow["Normal Row"]
```

**Diagram sources**
- [app.py:82-96](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L82-L96)
- [app.py:1322-1334](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1322-L1334)
- [app.py:222-260](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L222-L260)

**Section sources**
- [app.py:82-96](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L82-L96)
- [app.py:222-260](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L222-L260)
- [app.py:1322-1334](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1322-L1334)

### Default Alerts View Behavior
The default view shows:
- Typed HSBC ETF rows.
- Fund Name and Share Class identity.
- Spread, Return, and NAV Return depending on checkbox selections.
- Period averages for selected windows.
- Peer comparison columns when enabled.

The “Alerts view” described in the objective should map to this HSBC ETF table plus peer comparison columns. The code does not enforce a dedicated “Alerts” tab; instead, the HSBC ETF tab serves as the primary monitoring surface.

Key behaviors:
- Strategy filter selects typed IsinEntry rows.
- Fund filter narrows to a specific fund.
- Period buttons toggle collapsed/expanded groups.
- Visible columns depend on Spread, Return, and NAV Return checkboxes.
- Peer averages are added via `peer_metric_frame`.

**Section sources**
- [app.py:378-413](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L378-L413)
- [app.py:488-564](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L488-L564)
- [app.py:1277-1320](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1277-L1320)
- [metrics.py:399-444](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L399-L444)
- [metrics.py:447-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L447-L546)

### Rank 1 Equity Comparison
The codebase does not contain a field named “Rank 1 equity”. The closest concept is peer comparison:
- Peer average spread and return.
- Optional inclusion of the HSBC anchor in the peer average.
- Individual peer member series shown in charts.

If “Rank 1 equity comparison” means comparing the primary HSBC equity against its top peers, that is implemented through:
- `member_tickers` including the anchor when “HSBC + Peers” is selected.
- `spread_comparison` and `return_comparison` aligning HSBC and peers.
- `peer_member_spreads` and `peer_member_returns` plotting each peer separately.

**Section sources**
- [metrics.py:38-58](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L38-L58)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)
- [metrics.py:624-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L624-L670)
- [metrics.py:684-717](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L684-L717)
- [metrics.py:720-766](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L720-L766)

### Status Propagation Logic
Status propagation is primarily about data quality and how missing data affects displayed values:

- Data Issue propagation:
  - Missing market text makes numeric conversion blank.
  - Failed BQL requests append error notes.
  - Stale identifier mappings discard cached history and request fresh data.
  - Empty or invalid history produces blank spreads, returns, or NAV values.

- Over-limit names maintaining breach status:
  - There is no explicit “over-limit name” flag in the analyzed code.
  - If an over-limit rule is added later, the current design supports preserving a breach state by computing alerts after data cleaning and before replacing blanks with safe defaults.
  - To ensure over-limit names keep their breach status even with data issues, the alert layer should:
    - Compute breach/near-limit flags from available spread percent.
    - Mark Data Issue separately.
    - Combine them so that a prior breach remains visible unless explicitly cleared.

- AIM account-level propagation:
  - The app works at fund and share-class granularity.
  - If an AIM account corresponds to a fund, a Data Issue affecting all share classes of that fund can be represented by propagating a fund-level quality flag.
  - The current code does not implement AIM account grouping; this would require extending the data model and UI to attach a fund-level status.

```mermaid
flowchart TD
RawData["Raw Market Data"] --> Clean["Missing-Market Cleaning"]
Clean --> Quotes["Bid/Ask/Mid"]
Quotes --> Spread["Absolute Spread"]
Spread --> Percent["Percent Spread"]
Percent --> Quality["Data Quality Check"]
Quality --> DataIssue{"Any Missing or Invalid?"}
DataIssue --> |Yes| FlagDataIssue["Mark Data Issue"]
DataIssue --> |No| Threshold["Apply Thresholds"]
Threshold --> Breach{"Above Breach Threshold?"}
Breach --> |Yes| FlagBreach["Mark Breach"]
Breach --> |No| NearLimit{"Near Limit?"}
NearLimit --> |Yes| FlagNearLimit["Mark Near Limit"]
NearLimit --> |No| FlagOK["Mark OK"]
FlagDataIssue --> Combine["Combine With Prior Breach State"]
FlagBreach --> Combine
FlagNearLimit --> Combine
FlagOK --> Combine
Combine --> Propagate["Propagate to Fund/Account Level"]
```

[No diagram sources because this diagram illustrates conceptual alert propagation beyond the current code]

**Section sources**
- [book_view.py:12-83](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L12-L83)
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)

### Alert Filtering and Sorting
Filtering and sorting are driven by:
- Strategy dropdown.
- Fund dropdown.
- Spread, Return, NAV Return checkboxes.
- Period group toggles.
- Peer average mode.

Sorting:
- Typed order is preserved using the `Order` field.
- When `Order` is absent, rows sort last by design.
- The Peers Details view highlights HSBC rows but does not introduce a separate alert sort.

Default Alerts view composition:
- Show typed HSBC rows.
- Include peer comparison columns when enabled.
- Use selected periods for average spread and return columns.
- Keep identity columns frozen for readability.

**Section sources**
- [app.py:569-574](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L569-L574)
- [app.py:746-757](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L746-L757)
- [app.py:1203-1233](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1203-L1233)
- [app.py:1277-1320](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1277-L1320)
- [book_view.py:454-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L454-L496)
- [metrics.py:399-444](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L399-L444)

### Real-Time Update Mechanisms
Real-time updates are event-driven:
- Control changes trigger redraws without network requests.
- Refresh triggers full data loading.
- Status messages reflect processing state.

Key mechanisms:
- `_show_activity` paints Processing, runs work asynchronously, then restores Idle or Refreshed.
- `_on_pull_choice` prompts “Please Click Refresh” when strategy, history range, or cache setting changes.
- `_on_book_controls`, `_on_peer_controls`, and `_on_flow_controls` redraw views from cached data.
- `_set_status` updates the phase, detail, environment, and settings summary.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "ETFSpreadMonitor"
participant Cache as "Local Cache"
participant BQL as "BQL Service"
User->>App : Change Filter or Period
App->>App : _show_activity()
App->>App : Redraw from cache
App-->>User : Updated table/chart/status
User->>App : Click Refresh
App->>Cache : Read stored series
App->>BQL : Request missing gaps
BQL-->>App : New observations
App->>App : Merge, compute, render
App-->>User : Refreshed status with details
```

**Diagram sources**
- [app.py:612-637](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L612-L637)
- [app.py:1081-1099](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1081-L1099)
- [app.py:1101-1117](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1101-L1117)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)

**Section sources**
- [app.py:612-637](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L612-L637)
- [app.py:1081-1099](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1081-L1099)
- [app.py:1101-1117](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1101-L1117)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)

### Threshold Configuration Examples
Thresholds are not implemented in the analyzed files. To support Breach and Near Limit:

- Add threshold configuration objects for:
  - Absolute spread percent.
  - Period-average spread percent.
  - Return deviation from peer average.
  - NAV tracking error limits.

- Example configuration structure (conceptual):
  - `breach_threshold_percent`: float
  - `near_limit_threshold_percent`: float
  - `peer_deviation_threshold_percent`: float
  - `nav_tracking_error_threshold_percent`: float

- Evaluation logic should:
  - First check data quality.
  - Then apply thresholds.
  - Preserve prior breach state for over-limit names.
  - Propagate fund-level Data Issue to all share classes.

**Section sources**
- [book_view.py:101-160](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L101-L160)
- [metrics.py:584-621](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L584-L621)
- [metrics.py:624-670](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L624-L670)

### Interaction Between Different Status Types
Conceptual interaction rules:

- Data Issue overrides OK and Near Limit.
- Breach remains active until explicitly cleared.
- Over-limit names retain Breach even when new data has a Data Issue.
- Fund-level Data Issue marks all share classes as Data Issue, but existing Breach flags remain visible.
- UI should combine flags:
  - Primary alert: Breach > Near Limit > Data Issue > OK.
  - Secondary indicator: Data Issue presence.

```mermaid
flowchart TD
Start(["New Data"]) --> Quality["Check Data Quality"]
Quality --> HasDataIssue{"Data Issue Present?"}
HasDataIssue --> |Yes| KeepBreach{"Was Prior Breach Active?"}
KeepBreach --> |Yes| ShowBreachWithIssue["Show Breach + Data Issue"]
KeepBreach --> |No| ShowDataIssue["Show Data Issue"]
HasDataIssue --> |No| ApplyThresholds["Apply Thresholds"]
ApplyThresholds --> BreachCheck{"Above Breach?"}
BreachCheck --> |Yes| ShowBreach["Show Breach"]
BreachCheck --> |No| NearLimitCheck{"Near Limit?"}
NearLimitCheck --> |Yes| ShowNearLimit["Show Near Limit"]
NearLimitCheck --> |No| ShowOK["Show OK"]
```

[No diagram sources because this diagram shows conceptual interaction rules]

**Section sources**
- [book_view.py:12-83](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L12-L83)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)

## Dependency Analysis
The alert-related dependencies form a layered pipeline:

```mermaid
graph LR
Config["config.py"] --> Data["data.py"]
Data --> BookView["book_view.py"]
BookView --> Metrics["metrics.py"]
Metrics --> App["app.py"]
Data --> App
BookView --> App
```

**Diagram sources**
- [config.py:88-125](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L125)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [book_view.py:431-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L431-L496)
- [metrics.py:399-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L399-L546)
- [app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)

**Section sources**
- [config.py:88-125](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L125)
- [data.py:1759-1901](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1759-L1901)
- [book_view.py:431-496](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L431-L496)
- [metrics.py:399-546](file://User scripts/ETF Spread Monitoring/etf_spread/metrics.py#L399-L546)
- [app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)

## Performance Considerations
- Caching reduces repeated history requests.
- Parallel history fetching batches BQL requests.
- Stale identifier detection discards outdated cached series.
- Gap planning requests only missing days.
- UI redraws avoid network calls when only filters or periods change.

Recommendations for alert performance:
- Compute alert flags once per refreshed dataset.
- Avoid recomputing thresholds on every chart redraw.
- Cache threshold configurations and evaluation results per run.
- Defer heavy alert aggregation until after data merging.

**Section sources**
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)
- [app.py:612-637](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L612-L637)
- [app.py:1081-1099](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1081-L1099)

## Troubleshooting Guide
Common alert-related symptoms and causes:

- Blank spread or return values:
  - Missing Bid, Ask, or Mid.
  - Vendor missing tokens.
  - No London session in the selected period.

- Status shows Error or Loading:
  - BQL unavailable.
  - Identifier mapping changed.
  - Cached history invalidated.

- No rows in Alerts view:
  - Strategy or Fund filter excludes all typed rows.
  - Selected periods have no data.
  - Spread, Return, and NAV Return checkboxes hide all metric columns.

- Charts show no data:
  - Selected share class has no history.
  - Period window is invalid.
  - Only one metric type is selected but data is missing.

Actions:
- Verify ISIN_BOOK and share-class configuration.
- Check Strategy and Fund filters.
- Confirm history range and cache settings.
- Review status detail for BQL errors.
- Ensure custom date ranges are valid.

**Section sources**
- [book_view.py:12-83](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L12-L83)
- [book_view.py:340-365](file://User scripts/ETF Spread Monitoring/etf_spread/book_view.py#L340-L365)
- [app.py:846-1002](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L846-L1002)
- [app.py:1604-1794](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1604-L1794)
- [data.py:2227-2399](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L2227-L2399)

## Conclusion
The ETF Spread Monitoring application implements alert-like behavior through robust data-quality handling, spread and return computations, peer comparisons, and clear UI status indicators. While the exact “Breach / Near Limit / Data Issue / OK” classification is not present as a dedicated module, the foundation is ready for threshold-based alerting.

To complete the alert system:
- Add explicit threshold configuration.
- Implement alert flag computation after data cleaning.
- Preserve breach state for over-limit names.
- Propagate Data Issue at the AIM account level when applicable.
- Extend the default Alerts view to highlight Breach and Near Limit rows.
- Keep real-time updates efficient by caching alert results and recomputing only when data or filters change.