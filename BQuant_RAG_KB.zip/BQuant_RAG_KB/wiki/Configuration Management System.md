# Configuration Management System

<cite>
**Referenced Files in This Document**
- [ETF Capping config](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [ETF Capping redacted config](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py)
- [ETF Spread config](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [FI Index Change config](file://User scripts/FI Index Change/fi_index_change/config.py)
- [FI Spread Movement config](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [MDX Scan config](file://User scripts/MDX Scan/mdx_scan/config.py)
- [ETF Capping app](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [ETF Capping engine](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [ETF Spread app](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [FI Index Change app](file://User scripts/FI Index Change/fi_index_change/app.py)
- [FI Spread Movement app](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [FI Spread Movement engine](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the configuration management system used across the BQNT user-script modules. Each module owns its own `config.py` and exposes constants, business rules, display settings, operational thresholds, and helper functions that other modules import at runtime. The design is intentionally simple: configuration lives in Python modules rather than external files, with frozen dataclasses for structured rules, pandas helpers for tabular runbooks, and explicit validation where correctness matters.

The system supports:
- Environment-specific defaults through per-module configuration files.
- Business rule definitions such as capping limits, exception mappings, universe sources, spread types, and descriptor fields.
- Parameter management for UI layout, chart dimensions, timeouts, retries, cache behavior, and operator-selected options.
- Validation mechanisms that raise clear errors for malformed or inconsistent configuration.
- Security-sensitive handling by separating live data from desensitized output copies.
- Migration guidance through dated comments, decision records, tests, and cache-keying strategies.

## Project Structure
Each monitoring application follows a consistent pattern:
- A package directory under `User scripts/<Application>/`.
- A `config.py` module defining all static configuration.
- An `app.py` module wiring widgets and importing configuration.
- Optional `engine.py`, `data.py`, `cache.py`, and tests.

```mermaid
graph TB
ETF_Capping["ETF Capping Monitoring<br/>etf_capping"]
ETF_Spread["ETF Spread Monitoring<br/>etf_spread"]
FI_Index["FI Index Change<br/>fi_index_change"]
FI_Spread["FI Spread Movement Monitoring<br/>fi_spread_movement"]
MDX["MDX Scan<br/>mdx_scan"]
ETF_Capping --> |imports| ETF_Capping_Config["etf_capping/config.py"]
ETF_Spread --> |imports| ETF_Spread_Config["etf_spread/config.py"]
FI_Index --> |imports| FI_Index_Config["fi_index_change/config.py"]
FI_Spread --> |imports| FI_Spread_Config["fi_spread_movement/config.py"]
MDX --> |imports| MDX_Config["mdx_scan/config.py"]
```

**Diagram sources**
- [ETF Capping app:26-32](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L32)
- [ETF Spread app:26](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L26)
- [FI Index Change app:11](file://User scripts/FI Index Change/fi_index_change/app.py#L11)
- [FI Spread Movement app:163](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L163)
- [ETF Capping config](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [ETF Spread config](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [FI Index Change config](file://User scripts/FI Index Change/fi_index_change/config.py)
- [FI Spread Movement config](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [MDX Scan config](file://User scripts/MDX Scan/mdx_scan/config.py)

**Section sources**
- [ETF Capping app:26-32](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L32)
- [ETF Spread config:1-6](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L1-L6)
- [FI Index Change config:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [FI Spread Movement config:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)
- [MDX Scan config:1-3](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L3)

## Core Components
The configuration system is built around five recurring patterns:

1. **Module-level constants**: Operational thresholds, UI sizes, default values, and labels.
2. **Frozen dataclasses**: Structured business rules with immutable fields.
3. **Tuple-based rule lists**: Ordered, versioned collections of entities such as accounts, share classes, indices, and benchmarks.
4. **Pandas helper functions**: Convert configuration into DataFrames for display, export, or testing.
5. **Validation helpers**: Functions that enforce structural integrity before runtime use.

Key responsibilities by module:

| Module | Configuration Focus | Examples |
|---|---|---|
| ETF Capping | Account capping rules, exception mappings, Thai pricing overrides, status colors, batch sizes | `ACCOUNT_RULES`, `EXCEPTION_RULES`, `THAI_PRICING_RULES`, `WARNING_RATIO` |
| ETF Spread | Share-class book, ISIN book, observation columns, period keys, enabled filters | `SHARE_CLASSES`, `ISIN_BOOK`, `PERIOD_KEYS`, `OBSERVATION_COLUMNS` |
| FI Index Change | Default index/book, country overrides, rating labels, filter widths, retry/cache settings | `DEFAULT_INDEX`, `DEFAULT_BOOK`, `COUNTRY_NAME_OVERRIDES`, `QUERY_ATTEMPTS` |
| FI Spread Movement | Universe sources, spread types, descriptors, duration measures, chart geometry, cache policy | `UNIVERSE_SOURCES`, `SPREAD_TYPES`, `DESCRIPTOR_FIELDS`, `CACHE_DIR_NAME` |
| MDX Scan | Benchmarks, signal ranks/colors, EMA lookback, parameter defaults | `HK_INDICES`, `US_FUTURES`, `SIGNAL_RANK`, `MDXParams` |

**Section sources**
- [ETF Capping config:14-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L107)
- [ETF Spread config:15-81](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L81)
- [FI Index Change config:12-122](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L122)
- [FI Spread Movement config:26-197](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L197)
- [MDX Scan config:6-43](file://User scripts/MDX Scan/mdx_scan/config.py#L6-L43)

## Architecture Overview
At runtime, applications import configuration directly from their module’s `config.py`. There is no centralized configuration loader, environment variable resolver, or dynamic configuration service. Instead, each module encapsulates its own domain configuration and validates it when needed.

```mermaid
graph TB
App_EtfCapping["ETF Capping app.py"]
App_EtfSpread["ETF Spread app.py"]
App_FiIndex["FI Index Change app.py"]
App_FiSpread["FI Spread Movement app.py"]
Config_EtfCapping["ETF Capping config.py"]
Config_EtfSpread["ETF Spread config.py"]
Config_FiIndex["FI Index Change config.py"]
Config_FiSpread["FI Spread Movement config.py"]
Config_Mdx["MDX Scan config.py"]
App_EtfCapping --> Config_EtfCapping
App_EtfSpread --> Config_EtfSpread
App_FiIndex --> Config_FiIndex
App_FiSpread --> Config_FiSpread
App_EtfCapping -. optional .-> Config_Mdx
Config_EtfCapping --> Engine_EtfCapping["ETF Capping engine.py"]
```

**Diagram sources**
- [ETF Capping app:26-32](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L32)
- [ETF Spread app:26](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L26)
- [FI Index Change app:11](file://User scripts/FI Index Change/fi_index_change/app.py#L11)
- [FI Spread Movement app:163](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L163)
- [ETF Capping engine:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)

## Detailed Component Analysis

### ETF Capping Configuration
ETF Capping uses structured business rules to monitor position concentration against AIM account limits.

#### Business Rule Model
```mermaid
classDiagram
class AccountRule {
+string aim_code
+string fund_name
+float capping
+float largest
+string level
+string price_type
}
class ExceptionRule {
+string ticker
+string name
+string parent_ticker
+string parent_name
}
class ThaiPricingRule {
+string foreign_ticker
+string local_ticker
+string reason
}
class EtfCappingConfig {
+tuple ACCOUNT_RULES
+tuple EXCEPTION_RULES
+tuple THAI_PRICING_RULES
+dict PRIMARY_FM_BY_AIM
+float WARNING_RATIO
+account_rules_frame() DataFrame
+exception_rules_frame() DataFrame
+thai_pricing_rules_frame() DataFrame
+thai_pricing_overrides() dict
+account_codes() list
}
EtfCappingConfig --> AccountRule : "contains"
EtfCappingConfig --> ExceptionRule : "contains"
EtfCappingConfig --> ThaiPricingRule : "contains"
```

**Diagram sources**
- [ETF Capping config:26-49](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L26-L49)
- [ETF Capping config:52-124](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L124)
- [ETF Capping config:186-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L268)

#### Validation Flow
Thai pricing overrides and account codes are validated at import/runtime boundaries:

```mermaid
flowchart TD
Start(["Load Thai Pricing Rules"]) --> Normalize["Normalize foreign and local tickers"]
Normalize --> CheckForeign{"Is foreign line valid?"}
CheckForeign --> |No| RaiseForeign["Raise ValueError"]
CheckForeign --> |Yes| CheckLocal{"Is local line valid?"}
CheckLocal --> |No| RaiseLocal["Raise ValueError"]
CheckLocal --> |Yes| CheckDuplicate{"Duplicate key?"}
CheckDuplicate --> |Yes| RaiseDuplicate["Raise ValueError"]
CheckDuplicate --> |No| BuildOverrides["Build override map"]
BuildOverrides --> End(["Return overrides"])
```

**Diagram sources**
- [ETF Capping config:233-258](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L233-L258)

#### Security Handling
The live configuration contains real AIM codes, fund names, and mappings. A separate redacted copy exists for safe sharing or documentation. The live module explicitly forbids importing the redacted file.

```mermaid
flowchart TD
LiveConfig["etf_capping/config.py<br/>Live runbook"] --> Generate["Regenerate helpers"]
Redacted["etf_capping/config_redacted.py<br/>Desensitized output"] --> Use["Do not import in production code"]
LiveConfig --> Tests["Tests and internal runs"]
Redacted --> Docs["Documentation and examples"]
```

**Diagram sources**
- [ETF Capping config:1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)
- [ETF Capping redacted config:1-6](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py#L1-L6)

**Section sources**
- [ETF Capping config:14-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L107)
- [ETF Capping config:186-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L268)
- [ETF Capping redacted config:1-165](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py#L1-L165)
- [ETF Capping engine:173-199](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L173-L199)

### ETF Spread Configuration
ETF Spread focuses on ETF share-class identity, peer grouping, and observation metadata.

#### Configuration Model
```mermaid
classDiagram
class ShareClass {
+string share_class_id
+string etf_id
+string label
+string listing_ticker
+string currency
+string peer_group_id
+bool enabled
}
class IsinEntry {
+string fund_name
+string isin
+string ticker
+string order
+string strategy
}
class EtfSpreadConfig {
+tuple PERIOD_KEYS
+string DEFAULT_PERIOD
+int HISTORY_BUSINESS_DAYS
+tuple OBSERVATION_COLUMNS
+tuple SHARE_CLASSES
+tuple ISIN_BOOK
+enabled_share_classes() tuple
+isin_book_frame() DataFrame
+share_class_directory() DataFrame
}
EtfSpreadConfig --> ShareClass : "contains"
EtfSpreadConfig --> IsinEntry : "contains"
```

**Diagram sources**
- [ETF Spread config:35-44](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L35-L44)
- [ETF Spread config:88-103](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L103)
- [ETF Spread config:115-139](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L115-L139)

#### Example Configuration Shape
- Period presets: one-month through five-year plus custom.
- Sample share classes include enabled and disabled entries.
- ISIN book defines one primary share class per ETF.
- Observation columns define required fields for spread analysis.

**Section sources**
- [ETF Spread config:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [ETF Spread config:46-81](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L46-L81)
- [ETF Spread config:105-139](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L105-L139)

### FI Index Change Configuration
FI Index Change configures desktop app defaults, display logic, request resilience, and cache behavior.

#### Key Configuration Areas
| Area | Purpose |
|---|---|
| Defaults | Default index, default book, month-end choices |
| Labels | Country overrides, municipal/bond labels, rating classification |
| UI Layout | Filter widths, row width, screen ratio, pinned columns |
| Request Resilience | Split requests, query attempts |
| Display Limits | Weight scaling, row cap, cache directory |

```mermaid
flowchart TD
Defaults["DEFAULT_INDEX<br/>DEFAULT_BOOK"] --> UI["FILTER_WIDTHS<br/>CHART_WIDTH_PX"]
Defaults --> Requests["SPLIT_REQUESTS<br/>QUERY_ATTEMPTS"]
Labels["MUNI_LABEL<br/>RATING_MISSING<br/>MBS_TBA_LABEL"] --> Display["Display buckets and missing values"]
Requests --> Cache["CACHE_DIR_NAME"]
```

**Diagram sources**
- [FI Index Change config:12-16](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L16)
- [FI Index Change config:21-43](file://User scripts/FI Index Change/fi_index_change/config.py#L21-L43)
- [FI Index Change config:49-65](file://User scripts/FI Index Change/fi_index_change/config.py#L49-L65)
- [FI Index Change config:88-122](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L122)

**Section sources**
- [FI Index Change config:1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)

### FI Spread Movement Configuration
FI Spread Movement has the most extensive operator-driven configuration because it supports multiple universe sources, spread types, descriptors, duration measures, charts, and cache/retry policies.

#### Configuration Model
```mermaid
classDiagram
class FiSpreadConfig {
+int TOP_N
+string DEFAULT_INDEX
+dict UNIVERSE_SOURCES
+string DEFAULT_UNIVERSE_SOURCE
+string COMPARISON_SOURCE
+dict SPREAD_TYPES
+string DEFAULT_SPREAD_TYPE
+tuple DESCRIPTOR_FIELDS
+tuple DURATION_FIELDS
+dict DURATION_LABELS
+int DEFAULT_WINDOW_DAYS
+int MAX_RANGE_DAYS
+tuple FILTER_COLUMNS
+dict DIMENSIONS
+int CACHE_KEEP_RUNS
+bool CACHE_READ_FIRST
+int QUERY_ATTEMPTS
+tuple NUMERIC_RESULT_COLUMNS
}
```

**Diagram sources**
- [FI Spread Movement config:26-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L55)
- [FI Spread Movement config:104-197](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L104-L197)
- [FI Spread Movement config:199-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L199-L389)

#### Runtime Validation Flow
The engine validates ranked movers, handles duplicates, enforces directionality, applies top-N selection, and merges descriptors safely.

```mermaid
flowchart TD
Input["Ranked response"] --> Clean["Clean ID and Change"]
Clean --> Invalid{"Blank ID or non-numeric Change?"}
Invalid --> |Yes| DropInvalid["Drop invalid rows"]
Invalid --> |Yes| NoteInvalid["Record note"]
Invalid --> |No| GroupCheck{"Comparison mode?"}
GroupCheck --> |Yes| GroupKey["Use Universe + ID"]
GroupCheck --> |No| IdKey["Use ID"]
GroupKey --> Duplicate{"Duplicates?"}
IdKey --> Duplicate
Duplicate --> |Yes| Deduplicate["Keep last per key"]
Duplicate --> |No| Direction{"Correct sign?"}
Deduplicate --> Direction
Direction --> |No| DropWrong["Drop wrong-sign rows"]
Direction --> |No| NoteWrong["Record note"]
Direction --> |Yes| TopN["Apply TOP_N per book or overall"]
TopN --> Merge["Merge descriptors"]
Merge --> Output["Validated ranked movers"]
```

**Diagram sources**
- [FI Spread Movement engine:68-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L68-L176)
- [FI Spread Movement engine:179-200](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L179-L200)

**Section sources**
- [FI Spread Movement config:26-197](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L197)
- [FI Spread Movement config:199-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L199-L389)
- [FI Spread Movement engine:68-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L68-L176)

### MDX Scan Configuration
MDX Scan configuration is lighter but still structured around benchmarks, signals, and parameters.

#### Key Elements
- Benchmarks: Hang Seng family cash indices and US equity-index futures.
- Signals: Ranked signal types with colors and legends.
- Parameters: EMA lookback, cooldown, buy history window, and `MDXParams`.

```mermaid
classDiagram
class MDXParams {
+int n1
+int n2
+float n3
+int n4
+int n5
+int cooldown
+int buy_lookback
}
class BenchSpec {
+string ticker
+string label
+string group
}
class MdxConfig {
+string HSI_INDEX
+tuple HK_INDICES
+tuple US_FUTURES
+dict SIGNAL_RANK
+dict SIGNAL_COLORS
+tuple SIGNAL_LEGEND
+bench_universe() list
+all_bench_tickers() list
}
MdxConfig --> BenchSpec : "builds"
MdxConfig --> MDXParams : "uses defaults"
```

**Diagram sources**
- [MDX Scan config:6-27](file://User scripts/MDX Scan/mdx_scan/config.py#L6-L27)
- [MDX Scan config:32-68](file://User scripts/MDX Scan/mdx_scan/config.py#L32-L68)
- [MDX Scan config:77-103](file://User scripts/MDX Scan/mdx_scan/config.py#L77-L103)

**Section sources**
- [MDX Scan config:6-103](file://User scripts/MDX Scan/mdx_scan/config.py#L6-L103)

## Dependency Analysis
Configuration dependencies are mostly one-directional: apps and engines import from `config.py`. Some modules also depend on shared runtime behavior such as cache directories or retry counts.

```mermaid
graph LR
ETF_App["ETF Capping app.py"] --> ETF_Config["ETF Capping config.py"]
ETF_Engine["ETF Capping engine.py"] --> ETF_Config
ETF_Spread_App["ETF Spread app.py"] --> ETF_Spread_Config["ETF Spread config.py"]
FI_Index_App["FI Index Change app.py"] --> FI_Index_Config["FI Index Change config.py"]
FI_Spread_App["FI Spread Movement app.py"] --> FI_Spread_Config["FI Spread Movement config.py"]
FI_Spread_Engine["FI Spread Movement engine.py"] --> FI_Spread_Config
```

**Diagram sources**
- [ETF Capping app:26-32](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L32)
- [ETF Capping engine:10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10)
- [ETF Spread app:26](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L26)
- [FI Index Change app:11](file://User scripts/FI Index Change/fi_index_change/app.py#L11)
- [FI Spread Movement app:163](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L163)
- [FI Spread Movement engine:18](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L18)

**Section sources**
- [ETF Capping app:26-32](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L26-L32)
- [ETF Spread app:26](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L26)
- [FI Index Change app:11](file://User scripts/FI Index Change/fi_index_change/app.py#L11)
- [FI Spread Movement app:163](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L163)
- [FI Spread Movement engine:18](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L18)

## Performance Considerations
Configuration directly affects performance and reliability:

- **Request breadth**: FI Index Change splits analytics groups and limits query attempts to avoid Bloomberg timeouts.
- **Cache policy**: FI Spread Movement keeps a bounded number of cached runs and can fall back to cache after timeout.
- **Top-N bounds**: FI Spread Movement caps displayed movers while allowing a larger maximum for UI controls without silently truncating requests.
- **Chart sizing**: Both FI Index Change and FI Spread Movement compute chart widths based on filter layouts and screen ratios.
- **Batch sizes**: ETF Capping defines account and security batch sizes for downstream processing.

Recommendations:
- Keep `TOP_N`, `DISPLAY_TOP_MAX`, and `HISTORY_BUSINESS_DAYS` aligned with observed request latency.
- Treat `QUERY_ATTEMPTS` and `SPLIT_REQUESTS` as operational tuning knobs, not permanent fixes for oversized requests.
- Validate new descriptors and duration measures before adding them to `DESCRIPTOR_FIELDS` or `DURATION_FIELDS`.
- Monitor cache growth using `CACHE_DIR_NAME` and `CACHE_KEEP_RUNS`.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Common Configuration Loading Issues
| Symptom | Likely Cause | Resolution |
|---|---|---|
| Import fails because sensitive data is present | Live `config.py` contains real AIM codes or fund names | Use the redacted copy for documentation; do not import it in production code |
| Thai pricing override raises an error | Foreign/local ticker format does not match expected suffixes | Ensure foreign lines end with the expected foreign suffix and local lines end with the expected local suffix |
| Duplicate AIM code error | Runbook contains repeated account identifiers | Remove duplicates and verify mapping uniqueness |
| Unknown history kind or empty frame caching error | Cache layer received unexpected input | Inspect caller inputs and ensure frames contain required value columns |
| Missing columns in ranked response | Descriptor or ranking request failed partially | Check field status logs and exclude failing fields while keeping others |

**Section sources**
- [ETF Capping config:233-268](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L233-L268)
- [ETF Capping redacted config:129-164](file://User scripts/ETF Capping Monitoring/etf_capping/config_redacted.py#L129-L164)
- [ETF Spread cache:504-540](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L504-L540)
- [FI Spread Movement engine:68-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L68-L176)

### Parameter Validation Errors
- **Positive integer checks**: Top-N and similar numeric parameters should be validated before use.
- **Direction checks**: Ranked movers must match the expected increase/decrease direction.
- **Duplicate handling**: In comparison mode, duplicate detection uses a composite key so the same bond in two books is not incorrectly dropped.
- **Descriptor merging**: Missing descriptor columns are skipped gracefully; failing descriptors are noted rather than crashing the whole update.

**Section sources**
- [FI Spread Movement engine:68-176](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L68-L176)
- [FI Spread Movement engine:179-200](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L179-L200)

## Conclusion
The configuration management system in this repository is modular, explicit, and operationally focused. Each module owns its configuration, documents operator decisions, and validates critical assumptions. There is no global configuration server or secret manager; instead, security is handled by separating live data from redacted outputs, and operational resilience is handled by cache, retry, split, and bounded request policies.

For new configuration options:
- Add constants or frozen dataclasses in the relevant `config.py`.
- Provide pandas helpers if the configuration needs to be displayed or exported.
- Add validation where incorrect values could cause silent misbehavior.
- Update tests and decision records when operator requirements change.
- Avoid introducing hidden environment resolution unless a module clearly requires it.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Guidelines for Creating New Configuration Options
1. Decide whether the option is:
   - A constant threshold.
   - A structured rule.
   - A UI/display setting.
   - An operational parameter.
2. Prefer frozen dataclasses for structured rules.
3. Keep tuples ordered when widget order matters.
4. Add helper functions for DataFrames when the configuration is shown to operators.
5. Add validation only where necessary; prefer early failures with clear messages.
6. Document the operator confirmation date and rationale in module docstrings or comments.
7. If secrets or live identifiers are involved, keep them out of shared artifacts.

[No sources needed since this section provides general guidance]

### Migration and Backward Compatibility Strategy
- Use dated comments to record operator decisions.
- Avoid manual version stamps when cache keys or frozen item lists already invalidate old state.
- Keep backward-compatible defaults where possible.
- Add tests that pin important configuration values.
- When changing request shapes, treat it as a decision requiring review, not a typo fix.

**Section sources**
- [FI Index Change config:1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [FI Spread Movement config:339-344](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L339-L344)
- [FI Spread Movement config:104-117](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L104-L117)