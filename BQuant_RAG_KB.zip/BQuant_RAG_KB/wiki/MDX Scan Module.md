# MDX Scan Module

<cite>
**Referenced Files in This Document**   
- [MAIN.ipynb](file://User scripts/MDX Scan/MAIN.ipynb)
- [app.py](file://User scripts/MDX Scan/mdx_scan/app.py)
- [config.py](file://User scripts/MDX Scan/mdx_scan/config.py)
- [data.py](file://User scripts/MDX Scan/mdx_scan/data.py)
- [mdx_engine.py](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py)
- [26-mdx-scan.md](file://RAG KB/26-mdx-scan.md)
- [MDX_futu_formula.txt](file://User scripts/MDX Scan/Source/MDX_futu_formula.txt)
- [MDX_futu_sig.txt](file://User scripts/MDX Scan/Source/MDX_futu_sig.txt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
The MDX Scan module is a Bloomberg BQuant Desktop application that screens Hang Seng Index (HSI) equities using daily OHLCV data and a pandas port of the MDX v4e technical analysis formula. It retrieves live HSI membership, fetches historical daily bars for members and benchmark indices, computes technical indicators and signals per ticker, and presents results through an interactive Jupyter widget interface with tables, breadth chips, signal legends, and candlestick charts.

The module is intentionally scoped to daily equity screening. It does not implement intraday scanning or scheduled enterprise workloads. The authoritative runtime behavior, data contracts, and reconstruction lessons are documented in the project’s knowledge base entry for MDX Scan.

**Section sources**
- [26-mdx-scan.md:40-54](file://RAG KB/26-mdx-scan.md#L40-L54)
- [26-mdx-scan.md:133-162](file://RAG KB/26-mdx-scan.md#L133-L162)

## Project Structure
The MDX Scan implementation lives under `User scripts/MDX Scan/`. The notebook bootstraps the app, while the Python package provides configuration, data retrieval, the indicator engine, and the interactive UI.

```mermaid
graph TB
Notebook["MAIN.ipynb"] --> App["mdx_scan.app.MDXScanApp"]
App --> Config["mdx_scan.config"]
App --> Data["mdx_scan.data.fetch_scan_payload"]
App --> Engine["mdx_engine.compute_universe<br/>latest_snapshot"]
Data --> BQL["BQL Service / Requests"]
Engine --> Params["MDXParams"]
Engine --> Formula["MDX v4e logic"]
```

**Diagram sources**
- [MAIN.ipynb:19-27](file://User scripts/MDX Scan/MAIN.ipynb#L19-L27)
- [app.py:15-24](file://User scripts/MDX Scan/mdx_scan/app.py#L15-L24)
- [data.py:344-448](file://User scripts/MDX Scan/mdx_scan/data.py#L344-L448)
- [mdx_engine.py:61-276](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L61-L276)
- [config.py:77-98](file://User scripts/MDX Scan/mdx_scan/config.py#L77-L98)

**Section sources**
- [MAIN.ipynb:1-27](file://User scripts/MDX Scan/MAIN.ipynb#L1-L27)
- [app.py:89-101](file://User scripts/MDX Scan/mdx_scan/app.py#L89-L101)
- [data.py:1-29](file://User scripts/MDX Scan/mdx_scan/data.py#L1-L29)
- [mdx_engine.py:1-18](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L1-L18)
- [config.py:1-28](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L28)

## Core Components
The module has four main layers:

| Layer | Responsibility | Key artifacts |
|---|---|---|
| Configuration | Security IDs, lookback ranges, batch size, cooldown, buy lookback, signal ranks/colors/legends, parameter model | `config.py` |
| Data pipeline | BQL requests for HSI members, NameCN metadata, member OHLCV batches, benchmark OHLCV, response parsing and normalization | `data.py` |
| Indicator engine | MDX v4e channel, RSI/KDJ/MACD/CVF/MFI/CCI/WR components, buy/sell/wash/dump/reversal/continuation/squeeze flags, signal labeling | `mdx_engine.py` |
| Application UI | Widgets, refresh/auto-play, filtering, table rendering, benchmark cards, chart plotting, legend display | `app.py` |

The notebook is a thin bootstrap: it prints parser and formula versions, creates the app, renders it, and calls `load_on_start()` once.

**Section sources**
- [MAIN.ipynb:19-27](file://User scripts/MDX Scan/MAIN.ipynb#L19-L27)
- [config.py:24-98](file://User scripts/MDX Scan/mdx_scan/config.py#L24-L98)
- [data.py:344-448](file://User scripts/MDX Scan/mdx_scan/data.py#L344-L448)
- [mdx_engine.py:61-297](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L61-L297)
- [app.py:89-101](file://User scripts/MDX Scan/mdx_scan/app.py#L89-L101)

## Architecture Overview
At runtime, the user triggers a refresh either manually or via the auto-play timer. The app fetches a scan payload from BQL, recomputes MDX bars, attaches member metadata, renders the snapshot table, and draws the selected ticker chart.

```mermaid
sequenceDiagram
participant User as "User"
participant Notebook as "MAIN.ipynb"
participant App as "MDXScanApp"
participant Data as "fetch_scan_payload"
participant BQL as "BQL Service"
participant Engine as "compute_universe"
participant UI as "Plotly + ipydatagrid"
User->>Notebook : Run All
Notebook->>App : create MDXScanApp()
Notebook->>App : render()
Notebook->>App : load_on_start()
App->>Data : fetch_scan_payload(progress)
Data->>BQL : execute(members + OHLCV requests)
BQL-->>Data : responses
Data-->>App : ScanPayload(members, ohlcv, errors)
App->>Engine : compute_universe(ohlcv, params)
Engine-->>App : bar DataFrame
App->>UI : render tables, cards, legend, chart
```

**Diagram sources**
- [MAIN.ipynb:19-27](file://User scripts/MDX Scan/MAIN.ipynb#L19-L27)
- [app.py:375-447](file://User scripts/MDX Scan/mdx_scan/app.py#L375-L447)
- [data.py:344-448](file://User scripts/MDX Scan/mdx_scan/data.py#L344-L448)
- [mdx_engine.py:263-276](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L263-L276)

## Detailed Component Analysis

### Configuration System
The configuration layer centralizes all tuning knobs and reference data:

- **Universe and benchmarks**: HSI index ID, HK cash indices, US futures yellow keys.
- **Data windowing**: 6-month daily history range, member OHLCV batch size.
- **Signal lifecycle**: cooldown bars and buy lookback.
- **Signal ranking and colors**: numeric rank used for default sorting and color mapping for UI.
- **Signal legend**: human-readable definitions for BUY, SELL, WASH, DUMP, REVU, REVD, CONT, SQZ.
- **Parameter model**: frozen dataclass `MDXParams` carrying N1–N5, cooldown, and buy lookback.

Customization points include editing yellow keys when Terminal IDs differ, adjusting lookback ranges, changing batch sizes, and modifying signal parameters through the UI sliders.

```mermaid
classDiagram
class MDXParams {
+int n1
+int n2
+float n3
+int n4
+int n5
+int cooldown
+int buy_lookback
}
class BenchSpec {
+string ticker
+string label
+string group
}
class Config {
+HSI_INDEX
+HK_INDICES
+US_FUTURES
+HISTORY_RANGE_START
+HISTORY_RANGE_END
+MEMBER_OHLCV_BATCH
+COOLDOWN_BARS
+BUY_LOOKBACK
+SIGNAL_RANK
+SIGNAL_COLORS
+SIGNAL_LEGEND
+bench_universe()
+all_bench_tickers()
}
Config --> MDXParams : "uses"
Config --> BenchSpec : "returns"
```

**Diagram sources**
- [config.py:7-30](file://User scripts/MDX Scan/mdx_scan/config.py#L7-L30)
- [config.py:32-98](file://User scripts/MDX Scan/mdx_scan/config.py#L32-L98)

**Section sources**
- [config.py:1-103](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L103)

### Data Pipeline and External Integrations
The data pipeline integrates with Bloomberg BQL to retrieve:

1. **HSI members metadata**: name, sector, and weight.
2. **Chinese security names**: official traditional local language security name merged on `ID`.
3. **Member OHLCV**: daily open/high/low/close/volume over a configured date range, fetched in batches.
4. **Benchmark OHLCV**: separate requests for HK and US benchmark tickers.

Key design characteristics:

- Member metadata uses cached mode; benchmark requests do not attach cached mode.
- Member OHLCV requests use cached mode and are split into batches defined by `MEMBER_OHLCV_BATCH`.
- Responses are normalized to canonical column names such as `Open`, `High`, `Low`, `Close`, `Volume`, `Name`, `Sector`, `Weight`, `ID`, and `DATE`.
- Errors and empty responses are captured rather than failing the whole run.
- The final OHLCV frame is cleaned, deduplicated by `ID` and `DATE`, sorted, and tagged with a bucket indicating whether it belongs to HSI members or benchmarks.

```mermaid
flowchart TD
Start(["Start fetch_scan_payload"]) --> Range["Build date range<br/>and OHLCV items"]
Range --> Members["Request HSI members<br/>Name/Sector/Weight"]
Members --> NameCN["Request NameCN<br/>merge on ID"]
NameCN --> Batch["Chunk member IDs<br/>by MEMBER_OHLCV_BATCH"]
Batch --> MemberOHLCV["Execute member OHLCV requests<br/>mode=cached"]
MemberOHLCV --> Bench["Execute benchmark OHLCV requests"]
Bench --> Parse["Parse responses<br/>normalize columns"]
Parse --> Clean["Clean, deduplicate,<br/>sort OHLCV"]
Clean --> Payload["Return ScanPayload"]
```

**Diagram sources**
- [data.py:344-448](file://User scripts/MDX Scan/mdx_scan/data.py#L344-L448)

**Section sources**
- [data.py:1-29](file://User scripts/MDX Scan/mdx_scan/data.py#L1-L29)
- [data.py:70-74](file://User scripts/MDX Scan/mdx_scan/data.py#L70-L74)
- [data.py:84-150](file://User scripts/MDX Scan/mdx_scan/data.py#L84-L150)
- [data.py:231-305](file://User scripts/MDX Scan/mdx_scan/data.py#L231-L305)
- [data.py:333-341](file://User scripts/MDX Scan/mdx_scan/data.py#L333-L341)
- [data.py:344-448](file://User scripts/MDX Scan/mdx_scan/data.py#L344-L448)

### Technical Indicator Calculation Engine
The engine implements the pandas port of the MDX v4e daily formula. It computes:

- **Channel components**: EMA-based midline, volatility-adjusted upper and lower bands, and band position `PCTB`.
- **Momentum and oscillators**: RSI, KDJ-style KK/DD/JJ, MACD histogram, CMF/MFI, volume ratio, CCI, Williams %R.
- **State flags**: uptrend, pullback, golden/death cross conditions, money flow direction, hammer pattern, washout, dump/grind, oversold oscillator, near-high, bounce, reclaim, deep low, drawdown from 60-day high.
- **Signals**:
  - `BUY`: deep low, low band position, bounce, reclaim, non-down close, significant drawdown, no recent dump, not near recent high.
  - `SELL`: sell-vote score crosses above the threshold after a prior buy within the lookback window.
  - `WASH`: new low plus recovery pattern.
  - `DUMP`: high-volume reversal after quiet rally.
  - `REVU`/`REVD`: percentage-band reversals with RSI confirmation.
  - `CONT`: continuation condition in uptrend with MACD and money flow support.
  - `SQZ`: Bollinger-like bands inside Keltner-like channel.

Signal labeling applies an overwrite order where later flags win: squeeze, continuation, reversal down, reversal up, dump, wash, sell, buy.

```mermaid
flowchart TD
Input["OHLCV per ticker"] --> Channel["Compute MID/UP/DN/PCTB"]
Channel --> Oscillators["RSI/KDJ/MACD/CMF/MFI/CCI/WR"]
Oscillators --> Flags["Buy/Sell/Wash/Dump/Reversal/Continuation/Squeeze flags"]
Flags --> Score["VS/VB composite scores"]
Score --> Cooldown["Cooldown and lookback filters"]
Cooldown --> Label["Signal label with overwrite order"]
Label --> Output["Bars with PCTB, VS, DD60, Chg, Signal, Rank"]
```

**Diagram sources**
- [mdx_engine.py:23-58](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L23-L58)
- [mdx_engine.py:61-247](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L61-L247)
- [mdx_engine.py:250-260](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L250-L260)

**Section sources**
- [mdx_engine.py:1-18](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L1-L18)
- [mdx_engine.py:23-58](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L23-L58)
- [mdx_engine.py:61-247](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L61-L247)
- [mdx_engine.py:250-297](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L250-L297)
- [MDX_futu_formula.txt:1-93](file://User scripts/MDX Scan/Source/MDX_futu_formula.txt#L1-L93)
- [MDX_futu_sig.txt:1-77](file://User scripts/MDX Scan/Source/MDX_futu_sig.txt#L1-L77)

### Chart Visualization and UI Components
The UI layer builds an interactive dashboard:

- **Header and status**: state label, refresh progress, HKT timestamp, parser/formula version logging.
- **Controls**: Refresh button, Play auto-refresh, interval selector, signal filter dropdown, search box, and collapsible MDX parameter sliders.
- **Cards**: benchmark cards showing last price, change, points, and signal color.
- **Breadth chips**: counts of actionable signals across HSI members.
- **Table**: ipydatagrid grid displaying name, Chinese name, signal, change, last price, weight, sector, PCTB, VS, DD60, and last buy date.
- **Chart**: Plotly candlestick with MID/UP/DN lines and markers for BUY, SELL, WASH, DUMP, REVU, REVD.
- **Legends**: signal legend and metric legend explaining PCTB, VS, and DD60.

The app attaches member metadata to the latest snapshot, groups tickers into HK/US/HSI categories, and updates the chart title with current signal metrics.

```mermaid
graph TB
Controls["Refresh/Auto/Interval/Filter/Search/Parameters"] --> AppLogic["MDXScanApp._refresh/_recompute_and_draw"]
AppLogic --> Snapshot["Latest snapshot with Signal/Rank/Chg/PCTB/VS/DD60"]
Snapshot --> Cards["Benchmark cards"]
Snapshot --> Breadth["HSI breadth chips"]
Snapshot --> Grid["ipypdatagrid table"]
Snapshot --> Chart["Plotly candlestick + signals"]
Legend["Signal & Metric legends"] --> UI["HTML widgets"]
```

**Diagram sources**
- [app.py:111-280](file://User scripts/MDX Scan/mdx_scan/app.py#L111-L280)
- [app.py:449-537](file://User scripts/MDX Scan/mdx_scan/app.py#L449-L537)
- [app.py:539-666](file://User scripts/MDX Scan/mdx_scan/app.py#L539-L666)
- [app.py:714-770](file://User scripts/MDX Scan/mdx_scan/app.py#L714-L770)
- [app.py:784-873](file://User scripts/MDX Scan/mdx_scan/app.py#L784-L873)

**Section sources**
- [app.py:27-87](file://User scripts/MDX Scan/mdx_scan/app.py#L27-L87)
- [app.py:89-101](file://User scripts/MDX Scan/mdx_scan/app.py#L89-L101)
- [app.py:111-280](file://User scripts/MDX Scan/mdx_scan/app.py#L111-L280)
- [app.py:359-447](file://User scripts/MDX Scan/mdx_scan/app.py#L359-L447)
- [app.py:449-537](file://User scripts/MDX Scan/mdx_scan/app.py#L449-L537)
- [app.py:539-666](file://User scripts/MDX Scan/mdx_scan/app.py#L539-L666)
- [app.py:714-770](file://User scripts/MDX Scan/mdx_scan/app.py#L714-L770)
- [app.py:784-873](file://User scripts/MDX Scan/mdx_scan/app.py#L784-L873)

## Dependency Analysis
The module has clear layering with minimal coupling between concerns:

- `MAIN.ipynb` depends only on the app constructor and version constants.
- `app.py` depends on configuration, data fetching, and the engine.
- `data.py` depends on configuration and BQL.
- `mdx_engine.py` depends only on configuration and pandas/numpy.

```mermaid
graph LR
MAIN["MAIN.ipynb"] --> APP["app.py"]
APP --> CFG["config.py"]
APP --> DATA["data.py"]
APP --> ENG["mdx_engine.py"]
DATA --> CFG
ENG --> CFG
DATA --> BQL["BQL Service"]
```

**Diagram sources**
- [MAIN.ipynb:19-27](file://User scripts/MDX Scan/MAIN.ipynb#L19-L27)
- [app.py:15-24](file://User scripts/MDX Scan/mdx_scan/app.py#L15-L24)
- [data.py:14-20](file://User scripts/MDX Scan/mdx_scan/data.py#L14-L20)
- [mdx_engine.py:12-18](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L12-L18)

**Section sources**
- [MAIN.ipynb:19-27](file://User scripts/MDX Scan/MAIN.ipynb#L19-L27)
- [app.py:15-24](file://User scripts/MDX Scan/mdx_scan/app.py#L15-L24)
- [data.py:14-20](file://User scripts/MDX Scan/mdx_scan/data.py#L14-L20)
- [mdx_engine.py:12-18](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L12-L18)

## Performance Considerations
The codebase includes several performance-oriented patterns:

- **Batching**: Member OHLCV requests are chunked by `MEMBER_OHLCV_BATCH` to avoid oversized requests.
- **Caching**: Member metadata and member OHLCV requests use cached mode; benchmark requests do not attach cached mode because caching is per-request.
- **Vectorized computation**: The engine uses pandas rolling, exponential weighted, and vectorized boolean operations instead of row-wise loops.
- **Efficient merging**: Member metadata is merged once on `ID`, and duplicate rows are removed before downstream processing.
- **Incremental UI updates**: The chart uses batch updates and conditional marker updates to reduce redraw cost.
- **Local filtering**: Table filtering and search operate on already-fetched snapshots to avoid repeated network calls.

Best practices derived from the implementation:

- Keep `HISTORY_RANGE_START` long enough for EMA60, HHV60, and buy-history lookbacks.
- Use appropriate batch sizes for large universes.
- Avoid adding intraday scans unless the formula and data pipeline are explicitly adapted.
- Prefer parameter changes over refetches when possible; the UI supports recompute without refetching when OHLCV is already loaded.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Data Source Connectivity
Symptoms:
- No OHLCV returned.
- Missing DATE column.
- Empty members or missing NameCN.

Checks:
- Ensure the environment is Bloomberg BQuant Desktop; the data layer raises an error if BQL is unavailable.
- Verify yellow keys for HSI, HK indices, and US futures in configuration.
- Confirm entitlements for `members`, `name`, `classification_name`, `id()['weights']`, and `official_trad_local_lang_sec_nm`.
- Check that the date range produces daily bars and not a single snapshot.
- Inspect the log for request notes and parser/formula versions.

Relevant behaviors:
- The app logs parser and formula versions on refresh.
- Request errors are collected and displayed rather than aborting the entire run.
- Missing DATE causes an explicit error note.

**Section sources**
- [data.py:70-74](file://User scripts/MDX Scan/mdx_scan/data.py#L70-L74)
- [data.py:308-325](file://User scripts/MDX Scan/mdx_scan/data.py#L308-L325)
- [data.py:433-440](file://User scripts/MDX Scan/mdx_scan/data.py#L433-L440)
- [app.py:418-447](file://User scripts/MDX Scan/mdx_scan/app.py#L418-L447)
- [26-mdx-scan.md:120-122](file://RAG KB/26-mdx-scan.md#L120-L122)

### Indicator Calculations
Symptoms:
- Unexpected BUY signals on down bars.
- Incorrect smoothing or standard deviation values.
- Signals not matching the original Futu/TDX formula.

Checks:
- Confirm Wilder smoothing for SMA-like components and EMA alpha calculation.
- Confirm population standard deviation (`ddof=0`).
- Confirm the BOT condition requires `Close >= Open`.
- Confirm the overwrite order of signals.
- Validate parameters N1–N5, cooldown, and buy lookback.

Relevant behaviors:
- The engine documents the v4e port rules and the daily-only scope.
- The formula file defines the authoritative MDX v4e logic.
- The knowledge base records the correct smoothing and threshold conventions.

**Section sources**
- [mdx_engine.py:1-8](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L1-L8)
- [mdx_engine.py:23-40](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L23-L40)
- [mdx_engine.py:160-169](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L160-L169)
- [mdx_engine.py:250-260](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L250-L260)
- [MDX_futu_formula.txt:1-6](file://User scripts/MDX Scan/Source/MDX_futu_formula.txt#L1-L6)
- [26-mdx-scan.md:145-159](file://RAG KB/26-mdx-scan.md#L145-L159)

### Signal Accuracy
Symptoms:
- BUY appears too often or too rarely.
- SELL fires without a prior buy.
- WASH/DUMP/REVU/REVD labels seem inconsistent.

Checks:
- Review the signal overwrite order: SQZ → CONT → REVD → REVU → DUMP → WASH → SELL → BUY.
- Verify cooldown prevents repeated signals within the configured window.
- Verify buy lookback ensures SELL requires a prior BUY.
- Compare against the source formula and subplot signal file.

Relevant behaviors:
- Signal labeling applies later flags over earlier ones.
- Cooldown and lookback are configurable through `MDXParams`.
- The subplot signal file shares the same BOT and signal logic.

**Section sources**
- [mdx_engine.py:250-260](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L250-L260)
- [mdx_engine.py:196-203](file://User scripts/MDX Scan/mdx_scan/mdx_engine.py#L196-L203)
- [config.py:32-68](file://User scripts/MDX Scan/mdx_scan/config.py#L32-L68)
- [MDX_futu_sig.txt:1-5](file://User scripts/MDX Scan/Source/MDX_futu_sig.txt#L1-L5)

### UI and Display Issues
Symptoms:
- No chart updates.
- Ticker dropdown not populated.
- Legends not visible.
- Auto-play not refreshing.

Checks:
- Ensure the kernel was restarted after replacing `.py` files.
- Confirm `load_on_start()` is called once.
- Confirm Play interval is in milliseconds.
- Confirm legend HTML nodes are present after the table/chart container.

Relevant behaviors:
- The notebook calls `display(app.render())` then `load_on_start()`.
- The app binds events for refresh, auto-play, interval, filter, search, ticker selection, and parameter sliders.
- The footer explains daily-only scanning and restart requirements.

**Section sources**
- [MAIN.ipynb:19-27](file://User scripts/MDX Scan/MAIN.ipynb#L19-L27)
- [app.py:359-370](file://User scripts/MDX Scan/mdx_scan/app.py#L359-L370)
- [app.py:418-447](file://User scripts/MDX Scan/mdx_scan/app.py#L418-L447)
- [app.py:241-252](file://User scripts/MDX Scan/mdx_scan/app.py#L241-L252)
- [26-mdx-scan.md:186-200](file://RAG KB/26-mdx-scan.md#L186-L200)

## Conclusion
The MDX Scan module provides a disciplined, daily-only equity screening workflow for HSI members. Its architecture cleanly separates configuration, data retrieval, indicator computation, and visualization. The technical indicator engine is a faithful pandas port of the MDX v4e formula, with explicit handling of smoothing, thresholds, cooldown, lookback, and signal overwrite semantics. The data pipeline integrates with BQL, caches appropriately, and normalizes heterogeneous responses. The UI exposes practical customization options for screening parameters and strategy interpretation.

For reliable operation, users should keep the yellow keys accurate, preserve the daily-only scope, respect the required history warmup, and interpret signals according to the documented overwrite order and thresholds. When issues arise, the layered error collection, version logging, and explicit data contracts make it straightforward to isolate connectivity, parsing, calculation, or display problems.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Customization Options Summary
- **Security IDs**: Edit HK and US benchmark tickers in configuration if Terminal IDs differ.
- **History window**: Adjust start/end date range for EMA60/HHV60/buy-history warmup.
- **Batch size**: Tune `MEMBER_OHLCV_BATCH` for performance vs. request limits.
- **Signal parameters**: Use the UI sliders for N1, N2, N3, N5; cooldown and buy lookback are also configurable through the parameter model.
- **Filtering**: Filter by actionable signals or specific signal types; search by ticker, English name, or Chinese name.
- **Auto-refresh**: Select interval in milliseconds and use Play with Loop enabled.

**Section sources**
- [config.py:7-30](file://User scripts/MDX Scan/mdx_scan/config.py#L7-L30)
- [config.py:77-86](file://User scripts/MDX Scan/mdx_scan/config.py#L77-L86)
- [app.py:124-190](file://User scripts/MDX Scan/mdx_scan/app.py#L124-L190)
- [app.py:551-576](file://User scripts/MDX Scan/mdx_scan/app.py#L551-L576)

### Data Processing Pipeline Reference
- **Members**: Live universe from `bq.univ.members('HSI Index')`.
- **Metadata**: Name, Sector, Weight from first request; NameCN from second request merged on `ID`.
- **OHLCV**: Daily Open/High/Low/Close/Volume over `-6m` to `0d`, batched for members, separate for benchmarks.
- **Normalization**: Canonical column names, datetime conversion, numeric coercion, deduplication, sorting.
- **Output**: `ScanPayload` containing members, ohlcv, and errors.

**Section sources**
- [data.py:344-448](file://User scripts/MDX Scan/mdx_scan/data.py#L344-L448)
- [26-mdx-scan.md:66-118](file://RAG KB/26-mdx-scan.md#L66-L118)