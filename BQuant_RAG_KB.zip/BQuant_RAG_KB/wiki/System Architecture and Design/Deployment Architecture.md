# Deployment Architecture

<cite>
**Referenced Files in This Document**   
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md](file://RAG KB/05-get-started.md)
- [config.py (ETF Capping Monitoring)](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [config.py (ETF Spread Monitoring)](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
- [config.py (FI Index Change)](file://User scripts/FI Index Change/fi_index_change/config.py)
- [config.py (FI Spread Movement Monitoring)](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [config.py (MDX Scan)](file://User scripts/MDX Scan/mdx_scan/config.py)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the deployment architecture for the Bloomberg BQuant analytical applications in this repository. The project is explicitly scoped to **Bloomberg BQuant Desktop**, not BQuant Enterprise. Applications are authored locally in Cursor and executed only inside a Terminal-connected BQuant Desktop workload. There is no production server, scheduler, custom image, or managed Git pipeline in scope; operational delivery consists of copying approved notebook packages into a user’s BQuant Desktop project and running them interactively.

The key architectural constraints are:
- Local development is for design, review, and static checks.
- Live Bloomberg data access runs only on the work Bloomberg machine through BQL inside JupyterLab kernels.
- Each application is an independent Python package plus a `MAIN.ipynb` entry point.
- Configuration is per-application and stored as Python constants.
- Sensitive runbook data is kept separate from code where required.
- Cache files are local to each Desktop project folder.
- Versioning and change control are maintained through repository documentation and per-project decision records rather than automated CI/CD.

## Project Structure
The workspace contains:
- A top-level instruction file describing current procedures and cross-platform rules.
- A RAG knowledge base documenting platform behavior, data patterns, and project-specific runtime authority.
- Multiple independent analytical applications under `User scripts/`, each with its own package, tests, preview tooling, and upload mirror.
- Cross-cutting version and task logs at the repository root.

```mermaid
graph TB
Root["Repository Root"]
Instructions["instruction.md"]
KB["RAG KB"]
Scripts["User scripts"]
ETF_Capping["ETF Capping Monitoring"]
ETF_Spread["ETF Spread Monitoring"]
FI_Index["FI Index Change"]
FI_Spread["FI Spread Movement Monitoring"]
MDX["MDX Scan"]
VersionLog["VersionLog.md"]
Root --> Instructions
Root --> KB
Root --> Scripts
Root --> VersionLog
Scripts --> ETF_Capping
Scripts --> ETF_Spread
Scripts --> FI_Index
Scripts --> FI_Spread
Scripts --> MDX
```

**Diagram sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-37](file://RAG KB/05-get-started.md#L21-L37)

**Section sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:21-37](file://RAG KB/05-get-started.md#L21-L37)

## Core Components
Each analytical application follows a consistent shape:
- A Python package containing configuration, data fetching, engine logic, caching, and UI/app wiring.
- A `MAIN.ipynb` notebook that initializes the environment and exposes interactive controls.
- Optional tests and preview tooling used during local development.
- An `Upload/` mirror used when copying the runnable package onto Bloomberg Desktop.

| Application | Primary Purpose | Runtime Entry Point | Key Configuration File |
|---|---|---|---|
| ETF Capping Monitoring | AIM account capping and fund exposure monitoring | `User scripts/ETF Capping Monitoring/MAIN.ipynb` | `User scripts/ETF Capping Monitoring/etf_capping/config.py` |
| ETF Spread Monitoring | ETF spread, returns, NAV, and flow history with local cache | `User scripts/ETF Spread Monitoring/MAIN.ipynb` | `User scripts/ETF Spread Monitoring/etf_spread/config.py` |
| FI Index Change | Fixed-income index membership and analytics comparison across month-ends | `User scripts/FI Index Change/MAIN.ipynb` | `User scripts/FI Index Change/fi_index_change/config.py` |
| FI Spread Movement Monitoring | Ranked fixed-income spread movers by universe source | `User scripts/FI Spread Movement Monitoring/MAIN.ipynb` | `User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py` |
| MDX Scan | MDX signal scanning over selected indices and futures | `User scripts/MDX Scan/MAIN.ipynb` | `User scripts/MDX Scan/mdx_scan/config.py` |

**Section sources**
- [instruction.md:13-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [config.py (ETF Capping Monitoring):1-269](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L269)
- [config.py (ETF Spread Monitoring):1-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L1-L140)
- [config.py (FI Index Change):1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [config.py (FI Spread Movement Monitoring):1-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L389)
- [config.py (MDX Scan):1-103](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L103)

## Architecture Overview
The deployment model is a two-stage workflow:

1. **Local authoring:** Code, notebooks, tests, and preview pages are developed in Cursor on the operator’s Mac.
2. **Desktop execution:** Approved artifacts are copied into a BQuant Desktop project and executed inside a Terminal-connected JupyterLab kernel.

```mermaid
flowchart LR
Local["Local Cursor<br/>Design, review, tests, preview"] --> Copy["Manual copy to Bloomberg Desktop"]
Copy --> Kernel["BQuant Desktop JupyterLab<br/>Python 3.11 kernel"]
Kernel --> BQL["Bloomberg Query Language"]
BQL --> Terminal["Bloomberg Terminal session"]
```

**Diagram sources**
- [05-get-started.md:21-37](file://RAG KB/05-get-started.md#L21-L37)
- [05-get-started.md:81-86](file://RAG KB/05-get-started.md#L81-L86)

### Environment Boundaries
| Area | Allowed | Not allowed without explicit confirmation |
|---|---|---|
| IDE | Cursor locally; JupyterLab on Desktop | Custom environments or external package installs outside the managed workflow |
| Data access | BQL through `bq.execute` | External internet APIs |
| Compute | Single-user Desktop workload | Scalable compute, scheduled jobs, or enterprise-only features |
| Storage | Project files and local cache folders | Sandbox object storage or custom dataset mounts |
| Publishing | Limited Launchpad publishing | Unlimited transfer or unrestricted distribution |

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [05-get-started.md:99-138](file://RAG KB/05-get-started.md#L99-L138)

## Detailed Component Analysis

### Bloomberg Desktop Deployment Model
Bloomberg Desktop provides a managed Ubuntu-based Python 3.11 environment with JupyterLab 4.3.6 and preconfigured extensions. Applications must import only supported libraries such as BQL, Pandas, Plotly, and ipywidgets. Network connectivity to Bloomberg services is provided by the platform; notebook code should not implement custom network workarounds.

Key operational limits include:
- Maximum two concurrent project workloads.
- Individual project file size limit of 256 MB.
- BQL request timeout after approximately two minutes.
- One running instance per owned project.
- Workload shutdown after inactivity or maximum runtime.

```mermaid
flowchart TD
Start["Open BQuant Desktop project"] --> KernelCheck["Confirm Python 3.11 kernel"]
KernelCheck --> Setup["Import pandas, bql, create bq service"]
Setup --> Request["Build and execute BQL request"]
Request --> Result["Convert response to DataFrame"]
Result --> Interactive["Use ipywidgets and Plotly for analysis"]
```

**Diagram sources**
- [05-get-started.md:41-59](file://RAG KB/05-get-started.md#L41-L59)
- [05-get-started.md:207-223](file://RAG KB/05-get-started.md#L207-L223)

**Section sources**
- [05-get-started.md:21-37](file://RAG KB/05-get-started.md#L21-L37)
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [05-get-started.md:130-144](file://RAG KB/05-get-started.md#L130-L144)
- [05-get-started.md:207-248](file://RAG KB/05-get-started.md#L207-L248)

### Local Development Environment Setup
Local development uses Cursor for authoring and review. The repository includes per-project instructions for copying the correct files into a Desktop project, restarting the kernel, and running the notebook cell. Tests and preview servers are local-only and do not send live Bloomberg requests.

Recommended setup steps:
1. Use Cursor to edit notebooks and packages.
2. Run local unit tests where available.
3. Use preview servers for layout validation where provided.
4. Copy only the approved runtime files into the Desktop project.
5. Restart the Desktop kernel before testing changes.
6. Execute BQL only inside BQuant Desktop or Terminal-connected kernels.

```mermaid
flowchart TD
Author["Edit in Cursor"] --> Test["Run local tests"]
Test --> Preview["Run preview server if available"]
Preview --> Copy["Copy approved files to Desktop project"]
Copy --> KernelRestart["Restart Desktop kernel"]
KernelRestart --> Execute["Run MAIN.ipynb Update"]
```

**Diagram sources**
- [instruction.md:13-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:81-86](file://RAG KB/05-get-started.md#L81-L86)

**Section sources**
- [instruction.md:13-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:81-86](file://RAG KB/05-get-started.md#L81-L86)

### Production Deployment Topology
There is no traditional production topology. “Production” in this repository means the approved Desktop application that operators run on their Bloomberg Desktop workload. The topology is therefore:

- Operator workstation running Cursor.
- Bloomberg-managed Desktop workload running JupyterLab.
- BQL client connecting to Bloomberg services through the existing Terminal/BBA connection.

```mermaid
graph TB
Operator["Operator workstation<br/>Cursor"]
Desktop["Bloomberg Desktop<br/>JupyterLab + Python 3.11"]
BQLClient["BQL client"]
Services["Bloomberg services"]
Operator --> Desktop
Desktop --> BQLClient
BQLClient --> Services
```

**Diagram sources**
- [05-get-started.md:21-37](file://RAG KB/05-get-started.md#L21-L37)
- [05-get-started.md:235-238](file://RAG KB/05-get-started.md#L235-L238)

#### Network Requirements
- Connectivity is provided by Bloomberg Desktop and Terminal.
- Do not add notebook-level network workarounds.
- If the kernel stays on Connecting, use Bloomberg diagnostics to check WebSockets and the BBA/session connection.

#### Security and Access Controls
- Only approved BQL data items and universe calls may be used.
- ESG, GHG, climate, sustainable-finance, and other restricted categories are explicitly blocked by project policy.
- Sensitive runbook data is separated from code where applicable.
- No external API calls are allowed from BQuant notebooks or apps.

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [05-get-started.md:235-238](file://RAG KB/05-get-started.md#L235-L238)
- [config.py (ETF Capping Monitoring):1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)

### Configuration Management Strategy
Configuration is centralized per application in a dedicated `config.py`. This keeps business rules, display settings, request shapes, and operational defaults close to the code that consumes them.

| Application | Configuration Focus |
|---|---|
| ETF Capping Monitoring | AIM account rules, thresholds, status colors, Thai pricing overrides, primary fund manager mapping |
| ETF Spread Monitoring | Share class directory, peer groups, observation columns, default periods, history window |
| FI Index Change | Default index/book, country overrides, rating labels, filter widths, split requests, retry attempts, cache directory |
| FI Spread Movement Monitoring | Universe sources, spread types, descriptor fields, duration measures, date windows, cache retention, numeric result columns |
| MDX Scan | Index tickers, futures, lookback ranges, batch sizes, signal ranks and colors |

```mermaid
flowchart TD
Config["Per-app config.py"] --> App["Application logic"]
Config --> Notebook["MAIN.ipynb"]
Config --> Tests["Unit tests"]
Config --> Upload["Upload mirror"]
```

**Diagram sources**
- [config.py (ETF Capping Monitoring):1-269](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L269)
- [config.py (ETF Spread Monitoring):1-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L1-L140)
- [config.py (FI Index Change):1-133](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L133)
- [config.py (FI Spread Movement Monitoring):1-389](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L389)
- [config.py (MDX Scan):1-103](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L103)

#### Environment-Specific Settings
The repository does not define separate development, testing, and production environment variables. Instead, it relies on:
- Per-application configuration modules.
- Explicit operator inputs in notebooks.
- Separate redacted or mirrored outputs where sensitive data must not be committed.
- Decision records and version logs documenting why a setting exists.

#### Sensitive Credential Handling
- Sensitive runbook data is kept out of the main configuration module where stated.
- The ETF Capping Monitoring configuration explicitly documents that a redacted output copy must not be imported in production.
- Restricted data categories are enforced by policy and test/build-time checks.

**Section sources**
- [config.py (ETF Capping Monitoring):1-5](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L5)
- [config.py (ETF Capping Monitoring):14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [config.py (ETF Capping Monitoring):52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [config.py (ETF Capping Monitoring):127-183](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L127-L183)

### Monitoring and Logging Strategies
Monitoring is primarily interactive and log-driven:
- Status lines indicate whether a run is updated, cached, partial, or incomplete.
- Step logs record local processing stages, failed fields, and diagnostic notes.
- Request logs capture timing and attempt counts.
- Export tabs provide copyable tables for audit and troubleshooting.

```mermaid
sequenceDiagram
participant User as "Operator"
participant Notebook as "MAIN.ipynb"
participant Engine as "Application engine"
participant Cache as "Local cache"
participant BQL as "BQL"
User->>Notebook : Click Update
Notebook->>Engine : Build request
Engine->>Cache : Check cache if enabled
alt Cache hit
Cache-->>Engine : Return saved run
Engine-->>Notebook : Render cached result
else Cache miss or disabled
Engine->>BQL : Execute request
alt Timeout
BQL-->>Engine : Timeout
Engine->>Cache : Load saved run if available
Cache-->>Engine : Cached result
Engine-->>Notebook : Show Cached status
else Success
BQL-->>Engine : Response
Engine->>Cache : Save run if valid
Engine-->>Notebook : Show Updated status
end
end
```

**Diagram sources**
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)

**Section sources**
- [config.py (FI Spread Movement Monitoring):324-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L324-L371)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)

### Backup and Recovery Procedures
Backup and recovery are local to each Desktop project:
- ETF Spread Monitoring stores daily history as CSV files under a `cache/` folder beside `MAIN.ipynb`, along with a manifest.
- FI Spread Movement Monitoring stores ranked results, descriptors, series, and a manifest under a `cache/` folder.
- FI Index Change uses a `cache/` directory name and invalidates entries when field contracts change.
- Cache writes are guarded against empty frames, missing columns, and read-only project folders.

```mermaid
flowchart TD
Run["Completed run"] --> Validate["Validate frame shape"]
Validate --> Valid{"Valid?"}
Valid --> |No| Skip["Do not write cache"]
Valid --> |Yes| Write["Write cache files"]
Write --> Manifest["Update manifest"]
Manifest --> Prune["Prune old runs if configured"]
```

**Diagram sources**
- [config.py (ETF Spread Monitoring):15-22](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L22)
- [config.py (FI Index Change):122-133](file://User scripts/FI Index Change/fi_index_change/config.py#L122-L133)
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)

**Section sources**
- [config.py (ETF Spread Monitoring):15-22](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L22)
- [config.py (FI Index Change):122-133](file://User scripts/FI Index Change/fi_index_change/config.py#L122-L133)
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)

### Versioning Strategy and Upgrade Procedures
Versioning is manual and evidence-driven:
- `VersionLog.md` is append-only and records decisions, defects, and verification outcomes.
- Per-project decision records and READMEs document runtime behavior.
- Configuration modules intentionally avoid mutable version stamps where possible; cache keys and field contracts provide safer invalidation.
- Upgrades require Desktop measurement because Desktop has different timeouts, response shapes, and library versions than local environments.

```mermaid
flowchart TD
Change["Code or configuration change"] --> Test["Run local tests"]
Test --> Preview["Rebuild preview if applicable"]
Preview --> Sync["Sync Upload mirrors"]
Sync --> Verify["Verify desktop-compatible behavior"]
Verify --> Record["Record decision in VersionLog or decision record"]
```

**Diagram sources**
- [VersionLog.md:1-20](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [config.py (FI Index Change):1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [config.py (FI Spread Movement Monitoring):339-344](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L339-L344)

**Section sources**
- [VersionLog.md:1-20](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [config.py (FI Index Change):1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [config.py (FI Spread Movement Monitoring):339-344](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L339-L344)

### Relationship Between Local Development and Production Deployment Pipelines
There is no automated deployment pipeline. The relationship is:

- Local Cursor is the authoring environment.
- Local tests and preview tools validate logic and layout.
- Approved artifacts are manually copied into a BQuant Desktop project.
- Operators restart the kernel and run the notebook.
- Changes are recorded in `VersionLog.md`, per-project decision records, and updated instructions.

```mermaid
flowchart LR
Dev["Local development<br/>Cursor + tests + preview"] --> Gate["Review and approval"]
Gate --> Artifact["Approved package + notebook"]
Artifact --> Desktop["Bloomberg Desktop project"]
Desktop --> Operator["Operator-run application"]
```

**Diagram sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:81-86](file://RAG KB/05-get-started.md#L81-L86)

**Section sources**
- [instruction.md:1-11](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:84-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [05-get-started.md:81-86](file://RAG KB/05-get-started.md#L81-L86)

## Dependency Analysis
Applications depend on:
- Python 3.11 runtime provided by BQuant Desktop.
- Managed libraries including Pandas, Plotly, and ipywidgets.
- BQL for data access.
- Local cache files for performance and fallback.
- Per-project configuration modules for business rules and display behavior.

```mermaid
graph TB
Python["Python 3.11"]
Libraries["Pandas / Plotly / ipywidgets"]
BQL["BQL"]
Config["Per-app config.py"]
Apps["Analytical applications"]
Cache["Local cache"]
Python --> Libraries
Python --> BQL
Config --> Apps
Cache --> Apps
BQL --> Apps
```

**Diagram sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [05-get-started.md:225-248](file://RAG KB/05-get-started.md#L225-L248)
- [config.py (ETF Capping Monitoring):1-11](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L11)
- [config.py (ETF Spread Monitoring):1-12](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L1-L12)
- [config.py (FI Index Change):1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [config.py (FI Spread Movement Monitoring):1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)
- [config.py (MDX Scan):1-5](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L5)

**Section sources**
- [05-get-started.md:65-69](file://RAG KB/05-get-started.md#L65-L69)
- [05-get-started.md:225-248](file://RAG KB/05-get-started.md#L225-L248)
- [config.py (ETF Capping Monitoring):1-11](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L11)
- [config.py (ETF Spread Monitoring):1-12](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L1-L12)
- [config.py (FI Index Change):1-10](file://User scripts/FI Index Change/fi_index_change/config.py#L1-L10)
- [config.py (FI Spread Movement Monitoring):1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)
- [config.py (MDX Scan):1-5](file://User scripts/MDX Scan/mdx_scan/config.py#L1-L5)

## Performance Considerations
Performance is constrained by Desktop limits and Bloomberg request behavior:
- Keep universes and date ranges narrow.
- Split heavy requests into smaller measure families.
- Use cached mode where supported.
- Avoid unbounded pulls.
- Measure elapsed time on Desktop rather than assuming local performance applies.
- Respect the two-minute BQL timeout and the 256 MB project file limit.

```mermaid
flowchart TD
Start["Build request"] --> Narrow["Narrow universe and dates"]
Narrow --> Split{"Heavy request?"}
Split --> |Yes| SplitRequest["Split into smaller measure families"]
Split --> |No| Execute["Execute request"]
SplitRequest --> Execute
Execute --> Timeout{"Timeout?"}
Timeout --> |Yes| Retry["Retry once if configured"]
Timeout --> |No| Cache["Save valid result if cache enabled"]
Retry --> Fallback["Load saved run if available"]
Cache --> Done["Render result"]
Fallback --> Done
```

**Diagram sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)

## Troubleshooting Guide
Common issues and their documented resolutions:

| Symptom | Likely Cause | Resolution |
|---|---|---|
| Kernel stays on Connecting | WebSocket or BBA/session issue | Run Bloomberg diagnostics; verify Terminal login; reconnect before changing code |
| No kernel or cells do nothing | Kernel selection or workload state | Select or restart the kernel; shut down and reopen the workload if needed |
| BQL timeout | Large universe, too many items, or heavy measure | Narrow request, split analytics, or use cached mode |
| BQL 403 or queries do not execute | Missing Terminal session or changed connection | Log in to Terminal and restore the BBA/session connection |
| File save error | Project file exceeds 256 MB or temporary artifacts are too large | Move temporary data to `/tmp`; remove oversized generated output |
| Widget compatibility errors | ipywidgets or JupyterLab version mismatch | Re-test callbacks and upload widgets after environment upgrades |
| Stale preview page | Page rendered by older code | Reload the browser or rebuild the preview server |
| Cache not written | Read-only Desktop project folder | Treat as a status note; Refresh still completes but cannot persist cache |

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [05-get-started.md:210-213](file://RAG KB/05-get-started.md#L210-L213)
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)

## Conclusion
The Bloomberg BQuant deployment model in this repository is intentionally simple and Desktop-bound. Applications are designed locally, reviewed against platform constraints, and deployed by copying approved artifacts into a user’s BQuant Desktop project. Configuration is per-application, credentials and sensitive runbook data are separated where required, and operational visibility comes from interactive status, step logs, request logs, and export tables. Versioning is manual and evidence-driven, backed by `VersionLog.md` and per-project records. Because there is no automated production pipeline, consistency depends on disciplined local testing, preview validation, Upload mirroring, and Desktop verification before promoting changes.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Appendix A: Desktop Hard Limits Summary
| Limit | Value |
|---|---|
| Concurrent project workloads | Two |
| Owned projects | Two hundred |
| Published apps | Two hundred |
| Active app consumers | Two |
| Project file size | 256 MB |
| BQL request timeout | Approximately two minutes |
| Workload maximum runtime | 24 hours |

**Section sources**
- [05-get-started.md:130-138](file://RAG KB/05-get-started.md#L130-L138)

### Appendix B: Application Configuration Reference
| Application | Important Operational Defaults |
|---|---|
| ETF Capping Monitoring | Account rules, thresholds, status colors, Thai pricing overrides, primary FM mapping |
| ETF Spread Monitoring | Default period, history business days, share class directory, peer group structure |
| FI Index Change | Default index/book, split requests, query attempts, cache directory |
| FI Spread Movement Monitoring | Universe sources, spread types, descriptor fields, duration fields, date window, cache retention |
| MDX Scan | Index and futures tickers, history range, member batch size, signal rank and color mapping |

**Section sources**
- [config.py (ETF Capping Monitoring):14-23](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L23)
- [config.py (ETF Capping Monitoring):52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [config.py (ETF Capping Monitoring):127-183](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L127-L183)
- [config.py (ETF Spread Monitoring):15-22](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L22)
- [config.py (ETF Spread Monitoring):35-81](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L35-L81)
- [config.py (ETF Spread Monitoring):88-140](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L88-L140)
- [config.py (FI Index Change):12-16](file://User scripts/FI Index Change/fi_index_change/config.py#L12-L16)
- [config.py (FI Index Change):88-104](file://User scripts/FI Index Change/fi_index_change/config.py#L88-L104)
- [config.py (FI Index Change):122-133](file://User scripts/FI Index Change/fi_index_change/config.py#L122-L133)
- [config.py (FI Spread Movement Monitoring):26-40](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L40)
- [config.py (FI Spread Movement Monitoring):49-55](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L49-L55)
- [config.py (FI Spread Movement Monitoring):112-117](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L112-L117)
- [config.py (FI Spread Movement Monitoring):129-136](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L129-L136)
- [config.py (FI Spread Movement Monitoring):177-182](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L177-L182)
- [config.py (FI Spread Movement Monitoring):193-196](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L193-L196)
- [config.py (FI Spread Movement Monitoring):349-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L349-L371)
- [config.py (MDX Scan):6-15](file://User scripts/MDX Scan/mdx_scan/config.py#L6-L15)
- [config.py (MDX Scan):24-30](file://User scripts/MDX Scan/mdx_scan/config.py#L24-L30)
- [config.py (MDX Scan):33-55](file://User scripts/MDX Scan/mdx_scan/config.py#L33-L55)