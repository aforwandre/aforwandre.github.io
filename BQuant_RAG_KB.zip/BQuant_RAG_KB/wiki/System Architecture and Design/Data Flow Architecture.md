# Data Flow Architecture

<cite>
**Referenced Files in This Document**
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the Bloomberg BQuant data flow architecture across three related monitoring applications: ETF capping, ETF spread monitoring, and fixed-income index change detection. It traces the complete pipeline from user interface interactions through widget events to Bloomberg BQL queries, Pandas-based transformation, caching, visualization, and error handling. The focus is on how event-driven state changes trigger data refresh cycles, how Bloomberg API responses are ingested and validated, and how consistency and rollback strategies protect users when requests fail.

The repository contains separate project folders under `User scripts`, each with its own application controller, data layer, engine, and configuration. A shared operational protocol is documented at the workspace root.

## Project Structure
The relevant codebase is organized by feature rather than by technical layer:

- `User scripts/ETF Capping Monitoring/etf_capping/` — AIM position capping dashboard.
- `User scripts/ETF Spread Monitoring/etf_spread/` — HSBC book, peer comparison, flows heatmap, and history cache.
- `User scripts/FI Index Change/fi_index_change/` — Fixed-income index constituent change analysis.
- `instruction.md` — Cross-platform operational instructions for all projects.

```mermaid
graph TB
UI["ipywidgets Dashboard"] --> Controller["Application Controller"]
Controller --> DataLayer["BQL Data Layer"]
Controller --> Engine["Pandas Transformation Engine"]
Controller --> Cache["Local History Cache"]
DataLayer --> BQL["Bloomberg BQL Service"]
Engine --> Visualization["Tables, Charts, Status"]
Cache --> Visualization
```

**Diagram sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [data.py:25-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L25-L45)
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)

**Section sources**
- [instruction.md:13-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:43-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Core Components
Each application follows a consistent pattern:

| Component | Responsibility | Typical Files |
|---|---|---|
| User Interface | ipywidgets controls, tabs, status, charts, tables | `app.py` |
| Event Controller | Binds widgets, validates inputs, triggers updates | `app.py` |
| Data Layer | Builds BQL requests, batches calls, parses responses | `data.py` or `engine.py` |
| Transformation Engine | Pure Pandas calculations, validation, aggregation | `engine.py` |
| Cache | Local CSV + manifest for settled history | `cache.py` (ETF Spread) |
| Configuration | Defaults, batch sizes, allowed fields, labels | `config.py` files |

Key architectural properties:

- Requests are not sent automatically; they start only after an explicit user action such as **Update** or **Refresh**.
- Data ingestion uses `bql.execute_many` where possible, with per-request error collection.
- Transformation logic is isolated in pure-Pandas functions so it can be tested without Bloomberg connectivity.
- ETF Spread Monitoring stores raw historical series locally and requests only missing days.
- ETF Capping and FI Index Change rely on live BQL snapshots but still validate and diagnose partial results.

**Section sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

## Architecture Overview
The end-to-end data flow has four main stages:

1. **Event capture:** Widget state changes are observed and bound by the application controller.
2. **Request planning:** The controller validates inputs and delegates to the data layer.
3. **Ingestion and validation:** BQL responses are parsed into normalized Pandas frames; errors are collected rather than immediately failing the whole run.
4. **Transformation and visualization:** Engines compute weights, spreads, membership diffs, alerts, and charts; the UI displays results and diagnostic notes.

```mermaid
sequenceDiagram
participant User as "User"
participant UI as "ipywidgets App"
participant Controller as "Controller"
participant Data as "Data Layer"
participant BQL as "Bloomberg BQL"
participant Engine as "Pandas Engine"
participant View as "Visualization"
User->>UI : Click Update / Refresh
UI->>Controller : Event handler
Controller->>Controller : Validate inputs
Controller->>Data : Build request(s)
Data->>BQL : execute / execute_many
BQL-->>Data : Response(s)
Data->>Data : Parse, merge, validate
Data-->>Controller : Normalized frame(s)
Controller->>Engine : Transform / calculate
Engine-->>Controller : Result objects
Controller->>View : Render tables, charts, status
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [data.py:237-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L284)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

## Detailed Component Analysis

### ETF Capping Monitoring Pipeline
ETF capping monitors AIM account positions against fund-level capping rules. The pipeline converts AIM holdings into company-level weights, applies dynamic limits, and flags breaches or near-limit conditions.

```mermaid
flowchart TD
Start(["Update clicked"]) --> Validate["Validate position mode<br/>Current or Projected"]
Validate --> FetchAIM["Fetch AIM positions per account"]
FetchAIM --> Descriptors["Resolve Name and Market Status"]
Descriptors --> FundMapping["Resolve Fundamental Ticker"]
FundMapping --> ThaiPricing["Resolve Thai local pricing if needed"]
ThaiPricing --> Prices["Build approved USD price"]
Prices --> PositionMV["Compute Quantity × USD Price"]
PositionMV --> SecurityWeight["Compute security Weight"]
SecurityWeight --> CompanyGroup["Aggregate by company key"]
CompanyGroup --> Limits["Apply Largest/Capping limit"]
Limits --> Alerts["Classify Breach / Near Limit / OK / Data Issue"]
Alerts --> Render(["Render Monitor, Full Positions, Diagnostics"])
```

**Diagram sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:493-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L493-L531)
- [data.py:534-596](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L534-L596)
- [data.py:599-800](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L800)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

#### ETF Capping Data Ingestion
The data layer constructs frozen AIM request shapes, batches accounts and securities, and normalizes BQL responses into a common frame contract. Errors are appended to an error list instead of raising immediately, allowing partial results to be diagnosed.

Key behaviors:

- AIM requests use `position_without_pending()` for Current and add `pending_position()` for Projected.
- Account requests are batched; security descriptor and fundamental ticker requests are batched separately.
- Responses are checked via response-type heuristics, item lookup, and fallback combined DataFrame parsing.
- Missing columns, empty responses, and malformed items are recorded as parse errors.

**Section sources**
- [data.py:25-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L25-L45)
- [data.py:53-71](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L53-L71)
- [data.py:73-118](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L73-L118)
- [data.py:121-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L121-L183)
- [data.py:210-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L210-L284)
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)

#### ETF Capping Transformation and Validation
The engine performs pure-Pandas calculations:

- Asset classification from tickers.
- Runbook rule attachment.
- Price validation and market-status-aware zeroing.
- Security-level weight calculation.
- Company identity mapping with exception overrides.
- Grouping, ranking, dynamic limit selection, and alert status.

Validation is defensive: missing quantities, missing prices, zero account totals, unresolved Thai pricing, and incomplete accounts produce diagnostics rather than silently producing incorrect weights.

**Section sources**
- [engine.py:13-49](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L13-L49)
- [engine.py:83-93](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L83-L93)
- [engine.py:95-147](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L147)
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [engine.py:407-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L554)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

#### ETF Capping UI and Event Binding
The app class owns widget state, binds update handlers, renders static documentation, and exposes Monitor, Full Positions, Account Summary, Runbook, Exceptions, and Diagnostics tabs. BQL runs only when Update is clicked; dropdowns, searches, and exports are local operations.

**Section sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [app.py:718-800](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L718-L800)
- [app.py:274-686](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L274-L686)

### ETF Spread Monitoring Pipeline
ETF spread monitoring loads HSBC ETF share-class history, computes spreads and returns, compares peers, and optionally shows fund flows as a heatmap. It is the only project with a persistent local history cache.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "ETFSpreadMonitor"
participant Cache as "cache.py"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
participant View as "Book / Flows / Peers"
User->>App : Click Refresh
App->>Cache : Read stored quotes, returns, NAVs, flows
Cache-->>App : Stored frames + manifest
App->>Data : Plan gaps and build parallel history requests
Data->>BQL : Request missing dates
BQL-->>Data : Live frames
Data-->>App : Live frames
App->>Cache : Merge and save settled rows
App->>Engine : Prepare observations, period bounds, summary
Engine-->>App : SpreadView
App->>View : Render book, charts, flows, peers
```

**Diagram sources**
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

#### ETF Spread Caching Mechanism
The cache stores raw request outputs for quotes, returns, NAVs, and flows. It does not store derived metrics like spread percentages, so formula changes remain visible on the next refresh.

Important design points:

- Each kind has a fixed column contract.
- A manifest records contract version, generation token, file names, row counts, fingerprints, and identifier-to-security tokens.
- Fingerprinting derives from builder source code, so changing an item, parameter, or argument invalidates old cached rows.
- Stale identities are detected: if a ticker now resolves to a different security, those rows are dropped and requested again.
- Only rows before the last completed session are written; unsettled rows stay live-only.
- Reads never raise; unreadable or incompatible files fall back to “no cache.”

```mermaid
flowchart TD
LoadManifest["Load manifest.json"] --> CheckContract["Check contract and generation"]
CheckContract --> CheckFingerprint["Check fingerprint per kind"]
CheckFingerprint --> ReadCSV["Read kind.csv"]
ReadCSV --> Normalize["Normalize ID, DATE, numeric columns"]
Normalize --> CheckStale["Check stale identities"]
CheckStale --> FilterEmpty["Drop empty or value-less frames"]
FilterEmpty --> SortDedup["Sort by DATE,ID and deduplicate"]
SortDedup --> ReturnFrame["Return usable series"]
```

**Diagram sources**
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [cache.py:64-107](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L107)
- [cache.py:120-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

**Section sources**
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [cache.py:29-51](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L29-L51)
- [cache.py:64-107](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L107)
- [cache.py:120-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L120-L164)
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [cache.py:435-465](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L435-L465)
- [cache.py:492-575](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L492-L575)

#### ETF Spread Transformation
The engine prepares observations, computes midpoint spread in basis points, assigns quote status, slices periods, summarizes statistics, and builds chart frames. Invalid quotes stay blank rather than being treated as valid markets.

**Section sources**
- [engine.py:18-45](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L18-L45)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:193-205](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L193-L205)
- [engine.py:217-272](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L272)
- [engine.py:275-291](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L275-L291)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

#### ETF Spread UI and Controls
The app manages strategy, history range, cache toggle, fund filters, spread/return/NAV toggles, peer averages, flow period, and chart selections. Most control changes redraw from loaded data without sending new requests.

**Section sources**
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [app.py:566-610](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L566-L610)
- [app.py:677-716](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L677-L716)
- [app.py:732-757](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L732-L757)
- [app.py:780-800](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L780-L800)

### FI Index Change Detection Pipeline
FI index change detects adds and exits between two month-ends for a fixed-income index. It splits heavy analytics into smaller BQL groups, aligns classification labels, computes membership differences, and renders bucket summaries and detail views.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "FIIndexChangeApp"
participant Data as "data.py"
participant BQL as "Bloomberg BQL"
participant Engine as "engine.py"
participant View as "Main / Export / Full Position"
User->>App : Click Update
App->>App : Validate index ticker and month-end
App->>Data : fetch_index_payload(previous, selected)
Data->>BQL : Execute grouped member/analytics requests
BQL-->>Data : Snapshots and statuses
Data-->>App : Payload with snapshots, errors, notes
App->>Engine : comparison_for(selected, today)
App->>Engine : build_transition(snapshots, comparison, statuses)
Engine-->>App : Transition with previous/latest snapshots
App->>View : Render dimension chart, bucket summary, detail
```

**Diagram sources**
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

#### FI Index Change Validation and Comparison
The engine validates index tickers, computes effective month-ends, builds comparisons, normalizes snapshots, aligns classification labels, and computes membership diffs.

Key consistency rules:

- Weights are normalized and scaled when they arrive as fractions.
- MBS/TBA and municipal bonds receive special country, sector, currency, rating, and tenor-bucket handling.
- Rating buckets are restricted to IG, HY, and NR.
- Classification labels are aligned across months so IDs do not appear under conflicting selections.
- Adds and exits are computed from ID membership differences, not from precomputed change fields.

**Section sources**
- [engine.py:122-128](file://User scripts/FI Index Change/fi_index_change/engine.py#L122-L128)
- [engine.py:185-232](file://User scripts/FI Index Change/fi_index_change/engine.py#L185-L232)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [engine.py:306-332](file://User scripts/FI Index Change/fi_index_change/engine.py#L306-L332)
- [engine.py:353-368](file://User scripts/FI Index Change/fi_index_change/engine.py#L353-L368)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [engine.py:511-605](file://User scripts/FI Index Change/fi_index_change/engine.py#L511-L605)
- [engine.py:643-668](file://User scripts/FI Index Change/fi_index_change/engine.py#L643-L668)
- [engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

#### FI Index Change UI Behavior
The app disables duplicate updates, logs progress, separates non-fatal payload errors from exceptions, and clears stale state on failure. It also handles membership/license access failures distinctly from ordinary request failures.

**Section sources**
- [app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [app.py:740-773](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L773)

## Dependency Analysis
The following diagram maps the primary dependencies among the analyzed modules.

```mermaid
graph LR
ETF_Capping_App["ETF Capping app.py"] --> ETF_Capping_Data["ETF Capping data.py"]
ETF_Capping_App --> ETF_Capping_Engine["ETF Capping engine.py"]
ETF_Spread_App["ETF Spread app.py"] --> ETF_Spread_Engine["ETF Spread engine.py"]
ETF_Spread_App --> ETF_Spread_Cache["ETF Spread cache.py"]
ETF_Spread_App --> ETF_Spread_Data["ETF Spread data.py"]
FI_Index_App["FI Index app.py"] --> FI_Index_Engine["FI Index engine.py"]
ETF_Capping_Data --> BQL["Bloomberg BQL"]
ETF_Spread_Data --> BQL
FI_Index_Data --> BQL
```

**Diagram sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [data.py:25-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L25-L45)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)

Component coupling and cohesion:

- ETF Capping: UI depends on both data and engine; data depends on config and engine’s asset classifier; engine depends on config.
- ETF Spread: UI depends on view, metrics, peer map, peers, cache, and data; engine is mostly independent and works on prepared frames.
- FI Index: UI depends on data and engine; engine depends on field library and config.

Potential circular dependencies are avoided by keeping BQL calls out of pure engines and by isolating request building in data layers.

**Section sources**
- [app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [data.py:16-23](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L16-L23)
- [engine.py:10-10](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L10-L10)
- [app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [engine.py:15-15](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L15-L15)
- [app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)

## Performance Considerations
- Batched BQL calls reduce round-trips for AIM accounts, security descriptors, fundamental tickers, and Thai mappings.
- ETF Spread Monitoring avoids full re-fetches by storing settled history and requesting only head/tail gaps.
- Derived metrics are computed after merging, so cached raw values remain reusable when formulas change.
- FI Index Change splits analytics into smaller request groups to avoid Bloomberg timeouts.
- UI filtering, chart resizing, and display-top controls are local redraws that do not rebuild requests.

Operational constraints from the workspace instructions reinforce performance and safety:

- Do not run data requests from this Mac; Desktop is required.
- Avoid restricted ESG, GHG, climate, and sustainable-finance items.
- Keep concurrent runs single-threaded per project.
- Use the provided refresh and preview commands rather than editing generated files directly.

**Section sources**
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:493-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L493-L531)
- [data.py:534-596](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L534-L596)
- [cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [instruction.md:5-5](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:78-82](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Troubleshooting Guide

### ETF Capping Monitoring
Common issues and their signals:

- Missing AIM positions or malformed BQL responses appear in diagnostics.
- Unresolved Thai pricing leaves the holding without a usable price and marks the account as incomplete.
- Zero account total market value makes weights undefined and produces a Data Issue.
- Official empty-market statuses are not treated as missing-price errors; a numeric last price is still carried even for suspended or delisted names.

Recommended steps:

1. Open the Diagnostics tab.
2. Look for categories such as Missing Quantity, Missing Price, Reference Data Missing, Thai Pricing Unresolved, and Account Incomplete.
3. Confirm whether the issue is a request failure, a reference-data gap, or a calculation guard.
4. Do not widen the universe or substitute unapproved fields to hide the problem.

**Section sources**
- [engine.py:233-399](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L399)
- [engine.py:407-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L554)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

### ETF Spread Monitoring
Common issues and their signals:

- Cached rows may belong to a different security if the underlying ticker was repointed.
- A weekend-only gap should not trigger a request because no business day exists in the window.
- Crossed or non-positive bid/ask quotes are left blank and reported in notes.
- Formula changes require a refresh; unchecking Use cache forces a full re-request.

Recommended steps:

1. Check the status line for cache reuse, stored rows reused, and settled rows written.
2. Inspect notes for skipped unusable rows, crossed quotes, or missing peer rows.
3. If a ticker now resolves to a different security, allow the cache to drop the stale identifier and re-request.
4. Compare Spread, Spread %, return percent, and flow scaling after any formula change.

**Section sources**
- [cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

### FI Index Change Detection
Common issues and their signals:

- Membership license refusal is distinct from an empty result.
- Partial snapshot parsing is reported as warnings; the comparison still computes but the screen shows incomplete status.
- Month-end validation rejects dates outside the dropdown.
- MBS/TBA and municipal bonds have special classification behavior that must not be interpreted as missing data.

Recommended steps:

1. Read the log area under the status line before trusting the table.
2. Distinguish between a 403/session entitlement error and a missing field or empty membership set.
3. Verify the selected month-end and whether it is projected or historical.
4. For timeout-related analytics failures, inspect which measure group failed and retry only that group if supported.

**Section sources**
- [engine.py:99-119](file://User scripts/FI Index Change/fi_index_change/engine.py#L99-L119)
- [engine.py:235-251](file://User scripts/FI Index Change/fi_index_change/engine.py#L235-L251)
- [engine.py:371-462](file://User scripts/FI Index Change/fi_index_change/engine.py#L371-L462)
- [app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [app.py:740-773](file://User scripts/FI Index Change/fi_index_change/app.py#L740-L773)

## Conclusion
The Bloomberg BQuant platform in this repository implements a disciplined, event-driven data pipeline:

- User actions explicitly trigger data refreshes.
- Data ingestion isolates BQL calls, batches requests, and collects errors rather than failing silently.
- Transformation logic is pure Pandas, making it testable and transparent.
- ETF Spread Monitoring provides robust local caching with contract, generation, fingerprint, and identity checks.
- ETF Capping and FI Index Change emphasize defensive validation, diagnostics, and clear status reporting.
- Real-time or current-book data and historical processing are separated: current AIM positions and index snapshots are live, while ETF Spread Monitoring merges live gaps with settled history.

For future work, the same principles should apply: keep request contracts frozen, isolate transformations, preserve diagnostics, invalidate caches when semantics change, and never let partial failures look like clean success.