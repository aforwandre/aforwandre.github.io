# Core Architecture Patterns

<cite>
**Referenced Files in This Document**   
- [ETF Capping Monitoring app.py](file://User scripts/ETF Capping Monitoring/etf_capping/app.py)
- [ETF Capping Monitoring engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [ETF Capping Monitoring data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [ETF Spread Monitoring app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [ETF Spread Monitoring engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [ETF Spread Monitoring data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [FI Index Change app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [FI Index Change engine.py](file://User scripts/FI Index Change/fi_index_change/engine.py)
- [FI Index Change data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [FI Spread Movement Monitoring app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [FI Spread Movement Monitoring engine.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py)
- [FI Spread Movement Monitoring data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the core design patterns used across the Bloomberg BQuant platform modules for ETF analytics, fixed income analytics, and equity screening. The codebase follows a consistent modular monolith structure: each analytical domain is an independent package with a clear separation between user interface controllers, business logic engines, and data access layers.

The main architectural goals are:
- Maintainable separation of concerns through MVC-style packages.
- Extensible monitoring strategies via strategy and factory patterns.
- Real-time UI updates and alert notifications through IPyWidgets.
- Dynamic creation of monitoring instances through factories.
- Robust error handling, caching, and diagnostics for financial data pipelines.

## Project Structure
Each major module follows the same layout:
- `app.py`: Application controller that builds IPyWidgets, binds events, and orchestrates requests.
- `engine.py`: Pure-Pandas or pure-table business logic without direct Bloomberg calls.
- `data.py`: Bloomberg Query Language (BQL) adapters, request builders, response parsers, and optional cache helpers.
- `config.py` and related configuration files: Rules, thresholds, batch sizes, and feature toggles.

```mermaid
graph TB
subgraph "ETF Capping Monitoring"
EC_APP["etf_capping/app.py"]
EC_ENGINE["etf_capping/engine.py"]
EC_DATA["etf_capping/data.py"]
end
subgraph "ETF Spread Monitoring"
ES_APP["etf_spread/app.py"]
ES_ENGINE["etf_spread/engine.py"]
ES_DATA["etf_spread/data.py"]
end
subgraph "Fixed Income Analytics"
FI_INDEX_APP["fi_index_change/app.py"]
FI_INDEX_ENGINE["fi_index_change/engine.py"]
FI_INDEX_DATA["fi_index_change/data.py"]
FI_SPREAD_APP["fi_spread_movement/app.py"]
FI_SPREAD_ENGINE["fi_spread_movement/engine.py"]
FI_SPREAD_DATA["fi_spread_movement/data.py"]
end
EC_APP --> EC_ENGINE
EC_APP --> EC_DATA
ES_APP --> ES_ENGINE
ES_APP --> ES_DATA
FI_INDEX_APP --> FI_INDEX_ENGINE
FI_INDEX_APP --> FI_INDEX_DATA
FI_SPREAD_APP --> FI_SPREAD_ENGINE
FI_SPREAD_APP --> FI_SPREAD_DATA
```

**Diagram sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Spread Monitoring app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)

**Section sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Spread Monitoring app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)

## Core Components
The platform implements four key patterns:

| Pattern | Purpose | Where It Appears |
|---|---|---|
| Model-View-Controller | Separates UI state, business rules, and Bloomberg data access | All `app.py`, `engine.py`, `data.py` triplets |
| Strategy | Configurable monitoring approaches across asset classes | ETF spread source selection, FI spread movement universe selection |
| Observer | Real-time IPyWidgets updates and alert chips | App event binding, status HTML, progress callbacks |
| Factory | Dynamic creation of monitoring instances and data sources | ETF spread book/peer source factories, FI spread movement fetchers |

### MVC Separation
- **Controller (`app.py`)**: Builds widgets, binds events, validates inputs, triggers updates, and renders results.
- **Engine (`engine.py`)**: Performs calculations, validations, bucketing, ranking, and summary generation using pandas.
- **Data Layer (`data.py`)**: Encapsulates BQL requests, response parsing, batching, retries, and cache integration.

**Section sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Capping Monitoring engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [ETF Capping Monitoring data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [ETF Spread Monitoring app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [ETF Spread Monitoring engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)
- [ETF Spread Monitoring data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Index Change engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)
- [FI Index Change data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)
- [FI Spread Movement Monitoring engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [FI Spread Movement Monitoring data.py:76-106](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L106)

### Strategy Pattern
The ETF Spread Monitoring module uses a strategy pattern to switch between placeholder and Bloomberg data sources. The `book_source_for` and `peer_source_for` functions return different source implementations based on configuration.

```mermaid
classDiagram
class SourceResult {
+DataFrame observations
+list errors
}
class PlaceholderBookSource {
+fetch(today) SourceResult
}
class BloombergBookSource {
+fetch(today) SourceResult
}
class PlaceholderPeerSource {
+fetch(today) SourceResult
}
class BloombergPeerSource {
+fetch(today) SourceResult
}
class DataLayer {
+book_source_for(name) Source
+peer_source_for(name) Source
+fetch_spread_payload() SpreadPayload
}
PlaceholderBookSource --> SourceResult : returns
BloombergBookSource --> SourceResult : returns
PlaceholderPeerSource --> SourceResult : returns
BloombergPeerSource --> SourceResult : returns
DataLayer --> PlaceholderBookSource : creates
DataLayer --> BloombergBookSource : creates
DataLayer --> PlaceholderPeerSource : creates
DataLayer --> BloombergPeerSource : creates
```

**Diagram sources**
- [ETF Spread Monitoring data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [ETF Spread Monitoring data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)

**Section sources**
- [ETF Spread Monitoring data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [ETF Spread Monitoring data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)

### Observer Pattern
All applications use IPyWidgets as observers. Controllers bind widget events, update status HTML, render tables, and emit alerts. The ETF Capping Monitor demonstrates this with its `ETFCappingMonitor` class, which maintains state, binds events, and renders static tabs.

```mermaid
sequenceDiagram
participant User as "User"
participant Widget as "IPyWidget"
participant Controller as "App Controller"
participant Engine as "Business Engine"
participant Data as "Data Layer"
User->>Widget : Click Update
Widget->>Controller : Event callback
Controller->>Controller : Validate input
Controller->>Data : fetch_monitor_payload()
Data-->>Controller : MonitorPayload
Controller->>Engine : calculate_monitor()
Engine-->>Controller : MonitorResult
Controller->>Controller : Render tables and alerts
Controller-->>User : Updated dashboard
```

**Diagram sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Capping Monitoring data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [ETF Capping Monitoring engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

**Section sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Spread Monitoring app.py:461-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L461-L486)
- [FI Index Change app.py:579-595](file://User scripts/FI Index Change/fi_index_change/app.py#L579-L595)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)

### Factory Pattern
The ETF Spread Monitoring module provides factory functions for creating monitoring instances and data sources. The `book_source_for` and `peer_source_for` functions create appropriate source objects based on configuration.

```mermaid
flowchart TD
Start(["Configuration"]) --> CheckBook{"Book Source?"}
CheckBook --> |placeholder| CreatePlaceholderBook["Create PlaceholderBookSource"]
CheckBook --> |bloomberg| CreateBloombergBook["Create BloombergBookSource"]
CreatePlaceholderBook --> ReturnBook["Return Book Source"]
CreateBloombergBook --> ReturnBook
ReturnBook --> CheckPeer{"Peer Source?"}
CheckPeer --> |placeholder| CreatePlaceholderPeer["Create PlaceholderPeerSource"]
CheckPeer --> |bloomberg| CreateBloombergPeer["Create BloombergPeerSource"]
CreatePlaceholderPeer --> ReturnPeer["Return Peer Source"]
CreateBloombergPeer --> ReturnPeer
ReturnPeer --> End(["Spread Payload"])
```

**Diagram sources**
- [ETF Spread Monitoring data.py:197-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L197-L210)

**Section sources**
- [ETF Spread Monitoring data.py:197-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L197-L210)

## Architecture Overview
The platform follows a layered architecture where each module encapsulates its own domain logic while sharing common patterns.

```mermaid
graph TB
subgraph "Presentation Layer"
UI1["ETF Capping UI"]
UI2["ETF Spread UI"]
UI3["FI Index Change UI"]
UI4["FI Spread Movement UI"]
end
subgraph "Application Layer"
APP1["ETF Capping Controller"]
APP2["ETF Spread Controller"]
APP3["FI Index Change Controller"]
APP4["FI Spread Movement Controller"]
end
subgraph "Domain Layer"
DOMAIN1["ETF Capping Engine"]
DOMAIN2["ETF Spread Engine"]
DOMAIN3["FI Index Change Engine"]
DOMAIN4["FI Spread Movement Engine"]
end
subgraph "Infrastructure Layer"
DATA1["ETF Capping Data"]
DATA2["ETF Spread Data"]
DATA3["FI Index Change Data"]
DATA4["FI Spread Movement Data"]
BQL["Bloomberg BQL"]
end
UI1 --> APP1
UI2 --> APP2
UI3 --> APP3
UI4 --> APP4
APP1 --> DOMAIN1
APP2 --> DOMAIN2
APP3 --> DOMAIN3
APP4 --> DOMAIN4
DOMAIN1 --> DATA1
DOMAIN2 --> DATA2
DOMAIN3 --> DATA3
DOMAIN4 --> DATA4
DATA1 --> BQL
DATA2 --> BQL
DATA3 --> BQL
DATA4 --> BQL
```

**Diagram sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Spread Monitoring app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)

## Detailed Component Analysis

### ETF Capping Monitoring
The ETF Capping Monitoring module implements position capping analysis for ETF portfolios.

#### MVC Implementation
- **Controller**: `ETFCappingMonitor` class manages IPyWidgets state and user interactions.
- **Engine**: `calculate_monitor` function performs position valuation, company aggregation, and capping status calculation.
- **Data**: `fetch_monitor_payload` handles AIM position requests and USD pricing.

```mermaid
classDiagram
class ETFCappingMonitor {
-bool _events_bound
-bool _loading
-MonitorResult _result
-build_widgets()
-bind_events()
-render_static_tabs()
}
class MonitorResult {
+DataFrame positions
+DataFrame groups
+DataFrame alerts
+DataFrame diagnostics
}
class DataLayer {
+fetch_monitor_payload() MonitorPayload
-_aim_request() Request
-_position_item() Item
}
ETFCappingMonitor --> MonitorResult : creates
ETFCappingMonitor --> DataLayer : uses
```

**Diagram sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Capping Monitoring engine.py:52-58](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L52-L58)
- [ETF Capping Monitoring data.py:34-38](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L34-L38)

**Section sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Capping Monitoring engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [ETF Capping Monitoring data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)

### ETF Spread Monitoring
The ETF Spread Monitoring module provides spread analysis with configurable data sources.

#### Strategy Pattern Implementation
The module uses different strategies for book and peer data sources:

```mermaid
flowchart TD
Config["Configuration"] --> Factory["Factory Functions"]
Factory --> Placeholder["Placeholder Sources"]
Factory --> Bloomberg["Bloomberg Sources"]
Placeholder --> Results["Spread Results"]
Bloomberg --> Results
```

**Diagram sources**
- [ETF Spread Monitoring data.py:197-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L197-L210)

**Section sources**
- [ETF Spread Monitoring data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [ETF Spread Monitoring engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

### Fixed Income Analytics
The fixed income analytics include two distinct modules:

#### FI Index Change
Tracks index constituent changes between month-ends.

```mermaid
sequenceDiagram
participant User as "User"
participant App as "FI Index Change App"
participant Data as "Index Data Layer"
participant Engine as "Comparison Engine"
User->>App : Click Update
App->>Data : fetch_index_payload()
Data-->>App : IndexPayload
App->>Engine : build_transition()
Engine-->>App : Transition
App-->>User : Updated comparison view
```

**Diagram sources**
- [FI Index Change app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [FI Index Change data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)
- [FI Index Change engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)

**Section sources**
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Index Change engine.py:784-800](file://User scripts/FI Index Change/fi_index_change/engine.py#L784-L800)
- [FI Index Change data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)

#### FI Spread Movement Monitoring
Monitors spread movements with multiple universe options.

```mermaid
classDiagram
class FISpreadMovementApp {
-dict _frames
-dict _visible
-FetchResult _last_result
-build_widgets()
-bind_events()
-on_update()
}
class FetchResult {
+DataFrame increases
+DataFrame decreases
+DataFrame descriptors
+DataFrame series
+dict field_status
+list errors
+list notes
}
FISpreadMovementApp --> FetchResult : processes
```

**Diagram sources**
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)
- [FI Spread Movement Monitoring data.py:76-106](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L106)

**Section sources**
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)
- [FI Spread Movement Monitoring engine.py:243-271](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/engine.py#L243-L271)
- [FI Spread Movement Monitoring data.py:76-106](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L106)

## Dependency Analysis
The modules have clear dependency relationships with minimal coupling:

```mermaid
graph LR
subgraph "Controllers"
A1["ETF Capping App"]
A2["ETF Spread App"]
A3["FI Index Change App"]
A4["FI Spread Movement App"]
end
subgraph "Engines"
E1["ETF Capping Engine"]
E2["ETF Spread Engine"]
E3["FI Index Change Engine"]
E4["FI Spread Movement Engine"]
end
subgraph "Data Layers"
D1["ETF Capping Data"]
D2["ETF Spread Data"]
D3["FI Index Change Data"]
D4["FI Spread Movement Data"]
end
A1 --> E1
A2 --> E2
A3 --> E3
A4 --> E4
E1 --> D1
E2 --> D2
E3 --> D3
E4 --> D4
```

**Diagram sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Spread Monitoring app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)

**Section sources**
- [ETF Capping Monitoring app.py:701-716](file://User scripts/ETF Capping Monitoring/etf_capping/app.py#L701-L716)
- [ETF Spread Monitoring app.py:306-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L486)
- [FI Index Change app.py:307-595](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L595)
- [FI Spread Movement Monitoring app.py:656-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L800)

## Performance Considerations
The platform implements several performance optimizations:

- **Batching**: Data requests are batched to reduce API calls (AIM accounts in groups of 8, securities in groups of 150).
- **Caching**: Historical data is cached locally to avoid repeated Bloomberg requests.
- **Lazy Loading**: Widgets are constructed without fetching data; requests only occur on explicit user actions.
- **Efficient Rendering**: IPyDatagrid is used for large datasets with optimized column width calculations.
- **Retry Logic**: Timeout errors trigger automatic retries while deterministic failures are handled immediately.

## Troubleshooting Guide
Common issues and their resolution patterns:

### Data Quality Issues
- Missing required columns trigger diagnostic messages rather than silent failures.
- Zero account market values are flagged as data issues.
- Thai foreign line pricing mappings are validated with detailed error reporting.

### Request Failures
- BQL timeout errors are retried automatically.
- Deterministic failures (entitlements, invalid tickers) are reported immediately.
- Response parsing errors include detailed shape information for debugging.

### UI State Management
- Event handlers are idempotent to prevent duplicate bindings.
- Status messages clearly distinguish between idle, processing, updated, and error states.
- Progress indicators provide feedback during long-running operations.

**Section sources**
- [ETF Capping Monitoring engine.py:95-101](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L101)
- [ETF Capping Monitoring data.py:40-45](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L40-L45)
- [FI Index Change data.py:529-538](file://User scripts/FI Index Change/fi_index_change/data.py#L529-L538)
- [FI Spread Movement Monitoring data.py:153-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L153-L162)

## Conclusion
The Bloomberg BQuant platform demonstrates mature software engineering practices through its consistent application of design patterns. The MVC separation ensures maintainability, while strategy and factory patterns provide extensibility for different asset classes and data sources. The observer pattern implementation through IPyWidgets enables responsive user interfaces, and comprehensive error handling ensures robust operation in production environments.

This architecture supports the platform's growth from ETF analytics to fixed income and equity screening while maintaining code quality, performance, and user experience standards. The modular design allows new analytical domains to be added following established patterns without disrupting existing functionality.