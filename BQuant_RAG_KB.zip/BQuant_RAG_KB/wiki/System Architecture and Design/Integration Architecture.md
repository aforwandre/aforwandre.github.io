# Integration Architecture

<cite>
**Referenced Files in This Document**
- [fi_spread_movement/config.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py)
- [fi_spread_movement/cache.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py)
- [fi_spread_movement/app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [etf_capping/config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [etf_capping/data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [etf_capping/engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [etf_spread/app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [etf_spread/cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [test_cache_fallback.py](file://User scripts/FI Spread Movement Monitoring/tests/test_cache_fallback.py)
- [test_data_request.py](file://User scripts/FI Index Change/tests/test_data_request.py)
- [27-etf-spread-monitor.md](file://RAG KB/27-etf-spread-monitor.md)
- [25-etf-capping-monitor.md](file://RAG KB/25-etf-capping-monitor.md)
- [28-fi-index-change.md](file://RAG KB/28-fi-index-change.md)
- [29-fi-spread-movement-monitoring.md](file://RAG KB/29-fi-spread-movement-monitoring.md)
- [05-get-started.md](file://RAG KB/05-get-started.md)
- [14-bql-for-port-prep.md](file://RAG KB/14-bql-for-port-prep.md)
- [project-fi-spread-movement-monitoring.md](file://rules/project-fi-spread-movement-monitoring.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the integration architecture for external system connections used by Bloomberg BQuant applications in this repository. It focuses on:

- Bloomberg BQL integration patterns, including request construction, timeout behavior, and cached fallbacks.
- AIM (Asset Investment Manager) connectivity for portfolio position data retrieval and synchronization.
- Excel workbook integration for legacy compatibility and data export.
- Cache layer design for performance optimization and offline capability.
- Authentication and authorization context as it appears in Desktop/Bloomberg Terminal usage.
- Rate limiting, error handling, retry mechanisms, and fallback strategies.
- Environment-specific configuration management across multiple projects.
- Extensibility through plugin-like configuration and data source composition.

The codebase is not a single monolithic service; it is a set of Jupyter-based Bloomberg BQuant applications that share common integration patterns around BQL, AIM, local CSV/JSON caches, and Excel-oriented exports.

## Project Structure
The relevant integration logic is spread across several user-facing monitoring applications under `User scripts/`, with supporting runtime authority and decision records under `RAG KB/` and `.cursor/.trae/rules/`.

```mermaid
graph TB
subgraph "Bloomberg BQuant Applications"
ETF_Capping["ETF Capping Monitoring"]
FI_Spread["FI Spread Movement Monitoring"]
ETF_Spread["ETF Spread Monitoring"]
FI_Index["FI Index Change"]
end
subgraph "External Systems"
BQL["Bloomberg BQL API"]
AIM["AIM Portfolio Data"]
Excel["Excel Workbooks"]
LocalCache["Local CSV/JSON Cache"]
end
ETF_Capping --> BQL
ETF_Capping --> AIM
ETF_Capping --> Excel
ETF_Capping --> LocalCache
FI_Spread --> BQL
FI_Spread --> AIM
FI_Spread --> Excel
FI_Spread --> LocalCache
ETF_Spread --> BQL
ETF_Spread --> LocalCache
ETF_Spread --> Excel
FI_Index --> BQL
FI_Index --> Excel
FI_Index --> LocalCache
```

**Diagram sources**
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [fi_spread_movement/config.py:26-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L96)
- [etf_spread/app.py:27-36](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L27-L36)
- [fi_spread_movement/cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)

**Section sources**
- [etf_capping/config.py:1-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L16)
- [fi_spread_movement/config.py:1-24](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L1-L24)
- [etf_spread/app.py:1-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L54)
- [fi_spread_movement/cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)

## Core Components
The integration architecture is built around four main layers:

| Layer | Responsibility | Key Files |
|---|---|---|
| BQL Request Layer | Builds BQL requests, selects universes, handles timeouts, retries, and field-level diagnostics. | `fi_spread_movement/config.py`, `etf_capping/data.py`, `etf_spread/app.py` |
| AIM Connectivity Layer | Retrieves AIM account holdings, batches account and security requests, and maps positions to securities. | `etf_capping/config.py`, `etf_capping/data.py`, `etf_capping/engine.py` |
| Cache Layer | Persists successful runs locally as CSV plus JSON manifest, validates cache contracts, and supports fallback after timeouts. | `fi_spread_movement/cache.py`, `etf_spread/cache.py` |
| Export Layer | Produces Excel-compatible outputs, including copy-pasteable tables and structured change logs. | `fi_spread_movement/config.py`, `etf_capping/config.py` |

**Section sources**
- [fi_spread_movement/config.py:26-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L96)
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [fi_spread_movement/cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)
- [etf_spread/app.py:27-36](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L27-L36)

## Architecture Overview
At runtime, each application follows a similar flow:

1. The operator selects inputs such as universe type, spread type, date range, or AIM account.
2. The app builds one or more BQL requests.
3. Requests are executed against Bloomberg BQL via the active Desktop session.
4. Successful results may be written to a local cache.
5. On timeout, a bounded retry can occur, followed by an automatic fallback to a previously saved clean run.
6. Results are displayed, filtered, charted, and exported to Excel-compatible formats.

```mermaid
sequenceDiagram
participant Operator as "Operator"
participant App as "BQuant Application"
participant Config as "Configuration"
participant DataLayer as "Data / BQL Layer"
participant AIM as "AIM Service"
participant BQL as "Bloomberg BQL"
participant Cache as "Local Cache"
participant Excel as "Excel Export"
Operator->>App : Select universe, spread, dates, or AIM account
App->>Config : Read TOP_N, spread types, AIM settings, cache settings
App->>DataLayer : Build BQL request(s)
alt AIM universe
DataLayer->>AIM : Retrieve holdings for account
AIM-->>DataLayer : Position rows
end
DataLayer->>BQL : Execute request(s)
BQL-->>DataLayer : Response or timeout/error
alt Timeout
DataLayer->>BQL : Retry identical request once
BQL-->>DataLayer : Response or second timeout
DataLayer->>Cache : Check for clean cached run
Cache-->>DataLayer : Cached result if available
end
DataLayer-->>App : Result frame + diagnostics
App->>Cache : Save clean run when applicable
App->>Excel : Generate Excel-compatible table
App-->>Operator : Display updated or cached screen
```

**Diagram sources**
- [fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)
- [fi_spread_movement/cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [fi_spread_movement/app.py:2511-2537](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2511-L2537)
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)

## Detailed Component Analysis

### Bloomberg BQL Integration Layer
The BQL integration layer is responsible for constructing requests, selecting universes, handling timeouts, and reporting deterministic failures without retrying them.

Key behaviors:

- **Request construction:** Each project defines its own frozen request shapes, spread types, descriptor fields, and duration measures.
- **Timeout detection:** Timeouts are identified using specific markers rather than treating all errors as transient.
- **Retry policy:** Only timeouts are retried, and only once, with the same request rebuilt per attempt.
- **Deterministic failure handling:** Missing entitlements, invalid tickers, and rejected items fail immediately without retry.
- **Field-level diagnostics:** Failed fields are tracked so operators can see which descriptors did not arrive.

```mermaid
flowchart TD
Start(["Build BQL Request"]) --> ValidateInputs["Validate Universe, Ticker, Dates, Spread Type"]
ValidateInputs --> Valid{"Inputs Valid?"}
Valid --> |No| Refuse["Refuse Request<br/>Show Deterministic Error"]
Valid --> |Yes| Execute["Execute Request Against BQL"]
Execute --> Success{"Response Received?"}
Success --> |Yes| Process["Process Response<br/>Track Field Status"]
Success --> |No| IsTimeout{"Is Timeout?"}
IsTimeout --> |No| ReportError["Report Deterministic Failure<br/>Do Not Retry"]
IsTimeout --> |Yes| RetryOnce["Retry Identical Request Once"]
RetryOnce --> RetrySuccess{"Second Attempt Succeeded?"}
RetrySuccess --> |Yes| Process
RetrySuccess --> |No| FallbackCheck["Check Clean Cached Run"]
FallbackCheck --> HasCache{"Clean Cache Available?"}
HasCache --> |Yes| LoadCache["Load Cached Result<br/>Label as Cached"]
HasCache --> |No| ShowTimeout["Show Timeout Error<br/>No Stale Data"]
Process --> SaveCache["Save Clean Run to Cache"]
SaveCache --> End(["Return Result"])
LoadCache --> End
ReportError --> End
ShowTimeout --> End
Refuse --> End
```

**Diagram sources**
- [fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)
- [28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)
- [test_data_request.py:335-369](file://User scripts/FI Index Change/tests/test_data_request.py#L335-L369)

**Section sources**
- [fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)
- [28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)
- [test_data_request.py:335-369](file://User scripts/FI Index Change/tests/test_data_request.py#L335-L369)
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)

### AIM Connectivity Layer
AIM connectivity is primarily implemented in the ETF Capping Monitoring application. It retrieves portfolio positions from AIM accounts and combines them with pricing and company identity logic.

Key characteristics:

- **Account batching:** AIM account requests are batched to reduce request volume.
- **Security batching:** Security-level requests are also batched.
- **Position aggregation:** Positions are combined by exact AIM code and ticker, summing quantities without changing the held ticker.
- **Frozen contract:** The AIM request shape uses `bq.univ.members(type="AIM")` with explicit `accounts`, `pxnum`, and profile parameters.
- **Pricing rule selection:** Each account has a configured price type, such as Real Time or Last Close.

```mermaid
classDiagram
class AccountRule {
+string aim_code
+string fund_name
+float capping
+float largest
+string level
+string price_type
}
class AIMConnectivity {
+batch_accounts() list
+fetch_positions(account) DataFrame
+aggregate_by_account_ticker(DataFrame) DataFrame
+apply_pricing_rule(ticker, price_type) DataFrame
}
class ETFCappingEngine {
+process_positions(raw_positions) DataFrame
+classify_asset(ticker) string
+compute_company_weights(positions) DataFrame
}
AccountRule <.. ETFCappingEngine : "configuration"
AIMConnectivity --> AccountRule : "uses"
ETFCappingEngine --> AIMConnectivity : "calls"
```

**Diagram sources**
- [etf_capping/config.py:26-34](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L26-L34)
- [etf_capping/config.py:52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [etf_capping/data.py:807-861](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L807-L861)
- [etf_capping/engine.py:574-584](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L574-L584)

**Section sources**
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [etf_capping/config.py:52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [etf_capping/data.py:807-861](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L807-L861)
- [etf_capping/engine.py:574-584](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L574-L584)
- [25-etf-capping-monitor.md:49-75](file://RAG KB/25-etf-capping-monitor.md#L49-L75)

### Excel Workbook Integration
Excel integration is primarily export-oriented. Applications generate Excel-compatible tables, often repeating column names as the first data row so that copy-paste operations into Excel preserve headers.

Key behaviors:

- **Copy-paste-friendly tables:** Headers are repeated as the first data row.
- **Structured change logs:** Add and exit events are exported with consistent columns.
- **Legacy compatibility:** Exports align with existing Excel workbooks and macro-driven workflows.
- **No live file writes in some apps:** Some preview or validation paths avoid writing files and instead return frames for display.

```mermaid
flowchart TD
Start(["Export Workflow"]) --> PrepareFrame["Prepare DataFrame for Export"]
PrepareFrame --> RepeatHeaders["Repeat Column Names as First Row"]
RepeatHeaders --> FormatColumns["Format Numeric and Date Columns"]
FormatColumns --> ActionColumn{"Change Export?"}
ActionColumn --> |Yes| AddExitRows["Add 'Add' and 'Exit' Rows"]
ActionColumn --> |No| KeepOriginal["Keep Original Rows"]
AddExitRows --> SortAndSelect["Sort and Select Export Columns"]
KeepOriginal --> SortAndSelect
SortAndSelect --> ReturnFrame["Return Excel-Compatible Frame"]
```

**Diagram sources**
- [fi_spread_movement/config.py:320-337](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L320-L337)
- [project-fi-spread-movement-monitoring.md:198-200](file://rules/project-fi-spread-movement-monitoring.md#L198-L200)

**Section sources**
- [fi_spread_movement/config.py:320-337](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L320-L337)
- [project-fi-spread-movement-monitoring.md:198-200](file://rules/project-fi-spread-movement-monitoring.md#L198-L200)

### Cache Layer Architecture
The cache layer provides performance optimization and offline capability by persisting successful runs locally. It uses CSV files plus a JSON manifest, with strong validity checks.

Key design principles:

- **Result caching, not master data:** The cache stores the result of a specific run, not a general security master.
- **Generation tokens:** A generation token invalidates old cached runs when pipeline logic changes.
- **Run keys:** Keys include universe, spread type, dates, and top-N settings so different questions cannot serve stale results.
- **Manifest integrity:** The manifest tracks sequence numbers, file sizes, timestamps, and original request metadata.
- **Fail-safe reads:** Missing, unreadable, or mislabeled cache files read as no cache; write failures do not fail a good update.
- **Automatic fallback:** After a timeout, a clean cached run can be shown with a clear “Cached” status.

```mermaid
classDiagram
class CacheManifest {
+string generation
+int seq
+string saved_at
+dict request
+dict rows
+dict files
+dict bytes
+dict field_status
+list request_log
}
class CacheStore {
+save_run(key, result) void
+has_run(key) bool
+load_run(key) tuple
+prune(keep) list
+describe(info) string
}
class RunKey {
+source_key
+universe_key
+aim_value
+spread_code
+start
+end
+top_n
}
CacheStore --> CacheManifest : "reads/writes"
CacheStore --> RunKey : "generates"
```

**Diagram sources**
- [fi_spread_movement/cache.py:48-56](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L48-L56)
- [fi_spread_movement/cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)
- [fi_spread_movement/cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [fi_spread_movement/cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)
- [fi_spread_movement/cache.py:379-427](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L427)

**Section sources**
- [fi_spread_movement/cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)
- [fi_spread_movement/cache.py:48-56](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L48-L56)
- [fi_spread_movement/cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)
- [fi_spread_movement/cache.py:162-244](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L244)
- [fi_spread_movement/cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)
- [fi_spread_movement/cache.py:379-427](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L379-L427)
- [27-etf-spread-monitor.md:416-472](file://RAG KB/27-etf-spread-monitor.md#L416-L472)

### Authentication and Authorization Patterns
Authentication and authorization are handled at the Bloomberg Desktop and Terminal layer rather than inside these Python modules. The applications assume an active Bloomberg session and rely on Desktop-provided access.

Observed patterns:

- **Desktop session dependency:** BQL queries require a logged-in Bloomberg Terminal session.
- **Session connection stability:** Changes to the BBA/session connection can cause query failures until reconnection.
- **Entitlement-aware failures:** Missing entitlements are treated as deterministic failures, not transient network issues.
- **Portfolio service access:** Portfolio-related functions may require additional enablement through a Bloomberg Account representative.

```mermaid
sequenceDiagram
participant User as "User"
participant Desktop as "Bloomberg Desktop"
participant Terminal as "Bloomberg Terminal"
participant App as "BQuant Application"
participant BQL as "Bloomberg BQL"
User->>Terminal : Log in to Bloomberg Terminal
Terminal->>Desktop : Establish BBA/session connection
User->>App : Run notebook cell or Update
App->>BQL : Execute BQL request
alt No Terminal Session
BQL-->>App : Connection or entitlement error
App-->>User : Show troubleshooting guidance
else Valid Session
BQL-->>App : Return data or field-level error
App-->>User : Display result or diagnostic
end
```

**Diagram sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [14-bql-for-port-prep.md:399-412](file://RAG KB/14-bql-for-port-prep.md#L399-L412)

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [14-bql-for-port-prep.md:399-412](file://RAG KB/14-bql-for-port-prep.md#L399-L412)

### Rate Limiting, Error Handling, and Fallback Strategies
The applications implement resilience through three coordinated mechanisms: splitting, bounded retry, and cached fallback.

- **Splitting:** Requests are kept narrow, typically one item per request, to avoid wide BQL calls that exceed Desktop limits.
- **Retry:** A timed-out request is retried exactly once with the same request rebuilt per attempt.
- **Fallback:** If a timeout occurs and a clean cached run exists for the same key, the cached result is shown with a clear “Cached” label.
- **Deterministic failures:** Non-timeout errors are reported immediately and never fall back to stale data.

```mermaid
flowchart TD
Start(["Update Triggered"]) --> SplitRequests["Split Into Narrow Requests"]
SplitRequests --> ExecuteFirst["Execute First Attempt"]
ExecuteFirst --> Timeout{"Timeout?"}
Timeout --> |No| HandleNormal["Handle Normal Response or Deterministic Error"]
Timeout --> |Yes| ExecuteRetry["Execute Second Attempt"]
ExecuteRetry --> RetrySuccess{"Retry Succeeded?"}
RetrySuccess --> |Yes| HandleNormal
RetrySuccess --> |No| CheckCache["Check Clean Cached Run"]
CheckCache --> CacheHit{"Cache Hit?"}
CacheHit --> |Yes| ShowCached["Show Cached Result<br/>Status = Cached"]
CacheHit --> |No| ShowError["Show Timeout Error<br/>No Stale Data"]
HandleNormal --> MaybeCache["Save Clean Run When Applicable"]
MaybeCache --> End(["Done"])
ShowCached --> End
ShowError --> End
```

**Diagram sources**
- [fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)
- [fi_spread_movement/app.py:2511-2537](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2511-L2537)
- [test_cache_fallback.py:1-39](file://User scripts/FI Spread Movement Monitoring/tests/test_cache_fallback.py#L1-L39)
- [28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)

**Section sources**
- [fi_spread_movement/config.py:346-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L346-L371)
- [fi_spread_movement/app.py:2511-2537](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2511-L2537)
- [test_cache_fallback.py:1-39](file://User scripts/FI Spread Movement Monitoring/tests/test_cache_fallback.py#L1-L39)
- [28-fi-index-change.md:359-375](file://RAG KB/28-fi-index-change.md#L359-L375)

### Configuration Examples and Environment-Specific Settings Management
Each application maintains its own configuration module. These modules define operator-visible constants, request shapes, UI layout, and resilience settings.

Examples of environment-specific or deployment-relevant settings:

| Setting | Purpose | Example Location |
|---|---|---|
| `TOP_N` | Controls ranking breadth | `fi_spread_movement/config.py` |
| `SPREAD_TYPES` | Maps UI labels to BQL spread parameters | `fi_spread_movement/config.py` |
| `AIM_PXNUM` | Frozen AIM pricing number | `fi_spread_movement/config.py` |
| `CACHE_DIR_NAME` | Local cache folder name | `fi_spread_movement/config.py` |
| `CACHE_KEEP_RUNS` | Number of cached runs retained | `fi_spread_movement/config.py` |
| `QUERY_ATTEMPTS` | Maximum retry attempts for timeouts | `fi_spread_movement/config.py` |
| `AIM_ACCOUNT_BATCH` | Batch size for AIM account requests | `etf_capping/config.py` |
| `SECURITY_BATCH` | Batch size for security requests | `etf_capping/config.py` |
| `ACCOUNT_RULES` | Live AIM account runbook | `etf_capping/config.py` |
| `PRIMARY_FM_BY_AIM` | Legacy Excel Primary FM mapping | `etf_capping/config.py` |

Environment separation is achieved by:

- Keeping production-sensitive configuration separate from desensitized output copies.
- Using frozen request shapes and documented decision records rather than runtime discovery.
- Avoiding pre-filled sensitive values in UI inputs.
- Treating configuration changes as request-shape or business-rule changes requiring review.

**Section sources**
- [fi_spread_movement/config.py:26-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L26-L96)
- [fi_spread_movement/config.py:320-371](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L320-L371)
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [etf_capping/config.py:52-107](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L52-L107)
- [etf_capping/config.py:127-183](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L127-L183)

### Plugin Architecture for Extending Integrations
The repository does not expose a formal plugin framework. Instead, extensibility is achieved through:

- **Configuration-driven data sources:** New universes, spreads, and descriptors are added by extending configuration mappings.
- **Batching configuration:** Account and security batch sizes can be tuned per application.
- **Composition over inheritance:** Applications compose BQL requests, AIM lookups, and local caches rather than relying on deep class hierarchies.
- **Decision-record-gated changes:** New data items or request shapes are controlled by documented decisions and runtime authority documents.

```mermaid
graph LR
Config["Configuration Layer"] --> RequestBuilder["Request Builder"]
Config --> AIMRules["AIM Rules"]
Config --> CachePolicy["Cache Policy"]
RequestBuilder --> BQL["Bloomberg BQL"]
AIMRules --> AIM["AIM Holdings"]
CachePolicy --> LocalCache["Local CSV/JSON Cache"]
```

**Diagram sources**
- [fi_spread_movement/config.py:46-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L46-L96)
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [fi_spread_movement/cache.py:346-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L346-L348)

**Section sources**
- [fi_spread_movement/config.py:46-96](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/config.py#L46-L96)
- [etf_capping/config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [fi_spread_movement/cache.py:346-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L346-L348)

## Dependency Analysis
The applications have clear boundaries between configuration, data fetching, caching, and presentation. Dependencies are mostly unidirectional:

- `app.py` depends on `config.py`, `data.py`, `cache.py`, and visualization components.
- `data.py` depends on `config.py` and the Bloomberg BQL interface.
- `cache.py` depends on `config.py` for directory and retention settings.
- `engine.py` and `data.py` in ETF Capping depend on `config.py` for account rules and batching.

```mermaid
graph TB
APP_FI["FI Spread app.py"] --> CONFIG_FI["FI Spread config.py"]
APP_FI --> DATA_FI["FI Spread data.py"]
APP_FI --> CACHE_FI["FI Spread cache.py"]
APP_ETF_SPREAD["ETF Spread app.py"] --> CONFIG_ETF_SPREAD["ETF Spread config.py"]
APP_ETF_SPREAD --> DATA_ETF_SPREAD["ETF Spread data.py"]
APP_ETF_SPREAD --> CACHE_ETF_SPREAD["ETF Spread cache.py"]
APP_ETF_CAP["ETF Capping app.py"] --> CONFIG_ETF_CAP["ETF Capping config.py"]
APP_ETF_CAP --> DATA_ETF_CAP["ETF Capping data.py"]
APP_ETF_CAP --> ENGINE_ETF_CAP["ETF Capping engine.py"]
```

**Diagram sources**
- [etf_spread/app.py:1-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L54)
- [fi_spread_movement/app.py:2511-2537](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2511-L2537)
- [etf_capping/config.py:1-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L16)
- [etf_capping/data.py:807-861](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L807-L861)

**Section sources**
- [etf_spread/app.py:1-54](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L54)
- [fi_spread_movement/app.py:2511-2537](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L2511-L2537)
- [etf_capping/config.py:1-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L1-L16)
- [etf_capping/data.py:807-861](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L807-L861)

## Performance Considerations
Performance is managed through request shaping, caching, and conservative defaults:

- **Narrow requests:** One-item requests reduce the risk of exceeding Desktop’s two-minute limit.
- **Bounded retries:** Only timeouts are retried, and only once.
- **Cached runs:** Clean runs are persisted so future updates can reuse results after timeouts.
- **Settled data caching:** In ETF Spread Monitoring, settled daily rows are cached while recent rows remain fresh.
- **Identity-aware cache invalidation:** Cache entries are invalidated when code contracts or security identities change.
- **Batching:** AIM account and security requests are batched to reduce call volume.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common integration issues and their handling:

| Issue | Symptom | Expected Behavior |
|---|---|---|
| Bloomberg Desktop timeout | Query takes close to two minutes | Retry once; if still failing, show cached result if available |
| Missing BQL entitlement | Deterministic error | Fail immediately without retry |
| Invalid ticker or rejected item | Deterministic error | Fail immediately without retry |
| Stale cache | Old data shown | Cache must be labeled “Cached,” not “Updated” |
| Corrupted cache file | Missing or partial data | Treat as no cache; re-request |
| AIM session or connection change | Queries stop executing | Reconnect before changing code |
| Portfolio service unavailable | Portfolio functions fail | Require additional enablement through Bloomberg Account representative |

**Section sources**
- [05-get-started.md:196-204](file://RAG KB/05-get-started.md#L196-L204)
- [fi_spread_movement/cache.py:257-348](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L257-L348)
- [test_cache_fallback.py:1-39](file://User scripts/FI Spread Movement Monitoring/tests/test_cache_fallback.py#L1-L39)
- [14-bql-for-port-prep.md:399-412](file://RAG KB/14-bql-for-port-prep.md#L399-L412)

## Conclusion
The Bloomberg BQuant integration architecture in this repository is a pragmatic, operationally focused design. It prioritizes reliability over automation:

- BQL requests are narrow, observable, and resilient to timeouts.
- AIM connectivity is explicit, batched, and tied to frozen operational contracts.
- Excel exports support legacy workflows without introducing unnecessary complexity.
- The cache layer provides meaningful offline capability while clearly distinguishing cached data from fresh data.
- Configuration is centralized per application and treated as a boundary between business rules and runtime behavior.
- Extensibility is achieved through configuration and documented decision records rather than a formal plugin framework.

For new integrations, the safest approach is to follow the established pattern: freeze request shapes, validate inputs, handle deterministic failures immediately, retry only transient timeouts, persist clean runs, and make cache behavior visible to the operator.

[No sources needed since this section summarizes without analyzing specific files]