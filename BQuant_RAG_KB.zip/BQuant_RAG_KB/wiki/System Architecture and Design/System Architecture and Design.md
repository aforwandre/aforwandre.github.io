# System Architecture and Design

<cite>
**Referenced Files in This Document**
- [instruction.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [User scripts/ETF Spread Monitoring/etf_spread/app.py](file://User scripts/ETF Spread Monitoring/etf_spread/app.py)
- [User scripts/ETF Spread Monitoring/etf_spread/data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py)
- [User scripts/FI Index Change/fi_index_change/app.py](file://User scripts/FI Index Change/fi_index_change/app.py)
- [User scripts/FI Index Change/fi_index_change/data.py](file://User scripts/FI Index Change/fi_index_change/data.py)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the Bloomberg BQuant platform design as implemented in this workspace. The system is a modular monolith composed of three independent analyst applications:

- ETF analytics: ETF capping monitoring and ETF spread monitoring.
- Fixed income analytics: FI index constituent change and FI spread movement monitoring.
- Equity screening: MDX scan.

Each application follows an MVC-like pattern inside Jupyter notebooks:

- Model: data adapters, request builders, parsers, and local caches.
- View: IPyWidgets dashboards with tables, charts, and interactive controls.
- Controller: notebook-side classes that bind events, validate inputs, orchestrate requests, and render results.

The platform integrates with Bloomberg BQL through `bql.Request` and `bq.execute`, connects to AIM for account-based fixed-income universes, and uses local CSV-based caches to reduce repeated Bloomberg calls. It is designed for Bloomberg Desktop environments, with strict rules about where requests may run and how failures are handled.

## Project Structure
The repository organizes each analyst application under `User scripts/<Project Name>/`. Each project contains:

- A package directory with controller, configuration, data access, engine, and optional cache modules.
- A `MAIN.ipynb` entry point used on Bloomberg Desktop.
- Optional tests, preview tooling, and upload mirrors for Desktop deployment.
- Documentation such as README files and decision records.

```mermaid
graph TB
Root["Workspace root"] --> ETFSpread["ETF Spread Monitoring<br/>etf_spread/"]
Root --> FIIndexChange["FI Index Change<br/>fi_index_change/"]
Root --> FISpreadMovement["FI Spread Movement Monitoring<br/>fi_spread_movement/"]
Root --> ETFCapping["ETF Capping Monitoring<br/>etf_capping/"]
Root --> MDXScan["MDX Scan<br/>mdx_scan/"]
Root --> KB["RAG KB"]
Root --> Instructions["instruction.md"]
Root --> VersionLog["VersionLog.md"]
```

**Diagram sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [VersionLog.md:1-335](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

**Section sources**
- [instruction.md:1-98](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

## Core Components
The platform has three major analytical domains, each with its own controller, data layer, and cache strategy.

| Domain | Primary packages | Controller class | Data adapter role | Cache role |
|---|---|---|---|---|
| ETF spread monitoring | `etf_spread` | `ETFSpreadMonitor` | Builds book and peer history payloads, maps identifiers, combines BQL items, and plans gap fills | Per-ID daily series cache for quotes, returns, NAVs, and flows |
| FI index change | `fi_index_change` | `FIIndexChangeApp` | Requests membership snapshots per effective date, parses multi-item responses, and prepares members | Historical snapshot cache keyed by index and month-end |
| FI spread movement monitoring | `fi_spread_movement` | `FISpreadMovementApp` | Builds index, AIM, bond, and comparison universes; ranks spread movers; attaches descriptors and series | Result cache keyed by universe, spread type, window, and top-N |

Key responsibilities:

- Controllers build widgets, bind event handlers, validate user input, and call data adapters only from explicit Update or Refresh actions.
- Data adapters construct BQL requests, execute them, normalize responses, handle timeouts, and return pandas frames.
- Caches store either raw time-series rows or complete run results, depending on the application’s correctness model.

**Section sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [User scripts/ETF Spread Monitoring/etf_spread/data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [User scripts/FI Index Change/fi_index_change/app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)
- [User scripts/FI Index Change/fi_index_change/data.py:41-58](file://User scripts/FI Index Change/fi_index_change/data.py#L41-L58)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:76-107](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L76-L107)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py:1-36](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L1-L36)

## Architecture Overview
At a high level, each application follows the same flow:

1. User interacts with IPyWidgets controls.
2. Controller validates inputs and builds a request specification.
3. Data adapter constructs one or more BQL requests.
4. Bloomberg Desktop executes the requests through `bq.execute`.
5. Responses are normalized into pandas frames.
6. Engine computes rankings, transitions, metrics, or spread changes.
7. Cache stores or serves settled data when applicable.
8. Controller renders tables, charts, and status surfaces.

```mermaid
graph TB
UI["IPyWidgets dashboard"] --> Controller["Application controller"]
Controller --> Validator["Input validation"]
Controller --> DataLayer["Data adapter"]
DataLayer --> BQL["Bloomberg BQL Request"]
BQL --> Execute["bq.execute"]
Execute --> Response["ArrowExecuteResponse / item frames"]
Response --> Parser["Response parser and frame normalizer"]
Parser --> Engine["Business logic engine"]
Engine --> Cache["Local cache"]
Engine --> View["Tables, charts, status"]
```

**Diagram sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [User scripts/ETF Spread Monitoring/etf_spread/data.py:604-636](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L604-L636)
- [User scripts/FI Index Change/fi_index_change/data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:780-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L800)

## Detailed Component Analysis

### ETF Spread Monitoring
The ETF spread monitor provides HSBC ETF tables, peer comparisons, and fund-flow heatmaps. Its controller manages strategy selection, history range, cache usage, fund filters, chart periods, and flow visualization.

#### MVC breakdown
- Controller: `ETFSpreadMonitor` binds refresh, filter, period, and chart events.
- Data layer: `fetch_spread_payload`, share-class directory fetching, peer linking, and parallel history planning.
- Cache: daily append-only series cache keyed by kind, fingerprint, and identifier identity.

```mermaid
classDiagram
class ETFSpreadMonitor {
+update_button
+strategy_filter
+history_range
+use_cache
+fund_filter
+chart_period
+render()
+_on_update()
+_show_results(visible)
}
class DataAdapter {
+fetch_spread_payload(today, book_source_name, peer_source_name, progress)
+fetch_parallel_histories(...)
+share_class_identities(...)
}
class HistoryCache {
+read_series(kind, root, fingerprint_value, identities)
+plan_gaps(kind, identifiers, cached, request_start, request_end, default_end)
+save(kind, frame, settled_before, root, fingerprint_value, identities)
}
ETFSpreadMonitor --> DataAdapter : "calls"
DataAdapter --> HistoryCache : "reads and writes"
```

**Diagram sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [User scripts/ETF Spread Monitoring/etf_spread/data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:267-323](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L267-L323)

Key behaviors:

- The cache stores raw request output for quotes, returns, NAVs, and flows, not derived metrics.
- Formula changes remain visible because derived spreads and percentages are computed after merging live and cached rows.
- Identifier identity is tracked through ISINs so a moved primary share class triggers full re-request rather than silently replaying old history.
- Fingerprinting uses executable source hashes so changing an item, fill parameter, currency, or date argument invalidates stale rows.

**Section sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:306-459](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L306-L459)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:1-14](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L1-L14)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:64-81](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L64-L81)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:201-231](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L201-L231)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:352-414](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L352-L414)

### FI Index Change
The FI index change dashboard shows index constituent adds and exits between two month-ends. It focuses on membership transitions, weight summaries, bucket charts, and detailed bond views.

#### MVC breakdown
- Controller: `FIIndexChangeApp` builds controls, binds Update, and renders summary, detail, export, and full-position tabs.
- Data layer: sequential membership requests per effective date, multi-item response parsing, and member preparation.
- Cache: historical snapshot cache keyed by index ticker and month-end.

```mermaid
sequenceDiagram
participant User as "Operator"
participant App as "FIIndexChangeApp"
participant Data as "data.fetch_index_payload"
participant BQL as "bq.execute"
participant Cache as "Historical snapshot cache"
User->>App : Click Update
App->>App : Validate index and month-end
App->>Data : fetch_index_payload(index_ticker, selected_date)
Data->>Cache : load_historical(previous_date)
alt Cache hit
Cache-->>Data : Snapshot frame
else Cache miss
Data->>BQL : bq.execute(member_request)
BQL-->>Data : Response
Data->>Data : Parse and prepare members
Data->>Cache : save_historical(previous_date)
end
Data-->>App : IndexPayload
App->>App : Build transition and render
```

**Diagram sources**
- [User scripts/FI Index Change/fi_index_change/app.py:685-738](file://User scripts/FI Index Change/fi_index_change/app.py#L685-L738)
- [User scripts/FI Index Change/fi_index_change/data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)

Important design points:

- Only the previous month-end is cached; the projected or current effective date is requested every time.
- Timeout detection avoids retrying deterministic failures such as missing items, entitlement errors, or invalid tickers.
- Missing required columns mark a month as partial and prevent caching incomplete snapshots.

**Section sources**
- [User scripts/FI Index Change/fi_index_change/app.py:307-321](file://User scripts/FI Index Change/fi_index_change/app.py#L307-L321)
- [User scripts/FI Index Change/fi_index_change/data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [User scripts/FI Index Change/fi_index_change/data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)
- [User scripts/FI Index Change/fi_index_change/data.py:713-800](file://User scripts/FI Index Change/fi_index_change/data.py#L713-L800)

### FI Spread Movement Monitoring
The FI spread movement monitor ranks bonds by spread change across index, AIM account, single-bond, and AIM-vs-index comparison universes. It emphasizes robust error reporting, bounded retries, and result caching.

#### MVC breakdown
- Controller: `FISpreadMovementApp` manages universe selection, spread type, dates, filters, Top N display controls, and export.
- Data layer: frozen BQL shapes for index, AIM, and bond universes; ranking, descriptor, duration family, and series requests.
- Cache: CSV-based result cache keyed by run parameters.

```mermaid
flowchart TD
Start(["Update clicked"]) --> Validate["Validate universe, spread, and dates"]
Validate --> BuildRequest["Build BQL request(s)"]
BuildRequest --> Execute["bq.execute with attempts"]
Execute --> Timeout{"Timeout?"}
Timeout --> |Yes| Retry["Retry identical request once"]
Retry --> Success{"Answered?"}
Timeout --> |No| Parse["Parse response"]
Success --> |Yes| Parse
Success --> |No| FallbackCheck["Check saved run"]
Parse --> Engine["Rank movers, attach descriptors and series"]
Engine --> Save["Save successful run"]
Save --> Render["Render ranked tables, charts, and status"]
FallbackCheck --> |Cached| LoadSaved["Load saved result"]
FallbackCheck --> |Not cached| Error["Show live failure"]
LoadSaved --> Render
Error --> End(["End"])
Render --> End
```

**Diagram sources**
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)

Key behaviors:

- Only timeout exceptions trigger a second identical attempt. Deterministic failures are never retried.
- A cached screen is labeled `Cached`, not `Updated`, and preserves the original request label.
- The result cache stores ranked sides, descriptors, series, diagnostics, and request metadata.
- AIM connectivity uses frozen request shapes with `accounts`, `pxnum`, and `profile` parameters.

**Section sources**
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:123-162](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L123-L162)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:361-392](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L361-L392)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py:162-232](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L162-L232)

### Event-Driven Widget Architecture
All three platforms use IPyWidgets as the presentation layer. Controllers:

- Construct widgets without executing data requests.
- Bind event handlers for Update, Refresh, dropdowns, checkboxes, and table clicks.
- Guard against concurrent updates using flags such as `_running`, `_busy`, or `_view_busy`.
- Separate view-only redraws from data-fetching operations.

```mermaid
sequenceDiagram
participant Widget as "IPyWidgets control"
participant Controller as "App controller"
participant Data as "Data adapter"
participant View as "Dashboard surface"
Widget->>Controller : on_click / observe value
Controller->>Controller : Check running flag
alt View-only control
Controller->>View : Redraw from loaded frames
else Data request
Controller->>Data : Build and execute request
Data-->>Controller : Frames and diagnostics
Controller->>View : Render updated tables and charts
end
```

**Diagram sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:461-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L461-L486)
- [User scripts/FI Index Change/fi_index_change/app.py:579-595](file://User scripts/FI Index Change/fi_index_change/app.py#L579-L595)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)

**Section sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:461-486](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L461-L486)
- [User scripts/FI Index Change/fi_index_change/app.py:579-595](file://User scripts/FI Index Change/fi_index_change/app.py#L579-L595)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:656-721](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L656-L721)

## Dependency Analysis
The main dependency relationships are:

- Controllers depend on configuration, data adapters, engines, and optional cache modules.
- Data adapters depend on BQL, configuration, and sometimes cache helpers.
- Caches depend on pandas, JSON manifests, and file-system paths but do not build BQL requests.
- Tests and preview tooling depend on generated artifacts such as `preview/interface.html` and `Upload/` mirrors.

```mermaid
graph LR
AppETF["ETF app.py"] --> DataETF["ETF data.py"]
AppETF --> CacheETF["ETF cache.py"]
AppFIIndex["FI Index app.py"] --> DataFIIndex["FI Index data.py"]
AppFIMovement["FI Movement app.py"] --> DataFIMovement["FI Movement data.py"]
AppFIMovement --> CacheFIMovement["FI Movement cache.py"]
DataETF --> BQL["BQL"]
DataFIIndex --> BQL
DataFIMovement --> BQL
```

**Diagram sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:1-55](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L55)
- [User scripts/ETF Spread Monitoring/etf_spread/data.py:1-48](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L1-L48)
- [User scripts/FI Index Change/fi_index_change/app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [User scripts/FI Index Change/fi_index_change/data.py:1-34](file://User scripts/FI Index Change/fi_index_change/data.py#L1-L34)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:1-62](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1-L62)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:1-49](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L1-L49)

**Section sources**
- [User scripts/ETF Spread Monitoring/etf_spread/app.py:1-55](file://User scripts/ETF Spread Monitoring/etf_spread/app.py#L1-L55)
- [User scripts/FI Index Change/fi_index_change/app.py:1-50](file://User scripts/FI Index Change/fi_index_change/app.py#L1-L50)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:1-62](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L1-L62)

## Performance Considerations
The platform addresses performance through several mechanisms:

- Splitting heavy requests into smaller groups where needed.
- Limiting retries to timeout cases only.
- Using local caches for settled history or completed runs.
- Avoiding unnecessary network calls for view-only controls.
- Grouping related measures into one BQL request where possible.

Specific patterns:

- ETF spread monitoring plans per-identifier gaps and merges live rows over stored rows.
- FI index change prunes analytics fields and avoids optional retries that previously widened failed requests.
- FI spread movement monitoring caps request breadth, groups duration measures, and keeps total request counts stable.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common operational signals and their meanings:

| Signal | Meaning | Recommended action |
|---|---|---|
| `Idle` or `Please Click Update` | No data loaded | Enter inputs and click Update. |
| `Processing` | Controller is executing work | Wait; do not start another concurrent run. |
| `Updated` | Fresh data arrived | Review status detail and logs. |
| `Cached` | Saved result served from disk | Inspect cache age and request label. |
| `Refused` | Input or BQL shape was rejected | Fix inputs or field configuration. |
| `Error` | Local exception during processing | Read stage name, file, line, and function. |
| `partial` | Required column missing or identity values empty | Do not trust cache; next Update will re-request. |

Failure handling principles:

- Timeouts are retried once with the identical request.
- Deterministic failures are not retried.
- Failed fields are reported by name and do not hide other successful measures.
- Local reshape errors are distinguished from Bloomberg refusals by naming the update stage.
- Cached screens are visually distinct from fresh screens.

**Section sources**
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:63-86](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L63-L86)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:235-253](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L235-L253)
- [User scripts/FI Index Change/fi_index_change/data.py:499-538](file://User scripts/FI Index Change/fi_index_change/data.py#L499-L538)
- [User scripts/FI Index Change/fi_index_change/data.py:541-595](file://User scripts/FI Index Change/fi_index_change/data.py#L541-L595)

## Conclusion
The Bloomberg BQuant platform in this workspace is a disciplined modular monolith. Each analyst application owns its UI, business logic, data access, and caching behavior while sharing common concerns:

- Strict separation between user interaction and Bloomberg API calls.
- Conservative cache semantics that avoid serving stale or partially parsed data.
- Explicit timeout handling that does not mask deterministic failures.
- Clear status and logging surfaces for operators.
- Deployment constraints tailored to Bloomberg Desktop environments.

The architecture favors safety and traceability over automation: requests are intentional, caches are auditable, and failures are labeled with enough context to diagnose whether the problem is upstream at Bloomberg, mid-layer in parsing, or downstream in rendering.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Configuration Management
Configuration is kept close to the module that consumes it:

- ETF spread monitoring configures book sources, peer mapping, history ranges, and cache enablement.
- FI index change configures month-end choices, query attempts, split behavior, and display widths.
- FI spread movement monitoring configures universe sources, spread types, window size, top-N limits, and cache directories.

Operational rules:

- Do not install packages from this workspace.
- Do not run data requests from this Mac unless explicitly instructed.
- Do not merge unrelated notebooks into sibling projects.
- Keep new code under `User scripts/<Project Name>/`.

**Section sources**
- [instruction.md:13-18](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:78-83](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)

### Bloomberg BQL Integration Layer
The integration layer is narrow and explicit:

- Requests are built with `bql.Request(universe, items, with_params=...)`.
- Execution goes through `bq.execute`.
- Responses are adapted to pandas frames with consistent `ID` and optional `DATE` keys.
- Arrow-style responses are supported through multiple lookup strategies and a documented fallback.

**Section sources**
- [User scripts/ETF Spread Monitoring/etf_spread/data.py:604-636](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L604-L636)
- [User scripts/FI Index Change/fi_index_change/data.py:494-497](file://User scripts/FI Index Change/fi_index_change/data.py#L494-L497)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:780-800](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L780-L800)

### AIM Connectivity
AIM connectivity is frozen to a documented contract:

- Universe expression: `bq.univ.members(type="AIM")`.
- Parameters: `accounts=[one code]`, `pxnum`, and `profile="DEFAULT_PROFILE"`.
- No dates on the AIM members request.
- Non-integer `AIM_PXNUM` is refused before any request is sent.

**Section sources**
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:16-27](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L16-L27)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:361-392](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L361-L392)

### Cache Management Systems
Two cache models coexist:

| Application | Cache unit | Key | Invalidation rule |
|---|---|---|---|
| ETF spread monitoring | Per-ID daily row | Kind, fingerprint, identifier identity | Contract, generation, fingerprint, and ISIN mismatch |
| FI index change | Month-end snapshot | Index ticker and month-end | Required-column absence and cache-safety checks |
| FI spread movement monitoring | Complete run result | Source, universe, AIM, spread, start, end, top-N | Generation token and changed pipeline semantics |

**Section sources**
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:29-51](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L29-L51)
- [User scripts/ETF Spread Monitoring/etf_spread/cache.py:135-164](file://User scripts/ETF Spread Monitoring/etf_spread/cache.py#L135-L164)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py:48-56](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L48-L56)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py:102-138](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/cache.py#L102-L138)

### Logging, Monitoring, and Performance Optimization
Logging and monitoring are primarily operator-facing:

- Status bars show phase and environment activity.
- Detail panels explain why a screen is fresh, cached, refused, or errored.
- Step logs record request attempts, timing, and failed fields.
- Export tabs preserve receipts and request logs for offline review.

Performance optimization focuses on reducing redundant work:

- View-only controls redraw from memory.
- Caches serve settled history or saved runs.
- Request grouping reduces BQL calls.
- Retries are limited to timeouts.

**Section sources**
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py:185-222](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/app.py#L185-L222)
- [User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py:165-215](file://User scripts/FI Spread Movement Monitoring/fi_spread_movement/data.py#L165-L215)

### Deployment Topology
Deployment targets Bloomberg Desktop environments:

- Notebooks and runtime packages are copied into Desktop projects.
- Preview tooling is local development aid and is not the production interface.
- Upload mirrors are generated artifacts, not hand-edited copies.
- Some projects have a local refresh command that runs tests, rebuilds previews, restarts preview servers, and syncs uploads.

Relationship between local development and production:

- Local tests and previews validate logic without sending Bloomberg requests.
- Production runs execute on Bloomberg Desktop kernels with real BQL access.
- Generated artifacts must stay in sync with source packages.

**Section sources**
- [instruction.md:25-41](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:43-53](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)
- [instruction.md:55-76](file://RAG KB/PROJECT_OPERATIONS_AND_HISTORY.md)