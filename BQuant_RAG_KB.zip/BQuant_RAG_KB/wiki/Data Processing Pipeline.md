# Data Processing Pipeline

<cite>
**Referenced Files in This Document**
- [data.py](file://User scripts/ETF Capping Monitoring/etf_capping/data.py)
- [engine.py](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py)
- [config.py](file://User scripts/ETF Capping Monitoring/etf_capping/config.py)
- [README.md](file://User scripts/ETF Capping Monitoring/README.md)
- [bundle_examples_registry.json](file://RAG KB/bundle_examples_registry.json)
- [18-using-pandas.md](file://RAG KB/18-using-pandas.md)
- [data.py](file://User scripts/ETF Spread Monitoring/etf_spread/data.py)
- [engine.py](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py)
- [config.py](file://User scripts/ETF Spread Monitoring/etf_spread/config.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Guidelines for Extending the Pipeline](#guidelines-for-extending-the-pipeline)
10. [Conclusion](#conclusion)

## Introduction
This document describes the data processing pipeline architecture used by the Bloomberg BQuant-based monitoring applications in this repository. The pipeline ingests AIM portfolio positions, Bloomberg reference and pricing data, and external configuration, then validates, cleans, transforms, aggregates, and formats the data for capping monitors, spread analysis, visualization, reporting, and export.

Two main pipelines are present:
- ETF Capping Monitoring: converts AIM positions into company-level weights, applies capping rules, and produces alerts and diagnostics.
- ETF Spread Monitoring: loads book and peer observations, computes spreads, summarizes statistics, and prepares chart-ready time series.

The design emphasizes robust response parsing, explicit column contracts, safe numerical operations, diagnostic logging, and clear separation between ingestion, transformation, and output formatting.

## Project Structure
The relevant code is organized by application under `User scripts`, with each application following a consistent pattern:
- `data.py`: data ingestion, request building, response parsing, normalization, and enrichment.
- `engine.py`: pure-Pandas transformation, aggregation, validation, alerting, and view construction.
- `config.py`: static runbooks, thresholds, batch sizes, display metadata, and source selection.
- `app.py` and notebooks: orchestration, UI integration, and user workflows.

```mermaid
graph TB
subgraph "ETF Capping Monitoring"
CData["etf_capping/data.py"]
CEngine["etf_capping/engine.py"]
CConfig["etf_capping/config.py"]
CApp["etf_capping/app.py"]
end
subgraph "ETF Spread Monitoring"
SData["etf_spread/data.py"]
SEngine["etf_spread/engine.py"]
SConfig["etf_spread/config.py"]
SApp["etf_spread/app.py"]
end
subgraph "Bloomberg BQL"
BQL["bql.Request / execute_many"]
end
subgraph "External Inputs"
AIM["AIM Portfolio Positions"]
Ref["Reference & Pricing Data"]
Runbook["Capping Runbook & Exceptions"]
BookPeer["Book & Peer Observations"]
end
AIM --> CData
Ref --> CData
Runbook --> CEngine
BookPeer --> SData
SData --> SEngine
CData --> CEngine
CEngine --> CApp
SEngine --> SApp
CData --> BQL
SData --> BQL
```

**Diagram sources**
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

**Section sources**
- [README.md:1-33](file://User scripts/ETF Capping Monitoring/README.md#L1-L33)
- [bundle_examples_registry.json:41-77](file://RAG KB/bundle_examples_registry.json#L41-L77)

## Core Components
The pipeline has four primary responsibilities:
1. Ingestion: build and execute BQL requests for AIM positions, descriptors, fundamentals, Thai local pricing mappings, and USD pricing; load book and peer observation sources.
2. Validation and cleaning: enforce required columns, normalize IDs and dates, clean text values, handle malformed or missing fields, and record diagnostics.
3. Transformation: compute market values, security weights, company aggregations, capping status, spread metrics, and summary statistics using pandas and numpy.
4. Output formatting: produce monitor tables, alerts, diagnostics, chart frames, and structured payloads for visualization and export.

Key components:
- ETF Capping ingestion layer: `_fetch_positions`, `_fetch_descriptors`, `_fetch_fundamental_tickers`, `_select_thai_pricing_tickers`, `_fetch_thai_drsk_mappings`.
- ETF Capping engine: `_calculate_position_values`, `_calculate_security_weights`, `_attach_company_mapping`, `_group_positions`, `calculate_monitor`.
- ETF Spread ingestion layer: placeholder and future Bloomberg adapters, `_combine_items`, currency-aware combining, AUM conversion, share-class listing handling.
- ETF Spread engine: `prepare_observations`, `quote_spread_bps`, `period_bounds`, `_summarize`, `build_view`.

**Section sources**
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [engine.py:233-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L404)
- [engine.py:407-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L554)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)
- [engine.py:97-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L152)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:217-291](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L291)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

## Architecture Overview
The pipeline follows a layered architecture:
- Data Layer: builds BQL requests, executes them safely, parses heterogeneous responses, normalizes to standardized DataFrame schemas, and merges auxiliary data.
- Engine Layer: performs deterministic, pure-Pandas transformations, validations, aggregations, and risk calculations.
- Configuration Layer: provides runbooks, thresholds, batch sizes, display labels, and source selection.
- Application Layer: orchestrates runs, surfaces progress, and renders outputs for users.

```mermaid
sequenceDiagram
participant User as "User Workflow"
participant App as "Application Layer"
participant Data as "Data Layer"
participant BQL as "Bloomberg BQL"
participant Engine as "Engine Layer"
participant Output as "Visualization / Reporting"
User->>App : Trigger refresh
App->>Data : Fetch AIM positions and reference data
Data->>BQL : Execute many labeled requests
BQL-->>Data : Responses (ArrowExecuteResponse / items)
Data->>Data : Parse, normalize, merge, enrich
Data-->>Engine : Normalized positions + metadata
Engine->>Engine : Validate, clean, compute values and weights
Engine->>Engine : Attach company mapping and group
Engine-->>Output : Monitor groups, alerts, diagnostics
Output-->>User : Charts, tables, reports
```

**Diagram sources**
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

## Detailed Component Analysis

### ETF Capping Monitoring: Data Ingestion Layer
Responsibilities:
- Build frozen AIM request shapes for Current and Projected positions.
- Batch account requests and preserve request lineage when some fail.
- Parse Arrow-like responses without assuming iteration support.
- Normalize item frames to ID (+DATE) plus one named value column.
- Merge multiple items on stable keys and drop duplicates deterministically.
- Resolve Thai foreign-line pricing tickers through approved overrides, fundamental ticker matching, and HelpDesk DRSK fallbacks.
- Fetch descriptors and fundamental mappings in batches.

Key functions and patterns:
- `_aim_request`: locked shape with `accounts`, `pxnum=1377`, and `profile='DEFAULT_PROFILE'`; does not add dates.
- `_execute_many`: uses `on_request_error=_on_request_error` and `num_retries=1`, pairing labels with responses.
- `_is_response` and `_response_items`: defensive checks that avoid misclassifying successful Arrow responses as errors.
- `_item_frame` and `_merge_item_frames`: normalize and merge BQL item responses.
- `_parse_response`: records per-request errors and empty results.
- `_fetch_positions`: extracts `ID` and `Position`, renames to `Ticker` and `Quantity`, groups by AIM Code and Ticker, sums quantities.
- `_fetch_descriptors`: requests Name and Market Status per ticker batch.
- `_fetch_fundamental_tickers`: maps equities to fundamental company tickers via `fundamentalticker()`.
- `_select_thai_pricing_tickers` and `_fetch_thai_drsk_mappings`: resolve Thai local pricing tickers with strict validation.

Error handling:
- Missing columns in position responses are logged and skipped.
- Empty parsed responses are recorded as errors.
- Response shape mismatches are handled gracefully without crashing.

```mermaid
flowchart TD
Start(["Fetch AIM Positions"]) --> BuildRequest["Build _aim_request<br/>Current or Projected"]
BuildRequest --> ExecuteMany["_execute_many<br/>labeled_requests"]
ExecuteMany --> ParseResponse{"Response valid?"}
ParseResponse --> |No| RecordError["Record error<br/>and return empty frame"]
ParseResponse --> |Yes| ExtractItems["_response_items / _lookup_item"]
ExtractItems --> NormalizeFrame["_item_frame<br/>ID(+DATE)+VALUE"]
NormalizeFrame --> MergeFrames["_merge_item_frames<br/>outer merge on ID/DATE"]
MergeFrames --> ExtractPositions["Extract ID/Position<br/>rename to Ticker/Quantity"]
ExtractPositions --> GroupSum["Group by AIM Code/Ticker<br/>sum Quantity"]
GroupSum --> End(["Normalized positions"])
```

**Diagram sources**
- [data.py:303-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L303-L319)
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:126-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L126-L183)
- [data.py:186-207](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L186-L207)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)

**Section sources**
- [data.py:287-319](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L287-L319)
- [data.py:259-284](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L259-L284)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [data.py:126-183](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L126-L183)
- [data.py:186-207](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L186-L207)
- [data.py:439-490](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L439-L490)
- [data.py:493-531](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L493-L531)
- [data.py:534-596](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L534-L596)
- [data.py:599-698](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L599-L698)
- [data.py:701-764](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L701-L764)

### ETF Capping Monitoring: Validation, Cleaning, and Transformation
Responsibilities:
- Enforce required input columns (`AIM Code`, `Ticker`, `Quantity`).
- Clean text fields, ensure equity suffixes, classify assets.
- Compute USD price and market value with robust handling of missing prices and market statuses.
- Calculate security weights safely, avoiding division by zero and infinities.
- Attach company mapping via exceptions and fundamental tickers.
- Aggregate by parent/issuer, compute dynamic limits, utilization, and capping status.
- Produce alerts, diagnostics, and grouped outputs.

Key functions and patterns:
- `_validate_positions`: raises if required columns are missing.
- `_clean_text` and `_ensure_equity_suffix`: normalize strings and asset suffixes.
- `classify_asset`: categorizes tickers into Cash, FFX, Index Future, Equity, Others.
- `_calculate_position_values`: handles zero-price market statuses, unresolved Thai pricing, reference data issues, missing quantity/price, and sets market value accordingly.
- `_safe_ratio`: replaces zeros with NaN before division and coerces infinities to NaN.
- `_calculate_security_weights`: computes per-security weight and flags zero-denominator accounts.
- `_attach_company_mapping`: applies exception overrides and fundamental ticker fallbacks, recording diagnostics.
- `_group_positions`: aggregates by AIM Code and Parent/Issuer Ticker, computes observed weights, headroom, utilization, capping status, and rank.
- `calculate_monitor`: orchestrates the full pipeline and returns `MonitorResult`.

Error handling:
- Missing runbook or exception columns raise explicit errors.
- Duplicate AIM codes or exception tickers raise validation errors.
- Diagnostics capture row-level and account-level issues such as missing quantity, missing price, zero denominator, and incomplete accounts.

```mermaid
flowchart TD
Input(["Normalized positions"]) --> Validate["_validate_positions"]
Validate --> CleanText["Clean text and ensure Equity suffix"]
CleanText --> Classify["classify_asset"]
Classify --> Values["_calculate_position_values<br/>Price USD, Market Value USD"]
Values --> Weights["_calculate_security_weights<br/>Weight per security"]
Weights --> Mapping["_attach_company_mapping<br/>Exceptions + Fundamental Ticker"]
Mapping --> Group["_group_positions<br/>Aggregation, Rank, Limit, Utilization"]
Group --> Alerts["Alerts and Diagnostics"]
Alerts --> Output(["MonitorResult"])
```

**Diagram sources**
- [engine.py:95-100](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L100)
- [engine.py:60-92](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L60-L92)
- [engine.py:233-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L404)
- [engine.py:407-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L440)
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

**Section sources**
- [engine.py:95-100](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L100)
- [engine.py:60-92](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L60-L92)
- [engine.py:233-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L404)
- [engine.py:407-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L440)
- [engine.py:150-230](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L150-L230)
- [engine.py:443-554](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L443-L554)
- [engine.py:557-615](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L557-L615)

### ETF Spread Monitoring: Data Ingestion Layer
Responsibilities:
- Load book and peer observations from configured sources (placeholder or future Bloomberg).
- Build deterministic placeholder quotes for development and testing.
- Combine multi-item BQL responses while preserving ID and DATE keys.
- Handle currency-aware merging and collapse duplicate static rows.
- Convert fund AUM to USD millions and map umbrella company IDs.
- Provide share-class directory and Isin book metadata.

Key functions and patterns:
- `fetch_spread_payload`: fetches book and peer sources, concatenates observations, determines `as_of`.
- Placeholder sources: `PlaceholderBookSource`, `PlaceholderPeerSource` generate deterministic time series.
- Future Bloomberg adapters: `BloombergBookSource`, `BloombergPeerSource` return diagnostics until route card approval.
- `_combine_items`: normalizes item frames, deduplicates keys, merges time-series and static items on ID (+DATE).
- `_combine_keeping_currency`: merges listing responses on ID and CURRENCY.
- `fund_aum_usd_millions`: converts native fund assets to USD millions using exchange rates.
- `company_id_from_frame`: reads umbrella company ID from frames.

Error handling:
- Unknown source names raise `ValueError`.
- Missing or invalid ID/date/value columns raise explicit errors during normalization.
- Currency mismatches cause rows to be dropped rather than mixing prices.

```mermaid
flowchart TD
Start(["Load Sources"]) --> SelectBook["Select book source<br/>placeholder or bloomberg"]
SelectBook --> SelectPeer["Select peer source<br/>placeholder or bloomberg"]
SelectBook --> FetchBook["Fetch book observations"]
SelectPeer --> FetchPeer["Fetch peer observations"]
FetchBook --> Concat["Concat observations"]
FetchPeer --> Concat
Concat --> Combine["_combine_items<br/>normalize + merge on ID(+DATE)"]
Combine --> CurrencyMerge["_combine_keeping_currency<br/>merge on ID+CURRENCY"]
CurrencyMerge --> Output(["SpreadPayload"])
```

**Diagram sources**
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)
- [data.py:760-787](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L760-L787)

**Section sources**
- [data.py:213-254](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L213-L254)
- [data.py:135-210](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L135-L210)
- [data.py:466-527](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L466-L527)
- [data.py:760-787](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L760-L787)
- [data.py:530-549](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L530-L549)
- [data.py:552-570](file://User scripts/ETF Spread Monitoring/etf_spread/data.py#L552-L570)

### ETF Spread Monitoring: Validation, Cleaning, and Transformation
Responsibilities:
- Prepare observations by validating required columns, normalizing dates and identifiers, filtering unusable rows, and computing midpoint spread in basis points.
- Determine quote status (ok, crossed, missing).
- Define period windows (YTD, 1M, 3M, 6M, 1Y, 3Y, 5Y, Custom).
- Summarize statistics per share class and peer group.
- Build chart-ready time series and final views.

Key functions and patterns:
- `prepare_observations`: enforces schema, sorts by DATE, drops duplicates, computes spread and quote status.
- `quote_spread_bps`: computes midpoint spread only when bid/ask are positive and ask >= bid.
- `quote_status`: classifies quotes as ok, crossed, or missing.
- `period_bounds`: validates preset periods and custom ranges.
- `_summarize`: computes last, mean, median, min, max, observations, and priced counts.
- `_chart_frame`: prepares chart columns and series names.
- `build_view`: slices cache, validates inputs, constructs summary and chart, and collects notes.

Error handling:
- Missing observation columns raise `KeyError`.
- Unknown periods or invalid custom ranges produce notes and blank views.
- Crossed quotes are left blank rather than treated as tight markets.

```mermaid
flowchart TD
Input(["Observations"]) --> Prepare["prepare_observations<br/>schema + date + spread"]
Prepare --> Period["period_bounds<br/>preset/custom window"]
Period --> Filter["Filter by selected share classes and peers"]
Filter --> Summarize["_summarize<br/>statistics per group"]
Summarize --> Chart["_chart_frame<br/>time series"]
Chart --> View["build_view<br/>summary + chart + notes"]
```

**Diagram sources**
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:217-291](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L291)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

**Section sources**
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)
- [engine.py:155-186](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L155-L186)
- [engine.py:217-291](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L217-L291)
- [engine.py:294-369](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L294-L369)

## Dependency Analysis
The pipeline exhibits clear separation of concerns:
- Data modules depend on configuration for batch sizes, thresholds, and static runbooks.
- Engine modules depend on normalized Data outputs and configuration constants.
- Applications orchestrate calls but do not contain core transformation logic.
- External dependencies include Bloomberg BQL and pandas/numpy.

```mermaid
graph LR
CConfig["etf_capping/config.py"] --> CData["etf_capping/data.py"]
CConfig --> CEngine["etf_capping/engine.py"]
CData --> CEngine
SConfig["etf_spread/config.py"] --> SData["etf_spread/data.py"]
SConfig --> SEngine["etf_spread/engine.py"]
SData --> SEngine
CEngine --> OutputC["MonitorResult"]
SEngine --> OutputS["SpreadView"]
```

**Diagram sources**
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [config.py:186-269](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L269)
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [config.py:84-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L84-L85)

**Section sources**
- [config.py:14-16](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L14-L16)
- [config.py:186-269](file://User scripts/ETF Capping Monitoring/etf_capping/config.py#L186-L269)
- [config.py:15-32](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L15-L32)
- [config.py:84-85](file://User scripts/ETF Spread Monitoring/etf_spread/config.py#L84-L85)

## Performance Considerations
- Batched BQL requests: both pipelines chunk accounts and securities to reduce request size and improve throughput.
- Defensive response parsing: avoids expensive iteration assumptions and supports Arrow responses.
- Deterministic deduplication: uses sorted merges and explicit key combinations to prevent accidental duplication.
- Safe numerics: replaces zeros before division and coerces infinities to NaN to avoid unstable computations.
- Minimal recomputation: caches derived lookups (e.g., group totals) and reuses cleaned frames.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and strategies:
- Malformed BQL responses:
  - Use `_is_response` and `_response_items` to detect valid responses and extract items safely.
  - Record errors via `_parse_response` and continue processing other requests.
- Missing or inconsistent columns:
  - Enforce required columns in `_validate_positions` and `prepare_observations`.
  - Raise explicit `KeyError` messages indicating missing fields.
- Missing values and non-numeric data:
  - Use `pd.to_numeric(..., errors="coerce")` and replace infinities with NaN.
  - For spreads, leave invalid quotes blank rather than filling with zero.
- Inconsistent formats:
  - Normalize IDs and dates early; strip whitespace and coerce types.
  - Clean text fields with `_clean_text` and `_clean_reference_value`.
- Zero denominators and ratios:
  - Replace zeros with NaN before division and flag zero-denominator accounts.
- Unresolved Thai pricing:
  - Log diagnostics for unresolved mappings and fall back to HelpDesk DRSK where appropriate.
- Empty states:
  - Return empty DataFrames with correct schemas instead of failing downstream.

**Section sources**
- [data.py:57-98](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L57-L98)
- [data.py:237-256](file://User scripts/ETF Capping Monitoring/etf_capping/data.py#L237-L256)
- [engine.py:95-100](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L95-L100)
- [engine.py:233-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L233-L404)
- [engine.py:402-404](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L402-L404)
- [engine.py:407-440](file://User scripts/ETF Capping Monitoring/etf_capping/engine.py#L407-L440)
- [engine.py:122-152](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L122-L152)
- [engine.py:97-119](file://User scripts/ETF Spread Monitoring/etf_spread/engine.py#L97-L119)

## Guidelines for Extending the Pipeline
To add new data sources or transformation rules:
1. Define a clear contract:
   - Required and optional columns.
   - Lineage metadata (request date, instrument key).
   - Separate errors from data.
2. Implement ingestion in the Data layer:
   - Build BQL requests with explicit item names and parameters.
   - Use `_execute_many` with labeled requests to preserve lineage.
   - Normalize responses to standardized frames using `_item_frame` or equivalent logic.
   - Merge on explicit keys (ID, DATE) and deduplicate deterministically.
3. Add validation and cleaning:
   - Enforce required columns and types.
   - Clean text and numeric fields consistently.
   - Record diagnostics for missing or malformed data.
4. Implement transformation in the Engine layer:
   - Keep functions pure-Pandas and stateless.
   - Use `_safe_ratio` for divisions and guard against zero denominators.
   - Aggregate with explicit grouping keys and documented aggregation functions.
5. Configure behavior:
   - Add thresholds, batch sizes, and display metadata in config.
   - Avoid importing sensitive files directly; use desensitized copies where needed.
6. Test partial failures and empty states:
   - Ensure empty valid responses are distinguished from failed requests.
   - Preserve request-level errors in logs.
   - Do not fill missing financial observations with zero unless economically meaningful.
   - Before pivoting, detect duplicate key combinations and choose explicit aggregation.

**Section sources**
- [18-using-pandas.md:232-281](file://RAG KB/18-using-pandas.md#L232-L281)
- [bundle_examples_registry.json:41-77](file://RAG KB/bundle_examples_registry.json#L41-L77)

## Conclusion
The data processing pipeline is designed for robustness, clarity, and extensibility. It separates ingestion, validation, transformation, and output formatting across well-defined modules. The ETF Capping Monitoring pipeline converts AIM positions into actionable capping insights with detailed diagnostics, while the ETF Spread Monitoring pipeline computes and summarizes spread metrics for visualization and reporting. By following the established contracts, error-handling strategies, and configuration patterns, new data sources and transformation rules can be integrated safely and predictably.

[No sources needed since this section summarizes without analyzing specific files]