---
description: BQL universe, field, response, and pandas safety for every answer
alwaysApply: true
---
# BQL and Pandas Safety

- Clear composition goal: open `RAG KB/BUNDLE_EXAMPLES.md` Goal table (one
  card) before inventing Request/pandas glue. Official cards teach BQL/API
  **usage** (product demos, not a full spec). Named ETF/MDX stay on
  `25`/`26`. ETF Spread Monitoring stays on `27`, and FI Index Change stays on `28`. Do not replace those
  freezes with a demo's feature set.

- Classify EQUITY vs CREDIT before copying a recipe. Do not put equity fields
  on a bond universe or treat an issuer equity ticker as a bond universe.
- Exact-search `22` before using a BQL data-item mnemonic; use `08` for
  semantics and `07`/`14` or an official tutorial for signatures.
- Prefer `bql.Request` and object syntax. A Python `str` Request universe is a
  security ID, never BQL source text.
- Use `bq.univ.members('HSI Index')`, never singular `member` or the string
  `"members('HSI Index')"`.
- Members weights are `bq.data.id()['weights']`; holdings weights are
  `bq.data.id()['WEIGHTS']`.
- Clean returned identifiers through documented metadata such as
  `id_isin()['value']`, `id_sedol1()['value']`, and `id_cusip()['value']`.
  Never invent an accessor such as `id_sedol`.
- A BQL `ID` may be an index. Do not assume `df['ID']` exists.
- Desktop can return a valid non-iterable `ArrowExecuteResponse`. Use
  `len`/indexing, `.get(name)`, or the documented combined-frame fallback.
- `execute_many(..., on_request_error=...)` mixes error tuples and valid
  responses. Preserve request lineage and classify each result before parsing.
  Generic zip-to-keys: Goal table `official_response_normalization`.
  AIM labeled error-tuples: `execute_many_labeled_lineage`. Do not invent
  a third concat.
- Arrow time series may store `DATE` as a column. Preserve `ID`, `DATE`, and
  values; merge multi-item frames on their real keys. Value-only concat is
  safe only when those keys remain in the index.
- Verify `DATE` before sorting, deduplicating, or dropping nulls. Log returned
  columns when the expected shape is absent.
- Use `with_params={'mode': 'cached'}` only where the routed recipe supports
  it. Do not use `setdiff()` when member metadata or weights are required.
