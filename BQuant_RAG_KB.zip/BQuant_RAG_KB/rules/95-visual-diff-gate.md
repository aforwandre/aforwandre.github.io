---
description: Cursor-style visual diff review - agent applies all edits first, user reviews each checkpoint afterwards
alwaysApply: true
---

# Visual Diff Review (Cursor-style, all platforms)

- Apply first, review after. Complete ALL planned edits in one pass - every
  file, every hunk. Edits land in the working tree immediately; never pause
  mid-task to ask for serial acceptance.
- After the batch, hand the user the full changeset for review. Each changed
  file (and each hunk or line within it) is an independent checkpoint: the
  user may accept or reject any of them separately, or Accept All /
  Reject All in one click. Use each IDE's native review UI (Cursor floating
  review bar, Qoder diff view, TRAE changes list); for selective acceptance,
  reject unwanted lines, then Accept all.
- A rejected checkpoint is a reverted edit. Do not re-apply a rejected edit
  in the same task; if everything is rejected, stop and ask what to change.
- Derived artifacts (sync-script mirrors, RAG bundles) form a second batch:
  show `python3 .qoder/sync_rules.py --dry-run` output first, run for real
  after the source changeset is accepted, then let the user review that
  batch with the same controls. The operator has ruled that rule syncing
  itself runs automatically at task end without asking (`--check` must end
  `rule-sync=ok`).
- Never dodge review: no writing to another path, no splitting a change
  into smaller steps to escape it, no silent redo of a rejected edit.
