---
description: ETF Spread Monitoring quote, period, and placeholder boundaries
globs: User scripts/ETF Spread Monitoring/**
alwaysApply: false
---
# ETF Spread Monitoring

- This named destination's highway is `RAG KB/27-etf-spread-monitor.md`,
  not `BUNDLE_EXAMPLES.md`. The Goal table may lend the Update-only `MAIN`
  shape. It does not supply a quote field or a peer universe.

- **Highest priority:** never request, probe, test, generate, or use ESG, GHG,
  climate, or sustainable-finance data items for mapping, fallback,
  diagnostics, experiments, or any other purpose. A violation can cause the
  user's Bloomberg account to be suspended or deleted.
- User-confirmed validation scope (2026-10-22 / 2026-10-24) covers the share-class request from the 2026-10-22 HelpDesk sample and: `id_bb_company()['value']`
  as an umbrella filter, `fundsuniv("active")`, then `id()['value']`,
  `name()['value']`, `fund_comp_name()['value']`,
  `fund_open_shr_class()['value']`,
  `id_isin()['value']`, `fund_expense_ratio()['value']`, bare `crncy()`,
  and bare `px_bid()`, `px_ask()`, `px_mid()`, and `px_last()`. The same
  share-class request also reads bare `fund_class_assets()` and
  `fund_class_assets_crncy()`. Quotes, currency, and class assets used
  for the spread are one cached request on the typed listing ticker, not on
  the ISIN, and that request has no ``showids`` and no request-level
  currency. Fund AUM stays a separate request, one listing ticker per
  fund (the Primary Yes row when that row is present):
  `fund_total_assets(currency='USD')`, then divided by one million and
  copied onto each share class. The
  currency code is not a rate. Do not put `currency='USD'` on the quote
  request. Do not sum share classes into that column.
  `fund_class_assets` does not take `currency` and is already in millions.
  The same three quote items may be requested again for book tickers and for the resolved peer tickers, with
  `dates=bq.func.range("-5y", "0d")` and `mode="cached"`, and with no
  `fill`. Each of those requests holds at most 8 identifiers, and
  `execute_many` sends up to 8 requests in one wave. The two-minute
  limit is one request. Quote history, total return, and fund flow stay
  separate requests. Averages then carry the previous spread onto weekdays
  that returned no quote. The schedule is Monday to Friday; one-off exchange
  holidays are not filtered and use the same carry-forward rule. One row is kept per fund and ISIN: the typed ticker wins, otherwise a listing that has both a bid and an ask. The rows that reach the app are then projected onto `ISIN_BOOK`: exactly the typed lines, in typed order. A linked share class that is not typed is dropped, and a typed line is never swapped for another class of that fund. A typed line Bloomberg did not return keeps its typed identity and blank enrichment; it is not removed.
  A Bloomberg assistant reply is not a signature. When it conflicts with
  topic 27 or this file, the RAG KB stays. A Desktop print can confirm a
  call that already matches those sources. The book Strategy key is the
  text typed on `IsinEntry`, not `fund_strategy()`. It is not a table column. It drives the top dropdown and the fund menu.
  `fund_strategy()` is not the peer key. Peer membership is the manual
  list in `etf_spread/peer_map.py`: each row is one HSBC fund name, the same
  text as `IsinEntry.fund_name`, and one peer ISIN. Every share class of
  that fund uses the same list. Update resolves each peer ISIN to that
  fund's single primary ISIN.
  Zero or several primary ISINs skip that fund. Publication-currency lines
  are removed by keeping the response `CURRENCY` that matches `crncy()`;
  if none match, the lines are dropped. On the peer listing, `crncy()` may
  return only `ID` and `CURRENCY`; that column is the share-class currency.
  One unread listing batch is skipped and does not drop the other batches.
  Desktop 2026-10-30: raising "no single value column" on that shape cleared
  every peer while the HSBC rows stayed. Do not restore that raise. A
  peer-map name that is not exactly `IsinEntry.fund_name` skips that fund
  only. Do not treat a few mismatches as a blank peer list, and do not use
  the displayed `long_comp_name` as the join key.
  One ticker is then kept per primary
  ISIN. Quotes use that ticker. There is no benchmark screen and no
  200-name cap. `univ.peers` is not this screen. The book benchmark column
  is `long_comp_name()['value']` of the `fund_benchmark_prim` index id.
  `etf_undl_index_ticker()` is not that column and is not the peer
  predicate. The typed Strategy text is not a BQL predicate. Total return
  is `tot_return_index_gross_dvds(dates=bq.func.range("-5y","0d"), currency="USD", fill="prev")`
  on the ETF, its peers, and its benchmark. NAV Return is a separate cached
  request, `fund_net_asset_val(dates=..., currency="USD", fill="prev")`, on the
  same identifiers. The percent is the same pandas formula. It is not `px_last`. The NAV table and the NAV chart use that same Bmk Return column. There is no Bmk NAV Return column, and the benchmark index is not on the NAV request.
  The benchmark id is
  `fund_benchmark_prim()['value']` plus ` Index` when needed. An N/A token is left blank and is not requested. Return percent
  is `(end / start - 1) * 100`. Those dates are the HSBC listing's quote
  dates. A London holiday keeps the last print on or before the HSBC quote
  date. A later level is not used. Return mode adds `Bmk Return %` and the
  return chart draws it. A 0.09 expense ratio stays 0.09. It is the net ratio.
  Do not use
  `average_bid_ask_spread_pct` for the period columns. Tracking error has two columns: `tracking_error()['value']`
  (PX_LAST based) and `nav_tracking_error()['value']` (NAV based,
  `Net Asset Value Tracking Error`). Both are separate cached requests on
  the typed ticker for the HSBC book and for priced peers. The catalog
  entries have no window argument. Display both as percent (vendor value
  x100) with headers `1Y Tracking Error (%)` and `1Y NAV Tracking Error (%)`.
  The quote spread headers are `Latest Spread` and `Latest Spread %`.
  The operator confirmed the NAV item on the FLDS tab on 2026-10-24; its
  units and semantics stay on the Desktop validation list. A failed batch leaves the cell blank. A 0.3 percent expense ratio
  arrives as 0.3. Do not divide it by 100. The controls above the tabs are Strategy and Refresh. Refresh loads that Strategy once. The tabs stay hidden until it finishes. Changing Strategy hides them until the next Refresh. It filters the HSBC ETF
  table, the Flow heatmap, and Peers Details together. Fund sits on the
  HSBC ETF tab and on Peers Details, and both lists follow that Strategy.
  Primary stays a table column. Geographic Focus, Industry Focus, and
  Exchange are not requested and are not table columns.
  The HSBC ETF tab is named
  HSBC ETF. The table shows exactly the typed IsinEntry rows, in typed order. There is no Primary Share only checkbox. Spread and Return default on. Peer Average is one dropdown, Peers only or HSBC + Peers,
  exactly one of those, from the cache. A period button above a table
  hides or shows that period's columns. The buttons replace the period
  checkboxes and start closed. Custom stays a checkbox with its dates.
  Fund Name is the grid row header
  so it stays on screen while the other columns scroll. Clicking a row plots the selected mode: spread percent, return, or both
  stacked. The spread chart draws Spread % and Peer Avg Spread % only.
  The return chart draws Return %, Peer Avg Return %, and Bmk Return %.
  The legend is one line per series, under the plot.
  Peers Details repeats those charts and adds one line for each Top 5 Peer.
  Chart Period is shared by both tabs and does not send a request. The chart sits under
  the table, and the table height follows the row count. The Flows tab
  has no taxonomy treemap. It has no share-class switch. It shows one line per fund name
  for the same Strategy and Fund as the HSBC table. Rows keep the typed IsinEntry order,
  the same order as the HSBC ETF tab. A shared long name is qualified with the typed fund
  name so the heatmap keeps one row per fund.
  fund_flow is a fund figure, so share classes of one fund are not added.
  The kept ticker is the Primary Yes row when that row is present.
  HSBC + Peers adds the peer funds' flows onto that same line.
  Peers Details lists each selected fund's typed IsinEntry row and then
  that fund's primary peers. HSBC anchors keep the typed IsinEntry order. Its fund control is Fund, including All.
  Chart Period under that table is the same control as on HSBC ETF.
  Spread, Return, and Custom follow the HSBC ETF tab.
  The period buttons above both tables are the only standard-period control.
  They share one open or closed state, so one press redraws both tables.
  Fund Info sits to the left of those buttons and starts open. Closing it
  hides Class Name, ISIN, Currency, Class AUM, PX_LAST, PX_BID, PX_ASK,
  Benchmark, and Primary on both tables. Fund Name and Fund AUM
  stay. A peer row leaves Peer Avg blank. Last, fund assets, class assets,
  both tracking errors, and the benchmark name use the same
  request families as the HSBC book, on that peer's ticker or primary ISIN.
  The peer profile request still returns `fund_strategy()`, and that value
  is not displayed.
  Bmk Return on a peer row is that peer's own benchmark. Its own spread and
  return still come from the history Refresh already loaded. A failed peer
  batch leaves that column blank and does not clear the HSBC book. On Peers
  Details an HSBC row is bold and its fund-name cell is tinted. Number cells
  do not take a color expression. Absolute spread is ask minus
  bid. Percent spread is that difference divided by the mid, then
  multiplied by 100, because the column header already says percent.
  A blank PX_MID is (PX_BID + PX_ASK) / 2 on every spread-percent path. Return does not use PX_MID. A peer row's Latest Spread %
  reads that mid from the quote history. Period columns are Avg Spread %
  and Peer Avg Spread %. The absolute period average is not calculated.
  Latest Spread stays. The percent average includes every peer.   The profile
  request reads `fund_strategy()['value']` and `fund_benchmark_prim()['value']`.
  It does not read `etf_undl_index_ticker()`. It does not read
  `fund_geo_focus()`, `fund_industry_focus()`, or `exch_code()`. The spread
  profile does not request `fund_asset_class_focus`. The Flow tab does not draw that taxonomy screen.
  The showcase request remains in `data.py` and is not called from the app.
  Its universe is
  `fundsuniv(("active", "primary"))` filtered to ETF and one exchange code
  from JP, US, HK, KS, CH, TT, AU. That request reads
  `fund_asset_class_focus()['value']`, `actively_managed()['value']`,
  `cur_mkt_cap(currency=, fill='prev')` at today, 1M, 3M, and 1Y, and
  `fund_flow(...).sum()` for `-1M`, `-3M`, and `-1Y` in the selected currency.
  The flow heatmap is a second request on that same universe, using
  `fund_flow(...).sum().rolling(iterationdates=range(...))`. 1M and 3M use a
  month bucket. Longer periods use a week bucket. Do not request
  `fund_flow_sum`. Do not copy the keyword theme table or ASKB. A missing
  start market cap leaves Flow% blank. `crncy()` is the
  displayed share-class currency, not an asset classifier. That company
  id is not a pricing ticker and not a displayed company name. Primary
  is Yes or No from `fundsuniv(("active", "primary"))` filtered by that
  umbrella id. The benchmark column is `long_comp_name()['value']`
  of the `fund_benchmark_prim` index id, then `name()`, then the index id. Shown fund names
  prefer `long_comp_name()['value']`. The typed fund name stays the peer,
  strategy, and flow key. A blank long name falls back to `name()` or the
  typed fund name. Class Name stays `fund_open_shr_class()`. Catalog spelling and
  loan bid examples are not approval. Do not copy `25` last-price rules
  or `26` OHLCV ranges into this app. The five-year quote window above is
  the book history only. It is not an OHLCV request and it does not use
  `fill="prev"`. Max Data range beside Strategy defaults to `1Y`.
  Choosing `5Y` keeps `range("-5y", "0d")`. Every other choice is the
  weekday window of that preset, as absolute dates, on quotes, total
  return, and fund flow. Period controls after Refresh stay inside that
  pull. The flow heatmap grows with the fund-row count.
- `share_class_id` is the book key. The peer list is anchored by the fund
  name on `IsinEntry`, the same text as `peer_map.py`. It is not anchored
  by the HSBC ISIN. The quote id is the resolved primary ticker. Keep book identity,
  peer-group identity, and pricing identity separate.
- Invalid quotes stay blank. Do not zero-fill a missing spread. An empty
  cell, a zero quote, a zero level, a zero asset amount, or an N/A token
  with any trailing description is blank. A zero fund flow, a zero expense
  ratio, and a computed return of zero stay zero. Do not draw
  a peer line when the peer source returned no rows.
- `MAIN.ipynb` waits for Update. Do not call `load_on_start()`.
- History cache: `Use cache` (default on, `cache.CACHE_ENABLED`) serves a
  quote, total-return, NAV, or flow row older than the last completed
  London session from `cache/` and requests only the missing days. The
  stored frame is the raw request output; `Spread`, `Percent Spread`, the
  return percent, and the `/ 1e6` flow scaling are computed after the
  merge, so a formula change still applies on the next Refresh. A file is
  used only when `SERIES_CONTRACT`, `CACHE_GENERATION`, and the request
  fingerprint (`data.history_request_token()`, a hash of the builders'
  executable source, bound at import) all match `manifest.json`.
  Unreadable, mislabelled, or all-blank reads as no cache and is
  re-requested; a write failure is a note, never a failed Refresh; the
  folder is created only by a write. Coverage is per identifier, so a
  share class or peer added later gets its own full window and a removed
  one keeps its stored rows — never add a prune that deletes identifiers
  this run did not ask for, because a Strategy filter would then wipe
  another Strategy's history. An identifier is also bound to a security:
  `manifest.json` holds `{identifier: ISIN}` from
  `data.share_class_identities()` (book `Ticker`+`ISIN`, peer
  `Ticker`+`Primary ISIN`, no request), and a known mismatch drops that
  identifier's rows and re-requests the whole window, because a re-pointed
  primary share class or a reused ticker passes every date and column
  check. A missing ISIN on either side proves nothing and keeps the rows;
  never write the ledger without rewriting that identifier's rows in the
  same call. The answer is trimmed to the requested window. A gap is requested with absolute dates, so `range("-5y", "0d")`
  stays only for a fund with no stored history at all. Rows on or after
  the last completed session are never written. Uncheck `Use cache` to
  re-request the whole window; that run writes nothing. Do not add parquet
  or `pip`.
- Do not add a parser version constant until the first Desktop pull is
  frozen and the bundle registry has a reviewed row.
- Sample rows in `config.py` are not the live book. The live ETF and
  share-class list is typed into that file when the operator supplies it.
