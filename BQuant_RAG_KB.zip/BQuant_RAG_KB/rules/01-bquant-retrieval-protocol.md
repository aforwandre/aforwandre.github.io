---
description: Tiny destination index — open one route card, not the atlas
alwaysApply: true
---
# BQuant destination index

Do not load the atlas first. Wrong BQL is expensive.

Retrieval order (stop at the first match):

1. **Named Desktop app** (ETF Capping Monitor, MDX Scan, ETF Spread
   Monitoring, FI Index Change, FI Spread Movement Monitoring, or a freeze
   the user just signed): hard stops → `00` **§ 2 only** → that **one**
   route card (`25`, `26`, `27`, `28`, or `29`) + project `.mdc` → write
   `config` → `data` → `engine` → `app` → `MAIN` in one drop. Do not open
   `BUNDLE_EXAMPLES.md` as a second highway.
2. **Clear composition goal** (new app): open
   `RAG KB/BUNDLE_EXAMPLES.md` **Goal table**, at most **one** card.
   Borrow **code usage** (Request idiom, identity, do-not list). Official
   cards are product demos: usage is authoritative; feature depth is not
   the freeze. Then freeze a route card for the real job. They outrank
   `09` / `11` tutorials and the concept dictionary.
3. **Not a named destination:** one row from `00` § 8 Intent atlas, then
   that section only.
4. **New function not on the freeze or bundle card:** exact-search
   `## token` in `RAG KB/CONCEPT_INDEX.md` (not `@Codebase`, not `09` /
   `11` / `22`). Policy + Census. Independent relevance review.
   Co-mention is not a hop. Max two hops. Restriction/conflict → stop.
   Then `23`.

Never implement from `09` / `11` tutorials or `22` description similarity.
`22` is exact-search spelling only. Catalog-similar names are not
substitutes.
