---
description: Non-negotiable BQuant closed-world and Desktop safety constraints
alwaysApply: true
---
# BQuant Hard Stops

- **Highest priority:** never request, probe, test, generate, or use ESG, GHG,
  climate, or sustainable-finance data items for any purpose, including
  mapping, fallback, diagnostics, and experiments. Archived examples are
  documentation only. The user confirmed that a violation can cause the
  Bloomberg account to be suspended or deleted.
- Avoid any unfamiliar field or product family that may require a separate
  licence. If no confirmed core-data alternative exists, stop and ask the
  user to obtain Bloomberg HelpDesk confirmation of the FLDS BQL tab,
  entitlement, permitted request breadth, and intended semantics. Never probe
  the field to discover entitlement.
- Keep `CURSOR_BQNT` independent. Chat in Traditional Chinese (zh-Hant);
  write code, comments, and knowledge markdown in English.
- Local IDEs (Cursor, Qoder, TRAE) are for design, authoring, and review
  only. Never execute BQL, BQuant, or Bloomberg data requests locally.
- Use only local closed-world evidence. The official corpus ends 2026-07-25;
  later claims require dated user-supplied evidence. Never use WebSearch,
  WebFetch, external Bloomberg pages, or model memory for BQuant facts.
- The in-BQuant assistant is unstable and its replies are often wrong.
  A reply is text to investigate. When it conflicts with the RAG KB, the
  RAG KB is the authority. Do not replace a frozen Request, date rule,
  accessor, or field with the assistant's version.
- BQuant Desktop only. Do not assume Enterprise compute, scheduler, Sandbox
  Storage, custom images, managed Git, Event Studies production use, or
  unrestricted sharing. AIM Enterprise and PORT Enterprise are data
  entitlements on Desktop, not Enterprise runtime features.
- This account does not have ASKB. Gallery and official-script ASKB examples
  (`asb.py`, `asb_prompt.py`, `bbg://screens/ASB`, ASKB buttons, ASKB prompt
  builders) are demo documentation only. Do not copy them into
  `User scripts/`, do not add them to a new app, and do not describe an ASKB
  path as ready to run. A showcase that contains ASKB is not entitlement.
  Include ASKB only after the user explicitly says this account now has it.
- Keep user code under `User scripts/<Project Name>/`. Keep it separate from
  `RAG KB/`, generated bundles, and provenance archives.
- Default to `bql`, pandas, Plotly, ipywidgets, IPython display helpers,
  `ipydatagrid`, and Portfolio Library where supported. No external APIs,
  undeclared network calls, or `pip`. Never create new `bqport`.
- Keep requests narrow and batched. Desktop has download limits, a two-minute
  request timeout, at most two concurrent workloads, one running instance per
  project, and a 256 MB file limit.
- For company consolidation, use the documented
  `bq.univ.fundamentalticker()` lineage pattern plus reviewed business
  overrides. Never use ESG/GHG, DRSK, CAST, or another product-family field as
  a company/listing proxy without the mandatory substitution review.
- Retrieval front door: named app → `25`/`26`/`27`/`28`/`29` (FI Spread
  Movement Monitoring is `29`); new composition goal →
  indexed `RAG KB/BUNDLE_EXAMPLES.md` Goal table (one card). Official
  BQuant apps are product demos used to sell BQuant: treat their **code
  usage** as authoritative. They are not a full product spec — features
  may be thin and may not match a real user's job. New token →
  `CONCEPT_INDEX.md`. Never rebuild a proven Request from `09`/`11`.
