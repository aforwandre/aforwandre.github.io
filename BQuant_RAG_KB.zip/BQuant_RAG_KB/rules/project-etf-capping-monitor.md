---
description: ETF Capping Monitor entitlement, identity, pricing, and calculation rules
globs: User scripts/ETF Capping Monitoring/**
alwaysApply: false
---
# ETF Capping Monitor

- This named destination's highway is `RAG KB/25-etf-capping-monitor.md`,
  not `BUNDLE_EXAMPLES.md`. New apps may borrow AIM/last-price/classifier
  shapes from the Goal table; do not treat that file as a second ETF highway.

- **Highest priority:** never request, probe, test, generate, or use ESG, GHG,
  climate, or sustainable-finance data items for mapping, fallback,
  diagnostics, experiments, or any other purpose. A violation can cause the
  user's Bloomberg account to be suspended or deleted.
- Avoid separately licensed or entitlement-unknown fields. If no confirmed
  core-data alternative exists, stop and require Bloomberg HelpDesk evidence
  for the FLDS BQL tab, semantics, entitlement, and safe request breadth.
- Company grouping priority is hard Exception override, then
  `bq.data.id().value(bq.univ.fundamentalticker(), mapby="lineage")`, then
  original ticker. HelpDesk confirmed this replaces DT110 and DT679 here.
- Preserve the exact AIM Ticker and Quantity, calculate each position's MV and
  security Weight from its own approved Pricing Ticker, and attach the
  separate company key only afterward. Sum company-level weights only for the
  final capping comparison. Never price a subsidiary/listing with its
  parent/fundamental company ticker.
- Fetch `market_status()` without Request `mode=cached`. Last-price, Last
  Close as-of date, holiday `fill="prev"`, sibling-weight zero fallback,
  AIM `accounts=[one code]`, yellow-key asset classifier, cash FX invert,
  and Dynamic Limit / Rank are owned by `RAG KB/25-etf-capping-monitor.md`.
  Do not re-derive them from `08`/`23`/`24`. Do not add `crncy()` or
  `security_typ()` to classify holdings. Do not implement Excel `SHORT_NAME`
  until `25` marks it Approved. Primary FM is static runbook text in
  `config.py`, not BQL.
- Retain each Thai `/F TB Equity` and `-R TB Equity` (N-NDVR) AIM ticker and
  quantity. Only the separate Pricing Ticker may use a reviewed
  `THAI_PRICING_RULES` override, a deterministic `/F` or `-R` strip verified
  through ordinary local reference data and same-company fundamental mapping,
  or leftover HelpDesk-confirmed `bb_default_risk_obligor_ticker()` on the
  remaining Thai foreign lines only.
- An accepted Thai Pricing Ticker must end in `TB Equity`, contain no `/F`,
  must not remain a `-R` line, and have `Name` or `Market Status`.
  `fundamentalticker()` validates company identity only and must never become
  the Pricing Ticker. DRSK output is pricing identity only.
- Never request `cast_parent_equity_ticker()`, `parent(type='CAST')`, or
  `id_bb_company()` in this app. Official 2026-09-01 BQL tabs confirm they
  are not premium: CAST is the capital-structure parent equity ticker
  (`ID146`); `id_bb_company()` is integer `ID035`. Neither is a Thai local
  Pricing Ticker, and neither replaces HelpDesk `fundamentalticker()`
  grouping. Never request DRSK on a mixed HK/US or already-local universe.
  Never fall back to the sparse foreign-line price.
- Build batched caches for original, strip-candidate, and leftover DRSK local
  IDs. Use the local Pricing Ticker's status for zero-price handling and
  retain AIM status for display. Unverified mappings fail closed with a
  diagnostic.
- Current positions use `position_without_pending()["value"]`. Projected uses
  that same item plus `pending_position()["value"]`. This AIM contract is
  frozen from the 2026-08-28 Desktop tests: `pending_position()` alone returned
  all zeros; Current + Pending returned the non-zero book. Keep `accounts`,
  `pxnum=1377`, and `profile="DEFAULT_PROFILE"` on `with_params`. Do not move
  them onto `members()`, do not add dates, and do not use `ts_position()`.
- `etf_capping/config.py` is the only live runbook. App, data, engine, and
  tests must import it. `etf_capping/config_redacted.py` is a shareable
  desensitized **output** copy: placeholder AIM codes (`ACCT01`…), sample
  fund names, sample exceptions, and sample Thai override. Never import the
  redacted file in production code. When `config.py` helpers, dataclasses,
  constants, or rule-table *structure* change, update `config_redacted.py`
  in the same change, without copying live AIM codes, fund names, or other
  identifying tickers.
