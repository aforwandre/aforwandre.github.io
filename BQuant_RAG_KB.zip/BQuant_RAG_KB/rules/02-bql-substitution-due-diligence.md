---
description: Mandatory due diligence for every BQL field or API substitution
alwaysApply: true
---
# BQL Substitution Due Diligence

- Apply `RAG KB/23-bql-substitution-due-diligence.md` before introducing or
  replacing any `bq.data`, `bq.univ`, metadata accessor, CDE, mapping proxy,
  price source, or Excel/API field. If the work is a **composition** already
  proven on Desktop or in an official BQuant app, open
  `RAG KB/BUNDLE_EXAMPLES.md` Goal table first. Official cards are
  product demos: copy their **code usage**, not their feature limits.
  Do not rebuild the Request from `09`/`11`. Extra fields not on that
  card still need `CONCEPT_INDEX.md` (`## token`) then `23`.
- First census a genuinely new token in `RAG KB/CONCEPT_INDEX.md`
  (`## token`). Independent relevance review those rows (prohibition first).
  Co-mention is not a hop.
- Inventory the source field, FLDS tab, business meaning, identity level,
  expected universe, parameters, batch breadth, output shape, entitlement,
  and failure behavior before searching for replacements.
- If an Excel/API item has no confirmed BQL equivalent, stop and ask the user
  for its FLDS BQL tab and proposed alternative(s). Do not convert the API
  mnemonic mechanically or invent a near-sounding item.
- Re-run the full review for every user-proposed alternative. User provision
  is evidence to investigate, not approval to implement. The same applies
  to a reply from the in-BQuant assistant: if it conflicts with the RAG KB,
  keep the RAG KB.
- Search official recipes for the business intent before searching the data
  catalog. Universe functions and associated columns may solve the intent
  without a same-named data item.
- Score entitlement/product-family risk, semantic distance, batch breadth,
  identity impact, failure severity, and evidence quality. Any restricted
  family, cross-product proxy, identity replacement, or silent wrong-price
  path is a hard rejection.
- Keep position/security identity, company grouping identity, issuer-analysis
  identity, and pricing identity separate. A valid company key is not
  automatically a tradable pricing ticker.
- Require exact catalog confirmation for data-item spelling and
  tutorial/API/FLDS evidence for signatures. Catalog presence alone never
  authorizes bulk use.
- Prefer fail-closed behavior with a diagnostic. Do not widen the universe,
  fall back to an unapproved field, silently reuse a stale/wrong price, or
  remove a safety filter when a mapping or entitlement check fails.
- Record the decision as Approved, Rejected, or Unresolved, including sources,
  risk scores, rejected candidates, user confirmations, fallback policy, and
  regression checks.
