---
description: Quarantine and provenance rules for archived BQuant source material
globs: RAG KB/Raw source/**,RAG KB/Official scripts/**,RAG KB/Restricted reference/**
alwaysApply: false
---
# RAG Source Ingestion

- These directories are provenance archives, not normal code-generation
  sources. Route ordinary questions to `00` and canonical `01`–`28` topics.
  A **new composition goal** uses `RAG KB/BUNDLE_EXAMPLES.md` Goal table
  (indexed) before tutorials.
- Official BQuant apps in `Official scripts/` are product demos Bloomberg
  ships to sell BQuant. Treat their **code usage** as authoritative.
  They are demos: not a defect in API usage, but not a full product —
  features may be thin and may not match a real user's job. After ingest,
  add Goal table rows from distilled Production Recipes in `01` / `02` /
  `09` / `18`. Do not copy archive `.md` files, OCR-unresolved glue,
  ticker lists, or Restricted ESG examples into executable cards. OCR
  photos are not the shipped demo.
- ASKB blocks in an official script stay in the archive. Do not distill
  them into a Goal card, a route card, or a user script. This account does
  not have ASKB (`00`).
- Preserve source wording, date, capture method, and project/file identity.
- Label OCR reconstruction explicitly. OCR-observed mnemonics, parameters,
  ticker lists, and glue code are search leads only and cannot establish an
  API signature.
- Catalog existence and official-script appearance do not establish
  entitlement, bulk safety, current release status, or universe compatibility.
- Restricted ESG/GHG/climate/sustainable examples may be retained only as
  non-indexed historical evidence. Never distill executable restricted code
  into canonical topics or user scripts.
- Do not promote an archived pattern until exact catalog, semantics,
  signature, platform, entitlement, response-shape, and contradiction checks
  pass. Record unresolved points rather than repairing source gaps by guess.
- Update the official-source ledger first. Distill or rebuild only when the
  user has authorized knowledge ingestion.
