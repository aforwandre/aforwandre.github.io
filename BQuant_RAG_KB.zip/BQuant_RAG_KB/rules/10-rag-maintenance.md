---
description: Maintain canonical BQuant topics, router, rules, and integrity outputs
globs: RAG KB/00-RAG-INDEX.md,RAG KB/0[1-9]-*.md,RAG KB/1[0-9]-*.md,RAG KB/2[0-9]-*.md,RAG KB/regenerate_kb_bundle.py,RAG KB/build_concept_index.py,RAG KB/build_bundle_examples.py,RAG KB/concept_index_overlay.json,RAG KB/bundle_examples_registry.json,RAG KB/CONCEPT_INDEX.md,RAG KB/BUNDLE_EXAMPLES.md,.cursor/rules/*.mdc,.cursorindexingignore
alwaysApply: false
---
# RAG Knowledge Maintenance

- Canonical runtime knowledge is `RAG KB/00-RAG-INDEX.md` plus numbered
  `01`–`29` topics. Generated outputs (`BQUANT_RAG_KNOWLEDGE_BASE.md`,
  `RAG_KB_MANIFEST.json`, `CONCEPT_INDEX.md`, `CONCEPT_INDEX.json`,
  `BUNDLE_EXAMPLES.md`, `BUNDLE_EXAMPLES.json`) are never edited directly.
- Curated hop policy: `RAG KB/concept_index_overlay.json`. Proven
  composition registry: `RAG KB/bundle_examples_registry.json`.
- Keep knowledge in English, dense, evidence-labeled, and scoped to one
  authority role. Route cards (`25`, `26`, `27`, `28`, `29`, new named-app topics) are
  highways. `BUNDLE_EXAMPLES.md` is the indexed Goal table for **new**
  composition goals. Other topics are the atlas / rest stops.
- A new named Desktop app needs a route card **before** the first
  `User scripts/` Python. After Desktop success, add a project row and
  example rows to `bundle_examples_registry.json` so regenerate can
  extract the proven functions. PARSER_VERSION drift or an unregistered
  `User scripts/<Project>/**/data.py` with `PARSER_VERSION` must fail
  `--check` until the registry is reviewed.
- Official BQuant apps are product demos used to sell BQuant. Their
  **code usage** is authoritative; their feature set is not a real-user
  spec. After ingest, add Goal table rows from distilled Production
  Recipes (`01`/`02`/`09`/`18`), not from the unindexed archive. Do not
  rewrite `25`/`26` into a demo. OCR-unresolved mnemonics, ticker lists,
  and Restricted ESG examples are not cards.
- Destination first (`00` § 2). Coding first and freezing later is
  wandering the map.
- Default semantic index is the highway (`00`, `BUNDLE_EXAMPLES.md`,
  `25`, `26`, `27`, `28`, `29`, plus atlas `01`–`08`, `10`, `12`–`21`, `23`–`24`). Exclude
  `09`, `11`, `22`, and `CONCEPT_INDEX.md` from that index. Never add
  `BUNDLE_EXAMPLES.md` to `.cursorindexingignore` or its Qoder mirror
  (`.qoderignore`). Open `09`/`11` by path
  when a card names them. New functions: exact `## token` in
  `CONCEPT_INDEX.md`.
- Authority is claim-specific: rules for safety, `21` for releases, `22` for
  exact mnemonic existence, `08` for semantics, `07`/`14` or tutorials for
  signatures, `18` for response shape, and routed recipes for implementation.
- Preserve `canonical`, `script-verified`, `practice-derived`,
  `user-confirmed`, `OCR-observed`, `announcement-only`, `catalog-only`,
  `restricted-documentation`, and `gap-uncaptured` distinctions.
- Restricted reference material, raw HTML, and official-script archives are
  provenance, not normal runtime sources. Never copy restricted executable
  examples back into canonical topics.
- Update `00` routes and cross-links whenever a topic heading or authority
  changes. Do not create parallel routing tables that can drift.
- Rules are mirrored across three IDEs: `.cursor/rules/*.mdc`,
  `.qoder/rules/*.md`, and `.trae/rules/*.md`, kept in sync by
  `python3 .qoder/sync_rules.py` (baseline tracking; reverse writes into
  `.cursor/` are backed up first). After editing any rule, run the sync so
  all three sides converge. Every rule is three-sided: none is deliberately
  left unpaired, including `95-visual-diff-gate`.
- `globs` lists authored paths only. Never add the mirrors
  (`.qoder/rules/**`, `.trae/rules/**`, `rules-global/**`, `.qoderignore`) to
  it: the sync script rewrites them on every run, so the rule would fire on
  derived writes and nag for a bundle rebuild each time.
- After changing canonical knowledge, rules, indexing policy, or the builder,
  run `python3 "RAG KB/regenerate_kb_bundle.py"` and then
  `python3 "RAG KB/regenerate_kb_bundle.py" --check`.
