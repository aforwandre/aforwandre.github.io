---
description: FI Index Change BQuant app conventions and verified membership-diff traps
globs: User scripts/FI Index Change/**
alwaysApply: false
---
# FI Index Change

- This named destination's highway is `RAG KB/28-fi-index-change.md`,
  not `BUNDLE_EXAMPLES.md`. The membership-diff recipe stays in
  `RAG KB/02-bql-for-fixed-income.md` § Project Practice Notes. Do not
  treat the Goal table as a second highway.
- A reply from the in-BQuant assistant does not override this card or
  `02`. When the reply conflicts with the RAG KB, keep the RAG KB.

- CREDIT index members only. Do not put equity fields on this universe
  and do not use `holdings()` or uppercase `WEIGHTS`.
- Universe is `bq.univ.members(index_ticker, dates=effective_date)`.
  Never `setdiff()`. Never singular `member`. Diff locally on `ID`.
- Weight is `bq.data.id()['weights']`. A snapshot with no Weight column,
  or with Weight entirely null, is unavailable. Do not cache it and do
  not diff the other side against it.
- Phase 1 analytics are undated and deliberately narrow: three spreads
  (`spread(spread_type='OAS')`, `spread(spread_type='Z')`,
  `spread(spread_type='I')`), three durations (`duration()`,
  `option_adj_duration_sov_crv()`, `spread_duration_effective()`), three
  yields (`yield_()`, `yield_(yield_type='YTM')`, `yield_(yield_type='YTW')`),
  plus `cpn()`, `mty_years_tdy()`, `rating()`. Do not `replacena` those items.
  OAS at or above 9000 is dropped only inside the weighted average.
- `yield_type` is a parameter on `yield_()`, not a separate item. The confirmed
  form is `bq.data.yield_(yield_type='YTM')` / `'YTW'` / `'YTC'`, taken from
  two official Desktop demo apps (`Raw source/Bond Pair Relative Value`,
  `Raw source/TOMS Relative Value`). `yield_to_maturity()` and
  `yield_to_worst()` are **not** items and must not be restored: on 2026-11-02
  both returned a column with every value null, and neither has a single call
  site anywhere in this corpus.
- `option_adj_duration_sov_crv()` and `spread_duration_effective()` were
  **retired on 2026-11-02** in favour of the `duration_type` parameter form.
  Both had exact catalog spelling in `22` (`17010`, `20230`) and nothing else:
  no tutorial, no official script, no official Desktop page calls either one,
  and both returned a column with every value null on `LEGATRUU Index` for
  both month-ends. That null column was a **data** result, not a naming fault —
  `spread_duration_effective` is a correctly-called documented item. The
  measures are now reached through one builder: `duration()`,
  `duration(duration_type='MODIFIED')`, `('EFFECTIVE')`, `('SPREAD')`.
  Do not restore the two catalog spellings, do not substitute
  `mtg_eff_dur_mid()` (mortgage-only, cross-product proxy), do not re-add
  `hb_oas_eff_durtn()` or `mli_eff_dur()` (holdings-based; portfolio identity),
  and do not guess a near-sounding name.
- Do not widen that block. Desktop answered the 36-item request (22
  analytics) with `[BQLTimeoutError] - The query took too long to complete`
  on `LEGATRUU Index` for both month-ends on 2026-11-02. The 16- and 17-item
  builds with 3 analytics did answer. Every frozen item is requested on every
  Update, so a wide list is a permanent timeout, not a slower success. A
  wider list needs a dated Desktop timing first.
- `mtge_modified_duration()` is removed. Desktop answered
  `No BQL data item named 'mtge_modified_duration'` on 2026-11-02, and a
  rejected required item made the whole month unavailable. Do not re-add it
  or substitute a near-sounding name without a dated FLDS BQL confirmation.
- `crncy()` and `security_typ()` are the currency dimension and the
  MBS/TBA mask. They are not an ETF asset classifier.
- Do not request `credit_rating()` or any ESG, GHG, climate, or
  sustainable-finance item.
- Projected membership uses the next effective weekday through the same
  `members(..., dates=)` call. An error or an empty frame is
  unavailable, not "no changes".
- `MAIN.ipynb` waits for Update. Do not copy MDX `load_on_start`.
- Each Update requests only the selected month-end and the previous
  month-end. The dropdown itself does not request BQL.
- The index box has no local suggestion list. A completed Index yellow
  key requests `long_comp_name()` for that one ID and shows it under the
  input. The operator confirmed on 2026-10-30 that this is the index
  title. Bond Issuer still uses the same item on members. A partial
  ticker does not call BQL.
- Country on the membership request is `country_full_name()`. Bloomberg
  returns it upper case; display it in Excel PROPER style (`UNITED STATES`
  -> `United States`, `(blank)` unchanged). Apply
  `COUNTRY_NAME_OVERRIDES` from `config.py` first, then title-case: the
  rows show `BRITAIN` as `United Kingdom` and `SNAT` as `Supranational`.
  On an MBS/TBA row a blank Country / Sector becomes `MBS/TBA` and a blank
  Currency becomes `USD`; blanks stay `(blank)` on a Standard bond. An ID
  ending with `Muni` is Municipal (Country/Sector `Municipal`, USD). Every
  MBS/TBA and Municipal row shows Rating `N.A.` and bucket `N.A.`.
  `align_snapshot_labels()` standardizes Book, Country, Sector, Tenor
  Bucket, Rating, Rating Bucket, and Currency by ID: the latest usable
  value wins when it changed; if the latest value is missing, the previous
  value fills both sides. Never copy Weight or analytics. Do not fall back
  to `country_iso()` or use `msci_country_full_name()`.
- Tenor buckets come from numeric `mty_years_tdy`. An MBS/TBA row with no
  numeric tenor is `N.A.` (`TENOR_NOT_APPLICABLE`), not `Missing` or a
  blank filter value; a real numeric tenor keeps its normal bucket.
- The Currency box lists `crncy()` values on the extracted constituents
  for the selected book. Before Update it is only `(All)`.
- Book is a multi-select selection box after Yield with the same height as
  the other boxes. `(All)` is the rest label, and exactly one real pick wins;
  two picks, or none, fall back to `DEFAULT_BOOK` (All). Switching it rebuilds
  the Currency list from rows already extracted and sends no new request.
- If `members()` fails with an entitlement, permission, or license error,
  show `No Data Access License under this BBG ID`. A 403 is a session
  failure. An empty book is not a license failure.
- The selection line is local and boxed (green when loaded, amber when
  pending). The headline summary below it is bold inside a green box;
  unavailable uses amber and a refused license uses red. Under the date/book
  label it states `... (All). The figures, Bucket summary, and charts below
  follow this scope; Full book lines are all books.`, then a second line
  `Scope: Book = ...; filters = ...` that updates with Book and the filter
  widgets. All of it uses the same font and colour as the rest of the box.
  Label the two metric lines `As of <previous_date>` and
  `As of <selected_date>`, one per line, not `Before` / `After`. Start the two
  Full book sentences on their own line after the turnover sentence.
- The selection line is local: an index or month-end edit is pending
  until Update. Add weight uses the selected month-end. Exit weight uses
  the previous month-end.
- Charts are `CHART_WIDTH_PX` wide, capped at 80% of a full-screen
  1,920 px view: `min(FILTER_ROW_WIDTH_PX, int(1920 * 0.80))` = 1,536 px,
  while `FILTER_ROW_WIDTH_PX` (the nine boxes including Spread, Duration,
  Yield, and Book, plus `FILTER_GAP_PX`) is 2,284 px. The charts end short
  of the Book box on purpose (operator request, 2026-11-01); do not widen
  them back to the filter row. Set the width BOTH on the wrapping HBox and
  on the Plotly layout (`width=CHART_WIDTH_PX`, `autosize=False`); an HBox
  width alone does not resize a FigureWidget. Do not hardcode a percentage.
- The bucket chart keeps the Bucket summary Add + Exit order and draws the
  top 20 buckets with a non-zero Add or Exit weight plus one aggregated
  `Others` row (max 21 lines). Skip a bucket only when BOTH Add and Exit are
  zero; an offsetting Add/Exit pair stays in. The detail chart keeps largest
  Add to largest Exit.
- Charts use the Bloomberg dark theme: `paper_bgcolor` and `plot_bgcolor`
  are transparent, text/ticks/grid are light, and the Add/Exit bar colours
  stay unchanged. Update the title through `layout.title.text` so its light
  font is not replaced.
- Both charts are horizontal and signed: Add positive to the right, Exit
  negative to the left, rows top to bottom from the largest Add to the
  largest Exit (bucket chart by Add plus Exit, detail chart by signed
  weight). The detail table shows Exit weight as a negative number.
- The DataGrid gets only the columns in its own table definition, with every
  date converted to `YYYY-MM-DD` text. Never pass hidden helper columns such
  as `Maturity` / `AS_OF_DATE` to ipydatagrid: a NaT maturity breaks the
  widget with `Invalid time value`. `grid_display_frame()` enforces this.
- The Main tab keeps a table column visible while the body scrolls sideways
  (`PIN_FIRST_COLUMN`, operator request 2026-11-01). ipydatagrid 1.4.0 has no
  frozen-column trait, so `_pinned_view()` moves that column into the index:
  the row-header gutter does not scroll, and `base_row_header_size` widens it.
  A row-header click still opens the row: `primary_key_row` is the dataset row
  (the frontend maps it back through `ipydguuid`), so a repeated or string
  index label is not a row key. The summary table pins its dimension column;
  the detail bond table pins `ID`, not `Action`, because `Add` / `Exit` repeats
  and identifies nothing while scrolling (`PIN_DETAIL_COLUMN`,
  `PIN_DETAIL_ROW_HEADER_MAX_PX`). Gate the gutter on
  `hasattr(DataGrid, "base_row_header_size")` and drop the pin when the trait
  is missing: traitlets silently swallows an unknown keyword, so an exception
  fallback never fires and the label is simply cut at the default 64 px. The
  row header must stay shown, which is `header_visibility="all"`; 1.4.0 has no
  `row_headers` trait. The HTML fallback and the preview use
  `position: sticky; left: 0` on the pinned cell instead. Do not "fix" this by
  dropping the pinned column, and do not guess a frozen-column trait name.
- `SCREEN_WIDTH_PX` is 1920, the operator's FHD assumption: charts end at
  1536 px. On a narrower viewport they scroll sideways rather than shrink,
  because a `FigureWidget` must keep a fixed pixel width. That is accepted,
  not a bug to chase with `autosize`.
- Only the copy tables' `Weight` column carries a percent sign
  (`PERCENT_COLUMNS`). The summary `Begin` / `End` / `+/-` / `Add` / `Exit`
  weight columns stay as plain percent points: the operator asked for the
  Changes and Full Position `Weight` column only. Do not widen the suffix
  without a new request.
- The Bucket summary shows, for each measure, `Begin`, `End`, then one
  `+/- <measure>` column = End minus Begin (Count, Weight, selected spreads,
  selected durations, selected yields, Tenor); the Add/Exit block stays last.
  Compute every spread, duration, and yield block. Spread defaults to `OAS`,
  Duration to `Duration`, Yield to `Yield`; `(All)` expands every item and a
  subset expands just the selected blocks. All items always stay in Export
  Summary and the Changes / Full Position tables. Selection boxes use
  descriptive labels; table/export headers use short labels (`Modified
  Duration`, `YTM`, ...). Spread options are `OAS`, `Z-Spread`, `I-Spread`;
  duration options are `Duration`, `Modified Duration`, `Effective Duration`,
  `OASD`; yield options are `Yield`, `YTM`, `YTW`.
  That is the whole analytics set: 23 fields on every Update, sent as three
  requests (13 identity, 6 spreads+yields, 4 durations) because
  `config.SPLIT_REQUESTS` is `True`. A failed request drops only its own
  group, and it is never cached. `DMAT`, `MACM`,
  `ASW`, `OAD`, `ESPD`, and the rest of the old 22-analytics block stay out.
  The four duration options are one builder, `duration()`, differing only by
  `duration_type`; their value strings come from operator-supplied FLDS text
  dated 2026-11-02, and nowhere in the corpus. Do not widen this list without
  a dated Desktop timing inside the two-minute limit.
- The bucket detail summary is `N adds and N exits. Add weight x%, Exit
  weight x%, Net weight x%.` The detail chart shows only the Top 10 Adds
  and Top 10 Exits (max 20 rows) with a height that fits every label; the
  bar labels are the bond name only, never prefixed with `Add` or `Exit`
  (colour and title carry the action). The bond table still lists every row
  of the bucket.
- Clicking a bond puts its field table BELOW the bond table, never above
  it, so the grid stays put. The short note above the table names the
  selected bond.
- The footnotes come from `caption_html()` in `engine.py` and hold three
  things: the loaded Add / Exit as-of dates, the IG / HY bucket definitions,
  and the turnover formula (Exit + Add x MV ratio, the bucket rate, and the
  `(approx)` label). Do not put update scope, chart order, the Begin/End
  definition, Country, license, `403`, or empty-book text there: chart order
  lives on the chart axis, Begin/End under the Bucket summary heading, and
  errors in the live status line. There is no static footnote blob in `app.py`.
- The app has Main, Export, and Full Position tabs with no Export CSV
  button and no file output. Export has a Data dropdown (Changes / Summary);
  Full Position has a Date dropdown (Start / End) and shows every
  constituent of both month-ends (all books, independent of the Book
  dropdown and filters) with the CSV columns minus `Action`, keyed by
  `AS_OF_DATE`.
- Weight is not the first column of either copy table. It sits
  immediately after `Sector` in both `EXPORT_COLUMNS` (engine) and
  `POSITION_COLUMNS` (app), and it prints with a percent sign because the
  stored value is already in percent points. `engine.PERCENT_COLUMNS` is
  the single list that decides which columns get the sign; do not round the
  value, since a small MBS slice would print as `0.00%`. The vertical bond
  field table keeps its own `DETAIL_FIELDS` order and is not this contract.
- Hard rule: every copy table repeats the column names as its FIRST DATA
  ROW. `export_display_frame()` does this for Changes, Summary, and Full
  Position; never remove the row. A whole-table copy/paste into Excel then
  keeps the header.
- The Add / Exit detail list must apply every active filter, not only the
  current dimension key. `_filtered_changes()` is the single filtered
  change set; use it for the list, counts, weights, and bond chart. The
  2026-10-31 symptom was a one-sided Add with Rating AAA / IG appearing
  under both the IG and N.A. Rating selections; the cause was this missing
  cascade, not the rating data or `align_snapshot_labels()`.
- Monthly turnover is index-level
  `(ExitWeight_T0 + AddWeight_T2 x MV_T2/MV_T0)`. `MV_T2/MV_T0` is fixed at
  1.0, so `Turnover (index %)` is `Add Weight + Exit Weight` with a visible
  `(approx)` label on every row. Bucket `Turnover (index %)` is a
  contribution; `Turnover Rate (%)` divides it by Begin Weight. Do not add
  per-bond Par/Price/Accrued for this metric.
  There is no index-MV input: `bq.data.market_value()` was removed on
  2026-11-02. Its only consumer published this ratio behind a currency basis
  this account never confirmed, so the field was fetched on every Update and
  discarded, while costing one item on a request already fighting the
  two-minute timeout. Restoring the official basis needs the item back in
  `field_library.py` plus a dated Desktop check that the per-bond sum matches
  one index-level `market_value(universe_type='projected')`; never add a
  second request or a `member_count` request for it.
  The `MVBeginningDrops + MVEndingAdditions` definition itself is an external
  document, not local-corpus evidence: keep it labelled that way and
  re-confirm it from a dated user-supplied copy before quoting a turnover
  number outside the app.
- A status refresh must never freeze the lower tables. `render()` calls
  the idempotent `_bind_events()` before rebuilding the panels; keep it.
- There is no manual version stamp. Cache reuse is keyed to
  `FIELD_CONTRACT` in `cache.py`, derived from `field_library.ITEM_NAMES`;
  editing the item list invalidates old entries automatically. Do not add a
  `REQUEST_STAMP` or `PARSER_VERSION` back.
- The app header is `TITLE_HTML` in `app.py` (20px bold). It carries no
  version stamp, and neither does the status line.
- `SPLIT_REQUESTS` stays `False` unless a Desktop month times out.
- Desktop is Python 3.11: never put a backslash inside an f-string
  expression. Compute the value first. `tests/test_compat.py` enforces it.
- Cache is CSV. Do not add a parquet engine or `pip`.
- The preview and `Upload/` are derived artifacts; never hand-edit them.
  After any change under `fi_index_change/`, run `python3 refresh_local.py`
  from the project folder. It runs the test suite, regenerates
  `preview/interface.html`, restarts the page on
  `http://127.0.0.1:8770/interface.html`, and re-copies every runtime file
  to `Upload/`, then compares the bytes. A change is not finished until it
  exits 0. `Upload/` holds the seven runtime `.py` files plus `MAIN.ipynb`;
  `tests/`, `cache/`, `preview/`, and the markdown stay off the Desktop copy.
- After replacing `.py` files on BQuant, Restart Kernel and Run All.
