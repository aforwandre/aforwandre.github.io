# Project Rules — Platform-Neutral Format

This folder holds the **12 project rules** in plain Markdown so that any AI
coding agent can consume them, regardless of platform. They are the same rules
the source workspace enforces, copied verbatim; only the surrounding folder and
file extension are neutralized.

> The rule **bodies are authoritative and unmodified**. Adapt the *packaging*
> to your tool, not the wording — unless a rule is workspace-specific (flagged
> below), which you may adjust for your own environment.

## How to adapt these rules to your AI coding tool

Each rule file starts with a small YAML front-matter block, then the rule body:

```
---
description: <one-line purpose>
alwaysApply: <true|false>
globs: <comma-separated path patterns>   # present only on scoped rules
---
# <Rule title>
<rule body ...>
```

Front-matter keys:

| Key | Meaning | Portability |
|---|---|---|
| `description` | One-line purpose; used by model-decision rule routers | Generic — safe to keep anywhere |
| `alwaysApply: true` | Load this rule on every request | Cursor `.mdc` convention |
| `alwaysApply: false` + `globs` | Load only when editing files matching `globs` | Cursor `.mdc` convention |

Convert to your platform:

- **Cursor** — rename each file to `<name>.mdc` and drop the folder into
  `.cursor/rules/`. The front-matter is already in Cursor's native format.
- **Claude Code / generic agents** — concatenate the always-on rules
  (`alwaysApply: true`) into a single `CLAUDE.md` or `AGENTS.md` at the repo
  root; append scoped rules with a note describing when they apply.
- **Qoder** — place under `.qoder/rules/`; Qoder reads `trigger`/`glob`
  metadata, so map `alwaysApply: true` → an always-on trigger and `globs` →
  the glob trigger.
- **TRAE** — place the `.md` files under `.trae/rules/` as-is (verbatim copies).
- **GitHub Copilot / other** — paste the always-on rules into
  `.github/copilot-instructions.md`; summarize scoped rules by path.

If your tool has no rule mechanism, simply add the always-on rules (00–03, 95)
to your system/context prompt and keep the scoped rules (`project-*`, 10, 11)
as reference documents opened on demand.

## Rule index

### Always-on (load on every request)

| File | Purpose |
|---|---|
| `00-bquant-hard-stops.md` | Non-negotiable BQuant closed-world and Desktop safety constraints (ESG/GHG ban, no local BQL, Desktop limits, no ASKB) |
| `01-bquant-retrieval-protocol.md` | Tiny destination index — open one route card, not the atlas |
| `02-bql-substitution-due-diligence.md` | Mandatory due diligence for every BQL field or API substitution |
| `03-bql-pandas-safety.md` | BQL universe, field, response, and pandas safety for every answer |
| `95-visual-diff-gate.md` | Visual-diff review gate — apply all edits first, user reviews each checkpoint after |

### Scoped (load only for matching paths)

| File | Applies to | Purpose |
|---|---|---|
| `10-rag-maintenance.md` | `RAG KB/**`, rule + ignore files | Maintain canonical topics, router, rules, and integrity outputs |
| `11-rag-ingestion.md` | `RAG KB/Raw source/**`, `Official scripts/**`, `Restricted reference/**` | Quarantine and provenance rules for archived source material |
| `project-etf-capping-monitor.md` | `User scripts/ETF Capping Monitoring/**` | Entitlement, identity, pricing, and calculation rules |
| `project-etf-spread-monitor.md` | `User scripts/ETF Spread Monitoring/**` | Quote, period, and placeholder boundaries |
| `project-fi-index-change.md` | `User scripts/FI Index Change/**` | App conventions and verified membership-diff traps |
| `project-fi-spread-movement-monitoring.md` | `User scripts/FI Spread Movement Monitoring/**` | Validation-request and fail-closed rules |
| `project-mdx-scan.md` | `User scripts/MDX Scan/**` | App conventions and verified Desktop traps |

## Workspace-specific rules — adapt before reuse

A few clauses describe the **curator's own environment**, not universal BQuant
facts. Adjust or drop them for your setup:

- `00-bquant-hard-stops.md` — "Keep `CURSOR_BQNT` independent" and "Chat in
  Traditional Chinese (zh-Hant)". These are the curator's workspace/language
  preferences. The BQuant safety clauses (ESG/GHG ban, no local BQL execution,
  Desktop-only runtime, request budget, no ASKB) are universal — keep those.
- `10-rag-maintenance.md` / `11-rag-ingestion.md` — reference the source
  workspace's three-way rule mirror (`.cursor/rules/`, `.qoder/rules/`,
  `.trae/rules/`), the sync tool `.qoder/sync_rules.py`, and the quarantined
  provenance folders (`Raw source/`, `Official scripts/`, `Restricted
  reference/`). This share ships a **single neutral `rules/` folder** and does
  **not** include the quarantined archives or the sync tooling, so the
  mirror/sync steps do not apply here; treat these two rules as background on
  how the KB is maintained upstream.
- `95-visual-diff-gate.md` — describes an apply-first/review-after workflow and
  a rule-sync step. Keep the review discipline; the `sync_rules.py` step is
  upstream-only.

## Provenance

Verbatim copies of the source workspace's rules (the `.cursor/rules/*.mdc`,
`.qoder/rules/*.md`, and `.trae/rules/*.md` trees are byte-identical mirrors).
Line numbers are preserved, so line-anchored citations in `../wiki/` resolve
against these files unchanged.
