---
description: MDX Scan BQuant app conventions and verified Desktop traps
globs: User scripts/MDX Scan/**
alwaysApply: false
---
# MDX Scan

- This named destination's highway is `RAG KB/26-mdx-scan.md`, not
  `BUNDLE_EXAMPLES.md`. New apps may borrow members/NameCN/OHLCV/`load_on_start`
  shapes from the Goal table; do not treat that file as a second MDX highway.

- Daily-only BQuant Desktop app. Do not add Enterprise intraday analytics,
  a 5-minute scan, a 1-minute scan, or scheduled workloads. Runtime
  BQL/OHLCV/NameCN/signal port is owned by `RAG KB/26-mdx-scan.md`. Do not
  reconstruct those from `09` Error Log snippets.
- Formula port is daily v4e (`Source/MDX_futu_formula.txt` and
  `Source/MDX_futu_sig.txt`). BOT requires close >= open.
- Keep `MAIN.ipynb` as a thin bootstrapper. `app.load_on_start()` performs one
  refresh; it does not keep a workload alive. Do not copy the ETF Monitor
  Update-only bootstrap.
- Keep `PARSER_VERSION` in `data.py`. After replacing `.py` on BQuant,
  Restart Kernel and Run All.
- Preserve `DATE` in OHLCV parsing and use the Arrow-safe ID/DATE/value merge.
- The members universe is `bq.univ.members(HSI_INDEX)`, where
  `HSI_INDEX = 'HSI Index'`.
- NameCN is `bq.data.official_trad_local_lang_sec_nm()` on a **separate**
  members Request, merged on `ID`. Do not use `name_chinese_traditional()`.
- `widgets.Play.interval` is milliseconds; 15 minutes is `900000`.
- Keep legend keys and definitions in one HTML text node and place the legend
  after the table/chart `HBox`, outside fixed-height DataGrid clipping.
- For manual BQuant hand-copying, match the user's quote/wrap style and make
  the smallest patch. Do not autoformat.
- Use `with fig.batch_update():` and `functools.partial` for widget callbacks.
