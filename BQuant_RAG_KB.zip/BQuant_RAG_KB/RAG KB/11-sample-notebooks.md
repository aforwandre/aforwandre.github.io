---
topic_id: "11"
title: PyBQL Cross-Asset Use Cases
role: cross_asset_recipe
authority_for: [funds, FX, rates, commodities, AIM_examples]
not_authority_for: [restricted_data, unresolved_OCR_signatures]
evidence_grades: [canonical, script-verified, practice-derived, OCR-observed]
risk_tier: normal
routing_keywords: [funds, FX, curve, commodity, AIM, ts_position]
mandatory_cross_checks: [00-RAG-INDEX, 05-get-started, 18-using-pandas, 23-bql-substitution-due-diligence]
restricted_sections: [restricted_reference_archived]
source_families: [help_center, official_script]
---

# PyBQL Use Cases (Recipe Catalog)

> AI-oriented practice reference (Help Center chrome removed).

## AI quick map
- Core request patterns, dates/ranges, holdings metadata, set ops caveats
- Grouping/bins/filters/rolling/`execute_many`
- FX curves, fixed income, cashflows, string BQL, DataFrame alignment
- Official-script FX production recipe: cross-currency basis / fair forward → section below Help Center FX recipes
- Monthly rebalance masterpiece → `02-bql-for-fixed-income.md`
- What's New capability pointers: `commodities()` universe and commodity-curve members → `07` API patterns / `08` interpretation / `21` release digest (`22` covers data items, not universe APIs)

**Field gate:** exact-search standard data-item names in `22`; use `08` for meaning/metadata. Universe functions, parameters, and entitlements require routed API/tutorial evidence or FLDS when unresolved.

> **Restricted-data hard stop (user-confirmed, 2026-08-31):** all ESG, GHG,
> climate, and sustainable-finance examples in this file are reference-only.
> Never execute or copy them into user code. Bulk extraction requires Premium
> entitlement and can trigger Bloomberg account suspension.

```mermaid
flowchart LR
  U[Universe] --> I[Items dict]
  I --> R[Request]
  R --> X[execute / execute_many]
  X --> C["pd.concat item.df()"]
```

## Project Practice Notes: PyBQL Use Cases Reference

> Integrated use-case-oriented snippets. Object syntax first.
> The Global Aggregate monthly rebalancing masterpiece case lives in `02-bql-for-fixed-income.md`.

**PyBQL Use Cases Reference**

**Scope**
- Use-case oriented snippets showing how PyBQL code is typically written
- No rendered output tables
- Object syntax first; string syntax included where explicitly shown

**Assumes**
```python
import pandas as pd
import bql
bq = bql.Service()
```

**Core patterns**

**Minimal single-item request**
```python
universe = 'AAPL US Equity'
data_item = bq.data.px_last()
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Multiple items in one request (dict labels become column names)**
```python
universe = 'BBG000B9XRY4'
data_items = {
    'Name': bq.data.name(),
    'Price': bq.data.px_last(),
    'Volume': bq.data.px_volume(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Multiple tickers (universe as list)**
```python
universe = ['SPY US Equity', 'BBG000B9XRY4']
data_items = {
    'Name': bq.data.name(),
    'Volatility': bq.data.volatility(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Dates and ranges**

**Single as-of date on a data item**
```python
universe = 'SPY US Equity'
data_item = {'Price': bq.data.px_last(dates='2022-12-07')}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Time series over an absolute date range + drop non-trading days**
```python
universe = 'SPY US Equity'
data_range = bq.func.range('2023-12-01', '2023-12-14')
data_item = {'Price': bq.data.px_last(dates=data_range).dropna()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Time series over a relative date range + fill missing points + aggregate to single row**
```python
universe = 'SPY US Equity'
last_week = bq.func.range('-1w', '0d')
data_item = {
    'Assets Change %': bq.data.fund_total_assets(dates=last_week, fill='prev').pct_chg()
}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Chaining multiple time series transforms (diff, comparisons, tonumber, sum)**
```python
universe = 'MABAX US Equity'
last_year = bq.func.range('-1y', '0d')
daily_price_change = bq.data.px_last(dates=last_year).diff().dropna()
count_days = daily_price_change.count()
data_items = {
    'Up Days %': (daily_price_change > 0).tonumber().sum() / count_days,
    'Down Days %': (daily_price_change < 0).tonumber().sum() / count_days,
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Universes (univ) and bucket metadata**

**Holdings universe + request all metadata columns**
```python
universe = bq.univ.holdings('DIA US Equity')
data_item = {'ID': bq.data.id()}
request = bql.Request(universe, data_item, preferences={'addcols': 'all'})
response = bq.execute(request)
df = response[0].df()
```

**Holdings universe + use metadata columns from id()**
```python
universe = bq.univ.holdings('DIA US Equity')
data_items = {
    'Weight': bq.data.id()['WEIGHTS'],
    '1M Return': bq.data.total_return(calc_interval='1M'),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Holdings at a point in time + return over a custom interval ending on that date**
```python
date = '2023-10-01'
universe = bq.univ.holdings('DIA US Equity', dates=date)
return_range = bq.func.range('2023-09-01', date)
data_items = {
    'Weight': bq.data.id()['WEIGHTS'],
    '1M Return': bq.data.total_return(calc_interval=return_range),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Universe set operations (setdiff, intersect)**

> Safe here only because the request needs bare security IDs and `Name`. If weights or hidden membership metadata are required, fetch both universes separately and perform the difference in Pandas (`02` Practice Notes).

```python
universe = (
    bq.univ.holdings('DIA US Equity', dates='2024-06-01')
    .setdiff(bq.univ.holdings('DIA US Equity', dates='2023-10-06'))
)
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()

universe = (
    bq.univ.holdings('DIA US Equity', dates='2024-06-01')
    .intersect(bq.univ.list(['F FF Equity', 'AAPL US Equity']))
)
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()
```

**Cross-referencing a private universe with value(mapby='lineage')**
```python
universe = ['MABAX US Equity', 'BREIFDA LN Equity']
return_1y = bq.data.total_return(calc_interval='1Y')
benchmark_return_1y = return_1y.value(universe=bq.univ.relativeindex(), mapby='lineage')
outperformance = return_1y - benchmark_return_1y
data_items = {'Name': bq.data.name(), 'Outperformance': outperformance}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Grouping and aggregation**

**Sum of weights by sector for fund holdings**
```python
universe = bq.univ.holdings('MABAX US Equity')
weights = bq.data.id()['WEIGHTS']
sector = bq.data.classification_name(classification_scheme='BICS')
data_item = {'Total Weight': weights.group(sector).sum()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Count and sum grouped by a metadata column (rating watch)**
```python
universe = bq.univ.holdings('LQD US Equity')
watch = bq.data.rating()['WATCH']
data_items = {
    'Number of Bonds': bq.data.id().group(watch).count(),
    'Weight': bq.data.id()['WEIGHTS'].group(watch).sum(),
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Weighted average by group (wavg with grouped weights)**
```python
universe = bq.univ.holdings('MABAX US Equity')
pe_ratio = bq.data.pe_ratio()
sector = bq.data.classification_name(classification_scheme='BICS')
grouped_wgts = bq.data.id()['WEIGHTS'].group(sector)
data_item = {'Wgtd PE': pe_ratio.group(by=sector).wavg(weights=grouped_wgts)}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Binning (bins) + group aggregates + sort by a helper metric**
```python
universe = bq.univ.holdings('HYG US Equity')
maturity_years = bq.data.maturity_years()
maturity_year_bin = maturity_years.bins(
    bins=[3, 5, 7, 10],
    bin_names=['0-3', '3-5', '5-7', '7-10', '10+'],
)
data_items = {
    'Closest Maturity Year': maturity_years.group(maturity_year_bin).min(),
    'Weight': bq.data.id()['WEIGHTS'].group(maturity_year_bin).sum(),
    'Count': bq.data.id().group(maturity_year_bin).count(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
df = df.sort_values('Closest Maturity Year')
```

**Group-prefix functions for per-security projection (grouprank example)**
```python
universe = bq.univ.holdings('DIA US Equity')
return_1m = bq.data.total_return(calc_interval='1M')
sector = bq.data.classification_name()
data_items = {
    'Sector': sector,
    '1M Return': return_1m,
    '1M Return Sector Rank': return_1m.grouprank(by=sector),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Filtering universes (univ.filter) and logical chaining**

**Filter a large universe with cached mode**
```python
total_assets_usd_billion = bq.data.fund_total_assets(currency='USD') / 1e9
universe = bq.univ.fundsuniv('ACTIVE', 'PRIMARY').filter(total_assets_usd_billion > 200)
data_items = {'Name': bq.data.name(), 'Mkt Cap ($B)': total_assets_usd_billion}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Filter ETFs then aggregate flows by asset class focus**
```python
universe = bq.univ.fundsuniv('ACTIVE', 'PRIMARY').filter(bq.data.fund_typ() == 'ETF')
fund_flow_usd = (
    bq.data.fund_flow(dates=bq.func.range('-1M', '0D'), currency='USD').sum() / 1e9
)
asset_class_flow_sum = fund_flow_usd.group(by=bq.data.fund_asset_class_focus()).sum()
data_item = {'Fund Flow ($B)': asset_class_flow_sum.groupsort()}
request = bql.Request(universe, data_item, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**and_ chaining for multi-condition filters (ETF + assets + premium)**
```python
net_asset_value = bq.data.fund_net_asset_val(currency='USD')
price = bq.data.px_last(currency='USD')
premium = (price / net_asset_value - 1) * 100
total_assets = bq.data.fund_total_assets(currency='USD')
universe = bq.univ.fundsuniv('ACTIVE', 'PRIMARY').filter(
    (bq.data.fund_typ() == 'ETF')
    .and_(total_assets > 1e9)
    .and_(premium > 1)
)
data_items = {
    'Name': bq.data.name(),
    'Total Assets': total_assets,
    'Price': price,
    'NAV': net_asset_value,
    'Premium (%)': premium,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**or_ chaining for alternative conditions (liquidity score OR liquidation horizon)**
```python
liquidity_score = bq.data.lqa_liquidity_score()
liquidation_horizon = bq.data.liquidation_horizon()
universe = bq.univ.holdings('HYG US Equity').filter(
    (liquidity_score <= 50).or_(liquidation_horizon > 3)
)
data_items = {
    'Name': bq.data.name(),
    'Weight': bq.data.id()['WEIGHTS'],
    'Position (M)': bq.data.id()['POSITION'] / 1000,
    'Liquidity Score': liquidity_score,
    'Liquidation Horizon': liquidation_horizon,
    'Liquidation Volume (M)': bq.data.liquidation_volume() / 1000,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Filter using group-prefix results (top 10 by 1M flow after other filters)**
```python
total_assets_billion_usd = bq.data.fund_total_assets(currency='USD') / 1e9
fund_flow_sum = (
    bq.data.fund_flow(dates=bq.func.range('-1M', '0D'), currency='USD').sum() / 1e9
)
universe = (
    bq.univ.fundsuniv('ACTIVE', 'PRIMARY')
    .filter((bq.data.fund_typ() == 'ETF').and_(total_assets_billion_usd > 10))
    .filter(fund_flow_sum.grouprank() <= 10)
)
data_items = {
    'Flow (1M)': fund_flow_sum.groupsort(),
    'Total Assets': total_assets_billion_usd,
    'Flow as % Assets': fund_flow_sum / total_assets_billion_usd,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Rolling calculations (rolling + zscore + last + filter)**

**Detect funds with abnormal flows (weekly rolling sum, z-score, top 10)**
```python
fund_total_assets = bq.data.fund_total_assets(currency='USD')
weekly_fund_flow = (bq.data.fund_flow(dates=bq.func.range('-5D', '0D'), currency='USD').sum() / 1e6)
weekly_fund_flow = weekly_fund_flow.rolling(
    iterationdates=bq.func.range('2023-01-01', '2024-07-12', frq='CW')
)
latest_weekly_flow_z = weekly_fund_flow.zscore().last()
universe = (
    bq.univ.fundsuniv('ACTIVE', 'PRIMARY')
    .filter((bq.data.fund_typ() == 'ETF').and_(fund_total_assets > 50e9))
    .filter(latest_weekly_flow_z.grouprank() <= 10)
)
data_items = {
    'Name': bq.data.name(),
    'Geo Focus': bq.data.fund_geo_focus(),
    'Asset Focus': bq.data.fund_asset_class_focus(),
    'Strategy': bq.data.fund_strategy(),
    'Total Assets': fund_total_assets,
    'Latest Weekly Flow Z-Score': latest_weekly_flow_z,
    'Latest Weekly Flow ($M)': weekly_fund_flow.last(),
    'Average Weekly Flow ($M)': weekly_fund_flow.avg(),
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**execute_many for multiple requests (asynchronous batching)**

**Fund holdings across multiple dates (build requests, execute_many, stack results)**
```python
fund = 'DIA US Equity'
dates = pd.date_range('2023-12-31', '2024-06-30', freq='Q')

def build_bql_request(fund, date):
    holdings = bq.univ.holdings(fund, dates=date)
    data_items = {
        'Date': bq.data.id()['DATE'],
        'Name': bq.data.name(),
        'Weight': bq.data.id()['WEIGHTS'] / 100,
        'Sector': bq.data.classification_name(),
    }
    return bql.Request(holdings, data_items, with_params={'mode': 'cached'})

requests = [build_bql_request(fund, date) for date in dates]
responses = bq.execute_many(requests)

dfs = []
for response in responses:
    single_date_df = pd.concat([item.df()[item.name] for item in response], axis=1)
    single_date_df = single_date_df.set_index('Date', append=True)
    dfs.append(single_date_df)

df = pd.concat(dfs, axis=0)
```

**Parameterized Item reuse (with_additional_parameters)**

**Restricted parameter-override example**

The historical restricted-data example was removed from the canonical corpus. Parameter mutation semantics are documented in `07`; restricted provenance is non-indexed.

**FX use cases (curves, tenors, history)**

**FX spot snapshot**
```python
universe = 'EURUSD Curncy'
data_item = {'Last Price': bq.data.px_last()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**FX forward curve universe (curvemembers) + id metadata**
```python
currency_pair = 'EURUSD Curncy'
universe = bq.univ.curvemembers(currency_pair, curve_type='FX')
data_item = {'ID': bq.data.id()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**FX curve quote_type points + curve_rate bid/ask**
```python
currency_pair = 'EURUSD Curncy'
universe = bq.univ.curvemembers(currency_pair, curve_type='FX', quote_type='points')
data_items = {
    'Points Bid': bq.data.curve_rate(side='bid'),
    'Points Ask': bq.data.curve_rate(side='ask'),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**FX curve market_type onshore + outright**
```python
currency = 'USDBRL Curncy'
universe = bq.univ.curvemembers(currency, curve_type='FX', quote_type='outright', market_type='onshore')
data_item = {'Outright': bq.data.curve_rate(side='mid')}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**FX curve pricing_source example (as written; note the method name casing in source)**
```python
currency = 'EURUSD Curncy'
universe = bq.univ.curvemembers(currency, curve_type='FX', quote_type='implied_yield', pricing_source='LIBO')
data_item = {'Implied Yield': bq.data.curve_rate(side='mid', dates='2023-06-16')}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**FX curve filter by tenor range (tenors accepts func.range)**
```python
currency_pair = 'USDJPY Curncy'
universe = bq.univ.curvemembers(
    currency_pair,
    curve_type='FX',
    quote_type='implied_yield',
    tenors=bq.func.range('1M', '6M')
)
data_item = {'Implied Yield': bq.data.curve_rate(side='mid')}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**FX curve history: filter tenors + curve_rate(dates=range) + pivot**
```python
currency_pair = 'USDMXN Curncy'
tenor_range = bq.func.range('1M', '6M')
date_range = bq.func.range('-1M', '0D')
universe = bq.univ.curvemembers(currency_pair, curve_type='FX', quote_type='points', tenors=tenor_range)
data_item = {'Rate': bq.data.curve_rate(dates=date_range).dropna()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()

pivot = df.pivot(columns='TENOR', index='DATE', values='Rate')
pivot = pivot.reindex(df.sort_values('SETTLE_DATE')['TENOR'].drop_duplicates(), axis=1)
```

**Multiple FX curves at once + pivot**
```python
currency_list = ['NZDUSD Curncy', 'EURUSD Curncy', 'AUDUSD Curncy', 'GBPUSD Curncy']
universe = bq.univ.curvemembers(currency_list, curve_type='FX', quote_type='outright')
data_item = {'Rate': bq.data.curve_rate()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()

pivot = df.pivot(columns='BASE_CURRENCY', index='TENOR', values='Rate')
pivot = pivot.reindex(df.sort_values('SETTLE_DATE')['TENOR'].drop_duplicates())
```

**Fixed income use cases**

**Single bond snapshot**
```python
universe = '257759443 Corp'
data_item = bq.data.name()
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Multiple bond identifiers + one item**
```python
universe = ['EJ729942 Corp', 'US92556NAE75', '92556NAE3', 'BBG00GJ8HJZ6']
data_items = {'Spread': bq.data.spread(spread_type='OAS')}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Index-level fixed income analytics with universe_type**
```python
universe = ['GLOAM Index', 'ELDAM Index']
data_items = {
    'Market Value': bq.data.market_value(universe_type='projected'),
    'Member Count': bq.data.member_count(universe_type='projected'),
    'Total Return MTD': bq.data.total_return(universe_type='returns', calc_interval='mtd'),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Bond time series + dropna**
```python
universe = '257759443 Corp'
data_range = bq.func.range('2023-12-01', '2023-12-14')
data_item = {'Price': bq.data.px_last(dates=data_range).dropna()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Yield net change over last week with fill**
```python
universe = '257759443 Corp'
last_week = bq.func.range('-1w', '0d')
data_item = {'Yield': bq.data.yield_(dates=last_week, fill='prev').net_chg()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Issuer bond universe from equities + pull OAS**
```python
universe = bq.univ.bonds(['AAPL US Equity', 'MSFT US Equity'])
data_items = {'Bond Name': bq.data.name(), 'Issuer': bq.data.issuer(), 'OAS': bq.data.spread(spread_type='OAS')}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Backdata index membership**
```python
universe = bq.univ.members('I38493EU Index', dates='-1w')
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()
```

**Capital structure scoping with issuedby + asset class field**
```python
universe = bq.univ.debt('PARA US Equity', issuedby='ENTITY')
request = bql.Request(universe, {'Asset Class': bq.data.srch_asset_class()})
response = bq.execute(request)
df = response[0].df()
```

**Fixed income screening with multiple conditions (and_ chaining)**
```python
universe = bq.univ.bondsuniv('Active').filter(
    (bq.data.cpn_typ() == 'FIXED')
    .and_(bq.data.classification_name() == 'Financials')
    .and_(bq.data.maturity() < '3M')
    .and_(bq.data.bb_composite() >= 'AA-')
)
request = bql.Request(universe, {'Spread': bq.data.spread(spread_type='OAS')})
response = bq.execute(request)
df = response[0].df()
```

**Group-prefix ranking for top movers (grouprank + groupsort)**
```python
sprd = bq.data.spread(spread_type='I', dates=bq.func.range('-1m', '0d'), fill='prev')
sprd_chg = sprd.net_chg()
universe = bq.univ.members('LF98TRUU Index').filter(sprd_chg.grouprank(order='desc') <= 10)
request = bql.Request(universe, {'Spread Change': sprd_chg.groupsort()})
response = bq.execute(request)
df = response[0].df()
```

**Group z-scores + outlier selection**
```python
universe = bq.univ.members('LBUSTRUU Index')
sector = bq.data.classification_name('BCLASS', '3')
filtered_universe = bq.univ.filter(universe, sector == 'Energy')
spread_chg = bq.data.spread(dates=bq.func.range('-1w', '0d'), fill='prev').pct_chg()
spread_zscore = spread_chg.groupzscore()
spread_zscore_abs_rank = spread_zscore.abs().grouprank()
filtered_universe2 = bq.univ.filter(filtered_universe, spread_zscore_abs_rank <= 5)
req = bql.Request(filtered_universe2, {'Z-Spread Outliers': spread_zscore.groupsort()})
res = bq.execute(req)
df = res[0].df()
```

**Rolling weighted averages over time (group + wavg + rolling)**
```python
universe = bq.univ.members('I38494 Index')
sector = bq.data.classification_name(classification_scheme='bclass', classification_level='3')
rolling_avg_disc_margin = (
    bq.data.disc_margin(fill='prev')
    .group(sector)
    .wavg(bq.data.id()['weights'].group(sector))
    .rolling(iterationdates=bq.func.range('-1y', bq.func.today(), frq='W'))
)
request = bql.Request(universe, {'Rolling 1m Avg DM': rolling_avg_disc_margin})
response = bq.execute(request)
df = response[0].df()
```

**Cashflows use cases (matches + between + group)**

**Single bond cashflows (projected)**
```python
universe = 'EC527035 Corp'
request = bql.Request(universe, {'Principal': bq.data.cashflows()})
response = bq.execute(request)
df = response[0].df()
```

**Historical + projected cashflows via settle_dt**
```python
universe = 'EC527035 Corp'
request = bql.Request(universe, {'Principal': bq.data.cashflows(settle_dt='2022-02-28')})
response = bq.execute(request)
df = response[0].df()
```

**Filter cashflows to a date window using matches + between on the cashflow date column**
```python
universe = 'EC527035 Corp'
cashflows = bq.data.cashflows()
start = '2025-01-01'
end = '2030-01-01'
data_item = {'Principal': cashflows.matches(cashflows['date'].between(start, end))}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Aggregate cashflows for index members by year (group + sum)**
```python
universe = bq.univ.members('I00108US Index')
year = bq.data.cashflows()['date'].year()
data_item = {
    'Principal': bq.data.cashflows()['value'].group(year).sum(),
    'Interest': bq.data.cashflows()['interest'].group(year).sum(),
}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Filtered bond universe cashflows by year and month (cached mode recommended)**
```python
universe = (
    bq.univ.bondsuniv('active')
    .filter((bq.data.country_iso() == 'CA').and_(bq.data.cpn() > 2).and_(bq.data.maturity() < '2y'))
)
cashflows = bq.data.cashflows()
year = cashflows['date'].year()
month = cashflows['date'].month()
data_item = {
    'Principal': cashflows['value'].group([year, month]).sum(),
    'Interest': cashflows['interest'].group([year, month]).sum(),
}
request = bql.Request(universe, data_item, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1).dropna()
```

**String query syntax (when you must use it)**

**Minimal string query**
```python
bql_query = """
for('AAPL US Equity')
get(px_last)
"""
response = bq.execute(bql_query)
df = response[0].df()
```

**String query with preferences(addcols='all') and dropna in get()**
```python
bql_query = """
for(portuniv(type=prep))
get(dropna(port_info, remove_id=true))
preferences(addcols='all')
"""
response = bq.execute(bql_query)
df = response[0].df()
```

**String query with with(CURRENCY=EUR)**
```python
bql_query = """
get(AVG(PX_LAST(dates=RANGE(-1M,0D))))
for(['AAPL US EQUITY', 'V US EQUITY', 'MA US EQUITY'])
with(CURRENCY=EUR)
"""
response = bq.execute(bql_query)
df = response[0].df()
```

**Response handling and DataFrame alignment patterns**

**Single item response access**
```python
request = bql.Request('IBM US Equity', bq.data.px_last())
response = bq.execute(request)
df = response[0].df()
```

**Combine multiple items with same index (simple concat)**
```python
universe = ['IBM US Equity', 'VOD LN Equity']
data_items = {
    "px": bq.data.px_last(dates=bq.func.range("-1w", "0d")),
    "volume": bq.data.px_volume(dates=bq.func.range("-1w", "0d")),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df_combined = pd.concat([item.df() for item in response], axis=1)
```

**Combine only value columns to avoid duplicate metadata columns**
```python
df_combined = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Remove duplicate columns after concat**
```python
df_deduped = df_combined.loc[:, ~df_combined.columns.duplicated()]
```

**Merge different-shaped items (time series + static mapping)**
```python
universe = ['IBM US Equity', 'VOD LN Equity']
data_items = {
    "px": bq.data.px_last(dates=bq.func.range("-1w", "0d")),
    "volume": bq.data.px_volume(dates=bq.func.range("-1w", "0d")),
    "name": bq.data.name(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)

df_px = response[0].df()
df_volume = response[1].df()
df_name = response[2].df()

df_timeseries = pd.concat([df_px, df_volume], axis=1)
df_final = df_timeseries.merge(df_name, on="ID", how="left")
```

### Cross-Reference

- Monthly constituent change tracker (MBS/TBA split, business-day month-end, local Pandas `isin` diff): see **`02-bql-for-fixed-income.md`**.
- Verified identifiers / weights key case rules: see **`08-bql-data-items.md`**.
- Error log (setdiff metadata strip, cached weights lag, `id_sedol1`): see **`09-build-analysis.md`**.

---

## Help Center FX / Rates Curve Recipes

### FX Points per Day

FX forward curve members via `bq.univ.curvemembers`; z-score history per tenor; grid click drives dual-subplot `FigureWidget`.

APIs: `bq.data.curve_rate`, `bq.func.range`, `bq.univ.curvemembers`.

```python
date_range = bq.func.range(f'{pricing_date}{lookback}', pricing_date)
data_items = {
    f'Fwd Points - {side}': bq.data.curve_rate(dates=date_range, side=side).dropna()
    for side in ['Mid', 'Bid', 'Ask']
}
universe = bq.univ.curvemembers(
    f'{base}{quote} Curncy', curve_type='fx',
    quote_type='points', market_type='primary', tenors=tenor_map.keys(),
)
df = pd.concat([item.df() for item in bq.execute(bql.Request(universe, data_items))], axis=1)
z = df.groupby('Tenor')[list(data_items)].transform(
    lambda x: (x - x.mean()) / x.std(ddof=0)
)
```

### FX Volatility Cone

Spot + implied vol history; project forward path and ±1/±2σ log-normal bands to tenor horizon.

APIs: `bq.data.curve_rate`, `bq.data.px_last`, `bq.func.range`, `bq.univ.curvemembers`.

```python
fwd = get_bql_data(
    bq.univ.curvemembers(f'{ccy} Curncy', curve_type='fx', quote_type='outright', tenors=['12M']),
    {'Value': bq.data.curve_rate()},
    start_date,
)
spot_vol = get_bql_data([f'{ccy} Curncy', f'{ccy}V{tenor} Curncy'], {'Value': bq.data.px_last()}, start_date)
# Extend index to tenor end; Price = spot + fwd * (days_elapsed / days_total)
# Std bands: price * exp(±k * impl_vol * sqrt(days/365))
```

### Implied Overnight Rate Curve Evolution

Multi as-of paths of central-bank meeting implied rates; effective rate overlay; hikes/cuts bar subplot.

APIs: `bq.data.implied_overnight_rate`, `bq.func.range`.

```python
def get_data_as_of_date(universe, model, start_date, end_date, as_of_date):
    start = f'{start_date:%YM%#m}'
    end = f'{end_date:%YM%#m}'
    item = bq.data.implied_overnight_rate(
        as_of_date=as_of_date, model=model,
        period_reference=bq.func.range(start, end), fill='prev',
    )
    df = bq.execute(bql.Request(universe, {'implied_overnight_rate': item}))[0].df()
    return df[(df['ACT_EST_DATA'] == 'E') & (df['MEETING_DATE'] >= start_date.strftime('%Y-%m-%d'))]

effective = bq.data.implied_overnight_rate(
    model=model, dates=bq.func.range(start_date, date.today()), fill='prev',
)
```

### XCCY Historical Spread Analysis

Corporate bond universe filtered by ISIN and USD `amt_outstanding`; Z-spread and ASW time series; maturity-year bins with perpetual override.

APIs: `bq.data.amt_outstanding`, `bq.data.crncy`, `bq.data.id_isin`, `bq.data.is_perpetual`, `bq.data.maturity_years`, `bq.data.spread`, `bq.func.if_`, `bq.func.range`.

```python
bins = bq.func.if_(
    bq.data.is_perpetual(), 'Perp',
    bq.data.maturity_years().bins([1, 2, 3, 5, 7, 10, 20, 30], bin_names),
)
metrics = {
    'Z Spread': bq.data.spread(spread_type='Z'),
    'ASW Spread': bq.data.spread(spread_type='ASW'),
}
universe = universe.filter(
    (bq.data.id_isin() != bql.NA)
    .and_(bq.data.amt_outstanding(currency='USD') > min_usd_mm * 1e6)
)
```

## Production Recipes from Official Scripts (FX)

### Production Recipe: Cross-Currency Basis Swap Spread

**Evidence:** practice-derived composition from OCR of *Cross Currency Basis Swap Spread* (`IMG_6635`–`IMG_6639`). Catalog-confirmed data items: `px_last`, `px_mid`, `px_ask`, `px_bid`, `curve_rate`, `fwd_scale`, `id`. Universe arguments (`curvemembers(..., dates=)`, `curve_type='FX'`, `side='MID'`, BFIX ticker `'{pair} {BGN|BGNL|BGNT} Curncy'`) stay **OCR-observed** — use the canonical FX `curvemembers` / `curve_rate` snippets above unless FLDS confirms the photographed variants. Do not invent IR curve tickers; the widget defaults were not photographed.

```text
BFIX spot history (DATE column)
-> IR curve snapshot per date (execute_many; zip to date keys)
-> FX forward curve history (one request; points -> outright via fwd_scale)
-> interpolate IR to each FX tenor DAYS_TO_MATURITY / 365
-> fair forward from IR parity with explicit day-count denominators
-> forward basis, implied IR, CCBS; z-score by TENOR
-> latest-date DataGrid row -> 3x3 Plotly tenor history
```

Operational rules:

- Keep BQL and CIP math separated. Spot, IR members, and FX `curve_rate` are three layers; do not collapse them into one request.
- Align the FX curve onto spot dates (`DATE.isin`) before interpolating.
- `DATE`, `TENOR`, and `SETTLE_DATE` are canonical FX history columns in this file. `DAYS_TO_MATURITY`, `YEAR_FRACTION`, and `QUOTE_TYPE` were photographed; confirm they arrive before `np.interp`.
- Per-date `execute_many` for the full IR curve is Desktop-heavy (two-minute timeout). Narrow the spot window. Normalize responses with `18` — do not assume Arrow results are iterable.
- Convert points to outright only when `QUOTE_TYPE` contains `Points`; look up the same-date `TENOR=='SP'` rate and divide points by `10 ** fwd_scale()`.
- Fair forward (photographed CIP, actual/actual-style day counts supplied by widgets):

```python
fair = spot * (1 + quote_ir / 100 * dtm / quote_days) / (
    1 + base_ir / 100 * dtm / base_days
)
implied_quote_ir = (
    ((1 + base_ir / 100 * dtm / base_days) * forward / spot) - 1
) * 100 * quote_days / dtm
implied_base_ir = (
    ((1 + quote_ir / 100 * dtm / quote_days) * spot / forward) - 1
) * 100 * base_days / dtm
```

- Z-score inside `groupby('TENOR')`. Grid `selected_cell_values` indices follow the photographed column order after `reset_index`: quote CCY `[1]`, base CCY `[2]`, tenor `[3]`. Verify the `ipydatagrid` selection trait (`selection` vs `selections`) in the active environment (`09`).

## Help Center Funds Recipes

Cross-asset fund workflows from Help Center examples.

### Axes-Driven Market Insights
- Retrieves historic pairwise metric differences for bonds with z-score heatmaps and time series charts. Identify anomalies and relative performance patterns between bond pairs.
- **APIs:** `bq.data.axes`, `bq.data.industry_sector`, `bq.data.is_axed`, `bq.data.rating`, `bq.data.security_des`, `bq.univ.axeduniv`, `bq.univ.members`

```python
def fetch_data(universe_type, data_items, params=None):
    """
    Returns a BQL response for a given universe.
    """
    universe_map = {
        'Global High Yield': 'LG30TRUU Index',
        'US Corporate Investment Grade': 'LUACTRUU Index'
    }
    # Returns all axed bonds or axed bonds for a selected index
    if universe_type == 'All Axed Bonds':
        universe = bq.univ.axeduniv(type='All')
    else:
        index = universe_map.get(universe_type)
        universe = bq.univ.members(index).filter(bq.data.is_axed()==True)

    # Create request
    request = bql.Request(universe, data_items, with_params=params)
    response = bq.execute(request)

    #Process response
    if len(data_items) > 1:
        data = pd.concat(
            [data_item.df()[data_item.name] for data_item in response],
            axis=1
        ).reset_index()
    else:
        data = response[0].df().reset_index()

    return data
```

### Equity Funds Characteristics
- Aggregates unrestricted fundamental, valuation, performance, and analyst characteristics across each fund's holdings using holdings weights.
- **APIs:** `bq.data.best_target_price`, `bq.data.cur_mkt_cap`, `bq.data.id`, `bq.data.name`, `bq.data.px_last`, `bq.data.return_com_eqy`, `bq.data.return_on_asset`, `bq.data.return_on_cap`, `bq.data.return_series`, `bq.data.security_typ`, `bq.func.range`

```python
# Get fundamental metrics for aggregated fund holdings using individual BQL
# requests for each fund

# Get fundamental metrics for the fund holdings
data_items = {
    "ROE": bq.data.return_com_eqy(),
    "ROA": bq.data.return_on_asset(),
    "ROC": bq.data.return_on_cap(),
    "Mkt Cap ($B)": bq.data.cur_mkt_cap(currency="USD") / 1e9,
    "Analyst Est": bq.data.best_target_price() / bq.data.px_last() - 1,
}

def apply_wavg(item):
    """Calculates the aggregated weighted average for a BQL item"""
    # Get the weights of each holding in a fund
    weights = bq.data.id()["WEIGHTS"]
    return item.group().wavg(weights.group())

# Apply the weighted average calculation to each data item
wavg_data_items = {}
for name, item in data_items.items():
    wavg_data_items[f"WAvg {name}"] = apply_wavg(item)

# Create BQL requests for the aggregated holdings for each fund
requests = []
for fund in funds:
    universe = (
        bq.univ.holdings(fund)
        .filter(
            (bq.data.security_typ() == "Common Stock")
            .and_(bq.data.id()["POSITION"] != 0)
        )
    )

    request = bql.Request(
        universe, 
        wavg_data_items, 
        with_params={"mode": "cached"}
    )
    requests.append(request)

# Execute all the fund holdings requests
responses = bq.execute_many(requests)

# Process the individual responses into a list containing single
# DataFrames for each fund
dfs = []
for fund, response in zip(funds, responses):
    df = pd.concat(
        [data_item.df()[data_item.name] for data_item in response], 
        axis=1
    )
    # Insert the fund name by looking it up in the fund names DataFrame
    df.insert(0, "Fund Name", names_df.loc[fund].item())
    dfs.append(df)

# Create a DataFrame of fundamental metrics by concatenating the individual
# fund DataFrames together
fundamental_df = pd.concat(dfs).set_index("Fund Name")
```

### Fund vs Index Performance
- Retrieves cumulative returns and calculates weighted average fundamentals for fund holdings. Produces tabular and visual summaries comparing fund performance and characteristics.
- **APIs:** `bq.data.ann_total_return`, `bq.data.downside_volatility`, `bq.data.information_ratio`, `bq.data.max_drawdown`, `bq.data.return_series`, `bq.data.sharpe_ratio`, `bq.data.sortino_ratio`, `bq.data.total_return`, `bq.data.volatility`, `bq.func.range`

```python
# Common parameters
params = {'calc_interval': date_range}

# Required data items
data_items = {
    'Returns': bq.data.return_series(**params),
    'Total Rtn': bq.data.total_return(**params),
    'Annual Rtn': bq.data.ann_total_return(**params),
    'Volatility': bq.data.volatility(**params),
    'Downside Vol': bq.data.downside_volatility(**params),
    'Sharpe Ratio': bq.data.sharpe_ratio(**params),
    'Sortino Ratio': bq.data.sortino_ratio(**params),
    'Information Ratio': bq.data.information_ratio(**params),
    'Skew': bq.data.return_series(**params).skew(),
    'Kurtosis': bq.data.return_series(**params).kurt(),
    'Max DD': bq.data.max_drawdown(**params),
}

# Build and execute the request
request = bql.Request(universe, data_items)
response = bq.execute(request)

# DataFrame of the returns time series
df = response[0].df()
# DataFrame of all the other metrics
metrics_df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response[1:]],
    axis=1
)
```

```mermaid
flowchart LR
  F[Fund/ETF ticker] --> H[bq.univ.holdings / fundsuniv]
  H --> M[Metrics + flows + vs index]
  M --> V[Widgets / charts]
```


## Help Center Commodities Recipes

### Commitment of Traders
- Retrieves COT positions/traders together with futures price and open interest, including long/short/net breakdowns over time.
- **APIs:** `bq.data.cot_position`, `bq.data.cot_traders`, `bq.data.fut_aggte_open_int`, `bq.data.px_last`, `bq.func.range`

```python
def join_response_items(response, data_items):
    """
    Joins items from the BQL response into a single DataFrame indexed by
    security ID and date.
    """
    # If 'All' is selected as Tenor, there will be multiple rows per ID and
    # Date. These will have been grouped and summed via sum_over_id_and_date,
    # but the DataFrame for that item in the response will be indexed based on
    # this grouping layer and so will differ to the index for e.g., Price. 
    # We need to index these using their ORIG_IDS column (the original ticker)
    # so that we can concatenate them all effectively
    dfs = []
    for data_item in data_items:
        df = response.get(data_item).df()
        if 'ORIG_IDS' in df.columns:
            df = df.set_index('ORIG_IDS')
        df = df.set_index('DATE', append=True)
        dfs.append(df[[data_item]])
    df = pd.concat(dfs, axis=1)
    df.index.names = ['ID', 'Date']
    return df

    
def build_df(**kwargs):
    """
    Creates a combined DataFrame of COT traders/positions, price, and open
    interest for the specified universe and date range, including long,
    short, and net position breakdowns. Adds ISO week and year columns and
    returns rows with non-null Traders and Positions.
    """
    # Extract required args and create a daily date range
    universe = kwargs.pop('universe')
    dates = bq.func.range(kwargs.pop('start'), kwargs.pop('end'), frq='d')
    # Normalize all other parameter keys by replacing spaces with underscores
    kwargs = {k: v.replace(' ', '_') for k, v in kwargs.items()}

    data_items = {
        'Price': bq.data.px_last(fill='prev'),
        'Open Interest': bq.data.fut_aggte_open_int(fill='prev'),
        'Positions': sum_over_id_and_date(bq.data.cot_position(**kwargs)),
    }

    # Add direction-specific position series (Long, Short, Net)
    for direction in ['Long', 'Short', 'Net']:
        data_item = bq.data.cot_position(**kwargs)
        data_items[f'Positions - {direction}'] = sum_over_id_and_date((
            data_item
            .with_updated_parameters(direction=direction)
        ))

    for k in ['tenor', 'trader_activity']:
        kwargs.pop(k, None)
    data_items['Traders'] = sum_over_id_and_date(bq.data.cot_traders(**kwargs))

    # Retrieve and assemble the data into a single DataFrame
    request = bql.Request(
        universe, 
        data_items, 
        with_params={
            'currency': 'usd', 
            'dates': dates,
            'crop_year': ['NA','combined']
        }, 
        preferences={'unitscheck': 'ignore'}
    )
    response = bq.execute(request)

    df = join_response_items(response, data_items)

    # Add ISO calendar week and year
# ... truncated ...
```

### Commodity Option Open Interest Comparison
- Analyzes open interest concentration across strikes and expiries for an underlying security. Interactively explore where market participants focus their options activity.
- **APIs:** `bq.data.fut_month_yr`, `bq.data.id_bb_global`, `bq.data.open_int`, `bq.data.put_call`, `bq.data.px_last`, `bq.data.strike_px`, `bq.data.undl_ticker`, `bq.func.range`, `bq.univ.futures`, `bq.univ.list`, `bq.univ.options`

```python
class Model:
    """
    Handles data retrieval and transformation. Provides methods to fetch
    underlying and option data, then prepare it for visualization.
    """
    def __init__(self, bq=None):
        self.bq = bq or bql.Service() 
        
    def get_data(self, universe, data_items):
        """
        Returns data for a universe and a set of data items from BQL.
        """
        # Build and execute the request
        request = bql.Request(universe, data_items)
        response = self.bq.execute(request)
        # Process the response into a DataFrame
        df = pd.concat(
            [data_item.df()[data_item.name] for data_item in response], 
            axis=1
        )
        return df

    def get_underlying_price(self, universe):
        """
        Returns the underlying price of the chosen universe.
        """
        price = self.get_data(
            universe, 
            {'Price': bq.data.px_last(fill='prev')['value']}
        )
        return price.iloc[0, 0]
        
    def get_options_data(self, input_values):
        """
        Returns option data filtered by open interest and expiry for a
        chosen underlying.
        """
        start_date = input_values["start_date"]
        end_date = input_values["end_date"]
        
        # Convert expiry cutoff string (e.g., "6M") to number of months
        period_to_months = {"M": 1, "Y": 12}
        expiry_cutoff = input_values["expiry_cutoff"]
        try:
            cutoff = (
                int(expiry_cutoff[:-1]) * 
                period_to_months[expiry_cutoff[-1].upper()]
            )
        except:
            raise ValueError(
                "Invalid expiry cutoff format. " +
                "Acceptable format is e.g. '6M', '1Y'."
            )
        
        # Filter the universe based on minimum open interest
        open_int = bq.data.open_int(dates=end_date)
        open_int_chg = bq.data.open_int(
            dates=bq.func.range(start_date, end_date), fill='prev'
        ).znav().net_chg()
        
        if input_values['open_interest_mode'] == 'Open Int':
            open_int_filter = open_int
        else: 
            open_int_filter = open_int_chg
    
        universe = (
            bq.univ.options(bq.univ.futures(input_values["security"]))
            .filter(open_int_filter.abs() > input_values["min_open_int"])
        )

# ... truncated ...
```

### Commodity Pair Spread Matrix
- Builds pairwise commodity futures price/fair-value spread comparisons with a matrix and time-series drill-down.
- **APIs:** `bq.data.fair_value`, `bq.data.fut_days_expire`, `bq.data.id`, `bq.data.name`, `bq.data.px_last`, `bq.data.px_settle`, `bq.func.range`, `bq.univ.futures`

```python
def get_ticker_input():
    """Returns a list of tickers from the input box. Leading and trailing 
    spaces and empty strings are removed."""

    # Add COMB as the source if no source specified
    pattern = re.compile(
        r'^(?P<ticker>.+?)\s+(?!(?:PIT|ELEC|COMB)\b)(?P<sfx>Comdty|Index)\b',
        re.IGNORECASE
    )
    universe = []
    # Split into list of separate tickers, removing any blank entries in
    # the list
    for ticker in ticker_input.value.splitlines():
        universe.append(pattern.sub(r'\g<ticker> COMB \g<sfx>', ticker))
    return universe

def get_start_up_tickers():
    request = bql.Request(bq.univ.futures('CLA Comdty'), bq.data.id())
    response = bq.execute(request)
    # Take first 20 only
    df = response[0].df().head(20)
    tickers = df['ID()'].to_list()
    return tickers
```

### Seasonality Scatterplot
- Retrieves daily commodity prices and reshapes historical observations for seasonal cross-year scatter comparisons.
- **APIs:** `bq.data.px_last`, `bq.func.range`

```python
def get_bql_data(universe, start, end): 
    '''
    Retrieves daily price time series data.
    '''
    data_item  = {
        'Price': bq.data.px_last(
            dates=bq.func.range(start, end, frq='d')
        )
    }
    request = bql.Request(universe, data_item)
    response = bq.execute(request)

    df = response[0].df()

    return df.reset_index()
```


## Get Data Official Tutorial: Funds / FX / AIM

```mermaid
flowchart LR
  A["Funds / FX / AIM"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### BQL for Funds
- This notebook demonstrates several ways you can use BQL to perform fund analyses.
- **Topics:** Quickstart: BQL for Funds; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Querying for an individual fund¶; Querying for multiple data items¶; Querying for multiple tickers¶
- **APIs:** `bq.data.ann_total_return`, `bq.data.classification_name`, `bq.data.fund_asset_class_focus`, `bq.data.fund_flow`, `bq.data.fund_geo_focus`, `bq.data.fund_net_asset_val`, `bq.data.fund_strategy`, `bq.data.fund_total_assets`, `bq.data.fund_typ`, `bq.data.id`, `bq.data.information_ratio`, `bq.data.liquidation_cost`, `bq.data.liquidation_horizon`

```python
# Define the target universe, multiple securities, using several ID types
universe = [
    'SPY US Equity',    # Bloomberg Ticker
    'BBG00KY6GPH3',     # FIGI
]

# Define your target data
data_items = {
    'Name': bq.data.name(),
    'Annualized Return': bq.data.ann_total_return(),
    'Max Drawdown': bq.data.max_drawdown(),
    'Sharpe': bq.data.sharpe_ratio(),
    'Sortino': bq.data.sortino_ratio(),
    'Information Ratio': bq.data.information_ratio(),
    'Volatility': bq.data.volatility()    
}

# Build and execute the request and display the results
request = bql.Request(universe, data_items)
response = bq.execute(request)

data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
data
```

```python
universe = 'MABAX US Equity'

last_year = bq.func.range('-1y', '0d')

# Define target data including a BQL function that calculates the difference
# between price on each date in the time series
daily_price_change = bq.data.px_last(dates=last_year).diff().dropna()
count_days = daily_price_change.count()

data_items = {
    'Up Days %': (daily_price_change > 0).tonumber().sum() / count_days,
    'Down Days %': (daily_price_change < 0).tonumber().sum() / count_days,
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
data
```

### BQL for FX
- This notebook demonstrates several ways you can use BQL to perform FX analyses.
- **Topics:** Quickstart: BQL for FX; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Querying for an individual currency pair¶; Querying for multiple data items¶; Querying for multiple tickers¶
- **APIs:** `bq.data.cot_position`, `bq.data.cot_traders`, `bq.data.curve_rate`, `bq.data.id`, `bq.data.name`, `bq.data.px_ask`, `bq.data.px_bid`, `bq.data.px_high`, `bq.data.px_last`, `bq.data.px_low`, `bq.data.px_open`, `bq.data.settle_dt`, `bq.func.range`, `bq.univ.curveMembers`

```python
universe = [
    'EC1 Curncy',
    'SF1 Curncy'
]

# Common arguments for data items
kwargs = {
    'dates': bq.func.range('-1y', '0d'), 
    'commitment_type': 'FUTURES_AND_OPTIONS', 
    'trader_type': 'COMMERCIAL', 
    'direction': 'LONG'
}

# Data items for both positions and traders. trader_activity item only 
# applicable to cot_position
data_items = {
    'Positions': bq.data.cot_position(**kwargs, trader_activity='ALL'),
    'Traders': bq.data.cot_traders(**kwargs),
}

# Build and execute the request
request = bql.Request(universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df() for data_item in response],
    axis=1
)

# Drop any duplicated metadata columns
df = df.loc[:, ~df.columns.duplicated()]

# Retain just the DATE from the metadata and the requested data item columns
df = df[['DATE'] + list(data_items.keys())]

# Reshape the DataFrame
df = (
    df.reset_index()
    .pivot(columns='ID', index='DATE', values=['Positions', 'Traders'])
    .dropna()
)

df.head()
```

```python
# Define universe items
currency_pair = 'USDMXN Curncy'

tenor_range = bq.func.range('SP', '6M')
date_range = bq.func.range('-1Y', '0D')

universe = bq.univ.curvemembers(
    currency_pair,
    curve_type='FX',
    quote_type='points',
    tenors=tenor_range
)

data_item = {'Rate': bq.data.curve_rate(dates=date_range).dropna()}

# Initiate and execute request
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Parse the response object as a DataFrame
df = response[0].df()

# Pivot the DataFrame around the rate item
pivot = df.pivot(columns='TENOR', index='DATE', values='Rate')

# Re-index the columns based on the sorted tenor values
pivot = pivot.reindex(
    df.sort_values('SETTLE_DATE')['TENOR'].drop_duplicates(), 
    axis=1
)

pivot.head()
```

### Restricted historical tutorial

The Sustainable Finance tutorial was removed from the canonical code-generation corpus. Historical provenance is non-indexed and execution is prohibited.

### BQL for AIM
- This notebook is designed to show off several ways you can use BQL to access and analyze your Asset and Investment Manager (AIM) portfolios.
- **Topics:** Quickstart: BQL for AIM; Open an interactive version; Table of contents¶; Prerequisites¶; Setting up your environment¶; Querying BQL for data¶; Querying for members of an AIM portfolio¶; Querying for AIM positions¶
- **APIs:** `bq.data.id`, `bq.data.name`, `bq.data.net_market_val`, `bq.data.px_last`, `bq.data.security_typ`, `bq.data.ts_position`, `bq.univ.members`

> **Entitlement split (user-confirmed):** AIM Enterprise license is present; BQuant runtime remains Desktop. AIM members/positions are therefore in scope. Do not treat AIM as a BQuant Enterprise feature, and do not refuse AIM BQL just because the notebook runs on Desktop.

Tutorial-observed workflow:
1. Build an AIM account universe with `members(..., type='AIM', ...)`.
2. Retrieve positions with `bq.data.ts_position()`.
3. Filter the account universe and aggregate positions/market value.

Still unresolved without FLDS/runtime evidence for the generic tutorial:
whether other AIM notebooks require dates on `ts_position()`, and whether
account arguments belong on `members()` in other apps. Keep Desktop BQL
timeout/universe-size limits.

> **user-confirmed ETF Capping Monitor (2026-08-28 Desktop, IMG_6673 /
> IMG_6674):** AIM used `bq.univ.members(type="AIM")` with `accounts`,
> `pxnum=1377`, and `profile="DEFAULT_PROFILE"` on `with_params`. **ETF
> runtime (`25`):** `accounts` is a list of **one** AIM code per Request
> (`{"accounts": [account]}`), batched 8-wide; do not pass a bare string or
> the whole book. Current used `position_without_pending()["value"]`.
> `pending_position()["value"]` alone returned all zeros. Projected used
> Current plus Pending and returned the non-zero book. Cash FX fetch used
> `px_last(dates=..., fill="prev")` on `USD{CCY} BGNL Curncy`; USD price
> invert lives in `25` § Asset classifier and cash FX. Freeze that ETF
> contract; do not treat tutorial `ts_position()` as this app's Projected
> item.

```python
# Define the target universe, an individual bond, identified by its 
# Bloomberg ticker 

# You can use any combination of Bloomberg tickers, CUSIPs, ISINs, 
# FIGIs to identify the securities in your universe of interest.

universe = 'EC527035 Corp'

# Define the target data, the bond's price, and label the column 'Price'
data_item = {'Price': bq.data.px_last()} 

# Build and execute the BQL query
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Present the data as a Pandas DataFrame
df = response[0].df()
df
```

