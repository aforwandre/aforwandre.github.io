# Project Operations and History (Aggregated)

> **Provenance.** This file aggregates the durable, knowledge-base-relevant
> content of three workspace-running documents that are **not** shipped in this
> package: `instruction.md` (current run steps), `ToDoList.md` (open ideas and
> known gaps), and `VersionLog.md` (append-only decision history). Transient
> step-by-step runbook text, per-session chatter, and live account/personnel
> identifiers were dropped or redacted. Per-project **runtime authority** still
> lives in the route cards `25`–`29` and the reference implementations under
> `../User scripts/`; this file is the operations + known-gaps + history layer
> that ties them together.
>
> **Redaction note.** Real AIM account codes, real fund names, and real
> personnel names have been replaced with sample values (`ACCTnn`, `Sample
> Fund nn`, `Sample FM n`, `SAMPLEAIM`) throughout this package. Bloomberg
> **index** mnemonics such as `LEGATRUU Index` are published identifiers and
> are kept intentionally.

---

## 1. Global operating protocol (universal BQuant safety)

These apply to every project and every AI coding agent working with this KB:

- **Desktop-only execution.** BQuant Desktop is the runtime. Never execute BQL,
  BQuant, or Bloomberg data requests from a local machine. Local IDEs are for
  design, authoring, and review only.
- **Closed-world evidence.** Use only the local corpus in `RAG KB/`. The
  official Help Center / catalog corpus is frozen at **2026-07-25**; later
  claims require dated, user-supplied evidence labeled `user-confirmed`. Never
  use web search, external Bloomberg pages, or model memory to fill a BQuant
  evidence gap.
- **ESG/GHG hard stop.** Never request, probe, test, generate, or use ESG, GHG,
  climate, or sustainable-finance data items for any purpose. Archived examples
  are documentation only. A violation can suspend or delete the Bloomberg
  account. (See `rules/00-bquant-hard-stops.md`.)
- **Entitlement discipline.** Avoid unfamiliar fields or product families that
  may need a separate license. If no confirmed core-data alternative exists,
  stop and obtain Bloomberg HelpDesk confirmation of the FLDS BQL tab,
  semantics, entitlement, and permitted request breadth. Never probe a field to
  discover entitlement.
- **Retrieval first.** Before writing a query, open `00-RAG-INDEX.md` and read
  only the route for the named destination. A named app uses its route card
  (`25`–`29`); a new composition goal uses one `BUNDLE_EXAMPLES.md` Goal-table
  card; a genuinely new token uses an exact `## token` search in
  `CONCEPT_INDEX.md`, then the substitution review in `23`.
- **Request budget.** Keep requests narrow and batched. Desktop has download
  limits, a **two-minute** single-request timeout, at most **two concurrent**
  workloads, **one running instance per project**, and a **256 MB** file limit.
- **Environment.** Python **3.11**. Default stack is `bql`, pandas, Plotly,
  ipywidgets, IPython display helpers, `ipydatagrid`, and Portfolio Library. No
  external APIs, no undeclared network calls, no `pip` installs from the
  workspace, and never create a new `bqport`.
- **Code placement.** Keep user code under `User scripts/<Project Name>/`,
  separate from `RAG KB/`, generated bundles, and provenance archives.

### Switches that stay off

- No new portfolio-library object.
- No package install from this workspace.
- No second concurrent run of the same project.
- ASKB is **not** entitled on this account. Gallery/official-script ASKB
  examples are demo documentation only — never copy them into a project or
  describe an ASKB path as ready to run.

---

## 2. Cross-platform collaboration model (upstream context)

The source workspace keeps its rules as a **three-way byte-identical mirror**
(`.cursor/rules/*.mdc` ⇄ `.qoder/rules/*.md` ⇄ `.trae/rules/*.md`) maintained
by a sync script, with `VersionLog.md` as the append-only bridge between
platforms. Key rulings:

- **No platform is "first."** Any of the three may run a task, but only one runs
  at a time; a real conflict stops for the operator. Direction is decided by
  which side drifts from the sync baseline.
- `VersionLog.md` is **append-only**: never rewrite, delete, reorder, or merge an
  existing entry; a correction is a new entry. Retired rulings are superseded by
  a new entry, never by editing old ones.
- Every rule edit ends with a visual-diff review: apply all edits first, then
  review each checkpoint (accept/reject per file, or Accept All).

> **This package ships a single neutral `rules/` folder instead of the three
> mirrored trees**, and does not include the sync tooling. Treat the sync/mirror
> mechanics as upstream background; see `rules/README.md` for how to convert the
> neutral rules into your own platform's format.

---

## 3. Per-project reference implementations

Five independent BQuant Desktop notebook dashboards live under `../User scripts/`.
Each is self-contained (own package, `tests/`, `MAIN.ipynb`, `README.md`); none
imports another. Runtime authority is the matching route card.

| Project | Route card | Package | Lifecycle | Notable frozen facts |
|---|---|---|---|---|
| ETF Capping Monitoring | `25` | `etf_capping/` | Update-only | Company-group capping; Thai foreign-line pricing overrides; Last Close vs Real Time; market-status zero-price fallback; `SECURITY_BATCH=150`, `AIM_ACCOUNT_BATCH=8` |
| ETF Spread Monitoring | `27` | `etf_spread/` | Refresh-only | Typed ISIN book + manual `peer_map.py`; bid/ask/mid/last quotes; daily history cache (`quotes/returns/navs/flows.csv` + `manifest.json`); taxonomy + flow heatmap; peer screen capped near 200 names |
| FI Index Change | `28` | `fi_index_change/` | Update-only | Month-end bond adds/exits; `SPLIT_REQUESTS=True` (3 requests/date, ≤6 analytics each); 23 fields = 13 identity + 6 spread/yield + 4 duration; Rating from `BASE_RATING` (ignore `NORMALIZED_SCALE`); buckets IG/HY/NR; turnover `(approx)` (no `market_value()`); Export puts `Weight` after `Sector` with a `%` |
| FI Spread Movement Monitoring | `29` | `fi_spread_movement/` | Update-only | Top-10 spread increases/decreases for Index / AIM / Bond / AIM-vs-Index; `TOP_N=10`; one-book = 10 requests, comparison = 12; duration measures (Modified/Effective/OASD) ride the one duration request; timeout retry once (`QUERY_ATTEMPTS=2`) + amber `Cached` fallback |
| MDX Scan | `26` | `mdx_scan/` | `load_on_start=True` | Live HSI members + benchmark OHLCV; MDX v4e daily signal engine (pandas port of `Source/MDX_futu_formula.txt`); filterable grid + Plotly candlestick |

**Deployment shape (all projects):** create `MAIN.ipynb` plus the package on
Desktop, restart the kernel, run the single notebook cell; the data request fires
only when the user clicks **Update** (MDX Scan is the exception — it loads on
start). Copy the full package (module-load imports such as `cache`/`charts` must
be present or the first cell fails with `ModuleNotFoundError`). Do not copy a
local `cache/` — it is regenerated on Desktop.

---

## 4. Known gaps and unverified items (durable ledger)

Carried forward from the open/blocked tracker. These are **evidence-gated**, not
effort-gated: do not "fix" them by guessing or probing a catalog row.

### FI Spread Movement Monitoring
- **AIM-account ranking is refused by BQL** (blocked). A `members(type='AIM')`
  universe with a `net_chg(spread(...)) > 0` filter returns
  `[BQLInternalExecutionError] ... Predicate must be a Boolean expression`. An
  empty/refused AIM run says nothing about the account's holdings — never read it
  as an empty book, and never swap `filter()` for `matches()` on a guess. Unblock
  only with HelpDesk confirmation, a dated official card composing the two, or an
  operator decision to resolve the book to a `univ.list` first and rank in pandas.
- **Spread units unresolved** (blocked). The operator reports values arriving "in
  thousands" and expects basis points, but no code path scales anything (only
  `round(6)`). `29` forbids calling values bps before Terminal evidence. Capture
  the shown value, the same bond's Terminal OAS in bp, whether `Change` is off by
  the same factor, and the response column names — "off by 10" and "off by 100"
  have different fixes.
- **Desktop is pandas 1.x** (prints `Int64Index`), while the local dev machine
  runs pandas 3.x. A green local `pytest` is therefore **not** evidence about
  Desktop `.loc`/reshape behavior. Record Desktop `pandas`/`numpy`/Python
  versions from the kernel; rely on fail-soft containers and the
  `[file:line in function()]` banner until a local environment matches.
- **Bare `duration()` semantics** unverified: which measure the plain `Duration`
  column holds (if already Modified, `Modified Duration` duplicates it), and
  whether `duration_type='SPREAD'` (OASD) shifts the OAS curve or the benchmark
  curve. Settle by comparing columns on one Desktop batch, never by probing a new
  item. A step-log line naming two columns as identical means BQL ignored
  `duration_type`.
- Open: `net_chg()` endpoint behavior with no `fill` on weekend/holiday endpoints;
  Z-spread parameters (`pricing_source`) and multi-currency coverage;
  `rating()` letter-vs-number scale (display only, never parsed numerically);
  core-data entitlement for every requested item; the `AIM vs Index` 12-request
  path and a wide-window candidate union are still unmeasured (measured so far:
  ~25 s per ranking request on `LEGATRUU Index`, 10 requests ≈ 58 s).
- **Plotly on Desktop:** a displayed `FigureWidget` does **not** render a whole
  `figure.data = ...` replacement — mutate traces in place and keep the
  container. Do not reintroduce the wholesale-replacement form.

### FI Index Change
- Open: confirm `members(dates=upcoming weekday)` returns the announced set after
  publication; record whether `rating()` returns letters, numbers, or mixed;
  Phase 3 would pin OAS/duration/yield/rating to the effective date with
  `fill='prev'`; confirm `WEIGHT_FRACTION_SUM_MAX = 1.05` classifies this index's
  weight units; decide whether a constituent whose membership weight never
  arrived stays with a note (current) or invalidates the month.
- **Doc defect:** `RAG KB/28` contradicts itself on `SPLIT_REQUESTS` — three
  passages say `True` (matches shipped code), one old paragraph says it "stays
  `False`" and describes a two-way split. Correct that paragraph upstream.
- A month-end equal to today is requested but **never cached** (membership may
  still be the previous locked set that day). Turnover is always `(approx)`
  because no per-bond `market_value()` is requested; restoring the official basis
  would widen the request that already timed out.

### ETF Spread Monitoring
- Open (unproven on Desktop): the daily history cache (`cache/` appears with the
  four CSVs + `manifest.json`; a second Refresh reuses stored rows and requests
  only missing days; `Use cache` off re-requests the whole window); the
  ticker→ISIN identity binding (a moved primary class re-requests that fund's
  history in full, and reports `N identifier(s) now resolve to a different
  security`); and whether removed share classes/peers should ever be pruned from
  `cache/` (nothing prunes today by design — a prune keyed on the current run
  would delete another Strategy's history).

### Rule channel
- The count is **12** project rules (`95-visual-diff-gate` was promoted from
  TRAE-only to three-sided). On first use in a new platform, confirm the rules
  actually attach rather than assuming they loaded.

---

## 5. Decision-history digest

Condensed from the append-only log (newest first). Full per-decision evidence
lives in the route cards and each project's `DECISION_RECORD.md` /
`VERIFICATION_REPORT.md` where present.

**Corpus and platform**
- `2026-07-25` — Official corpus cutoff (evidence frozen at this date).
- `2026-10-25` — Rule channel widened to three sides (Cursor ⇄ Qoder ⇄ TRAE),
  switched to bidirectional; "no platform is first"; visual-diff gate goes
  three-sided; Qoder mirror of the Cursor rules and indexing boundary.

**MDX Scan** — `2026-08-27` notebook; MDX v4e channel ported to pandas from
`Source/MDX_futu_formula.txt` (Wilder smoothing, population std `ddof=0`, v4e BOT
requires `Close >= Open`, daily bars only).

**ETF Capping Monitoring** — `2026-09-02` monitor; company-group capping, Thai
foreign-line pricing (preserve original AIM ticker/quantity for `/F TB Equity`
and `-R TB Equity`; resolve local pricing via approved overrides + deterministic
strip validation + leftover HelpDesk DRSK; never use CAST parent or integer
company id as a pricing ticker; unresolved mapping fails closed), market-status
zero-price fallback.

**ETF Spread Monitoring** — `2026-10-23/24` V1 hardening and user confirmations:
HSBC taxonomy kept; taxonomy universe switch (HSBC / Bloomberg Global); exchange
taxonomy tab; fund assets and period ticks; flow heatmap (one row per fund name,
typed `IsinEntry` order); benchmark peers via `fund_benchmark_prim()` + ` Index`
suffix; peer screen cap; underlying index ticker; RAG KB outranks the in-BQuant
assistant. `2026-11-02` daily history cache on the four history legs; the cache
self-invalidates when the book, peers, or request change; a ticker is bound to
its ISIN so a moved primary class cannot reuse history.

**FI Index Change** — `2026-10-22` one month-end + detail/weight export.
`2026-11-01` detail table pins `ID`; charts stop at 80% of FHD and the first
column stays pinned; `Weight` moves after `Sector` and prints as a percent; one
local refresh command (`refresh_local.py`); preview builder stops rewriting
identical bytes; adversarial and third-party reviews adjudicated; rating
classification collapsed to **IG / HY / NR** (a blank, a stated NR, `N.A.` on an
MBS/TBA or Municipal row, and a vendor numeric scale all map to NR — that is why
Desktop once showed NR/Missing everywhere). `2026-11-02` the membership request
settled at **22–23 items** because the 36-item request timed out; the duration
block became four `duration_type` items; the 23-item single request timed out so
the fetch runs as **three requests**; `ESPD` signature recorded; `Asset swap
spread` (ASW) pruned from `SPREAD_FIELDS` (it was a fourth spread never logged).

**FI Spread Movement Monitoring** — `2026-10-23` Copilot drafts and audit
findings. `2026-10-24` independent review, user confirmation, KB reconciliation,
V1 rewrite. `2026-10-30/31` Index field; Universe dropdown + five filters; two
more sources (Bond, AIM-vs-Index) and two tabs. `2026-11-01` comparison chart
plots both books, path chart plots one bond; `AIM vs Index` draws the AIM code
before the Index box; preview on 8775 follows the code on disk; `Upload/` is a
generated mirror. `2026-11-02` start/end spread columns added and headings name
the spread type; duration reference columns (Modified/Effective/OASD) added and
cost **no extra request**; five defects closed; version stamp deleted (header
matches FI Index Change); ASW withdrawn the same day it was added; the reported
"dead Refresh" was a page rendered by older code; each ranked panel gets its own
`Display Top` box + Refresh; two Desktop failures traced to the layer **after**
the data arrives (an empty answer was being reported as a misspelt field, and a
reshape fault now contains itself); three blank charts fixed by mutating a
displayed `FigureWidget` in place instead of rebuilding it; a weekend end date no
longer spends a request; the spread scale remains an open question (see §4).

---

## 6. What was intentionally dropped from the source documents

- Step-by-step Desktop runbook prose (duplicated by the route cards `25`–`29`
  and each project `README.md`).
- Per-session transient notes and timing estimates marked "Not measured."
- Live account codes, real fund names, and real personnel names (redacted).
- The workspace-only clause forbidding reading a sibling workspace's secretary
  files (not applicable outside the curator's environment).

For the current, authoritative per-project runtime contract, always open the
route card (`25`–`29`) and the reference implementation under `../User scripts/`.
