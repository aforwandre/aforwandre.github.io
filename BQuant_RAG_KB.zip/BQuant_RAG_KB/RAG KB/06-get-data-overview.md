---
topic_id: "06"
title: Get Data Overview
role: query_workflow
authority_for: [request_anatomy, field_discovery, universe_data_item_boundary]
not_authority_for: [individual_field_semantics, entitlement]
evidence_grades: [canonical]
risk_tier: normal
routing_keywords: [Request, universe, data_item, field_discovery, FLDS, string_BQL]
mandatory_cross_checks: [00-RAG-INDEX, 07-pybql-api-reference, 08-bql-data-items, 23-bql-substitution-due-diligence]
restricted_sections: []
source_families: [help_center, workspace_curation]
---

# Get Data — Overview

> AI-oriented BQL data access primer for CURSOR_BQNT.
> PyBQL is the Python implementation of Bloomberg Query Language inside BQuant.

---

## Request Flow

Every BQuant data pull follows the same object-syntax pattern:

```mermaid
flowchart LR
    U[Universe] --> R[bql.Request]
    D[Data items dict] --> R
    P[with_params optional] --> R
    R --> E[bq.execute]
    E --> F[response i.df]
    F --> G[pd.concat if multi-item]
```

```python
import bql
import pandas as pd

bq = bql.Service()
universe = bq.univ.members('INDU Index')
data_items = {'Name': bq.data.name(), 'PE': bq.data.pe_ratio()}
response = bq.execute(bql.Request(universe, data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Index rule:** Security IDs appear on `df.index`, not as a `'ID'` column.

---

## Universe Helpers (Quick Reference)

| Helper | Example |
|--------|---------|
| Index members | `bq.univ.members('LUACTRUU Index')` |
| Equities | `bq.univ.equitiesuniv(['ACTIVE', 'PRIMARY'])` |
| Bonds | `bq.univ.bondsuniv('Active')` |
| Issuer chains | `bq.univ.bonds(['AAPL US Equity'])` |
| Fund holdings | `bq.univ.holdings('HYG US Equity')` |
| Filter | `.filter(predicate)` chained on any universe |

Large screens: pass `with_params={'mode': 'cached'}` on the Request.

---

## Excel/API and substitution gate

Do not begin an Excel/API migration with a fuzzy catalog search.

1. Inventory the source BDP/BDH/BQL formula, FLDS tab, parameters, business
   role, universe, output shape, batch breadth, and failure behavior.
2. Classify the requirement as universe transformation, data item, metadata,
   Pandas/business rule, CDE, Portfolio Library, restricted, or unresolved.
3. Search the official tutorial for the business intent.
4. Apply `23-bql-substitution-due-diligence.md`.
5. If there is no confirmed BQL equivalent, stop and request the user's FLDS
   BQL tab and proposed alternatives. Independently review every alternative.

Excel/API mnemonics cannot be converted mechanically to `bq.data.*`. A CDE is
not an API-to-BQL bridge. A ticker-shaped result is not proof that a field has
the required identity semantics.

## Field Discovery — Catalog First, FLDS When Needed

BQL exposes tens of thousands of data items. **Never invent field names.**

For a known data-item requirement:

1. Exact-search the code in `22-BQuant_DataItems.md`.
2. An exact row confirms mnemonic spelling/existence for the extracted Bloomberg catalog.
3. Use `08-bql-data-items.md` and the routed domain file for meaning, metadata traps, and implementation.
4. Open Terminal `FLDS` → BQL only when candidates are ambiguous or parameters, metadata, universe compatibility, entitlement, or current runtime behavior need confirmation.
5. Record reusable semantic/signature findings in `08`.

For substitutions or description-only searches, use the high-risk workflow
above before accepting any catalog candidate.

---

## String Safety Rule

- Never paste Bloomberg physical-key / GO-style command symbols wrapped in angle brackets into Python strings or comments.
- Some clipboard tools rewrite braces `{}` into physical-key glyphs and cause hard `SyntaxError` failures.

---

## Topic File Map

| Need | File |
|------|------|
| Complete mnemonic/description catalog | `22-BQuant_DataItems.md` |
| Curated field semantics / traps | `08-bql-data-items.md` |
| Equities patterns | `01-bql-for-equities.md` |
| Fixed income patterns | `02-bql-for-fixed-income.md` |
| FI screening recipes | `12-bql-fixed-income-screening.md` |
| Snippet catalog | `11-sample-notebooks.md` |
| Pandas post-processing | `18-using-pandas.md` |

## Get Data Official Tutorial: Core Guides

Official Get Data guides. Prefer object syntax; string BQL only when required.

> Desktop routing: the Help Center hubs also link to Enterprise quickstarts. This project must stay on the Desktop topic routes in `RAG KB/00-RAG-INDEX.md`.

```mermaid
flowchart LR
  A["Core Guides"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### BQL Overview
- Building a custom analysis of financial data can be cumbersome. You often need to fetch large, costly datasets, then spend time aligning and manipulating the data before starting your work. BQL is a solution created by and for financial professionals to overcome these barriers.
- **Topics:** Table of Contents; Introduction; How BQL works; Process overview; Queries; Calculation; Output; See also

### BQL Basics Tutorial
- Introduction Foundation of BQL The skills you need Using BQL in BQuant Constructing your target universe Retrieving your target data Analyzing data with functions Working with the output Handling errors Putting it all together Going further
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Foundation of BQL¶; The skills you need¶; Using BQL in BQuant¶; Constructing your target universe¶; Retrieving your target data¶
- **APIs:** `bq.data.bics_level_1_sector_name`, `bq.data.classification_name`, `bq.data.country_full_name`, `bq.data.cpi`, `bq.data.free_cash_flow_yield`, `bq.data.is_eps`, `bq.data.name`, `bq.data.pe_ratio`, `bq.data.px_high`, `bq.data.px_last`, `bq.data.px_low`, `bq.data.px_open`, `bq.data.px_volume`

#### Teaching notes
- A relative as-of holding example uses `holdings(..., dates='-2Q')`; confirm the universe supports the requested historical date.
- A literal private universe passed to `value(universe=...)` should be wrapped with `bq.univ.list([...])`, rather than relying on an untyped Python list.
- The tutorial shows `spread(..., pricing_source='bgn')`; pricing-source values and casing are field-specific and require FLDS confirmation.

```python
# Set up your environment:
# import pandas as pd
# import bql
# bq = bql.Service()

# Define the target universe of your BQL query: one or more entities
universe = 'AAPL US Equity'

# Define the target data (e.g., last price) you want for the universe
data_item = bq.data.px_last()

# Pass the two parts of your query as arguments for a Request object
# And execute the request
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Parse the response as a DataFrame and print the output
data = response[0].df()
data
```

```python
# For each Euro Stoxx 50 Index member that was in the index
# on December 31, 2020, retrieve its last-reported price
# as of March 6, 2023

universe = bq.univ.members('SX5E Index', dates='2020-12-31')
data_item = bq.data.px_last(dates='2023-03-06')

request = bql.Request(universe, data_item)
response = bq.execute(request)

data = response[0].df()
data.head()
```

### String and Object BQL Queries
- The Bloomberg Query Language (BQL) Python API enables you to retrieve and transform BQL financial data from BQuant. Using a BQL query, you can apply, for example, calculations, statistical analysis, and screening to normalized, point-in-time financial data. The BQL Python API returns the results of these queries as ...
- **Topics:** Overview; BQL string syntax; Example; BQL object syntax; Example; BQL query execution; Examples; See also
- **APIs:** `bq.data.px_last`, `bq.func.range`, `bq.univ.members`

```python
# Set up your environment
import bql
bq = bql.Service()

# Define the data item and universe for your query
dates = bq.func.range('-1M','0D')
data_item = bq.data.px_last(dates=dates).avg()
universe = ['AXP US EQUITY','V US EQUITY','MA US EQUITY']

# Create a Request object using the data item and universe
request = bql.Request(universe, data_item,
  with_params={'CURRENCY':'EUR'})

# Execute the BQL query
response = bq.execute(request)

# Print the output as a DataFrame
data = response[0].df()
data.head()
```

### Defining BQL Universes
- Every BQL query requires you to specify the target universe for which you want to retrieve data. This defines the set of securities, indices, countries, or other entities you want to analyze. BQL offers multiple ways to declare your universe, depending on your workflow and asset class.
- **Topics:** Defining BQL UniversesNew; Overview; Specifying IDs; Using universe functions; Types of universe functions; Equity universe functions; Fixed income universe functions; Other asset classes
- **APIs:** `bq.data.px_last`, `bq.univ.members`

#### Function catalog

| Family | Common universe functions | Canonical recipe |
|--------|---------------------------|------------------|
| Equity/index | `members`, `equitiesuniv`, `holdings`, `peers` | `01` |
| Fixed income | `bonds`, `bondsuniv`, `debt` | `02`, `12` |
| Curves / FX / commodities | `curvemembers` and explicit curve IDs | `11` |
| Economics | `countries` and explicit economic series IDs | `13` |
| Funds / portfolios | `fundsuniv`, `holdings`, `portuniv` | `11`, `14` |

Function availability and signatures vary by asset class and entitlement; route to the topic recipe and use FLDS when uncertain.

```python
import bql

bq = bql.Service()

# Create a static universe using a list of IDs
universe = [
    'AAPL US Equity',
    'MSFT US Equity',
    'GOOGL US Equity',
]

# Define the data you want to retrieve: Last Price
data_item = bq.data.px_last()

# Build the query and execute the request
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Present the data as a pandas DataFrame
data = response[0].df()
data
```

### Aligning and Merging BQL Responses
- When you query data from BQL, the results are returned as a bql.Response object that contains one or more bql.SingleItemResponse objects. You can then call bql.SingleItemResponse.df() to get the data as a pandas DataFrame.
- **Topics:** Overview; Single data item; Inspecting a DataFrame’s shape; Multiple data items of the same shape; Cleaning up your data; Multiple data items with different shapes
- **APIs:** `bq.data.name`, `bq.data.px_last`, `bq.data.px_volume`, `bq.func.range`

```python
import bql, pandas as pd
bq = bql.Service()

universe = ["IBM US Equity", "VOD LN Equity"]

# retrieve price and volume time-series data from the past week
data_items = {
      "px": bq.data.px_last(dates=bq.func.range("-1w", "0d")),
      "volume": bq.data.px_volume(dates=bq.func.range("-1w", "0d"))
}
request = bql.Request(universe, data_items)
response = bq.execute(request)

# get price data
df_px = response[0].df()

# get volume data
df_volume = response[1].df()

# confirm that both DataFrames share the same index
if (df_px.index.equals(df_volume.index)):
    print("DataFrames share the same index and can be combined.")

df_combined = pd.concat([df_px, df_volume], axis=1)
df_combined.head()
```

