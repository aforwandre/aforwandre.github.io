---
topic_id: "29"
title: FI Spread Movement Monitoring
role: project_runtime_authority
authority_for:
  - fi_spread_movement_shell
  - spread_change_ranking
  - fi_spread_movement_validation_request
  - fi_spread_aim_universe_binding
not_authority_for:
  - entitlement
  - verified_field_semantics
  - verified_units
evidence_grades:
  - user-confirmed
  - practice-derived
risk_tier: high
routing_keywords:
  - FI Spread Movement Monitoring
  - Top 10
  - Bottom 10
  - spread movers
  - AIM account universe
  - position_without_pending
mandatory_cross_checks:
  - 00-RAG-INDEX
  - 02-bql-for-fixed-income
  - 18-using-pandas
  - 23-bql-substitution-due-diligence
restricted_sections: []
source_families:
  - user_request
  - workspace_policy
---

# FI Spread Movement Monitoring

## Retrieval card

Build a BQuant Desktop tool to monitor spread movers and display the largest
10 increases and decreases in a user-confirmed fixed-income universe. This
goal was supplied by the user from colleague meeting notes on 2026-10-23.
Huini's demonstrated setup is a reference to obtain and review, not a local
runtime dependency or authority for an unverified field.

On 2026-10-31 the universe became a choice: a typed Bloomberg index ticker, or
an AIM account whose holdings are the universe. Both paths spend the same
OAS/Z/I ranking and the same descriptors. The AIM request shape is the frozen
contract owned by `25` § AIM request shape; this file records only how this app
applies it.

Code belongs under `User scripts/FI Spread Movement Monitoring/`. Keep
`MAIN.ipynb` thin and split configuration, BQL access, pure pandas logic,
and UI into importable modules. Local checks use synthetic data only. BQL
runs only in BQuant Desktop after an explicit Update.

## Monitoring contract

- Display two ranked lists, each capped at 10: largest increases and largest
  decreases in the selected spread measure.
- Compare spread changes over the explicitly selected date range using the
  documented `net_chg()` calculation. Do not forward-fill, interpolate, or
  silently substitute a nearby observation.
- Rank positive and negative changes in BQL; validate and order returned
  candidate frames in pandas. Keep security `ID` as the row key.
- The scaffold labels values as spread units returned by the source. Do not
  call them bps or percentages until Terminal evidence establishes units.
- Missing or non-numeric changes are excluded with diagnostics; they are not
  converted to zero. Duplicate security IDs are not silently expanded.
- The screen labels positive/negative changes. The business interpretation
  of "widening" versus "tightening" must be checked against the selected
  spread measure.
- `MAIN.ipynb` displays the app but does not trigger a startup request.

## Request and validation boundaries

The user selected `LEGATRUU Index`, OAS/Z/I spread choices, custom start/end
dates, and the descriptors `id`, `name`, `rating`, `crncy`, `maturity`, and
`duration` on 2026-10-23, and confirmed that selection in chat on 2026-10-24.
**Amended 2026-11-02:** `Asset swap spread` (`ASW`) was briefly a fourth choice,
added at the operator's request and matching the identical choice then in `28`.
It was a parameter value on the same `spread(spread_type=...)` call, not a new
data item. **Withdrawn later the same day** at the operator's request, because a
swap-curve measure would make the Desktop request too heavy and risk the
two-minute timeout; the choices are `OAS` / `Z` / `I` again and the withdrawn
value is refused, not mapped. See `## User confirmation (2026-11-02)`. The `id`
descriptor is
displayed from the ranking response `ID` key; the other
five descriptors are requested from BQL. The local FI Index Change card identifies
`LEGATRUU Index` as the Global Aggregate index; the UI must not call it a US
Treasury universe.

On 2026-10-31 the user asked for the five dimension filters to match the
Dimension list in FI Index Change, which added `country_full_name` as
`Country` and `classification_name` as `Sector`. Both are the items `28`
already freezes on this same bond index universe, so this is not a new
field family; the `23` decision is DR-13 in the project
`DECISION_RECORD.md`. They are display dimensions only: nothing is filtered
in BQL, a failed request leaves `(unavailable)` and a diagnostic in the step
log, and a blank value Bloomberg returned shows as `(blank)`. Do not
substitute `country_iso()` or `market_sector_des()`, and do not move these
dimensions into a BQL filter.

Use `bq.univ.members(index, dates=end_date)`: the cohort is membership as of
the selected end date, not a point-in-time comparison at both endpoints.
The index ticker is typed into the Index field on each launch. That field
starts empty. `LEGATRUU Index` is the recorded example (Global Aggregate)
and the field placeholder; it is not submitted unless the operator types it.
A ticker that does not end with `Index` is rejected, so a bare root is not
resolved to another asset class. The UI must not call the chosen index a US
Treasury universe.
Use the documented fixed-income `spread(spread_type=...)` with the custom
`range(start, end)` and `net_chg()`. Do not add `fill`. Filter positive and
negative movers and rank each side to 10 in BQL. The candidate descriptors
are requested separately only for those ranked IDs, yielding per-field
diagnostics without downloading metadata for the full index. The bound is
`2 × TOP_N` (20) in a one-book run and `4 × TOP_N` (40) in the two-book
comparison, because `grouprank` caps each (book, direction) at `TOP_N`. It is
never produced by slicing the stacked frame: after the two books are
concatenated a positional cut keeps only the first book.

A bounded candidate-series request (at most the same ranked IDs) re-reads a fresh
dated spread item to expose the effective observation dates and check that the
ranked change equals the last value minus the first value in the returned
series. It is diagnostic only and never replaces the ranking request.

A descriptor cell has to say which of the two things happened. `(unavailable)`
means the field request failed, or the descriptor response did not cover that
ID at all; `(blank)` means Bloomberg returned an empty value for that bond.
Collapsing the two makes "we never asked" read as a bridge answer. The Rating
bucket follows the same rule: an absent or `(unavailable)` Rating bucket is
`(unavailable)`, never `NR/Missing`, because "the request failed" and "the
issuer has no letter grade" are different statements.

### Duration measures (2026-11-02)

Three extra duration columns are requested beside the existing `Duration`, and
all four measures come from a single builder. `Duration` is the bare
`bq.data.duration()`; the other three are parameter values on it:

| Output name | Call |
|---|---|
| Duration | `bq.data.duration()` |
| Modified Duration | `bq.data.duration(duration_type="MODIFIED")` |
| Effective Duration | `bq.data.duration(duration_type="EFFECTIVE")` |
| OASD | `bq.data.duration(duration_type="SPREAD")` |

Evidence is the FI Index Change build that completed on Desktop on 2026-11-02
(`28`, `08`): the value strings come from operator-supplied FLDS BQL tab text,
and the calls were accepted inside a live `Request` against `LEGATRUU Index`.
`22` has one `duration()` row and no `modified_duration()` /
`effective_duration()` item, so this is a parameter form, not a new item.

**The extra columns cost no additional request.** Every entry in
`config.DESCRIPTOR_FIELDS` is sent as its own one-item Request, and `Duration`
used to be one of them. Instead of adding three more descriptors (which would
have been three more `bq.execute` calls), `Duration` moved into a single
measure-family Request that now carries all four. The family **replaced** the
request that already existed, so a one-book Update still spends **10** requests
(2 rankings + 6 descriptors + 1 duration family + 1 series) and the comparison
still spends **12** — exactly what the app spent before the extra measures were
asked for. This is the `RAG KB/23` rule applied properly: appending a measure
costs a slot, merging into an existing request costs nothing.

**They ride on the bounded candidate universe**, at most `2 * TOP_N` IDs in a
one-book run and `4 * TOP_N` in the comparison, never the whole index, so this
family cannot re-create the width problem that hit FI Index Change, which
evaluates duration over the entire membership.

**One measure can fail without losing the others.** The four items share a
request, so a rejected `duration_type` drops that item and keeps the remaining
three; the missing one is named in the step log and its column stays absent.

**Display only.** No filter, chart, ranking or bucket reads these columns. A
failed family keeps the ranked rows, leaves the columns absent (never
zero-filled), and names itself in the step log.

Two failure modes are guarded. A family that returns a column with every value
null is recorded as `FAILED: all values null` when more than one row came back,
because "the field is broken" and "one bond has no duration" are different
findings; a single row (the Bond path) is noted without failing the run. And
because one builder with several parameter values can silently ignore the
parameter, the parsed columns are compared and a note names any pair that holds
identical values on every row that carries both.

Unresolved and not to be asserted: which measure the bare `duration()` returns
(if it is Modified then the existing `Duration` column and `Modified Duration`
are one number under two names), and whether `'SPREAD'` shifts the OAS curve or
the benchmark curve. Settle both by comparing columns on one Desktop batch,
never by probing a new data item. Do not add a fourth `duration_type` value
without new dated FLDS text.

This is a validation implementation, not proof of entitlement, units, or
field semantics. Review each field's exact FLDS BQL tab and Terminal output
before relying on results. The bounded series check proves the effective dates
and the change arithmetic, not the units. No field substitution, broader-universe
fallback, fill, or stale observation is allowed on error.

## User confirmation (2026-10-30)

On 2026-10-30 the operator asked for an Index field to the left of the Spread
dropdown. The field starts empty on every launch. `LEGATRUU Index` stays the
recorded example and is shown only as the placeholder. The request uses the
typed ticker and never substitutes the example when the field is blank. A
value that does not end with `Index` is refused before any request is built.

## User confirmation (2026-10-31)

On 2026-10-31 the operator asked for a Universe dropdown to the left of the
input, offering `Index` or `AIM account`, followed by the typed Index ticker or
AIM code. This app now spends the same OAS/Z/I ranking on either universe.

Index path (unchanged): `bq.univ.members(index, dates=end_date)`.

AIM path (frozen contract re-used from `25` § AIM request shape, not
re-derived here):

- `bq.univ.members(type="AIM")` is the expression.
- `accounts` is a list of **one** AIM code, together with `pxnum` and
  `profile="DEFAULT_PROFILE"`, on `bql.Request(..., with_params=...)`.
  Never on `members()`, never a bare string, never the whole book in one list,
  no dates, and no `ts_position()`.
- `AIM_PXNUM` in `config.py` defaults to the frozen `1377`; a non-empty value
  overrides it and is a request-shape change.
- `with_params` is attached to the two ranking requests only. Descriptor and
  series requests run on an explicit `bq.univ.list()` of the at-most-20
  candidate IDs, so an account block there would re-scope them to the whole
  book.

Fail-closed rules on the AIM path: a blank code, a code containing whitespace,
or an unknown source is refused before any request is built. An AIM code is not
an index ticker, so `INDEX_REQUIRED_SUFFIX` does not apply to it.

Ranking stays change-based on both paths: the AIM holding size never widens,
narrows, or re-weights the lists, and the book is not filtered by an unverified
security-type vocabulary. An AIM holding list can include cash and equity
lines; those return no spread and are excluded with a diagnostic. This is a
validation run, not proof of AIM entitlement, bond-universe completeness, units,
or field semantics.

## User confirmation (2026-11-01)

On 2026-11-01 the operator asked for three changes to this app: two more
universe sources, the page under a `Main` tab with the copy/paste tables under
`Export Excel`, and the CHART/control geometry of FI Index Change. The
decisions are DR-14, DR-15, and DR-16 in the project `DECISION_RECORD.md`.

`AIM vs Index` (DR-14) is a composition of the two request shapes already
frozen here and in `25`; it introduces no new BQL item:

- Both fields are required. A blank on either side is refused before any
  request, never a one-book run that reads as a comparison.
- Each book keeps its own universe, its own `with_params` (AIM only), and its
  own two change-ranked top-10 requests. The two books are never merged into one
  ranking and the AIM holding size never re-weights the index book.
- Descriptors, the duration measure family, and the bounded candidate series run
  **once** on the union of the two candidate lists: four ranking + six
  descriptor + one duration family + one series request per Update, spent
  sequentially (Desktop allows at most two concurrent workloads).
  The union is at most 40 IDs (10 ranked per book per direction, deduplicated),
  and it is built by deduplicating the stacked frames, not by keeping the first
  20 rows: the index book is concatenated first, so a positional cut would drop
  the entire AIM book before anything was asked about it.
- A bond can be an index member and an account holding at the same time, so in
  this mode the row identity is `(Universe, ID)`. Duplicate detection and the
  top-N cut are per book, and every ranked row carries `Universe`. Dropping a
  repeated `ID` as a "duplicate" is a defect.
- Comparison measures are pandas only: movers, increases, decreases, net and
  mean change, mean duration, widest change, and top bucket, one line per book.
  The comparison chart counts movers per bucket, one increase and one decrease
  series per book; signed sums stay in the table.
- A successful index ranking says nothing about AIM entitlement. The first
  comparison run must show the AIM side returning rows.

`Bond` (DR-15) spends `bq.univ.list([one_ticker])` on one typed security — the
`06` rule for a private literal universe, and the `02` § Project Practice Notes
shape `spread().value(bq.univ.list(bond))`. Exactly one security is sent: a
list separator (`,` `;` newline) or a value naming an index is refused rather
than split or widened. The same change ranking applies, so a one-row screen is
the expected shape for a bond that moved. No `fill`, no widening to the issuer
or the parent index, no substitute field when a price is blank.

Evidence status (2026-11-01, DR-18). Do not upgrade these two sentences:
`net_chg()`, `grouprank()`, and `groupsort()` are documented in this corpus only
on `members()` universes, and `07` has no signature row for `bq.univ.list`.
Both new sources therefore leave `23` `G4` (universe compatibility) **open** and
stay validation-only until a Desktop run returns rows on a `list` universe
(Bond) and on the AIM side next to an index book (`AIM vs Index`). No card in
`BUNDLE_EXAMPLES.md` composes two books side by side, and this section froze a
two-way choice before either source was added. A failure there is a
universe-compatibility finding, not something to patch with a fallback.

`Descriptor and series status` (DR-16): the per-field receipt
(`Country: returned 19 row(s) …`) is request metadata, not data, and it is no
longer a table at the top of the layout. It is recorded on the result and shown
in the `Export Excel` tab under `Request detail`; the step log keeps only a
`FAILED` field line, so a broken descriptor stays visible. Do not put the
success receipt back into the page body.

Layout (2026-11-01): the `Group by` dropdown sits at the far left of its own
row, and the five selection boxes (`Country`, `Sector`, `Tenor`, `Rating`,
`Currency`) sit beneath it with the FI Index Change geometry: `90px` label
width, `rows=10`, widths 300/300/220/220/220, an 8 px gap, and a chart width of
1,292 px (their total plus four gaps). Every chart uses that width, a
transparent paper and plot background, `#f5f5f5` title text, `#b8b8b8` axis
labels, `#3a3a3a` grid, `#9a9a9a` zero line, and a 140 px left margin. The bar
charts are 360 px tall; the path chart is the lower card at 300 px with a 40 px
top and 48 px bottom margin, as in FI Index Change, through
`charts._detail_layout`. Each figure is wrapped in a same-width `HBox` and its
layout carries the same fixed width with `autosize=False`.

Those hex values and heights are **not** frozen here: `28` states only
"transparent paper and plot backgrounds, light text and grid", and its width
arithmetic is for its own nine boxes. The concrete numbers were read from
`User scripts/FI Index Change/fi_index_change/` and match that app. Cite them as
code-side parity, not as a RAG-verified palette.

Tabs: `Main` holds the dashboard; `Export Excel` holds the copy/paste tables
(Top 10 increases, Top 10 decreases, Validation, Request log) and the request
receipt. Every export table repeats its column names as the first data row, the
same contract as FI Index Change. No file is written.

Two tabs are not a frozen shape: `28` records three tabs (Main, Export, Full
Position) for FI Index Change, and nothing in the corpus fixes the tab count for
this app. This pair is an operator instruction with no card behind it. It does
not conflict with `28` because `Export Excel` writes nothing — it only prepares
a copy/paste table — so a packaged App user's lack of filesystem access is
respected. The label promises a file it does not create; keep it only because
the operator asked for that name.

Display state, so a later "alignment" pass does not undo it (DR-19): the two
ranked export tables copy the **filtered** view on `Main`, while `Validation` and
the request log are copied whole; a one-book run carries no `Universe` column
because the book label only exists when two books were requested. A `Refused`
input or a failed Update clears the previous headline, charts, tables, and
comparison flag, and the per-field receipt survives in `Export Excel`. The status
words are `Idle`, `Loading`, `Updated`, `Please Click Update`, `Refused`,
`Incomplete`, and `Error`; `Refused` and `Incomplete` have no counterpart in FI
Index Change and are deliberate here, not drift. The internal source keys are
`index`, `aim`, `aim_vs_index`, and `bond` (UI labels are separate) — compare
them before comparing a log line.

Field order in the header row is also settled (DR-20): `Universe` first, then the
input(s) the chosen source reads, and in `AIM vs Index` the **AIM code comes
before the Index**. It is a layout order only — each box keeps its own field, so
the account and the ticker cannot be swapped by moving a box — and the AIM box is
validated first for the same reason, so with both boxes blank the refusal names
the left-hand one.

Local view contract, so a later change does not turn a filter into a request: a
filter, a grouping change, or a click on a row never builds a BQL request and
never moves the status bar to `Please Click Update`; only the Universe value, the
spread choice, or the dates do that, and putting them back on the loaded values
restores `Updated`.

## User confirmation (2026-11-02)

On 2026-11-02 the operator asked for four things: `Asset swap spread` as the
fourth spread choice, a second diverging chart that sums the spread change per
bucket, one full bucket table under the two charts, and a daily observation list
under the path chart. The decisions are DR-22 and DR-23 in the project
`DECISION_RECORD.md`.

**Superseded later on 2026-11-02:** the operator asked to remove
`Asset swap spread`, because a swap-curve measure makes the Desktop request too
heavy and would risk the two-minute timeout. DR-26 does that; the choice was
**not** part of the frozen contract and the dropdown is `OAS` / `Z` / `I` again.
Because a run sends exactly one spread type, this does not change a returned
frame — it removes the heaviest selectable measure, whose cost and entitlement
were never measured on this account. `data._validated_window()` resolves a label
through `config.SPREAD_TYPES` and then checks the mapped codes, so
`"Asset swap spread"` and `"ASW"` now raise instead of being sent; no substitute
measure was introduced, since none was asked for and a near-sounding item would
need the `23` review. The paragraph below is the history of the withdrawn
choice, kept so a later reader does not re-derive it as a live requirement.

`Asset swap spread` was a `spread_type` value, exactly as `28` records it:

- The call is `bq.data.spread(spread_type="ASW", dates=bq.func.range(start, end))`.
  It is the same item, the same parameters, and the same `net_chg()` as the
  frozen `OAS` / `Z` / `I` choices. No new data item, no new request shape, and
  still exactly one spread type per run.
- **Not resolved by this card, and moot while the choice is withdrawn:** whether
  `ASW` is entitled for the same IDs as `OAS` under this account, and whether
  its sign convention matches `OAS`. This knowledge base states neither. It
  becomes live again only if a new dated instruction restores the choice; then
  confirm both in Terminal on the same small ID set before relying on a ranking,
  and record the answer in the project `DECISION_RECORD.md`. Do not probe the
  field to discover entitlement.
- The UI therefore says `Increase` / `Decrease` and never claims a bps figure or
  a direction that the source has not been shown to support.

The two new surfaces are display arithmetic over rows already returned, so they
add no request:

- `Spread Change by <Group by>` is the signed sum of each bond's `Change` inside
  a bucket, in **source spread units**. Both charts cut to ten buckets with the
  remainder in `Others (n)`; `engine.bucket_table()` keeps every bucket.
- `Increase Spread + Decrease Spread = Net Change` is arithmetic on those same
  values. A bucket in `LEGATRUU Index` spans currencies, so the sum is **not**
  currency-neutral. The note under the table states that; the column names are
  the operator's own words and the UI must not call the sum a total in bps.
- The daily list is one row per date the window request returned, with the
  difference from the previous observation. A weekend, a holiday, or a no-quote
  day has **no row**; nothing is forward-filled, in line with the `fill` ban in
  `## Request and validation boundaries`.

The effective-date table retired on 2026-11-01 (DR-16) is not restored by this
change. The bounded series check still runs and still reports to the step log.

A `(blank)` cell is now offered as a filter option and forms its own clickable
bucket. `classification_name` returns nothing for much of the US MBS/TBA in a
global aggregate (`08` § Edge case), so dropping the blank would make those rows
unreachable and would let a Sector filter delete them silently. All three call
sites now share `config.DESCRIPTOR_BLANK`.

## User confirmation (2026-10-24)

On 2026-10-24 the user confirmed in chat that the 2026-10-23 selection above
is theirs: `LEGATRUU Index`, OAS/Z/I spread choices, custom start/end dates,
the six descriptors, and the validation-run scope. This is user-confirmed
evidence (`00` § 1), and it is not field approval: entitlement, units, and
field semantics remain unverified, and production use still requires the
FLDS/units/entitlement review plus a `23` decision record per field. The first
Desktop run is a validation run; the no-fill rule above and the per-field
review below still apply.

## Timeout protection (2026-11-02)

Desktop kills a query at two minutes, and this app cannot make Bloomberg answer
faster. Three measures keep a timeout from leaving an empty screen. **The error is
still reported**; these sit on top of it.

**Split.** Already true and unchanged: every `bq.execute` carries one item, except
the duration family which carries four. One book is 10 requests, `AIM vs Index` is
12. There is no wide request to split.

**Retry.** A timed-out request is re-sent **identical**, once
(`config.QUERY_ATTEMPTS = 2`), rebuilt per attempt. Nothing is dropped and no field
is substituted: the second attempt relies on a warmed Bloomberg-side cache. Only a
timeout is retried. `data.is_timeout()` tests the deterministic markers first
(`no bql data item`, `not entitled`, `invalid ticker`, `license`, `403`, …), so a
rejected item or a missing entitlement is reported at once instead of spending
another two minutes. Every request-log entry records `attempts`.

**Cache.** `cache.py` writes one clean run per key into `cache/` under the project
folder: three CSVs (ranked, descriptors, series) plus `manifest.json`. The key is
`run_key(source, universe, aim, spread, start, end, TOP_N)` with a
`CACHE_GENERATION` token, so a cached run can only answer the exact question that
produced it and a pipeline change invalidates every old file. `CACHE_KEEP_RUNS`
(12) runs are kept; the rest are pruned **by a recorded sequence, not by manifest
key order**, because the manifest is written sorted. An empty run, and a run with a
failed field, are **not** cached: replaying either would present `Incomplete` as a
clean cached answer.

**Fallback.** Only when the failure was a timeout **and** a clean run exists for
the same key. The status word is `Cached` in amber, never `Updated`; the reason and
the live error stay on screen and in the step log. A deterministic failure never
falls back, and a mixed set (a timeout plus a rejected item) counts as
deterministic. `Load saved` reads the same cache on request. A cached screen is
captioned from the request recorded in the manifest, never from the live widgets,
so an edit made during a run cannot relabel the data. A cache write that fails —
read-only folder, full disk — is logged and never fails a good Update.

## Minimum shippable package

- `config.py`: confirmed index, Top-N, spread choices, descriptor list, the
  four universe sources, the layout geometry, and the AIM `pxnum` / `profile`
  switch.
- `engine.py`: pure pandas validation and ordering of ranked responses, the
  two-book comparison summary, and the copy-to-Excel frame.
- `data.py`: BQL requests for the four universe sources, independent bounded
  descriptor validation, and the bounded retry of a timed-out request.
- `cache.py`: the result cache that the fallback reads. **Required**: `app.py`
  imports it at module load, so a Desktop copy without it fails the first
  notebook cell with `ModuleNotFoundError`.
- `app.py`: Update-only BQuant UI with the source dropdown, the `Main` /
  `Export Excel` tabs, visible status, ranked tables, and the cached fallback.
- `MAIN.ipynb`: thin import-and-display bootstrap; no startup BQL.
- `tests/`: synthetic calculation and fail-closed behavior checks.

First Desktop success requires successful spread ranking plus explicit
per-field validation statuses and review of the returned values. This is a
validation success, not production approval; production use requires the
FLDS/units/entitlement review. The AIM path additionally requires a Desktop
run that proves the account resolve and the bond-holding completeness; a
successful index run says nothing about AIM entitlement. Review a parser/cache
contract before adding a parser version or promoting an example to
`BUNDLE_EXAMPLES.md`.
