---
topic_id: "08"
title: BQL Data Item Semantics and Traps
role: semantics_authority
authority_for: [data_item_semantics, metadata, catalog_exceptions, mapping_traps]
not_authority_for: [entitlement_authorization, complete_api_signatures]
evidence_grades: [canonical, user-confirmed, practice-derived, catalog-only]
risk_tier: high_for_substitution
routing_keywords: [data_item, metadata, fundamentalticker, market_status, Thai, catalog_exception, bb_default_risk_obligor_ticker, cast_parent_equity_ticker, id_bb_company, short_name, 6166]
mandatory_cross_checks: [00-RAG-INDEX, 22-BQuant_DataItems, 23-bql-substitution-due-diligence, 25-etf-capping-monitor]
restricted_sections: [restricted_reference_archived]
source_families: [help_center, catalog, helpdesk, desktop_observation]
---

# BQL Data Items

> Curated BQL semantics, metadata, traps, Second Measure, and CDE. Exact 22,513-item mnemonic catalog: `22-BQuant_DataItems.md`.

> **Restricted-data hard stop (user-confirmed, 2026-08-31):** ESG, GHG,
> climate, and sustainable-finance data items are documentation-only in this
> workspace. Never execute or place them in user code; bulk extraction requires
> Premium entitlement and can trigger Bloomberg account suspension.

---

```mermaid
flowchart TD
  Q[Need a field?] --> S[Exact/description search in 22]
  S -->|One exact semantic match| C[Use 08 + domain recipe]
  S -->|Absent or multiple close meanings| F[Terminal FLDS / BQL tab]
  C --> P{Parameters or metadata uncertain?}
  P -->|Yes| F
  P -->|No| Code[Write bq.data.*]
  F --> Code
```

## Field Discovery (FLDS)

BQL supports a very large catalog of data items. **Never invent mnemonics.**

1. Search the exact mnemonic or business description in `22-BQuant_DataItems.md`.
2. An exact row confirms local catalog existence/spelling; use this file and the domain recipe for meaning and implementation.
3. If multiple descriptions are close, no exact row exists, or parameters/metadata/universe/entitlement remain uncertain, run Terminal `FLDS` → BQL tab.
4. The complete catalog covers `bq.data.*` items; it does not validate universe functions or other PyBQL APIs.

For any replacement, Excel/API migration, description-only search, mapping,
or unfamiliar product family, run `23-bql-substitution-due-diligence.md`
before accepting a candidate. A catalog description is not a substitute
decision.

## Dictionary Renaming & Metadata

```python
request = bql.Request(universe, {'OAS_Spread': bq.data.spread(spread_type='OAS')})
rating = bq.data.rating()
normalized = rating['NORMALIZED_SCALE']  # hidden metadata for ordering
```

## Bloomberg Second Measure (Consumer Transaction Metrics)

The captured semantics below do not establish entitlement or portfolio-wide
batch safety. New use is high risk and requires `23` plus current user
evidence.

**`observed_sales`**
- Path: `bql.Service.data.observed_sales`
- Syntax: `bq.data.observed_sales()`
- Behavior: Aggregated consumer transaction spend for covered companies (US consumer panel, debit/credit card).
- Related: `observed_transactions`, `average_transaction_value`, `observed_unique_customers`, `transactions_per_customer`, `sales_per_customer`

**`observed_transactions`**
- Syntax: `bq.data.observed_transactions()`
- Behavior: Aggregated consumer transaction count.

**`average_transaction_value`**
- Syntax: `bq.data.average_transaction_value()`
- Behavior: Aggregated average ticket (average value per transaction).

**`observed_unique_customers`**
- Syntax: `bq.data.observed_unique_customers()`
- Behavior: Aggregated unique customers transacting.

**`transactions_per_customer`**
- Syntax: `bq.data.transactions_per_customer()`
- Behavior: Transaction count per customer.

**`sales_per_customer`**
- Syntax: `bq.data.sales_per_customer()`
- Behavior: Spend per customer.

**`_cde` (Custom Data Extension)**
- Syntax: `bq.data._cde(mnemonic, *args, **kwargs)`
- Parameters: `mnemonic` (required); optional date/fill groups `(start, end, frq, fill)` or `(dates, fill)`.
- `frq`: `D,W,M,Q,S,Y` (default `D`); `fill`: `na, prev, next` (default `na`).
- Behavior: Returns custom CDE fields as a `bql.DataItem`.

## Production-Verified Fixed Income / Index Fields

> Verified in Bloomberg Terminal for global aggregate index rebalancing workflows (2026).

### `bq.data.id()['weights']` — Index Member Weight

- Syntax: `bq.data.id()['weights']`
- **Critical case rule**:
  - For index members via `bq.univ.members()` → key must be lowercase `'weights'`.
  - For fund/ETF holdings via `bq.univ.holdings()` → key is uppercase `'WEIGHTS'`.
  - Mixing these keys triggers `called without required column(s): value column`.

### `id_isin`

- Syntax: `bq.data.id_isin()['value']`
- Behavior: Bond ISIN. Chain `['value']` for returned/exported strings (otherwise nested metadata breaks joins); a bare accessor is acceptable only inside a filter predicate.

### `id_sedol1`

- Syntax: `bq.data.id_sedol1()['value']`
- Behavior: SEDOL 1 identifier.
- **Anti-hallucination**: Valid mnemonic is `id_sedol1` (with `1`). Do **not** use `id_sedol` — it raises `AttributeError: No BQL data item named 'id_sedol'`.

### `id_cusip`

- Syntax: `bq.data.id_cusip()['value']`
- Behavior: US fixed-income CUSIP. Chain `['value']` for a clean string.

### `crncy`

- Syntax: `bq.data.crncy()`
- Behavior: Pricing/settlement currency code (e.g., USD, EUR, JPY).

### `classification_name`

- Syntax: `bq.data.classification_name()`
- Behavior: Sector / classification name.
- **Edge case**: For large volumes of US MBS/TBA in global bond indices, this often returns `None`. When using Pandas `.str.contains()`, always pass `na=False`.

### `security_typ`

- Syntax: `bq.data.security_typ()`
- Behavior: Precise security type (e.g., `MBS 30yr`, `TBA`). Primary local filter for TBA/MBS roll noise isolation.

### `duration` with `duration_type` — Duration Measure Selector

- Syntax: `bq.data.duration()` or
  `bq.data.duration(duration_type=<TYPE>)`
- **Evidence grade:** user-confirmed on Desktop, 2026-11-02. The parameter and
  all three value strings were read from the FLDS BQL tab, then the calls
  completed inside a live Request against `LEGATRUU Index`. The bare `duration()`
  form is also tutorial-observed (`02` calls `duration()`,
  `duration(fill='prev')` and `duration(dates=...)`).
- Accepted values, as listed by FLDS:

| Value | Measure | Intent |
|---|---|---|
| `'MODIFIED'` | Modified duration | Sensitivity to a parallel shift of the benchmark curve |
| `'EFFECTIVE'` | Effective duration | Sensitivity allowing for embedded options' cash-flow changes |
| `'SPREAD'` | Spread duration (FLDS: "OAS Duration") | Sensitivity to a spread shift |

- **Why this form and not a separate item.** The catalog has no
  `modified_duration()` or `effective_duration()` entry — `22` lists one
  `duration()` row (`7701`) and nothing else for those two measures. The
  selectable-measure shape is the same as `spread(spread_type=...)` and
  `yield_(yield_type=...)`, and all three forms are confirmed by live calls, so
  one builder carrying several parameter values in a single Request is
  established behaviour rather than an assumption.
- **Four duration columns in one Request is confirmed, but they are four
  request slots.** If the intent is only to compare two measures, a bond that
  has no embedded option returns the same number for Modified, Effective and
  Spread; the columns are not free to compute.
- **Do not translate a "duration" label into an item name.** Substituting
  `mty_dur_mid()` (Macaulay), `duration_maturity()` (closed-form), or a
  `*_contrib()` row is a different measure and a different identity; see `23`.

> **Unresolved (2026-11-02), do not present as settled:** (a) which measure the
> bare `duration()` returns — nothing in this corpus states it, and if it is
> Modified then `duration()` and `duration_type='MODIFIED'` are the same number
> under two request names; (b) whether `'SPREAD'` is an OAS-curve shift or a
> benchmark-curve shift. FLDS calls it "OAS Duration" while naming the measure
> "Spread Duration"; the two coincide for a bond with no embedded option and
> diverge for MBS/TBA and callables. Decide both by comparing columns on one
> Desktop batch, never by probing a new data item.

## Common Equity / FI Quick Reference

| Function | Description |
|----------|-------------|
| `bq.data.name()` | Name |
| `bq.data.name_chinese_traditional()` | Company Name in Chinese Traditional (`22` exact). **Not** MDX Scan NameCN. Different identity (company vs official local-language security name). See `26` |
| `bq.data.official_trad_local_lang_sec_nm()` | Official Traditional Local Language Security Name (`22` exact). MDX Scan NameCN is this item on a **separate** members Request (`26`). Do not swap with `name_chinese_traditional()` |
| `bq.data.px_last()` | Last price |
| `bq.data.px_volume()` | Volume |
| `bq.data.pe_ratio()` | P/E |
| `bq.data.cur_mkt_cap()` | Market cap |
| `bq.data.spread(spread_type='OAS')` | OAS / spread |
| `bq.data.yield_()` | Yield |
| `bq.data.cpn()` | Coupon |
| `bq.data.maturity()` | Maturity date |
| `bq.data.rating()` | Rating (+ metadata columns) |
| `bq.data.cashflows()` | Bond cashflows |

## Tutorial-observed fields and universes (catalog/signature status)

> Observed in the 2026-07-24 Help Center HTML tutorials/examples. Exact-search data items in `22`; universe functions and unresolved signatures still require current API/FLDS confirmation.

| Area | Tutorial-observed symbols | Source context |
|------|---------------------------|----------------|
| Equity universe | `bq.univ.segments()` | Equity Company Analysis |
| Trading/portfolio universes | `bq.univ.books()`, `bq.univ.screenresults()` | TOMS / Securitized Products |
| Equity derivatives | `bq.data.vega()`, `bq.data.theta()` | Equity Derivatives |
| Equity capital allocation | `bq.data.cf_stock_based_compensation()`, `bq.data.net_debt_to_shrhldr_eqty()`, `bq.data.capex_to_depr_expn_ratio()` | Capital Allocation |
| Ownership contacts | `bq.data.fund_mgr()`, `bq.data.fund_phone()`, `bq.data.company_web_address()` | Peer Ownership Matrix |
| Primary markets | `bq.data.new_issue_compression()`, `bq.data.preliminary_security()` | Monitoring Primary/Secondary Markets |
| Securitized products | `bq.data.nxt_call_dt()` | Securitized Products |
| Municipal bonds | `bq.data.insurance_status()`, `bq.data.muni_fed_tax()`, `bq.data.offering_type()`, `bq.data.mty_typ()` | Muni New Issue Spreads |
| Fundamentals | `bq.data.is_sh_for_diluted_eps()` | Equities Tutorial |

### Tutorial-observed parameters requiring signature confirmation
- `holdings(..., type='13F')` versus older `filingsource='13F'` examples
- `spread(..., pricing_source='bgn')`
- AIM `members(..., type='AIM', ...)` account/pricing arguments (user has AIM Enterprise; BQuant remains Desktop; confirm the argument names, not the product entitlement)

## Catalog Exception Registry

Only the exceptions below may remain in canonical content without an exact `22` match. Official-source evidence proves that an alias was observed; it does **not** authorize production execution.

| Observed symbol | Canonical location | Closest `22` candidate | Required action |
|-----------------|--------------------|------------------------|-----------------|
| `headline_eps()` | `01` Equity Return Decomposition | `headline_eps_gaap()` | Do not assume equivalence; FLDS/API-confirm before running |
| `credit_rating()` | `02` / `12` Bond Sector Curve Analysis | `bond_rating()` | Confirm return scale and parameters before running |
| `wal()` | `02` BQL for Securitized Products | `mtg_wal()` / `mtge_wal()` | Ambiguous; FLDS-confirm the scenario-aware item |
| `job_openings()` | `21` announcement queue | No exact match | Confirm current mnemonic before use |

Blank Description is not semantics. Exact `22` row `short_name()` has an empty
description. That is spelling-only. Do not treat it as listing short name,
and do not substitute `ts_short_name()` or `index_short_name()`. ETF Monitor
Company-column use is Unresolved in `25` § Unresolved: Monitor Company.

Non-catalog namespaces/patterns:
- `bq.data._cde(...)` is a dynamic CDE API governed by `07`, not a catalog row.
- `cf_*` and `fund_*` are family wildcards in prose, not callable mnemonics.

## Canonical company-ticker mapping

> **canonical + user-confirmed Bloomberg HelpDesk (2026-08-31):**
> `bq.univ.fundamentalticker()` replaces both DT110
> (`FUNDAMENTAL_TICKER`) and DT679 (`ISSUER_EQUITY_TICKER`); HelpDesk
> confirmed that DT110 and DT679 return the same content for this use case.
> Never substitute an ESG/GHG field.

Apply the universe function as a value item to preserve the input-security row:

```python
fundamental_ticker = bq.data.id().value(
    bq.univ.fundamentalticker(),
    mapby="lineage",
)
request = bql.Request(
    securities,
    {"Fundamental Ticker": fundamental_ticker},
)
```

Direct universe transformation is also official:

```python
universe = bq.univ.fundamentalticker(securities)
```

Source provenance: Bloomberg HelpDesk response supplied by the user and the
official Fixed Income Company Analysis `func.value(..., mapby='lineage')`
example in the archived Help Center corpus.

Official 2026-09-01 BQL tabs confirm `cast_parent_equity_ticker()` and
`id_bb_company()` are core data items, not premium ESG. They are still the
wrong identity for this grouping: CAST returns a capital-structure parent
equity ticker, and `id_bb_company()` returns integer `ID035`. Do not replace
the HelpDesk `fundamentalticker()` lineage pattern with either field.

## Official CAST parent and Bloomberg company identifier

> **user-confirmed official BQL tabs (2026-09-01):** not premium. Entitlement
> to request the field is not permission to use it as a Thai local price or
> as the ETF Company Key.

### `cast_parent_equity_ticker()`

```text
bq.data.cast_parent_equity_ticker(mode=null)
```

Exact `22` row: `Capital Structure Parent Equity Ticker`. Official purpose:
equity ticker of the CAST parent (`ID146`, `CAST_PARENT_ID`). Default column
`value` is a string. `mode` matches the usual cached/realtime enum;
`'CACHED_ONLY'` and `'INTRADAY'` are currently unavailable.

Desktop incident evidence still applies: `DELTA/F TB Equity` resolved to a
Taiwanese parent, not the Thai local listing. Using that ticker as the
Pricing Ticker would value a Thai quantity at a foreign parent's price.

### `id_bb_company()`

```text
bq.data.id_bb_company(mode=null)
```

Exact `22` row: `Bloomberg Company Identifier`. Official purpose: persistent
unique identifier for the issuer or a subset of the issuer (`ID035`). Default
column `value` is an **integer**. Official examples: `AAPL US Equity` →
`101695`; `INDU Index` → `170310`; `members('INDU Index')` returns one
integer per member. Asset-class notes: MBS may not be unique; futures return
the series; warrants and DRs return the underlying; funds return the fund
not the family. Historical values are not available.

An integer company ID cannot be a yellow-key Pricing Ticker, cannot keep the
SK ticker Exception table, and is not the HelpDesk DT110/DT679 replacement.

## Market-status zero-price rule

> **user-confirmed Excel parity (2026-08-31):** PR286 `MARKET_STATUS` maps to
> catalog-confirmed `bq.data.market_status()`. Normalize both long and short
> outputs. User-confirmed official no-price kinds (2026-09-02): `DLST`/
> `Delisted`, `UNLS`/`Unlisted`, `PRNA`/`Price Not Available`, `PRIV`/
> `Private Company`, `INAC`/`Inactive`, `SUSP`/`Suspended`, `EXPD`/`Expired`,
> `PEND`/`Pending Listing`, `LIQU`/`Liquidated`, and `RCNA`/`Reason not
> available`.
> **Desktop 2026-09-02:** Request `with_params={'mode': 'cached'}` on
> `market_status()` returned stale `Delisted` for `6166 HK Equity`. The same
> item without cached, and the FLDS BQL tab for PR286, returned `Active`.
> Do not pass Request `mode=cached` on descriptor `market_status()` /
> `name()` fetches. Last Close `px_last` cached is a separate recipe.

Field semantics stop here. ETF monitor last-price, Last Close as-of date,
holiday `fill="prev"`, and sibling-weight zero fallback are owned by `25`
§ Last-price, Last Close, and zero fallback. Do not copy that recipe into
this file.

## Thai foreign-board local pricing safety

> **practice-derived + user-directed (2026-08-31, updated 2026-09-01):** keep
> the AIM position ticker and quantity for `*/F TB Equity` and
> `*-R TB Equity` (N-NDVR); change only the ticker used for price retrieval.

`bb_default_risk_obligor_ticker()` has an exact catalog row
(`Bloomberg Default Risk Obligor Ticker`) and a user-supplied official BQL
tab (IMG_6671, 2026-09-01):

```text
bq.data.bb_default_risk_obligor_ticker(mode=null)
```

Official `mode` values: `'CACHED'`, `'CACHED_ONLY'`, `'REALTIME'`,
`'INTRADAY'`, `'DEFAULT'`, `'STAGE_INTERNAL'`. `'CACHED_ONLY'` and
`'INTRADAY'` are currently unavailable. Default associated column is
`value` (string). `id` is not default output; add it with Request
`preferences` `addCols` if required.

Catalog spelling and the official tab are not listing semantics. Native
purpose is the equity ticker used to calculate default-risk measures of a
bond, corporate, or sovereign entity. On 2026-09-01 the user confirmed
Bloomberg HelpDesk evidence that this item is usable here as a leftover Thai
local-line pricing mapper only.

Desktop 2026-08-28 (IMG_6672) executed
`bq.data.bb_default_risk_obligor_ticker()` with Request
`with_params={'mode': 'cached'}` and returned string tickers that often omit
`Equity` (`NVDA US`, `017670 KS`), `None` for some equities, and retrieval
errors for cash/index. Production code must append ` Equity` when the suffix
is missing, and must never copy that probe's mixed NVDA/SKM/cash/index
universe. `any_prim_security_comp_exch()` was only a probe companion and is
not part of the Thai pricing path.

`cast_parent_equity_ticker()` and `id_bb_company()` have official BQL tabs
(2026-09-01) and are not premium, but they remain the wrong identity for
this pricing path: CAST is a parent equity ticker; `id_bb_company()` is
integer `ID035`. Do not request either as a Thai Pricing Ticker.

Use this fail-closed hierarchy:

1. Apply a reviewed static local-price override (`THAI_PRICING_RULES`).
2. Remove `/F` or `-R` deterministically to form a local candidate, then
   accept it only when the candidate ends in `TB Equity`, contains no `/F`,
   is not itself a `-R` line, returns `Name` or `Market Status`, and the
   input and candidate resolve to the same company-level fundamental ticker.
3. If strip validation fails, request
   `bb_default_risk_obligor_ticker()` only for those leftover Thai `/F` and
   `-R` AIM tickers. Never mix HK/US, already-local, or other markets into
   that request. Accept the value only after cleaning it to a local
   `TB Equity` with `Name` or `Market Status`.
4. If leftover mapping still fails, leave the price ticker unresolved, emit a
   diagnostic, and never silently use the foreign-line price.

`fundamentalticker()` is a company-level consolidation/validation value. The
corpus has no evidence that its output is the correct Thai local listing, so
never use the returned fundamental ticker itself as the Pricing Ticker. DRSK
output is pricing identity only; it must not replace the AIM ticker,
quantity, or company key.

Build a batched cache from original AIM tickers plus override/strip
candidates, then a second batched cache only for leftover DRSK locals that
were not already requested. Retrieve ordinary descriptors, `market_status()`,
and canonical fundamental mapping in batches, then perform selection locally
in Pandas.

Known non-mechanical symbol example supplied during design:
`CPNREI/F TB Equity` → `CPNREIT TB Equity`. A simple `/F` removal would
produce the wrong candidate.

**N-NDVR yellow key (user-confirmed, 2026-09-01):** N-NDVR AIM tickers end in
`-R TB Equity`. Strip to `XXX TB Equity` with the same validation as `/F`,
or use leftover HelpDesk DRSK if strip fails. Do not use the N-NDVR line's
own sparse price.

CAST parent/equity ticker and `id_bb_company()` remain rejected as Thai
local-price or Company Key substitutes. Mixed-universe DRSK then Pandas
filtering remains rejected.

The complete incident, rejected GHG/CAST/listings shortcuts, and
regression gates are in `24-etf-field-migration-incident.md`.

## What's New–observed API queue (2026-07-25 snapshot)

> Announcement evidence only. Exact mnemonic matches below confirm name existence, not signatures, parameters, entitlement, or return metadata.

| Area | What's New–observed symbols / parameters |
|------|-------------------------------------------|
| Real-time new issues | `latst_stats_for_most_recent_deal()` |
| Parent / issuer mapping | `parent(type='CAST')`, enhanced `fundamentalticker()` |
| Private credit | `ln_direct_lending()` |
| Restricted-data announcements | Historical only; execution prohibited |
| Repo / forward pricing | `repo_reporate()` |
| Labor economics | `jobless_claims()`, `job_hires()`, `job_vacancies()`, `job_openings()`, `job_separations()`, `job_applications()`, `job_advertisements()`, `underemployment()` |
| Commodities | `commodities()`, `curvemembers(curve_type='COMMODITY')` |
| Bond classification | `classification_name(classification_scheme='SBI')` |

Retired parameter: do not use `new_method_ltm_blending='N'`; the revised LTM methodology is mandatory.

### Cross-check against the complete catalog
- Exact unrestricted `22` matches include `latst_stats_for_most_recent_deal()`, `ln_direct_lending()`, `repo_reporate()`, the listed labor items, and `classification_name()`.
- No exact `22` match for `job_openings()`; confirm manually before use.
- `parent(...)`, `fundamentalticker()`, `commodities()`, and `curvemembers(...)` are non-data-item APIs/universe operations, so absence from `22` is not evidence that they are invalid.

## Restricted historical material

Executable ESG/GHG/climate/sustainable-finance examples were moved out of the canonical code-generation corpus. They remain available only as non-indexed provenance under `Restricted reference/` and `Raw source/`. Execution, probing, and testing are prohibited.
