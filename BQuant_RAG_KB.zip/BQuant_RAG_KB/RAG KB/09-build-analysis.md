---
topic_id: "09"
title: Build Analysis and Error Log
role: ui_app_authority
authority_for: [widgets, plotly, datagrid, app_lifecycle, desktop_error_patterns]
not_authority_for: [data_item_semantics, api_entitlement]
evidence_grades: [canonical, practice-derived, user-confirmed]
risk_tier: normal
routing_keywords: [ipywidgets, Plotly, DataGrid, app, lifecycle, error_log, infinite]
mandatory_cross_checks: [00-RAG-INDEX, 05-get-started, 18-using-pandas]
restricted_sections: []
source_families: [help_center, official_script, desktop_observation]
---

# Build Analysis — UI Templates & Error Log

> AI-oriented practice reference (Help Center chrome removed).

## AI quick map
- Interactive heatmap: Plotly `FigureWidget` + ipywidgets + BQL group/bins
- Always `with fig.batch_update()`
- Error log: ID-as-index, winsorize, setdiff, `id_sedol1`, ArrowExecuteResponse, KeyError `['DATE']`, `members` vs `member` vs Python-string universe
- Named Desktop apps: reconstruct BQL from project runtime `25` (ETF) or `26` (MDX), not from this Error Log. Vibe coding: one drop `config` → `data` → `engine` → `app` → `MAIN`. Do not start a Desktop trial loop for items already on that topic’s regression checklist.
- Production architecture: thin notebook, controller/view/model split, bind once, lazy detail, stable request lifecycle

```mermaid
flowchart TD
  UI[ipywidgets Dropdown/Button] --> CB[update_dashboard callback]
  CB --> BQL[bql.Request + group/bins/winsorize/avg]
  BQL --> PD[Pandas split/pivot]
  PD --> PL["FigureWidget.batch_update()"]
```

## Project Practice Notes: Interactive Heatmap Dashboard Template

> End-to-end pattern: BQL fetch → Pandas reshape → Plotly FigureWidget → ipywidgets callbacks.

```python
import bql
import pandas as pd
import ipywidgets as widgets
import plotly.graph_objects as go

bq = bql.Service()

# 1. Initialize visualization widgets (avoid empty-chart flicker)
heatmap = go.FigureWidget()
heatmap.add_trace(go.Heatmap(
    texttemplate='%{text}',
    colorscale=[(0, 'darkgreen'), (0.5, 'yellow'), (1, 'red')],
))
heatmap.update_layout(
    template='plotly_dark',
    width=600,
    height=500,
    margin=dict(t=40, l=5, b=5, r=5),
)

index_dropdown = widgets.Dropdown(options=['[INDEX_A]', '[INDEX_B]'], description='Index:')
measure_dropdown = widgets.Dropdown(options=['[MEASURE_A]', '[MEASURE_B]'], description='Measure:')
go_button = widgets.Button(description='Go', button_style='success')
spinner = widgets.HTML('<i class="fa fa-spinner fa-spin"></i>', layout={'visibility': 'hidden'})
err_label = widgets.Label()

# 2. Event-driven data flow (callback)
def update_dashboard(event=None):
    spinner.layout.visibility = 'visible'
    err_label.value = ''

    try:
        idx = index_dropdown.value
        msr = measure_dropdown.value

        universe = bq.univ.members(idx).filter(
            (bq.data.classification_name() != 'Government').and_(bq.data.is_perpetual() == 'N')
        )
        rating = bq.data.rating()
        binned_mty = bq.data.mty_years_tdy().bins([3, 7, 10], ['0-3', '3-7', '> 10'])

        measures_dict = {'[MEASURE_A]': bq.data.spread(spread_type='[TYPE_A]')}

        avg_measure = (
            measures_dict[msr]
            .group(by=[rating['BASE_RATING'], rating['NORMALIZED_SCALE'].replacena(99), binned_mty])
            .winsorize(lower_limit=-3, upper_limit=3)
            .avg()
        )

        request = bql.Request(universe, {f'Avg_{msr}': avg_measure})
        df = bq.execute(request)[0].df()

        # Composite index split + matrix reshape
        df[['rating', 'num_rating', 'bin']] = df.index.to_series().str.split(':', expand=True)
        df['num_rating'] = pd.to_numeric(df['num_rating'])

        pivoted = df.pivot(index='num_rating', columns='bin', values=f'Avg_{msr}')
        pivoted = pivoted[['0-3', '3-7', '> 10']]  # force X-axis order

        rating_map = df.set_index('num_rating')['rating'].drop_duplicates()
        pivoted.index = pivoted.index.map(rating_map)

        df_clean = pivoted.round(2).fillna("")

        # Batch-update chart (single redraw)
        with heatmap.batch_update():
            heatmap.data[0].x = df_clean.columns
            heatmap.data[0].y = df_clean.index
            heatmap.data[0].z = df_clean.values
            heatmap.data[0].text = df_clean.values
            heatmap.layout.title = f'{msr} for {idx}'
            heatmap.update_yaxes(autorange='reversed')

    except Exception as e:
        err_label.value = f'Error: {e}'
    finally:
        spinner.layout.visibility = 'hidden'

# 3. Bind events and render UI
go_button.on_click(update_dashboard)
ui_display = widgets.VBox([
    index_dropdown,
    measure_dropdown,
    widgets.HBox([go_button, spinner, err_label]),
    heatmap,
])

update_dashboard()  # preload on start
ui_display
```

## Project Practice Notes: Error Log & Pitfalls

### BQL Data Handling

| Symptom | Cause | Fix |
|---------|-------|-----|
| `KeyError` on `df['ID']` | Leftmost `ID` is the DataFrame **Index**, not a column | Use `df.index` |
| Pivot/sort breaks on unrated bonds | Rating returns `NaN` | Chain `.replacena(99)` in BQL so unrated sorts last |
| Winsorize/avg ineffective or errors | Wrong chain order | Strict order: `.group(by=...)` → `.winsorize(...)` → `.avg()` |

### Pandas / Plotly Visualization

| Symptom | Cause | Fix |
|---------|-------|-----|
| Bin labels like `10-20` appear before `3-7` | Default string sort | After pivot: `pivoted = pivoted[['0-3', '3-7', '10-20']]` |
| AAA rating at bottom of heatmap | Plotly Y-axis draws bottom-up | `heatmap.update_yaxes(autorange='reversed')` |

### JupyterLab / UI Interactivity

| Symptom | Cause | Fix |
|---------|-------|-----|
| Chart flickers on every callback update | Setting `fig.data[0].x = ...` line-by-line | Use `with fig.batch_update():` for one redraw |
| Kernel remains `Connecting…` | WebSockets/network path unavailable | Run Network Diagnostics; then verify/restart the kernel/workload (`05`) |
| BQL request times out | Desktop 2-minute limit / request too broad | Narrow or split request; use `with_params={'mode': 'cached'}` where supported (`05`) |
| BQL returns 403 | Terminal/BBA session disconnected or changed | Reconnect the Bloomberg session before modifying query logic (`05`) |
| File Save Error | Project file exceeds 256 MB or generated output is oversized | Remove output; use `/tmp` for temporary data (`05`) |
| Replaced `.py` but log still shows the old `PARSER_VERSION` | Kernel cached the previous `import` | **Restart Kernel**, then Run All. Print `PARSER_VERSION` on every refresh |
| Auto Play fires every second / never at 15 min | `widgets.Play.interval` is milliseconds | `15 min` = `900000` |
| Header/log shows only `['DATE']` | `str(KeyError(['DATE']))`; parser dropped the DATE column | Keep `ID`+`DATE`+value (`18`). Do not assume the UI title widget is the bug |
| Log prints `ArrowExecuteResponse` as a Request note; members never load | Success treated as failure because the object is not iterable | Type-name contains `response` → valid (`07`). Do not require `__iter__` |
| `No BQL universe handler named 'member'` | Typo `bq.univ.member` (missing **s**) | Restore `bq.univ.members('HSI Index')` (`01`) |
| `Unable to parse request at '(['members('HSI'` | Python string `"members('HSI Index')"` was treated as a ticker ID (`07`: `str` = security) | Never pass a BQL snippet as `str`. Use `bq.univ.members(...)` |
| `NameError: name '_member_univ' is not defined` | Helper not copied, or `members`/`member` renamed inconsistently | Do not invent universe helpers. Call `bq.univ.members(ticker)` at the `Request` site |
| Green mark on Projects list while idle | Project **workload** is open (`05`) | Not `load_on_start`. Shut down the workload / close the project. Max 2 running; idle 10 min or 24 h cap |
| Cursor visual-diff line numbers do not match BQuant | Local file was Black-wrapped / re-quoted | Overwrite local to the BQuant screenshot, then patch; user hand-copies by line number |
| `AttributeError: module 'numpy' has no attribute 'infinite'` | Hand-copy wrote `np.infinite` (token does not exist). Correct name is `np.isfinite`; Preview/PDF copy is a hazard | In copied files prefer `replace([np.inf, -np.inf], np.nan)`. ETF engine recipe: `25` |
| Legend shows `PCTB` / `VS` / `DD60` with **blank** definitions; SIGNAL text is fine | Nested grey `<span>` after the key did not paint on Desktop; `{color}` leftover from a prior SIGNAL loop is a hand-copy hazard | One HTML node per row (`<b>PCTB</b>&nbsp;&nbsp;definition`). Dedicated `widgets.HTML` for column notes. Do not reuse `{color}` from the SIGNAL loop |
| Legend under the member grid is clipped after data loads | Fixed-height `DataGrid` (~520px) in an `HBox(align_items='stretch')` sized by the Plotly chart | Put legends in the parent `VBox` **after** the table+chart `HBox`. If the three keys are already visible, this is not the blank-definition bug |

### Desktop ArrowExecuteResponse / DATE column (Observed 2026-08-27)

**Evidence:** practice-derived, user-verified on BQuant Desktop (MDX Scan). Not an Official Tutorial signature.

BQuant Desktop `bq.execute` / `bq.execute_many` can return `bql.refactor.response.arrow_execute_response.ArrowExecuteResponse`.

- It is a **successful** response. It often has no `__iter__`.
- `list(response)` raises `TypeError`; a naive `_is_response` that requires iteration then dumps `str(response)` into the app error log ("Request note: ArrowExecuteResponse"). Downstream frames stay empty.
- Accept it when `type(obj).__name__` contains `response` (and `obj` is not a `tuple`/`Exception`/`DataFrame`). Extract with `len`/`response[i]`, `response.get(name)`, then `bql.combined_df` as fallback (`07`).
- `execute_many(..., on_request_error=callback)` **includes** callback results in the same list as successes. Distinguish error tuples from Response objects before parsing.

On Arrow timeseries, `item.df()` often already has `DATE` as a **column**. Slicing `frame[[item.name]]` (the official-script value-only concat) drops it. A later `dropna(subset=['ID', 'DATE', 'Close'])` raises `KeyError: ['DATE']`. An app that does `self.title.value = header('Error', extra=str(exc))` then shows exactly `['DATE']`. Fix in the parser (`18`), not in the title widget.

After any `.py` paste onto BQuant: Restart Kernel then Run All. Ship a `PARSER_VERSION` canary in the refresh log so a stale import is obvious.

### Desktop index members Request (Observed 2026-08-27, corrected)

**Evidence:** practice-derived, user-verified on BQuant Desktop (MDX Scan). Canonical object API is `01` / `07`.

Correct universe (Hang Seng constituents; `HSI_INDEX = 'HSI Index'` is the same yellow key):

```python
meta_request = bql.Request(
    bq.univ.members('HSI Index'),
    {
        'Name': bq.data.name(),
        'Sector': bq.data.classification_name(),
        'Weight': bq.data.id()['weights'],  # members: lowercase
    },
    with_params={'mode': 'cached'},
)
```

Optional Traditional Chinese **listing** names for MDX Scan are owned by
`26` § Member metadata and NameCN. The deployed item is
`official_trad_local_lang_sec_nm()`, fetched on a **second**
`bq.univ.members(...)` Request and merged on `ID`. Do not paste
`name_chinese_traditional()` here; that catalog row is company name, not
the MDX NameCN field.

Do **not**:

| Wrong | What Desktop does |
|-------|-------------------|
| `bq.univ.member('HSI Index')` | `No BQL universe handler named 'member'` |
| `bql.Request("members('HSI Index')", items)` | `str` is a security ID → `Unable to parse request at '(['members('HSI'` |
| A helper `_member_univ` / `_members_univ` copied on only one side | `NameError: name '_member_univ' is not defined` |

`MAIN.ipynb` `app.load_on_start()` runs **one** BQL refresh. It does not keep the project running. The Projects-page green mark is the Jupyter **workload** (`05`: 2 concurrent; idle 10 minutes; max 24 hours).

UI-only changes (signal legends, `PCTB`/`VS`/`DD60` notes, HKT clock, index point change) never cause these BQL parse errors.

### Desktop widgets.HTML legend (Observed 2026-08-28)

**Evidence:** practice-derived, user-verified on BQuant Desktop (MDX Scan). Not an Official Tutorial signature.

`widgets.HTML` on Desktop can show a **key without its definition** when the definition lives in a second `<span>`. MDX Scan SIGNAL rows (color chosen **inside** the loop, then key span + grey text span) painted both parts. COLUMNS rows used the same two-span shape for `PCTB` / `VS` / `DD60`; the three keys appeared and the definitions did not. Putting explanations in `config.py` / `METRIC_LEGEND` does not help if that second span is empty on screen.

Do **not**:

| Wrong | What Desktop does |
|-------|-------------------|
| `<span>PCTB</span><span style="color:#8b93a7;">{text}</span>` | Keys visible; definition span can be blank |
| Reuse `{color}` from the SIGNAL loop in a later METRIC f-string | Last SIGNAL color (`(blank)` → `#8b93a7`); easy to omit `{text}` while hand-copying |
| Treat blank COLUMNS text as DataGrid clipping **when the three keys are already visible** | Clipping hides the whole block, not only the words after the key |
| Put the legend `HTML` under a `DataGrid` with `layout height ~520px` inside `HBox(align_items='stretch')` | Left column is capped by the chart (~500px); widgets below the grid are clipped after data loads |

Do:

```python
# One text node per row. Separate widget, full width, after the table+chart HBox.
html = (
    '<div style="font-size:12px;line-height:1.5;color:#c5c8d0;">'
    '<b style="color:#7aa2f7;">PCTB</b>'
    '&nbsp;&nbsp;Band position: 0 at lower DN, 1 at upper UP</div>'
)
column_legend = widgets.HTML(
    value=html,
    layout=widgets.Layout(width='100%', overflow='visible'),
)
# VBox: [..., body_hbox, column_legend, signal_legend, log, footer]
```

Empty-grid screenshots can still show a legend that later disappears: that is the stretch/clip layout, not the two-span paint bug.

### Global Bond Index Tracking (Observed 2026)

**`ResponseError: Function ID().WEIGHTS called without required column(s): value column.`**

- Cause A: `universe.setdiff()` strips hidden member metadata (including weights) on the server.
- Cause B: Early in a new month, `with_params={'mode': 'cached'}` may not yet contain the prior month-end official weights.
- Fix: Prefer local Pandas `isin()` set ops. For cause B, backdate one more month for historical tests, or drop `cached` (large country-level universes may then time out).

**`SyntaxError: invalid syntax` on request params**

- Cause: Invalid dict syntax such as `with_params='mode': 'cached'`.
- Fix: `with_params={'mode': 'cached'}`.

**`AttributeError: No BQL data item named 'id_sedol'`**

- Cause: Invented mnemonic. Verified field is `id_sedol1` (with trailing `1`).
- Fix: Exact-search `22` first (`id_sedol1()` exists; `id_sedol()` does not); use FLDS only if semantics/signature remain unresolved.

---

## Production App Architecture from Official Scripts

Repeated across the 2026-08-26 EQUITY/CREDIT script ingest: *Bespoke Factor Analysis*, *Index Performance Drivers*, *Bond Ownership Dashboard*, *Bond Curves Comparison*, *Asset-backed Security Analysis*, and the technical monitors.

### Thin notebook, importable application

For a multi-view app, keep the notebook as a bootstrapper:

```text
MAIN.ipynb
  -> add project root to sys.path
  -> import AppController
  -> app = AppController()
  -> display(app.render())

controllers/
  app_controller.py      dependency wiring, defaults, tab composition
  error_log.py           shared status/log helpers
views/
  chart_tab.py           widgets + callbacks + rendering
  summary_tab.py
models/
  engine.py              BQL orchestration + analytics
data/
  field_library.py       verified field/category mappings
```

This separation is **practice-derived**. Exact BQL fields remain in the routed domain file (`01` or `02`) and must pass the field/signature gate.

### State ownership contract

- The controller owns shared configuration and creates each tab once.
- Each tab owns its widgets, output container, and log widget.
- The model/engine returns DataFrames or typed results; it does not call `display`.
- Views do not build ad-hoc BQL fields from arbitrary text. They select from a verified field registry.
- Callback code reads widget state at execution time; avoid stale module-level globals.
- After replacing application `.py` files on BQuant, Restart Kernel then Run All; `import` is cached (`09` Error Log).

```python
class AppController:
    def __init__(self, service, field_registry):
        self.chart_log = create_log_widget()
        self.summary_log = create_log_widget()
        self.chart_tab = ChartTab(service, field_registry, self.chart_log)
        self.summary_tab = SummaryTab(
            service,
            field_registry,
            self.summary_log,
        )

    def render(self):
        tabs = widgets.Tab(children=[
            self.chart_tab.render(),
            self.summary_tab.render(),
        ])
        tabs.set_title(0, 'Chart')
        tabs.set_title(1, 'Summary')
        return tabs
```

### Bind observers exactly once

Repeated `Run` calls must not register additional observers.

```python
class Dashboard:
    def __init__(self):
        self._events_bound = False
        self.run_button = widgets.Button(description='Run')
        self.universe = widgets.Dropdown(options=[])
        self.output = widgets.Output()
        self._bind_events()

    def _bind_events(self):
        if self._events_bound:
            return
        self.run_button.on_click(self._run)
        self.universe.observe(self._on_universe_change, names='value')
        self._events_bound = True
```

For lambdas created in loops, freeze the current value:

```python
for field in fields:
    button.on_click(lambda event, field=field: remove_field(field))
```

Prefer `functools.partial` when the callback has several bound arguments.

When one callback must correct another widget's value, prevent recursive updates:

```python
def set_date_without_recursion(widget, value, handler):
    widget.unobserve(handler, names='value')
    try:
        widget.value = value
    finally:
        widget.observe(handler, names='value')
```

For coupled date pickers, a small re-entry flag is also valid:

```python
if self._fixing_dates:
    return
self._fixing_dates = True
try:
    fix_date_range()
finally:
    self._fixing_dates = False
```

### Lazy-load expensive tabs and drill-downs

Official CREDIT applications repeatedly use a two-level request design:

```text
render placeholders and disabled data controls
-> explicit Run loads a bounded summary universe
-> enable controls
-> row/cell selection loads one security/fund detail
-> trace-only updates do not rerun the summary request
```

Use this for bond holders, fund look-through, securitized scenarios, issuer curves, and large equity monitors. It reduces Desktop timeout risk and prevents unnecessary downloads.

```python
def on_row_selected(change):
    row = selected_row(change)
    if row is None:
        detail_box.children = [empty_state('Select a row')]
        return
    detail_box.children = [spinner]
    try:
        detail = engine.fetch_detail(row['ID'])
        detail_box.children = [build_detail_grid(detail)]
    except Exception as exc:
        detail_box.children = [error_state(str(exc))]
```

### Stable request lifecycle

Every long callback should expose the same states:

```python
def run(_):
    run_button.disabled = True
    status.value = 'Loading...'
    with output:
        clear_output(wait=True)
        try:
            result = engine.run(progress_callback=update_progress)
            render_result(result)
            status.value = 'Completed'
        except Exception as exc:
            status.value = f'Error: {exc}'
        finally:
            run_button.disabled = False
```

Do not swallow request failures and then render an empty chart as success. Distinguish:

- no rows matched;
- detail unavailable;
- partial request failures;
- entitlement/signature failure;
- timeout / request too broad.

### Update figures in place

Create expensive `FigureWidget`s once and update all properties inside one batch:

```python
with figure.batch_update():
    trace.x = frame.index
    trace.y = frame['Value']
    figure.layout.title = title
```

Heatmap/grid click handlers should update only the drill-down view. Rebuilding the whole `VBox` on each click loses selection state and may duplicate callbacks.

### Widget compatibility checks

The official scripts include older and newer widget idioms. On Desktop JupyterLab 4.3.6 / ipywidgets v8:

- validate `observe(..., names='value')` payloads;
- validate `FileUpload.value` shape before reading;
- avoid mutating tuple-valued `children` in place;
- test DataGrid selection payloads and renderer expressions;
- run the notebook from a fresh kernel to catch hidden cell-order state.

---

## Help Center UI Patterns

Recurring dashboard idioms from unrestricted Help Center examples.

> UI layout techniques may be reused, but the Portfolio ESG example's data
> items are **REFERENCE ONLY** and prohibited from execution in this workspace.

| Pattern | Example | Widget stack |
|---------|---------|--------------|
| Rating × maturity heatmap | Credit Spread Heatmap | `FigureWidget(go.Heatmap)` + `batch_update()` on z/x/y/text; `autorange='reversed'` on Y for ratings |
| Portfolio theme heatmap | Generic portfolio heatmap | MultiIndex columns from pipe-delimited labels; `ipd.DataGrid` conditional color formatting |
| Pivot HTML dashboard | Tariffs Dashboard | `ipywidgets` axis dropdowns → Pandas pivot → `df.style.background_gradient().to_html()` in `widgets.HTML` |
| Hierarchical treemap | Equity Market Performance Treemap | `px.treemap` → `go.FigureWidget`; nested `aggregate_df` by GICS levels; `centered_color_scale()` for ±returns |

### Representative `FigureWidget` + `batch_update` (Credit Spread Heatmap)

```python
def update_heatmap(df, universe_name, measure_name):
    df = df.round(2).fillna('')
    with heatmap.batch_update():
        heatmap.data[0].x = df.columns
        heatmap.data[0].y = df.index
        heatmap.data[0].z = df
        heatmap.data[0].text = df
        heatmap.layout.title = f'Average {measure_name} for {universe_name}'
    heatmap.update_yaxes(autorange='reversed')
```

BQL chain in that example: `.group(by=[rating base, rating normalized, maturity bin]).winsorize(...).avg()` — strict order per project rules.

## Build Analysis Official: Coding Workspace

> Canonical JupyterLab, Python environment, package, and project guidance lives in `05-get-started.md`. This file keeps only UI/visualization/interactivity recipes.


## BQuant Assistant cross-reference

> Canonical Assistant limitations and prompting guidance live in `10-bquant-research.md`. Still obey Desktop-only, locked-stack, and FLDS anti-hallucination rules.


## Build Analysis Official: Portfolio Library

> Full Portfolio Library recipes live in `14-bql-for-port-prep.md` (Desktop limits still apply).

## Build Analysis Official: Event Studies API

> **Beta library.** Help Center warns: may change; no support/bug fixes; **do not use in production code**. Prefer classic BQL+Pandas event windows unless user explicitly requests Event Studies.

### Event Studies API Reference
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Package surface includes EventStudy / Events / Event / TimeSeries / Analytics / Aggregations / Filters / MarketProxies / Visualizations / Windows.
- **Topics:** Overview; Creating an event study; Managing underlying event study data; Calculating analytics; Filtering event study data; Aggregating time series data across multiple events; Visualizing your event study analysis
- **Key points:**
  - Creating an event study
  - Managing underlying event study data
  - Calculating analytics
  - Filtering event study data
  - Aggregating time series data across multiple events
  - Visualizing your event study analysis
  - Calculate analytics for the event study
  - Filter the underlying data to drill down into specific subsets

### EventStudy workflow (beta reference only)

```mermaid
flowchart LR
  E[Events] --> ES[EventStudy]
  T[TimeSeries] --> ES
  ES --> F[apply_filters]
  F --> A[run_analytics]
  A --> G[run_aggregation]
  G --> V[visualize]
  ES --> C[get_combined_time_series]
```

| API family | Tutorial-observed symbols |
|------------|---------------------------|
| Event orchestration | `EventStudy`, `apply_filters`, `get_combined_time_series`, `run_analytics`, `run_aggregation`, `visualize` |
| Relative time / windows | `RelativeTime`, `RelativeBusinessDays`, `SymmetricWindow`, `AsymmetricWindow` |
| Analytics | `Returns`, `CumulativeReturns`, `BetaAdjustedReturns`, `ZScore` |
| Aggregation | `ReturnsAggregation` |
| Filters / proxies | `ColumnFilter`, `SingleMarketProxy` |
| Visualization | `ReturnsAggChart` |

All symbols above are beta and version-sensitive. Confirm the installed API before use; prefer a BQL + Pandas event-window implementation for production.

## Build Analysis Official: Visualizations & IPyDataGrid

Official Desktop tutorials for Plotly visualizations and `ipydatagrid` tables.

```mermaid
flowchart LR
  P[Plotly charts] --> G[Gallery patterns]
  D[DataGrid] --> H[Headers]
  H --> F[Text / conditional format]
  F --> I[Grid interactivity]
```

### Building Visualizations
- Building interactive visualizations with Jupyter Widgets
- **BQViz is deprecated.** Migrate BQViz wrappers to Plotly + ipywidgets; do not generate new `bqviz` code.
- **Topics:** Overview; Using Plotly; Plotly Express vs. Graph Objects; Basic Plotly workflow; Displaying tabular data with IPyDataGrid; Building interactive visualizations with Jupyter Widgets; Migrating from BQViz to Jupyter Widgets; Example: Migrating an Interactive Line Plot
- **Key points:**
  - Using Plotly Plotly Express vs. Graph Objects
  - Basic Plotly workflow
  - Displaying tabular data with IPyDataGrid
  - Building interactive visualizations with Jupyter Widgets
  - Migrating from BQViz to Jupyter Widgets Example: Migrating an Interactive Line Plot
  - Example: Migrating an Interactive Scatter Plot
  - Build and execute a BQL request.

```python
import ipywidgets as widgets
import pandas as pd
import plotly.graph_objects as go
import bql

# Build and execute request for last 30 days of AAPL price
request = bql.Request("AAPL US Equity", {
    "Price": bq.data.px_last(dates=bq.func.range("-30D", "0D"), fill="prev")
})
df = bq.execute(request)[0].df().reset_index()

# Create FigureWidget with scatter plot
fig = go.FigureWidget()
fig.add_scatter(x=df["DATE"], y=df["Price"])
fig.update_layout(template="plotly_dark", title="AAPL Price")

# Create sliders for axis bounds
lower_slider = widgets.IntSlider(
    value=0,
    min=0,
    max=len(df)-2,
    step=1,
    description="Start"
)
upper_slider = widgets.IntSlider(
    value=len(df)-1,
    min=1,
    max=len(df)-1,
    step=1,
    description="End"
)

def update_xaxis(*_):
    """Updates x-axis range when slider values change."""

    lo, hi = lower_slider.value, upper_slider.value
    if lo >= hi:
        return
    x0, x1 = df["DATE"].iloc[lo], df["DATE"].iloc[hi]
    fig.update_xaxes(range=[x0, x1])

# Bind sliders to update handler
lower_slider.observe(update_xaxis, names="value")
upper_slider.observe(update_xaxis, names="value")
update_xaxis()

widgets.VBox([fig, lower_slider, upper_slider])
```

### Visualization Gallery
- Official gallery coverage: bar-plus-line, time series, box plot, histogram, horizontal bar, scatter, IPyDataGrid `BarRenderer`, and conditional formatting.
- Project implementation rule: use Plotly for charts and `ipydatagrid` for tables. Do not copy gallery examples that require libraries outside the locked project stack.
- For linked chart/grid callbacks, use `FigureWidget`, `with fig.batch_update():`, and `functools.partial` patterns below.

### Showcase: Adding Interactivity to an IPyDataGrid
- This notebook demonstrates how to edit, filter, and sort an IPyDataGrid, as well as trigger events based on grid interactions and changes.
- **Topics:** Open an interactive version; Setting up your environment¶; Overwriting cell values¶; Filtering and sorting using transform()¶; Filtering by index¶; Filtering and sorting with multiple columns¶; Triggering events based on grid interactions and changes¶; BQL data example¶
- **Key points:**
  - Visualization Gallery
  - Overwriting cell values
  - Filtering and sorting using transform() Filtering by index
  - Filtering and sorting with multiple columns
  - Triggering events based on grid interactions and changes BQL data example
  - Filters the grid on the 0 columnIndex (the index) to only show rows that have the strings 'some', 'demonstration', or 'data' in the index.
  - Filters on the 2 columnIndex (column 'B') to only show rows with values above 0.01 in that column.

#### Grid event registration
- `on_cell_click(callback)` — respond to a selected cell/row.
- `on_cell_change(callback)` — respond after editable cell data changes.
- `observe(callback, names=...)` — watch widget traits such as selections; verify the trait name in the installed version.
- Programmatic overwrite uses the DataGrid/data model interface from the installed `ipydatagrid` version; do not mutate a detached source DataFrame and assume the grid refreshes automatically.

```python
# Set up your environment
import ipydatagrid as ipd
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import ipywidgets as widgets

import bql

# Connect to the BQL service
bq = bql.Service()

# Create sample DataFrame
df = pd.DataFrame(
    {
        'A': np.random.default_rng(0).integers(-100, 100, size=5), 
        'B': np.random.default_rng(1).integers(-100, 100, size=5) / 1000,
        'C': pd.date_range('2020-01-01', '2020-01-05'),
        'D': np.random.default_rng(0).integers(100000, 10000000, size=5),
        'E': [1, np.nan, 3, 4, np.nan]
    }, 
    index=pd.Index(
        ['this', 'is', 'some', 'demonstration', 'data'],
        name='Demo'
    )
)
```

```python
grid2 = ipd.DataGrid(
    dataframe=df,
    base_column_size=80,
    base_row_header_size=100,
    layout={'width': '540px', 'height': '130px'}
)

grid2.transform(
    [
        {
            "type": "filter",
            "operator": "in",
            "columnIndex": 0,
            "value": ["some", "demonstration", "data"],
        },
        {
            "type": "filter",
            "operator": ">",
            "columnIndex": 2,
            "value": 0.01,            
        },
        {
            "type": "sort",
            "columnIndex": 5,   
            "desc": True
        }
    ]
)

grid2
```

### Sample Notebook: Knock In/Knock Out Barrier Visualizer
- UI composition excerpt for a multi-security barrier visualizer: tabbed security views, per-tab controls, Plotly updates, and callback-bound tab titles.
- **Scope:** The retained excerpt documents widget composition only; it is not a complete barrier-pricing implementation.

```python
class AllSecurityTabs(widgets.Tab):
    """
    Tabbed container for multiple security tabs, with each security tab
    containing a plot and controls.
    """

    def __init__(self, tickers, lookback, level_type, level_control_specs):
        """
        Initialize the tabbed security container.
        """
        
        # Build one security tab for each supplied ticker
        self.tabs = [
            SecurityTab(
                ticker,
                lookback,
                level_type,
                level_control_specs,
                partial(self._update_title, tab_num),
            )
            for tab_num, ticker in enumerate(tickers)
        ]

        super().__init__(children=self.tabs, titles=tickers)

    def _update_title(self, tab_num, name):
        """
        Updates the title for a single tab.
        """
        self.set_title(tab_num, name)
```

```python
# Set up your environment
from functools import partial

import ipywidgets as widgets
import pandas as pd

import bql
```

### Showcase: Formatting an IPyDataGrid Based on Conditions
- This notebook demonstrates how to format an IPyDataGrid based on defined conditions.
- **Topics:** Open an interactive version; Overview¶; Setting up your environment¶; Formatting using a Python function¶; Formatting using a Vega expression¶; Formatting using a color scale¶; Creating a conditional bar using scales¶; Hiding NaN values using a Vega expression¶
- **Key points:**
  - Visualization Gallery
  - Setting up your environment
  - Formatting using a Python function
  - Formatting using a Vega expression
  - Formatting using a color scale
  - Creating a cell bar using scales
  - Hiding NaNs using a Vega expression

#### Conditional-format modes
- Python renderer function: simple readable logic.
- Vega expression through the installed `ipydatagrid` interface: front-end conditional formatting and NaN handling.
- Color scale: map a numeric domain to text/background colors.
- Cell bar renderer: compact magnitude visualization inside a table cell.

Prefer the simplest renderer that works. Do not add or directly import `py2vega`; use only the expression support exposed by the installed `ipydatagrid` version.

```python
# Set up your environment
import ipydatagrid as ipd
import numpy as np
import pandas as pd

import bql

# Connect to the BQL service
bq = bql.Service()

# Create sample DataFrame
np.random.seed(1)

df = pd.DataFrame(
    {
        'A': np.random.default_rng(0).integers(-100, 100, size=5), 
        'B': np.random.default_rng(1).integers(-100, 100, size=5) / 1000,
        'C': pd.date_range('2020-01-01', '2020-01-05'),
        'D': np.random.default_rng(0).integers(100000, 10000000, size=5),
        'E': [1, np.nan, 3, 4, np.nan]
    }, 
    index=pd.Index(
        ['this', 'is', 'some', 'demonstration', 'data'],
        name='Demo'
    )
)
```

```python
universe = bq.univ.members('INDU Index')
# Required data items
data_items = {
    'Name': bq.data.name(),
    'Sector': bq.data.classification_name(),
    'Price': bq.data.px_last(),
    'Target Price': bq.data.best_target_price(),
    'Total Rtn 1M': bq.data.total_return(calc_interval='1M'),
    'EPS 0FY': bq.data.is_eps(fa_period_type='A'),
    'Est EPS': bq.data.is_eps(
        fa_period_offset='1',
        fa_period_type='A'
    ),
    'Exp Rprt Dt': bq.data.expected_report_dt(),    
}

with_params = {'fill': 'prev', 'mode': 'cached'}
# Build and execute the request
request = bql.Request(universe, data_items, with_params=with_params)
response = bq.execute(request)

# Process response into single DataFrame
df_bql = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
```

### Showcase: Formatting IPyDataGrid Text
- This notebook demonstrates how to change the data type, alignment, color, and font for text in an IPyDataGrid.
- **Topics:** Open an interactive version; Overview¶; Setting up your environment¶; Setting column data type formats¶; Changing text alignment¶; Changing colors and fonts¶
- **Key points:**
  - Visualization Gallery
  - Setting up your environment
  - Setting column data type formats
  - Changing text alignment
  - Changing colors and fonts
  - default_renderer: A single renderer to apply as the default to all columns.
  - renderers: A dictionary of renderers keyed by column name.

```python
# Set formats for the index, and columns A, B, C, and D
renderers = {
    'Demo': ipd.TextRenderer(background_color='blue'),
    'A': ipd.TextRenderer(format='.2f', text_color='red'),
    'B': ipd.TextRenderer(format='.2%', background_color='rgb(155,120,130)'),
    'C': ipd.TextRenderer(format='%Y-%m-%d', format_type='time'),
    'D': ipd.TextRenderer(format=',.0f', font='bold 20px fontawesome')
}

grid = ipd.DataGrid(
    dataframe=df,
    # Pass the above dictionary to the renderers argument
    renderers=renderers,
    # Pass a TextRenderer to apply to the column headings
    header_renderer=ipd.TextRenderer(background_color='green'),
    # Pass a TextRenderer to apply to the top left corner cell
    corner_renderer=ipd.TextRenderer(background_color='violet'),
    base_column_size=120,
    base_row_header_size=100,
    layout={'width': '650px', 'height': '140px'}
)

grid
```

```python
# Set formats for columns B, C, and D
renderers = {
    'B': ipd.TextRenderer(format='.2%', horizontal_alignment='right'),
    'C': ipd.TextRenderer(format='%Y-%m-%d', format_type='time'),
    'D': ipd.TextRenderer(format=',.0f', horizontal_alignment='center')
}

grid = ipd.DataGrid(
    dataframe=df,
    # Pass the above dictionary to the renderers argument
    renderers=renderers,
    # Pass a single TextRenderer to apply as the default to other columns
    default_renderer=ipd.TextRenderer(format='.1f'),
    base_column_size=100,
    base_row_header_size=100,
    layout={'width': '560px', 'height': '140px'}
)

grid
```

### Showcase: Configuring IPyDataGrid Grid, Column, Row, and Header Settings
- This notebook demonstrates how to configure grid, column, row, and header settings for an IPyDataGrid.
- **Topics:** Open an interactive version; Setting up your environment¶; Setting grid size¶; Setting column widths¶; Setting row heights¶; Setting header visibility¶
- **Key points:**
  - Visualization Gallery
  - Setting grid size
  - Setting column widths
  - Setting row heights
  - Setting header visibility
  - column_widths: A dictionary of pixel widths keyed by column name.
  - base_column_size: The default pixel width to apply to all other columns.

```python
# Set up your environment
import ipydatagrid as ipd
import numpy as np
import pandas as pd

# Create sample DataFrame
df = pd.DataFrame(
    {
        'A': np.random.default_rng(0).integers(0, 100, size=5), 
        'B': np.random.default_rng(1).integers(0, 100, size=5),
        'C': np.random.default_rng(2).integers(0, 100, size=5)
    }, 
    index=pd.Index(
        ['this', 'is', 'some', 'demonstration', 'data'],
        name='Demo'
    )
)
```

```python
# Set column C as 90 pixels wide
column_widths = {'C': 90}

grid = ipd.DataGrid(
    dataframe=df,
    # Pass the above dictionary to the column_widths argument
    column_widths=column_widths,
    # Set the column width of all other columns
    base_column_size=55,
    # Set the index width
    base_row_header_size=90,
    layout={'width': '300px', 'height': '140px'},
)

grid
```

## Build Analysis Official: Interactivity & Callbacks

> Desktop-safe UI: `ipywidgets` + Plotly `FigureWidget`. Prefer `batch_update()`; prefer `functools.partial` over bare `global` for callback binding.
> Environment gate: ipywidgets v8 is not fully compatible with v7 behavior. Re-test callbacks, layout traits, and upload widgets after upgrades.
> What's New indexes a **Linking Components Together** Help Center page (May 2026), but its page body is not present in Raw source; do not infer undocumented linking APIs.

```mermaid
flowchart TD
  W[Fundamental widgets] --> L[Container layout]
  L --> S[Scope / kernel state]
  S --> C[Callbacks]
  C --> P[partial]
  C --> G[global]
  C --> U[Update chart / grid]
```

### Building an Interactive App
- BQuant published apps allow you to share research results with colleagues within your firm, combining data retrieval, visualizations, and interactive controls into a single interface.
- **Topics:** Overview; Setting up your project; Retrieving your data; Manipulating your data; Visualizing your data; Adding interactivity; Publishing your app; See also
- **Key points:**
  - Setting up your project
  - Retrieving your data
  - Manipulating your data
  - Visualizing your data
  - Adding interactivity
  - Publishing your app
  - Retrieve data (PyBQL): Query Bloomberg data with BQL.

```python
def update_chart(change):
    # Filter to the newly selected ticker
    ticker_df = df.loc[[change['new']]]
    # Update the figure data in place
    with fig.batch_update():
        fig.data[0].x = ticker_df.index
        fig.data[0].y = ticker_df['PX_LAST()']

# Call update_chart whenever the dropdown value changes
ticker_dropdown.observe(update_chart, names='value')
```

```python
# Filter the DataFrame to a single ticker
ticker_df = df.loc[['AAPL US Equity']]

# Create a Plotly FigureWidget (supports in-place updates)
fig = go.FigureWidget(
   data=[go.Bar(x=ticker_df.index, y=ticker_df['PX_LAST()'])],
   layout=go.Layout(
      template='plotly_dark',
      title='Last Price',
   ),
)
fig
```

### Fundamental Widgets
- This notebook introduces the fundamental widgets used to build interactive BQuant applications. These widgets are used to display content, collect user input, and trigger actions. You can see a full list of available widgets by viewing the IPyWidgets documentation.
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Setting up your environment¶; Static display widgets¶; Displaying application state with labels¶; Adding titles and descriptive text using HTML¶; Adding a loading spinner¶
- **Key points:**
  - Setting up your environment
  - Static display widgets Displaying application state with labels
  - Adding titles and descriptive text using HTML
  - Adding a loading spinner
  - Input widgets Creating and reading text inputs
  - Using date selectors
  - Dropdowns Dropdown to select members of an index

```python
# Read the selected ticker
selected_ticker = ticker_dropdown.value

# Define universe and data item
data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-30d', '0d'), fill='prev')
}

# Build and execute request
request = bql.Request(selected_ticker, data_item)
response = bq.execute(request)

# Create DataFrame from response
df = response[0].df()

# Create line chart
fig = px.line(
    df,
    x='DATE',
    y='Price',
    title=f"{selected_ticker} Last 30 Days",
    template='plotly_dark'
)
# Display figure
fig
```

```python
# Create the Dropdown widget using the index_members list
ticker_dropdown = widgets.Dropdown(
    description='Index member',
    options=index_members,
    style={'description_width': 'initial'}
)

# Display the Dropdown widget
ticker_dropdown
```

### Container Widgets
- Container widgets are used to collect individual widgets together in a single cell output. These examples show how to use container widgets to create and update a display.
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Setting up your environment¶; Creating displays with VBox() and HBox()¶; Updating displays using the children attribute¶; Updating displays using a button¶; Defining tabs¶
- **Key points:**
  - Setting up your environment
  - Creating displays with VBox() and HBox()
  - Updating displays using the children attribute Updating displays using a button
  - Defining tabs Updating a specific tab
  - Defining accordions Updating an accordion
  - Using VBox and HBox to arrange widgets vertically and horizontally, including nested layouts
  - Updating displays dynamically by assigning new values to the .children attribute

```python
# Define the content for each accordion section

# Section 1: Universe definition
universe_label = widgets.Label(value='Define your universe here')
text_input = widgets.Text(
    value='SPX Index',
    description='Index:',
    placeholder='Enter an index'
)

universe_container = widgets.VBox([text_input, universe_label])

# Section 2: Results
results_label = widgets.Label(value='Results will appear here')
results_container_2 = widgets.VBox([results_label])

# Create the Accordion widget and assign children and titles
accordion = widgets.Accordion(
    children=[universe_container, results_container_2],
    titles=('Universe', 'Results')
)

# Display the accordion
accordion
```

```python
# Define the content for each tab

# Tab 1: Universe definition
universe_label = widgets.Label(value='Define your universe here')
text_input = widgets.Text(
    value='SPX Index',
    description='Index:',
    placeholder='Enter an index'
)

universe_container = widgets.VBox([text_input, universe_label])

# Tab 2: Results
results_label = widgets.Label(value='Results will appear here')
results_container = widgets.VBox([results_label])

# Create the Tab widget and assign children and titles
tabs = widgets.Tab(
    children=[universe_container, results_container],
    titles=('Universe', 'Results')
)

# Display the tabs
tabs
```

### Scope
- Introduction Setting up your environment Local scope Global scope Building a user interface Summary Introduction¶ Scope refers to where a variable can be accessed from. In practice, scope answers questions such as:
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Setting up your environment¶; Local scope¶; Global scope¶; Building a user interface¶; Summary¶
- **Key points:**
  - Setting up your environment
  - Building a user interface
  - Where was this variable created?
  - Which functions are allowed to read it?
  - Which functions are allowed to change it?
  - Creates a global variable that contains a string.
  - Defines a print_message_2() function that prints the string.

```python
fig_2 = go.FigureWidget(go.Scatter())

def get_data():
    df = pd.DataFrame(
        {
            'ABC': [1, 2, 3, 4, 5, 6, 7, 8],
            'DEF': [11, 22, 33, 44, 55, 66, 77, 88]
        }
    )

    return df

def update_chart_2(df):
    with fig_2.batch_update():
        fig_2.data[0].x = df['ABC']
        fig_2.data[0].y = df['DEF']

def run():
    df = get_data()
    update_chart_2(df)

fig_2
```

```python
dropdown = widgets.Dropdown(
    description='Ticker',
    options=['MSFT US Equity', 'IBM US Equity']
)

def run():
    dropdown.value = 'IBM US Equity'

dropdown
```

### Callback Functions
- The method for registering a widget to a callback function depends on the widget type. The most common are:
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Setting up your environment¶; Triggering a callback with a button click¶; Triggering a callback on startup¶; Observing a dropdown¶; Displaying the spinner widget¶
- **Key points:**
  - Setting up your environment
  - Triggering a callback with a button click
  - Triggering a callback on startup
  - Observing a dropdown
  - Displaying the spinner widget
  - Creates a Button widget with a "Run" description.
  - Defines a callback function that executes when the button is clicked. The function: Has a single parameter named event.

```python
button_3 = widgets.Button(description='Run')
spinner = widgets.HTML(
    '''<i class="fa fa-spinner fa-spin" style="font-size: 18px"></i>''',
    layout={'visibility': 'hidden', 'margin': '2px 0 0 5px'}
)

def run_5(event):
    spinner.layout.visibility = 'visible'
    # Simulate some other code running
    time.sleep(1)
    spinner.layout.visibility = 'hidden'

button_3.on_click(run_5)

widgets.HBox([button_3, spinner])
```

```python
dropdown_2 = widgets.Dropdown(
    description='Security',
    options=['IBM US Equity', 'MSFT US Equity']
)

def run_4(event=None):
    print(
        "Newly selected security using event details:",
        event['new']
    )
    print(
        "Newly selected security using dropdown's value attribute:",
        dropdown_2.value
    )

dropdown_2.observe(run_4, names='value')

dropdown_2
```

### Callback Functions and Scope
- This issue can be resolved in different ways, including:
- **Topics:** Table of contents¶; Introduction¶; Setting up your environment¶; Introducing the grid click event¶; Extracting information from the event¶; Accessing data inside the callback¶; Accessing data inside the callback with partial¶; Accessing data inside the callback with global variables¶
- **Key points:**
  - Setting up your environment
  - Introducing the grid click event
  - Extracting information from the event
  - Accessing data inside the callback
  - Accessing data inside the callback with partial
  - Accessing data inside the callback with global variables
  - Explicitly passing required data to the callback using a partial function

```python
# Create sample data
def get_data():
    df_5 = pd.DataFrame(
        data={
            'Price': [10, 20, 15],
            'EPS': [3, 2, 5]
        },
        index=['AAA', 'BBB', 'CCC']
    )

    df_5.index.name = 'Ticker'
    return df_5

def grid_click(event):
     # Identify the clicked row
    clicked_row = event['primary_key_row']
    # Use the clicked row to identify the ticker in the global DataFrame
    clicked_ticker = df_5.iloc[clicked_row].name

    print("Clicked row:", clicked_row)
    print("Clicked ticker:", clicked_ticker)

# Create the grid
def build_grid(df_5):
    grid = ipd.DataGrid(df_5, layout={'height': '100px'})
    # Register the grid cell click to the grid_click callback
    grid.on_cell_click(grid_click)
    return grid

def run():
    # Get the data as a global variable
    global df_5
    df_5 = get_data()
    # Build the grid
    grid = build_grid(df_5)
    # Place the grid in its container box
    grid_box.children = [grid]

# Empty container to house the grid
grid_box = widgets.VBox()

# Call the run function
run()

# Show the grid_box
grid_box
```

```python
# Create sample data
def get_data():
    df_3 = pd.DataFrame(
        data={
            'Price': [10, 20, 15],
            'EPS': [3, 2, 5]
        },
        index=['AAA', 'BBB', 'CCC']
    )

    df_3.index.name = 'Ticker'
    return df_3

# Callback to be execuated when the grid is clicked
def grid_click(event):
    # Identify the clicked row
    clicked_row = event['primary_key_row']
    # Use the clicked row to identify the ticker in the DataFrame
    clicked_ticker = df_3.iloc[clicked_row].name

    print("Clicked row:", clicked_row)
    print("Clicked ticker:", clicked_ticker)

# Create the grid
def build_grid(df_3):
    grid = ipd.DataGrid(df_3, layout={'height': '100px'})
    # Register the grid cell click to the grid_click callback
    grid.on_cell_click(grid_click)
    return grid

def run():
    # Get the data
    df_3 = get_data()
    # Build the grid
    grid = build_grid(df_3)
    # Place the grid in a container box
    grid_box.children = [grid]

# Empty container to house the grid
grid_box = widgets.VBox()

# Call the run function
run()

# Show the grid_box
grid_box
```

### Implementation Example Using partial
- This notebook results in identical output to the Global Example but using a different implementation.
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Setting up your environment¶; Data retrieval function¶; Implementation with partial¶
- **Key points:**
  - Setting up your environment
  - Data retrieval function
  - Implementation with partial
  - Request price data over the last three months from BQL for all securities in INDU Index.
  - Build a grid showing the latest available price for each security.
  - Create a callback function that is triggered when the grid is clicked. This function updates the chart to show the price history for the clicked security.
  - The click event itself, so that the function knows which row was clicked.

```python
def build_grid(df):
    """
    Creates a grid and links the grid click to the update_chart() function
    using a partial function so that the grid_df and df is accessible.
    """
    # Create a DataFrame for the grid, which is the last available price per
    # ticker
    grid_df = df[['Price']].groupby('ID').tail(1)

    # Create the grid
    grid = ipd.DataGrid(
        grid_df,
        default_renderer=ipd.TextRenderer(text_format=',.2f'),
        base_row_header_size=150
    )

    # Register the grid click to the update_chart callback, ensuring that it
    # also has access to both the grid_df and the df containing the price
    # history
    grid.on_cell_click(partial(update_chart, grid_df, df))

    return grid
```

```python
def update_chart(grid_df, df, event):
    """
    Updates the chart on grid click with price history for the relevant
    security. Uses the grid_df and df DataFrames referenced via the partial
    function.
    """
    # Identify the clicked row
    clicked_row = event['primary_key_row']
    # Use the clicked row to identify the ticker in the grid DataFrame
    clicked_security = grid_df.iloc[clicked_row].name

    # Update the chart with the time series for the chosen security
    with fig.batch_update():
        fig.data[0].x = df.loc[clicked_security]['DATE']
        fig.data[0].y = df.loc[clicked_security]['Price']
        fig.layout.title.text = clicked_security
```

### Implementation Example Using global
- This results in identical output to the Partial Example but with a different implementation.
- **Topics:** Open an interactive version; Table of contents¶; Introduction¶; Setting up your environment¶; Data retrieval function¶; Implementation with global¶
- **Key points:**
  - Setting up your environment
  - Data retrieval function
  - Implementation with global
  - Request price data over the last three months from BQL for all securities in INDU Index.
  - Build a grid showing the latest available price for each security.
  - Create a callback function that is triggered when the grid is clicked. This function updates the chart to show the price history for the clicked security.
  - The click event itself, so that the function knows which row was clicked.

```python
def build_grid(df):
    """
    Creates a global grid_df, builds the grid, links the grid click to the
    update_chart() function.
    """
    # Create a DataFrame for the grid, which is the last available price per
    # ticker. Make this global so it is available to reference in the
    # update_chart callback
    global grid_df
    grid_df = df[['Price']].groupby('ID').tail(1)

    # Create the grid
    grid = ipd.DataGrid(
        grid_df,
        default_renderer=ipd.TextRenderer(text_format=',.2f'),
        base_row_header_size=150
    )

    # Register the grid click to the update_chart callback
    grid.on_cell_click(update_chart)

    return grid
```

```python
# Empty container for grid
grid_box = widgets.HBox(layout={'min_width': '240px'})

# Empty chart which will be filled with data when the grid is clicked
fig = go.FigureWidget(go.Scatter())

# Run at startup
run()

# Collect the display widgets together
widgets.HBox([grid_box, fig])
```

## Build Analysis Official: Event Studies Modules

> **Beta / not for production** (Help Center warning). Package: `bloomberg.bquant.event_studies`. Do not use in production apps unless user explicitly insists after warning.

```mermaid
flowchart LR
  ES[EventStudy] --> E[Events / Event]
  ES --> TS[TimeSeries]
  ES --> A[Analytics / Aggregations]
  ES --> F[Filters]
  ES --> M[MarketProxies]
  ES --> V[Visualizations / Windows]
```

### bloomberg.bquant.event_studies.Event
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- **Key points:**
  - Timezone-aware values (e.g., 2026-05-19 15:30:00-07:00)
  - event (dict) – The dictionary containing event data.
  - event_datetime_column (str) – The key for the event datetime column.
  - security_column (str) – The key for the security column.
  - feature_columns (Optional[list[str]]) – List of keys for event features to include in the event.
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Represents an event at a specific datetime for a given security, with associated event features.
- You should only create an instance of this class if you are using from_list() to create an Events object.

### bloomberg.bquant.event_studies.Events
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- **Key points:**
  - Timezone-aware values (e.g., 2026-05-19 15:30:00-07:00)
  - events_df (pandas.DataFrame) – A DataFrame containing event data.
  - event_datetime_column (str) – The column for event datetimes.
  - security_column (str) – The column for the security identifier.
  - feature_columns (Optional[list[str]]) – A list of column names for the event features you are analyzing.
  - TypeError – If input types are invalid.
  - ValueError – If specified columns are missing from the DataFrame, if the event_datetime_column contains timezone-naive datetimes with non-zero time components, or if duplicate events exist in the DataFrame.
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Represents a collection of Event objects, organized in a DataFrame, with specified columns for the event datetimes, security identifiers, and event features.
- Tutorial-observed constructors: `Events.from_df(...)` and `Events.from_list(...)`.
- The event datetimes in the event_datetime_column must be Python datetime objects or the pandas equivalent with either:

### bloomberg.bquant.event_studies.TimeSeries
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- **Key points:**
  - KeyError – If specified columns are not present in the DataFrame.
  - df (pandas.DataFrame, optional) – The new DataFrame to use. If not provided, the current DataFrame is retained.
  - datetime_column (str, optional) – The new datetime column name. If not provided, the current datetime_column is retained.
  - security_column (str, optional) – The new security column name. If not provided, the current security_column is retained.
  - TypeError – If the replacement values have invalid types.
  - KeyError – If the specified columns are not present in the DataFrame.
- Tutorial-observed operations include `replace(...)` and `run_analytics(...)`; signatures are beta/version-sensitive.

```python
from datetime import datetime, timezone

import pandas as pd
from bloomberg.bquant.event_studies.time_series import TimeSeries

df = pd.DataFrame(
    {
        "datetime": [datetime(2024, 1, 1, 10, 0, tzinfo=timezone.utc)],
        "security": ["BBG000BQXJJ1"],
        "price": [100.5],
    }
)

ts = TimeSeries(
    df=df,
    datetime_column="datetime",
    security_column="security",
)
```

### bloomberg.bquant.event_studies.aggs
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- **Key points:**
  - relative time: The values are split into resample_freq buckets, indicating the time grouping. The column name is the string passed to the relative_time_column attribute.
  - mean: The mean of the provided returns_column within the group. The values are floats.
  - std: The sample standard deviation of the provided returns_column within the group. The values are floats.
  - count: The number of returns samples within the group. The values are floats.
  - error (float): The error term, which when added and subtracted from the mean gives a confidence interval of 1 - error_probability. The values are floats.
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Defines operations for aggregating time series data across multiple events to produce summary statistics.
- The abstract base class for Aggregation objects, subclasses of which define aggregation operations for event studies.

### bloomberg.bquant.event_studies.analytics
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- **Key points:**
  - Tuesday 2024-01-02 → -1 business days
  - Wednesday 2024-01-03 → 0 business days
  - Thursday 2024-01-04 → 1 business days
  - Friday 2024-01-05 → 2 business days
  - Saturday 2024-01-06 → 2 business days (same as Friday)
  - Sunday 2024-01-07 → 2 business days (same as Friday)
  - Monday 2024-01-08 → 3 business days
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Defines operations for calculating analytics that can be added as additional columns to event study and time series datasets.
- The abstract base class for Analytic objects, subclasses of which describe different ways of calculating new columns to add to existing datasets.

### bloomberg.bquant.event_studies.filters
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- **Key points:**
  - >=: Greater than or equal to the value
  - <=: Less than or equal to the value
  - >: Greater than the value
  - <: Less than the value
  - isin: Checks if the column value is within a given list
  - isna: Checks if the column values are missing
  - isnull: Checks if the column values are missing
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Defines DataFrame-agnostic filters for refining event study data.
- The abstract base class for Filter objects, subclasses of which describe different DataFrame-agnostic ways of filtering event study data.

### bloomberg.bquant.event_studies.market_proxy
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Encapsulates market proxy datasets used as reference benchmarks for calculating relative performance metrics.
- The abstract base class for MarketProxy objects used as reference benchmarks for calculating relative performance metrics, such as beta-adjusted returns.

### bloomberg.bquant.event_studies.visualizations
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Defines operations for generating renderable, interactive visual components from event study datasets.
- The abstract base class for event study Visualizations objects.

### bloomberg.bquant.event_studies.window
- Event Studies is a library in beta release and may change in future releases. Bloomberg does not currently provide support or bug fixes for this library and recommends that you do not use it in production code.
- Event Studies beta API surface — confirm availability on Desktop before use.
- If you would like to provide feedback, contact your Bloomberg Account representative, which you can find on the Bloomberg Terminal® by running CANN <GO>.
- Defines representations of relative-time windows and utilities for converting them into absolute time ranges.
- Represents a relative-time window around a specific datetime. You can convert this class to an absolute TimeRange by passing a reference datetime around which to apply the relative window.
