---
topic_id: "14"
title: BQL for PORT PREP
role: portfolio_api_authority
authority_for: [PORT_PREP, Portfolio_Library, bqport_migration]
not_authority_for: [general_data_item_catalog, enterprise_compute]
evidence_grades: [canonical, user-confirmed, announcement-only]
risk_tier: high_for_writes
routing_keywords: [PORT, PREP, Portfolio_Library, bqport, save, positions]
mandatory_cross_checks: [00-RAG-INDEX, 21-bquant-whats-new, 23-bql-substitution-due-diligence]
restricted_sections: []
source_families: [help_center, whats_new, user_entitlement]
---

# BQL for PORT PREP

String BQL recipes for Portfolio Reporting (`PREP`) data in the BQL Data Lake. PREP fields often require string query syntax (`for()` / `get()`).

> Field boundary: `22` validates standard `bq.data.*` names only. PREP string functions/report fields and Portfolio Library methods require this file plus current entitlement/API evidence.

## Prerequisites

> **Entitlement split (user-confirmed):** PORT Enterprise is present; BQuant runtime remains Desktop. PORT members, PREP string BQL, and Portfolio Library PORT paths are in scope. Do not treat PORT as a BQuant Enterprise feature, and do not refuse PORT/PREP BQL just because the notebook runs on Desktop.

Requires the PREP BQL Module for report queries. Confirm report names and Portfolio Library version/`create_port_portfolio()` Beta status on the Bloomberg machine before write operations. Keep Desktop BQL timeout/universe-size limits.

## Setup

```python
import pandas as pd
import plotly.graph_objects as go
import bql

bq = bql.Service()
```

Object model works for standard securities; PREP uses string syntax:

```python
# Object (non-PREP)
request = bql.Request('AAPL US Equity', {'Price': bq.data.px_last()})
df = bq.execute(request)[0].df()

# String equivalent
bql_query = """
for('AAPL US Equity')
get(px_last)
"""
df = bq.execute(bql_query)[0].df()
```

```mermaid
flowchart TD
  PU[portuniv type=prep] --> PI[port_info]
  PI --> PA[port_all report_name]
  PA --> CL[classification_level]
  PA --> DT[dates=range]
  ALL[preferences addcols=all] --> PI
  ALL --> PA
```

## Discovery Queries

**All portfolios and reports** — `portuniv(type=prep)` lists portfolios; `port_info` returns report metadata:

```python
bql_query = """
for(portuniv(type=prep))
get(dropna(port_info, remove_id=true))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df()
```

**Reports for one portfolio:**

```python
portfolio = 'BI US HIGH YIELD'
bql_query = f"""
for('{portfolio}')
get(port_info)
preferences(addcols='all')"""
df = bq.execute(bql_query)[0].df()
```

**Portfolios holding a specific report:**

```python
report_name = 'FICharacteristicsByBICS'
bql_query = f"""
for(portuniv(type=prep))
get(dropna(port_info(report_name='{report_name}'), remove_id=true))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df()
```

## `port_all()` Report Data

Required: `report_name`. Optional: `dates`, `benchmark`, `currency`, `classification`, `classification_level`, `calc_interval`, `section`.

| `classification_level` | Returns |
|------------------------|---------|
| `'Portfolio'` | Single portfolio rollup |
| `['1']` or `['1','2']` | Bucket levels from PREP report |
| `'Security'` | Security-level rows |

```python
portfolio = 'BI FIXED INCOME'
report = 'FICharacteristicsByBICS'

# Current snapshot
bql_query = f"""
for('{portfolio}')
get(port_all(report_name='{report}'))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df().head()

# Historical week
bql_query = f"""
for('{portfolio}')
get(port_all(report_name='{report}', dates=range(-1w,0d)))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df().head()

# Portfolio level
bql_query = f"""
for('{portfolio}')
get(port_all(report_name='{report}', classification_level='Portfolio'))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df()

# Multiple portfolios
portfolios = ['BI FIXED INCOME', 'BI US HIGH YIELD']
bql_query = f"""
for({portfolios})
get(port_all(report_name='{report}', classification_level='Portfolio'))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df()

# Bucket level 1 (BICS L1)
bql_query = f"""
for('{portfolio}')
get(port_all(report_name='{report}', classification_level=['1']))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df()

# Security level
portfolio = 'LEGATRUU'
report = '11A_INBOUND'
bql_query = f"""
for('{portfolio}')
get(port_all(report_name='{report}', classification_level='Security'))
preferences(addcols='all')
"""
df = bq.execute(bql_query)[0].df()
```

## MAC HPA Section + Radar Chart

```python
request = """
for('WORLD')
get(dropna(port_all(report_name='RiskModelFiles', section='Exposures')))
preferences(addcols='all')
"""
df = bq.execute(request)[0].df().head()

factors = ['GL_BETA', 'GL_SIZE', 'GL_VALUATION', 'GL_GROWTH',
           'GL_PROFIT', 'GL_LEVERAGE', 'GL_SEMICON', 'GL_US']
stocks = df.sort_values('GL_SEMICON', ascending=False)['TICKER'].head(5).unique()

fig = go.Figure()
for stock in stocks:
    row = df.loc[df['TICKER'] == stock].iloc[0]
    vals = row[factors].tolist()
    fig.add_trace(go.Scatterpolar(
        r=vals + [vals[0]], theta=factors + [factors[0]],
        fill='toself', name=stock,
    ))
fig.update_layout(title='Factor Exposures', template='plotly_dark', width=900, height=700)
fig.show()
```

## String Pattern Quick Reference

| Goal | Fragment |
|------|----------|
| PREP universe | `for(portuniv(type=prep))` |
| Valid IDs only | `get(dropna(port_info, remove_id=true))` |
| Full columns | `preferences(addcols='all')` |
| Report filter | `port_info(report_name='...')` |
| Report body | `port_all(report_name='...')` |
| History | `dates=range(-1w,0d)` |
| HPA section | `section='Exposures'` |

Execute: `df = bq.execute(bql_query)[0].df()`. See `11-sample-notebooks.md` for minimal `portuniv` example.

## Project Practice Notes

- Exact-search PORT PREP data-item names in `22`; use Terminal FLDS for ambiguous meanings, parameters, metadata, or entitlement questions.
- String-query example when required: `portuniv(type=prep)` with `preferences(addcols='all')` — see use cases in `11-sample-notebooks.md`.
- No external APIs; BQL + Pandas only for portfolio extracts in this project.

## Get Data Official Tutorial: PORT PREP (Official Quickstart)

```mermaid
flowchart LR
  A["PORT PREP (Official Quickstart)"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### BQL for PORT PREP
- This notebook is designed to show off several ways you can use BQL to access reports from the Portfolio Reporting (PREP <GO>) Bloomberg Terminal® function.
- Note: Official page supplement; string-BQL PREP patterns preferred here.
- **Topics:** Quickstart: BQL for PORT PREP; Open an interactive version; Table of contents¶; Prerequisites¶; Setting up your environment¶; Querying BQL for data¶; Object model syntax¶; String query syntax¶
- **APIs:** `bq.data.px_last`

```python
# Define the target universe, an individual equity identified by its 
# Bloomberg ticker

# You can use any combination of Bloomberg tickers, CUSIPs, ISINs, and
# FIGIs to identify the securities in your universe of interest

universe = 'AAPL US Equity'

# Define the target data, the equity's price, and label the column 
# 'Price'
data_item = {'Price': bq.data.px_last()} 

# Build and execute the BQL query
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Present the data as a pandas DataFrame
df = response[0].df()
df
```

```python
bql_query = f"""
    for(portuniv(type=prep)) 
    get(dropna(port_info(report_name='{report_name}'), remove_id=true))
    preferences(addcols='all')
    """

# Execute the BQL query
response = bq.execute(bql_query)

# Present the data as a pandas DataFrame
df = response[0].df()
df
```


## Build Analysis Official: Portfolio Library

> Uses `import bloomberg.bquant.portfolio as bqp` in official quickstart. Confirm Desktop availability before relying on it in production apps.

### Version / release gate
- Portfolio Library status is version-dependent. Use `21-bquant-whats-new.md` for the current curated release state.
- General write operations are GA in version 2.1; confirm that the installed environment is on a compatible version before writing.
- `Portfolio.to_port()` is beta and requires additional enablement; do not assume availability.

### Release Notes digest (Raw source snapshot, 2026-07-25)
- Portfolio Library **2.1** makes general update/clear/save/review/revert operations generally available; these operations no longer carry the former beta-enablement requirement.
- Portfolio Library 2.x deprecates `PortfolioType` in favor of `PositionType`; do not generate new `PortfolioType` code.
- `create_port_portfolio()` remains **Beta**; confirm availability before use.
- The 2.x API adds staged write/review operations such as `clear_and_update_positions()`, `clear_positions()`, `review_changes()`, and `revert_changes()`.
- Write APIs can replace or clear holdings. Always inspect staged changes and verify the installed version before calling `save()` or writing to PORT.
- History/normalization switches such as `include_all_history` and `include_normalized_weights` default to `False`; request them explicitly only when the installed signature confirms support.
- Portfolio metadata properties include position type, source, currency, and asset class; `list_portfolios()` includes currency and last-updated metadata.
- The former `as_of_dates` parameter was renamed to `dates`; use the current name in new code.
- Legacy `bqport` is unsupported after April 2026.

```mermaid
flowchart LR
  BQP[bloomberg.bquant.portfolio] --> L[list_portfolios]
  BQP --> C[create_port_portfolio]
  BQP --> R[get_rebalance_dates]
  L --> BQL[Join with BQL analytics]
```

### Library Overview
- The BQuant Portfolio Library provides a single streamlined interface for accessing and manipulating investment portfolios in BQuant. The API offers intuitive methods to retrieve, modify, and create portfolios sourced from Bloomberg Terminal®’s PORT function or constructed from user-defined Pandas DataFrames.
- **Topics:** Portfolio Library Overview; Introduction; How it works; Using the library; Creating new portfolios; Updating portfolio holdings; See also
- **Key points:**
  - Using the library Creating new portfolios
  - Updating portfolio holdings
  - To perform operations on PORT portfolios (e.g., discover, read, or update portfolios).
  - Seamless integration into backtesting, optimization, or risk workflows in BQuant.
  - Load portfolios from supported sources. The Portfolio class provides methods for loading portfolios from Terminal functions or construct custom portfolios from Pandas DataFrames: Use Portfolio.from_port() to retrieve portfolios from PORT.
  - Use Portfolio.from_df() to load portfolios from DataFrames.
  - DataFrame support. To use a portfolio in your analysis workflow, you can use to_df() to get the portfolio as a multi-index DataFrame, indexed by date and security.

```python
from bloomberg.bquant.portfolio import (
    create_port_portfolio,
    PortfolioAssetClass,
    PortfolioCurrency,
    PositionType,
)

pf = create_port_portfolio(
    portfolio_name="My Portfolio",
    portfolio_currency=PortfolioCurrency.USD,
    portfolio_asset_class=PortfolioAssetClass.EQUITY,
    position_type=PositionType.SHARES,
)
```

```python
import pandas as pd

positions = pd.DataFrame({
    "date": ["2026-06-01", "2026-06-01"],
    "security": ["AAPL US Equity", "MSFT US Equity"],
    "position": [100, 200],
})

pf.update_positions(positions)
pf.save()
```

### Quickstart: Portfolio Library
- Before running the examples in this notebook, set up your environment by importing the necessary libraries and connecting to the BQL service:
- **Topics:** Quickstart: Interacting with Portfolios; Open an interactive version; Setting up your environment¶; List all portfolios¶; Load a portfolio¶; Supplement positions with additional data from BQL¶; Using holdings in an interactive display¶; See also¶
- **Key points:**
  - List all portfolios
  - Load a portfolio
  - Supplement positions with additional data from BQL
  - Using holdings in an interactive display

```python
def update_fig(event=None):
    """Updates the figure with the price series for the selected security."""
    security = dropdown.value
    temp = df.loc[security]

    with fig.batch_update():
        try:
            fig.data[0].x = temp['DATE']
            fig.data[0].y = temp['Price']
        except:
            fig.data[0].x = [0]
            fig.data[0].y = [0]
```

```python
# List all portfolios
portfolios = bqp.list_portfolios()

# Load the portfolio using its ID
portfolio = bqp.Portfolio.from_port(portfolio_id=portfolios.portfolio_id[0])

# Create a DataFrame of holdings in the specific portfolio
portfolio_df = portfolio.to_df()

# Additional data items to retrieve from BQL
data_items = {
    'Name': bq.data.name(),
    'Sector': bq.data.classification_name()
}

# Request the data items for the portfolio holdings and return as a DataFrame
request = bql.Request(
    portfolio_df.index.get_level_values('security'), 
    data_items
)

response = bq.execute(request)

df = pd.concat(
    [item.df()[item.name] for item in response],
    axis=1
)

# Merge the BQL data back onto the portfolio DataFrame
portfolio_df.merge(df, how='left', left_on='security', right_index=True)
```

### Migrating from bqport
- The legacy `bqport` library is unsupported after April 2026. Do not generate new `bqport` code.
- Migration concepts: discovery → `list_portfolios()`; load → `Portfolio.from_port()`; DataFrame construction → `Portfolio.from_df()`; holdings → `to_df()`; replacement/addition → Portfolio update methods; persistence → `save()`.
- API availability and exact update semantics must be confirmed against the installed Portfolio Library version before modifying a live PORT portfolio.

## Build Analysis Official: Portfolio API Symbols

> Additional API symbol pages from Help Center. Prefer quickstart patterns already above; these entries capture symbol-level docs.

### bloomberg.bquant.portfolio.Portfolio
- The to_port() function is currently in beta and requires additional enablement. To request access, please contact your Bloomberg Account representative. You can find your representative on the Bloomberg Terminal® by running CANN <GO>.
- **Key points:**
  - "identifier", "date", "position"
  - "security", "date", "weight"
  - "identifier", "date", "weight"
  - InputValidationError – If positions is not a DataFrame, is empty, contains future dates, has missing/incorrect columns for the portfolio type, or contains mismatched value types (e.g., weights for a shares portfolio).
  - PortfolioServiceError – If the replacement operation fails during execution.
  - df (pandas.DataFrame) – User-input DataFrame for the portfolio object.
  - position_type (str or PositionType, optional) – The type of portfolio to be created. Options are SHARES, FIXED_WEIGHTS and DRIFTING_WEIGHTS. Defaults to SHARES.
- A Portfolio object holds securities data with positions or weights at various rebalance dates. Portfolios can be created from DataFrames or loaded from PORT.
- Do not instantiate this class directly. Use from_df() to create a portfolio from a DataFrame or from_port() to load from PORT.
- Replaces the portfolio’s positions based on positions, which may include multiple rebalance dates. For each date in positions, all holdings are replaced with the securities specified; any existing holdings not included are removed.
- Read-only metadata includes position type, source, currency, and asset class; exact property names are version-dependent.

### bloomberg.bquant.portfolio.PortfolioAssetClass
- These values represent the asset classification assigned to a portfolio in PORT.
- `FUND_OF_FUNDS` may appear in the enum, but `create_port_portfolio()` rejects it.

### bloomberg.bquant.portfolio.PortfolioCurrency
- These values represent the currency assigned to a portfolio in PRTU.

### bloomberg.bquant.portfolio.PortfolioIdType
- These values can be supplied to methods that retrieve or update portfolio data to specify whether the portfolio is identified by ID or by name.

### bloomberg.bquant.portfolio.PortfolioSource
- These values indicate the system from which a portfolio originates. Certain operations may only be available for specific sources.
- Portfolio created from a local DataFrame.

### bloomberg.bquant.portfolio.PortfolioType
- **Deprecated in Portfolio Library 2.x.** Use `PositionType`; retain this entry only for migration of old notebooks.

### bloomberg.bquant.portfolio.PositionType
- These values specify how portfolio holdings are expressed, and are used when creating or loading a portfolio.
- Holdings specified as drifting portfolio weights.

### bloomberg.bquant.portfolio.create_port_portfolio
- **Beta:** confirm availability in the installed environment before use.
- A set of optional parameters can be assigned upon creation. If a portfolio with the same name already exists, an error is raised.
- **Key points:**
  - portfolio_currency (str or PortfolioCurrency, optional) – The currency associated with the new portfolio (e.g., "USD"). Defaults to "USD".
  - portfolio_asset_class (str or PortfolioAssetClass, optional) – The asset class of the new portfolio as set in PRTU. Options are "Equity", "Balanced", and "FI". Defaults to "Equity".
  - position_type (str or PositionType, optional) – The position type of the new portfolio. Options are SHARES, FIXED_WEIGHTS, and DRIFTING_WEIGHTS. Defaults to SHARES.
  - UserPermissionError – If the user lacks permission to create PORT portfolios.
  - InputValidationError – If portfolio_name is empty, already exists, or portfolio_asset_class is FUND_OF_FUNDS.
- portfolio_name (str) – The name of the new portfolio.
- portfolio_currency (str or PortfolioCurrency, optional) – The currency associated with the new portfolio (e.g., "USD"). Defaults to "USD".
- portfolio_asset_class (str or PortfolioAssetClass, optional) – The asset class of the new portfolio as set in PRTU. Options are "Equity", "Balanced", and "FI". Defaults to "Equity".

### bloomberg.bquant.portfolio.get_rebalance_dates
- portfolio_id (str) – The portfolio ID or name, depending on portfolio_id_type.
- **Key points:**
  - portfolio_id_type (PortfolioIdType, optional) – The type of identifier used to look up the portfolio. Defaults to PORTFOLIO_ID.
  - source (str, optional) – The portfolio source. Only "PORT" is supported. Defaults to None.
  - InputValidationError – If portfolio_id is empty, not found, or matches more than one portfolio when portfolio_id_type is PORTFOLIO_NAME.
  - NotSupportedError – If source is provided but is not "PORT".
  - PortfolioServiceError – If the request to retrieve rebalance dates fails.
- portfolio_id_type (PortfolioIdType, optional) – The type of identifier used to look up the portfolio. Defaults to PORTFOLIO_ID.
- source (str, optional) – The portfolio source. Only "PORT" is supported. Defaults to None.
- A list of ISO-formatted rebalance dates (YYYY-MM-DD) in ascending order.

### bloomberg.bquant.portfolio.list_portfolios
- source (str or PortfolioSource, optional) – The portfolio source to filter results. Only PortfolioSource.PORT is currently supported. Defaults to None.
- **Key points:**
  - portfolio_name (str, optional) – The name of the portfolio to get metadata for. If None, metadata for all portfolios is returned. Defaults to None.
- portfolio_name (str, optional) – The name of the portfolio to get metadata for. If None, metadata for all portfolios is returned. Defaults to None.
- A DataFrame where each row represents a portfolio. Includes columns portfolio_name, portfolio_id, asset_type, position_type, enterprise_association, permission, currency, last_updated.
- NotSupportedError – If source is provided but is not PortfolioSource.PORT.
