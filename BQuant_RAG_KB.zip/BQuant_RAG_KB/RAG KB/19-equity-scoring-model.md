---
topic_id: "19"
title: Creating an Equity Scoring Model
role: analytical_recipe
authority_for: [equity_scoring, credit_factor_scoring, matches_and_grouprank]
not_authority_for: [factor_entitlement, catalog_existence]
evidence_grades: [canonical, script-verified, practice-derived]
risk_tier: normal
routing_keywords: [scoring, grouprank, matches, percentile, factor]
mandatory_cross_checks: [00-RAG-INDEX, 01-bql-for-equities, 18-using-pandas, 22-BQuant_DataItems]
restricted_sections: []
source_families: [help_center, official_script]
---

# Creating an Equity Scoring Model

Dense recipe: BQL factor dictionaries, percentile composites, `matches()` screening, MultiIndex layout, linked Plotly / IPyWidgets UI.

> Field gate: exact-search data items in `22`; use `08` for meaning/metadata and current API/FLDS only when signatures remain unresolved.

## Setup

```python
import bql
import pandas as pd
import ipywidgets as ipw
import ipydatagrid as ipd
import plotly.express as px
import plotly.graph_objects as go

bq = bql.Service()
index = 'B500 Index'
as_of_dt = '2023-05-05'
params = {'dates': as_of_dt, 'fill': 'prev'}
rng_3y = bq.func.range(-2, 0)
```

```mermaid
flowchart LR
  FD[Factor dicts] --> CB[combine percentile]
  CB --> PF[Parent factors] --> CF[Composite grouprank]
  CF --> MF[matches top 40] --> BQ[Request] --> UI[Grid + FigureWidget]
```

## Factor Component Dictionaries

Structure: `{'item': bq.data.*(...), optional 'multiplier': -1}`. Negative multiplier inverts rank (lower PE ranks higher).

```python
value = {
    'FCF Yield': {'item': bq.data.fcf_ev_yield(**params)},
    'Px/Sales': {'item': bq.data.px_to_sales_ratio(**params), 'multiplier': -1},
    'PE': {'item': bq.data.pe_ratio(**params), 'multiplier': -1},
    'EV/EBITDA': {'item': bq.data.ev_to_ebitda(**params), 'multiplier': -1},
}
profitability = {
    'Avg ROE 3Y': {'item': bq.data.return_com_eqy(**params, fpo=rng_3y).avg()},
    'Avg ROIC 3Y': {'item': bq.data.return_on_inv_capital(**params, fpo=rng_3y).avg()},
    'Est Op Mrg Chg': {'item': (
        bq.data.oper_margin(**params, fpo='1')
        - bq.data.oper_margin(**params, fpo='0')
    )},
}
momentum = {
    'Mom 12-1': {'item': bq.data.total_return(
        calc_interval=bq.func.range(f'{as_of_dt}-12m', f'{as_of_dt}-1m'),
    )},
    'Mom 6-1': {'item': bq.data.total_return(
        calc_interval=bq.func.range(f'{as_of_dt}-6m', f'{as_of_dt}-1m'),
    )},
}
display = {
    'Name': {'item': bq.data.name()},
    'Sector': {'item': bq.data.classification_name()},
}
```

## `combine()` and Composite

Average group percentile (NA → 0.5), scale 0–100:

```python
def combine(components):
    final_calc = 0
    for component in components:
        item = component['item'] * component.get('multiplier', 1)
        final_calc += (1 - item.grouprank() / item.groupcount()).replacena(0.5)
    return final_calc / len(components) * 100

factors = {
    'Value Pctle': {'item': combine(value.values())},
    'Profitability Pctle': {'item': combine(profitability.values())},
    'Momentum Pctle': {'item': combine(momentum.values())},
}
composite_factor = (
    factors['Value Pctle']['item']
    + factors['Profitability Pctle']['item']
    + factors['Momentum Pctle']['item']
) / 3
composite_factor = composite_factor.grouprank()
factors['Composite'] = {'item': composite_factor}
```

## `matches()` Filter (Preserves Group Ranks)

Unlike `univ.filter()`, ranks stay relative to full universe:

```python
def apply_matches_filter(d, composite_factor, cutoff):
    for name, item in d.items():
        d[name] = (
            item['item']
            .matches(composite_factor <= cutoff)
            .dropna(remove_id=True)
        )
    return d

value = apply_matches_filter(value, composite_factor, 40)
profitability = apply_matches_filter(profitability, composite_factor, 40)
momentum = apply_matches_filter(momentum, composite_factor, 40)
factors = apply_matches_filter(factors, composite_factor, 40)
display = apply_matches_filter(display, composite_factor, 40)
all_items = {**display, **value, **profitability, **momentum, **factors}
```

## Execute and MultiIndex Columns

```python
univ = bq.univ.members(index, dates=as_of_dt)
response = bq.execute(bql.Request(univ, all_items, with_params={'mode': 'cached'}))
df = pd.concat([item.df()[item.name] for item in response], axis=1)

df = df.loc[:, [
    *display.keys(), *value.keys(), 'Value Pctle',
    *profitability.keys(), 'Profitability Pctle',
    *momentum.keys(), 'Momentum Pctle', 'Composite',
]]

def create_multiindex(heading, col_names):
    names = list(col_names) + [heading + ' Pctle']
    return pd.MultiIndex.from_product([[heading], names])

df.columns = pd.MultiIndex.from_tuples(
    list(create_multiindex('Descriptive', display.keys()))[:-1]
    + list(create_multiindex('Value', value.keys()))
    + list(create_multiindex('Profitability', profitability.keys()))
    + list(create_multiindex('Momentum', momentum.keys()))
    + [('Composite', 'Rank')]
)
```

## IPyDataGrid + Plotly + Dropdowns

```python
num_fmt = ipd.TextRenderer(format='.2f')
pct_fmt = ipd.TextRenderer(format='.2%')
renderers = {
    **{c: pct_fmt for c in df.columns if c[1] in momentum.keys()},
    **{c: num_fmt for c in df.columns if c[1] in [*value.keys(), *profitability.keys(), *factors.keys()]},
}
grid = ipd.DataGrid(dataframe=df, renderers=renderers, layout={'width': '1690px'})

scatter = px.scatter(
    x=df[('Value', 'Value Pctle')].values,
    y=df[('Profitability', 'Profitability Pctle')].values,
    hover_name=df[('Descriptive', 'Name')].values,
    color=df[('Descriptive', 'Sector')].values,
    template='plotly_dark',
)
fig = go.FigureWidget(scatter)
fig.update_layout(dragmode='select', legend=None)

def tuple_to_text(tup):
    return ' - '.join(tup)

options = [(tuple_to_text(c), c) for c in df.columns if c[0] != 'Descriptive']
dropdown_x = ipw.Dropdown(options=options, value=('Value', 'Value Pctle'), description='X Axis')
dropdown_y = ipw.Dropdown(options=options, value=('Profitability', 'Profitability Pctle'), description='Y Axis')
```

## Event Handlers

```python
def update_chart(event):
    with fig.batch_update():
        for trace in fig.data:
            temp = df[df[('Descriptive', 'Sector')] == trace.name]
            trace.x = temp[dropdown_x.value].values
            trace.y = temp[dropdown_y.value].values
        fig.update_xaxes(title=tuple_to_text(dropdown_x.value))
        fig.update_yaxes(title=tuple_to_text(dropdown_y.value))

def update_grid(trace, points, selector):
    selected = []
    for t in fig.data:
        if t.selectedpoints:
            selected.extend([t.hovertext[i] for i in t.selectedpoints])
    grid.transform([{'type': 'filter', 'operator': 'in', 'columnIndex': 1, 'value': selected}])

dropdown_x.observe(update_chart)
dropdown_y.observe(update_chart)
for trace in fig.data:
    trace.on_selection(update_grid)

display = ipw.VBox([fig, ipw.HBox([dropdown_y, dropdown_x]), grid])
display
```

Winsorize extension: chain `.group(by=...)` → `.winsorize(...)` → `.avg()`.

## PIT Quartile Long/Short Extension

The scoring model above is a single-date percentile screen. The official *Fundamental Backtester* adds a different, complementary workflow:

```text
verified raw factors
-> optional sector-relative z-score cap
-> composite signal
-> ntile(4)
-> retain extreme quartiles
-> holding-period total return
-> quartile 4 minus quartile 1, or the explicitly chosen reverse
-> cumulative and rolling analytics
```

Key distinctions:

- `grouprank` / `groupcut` ranks a cross-section for selection; `ntile(4)` assigns portfolio buckets.
- Backdate index membership and every PIT fundamental request at each rebalance date.
- Calculate return over the next rebalance interval, not at the signal date.
- Preserve the rebalance date during `execute_many` normalization.
- Confirm which end of each factor is economically "good" before fixing the long/short direction.
- A sector z-score cap via nested `if_` is a signal transform; `.group().winsorize().avg()` remains a separate grouped-aggregation pattern.

The full request blueprint is in `01-bql-for-equities.md` → **Production Recipe: PIT Factor Backtest**. Response lineage and `merge_asof` rules are in `18`.

## Project Practice Notes

- Scoring pipelines must exact-search data-item names in `22`; use FLDS only for unresolved ambiguity/signatures.
- Group / winsorize / aggregate chain order: `.group(by=...)` → `.winsorize(...)` → `.avg()`.
- For interactive score heatmaps, use Plotly `FigureWidget` + `batch_update()` (see `09-build-analysis.md`).

---

## Help Center Scoring Extras (from examples)

Patterns not fully covered above; full factor UI lives in this file — avoid duplicating in `01-bql-for-equities.md`.

### Equity Scoring and Screening — `groupcut` percentile variant

Help Center uses decile-style `groupcut(n=100).replacena(50)` instead of `grouprank()/groupcount()`; composite uses `.grouprank()` only at the end.

```python
def combine(components):
    final_calc = 0
    for component in components:
        item = component['item'] * component.get('multiplier', 1)
        final_calc += item.groupcut(n=100).replacena(50)
    return final_calc / len(components)

def apply_cutoff_filter(to_filter, composite_factor, cutoff):
    filtered = {}
    for name, item in to_filter.items():
        filtered[name] = (
            item['item']
            .matches(composite_factor <= cutoff)
            .dropna(remove_id=True)
        )
    return filtered

# UniversePicker path: pin members/holdings date; equity-only filter
universe = universe_picker.value
if universe_picker.universe_type in ['Fund holdings', 'Index members']:
    universe = universe.with_additional_parameters(dates=as_of_date)
universe = universe.filter(bq.data.market_sector_des() == 'Equity')
```

APIs: `bq.data.classification_name`, `bq.data.ev_to_ebitda`, `bq.data.fcf_ev_yield`, `bq.data.market_sector_des`, `bq.data.name`, `bq.data.oper_margin`, `bq.data.pe_ratio`, `bq.data.px_to_sales_ratio`, `bq.data.return_com_eqy`, `bq.data.return_on_inv_capital`, `bq.data.total_return`, `bq.func.range`.

### Creating an Equity Scoring Model — tutorial alignment

Canonical Help Center walkthrough matches this file's `combine()` / `matches()` / MultiIndex grid pattern; tutorial adds explicit `with_params={'mode': 'cached'}` on `bq.univ.members(index, dates=as_of_dt)`.

### Credit Factor Scoring — issuer-mapped credit factors (bond universe)

Map bond metrics to equity issuer fundamentals via `bq.univ.issuerof()` lineage; winsorize and z-score **within sector**, then blend credit + spread + momentum.

```python
def map_to_issuer(data_item):
    return (
        data_item
        .value(bq.univ.issuerof(), mapby='lineage')
        .znav()
    )

universe = (
    bq.univ.members('EMUSTRUU Index')
    .filter(bq.data.classification_name() != 'Government')
)

data_items = {
    'Sector': bq.data.classification_name(),
    'Debt to EBITDA': map_to_issuer(
        bq.data.net_debt_to_ebitda(fa_period_type='BA') * -1
    ),
    'Debt to Capital': map_to_issuer(
        bq.data.tot_debt_to_tot_cap(fa_period_type='BA') * -1
    ),
    'Interest Coverage': map_to_issuer(
        bq.data.net_interest_coverage(fa_period_type='BA')
    ),
    'Valuation Score': bq.data.spread(spread_type='OAS'),
    'Momentum Score': bq.data.total_return(
        calc_interval=bq.func.range('-3m', '0d')
    ),
}

df = pd.concat(
    [item.df()[item.name] for item in bq.execute(
        bql.Request(universe, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
    )],
    axis=1,
)

numeric_cols = df.select_dtypes(include='number').columns

def clip_group(group):
    """Winsorize numeric columns using within-sector 10th/90th percentiles."""
    result = group.copy()
    for column in numeric_cols:
        lower, upper = group[column].quantile([0.1, 0.9])
        result[column] = group[column].clip(lower=lower, upper=upper)
    return result

def standardize(series):
    """Return a within-sector z-score without external dependencies."""
    std = series.std(ddof=0)
    return (series - series.mean()) / std if std else 0.0

scored = df.groupby('Sector', group_keys=False).apply(clip_group)
scored[numeric_cols] = (
    scored.groupby('Sector')[numeric_cols].transform(standardize)
)
scored['Credit Score'] = (
    scored['Debt to EBITDA'] / 3
    + scored['Debt to Capital'] / 3
    + scored['Interest Coverage'] / 3
)
scored['Combined Score'] = (
    scored['Credit Score'] / 3
    + scored['Valuation Score'] / 3
    + scored['Momentum Score'] / 3
)
```

APIs: `bq.data.classification_name`, `bq.data.issuer`, `bq.data.name`, `bq.data.net_debt_to_ebitda`, `bq.data.net_interest_coverage`, `bq.data.spread`, `bq.data.tot_debt_to_tot_cap`, `bq.data.total_return`, `bq.func.range`, `bq.univ.issuerof`, `bq.univ.members`.

## Related White Paper

See `10-bquant-research.md` → **White Paper: Equity Factor Investing Strategy** for an extended factor notebook extract.
