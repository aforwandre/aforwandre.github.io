---
topic_id: "15"
title: Share Results
role: publishing_reference
authority_for: [captured_launchpad_publishing_guidance]
not_authority_for: [uncaptured_app_limits, enterprise_sharing]
evidence_grades: [canonical, gap-uncaptured]
risk_tier: normal
routing_keywords: [publish, Launchpad, share, app_limits, BQAP, Terminal Link, snapshot]
mandatory_cross_checks: [00-RAG-INDEX, 05-get-started, 16-home]
restricted_sections: []
source_families: [help_center]
---

# Share Results

> Publishing BQuant notebooks as Terminal Launchpad apps — practice notes for CURSOR_BQNT.
> Source status: the current Raw source snapshot includes the publishing pointer in **Building an Interactive App**, but not the full **Publishing BQuant Apps** or **App limits** pages.

---

## What a Published App Is

A BQuant app captures a project snapshot (source + startup notebook) and exposes interactive widgets/plots to Terminal users without showing raw code. Apps can be shared via Terminal Link; Desktop ↔ Enterprise sharing may hit version compatibility issues — test on target environment before wide rollout.

What's New records a BQAP `<GO>` search/sort/filter redesign in May 2026. Treat this as a discovery-UI change, not a notebook API change.

---

## App Deployment Workflow (Launchpad)

Convert a finished notebook into a no-code Bloomberg Terminal Launchpad app:

```mermaid
flowchart LR
    A[Finish notebook + widgets] --> B[Set as startup notebook]
    B --> C[Save Project]
    C --> D[Management Center → New App]
    D --> E[Copy Terminal Link]
    E --> F[Teammates open in Launchpad]
```

**Steps:**

1. **Set startup notebook**: Right-click the notebook → `Set as startup notebook`.
2. **Save project**: Top menu `Project` → `Save Project`.
3. **Preview app**: use the JupyterLab application preview to verify startup layout and callbacks.
4. **Publish app**: Open Management Center → click `New App`.
5. **Internal share**: After publishing, copy the `Terminal Link`. Teammates can open the interactive dashboard in Terminal without viewing source code.

## Snapshot versus auto-sync (user-confirmed practice, 2026-09-02)

A published app is a **project snapshot** (source + startup notebook). Saving
or editing the author's project does **not** update colleagues' BQAP copy.
After each accepted change: Save Project, then publish/update that **same**
app from Management Center. Exact Update-existing-app chrome is on the
uncaptured *Publishing BQuant Apps* page; do not invent a second New App
unless the UI has no update path.

**How a teammate uses a Terminal Link**

1. Open the link inside Bloomberg Terminal. The app launches in Launchpad
   without source code.
2. Later they may find the same app under **BQAP `<GO>`** search/sort/filter
   (May 2026 redesign is discovery UI only).

The link does **not** auto-pin onto their personal BQAP page. Controls for
Favorite / My Apps / pin-to-page are `gap-uncaptured` (*Apps overview*).
Do not reconstruct button names. Desktop consumers: at most **2** apps
viewed concurrently.

**Not the same as publishing**

| Action | Effect |
|---|---|
| Publish Launchpad app | Snapshot for Terminal/BQAP consumers; no source |
| Send project | Recipient gets a **copy**; not live-linked |
| Transfer project | Ownership moves, with snapshot history |
| Managed Git | **Enterprise only**; not available on this Desktop entitlement |

Recipient communities use Terminal CMTY / SPDL. Desktop publishing remains
limited (`05`).

Help Center snapshot limits for Desktop: at most **2 apps viewed concurrently** and **200 published apps**. Verify current limits before large-scale rollout.

---

## Pre-Publish Checklist

- Run **Run All** top-to-bottom; no `NameError` from out-of-order cells.
- Plotly updates wrapped in `with fig.batch_update():` to avoid flicker.
- No external network calls — BQL / Pandas / Plotly / ipywidgets only.
- Hard-coded dates replaced with relative ranges where appropriate for recurring use.

---

## Project Practice Notes: App Deployment (Launchpad)

> Integrated from production BQuant development experience.

Convert a finished notebook into a no-code Bloomberg Terminal Launchpad app using the four steps above. For heatmap / monitor apps built in this workspace, see build patterns in `09-build-analysis.md` and sample flows in `11-sample-notebooks.md`.

## Interactivity Cross-Ref

App UI patterns: `09-build-analysis.md` sections **Visualizations & IPyDataGrid** and **Interactivity & Callbacks**. Respect Desktop Launchpad view/publish limits.
