---
topic_id: "05"
title: Get Started with BQuant
role: platform_authority
authority_for: [desktop_runtime, limits, environment, troubleshooting]
not_authority_for: [bql_signatures, enterprise_runtime]
evidence_grades: [canonical, user-confirmed]
risk_tier: normal
routing_keywords: [Desktop, timeout, workload, kernel, 403, package]
mandatory_cross_checks: [00-RAG-INDEX, 21-bquant-whats-new]
restricted_sections: []
source_families: [help_center, workspace_policy]
---

# Get Started with BQuant

> AI-oriented onboarding for CURSOR_BQNT — environment rules and workflow, not Help Center navigation.

---

## Platform Role

BQuant Desktop runs on Bloomberg-managed infrastructure (Python 3.11). You write and review code locally in Cursor; you execute BQL only on the work Bloomberg machine inside BQuant or Terminal-connected kernels.

```mermaid
flowchart LR
    subgraph local [Local Cursor — CURSOR_BQNT]
        A[Design notebook / app]
        B[Review with AI]
    end
    subgraph terminal [Work Bloomberg Machine]
        C[Copy code to BQuant project]
        D[Run All / test BQL]
        E[Publish Launchpad app]
    end
    A --> B --> C --> D --> E
```

---

## First Session Checklist

1. Launch BQuant Desktop from Bloomberg Terminal.
2. Create or open a project; confirm Python 3.11 kernel.
3. Setup cell:

```python
import pandas as pd
import bql
bq = bql.Service()
```

4. Run a minimal request:

```python
request = bql.Request('LUACTRUU Index', {'Name': bq.data.name()})
response = bq.execute(request)
response[0].df().head()
```

5. When a field name is uncertain, exact-search `22` first; use Terminal FLDS only for absent/ambiguous names or unresolved signatures.

---

## Tech Stack Constraints

- Closed environment: depend only on **BQL**, **Pandas**, **Plotly**, and **ipywidgets**.
- Do **not** call external / internet APIs from BQuant notebooks or apps.
- Code must run on Bloomberg BQuant (Python 3.11). Local Cursor is for design, authoring, and review only — not for live BQL execution.

---

## Kernel State Sharing

- Notebook cells share a global kernel namespace.
- Variables and functions must be **defined before they are called**.
- If you hit `NameError`, move definition cells to the top and click **Run All**.

---

## Development Workflow (Local vs Terminal)

1. Design and write code in local Cursor (`CURSOR_BQNT`).
2. Manually copy notebooks/scripts to the work Bloomberg machine.
3. Run and test only inside Bloomberg BQuant / Terminal.
4. Exact-search uncertain BQL data-item names in `22`; ask for Terminal FLDS only when ambiguity, parameters, metadata, entitlement, or runtime behavior remain unresolved.

---

## Next Steps

| Goal | Read |
|------|------|
| Data access patterns | `06-get-data-overview.md` |
| Equities | `01-bql-for-equities.md`, `03-equity-foundations.md` |
| Fixed income | `02-bql-for-fixed-income.md`, `04-fixed-income-foundations.md` |
| Project hub | `16-home.md` |

## Desktop vs Enterprise (Hard Constraint for This Project)

> User entitlement: **BQuant Desktop only**. Do not design for BQuant Enterprise-only capabilities (scheduler, sandbox storage, custom images, managed Git). **AIM Enterprise** and **PORT Enterprise** are separate data/product entitlements and **are present**; AIM positions, PORT members/PREP, and Portfolio Library PORT paths are in scope on Desktop. Do not mix those licenses with BQuant Enterprise.

```mermaid
flowchart TB
  U[User: BQuant Desktop] --> OK[Allowed: JupyterLab + BQL + local notebook patterns]
  U --> NO[Forbidden without explicit user confirmation]
  NO --> E1[Scalable compute / custom environments]
  NO --> E2[Own dataset integration / Sandbox object storage]
  NO --> E3[Managed Git collaboration]
  NO --> E4[Recurring scheduled workloads]
  NO --> E5[Unlimited project transfer / unrestricted Launchpad publishing]
```

### Feature comparison (from Help Center)

| Area | Desktop | Enterprise |
|------|---------|------------|
| JupyterLab Python IDE | Yes | Yes |
| Web browser interface | Yes | Yes |
| Scalable compute resources | **No** | Yes |
| BQL data access | **Limited (download limits)** | Full |
| Integrate your own datasets | **No** | Yes |
| Object storage / Sandbox Storage | **No** | Yes |
| Send / transfer / receive projects | **Limited** | Yes |
| Publish projects as Terminal Launchpad apps | **Limited** | Yes |
| Schedule recurring workloads | **No** | Yes |
| Custom BQuant environments | **No** | Yes |
| Managed Git collaboration | **No** | Yes |

### Desktop hard limits (footnotes)

1. **BQL download limits** apply on Desktop — keep universes/filters tight; prefer `with_params={'mode':'cached'}` for large screens; avoid unbounded pulls.
2. Code may **not be portable** between Desktop and Enterprise versions.
3. Desktop user: run **at most 2 projects** concurrently; own **at most 200** projects.
4. Desktop app consumer: view **at most 2 apps** at once; publish **at most 200 apps**.
5. Individual project files are limited to **256 MB**. Use `/tmp` only for temporary workload-local data.
6. A Desktop BQL request can time out after **2 minutes**; narrow the request or use cached mode.
7. One owned project can have only one running instance. Avoid competing tabs/sessions that can create synchronization issues.

### Coding implications

- Prefer notebook-local workflows: BQL + Pandas + Plotly + ipywidgets.
- Do not assume Enterprise scheduling, custom images/envs, firm dataset mounts, or Git-backed multi-user workflows.
- Treat Event Studies library as **beta / not for production** (Help Center warning), even if importable.

## Build Analysis Official: Projects

```mermaid
flowchart LR
  P[Projects] --> W[Working / Save / Startup notebook]
  W --> T[Troubleshoot]
  W --> A[Publish app - Desktop limits apply]
```

### About Projects
- A BQuant project is an interactive computing workspace that you can use to explore financial datasets, test ideas, and build quantitative models. Projects provide a personal space to create, edit, and run code that investigates a particular idea, using static Python scripts or interactive formats like Jupyter notebooks.
- **Topics:** About BQuant Projects; Overview; Project files; Installed libraries; Running projects; Workload capacity; Shutting down workloads; Project owners & sharing
- **Key points:**
  - Installed libraries
  - Running projects Workload capacity
  - Shutting down workloads
  - Project owners & sharing
  - Snapshot history
  - You can shut down your workload manually from the workloads tracker.
  - A workload shuts down automatically if an opened project has been inactive for 10 minutes, or if the workload has reached its maximum runtime of 24 hours. You can keep track of a workload’s runtime in the JupyterLab timeout indicator.
  - Limited number of running projects: BQuant limits each user to two running project workloads at the same time.

### Projects Page
- You can view your projects on the Projects page. This displays a list of all the projects you own, along with project metadata:
- **Topics:** Overview; Workloads tracker; My Projects list; Details pane; Filters and search; Menu bar; Received Projects list; Filters
- **Key points:**
  - Workloads tracker
  - My Projects list Details pane
  - Filters and search
  - Received Projects list Filters
  - Archived Projects list Restore to My Projects button
  - Project actions include Favorite, Archive, and Duplicate. A project that is the source of a published app cannot be archived until the app relationship is resolved.
  - Details include last-published metadata and the Terminal app link when applicable.
  - Name: The name of the project. You provide this name when you create a project. You can rename the project by clicking the Rename button.
  - Modified: The date the project was last modified. By default, the project list is ordered from most recently modified to least recently modified. You can change this order by selecting the column header that you want to sort by.

### Working with Projects
- Projects are an interactive workspace where you can write, edit, and run code to carry out your quantitative analysis. Source code in projects also serve as the basis for BQuant published apps, which you can use to share research results, such as trading strategies, with colleagues within your firm. Snapshotting, sharing, and transferring projects 
- **Topics:** Overview; Prerequisites; Creating and reverting to a snapshot; Sending projects; Transferring projects; Publishing apps
- **Key points:**
  - Creating and reverting to a snapshot
  - Sending projects
  - Transferring projects
  - Send creates a recipient copy; transfer changes ownership and carries snapshot history. Verify permissions before transfer.
  - Recipient communities are managed through Terminal community/distribution functions such as CMTY / SPDL.
  - A project created on the Projects page. If you have not yet created a project, follow BQuant Desktop Quickstart to get started quickly.
  - Select a project and then click Create Snapshot.
  - On the Create Snapshot pop-up, enter the Snapshot Name:
  - Click Create Snapshot.

### Troubleshooting Projects
- **Kernel stays on Connecting:** run Network Diagnostics to check WebSockets. If networking is healthy, verify the selected kernel and restart the workload.
- **Kernel shows No Kernel / cells do nothing:** select or restart the kernel; if necessary, shut down and reopen the project workload.
- **BQL timeout:** Desktop requests can time out after 2 minutes. Reduce the universe/date range/items, split the request, or use `with_params={'mode': 'cached'}` where supported.
- **BQL 403 / queries do not execute:** check that the Bloomberg Terminal session is logged in and that the BBA/session connection has not changed; reconnect before changing code.
- **File Save Error:** verify the project file is below the 256 MB limit; move temporary artifacts to `/tmp` and remove oversized generated output.
- **`FileUpload` AttributeError:** treat it as a widget/version compatibility issue; verify the supported ipywidgets interface in the active environment.
- **`overflow_x` / `overflow_y` silently fail:** use the supported combined layout overflow property for the installed ipywidgets version.
- Use the Jupyter debugger for Python exceptions; BQL entitlement/field failures still require Terminal/FLDS checks.


## Build Analysis Official: Coding Workspace

### JupyterLab in BQuant
- The BQuant version of JupyterLab includes pre-configured custom and third-party extensions to provide additional functionality on top of the out-of-the-box open-source version. Bloomberg configures and manages these extensions for you, ensuring compatibility between extensions and package versions.
- What's New records the BQuant Desktop upgrade to JupyterLab **4.3.6** in July 2025.
- The ipywidgets v8 advisory warns that v7 behavior is not fully compatible. Re-test callbacks, layout properties, and upload widgets after an environment upgrade.
- Raw source snapshot identifies the managed **Standard Desktop Environment** on Ubuntu 22.04; environment details can change with Bloomberg upgrades.
- **Topics:** Overview; BQuant JupyterLab; Out-of-the-box JupyterLab; Additional resources
- **Key points:**
  - BQuant JupyterLab
  - Out-of-the-box JupyterLab Additional resources
  - Keyboard shortcuts: See Commands List in the open-source JupyterLab documentation. Shortcuts that are specific to BQuant are documented in the UI.
  - Markdown reference and tutorial: See the CommonMark website.
  - The footer exposes workload timeout (maximum runtime 24 hours) and memory usage indicators.
  - Preview code as an application before publishing; startup files define Launchpad components and initialization behavior.
  - Bloomberg supports the managed extensions; third-party Jupyter extensions are not guaranteed.
  - The captured UI documents Bloomberg Terminal theme support and English/Japanese interface languages.

### Python Version Environments
- When you create a BQuant Desktop project, you select a Python version environment. A Python version environment includes a preconfigured version of Python and supporting libraries. Your selection determines not only which Python version your project uses, but also the versions of other libraries available to you.
- **Topics:** Python Versions in BQuant Desktop; Overview; Selecting a Python version; Choosing a version; See also
- **Key points:**
  - Selecting a Python version
  - Choosing a version
  - New projects: Select the latest available version. This provides access to the latest libraries has a longer support window.
  - Ongoing projects: Choose the Python version with which you originally created your project. Changing environments can introduce unexpected issues due to library version differences.
  - Upgrading to a newer version: To upgrade to a new Python version environment, test your code in that environment before using it in production. This helps you catch compatibility issues early.

### Platform release pointers
- BQAP search, sort, and filter behavior was redesigned in May 2026.
- Dedicated BQuant Desktop connectivity over BFIN and Desktop Network Requirements are documented platform concerns; use Bloomberg diagnostics/support rather than adding notebook network workarounds.
- Canonical rolling release status lives in `21-bquant-whats-new.md`.

### Managing Python Packages
- Many data science and analysis workflows require external libraries, such as NumPy and Pandas. To make these libraries available for import inside your code, you need to install the packages. An environment is the set of installed packages available for import in your BQuant project code.
- **Topics:** Overview; Viewing all available packages; Checking for a specific package; Installing a new package; Example: Installing the PyTorch package
- **Key points:**
  - Viewing all available packages
  - Check whether a package is already available before attempting installation.
  - Use `%package list` to inspect the environment and `%package install <PACKAGE_NAME>` only for packages available on conda-forge.
  - BQuant uses the managed `%package` / micromamba workflow; **do not use pip**.
  - This project must obey `bquant-core.mdc` stack restrictions. Do not install or depend on additional packages unless the user explicitly requests it.

