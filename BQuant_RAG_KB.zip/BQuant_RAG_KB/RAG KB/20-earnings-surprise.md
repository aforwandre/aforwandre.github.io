---
topic_id: "20"
title: Investigating Earnings Surprise
role: analytical_recipe
authority_for: [earnings_surprise, contributor_revisions]
not_authority_for: [OCR_field_aliases, entitlement]
evidence_grades: [canonical, practice-derived, OCR-observed]
risk_tier: normal
routing_keywords: [earnings, EPS, surprise, revisions, contributor]
mandatory_cross_checks: [00-RAG-INDEX, 01-bql-for-equities, 05-get-started, 18-using-pandas]
restricted_sections: []
source_families: [help_center, official_script]
---

# Investigating Earnings Surprise

Dense recipe: EPS actuals/estimates, contributor revisions, prices; merge on announcement date; surprise/beat; sector and index aggregation; Plotly subplots.

Pin `AS_OF_DATE` for reproducible index membership.

> Field gate: exact-search data items in `22`; use `08` for meaning/metadata and current API/FLDS only when signatures remain unresolved.

## Desktop request and response gate

- Multi-year estimate/revision windows can exceed Desktop download or
  two-minute request limits. Start with a narrow date window/universe and use
  cached mode only where the routed item/universe supports it.
- Preserve `ID`, `DATE`, `AS_OF_DATE`, and request lineage using `18`; do not
  treat the value-only concat snippets below as a universal Arrow parser.
- Consensus Revisions OCR supports UI shape only. It cannot supply field
  aliases or parameter signatures.
- Any new estimates/revisions field requires `23` substitution review,
  including entitlement and batch breadth.

## Setup

```python
import bql
import pandas as pd
import numpy as np
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

bq = bql.Service()
AS_OF_DATE = '2023-11-06'
index_ticker = 'B500 Index'
```

```mermaid
flowchart TD
  U[members + translatesymbols] --> E[df_ests] --> M[merge ID + REVISION_DATE]
  U --> R[df_revisions] --> M
  U --> P[df_px] --> M
  U --> S[df_sector] --> M
  M --> A[Surp Beat Season returns] --> V[Plotly + sector/index agg]
```

## Universe and Descriptive

```python
universe = bq.univ.members(index_ticker, dates=AS_OF_DATE)
universe = universe.translatesymbols(targetidtype='composite')

data_items = {
    'Name': bq.data.name(),
    'Sector': bq.data.classification_name(classification_level='1'),
    'Industry Group': bq.data.classification_name(classification_level='2'),
    'Industry': bq.data.classification_name(classification_level='3'),
}
response = bq.execute(bql.Request(universe, data_items))
df_sector = pd.concat([item.df()[item.name] for item in response], axis=1)
```

## EPS Actuals, Estimates, Surprise

Shared fiscal params across all items:

```python
params = {
    'fa_period_offset': bq.func.range('-40Q', '0Q'),
    'fa_period_type': 'Q',
    'fa_filing_status': 'LR',
    'dates': AS_OF_DATE,
}
data_items = {
    'Period': bq.data.is_comp_eps_adjusted(**params, fa_act_est_data='A')['PERIOD'],
    'Act': bq.data.is_comp_eps_adjusted(**params, fa_act_est_data='A'),
    'Est': bq.data.is_eps(**params, fa_act_est_data='E', fa_adjusted='Y'),
    'Sh Out': bq.data.bs_sh_out(**params, fa_act_est_data='A'),
}
response = bq.execute(bql.Request(universe, data_items))
df_ests = pd.concat([item.df() for item in response], axis=1)

df_ests = df_ests.loc[:, ~df_ests.columns.duplicated()]
df_ests = df_ests.drop(columns=['ID_DATE', 'PERIOD_END_DATE', 'CURRENCY', 'AS_OF_DATE', 'Partial Errors'])
df_ests = df_ests[~pd.isna(df_ests['Act'])]

df_ests['Surp'] = np.where(
    np.sign(df_ests['Act']) != np.sign(df_ests['Est']),
    np.nan,
    (df_ests['Act'] - df_ests['Est']) / df_ests['Est'].abs(),
)
df_ests['Beat'] = np.where(df_ests['Surp'] > 0, 1, 0)
df_ests['Miss'] = np.where(df_ests['Surp'] < 0, 1, 0)
```

**Earnings season bucket** (align varying fiscal periods to calendar quarter):

```python
def calendar_quarter(date):
    y = date.year
    if datetime(y, 2, 16) <= date <= datetime(y, 5, 15): return y + 0.1
    if datetime(y, 5, 16) <= date <= datetime(y, 8, 15): return y + 0.2
    if datetime(y, 8, 16) <= date <= datetime(y, 11, 15): return y + 0.3
    if date >= datetime(y, 11, 16): return y + 0.4
    if date <= datetime(y, 2, 15): return y - 1 + 0.4
    return np.nan

df_ests['Season Num'] = df_ests['REVISION_DATE'].apply(calendar_quarter)
s = df_ests['Season Num'].astype(str).str
df_ests['Season'] = s[:4] + ' Q' + s[-1]
df_ests = df_ests[df_ests['Season Num'] >= 2013.3]
```

`REVISION_DATE` on actuals = announcement date.

## Contributor Revisions

`fa_period_offset='0'` aligns with quarter ending on each announcement:

```python
params = {
    'fa_period_offset': '0', 'fa_period_type': 'Q', 'fa_filing_status': 'LR',
    'fa_act_est_data': 'E', 'fa_adjusted': 'Y',
    'dates': bq.func.range(AS_OF_DATE + '-11Y', AS_OF_DATE + '+0D'),
}
eps = bq.data.is_eps(**params)
pos = bq.data.contributor_revisions(eps, revision_type='NETUP', revision_window='4W')
neg = bq.data.contributor_revisions(eps, revision_type='NETDN', revision_window='4W')
num = bq.data.contributor_count(bq.data.is_eps(**params, fill='prev'))

response = bq.execute(bql.Request(universe, {'Pos Revis': pos, 'Neg Revis': neg, 'Num Ests': num}))
df_revisions = pd.concat([item.df() for item in response], axis=1)
df_revisions = df_revisions.loc[:, ~df_revisions.columns.duplicated()]
df_revisions = df_revisions.drop(columns=['REVISION_DATE', 'PERIOD_END_DATE', 'ID_DATE'], errors='ignore')
df_revisions['Revis Momentum'] = (df_revisions['Pos Revis'] - df_revisions['Neg Revis']) / df_revisions['Num Ests']
```

## Prices and Merge Pipeline

```python
date_range = bq.func.range(AS_OF_DATE + '-11Y', AS_OF_DATE + '+0D')
response = bq.execute(bql.Request(universe, {'Px': bq.data.px_last(dates=date_range)}))
df_px = response[0].df().dropna().drop(columns=['ID_DATE', 'CURRENCY'])

df = pd.merge(df_ests, df_sector, how='left', left_index=True, right_index=True)
df = pd.merge(
    df.reset_index(), df_revisions.reset_index(), how='left',
    left_on=['ID', 'REVISION_DATE'], right_on=['ID', 'AS_OF_DATE'],
)
df = df.drop(columns=['AS_OF_DATE']).set_index(['ID', 'REVISION_DATE'])

df_px = df_px.rename(columns={'DATE': 'REVISION_DATE'}).set_index('REVISION_DATE', append=True)
day_offsets = list(range(-1, 6))
for off in day_offsets:
    tmp = df_px.rename(columns={'Px': f'Px {off}D'}).groupby('ID').shift(-off)
    df = pd.merge(df, tmp, how='left', left_index=True, right_index=True)
for off in day_offsets:
    df[f'Rtn Ann. {off}D'] = df[f'Px {off}D'] / df['Px -1D'] - 1
rtn_cols = [c for c in df.columns if 'Rtn' in c]
```

Returns base on `Px -1D` (day before announcement).

## Plotly: Template and Subplots

```python
plotly_template = {
    'layout': {
        'paper_bgcolor': '#212121', 'plot_bgcolor': '#212121',
        'font': {'color': 'white'},
        'yaxis': {'gridcolor': '#505050', 'tickformat': '0%'},
        'xaxis': {'gridcolor': '#505050', 'tickformat': '0%'},
    },
}

def build_scatter(frame, x, y, hover_data, color=None, size=None, trendline=None):
    return px.scatter(frame, x=x, y=y, hover_data=hover_data, color=color,
                      size=size, trendline=trendline, template=plotly_template, height=500)

# Distribution histograms
subplots1 = make_subplots(rows=2, cols=2, subplot_titles=('Revis Momentum', 'Ann +1 Rtns', 'Surprises'))
for i, col in enumerate(['Revis Momentum', 'Rtn Ann. 1D', 'Surp']):
    subplots1.add_trace(go.Histogram(x=df[col]), row=i // 2 + 1, col=i % 2 + 1)
subplots1.update_layout(template=plotly_template, height=800, showlegend=False)
```

## Outlier Trim and Sector Analysis

```python
def remove_outliers_iqr(frame):
    out = frame.copy()
    for col in ['Surp', 'Revis Momentum']:
        q1, q3 = out[col].quantile(0.25), out[col].quantile(0.75)
        iqr = q3 - q1
        out = out[(out[col] >= q1 - 1.5 * iqr) & (out[col] <= q3 + 1.5 * iqr)]
    return out

df_no_outliers = remove_outliers_iqr(df)
df = df.dropna(subset=['Est'])

recent = df_no_outliers.reset_index()
recent = recent[recent['Season'] == '2023 Q3']
recent['Count'] = 1
sector_avg = recent.groupby('Sector').agg({
    'Act': 'mean', 'Est': 'mean', 'Surp': 'mean',
    'Rtn Ann. 1D': 'mean', 'Revis Momentum': 'mean', 'Count': 'count',
}).reset_index()

fig_s = build_scatter(recent.sort_values('Sector'), 'Surp', 'Rtn Ann. 1D',
                      ['ID', 'Name', 'Period', 'Act', 'Est'], color='Sector')
fig_a = build_scatter(sector_avg, 'Surp', 'Rtn Ann. 1D', ['Act', 'Est'],
                      color='Sector', size='Count')

subplots2 = make_subplots(rows=1, cols=2, subplot_titles=['Stocks', 'Sector Avg'])
for tr in fig_s.to_dict()['data']:
    subplots2.add_trace(go.Scatter(tr), row=1, col=1)
for tr in fig_a.to_dict()['data']:
    subplots2.add_trace(go.Scatter(tr, showlegend=False), row=1, col=2)
subplots2.update_layout(template=plotly_template, height=600)
```

Layer `px` figures onto `make_subplots` via `.to_dict()['data']`.

## Correlation Heatmap (Per Security)

```python
df_corr = df.groupby('ID').apply(remove_outliers_iqr)
df_corr = df_corr.groupby('ID').filter(lambda g: g['Surp'].count() > 30)
df_corr = df_corr[['Surp', 'Revis Momentum', *rtn_cols]].groupby('ID').corr()
df_corr = df_corr.groupby('ID').first().drop(columns=['Surp', 'Rtn Ann. -1D'])
df_rsq = (df_corr ** 2).sort_values('Rtn Ann. 1D', ascending=False).head(12)

fig_rsq = px.imshow(df_rsq.round(2), text_auto=True, aspect='auto', color_continuous_scale='hot')
fig_rsq.update_layout(template=plotly_template, title='R-squared vs Surprise')
```

## Index and Sector Aggregation

Weight by shares outstanding before summing:

```python
df_index = df.copy()
df_index['Act'] = df_index['Sh Out'] * df_index['Act']
df_index['Est'] = df_index['Sh Out'] * df_index['Est']
agg = {'Beat': 'sum', 'Miss': 'sum', 'Act': 'sum', 'Est': 'sum'}

beat_miss_index = df_index.sort_values('Season Num').groupby('Season').agg(agg)
beat_miss_index['Beat %'] = beat_miss_index['Beat'] / (beat_miss_index['Beat'] + beat_miss_index['Miss'])
beat_miss_index['Agg Surp'] = np.where(
    np.sign(beat_miss_index['Act']) != np.sign(beat_miss_index['Est']), np.nan,
    (beat_miss_index['Act'] - beat_miss_index['Est']) / beat_miss_index['Est'].abs(),
)

fig_index = go.Figure()
fig_index.add_trace(go.Bar(x=beat_miss_index.index, y=beat_miss_index['Beat %'], name='Beat %'))
fig_index.add_trace(go.Scatter(
    x=beat_miss_index.index, y=beat_miss_index['Agg Surp'],
    name='Agg Surp', yaxis='y2', line=dict(color='firebrick'),
))
fig_index.update_layout(
    template=plotly_template, title='Index Beat % and Surprise',
    yaxis={'title': 'Beat/Miss %'},
    yaxis2={'title': 'Agg Surp', 'overlaying': 'y', 'side': 'right'},
)

beat_miss_sector = df_index.groupby(['Sector', 'Season']).agg(agg)
beat_miss_sector['Agg Surp'] = np.where(
    np.sign(beat_miss_sector['Act']) != np.sign(beat_miss_sector['Est']), np.nan,
    (beat_miss_sector['Act'] - beat_miss_sector['Est']) / beat_miss_sector['Est'].abs(),
)
fig_sector = px.bar(beat_miss_sector.reset_index(), x='Season', y='Agg Surp',
                    color='Sector', barmode='stack', template=plotly_template)
```

## Key BQL Items

| Item | Role |
|------|------|
| `is_comp_eps_adjusted` | Actual comparable EPS |
| `is_eps` | Consensus estimate (adjusted) |
| `bs_sh_out` | Shares for index weighting |
| `contributor_revisions` | NETUP/NETDN in 4W window |
| `contributor_count` | Revision momentum denominator |
| `px_last` | Daily prices |
| `classification_name` | Sector buckets |

## Project Practice Notes

- Exact-search estimate/surprise data-item names in `22`; use Terminal FLDS only for unresolved ambiguity or signatures.
- Keep notebook cells ordered so definitions run before callbacks (kernel-shared state).
- Visualization updates: prefer `with fig.batch_update():` to avoid UI flicker.
- The ingested *Consensus Estimates Revisions* script confirms the production UI shape (index/fiscal period/window/as-of controls, top upgrades/downgrades, conditional bars), but its photographed field aliases are OCR-unresolved. Generate revision BQL from the verified `contributor_revisions` / `contributor_count` recipe above, not from the archive placeholders.

---

## Help Center Cross-Check

`Investigating Earnings Surprise` Help Center extract matches this recipe (same pipeline: `members` + `translatesymbols`, shared fiscal params, sign-aware surprise, calendar-quarter season bucket, revision momentum on `fa_period_offset='0'`, price merge on `REVISION_DATE`, sector/index share-weighted aggregation). No new BQL patterns beyond what is documented above.

APIs confirmed in extract: `bq.data.bs_sh_out`, `bq.data.classification_name`, `bq.data.contributor_count`, `bq.data.contributor_revisions`, `bq.data.is_comp_eps_adjusted`, `bq.data.is_eps`, `bq.data.name`, `bq.data.px_last`, `bq.func.range`, `bq.univ.members`.

## Related White Paper

See `10-bquant-research.md` → **White Paper: Earnings Surprise Momentum Strategy** for an extended strategy notebook extract.
