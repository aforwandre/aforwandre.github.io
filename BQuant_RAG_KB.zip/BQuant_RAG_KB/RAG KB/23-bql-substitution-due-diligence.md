---
topic_id: "23"
title: BQL Substitution Due Diligence
role: governance_workflow
authority_for:
  - field_and_api_substitution_review
  - excel_api_to_bql_migration
  - entitlement_and_identity_risk
not_authority_for:
  - data_item_existence
  - api_signatures
evidence_grades:
  - canonical
  - user-confirmed
risk_tier: high
routing_keywords:
  - substitute
  - replacement
  - Excel
  - BDP
  - BDH
  - FLDS
  - entitlement
  - mapping
mandatory_cross_checks:
  - 00-RAG-INDEX
  - 06-get-data-overview
  - 08-bql-data-items
  - 22-BQuant_DataItems
restricted_sections: []
source_families:
  - workspace_policy
  - user_confirmed_incident
---

# BQL Substitution Due Diligence

## Retrieval card

Use this topic before introducing or replacing any BQL data item, universe
function, metadata accessor, CDE, Portfolio Library API, pricing source, or
Excel/API field. Named destinations stay on `25`/`26`. A **composition**
already proven on Desktop: `BUNDLE_EXAMPLES.md` Goal table first (one card).
This topic reviews fields **not** on that card; it does not prove that a
candidate exists or that its signature is valid.

An exact catalog hit is never enough. The objective is to preserve business
meaning, identity level, entitlement safety, response shape, and failure
behavior—not merely to obtain a non-null value.

## Mandatory workflow

### 1. Inventory the source requirement

Record all of the following before searching for a replacement:

- source system and form: Excel BDP/BDH, FLDS API tab, FLDS BQL tab, existing
  PyBQL, metadata column, CDE, or business formula;
- exact source mnemonic/formula and parameters;
- business role: universe, security identity, quantity, company grouping,
  issuer analytics, price, FX, status, classification, or display;
- expected input universe and yellow-key type;
- point-in-time and date/fill semantics;
- expected output type, row cardinality, metadata, and error shape;
- request breadth and frequency;
- entitlement/product family;
- required failure behavior: zero, skip, fail closed, user review, or
  account-level invalidation.

If these facts are not known and would change the implementation, ask the
user before writing code.

### 2. Classify the implementation layer

| Class | Meaning | Evidence route |
|---|---|---|
| `U` | Universe transformation or lineage mapping | Official tutorial + `07`; not `22` |
| `D` | Standard `bq.data.*` item | Exact `22` + `08` + domain recipe |
| `M` | Associated/metadata column | FLDS BQL tab or documented item metadata |
| `P` | Pandas/business calculation | Excel/business evidence + `18`; do not invent BQL |
| `C` | Existing Terminal CDE | `07` `_cde`; not an API-field bridge |
| `L` | Portfolio Library/PREP | `14` + `21` |
| `X` | Restricted or cross-product proxy | Reject |
| `?` | Unresolved | Stop and request evidence |

### 3. Search by business intent before name

For every candidate:

1. Exact-search `## token` in `CONCEPT_INDEX.md` for that candidate.
   Independent relevance review of Policy + Census. Prohibition rows are
   first-class. Co-mention is not a hop. Maximum two hops, and only along
   `next_hops_if_must_resolve` when this Request still needs them.
2. Search for **that candidate** (not a tour of every topic): the exact
   mnemonic, candidate name, synonyms, restrictions, prior incidents, and
   negative evidence.
3. Locate official tutorial patterns before inspecting similar catalog rows.
4. Exact-search `22` only for `bq.data.*` spelling/existence.
5. Search `21` for deprecation/Beta/platform status.
6. Search `16` for uncaptured source gaps.
7. Search project rules and `24` for prior rejected proxies.

Include counter-search terms such as `not`, `never`, `unresolved`,
`catalog-only`, `OCR-observed`, `REFERENCE ONLY`, `deprecated`, `Beta`,
`entitlement`, and `fail closed`.

### 4. Require user alternatives when the source has no BQL equivalent

If the source exists only in the FLDS API tab or local evidence cannot resolve
the BQL equivalent:

1. Stop before implementation.
2. Ask the user for the FLDS BQL tab and one or more candidate alternatives.
3. Do not transliterate the API mnemonic into `bq.data.*`.
4. Do not propose a field merely because its description contains a similar
   noun. Catalog example: `name_chinese_traditional()` (company name) is
   not `official_trad_local_lang_sec_nm()` (official local-language
   security name). MDX NameCN is the latter (`26`). Tutorial AIM helpers
   (`crncy()`, `security_typ()`, `ts_position()`) are not the ETF freeze
   (`25`).
5. Re-run this complete review for each user-proposed alternative.

User provision establishes a candidate, not approval.

### 5. Separate identity layers

Every mapping decision must identify all four layers:

| Layer | Question |
|---|---|
| Position/security identity | What ticker and quantity did the account actually hold? |
| Company/grouping identity | Which rows aggregate for issuer/company limits? |
| Issuer-analysis identity | Which entity supplies fundamentals or credit analytics? |
| Pricing identity | Which tradable listing supplies the required price? |

Never assume that a valid value at one layer is safe at another. A company
ticker may be correct for grouping and wrong for pricing. A parent/obligor may
return a ticker and still represent a different legal entity or market.

### 6. Define the fallback before coding

The fallback must be explicit and evidence-backed.

- Prefer fail closed with a structured diagnostic.
- Never widen the universe after an entitlement/mapping failure.
- Never switch to a different product-family proxy silently.
- Never replace the original position identity or quantity to make pricing
  work.
- Never reuse a sparse/stale/wrong-market price when the requirement says to
  use another listing.
- Zero is valid only when the business rule or status rule authorizes zero.

## Risk score

Score each dimension from 0 (resolved/low) to 5 (unacceptable/high).

| Dimension | 0 | 2 | 4 | 5 |
|---|---|---|---|---|
| Entitlement/product family | documented core use | known account entitlement | unfamiliar model/vendor family | restricted ESG/GHG/climate/SF |
| Semantic distance | same documented intent | near equivalent with FLDS | side-effect mapping | different product family as proxy |
| Batch breadth | one security | one account | daily portfolio-wide | broad market/probe extraction |
| Identity impact | identities separated | display/grouping only | pricing/listing ambiguity | changes position identity/quantity |
| Failure severity | fail closed | visible row zero/skip | stale or partial result | silent wrong price/company |
| Evidence quality | canonical resolved | script/user verified | catalog/announcement only | OCR/model memory/no evidence |

### Decision rules

- **Hard reject** when any dimension is 5 for restricted execution,
  cross-product proxy semantics, position-identity replacement, or silent
  wrong-price/wrong-company behavior.
- **Approved** only when semantics, signature, platform, entitlement, batch
  scope, identity level, and fallback are resolved with no hard reject.
- **Guarded approval** may require a narrow Desktop validation, reviewed
  override table, batching, isolated optional request, or explicit diagnostic.
- **Unresolved** when required FLDS/user evidence is absent. Do not code the
  candidate while unresolved.

The total score is an audit aid, not a way to average away a hard reject.

## Evidence gates

- `G1` — Exact source requirement and business role recorded.
- `G2` — Official-intent/tutorial search completed.
- `G3` — Exact catalog check completed for every `bq.data.*` item.
- `G4` — Signature, parameters, universe compatibility, and metadata resolved.
- `G5` — Entitlement/product family and request breadth resolved.
- `G6` — Security, grouping, issuer, and pricing identities separated.
- `G7` — Failure/fallback behavior confirmed by the user where material.
- `G8` — Every user-proposed alternative independently rescored.
- `G9` — Counter-evidence and prior-incident search completed.
- `G10` — Regression tests/static guards defined before implementation.

All applicable gates must pass.

## Known hard stops

- ESG/GHG/climate/sustainable-finance data items: no request, probe, test, or
  code generation.
- API-only Excel mnemonic mechanically converted to `bq.data.*`.
- OCR/catalog/announcement-only signature used in production.
- Default-risk, CAST parent, or integer company-ID fields used as Thai local
  listing or displayed Company Key because they happen to return a convenient
  value, except the narrow HelpDesk-guarded leftover Thai `/F` and `-R` DRSK
  pricing path in `08`/`24`. Official CAST/`id_bb_company` tabs do not change
  those identity layers.
- Company/fundamental ticker used directly as a tradable local Pricing Ticker
  without listing-level evidence.
- Pandas filtering performed after a broad sensitive request as if it reduced
  what Bloomberg had already received.

## Decision record

Use this compact record for every substitution:

```text
Decision ID:
Date:
Project:
Source field/API:
Business role:
Candidate:
Class (U/D/M/P/C/L/X/?):
Evidence:
Exact catalog result:
Signature/universe result:
Entitlement and batch scope:
Identity layers:
Fallback:
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence):
Counter-evidence:
Rejected alternatives:
User confirmations:
Decision (Approved/Guarded/Rejected/Unresolved):
Required tests:
```

## Worked approved patterns

### Company consolidation for the ETF monitor

DT110 and DT679 were replaced by the user-confirmed HelpDesk pattern
`bq.data.id().value(bq.univ.fundamentalticker(), mapby="lineage")`.
The official Company Analysis tutorial supplies the lineage pattern. The
output is a company/grouping key, not automatically a local pricing listing.

### Market status

Excel PR286 maps to catalog-confirmed `market_status()`. Desktop 2026-09-02:
do not fetch `market_status()` with Request `mode=cached` (`6166 HK Equity`
stale `Delisted`). Last-price / Last Close / zero-fallback runtime is `25`,
not this workflow file.

### Thai foreign-line pricing

Keep the AIM foreign-line identity and quantity. Use a reviewed local-listing
override, deterministic `/F` or `-R` removal with ordinary local reference
evidence and same-company validation, then leftover HelpDesk-confirmed
`bb_default_risk_obligor_ticker()` only for remaining Thai foreign lines.
Never use the company key itself as the Pricing Ticker. See `24`.

```text
Decision ID: ETF-THAI-DRSK-LEFTOVER-2026-09-01
Date: 2026-09-01
Project: ETF Capping Monitor
Source field/API: no Excel mnemonic; leftover Thai foreign-board local listing
Business role: Pricing Ticker only for unresolved `/F TB Equity` and `-R TB Equity` AIM lines
Candidate: bq.data.bb_default_risk_obligor_ticker(mode="cached")
Class: X (cross-product) used only as HelpDesk-confirmed leftover pricing mapper
Evidence: official BQL tab IMG_6671 (2026-09-01); Desktop execute IMG_6672 (2026-08-28); user-confirmed HelpDesk 2026-09-01; exact 22 row spelling only
Exact catalog result: bb_default_risk_obligor_ticker() | Bloomberg Default Risk Obligor Ticker
Signature/universe result: official `mode=null` on the data item; Desktop also used Request `with_params={'mode': 'cached'}`; leftover Thai foreign-line list only; default column is `value`; returned tickers may omit `Equity`
Entitlement and batch scope: DRSK family; HelpDesk confirmed usable; leftover Thai `/F` and `-R` only; never mixed HK/US/cash/index
Identity layers: AIM ticker/quantity unchanged; DRSK is Pricing Ticker only; company key remains Exception then fundamentalticker()
Fallback: fail closed, diagnostic, no sparse foreign-line price
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence): 3/3/2/2/2/2
Counter-evidence: 24 failure chain §4 mixed-universe DRSK; official purpose is default-risk equity ticker, not listing conversion
Rejected alternatives: CAST parent; id_bb_company(); mixed-universe DRSK; fundamental ticker as price; foreign-line price fallback; pending_position() alone as Projected
User confirmations: 2026-09-01 HelpDesk usable; official BQL tab IMG_6671; Desktop IMG_6672/6673/6674; N-NDVR yellow key is -R TB Equity
Decision: Guarded
Required tests: leftover-only apply; reject -R/local-foreign DRSK output; append Equity suffix; allowlist bb_default_risk_obligor_ticker; do not call CAST or id_bb_company in production
```

```text
Decision ID: ETF-CAST-PARENT-2026-09-01
Date: 2026-09-01
Project: ETF Capping Monitor
Source field/API: official BQL tab cast_parent_equity_ticker (IMG_6675)
Business role: none in this app; evaluated as Thai listing and as DT110/DT679 substitute
Candidate: bq.data.cast_parent_equity_ticker(mode=null)
Class: P/C (parent / capital-structure)
Evidence: official BQL tab IMG_6675; exact 22 row; user-confirmed not premium 2026-09-01; DELTA/F Desktop incident in 24
Exact catalog result: cast_parent_equity_ticker() | Capital Structure Parent Equity Ticker
Signature/universe result: mode=null; default value is string CAST parent equity ticker; ID146 CAST_PARENT_ID
Entitlement and batch scope: user-confirmed not premium; still do not request in this app
Identity layers: CAST parent is not AIM ticker, not Thai local Pricing Ticker, not HelpDesk fundamentalticker() company key
Fallback: do not call; keep Exception then fundamentalticker() then original ticker
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence): 2/5/2/5/5/2
Counter-evidence: DELTA/F returned a Taiwanese parent; official description is CAST parent, not local listing
Rejected alternatives: using CAST as Thai price or Company Key
User confirmations: 2026-09-01 official tab; not premium
Decision: Rejected for production ETF calls
Required tests: production allowlist must not contain cast_parent_equity_ticker
```

```text
Decision ID: ETF-ID-BB-COMPANY-2026-09-01
Date: 2026-09-01
Project: ETF Capping Monitor
Source field/API: official BQL tab id_bb_company (IMG_6676/6677/6678); ID035
Business role: none in this app; evaluated as Thai listing and as DT110/DT679 substitute
Candidate: bq.data.id_bb_company(mode=null)
Class: C (company identifier)
Evidence: official tab and examples; exact 22 row; user-confirmed not premium 2026-09-01
Exact catalog result: id_bb_company() | Bloomberg Company Identifier
Signature/universe result: mode=null; default value is integer; examples AAPL US Equity -> 101695, INDU Index -> 170310, members('INDU Index') one int per member
Entitlement and batch scope: user-confirmed not premium; still do not request in this app
Identity layers: integer company ID is not a yellow-key Pricing Ticker and cannot replace ticker-based Exception keys
Fallback: do not call; keep fundamentalticker() lineage for grouping
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence): 2/5/2/5/5/2
Counter-evidence: official return type Int; warrants/DRs map to underlying, not the held listing
Rejected alternatives: using ID035 as price ticker or displayed Company Key
User confirmations: 2026-09-01 official tab; not premium
Decision: Rejected for production ETF calls
Required tests: production allowlist must not contain id_bb_company
```

### Parameter form instead of a same-named item

The transferable rule from the FI Index Change duration work, 2026-11-02.

**A catalog row is a spelling, not a call.** `22` listed
`option_adj_duration_sov_crv` and `spread_duration_effective` for the measures
the project wanted, and both answered with a column present and every value
null on the index. The project spent a day treating that as a bad name. It was
not: `spread_duration_effective` is a documented, correctly-called item whose
value simply did not arrive for those bonds. **An all-null column is evidence
about the data, not about the spelling.** Two different defects wear the same
face, and the log has to print the returned column names to tell them apart.

**The measure was already reachable through a parameter.** `duration()` accepts
`duration_type='MODIFIED' | 'EFFECTIVE' | 'SPREAD'`, so three "missing items"
were parameter values on a builder the official recipes already call. The
check that finds this is cheap and was skipped:

1. Exact-search the **bare builder** (`duration`, `spread`, `yield_`) in `22`
   and in the project freeze, not only the measure's descriptive name.
2. Read the FLDS BQL tab of that builder for an `Other Values` line. A `_type`
   parameter is where alternate measures hide, because the catalog lists items
   and parameters are not items.
3. Confirm two things before implementing: the value strings (from FLDS, not
   from an assistant) and whether the values produce **distinct numbers**. A
   parameter that silently ignores its argument returns the same column several
   times, and nothing raises.

**Adding one measure can cost a request slot, so count before adding.** Four
duration columns from one builder is four slots, not one. If a request is
already at its breadth limit, replacing a no-call-site item with a parameter
value is the move that costs nothing; appending is the move that turns a
working run into a timeout.

**A breadth limit is about the request, not the field list.** When widths of
22 and 23 both timed out while 16 and 17 answered, the fix that worked was to
split one request into one request per measure family, and to keep the
model-priced family last so its failure costs only its own columns. Two rules
came with it: a group that never returned must refuse the cache (otherwise the
next run reads the incomplete month back and never retries), and a column that
arrived blank must not (otherwise every optional measure makes the month
uncacheable). Those are different failures and they must not share a branch.

```text
Decision ID: FIIDX-DURATION-2026-11-02
Date: 2026-11-02
Project: FI Index Change
Source field/API: Excel MEASURE labels DMAT / MACM / OAD / ESPD, then four duration labels
Business role: bond-level interest-rate and spread sensitivity for index change analysis
Candidate: bq.data.duration(), bq.data.duration(duration_type="MODIFIED" | "EFFECTIVE" | "SPREAD")
Class: P (parameter value on an already-frozen builder)
Evidence: operator-supplied FLDS BQL tab text 2026-11-02 (value strings); live Desktop run 2026-11-02 completed inside the three-request split; bare duration() tutorial-observed in 02
Exact catalog result: 22:7701 duration() | Duration; no modified_duration / effective_duration row exists
Signature/universe result: parameter form accepted in a Request against index members; semantics of the default and of 'SPREAD' unresolved
Entitlement and batch scope: same product family as duration/spread; no new entitlement surfaced; breadth resolved only by splitting
Identity layers: security-level measure; MACM (Macaulay) and *_contrib() rows are different measures and different identities
Fallback: if a group fails, show the month without those columns, name the group, and refuse the cache
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence): 1/3/4/1/2/2
Counter-evidence: an all-null column from the catalog spellings looked like a naming fault and was not one
Rejected alternatives: restoring option_adj_duration_sov_crv / spread_duration_effective; hb_oas_eff_durtn (holdings-based, portfolio identity); mty_dur_mid / duration_maturity (different measures); mid_oas_spread_dur_*_contrib (contributed pricing, no signature in corpus)
User confirmations: FLDS text 2026-11-02; chose all four measures; run succeeded 2026-11-02
Decision: Approved for the four duration columns
Required tests: each builder passes its own duration_type; the analytics groups partition the analytics set; a failed group keeps the other rows and refuses the cache
```

