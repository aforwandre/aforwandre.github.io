---
topic_id: "02"
title: BQL for Fixed Income
role: domain_recipe
authority_for: [credit_universes, fixed_income_bql_recipes, company_analysis_tutorial]
not_authority_for: [entitlement, release_status, catalog_existence]
evidence_grades: [canonical, script-verified, practice-derived, OCR-observed]
risk_tier: normal
routing_keywords: [credit, bonds, debt, holders, issuerof, fundamentalticker]
mandatory_cross_checks: [00-RAG-INDEX, 08-bql-data-items, 18-using-pandas, 22-BQuant_DataItems]
restricted_sections: [sustainable_finance_material]
source_families: [help_center, official_script]
---

# BQL for Fixed Income

**AI quick map**
- `Setup` — service and request pattern
- `Bond Snapshot` / `Multi ID` — single and mixed identifiers
- `Index Analytics (universe_type)` — projected versus returns analytics
- `Dates / Yield Transforms` — ranges, fill, change calculations
- `Universes` — bonds, members, debt/issuedby, filtered bond universes
- `Ratings / Spreads / Cashflows Pointers` — route detailed use cases to `11`
- `Group / Rank / Z-Score FI Examples` — grouped FI analytics
- `Production Recipes from Official Scripts` — ownership, direct loans, issuer curves, securitized drill-down
- `Project Practice Notes: Index Membership Diff...` — metadata-safe differences, MBS/TBA, month-end tracking

**Field gate:** exact-search data-item names in `22`; use `08` for meaning/metadata and current API/FLDS only when signatures remain unresolved.

---

## Setup

```python
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta
import bql

bq = bql.Service()
```

### What's New capability map (2026-07-25 snapshot)
- Real-time new-issue screening aligned with SRCH/PREL workflows (June 2026).
- Enhanced bond/loan issuer and CAST ultimate-parent mapping (May 2026).
- Private Credit, repo/forward pricing, expanded municipal ratings/fund mapping, and longer cross-currency spread/yield history.
- US BDC Aggregate Index announcement: `BDCUSAGG Index`.

These are release-discovery pointers, not verified signatures. Exact-search announced data-item names in `22`, then use `08` and current API/FLDS only for unresolved semantics or signatures.

**Request pattern**

```python
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

---

## Bond Snapshot

**Single bond — name**

```python
universe = 'ZS7759443 Corp'
data_item = bq.data.name()
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Single bond (FIGI) — static fields**

```python
universe = 'BBG00NWNF0K4'
data_items = {
    'Issue Date': bq.data.issue_dt(),
    'Maturity': bq.data.maturity(),
    'Issuer': bq.data.company_corp_ticker(),
    'Payment Rank': bq.data.payment_rank(),
    'Country of Risk': bq.data.cntry_of_risk(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

---

## Multi ID

```python
universe = [
    'EJ729042 Corp',    # Bloomberg ticker
    'US92556HAE71',     # ISIN
    '92556HAB3',        # CUSIP
    'BBG00G38H326',     # FIGI
]
data_items = {'Spread': bq.data.spread(spread_type='OAS')}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

---

## Index Analytics (universe_type)

| `universe_type` | Use |
|---|---|
| `'projected'` | Dynamic daily eligible set — most published index analytics |
| `'returns'` | Static monthly rebalance set — total return decomposition |

```python
universe = ['GLOAN Index', 'ELOAN Index']
data_items = {
    'Name': bq.data.name(),
    'Currency': bq.data.crncy(),
    'Market Value': bq.data.market_value(universe_type='projected'),
    'Member Count': bq.data.member_count(universe_type='projected'),
    'Coupon': bq.data.cpn(universe_type='projected'),
    'Amt Outstanding': bq.data.amt_outstanding(universe_type='projected'),
    'Total Return MTD': bq.data.total_return(
        universe_type='returns', calc_interval='mtd'
    ),
    'Coupon Return MTD': bq.data.total_return(
        universe_type='returns', calc_interval='mtd', return_type='cpn'
    ),
    'Currency Return MTD': bq.data.total_return(
        universe_type='returns', calc_interval='mtd', return_type='currency'
    ),
    'Price Return MTD': bq.data.total_return(
        universe_type='returns', calc_interval='mtd', return_type='price'
    ),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

---

## Dates / Yield Transforms

**Point-in-time price**

```python
universe = 'ZS7759443 Corp'
date = '2022-12-07'
data_item = {'Price': bq.data.px_last(dates=date)}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Price time series — dropna**

```python
universe = 'ZS7759443 Corp'
date_range = bq.func.range('2023-12-01', '2023-12-14')
data_item = {'Price': bq.data.px_last(dates=date_range).dropna()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Yield net change over last week (fill gaps)**

```python
universe = 'ZS7759443 Corp'
last_week = bq.func.range('-1w', '0d')
data_item = {'Yield': bq.data.yield_(dates=last_week, fill='prev').net_chg()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

---

## Universes

### bonds() — issuer bond chains from equity tickers

```python
universe = bq.univ.bonds(['AAPL US Equity', 'MSFT US Equity'])
data_items = {
    'Bond Name': bq.data.name(),
    'Issuer': bq.data.issuer(),
    'OAS': bq.data.spread(spread_type='OAS'),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### members() — index constituents + backdate

```python
universe = bq.univ.members('LUACTRUU Index')
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()

# backdated loan index membership
universe_loans = bq.univ.members('I39493EU Index', dates='-1m')
request = bql.Request(universe_loans, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()
```

### debt() / issuedby — capital structure scoping

```python
# Entity-level debt (not just equity-linked chain)
universe = bq.univ.debt('PARA US Equity', issuedby='ENTITY')
request = bql.Request(universe, {'Asset Class': bq.data.srch_asset_class()})
response = bq.execute(request)
df = response[0].df()

# Filter issuer debt to loans only
universe = (
    bq.univ.debt(['VOD LN Equity'])
    .filter(bq.data.srch_asset_class() == 'Loans')
)
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()
```

### bondsuniv() + filter — global active bond screen

```python
universe = (
    bq.univ.bondsuniv('Active')
    .filter(
        (bq.data.cpn_typ() == 'FIXED')
        .and_(bq.data.classification_name() == 'Financials')
        .and_(bq.data.maturity() < '1M')
        .and_(bq.data.bb_composite() >= 'AA-')
    )
)
request = bql.Request(universe, {'Spread': bq.data.spread(spread_type='OAS')})
response = bq.execute(request)
df = response[0].df()
```

### Issue amount filter on index members

```python
amt_issued = bq.data.amt_issued(currency='usd')
universe = (
    bq.univ.members('LUACTRUU Index')
    .filter(amt_issued > 500e6)
)
request = bql.Request(universe, {'Ammount Issued': amt_issued})
response = bq.execute(request)
df = response[0].df()
```

### Private portfolio & saved list

```python
portfolio = bq.univ.members('your_portfolio_id', type='PORT')
data_items = {
    'Yield': bq.data.yield_(),
    'Weights': bq.data.id()['WEIGHTS'],
}
# request = bql.Request(portfolio, data_items)
# response = bq.execute(request)
# df = pd.concat([x.df()[x.name] for x in response], axis=1)

universe = bq.univ.savedlist(name='Watchlist', source='security_worksheets')
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()
```

**Weights key case:** `bq.univ.members()` → `bq.data.id()['weights']` (lowercase); `bq.univ.holdings()` / portfolios → `['WEIGHTS']`.

---

## Ratings / Spreads / Cashflows Pointers

**Spread types (verified in quickstart):** `OAS`, `ASW`, `I` (I-spread).

```python
oas = bq.data.spread(spread_type='OAS')
asw = bq.data.spread(spread_type='ASW')
isprd = bq.data.spread(spread_type='I', dates=bq.func.range('-1m', '0d'), fill='prev')
```

**Rating aggregation**

```python
median_yld_by_rating = (
    bq.data.yield_()
    .group(bq.data.rating())
    .median()
)
```

**Cashflows** (detail in **`11-sample-notebooks.md`**):

```python
# Single bond projected cashflows
universe = 'EC527035 Corp'
request = bql.Request(universe, {'Principal': bq.data.cashflows()})
response = bq.execute(request)
df = response[0].df()

# Historical + projected via settle_dt
request = bql.Request(universe, {'Principal': bq.data.cashflows(settle_dt='2022-02-28')})

# Date window filter
cashflows = bq.data.cashflows()
data_item = {
    'Principal': cashflows.matches(
        cashflows['date'].between('2025-01-01', '2030-01-01')
    )
}

# Index members — aggregate by year
universe = bq.univ.members('I00108US Index')
year = bq.data.cashflows()['date'].year()
data_items = {
    'Principal': bq.data.cashflows()['value'].group(year).sum(),
    'Interest': bq.data.cashflows()['interest'].group(year).sum(),
}
```

---

## Group / Rank / Z-Score FI Examples

### Median OAS by maturity year (pharma issuers)

```python
universe = bq.univ.bonds(['NOVN SW Equity', 'ROG SW Equity', 'GSK LN Equity'])
oas_spread = bq.data.spread(spread_type='OAS')
maturity_year = bq.data.maturity().year()
oas_spread_by_year = oas_spread.group(maturity_year).median()

request = bql.Request(universe, {'Median OAS by Year (bp)': oas_spread_by_year})
response = bq.execute(request)
df = response[0].df()
```

### Median yield by rating — equity screen → bonds()

```python
universe = (
    bq.univ.members('SPX Index')
    .filter(
        (bq.data.net_debt_to_ebitda(fa_period_type='a') >= 3)
        .and_(bq.data.classification_name() != 'Financials')
    )
    .bonds()
    .filter(
        (bq.data.cpn_typ() == 'FIXED')
        .and_(bq.data.maturity() > '10Y')
    )
)
median_yld_by_rating = (
    bq.data.yield_()
    .group(bq.data.rating())
    .median()
)
request = bql.Request(universe, {'Median Yield by Rating': median_yld_by_rating})
response = bq.execute(request)
df = response[0].df()
```

### ASW percentile (cut + ungroup)

```python
universe = bq.univ.bonds('VOD LN Equity')
asw = bq.data.spread(spread_type='ASW')
data_item = {'Percentile': asw.group().cut(100).ungroup()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

### Top 10 HY spread wideners (I-spread net chg)

```python
sprd = bq.data.spread(
    spread_type='I',
    dates=bq.func.range('-1m', '0d'),
    fill='prev',
)
sprd_chg = sprd.net_chg()
universe = (
    bq.univ.members('LF98TRUU Index')
    .filter(sprd_chg.grouprank(order='desc') <= 10)
)
request = bql.Request(universe, {'Spread Change': sprd_chg.groupsort()})
response = bq.execute(request)
df = response[0].df()
```

### Energy sector z-score outliers (LBUSTRUU)

```python
universe = bq.univ.members('LBUSTRUU Index')
sector = bq.data.classification_name('BCLASS', '3')
filter_sector = sector == 'Energy'
filtered_universe = bq.univ.filter(universe, filter_sector)

spread_chg = bq.data.spread(dates=bq.func.range('-1w', '0d'), fill='prev').pct_chg()
spread_zscore = spread_chg.groupzscore()
spread_zscore_abs_rank = spread_zscore.abs().grouprank()
filtered_universe2 = bq.univ.filter(filtered_universe, spread_zscore_abs_rank <= 5)

req = bql.Request(filtered_universe2, {'Z-Spread Outliers': spread_zscore.groupsort()})
res = bq.execute(req)
df = res[0].df()
```

### Rolling weighted average discount margin by sector

```python
universe = bq.univ.members('I39494 Index')
sector = bq.data.classification_name(
    classification_scheme='bclass',
    classification_level='3',
)
rolling_avg_disc_margin = (
    bq.data.disc_margin(fill='prev')
    .group(sector)
    .wavg(bq.data.id()['weights'].group(sector))
    .rolling(iterationdates=bq.func.range('-1y', bq.func.today(), frq='m'))
)
request = bql.Request(universe, {'Rolling 1m Avg DM': rolling_avg_disc_margin})
response = bq.execute(request)
df = response[0].df()
```

---

## Production Recipes from Official Scripts (2026-08-26 ingest)

These recipes distill four user-supplied official CREDIT applications. CREDIT universe grammar is intentionally separate from EQUITY: do not copy an equity `members`/fundamental pattern into bonds, loans, holders, curves, or mortgages.

### Production Recipe: Bond / Loan Ownership

**Evidence:** canonical single-instrument `holders()` behavior from the Private Credit tutorial, reinforced by the *Bond Ownership Dashboard* application.

`holders()` accepts one instrument per universe. Batch ownership work by building one request per bond/loan and preserving the source instrument on every response.

```python
def build_holder_request(instrument):
    universe = bq.univ.holders(instrument, view='lowest')
    items = {
        'Instrument': bq.data.id()['orig_ids'],
        'Holder Name': bq.data.id()['holder_name'],
        'Position': bq.data.id()['position'],
        'Market Value': bq.data.id()['reported_market_value'],
    }
    return bql.Request(universe, items)

requests = [build_holder_request(instrument) for instrument in instruments]
responses = list(bq.execute_many(requests))

frames = []
for instrument, response in zip(instruments, responses):
    frame = pd.concat(
        [item.df()[item.name] for item in response],
        axis=1,
    )
    frame['Requested Instrument'] = instrument
    frames.append(frame.reset_index())

ownership = pd.concat(frames, ignore_index=True)
```

Production extensions from the dashboard:

- Use `view='Summary'` for institution-level ownership and `view='Lowest'` for fund-level detail; do not concatenate them as if they had the same grain.
- Keep **institution**, **fund**, and **underlying holding detail** as separate shapes/tabs.
- Compute ownership change only after aligning holder identity and observation date.
- Defer fund look-through until a user selects an aggregate holder row; this avoids downloading every fund constituent.
- Treat missing detailed holdings as a valid empty state, not an exception.
- Use bounded batches and an `on_request_error` callback for long instrument lists.
- A dated ownership comparison requires two explicit `holders(..., dates=...)` snapshots. Preserve both snapshot dates before calculating changes.

Do not replace `holders()` with equity/fund `holdings()`: they answer different questions.

### Production Recipe: Holder-Implied Direct-Loan Price

**Evidence:** canonical Private Credit tutorial, used as a building block for *BDC Direct Loan Pricer*.

```python
holder_rows['Implied Price'] = (
    holder_rows['Market Value'] / holder_rows['Position']
) * 100
holder_rows = holder_rows.dropna(subset=['Implied Price'])
```

Use this only when `Market Value` and `Position` share the same holder/reporting basis. The BDC application adds universe modes, loan-type/sector/spread/holder filters, portfolio selection, and chart/grid callbacks; those are UI composition patterns, not evidence that every BDC or loan universe supports identical fields.

Recommended separation:

```text
universe adapter -> verified loan IDs
holder requests -> holder-level observations
calculation -> implied price / summary statistics
filters -> local Pandas filtering
view -> chart + selectable detail grid
```

### Production Recipe: Issuer Curve with Historical Comparisons

**Evidence:** script-verified composition from *Bond Curves Comparison with History*, using the canonical bond-chain/curve concepts in this file.

1. Resolve the issuer or explicit bond universe.
2. Pull the cross-sectional bond descriptors and selected pricing metric for one date.
3. Apply currency, sector, coupon, maturity, rating, and amount filters before regression.
4. Fit the selected curve/regression to the filtered points.
5. Store each historical snapshot independently; never mutate the current snapshot into a historical one.
6. Overlay current and selected historical curves, then bind point clicks to bond detail.

The curve app uses a conservative rating waterfall for peer selection: Bloomberg, then S&P, Moody's, and Fitch normalized scales, skipping missing/NR observations. If no valid rating bucket exists, return an intentionally empty universe rather than dropping the rating filter and downloading a broad bond universe.

```python
def valid_rating(value):
    return (value != 24).and_(value != bql.NA)

consolidated_rating = bq.func.if_(
    valid_rating(bbg_rating),
    bbg_rating,
    bq.func.if_(
        valid_rating(sp_rating),
        sp_rating,
        bq.func.if_(
            valid_rating(moodys_rating),
            moodys_rating,
            bq.func.if_(
                valid_rating(fitch_rating),
                fitch_rating,
                bql.NA,
            ),
        ),
    ),
)
```

Desktop-safe lazy-load pattern:

```text
render controls disabled
-> user chooses universe
-> first explicit Run loads bonds
-> enable data-dependent controls
-> field/date changes update only the affected traces
```

The application supports multiple regression choices, but exact regression parameter values remain governed by the verified recipes/API references. Do not infer a regression signature from chart labels.

### Production Recipe: Securitized-Product Screen and Drill-Down

**Evidence:** canonical `mortgagesuniv` tutorial plus application composition from *Asset-backed Security Analysis*.

Use two request levels:

- **Screen request:** a tightly filtered `mortgagesuniv` universe with only grid/sort fields.
- **Single-security request:** expensive scenario/cashflow analytics only after the user selects one result.

```python
screen_universe = bq.univ.filter(
    bq.univ.mortgagesuniv('all'),
    screen_predicate,
)
screen_response = bq.execute(
    bql.Request(
        screen_universe,
        screen_items,
        with_params={'mode': 'cached'},
    )
)
```

Production rules:

- Keep universe filters and chart-axis selectors separate.
- Validate that both selected axes exist and are numeric before plotting.
- Register result observers once; repeated `Run` clicks must not stack callbacks.
- Use a single-security detail query for scenario-dependent fields.
- Normalize preliminary/provisional rating labels before grouping; the application strips a trailing `(P)` marker and whitespace.
- WAL field/signature ambiguity remains FLDS-gated as documented in the securitized-products tutorial below.

### CREDIT/EQUITY boundary checklist

Before generating:

- A company ticker is not yet a bond universe: explicitly call `bonds()` or entity `debt()`.
- An index can contain equities, bonds, or loans: confirm constituent instrument type before selecting fields.
- Bond ownership uses `holders(single_instrument)`; fund constituents use `holdings(fund)`.
- Curve members and bond chains have cross-sectional shapes that differ from equity price matrices.
- Ratings/spreads/cashflows often carry metadata and scenario/date columns; normalize response shape before joins.
- Never assume the equity weights casing rule describes every credit universe; use the exact universe recipe.

---

## Diagrams

### Membership-diff safe flow (do NOT use setdiff when weights needed)

```mermaid
flowchart TD
    A[Pick index + two month-end business dates] --> B["univ_latest = members(index, dates=me1)"]
    A --> C["univ_previous = members(index, dates=me2)"]
    B --> D["BQL pull each universe independently"]
    C --> D
    D --> E["df_latest / df_previous with id weights metadata"]
    E --> F["Pandas: ~index.isin for added/deleted"]
    F --> G[Optional MBS/TBA split via security_typ + Mtge ID mask]
    G --> H[Display + CSV export]
    X["AVOID: univ_latest.setdiff(univ_previous)"] -.->|strips weights| Y[ResponseError on id weights]
```

### FI universe construction

```mermaid
flowchart LR
    E[Equity tickers] --> B[bq.univ.bonds issuers]
    I[Index ticker] --> M[bq.univ.members dates]
    G[Global screen] --> U[bq.univ.bondsuniv Active]
    B --> F[".filter cpn_typ rating maturity ..."]
    M --> F
    U --> F
    D[bq.univ.debt issuedby=ENTITY] --> F
    F --> R[bql.Request + execute]
```

---

## Project Practice Notes: Index Membership Diff, MBS/TBA Isolation, Monthly Rebalance Tracker

### Critical Trap: `setdiff()` Strips Metadata

Although BQL supports `universe.setdiff()`, the server-side set operation reduces the universe to bare string IDs and **strips hidden member attributes** such as index weights (`id()['weights']`). Subsequent weight access raises:

`ResponseError: called without required column(s)`

### Correct Pattern: Fetch Separately + Local Pandas Diff

1. Pull each month-end universe independently so embedded weight snapshots are preserved.
2. Compute set difference locally with Pandas:

```python
df_added = df_latest[~df_latest.index.isin(df_previous.index)]
df_deleted = df_previous[~df_previous.index.isin(df_latest.index)]
```

### Month-End Business Day Correction

Bloomberg index rebalancing (MEMB) locks to the **last business day** of the month. Using a calendar month-end that falls on a weekend can pull the next month's projected universe and bias the denominator.

```python
# Roll calendar month-end back to last valid business day (excludes Sat/Sun)
latest_completed_me = pd.bdate_range(end=calendar_month_end, periods=1)[0].strftime('%Y-%m-%d')
```

### MBS Roll / TBA Isolation

Global aggregate indices contain large US MBS/TBA books. Roll month changes codes and creates false "added/deleted" noise for IG credit / government analysis.

Practical filters:

- Sector (`classification_name`) is often `None` for MBS.
- `security_typ` often looks like `MBS 30yr`.
- Bloomberg IDs frequently contain `Mtge`.

```python
# Always use na=False so None sectors do not crash string filters
tba_mask = (
    df['Sec_Type'].str.contains('MBS|TBA|Pool', case=False, na=False)
    | df.index.to_series().str.contains('Mtge', case=False, na=False)
)
df_clean, df_tba = df[~tba_mask], df[tba_mask]
```

### Weights Key Case Rule

- `bq.univ.members()` → `bq.data.id()['weights']` (lowercase)
- `bq.univ.holdings()` → `bq.data.id()['WEIGHTS']` (uppercase)

### Masterpiece Case: Global Aggregate Monthly Constituent Change Tracker

```python
"""
BQNT: Global Aggregate Bond Index -- Monthly Constituent Change Tracker (V4.3)
======================================================================
"""
import bql
import pandas as pd
from IPython.display import display

bq = bql.Service()

# 1. Parameters & Business Date Boundary
index_ticker = 'LEGATRUU Index'

today = pd.Timestamp.today().normalize()
if today.is_month_end:
    c_me1 = today
    c_me2 = today - pd.offsets.MonthEnd(1)
else:
    c_me1 = today - pd.offsets.MonthEnd(1)
    c_me2 = today - pd.offsets.MonthEnd(2)

latest_completed_me = pd.bdate_range(end=c_me1, periods=1)[0].strftime('%Y-%m-%d')
previous_me = pd.bdate_range(end=c_me2, periods=1)[0].strftime('%Y-%m-%d')

print(f"=== {index_ticker} Constituent Change Analysis ===")
print(f"Comparison period: {previous_me} -> {latest_completed_me}\n")

# 2. Universe Definition (independent pulls preserve hidden metadata)
univ_latest = bq.univ.members(index_ticker, dates=latest_completed_me)
univ_previous = bq.univ.members(index_ticker, dates=previous_me)

# 3. Data Items (strict mnemonic + suffix rules)
data_items = {
    'Name': bq.data.name(),
    'Sector': bq.data.classification_name(),
    'Country': bq.data.country_iso(),
    'Sec_Type': bq.data.security_typ(),
    'Weight': bq.data.id()['weights'],          # lowercase for members()
    'ISIN': bq.data.id_isin()['value'],
    'SEDOL': bq.data.id_sedol1()['value'],      # id_sedol1, not id_sedol
    'Currency': bq.data.crncy(),
    'Coupon': bq.data.cpn().replacena(0),
    'Maturity Date': bq.data.maturity(),
    'OAS': bq.data.spread(spread_type='OAS').replacena(9999),
}

# 4. Core helpers
def safe_extract(response, label):
    if response is None:
        print(f"WARNING [{label}] BQL returned None.")
        return pd.DataFrame()

    frames = []
    for item in response:
        item_df = item.df()
        if item_df.empty or item.name not in item_df.columns:
            continue
        frames.append(item_df[item.name])

    if not frames:
        return pd.DataFrame()

    df = pd.concat(frames, axis=1)
    df.index.name = 'ID'
    df = df.loc[:, ~df.columns.duplicated()]

    for col in ['ISIN', 'SEDOL']:
        if col in df.columns:
            df[col] = df[col].fillna('N/A')

    return df


def run_request(universe, label):
    try:
        req = bql.Request(universe, data_items, with_params={'mode': 'cached'})
        res = bq.execute(req)
        return safe_extract(res, label)
    except Exception as e:
        raise RuntimeError(f"ERROR BQL execution failed [{label}].") from e


# 5. Execution & Pandas set difference
print("Step 1: Extracting constituents from BQL (Please wait)...\n")
df_latest = run_request(univ_latest, "Latest Month")
df_previous = run_request(univ_previous, "Previous Month")

print("Step 2: Calculating added and deleted bonds via Pandas...\n")
if not df_latest.empty and not df_previous.empty:
    df_added = df_latest[~df_latest.index.isin(df_previous.index)].copy()
    df_deleted = df_previous[~df_previous.index.isin(df_latest.index)].copy()

    def split_tba(df):
        if df.empty:
            return df, df
        df = df.sort_values('Weight', ascending=False)
        tba_mask = (
            df['Sec_Type'].str.contains('MBS|TBA|Pool', case=False, na=False)
            | df.index.to_series().str.contains('Mtge', case=False, na=False)
        )
        return df[~tba_mask], df[tba_mask]

    df_added_clean, df_added_tba = split_tba(df_added)
    df_deleted_clean, df_deleted_tba = split_tba(df_deleted)
else:
    df_added_clean, df_added_tba = pd.DataFrame(), pd.DataFrame()
    df_deleted_clean, df_deleted_tba = pd.DataFrame(), pd.DataFrame()

# 6. UI output
print("=" * 60)
print(f"SUMMARY: {index_ticker}")
print(f"  [Standard Bonds]")
print(f"    Added:   {len(df_added_clean)}")
print(f"    Deleted: {len(df_deleted_clean)}")
print(f"    Net:     {len(df_added_clean) - len(df_deleted_clean):+d}")
print(f"  [TBA & MBS Panel]")
print(f"    Added:   {len(df_added_tba)}")
print(f"    Deleted: {len(df_deleted_tba)}")
print("=" * 60 + "\n")

if not df_added_clean.empty:
    print(f"[ADDED] Standard Bonds ({latest_completed_me}):")
    display(df_added_clean.head(10))

if not df_added_tba.empty:
    print(f"[ADDED] TBA & MBS Standalone List (Top 5):")
    display(df_added_tba.head(5))

# 7. CSV export (utf-8-sig for Excel)
print("\nStep 3: Exporting results to CSV for Manual Copy-Paste...\n")
safe_ticker = index_ticker.replace(' ', '_')

added_clean_csv = f"{safe_ticker}_Added_Bonds_{latest_completed_me}.csv"
added_tba_csv = f"{safe_ticker}_Added_TBA_{latest_completed_me}.csv"
deleted_clean_csv = f"{safe_ticker}_Deleted_Bonds_{latest_completed_me}.csv"
deleted_tba_csv = f"{safe_ticker}_Deleted_TBA_{latest_completed_me}.csv"

if not df_added_clean.empty:
    df_added_clean.to_csv(added_clean_csv, encoding='utf-8-sig')
if not df_added_tba.empty:
    df_added_tba.to_csv(added_tba_csv, encoding='utf-8-sig')
if not df_deleted_clean.empty:
    df_deleted_clean.to_csv(deleted_clean_csv, encoding='utf-8-sig')
if not df_deleted_tba.empty:
    df_deleted_tba.to_csv(deleted_tba_csv, encoding='utf-8-sig')

print(f"CSV files generated with prefix: {safe_ticker}")
print("[DLP Access SOP]: Double-click CSV on the left, Ctrl+A, Ctrl+C, paste into local Excel.")
```

---

## Help Center Example Recipes (Fixed Income)

Dense cards curated from BQuant Desktop Help Center HTML snapshots in `RAG KB/Raw source/`. Screening-focused subset: `12-bql-fixed-income-screening.md`.

```mermaid
flowchart TB
    subgraph spread["Spread / heatmap"]
        CSH[Credit Spread Heatmap]
        MNI[Muni New Issue Spreads]
        XCCY[XCCY Historical Spread]
    end
    subgraph rv["Relative value / pairs"]
        BPRV[Bond Pair RV]
        RVS[Relative Value Screening]
        TOMSRV[TOMS Relative Value]
    end
    subgraph liq["Liquidity"]
        BLS[Bond Liquidity Shifts]
        XCCY
    end
    subgraph curve["Curves / issuer"]
        BSC[Bond Sector Curve]
        IOTR[Issuer On-the-run]
        TYC[Treasury Yield Curve]
    end
    subgraph credit["Credit risk"]
        CDS[CDS-Driven Risk]
        DRM[Default Risk Monitor]
        CFS[Credit Factor Scoring]
    end
    spread --> rv
    rv --> credit
    curve --> spread
```

### Bond Liquidity Shifts Across Sectors

Tracks monthly LQA liquidity scores for index-member bonds by BICS sector, buckets bonds into liquidity tiers, and flags tier migrations month over month.

**APIs:** `bq.data.bics_level_1_sector_name`, `bq.data.classification_name`, `bq.data.id`, `bq.data.lqa_liquidity_score`, `bq.data.liquidity_sector`, `bq.data.long_comp_name`, `bq.data.name`, `bq.func.range`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()
index_name = 'INDU Index'
sector = 'Financials'

time_range = bq.func.range('-1M', '0D', frq='M')
lqa_score = bq.data.lqa_liquidity_score(dates=time_range)

universe = (
    bq.univ.members(index_name)
    .filter(bq.data.classification_name('BICS', '1') == sector)
    .bonds(issuedby='Credit_Family')
)
data_items = {
    'Bond Info': bq.data.name(),
    'Issuer': bq.data.long_comp_name(),
    'LQA Sector': bq.data.liquidity_sector(),
    'LQA Score': lqa_score,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response[:3]], axis=1)
df = df.join(response[3].df(), how='right')
df = df.groupby('ID').filter(lambda x: not any(x['LQA Score'] == 0))
# ... UI omitted: qcut tiers, migration grid, sector dropdown ...
```

### Bond Pair Relative Value

Pulls historical spread/yield/price metrics for a bond list, builds pairwise differentials and rolling z-scores, and highlights top absolute z-score pairs in heatmaps with drill-down time series.

**APIs:** `bq.data.crncy`, `bq.data.disc_margin`, `bq.data.id`, `bq.data.issue_dt`, `bq.data.maturity`, `bq.data.mty_years_tdy`, `bq.data.name`, `bq.data.price`, `bq.data.spread`, `bq.data.ticker`, `bq.data.yield_`, `bq.func.range`, `bq.univ.bonds`

```python
import bql

bq = bql.Service()

universe = bq.univ.bonds('AAPL US Equity', includepreliminarysecurities=True).filter(
    (bq.data.crncy() == 'USD')
    .and_(bq.data.maturity() > '5Y')
    .and_(bq.data.issue_dt() < '-90D')
)
data_item = bq.data.spread(spread_type='Z')
data_item = data_item.with_additional_parameters(
    dates=bq.func.range('-180d', '0d'),
    fill='prev',
    pricing_source='BVAL',
)
data_items = {
    'Z-Spread': data_item,
    'name': bq.data.name(),
    'time_to_maturity': bq.data.mty_years_tdy(),
    'tickers': bq.data.ticker(),
}
response = bq.execute(bql.Request(universe, data_items))
df = response.get('Z-Spread').df()
df = df.join(response.get('name').df())
df = df.join(response.get('time_to_maturity').df())
# ... UI omitted: pairwise diff, rolling z-score heatmap, pair charts ...
```

### Bond Sector Curve Analysis

Fits Nelson-Siegel-Svensson yield curves to a single issuer's bond chain and overlays a same-rating sector benchmark curve from `bondsuniv` for relative curve shape comparison.

**APIs:** `bq.data.amt_outstanding`, `bq.data.bics_level_1_sector_name`, `bq.data.classification_name`, `bq.data.cntry_of_risk`, `bq.data.cpn_typ`, `bq.data.credit_rating`, `bq.data.crncy`, `bq.data.duration`, `bq.data.id`, `bq.data.maturity`, `bq.data.rating`, `bq.data.regression`, `bq.data.yield_`

> Catalog exception: `credit_rating()` is official-example-observed but absent from `22`. Do not substitute `bond_rating()` without confirming return scale and parameters via current API/FLDS.

```python
import pandas as pd
import bql

bq = bql.Service()

filtering_criteria = (
    (bq.data.amt_outstanding() > '500M')
    .and_(bq.data.cpn_typ() == 'FIXED')
    .and_(bq.data.crncy() == 'USD')
    .and_(bq.data.maturity() > '6M')
    .and_(bq.data.cntry_of_risk() == 'US')
)
company_bond_univ = bq.univ.bonds('AAPL US Equity', issuedby='credit_family').filter(
    filtering_criteria
)
data_items = {
    'duration': bq.data.duration(fill='prev'),
    'yield': bq.data.yield_(fill='prev'),
}
response = bq.execute(bql.Request(company_bond_univ, data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1).sort_values('duration')
durations = df['duration'].tolist()

regressions = []
for duration in durations:
    regression = bq.data.regression(
        reg_by=bq.data.duration().group(),
        reg_value=bq.data.yield_().group(),
        regression_points=duration,
        regression_type='nelson_siegel_svenson',
    )
    regressions.append(regression)
sector_univ = bq.univ.bondsuniv('active').filter(
    filtering_criteria
    .and_(bq.data.credit_rating() == 'A')
    .and_(bq.data.bics_level_1_sector_name() == 'Technology')
)
# ... UI omitted: sector NSS overlay chart ...
```

### CDS-Driven Risk Dynamics

Links issuer CDS spreads to index-member bonds via `bq.univ.cds` lineage mapping, normalizes OAS/yield/duration/CDS jointly, and clusters names to surface risk-regime shifts over time.

**APIs:** `bq.data.bics_level_1_sector_name`, `bq.data.cds_spread`, `bq.data.classification_name`, `bq.data.duration`, `bq.data.id`, `bq.data.security_des`, `bq.data.spread`, `bq.data.yield_`, `bq.func.range`, `bq.univ.cds`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()
index = 'INDU Index'
sector = 'Technology'
tenor = '5Y'
date_range = bq.func.range('-1Y', '0D', frq='CM')

universe = bq.univ.members(index).filter(
    bq.data.classification_name('BICS', '1') == sector
)
cds_spread = bq.data.cds_spread(dates=date_range)
issuer_cds_spread = cds_spread.value(bq.univ.cds(tenor=tenor), mapby='LINEAGE')

data_items = {
    'CDS Spread': issuer_cds_spread,
    'Name': bq.data.security_des(),
    'Spread': bq.data.spread(spread_type='OAS', dates=date_range),
    'Yield': bq.data.yield_(dates=date_range),
    'Duration': bq.data.duration(dates=date_range),
}
response = bq.execute(
    bql.Request(universe, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
)
df = pd.concat([item.df() for item in response[2:]], axis=1)
df = df.join(response.get('Name').df()[['Name']])
cds = response.get('CDS Spread').df()
# ... UI omitted: winsorize, k-means clusters, PCA scatter ...
```

### Commodity Pair Spread Matrix

Applies the bond pair-RV heatmap pattern to futures chains: time-series metric diffs across contract pairs with click-through line charts. Tagged `fixed_income` in Help Center alongside commodities.

**APIs:** `bq.data.fair_value`, `bq.data.fut_days_expire`, `bq.data.id`, `bq.data.name`, `bq.data.px_last`, `bq.data.px_settle`, `bq.func.range`, `bq.univ.futures`

```python
import bql

bq = bql.Service()

universe = bq.univ.futures('CLA Comdty')
data_item = bq.data.px_last()
data_item = data_item.with_additional_parameters(
    dates=bq.func.range('-90d', '0d'),
    fill='prev',
)
data_items = {
    'Price': data_item,
    'name': bq.data.name(),
    'expiry': bq.data.fut_days_expire(),
}
response = bq.execute(bql.Request(universe, data_items))
df = response.get('Price').df()
df = df.join(response.get('name').df())
df = df.join(response.get('expiry').df())
# ... UI omitted: pairwise pivot diff heatmap, line chart ...
```

### Credit Factor Scoring

Maps index bonds to equity issuers via `issuerof`, blends leverage/coverage fundamentals with OAS and 3-month total return, winsorizes and z-scores by sector, then ranks combined credit scores.

**APIs:** `bq.data.classification_name`, `bq.data.issuer`, `bq.data.name`, `bq.data.net_debt_to_ebitda`, `bq.data.net_interest_coverage`, `bq.data.spread`, `bq.data.tot_debt_to_tot_cap`, `bq.data.total_return`, `bq.func.range`, `bq.univ.issuerof`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()

def map_to_issuer(data_item):
    return data_item.value(bq.univ.issuerof(), mapby='lineage').znav()

universe = bq.univ.members('EMUSTRUU Index').filter(
    bq.data.classification_name() != 'Government'
)
data_items = {
    'Name': bq.data.name(),
    'Issuer': bq.data.issuer(),
    'Sector': bq.data.classification_name(),
    'Debt to EBITDA': map_to_issuer(bq.data.net_debt_to_ebitda(fa_period_type='BA') * -1),
    'Debt to Capital': map_to_issuer(bq.data.tot_debt_to_tot_cap(fa_period_type='BA') * -1),
    'Interest Coverage': map_to_issuer(bq.data.net_interest_coverage(fa_period_type='BA')),
    'Valuation Score': bq.data.spread(spread_type='OAS'),
    'Momentum Score': bq.data.total_return(calc_interval=bq.func.range('-3m', '0d')),
}
request = bql.Request(universe, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1).dropna()
# ... UI omitted: sector z-score grid, top bonds by Combined Score ...
```

### Credit Spread Heatmap

Aggregates winsorized average OAS or Z-spread by rating and maturity bucket for a bond index universe, excluding government and perpetual bonds.

**APIs:** `bq.data.classification_name`, `bq.data.is_perpetual`, `bq.data.mty_years_tdy`, `bq.data.rating`, `bq.data.spread`

```python
import bql

bq = bql.Service()

universe = bq.univ.members('I02701EU Index').filter(
    (bq.data.classification_name() != 'Government')
    .and_(bq.data.is_perpetual() == 'N')
)
bin_values = [3, 7, 10, 20]
bin_labels = ['0-3', '3-7', '7-10', '10-20', '> 20']
binned_mty_years = bq.data.mty_years_tdy().bins(bin_values, bin_labels)
measure = bq.data.spread(spread_type='oas')
rating = bq.data.rating()
avg_measure = (
    measure.group(
        by=[
            rating['BASE_RATING'],
            rating['NORMALIZED_SCALE'].replacena(99),
            binned_mty_years,
        ]
    )
    .winsorize(lower_limit=-3, upper_limit=3)
    .avg()
)
response = bq.execute(bql.Request(universe, {'Avg OAS': avg_measure}))
df = response[0].df()
# ... UI omitted: pivot to rating × maturity heatmap ...
```

### Default Risk Monitor

Screens index or ETF holdings by sector for extreme CDS–Z-spread basis (`yas_zspread_basis_constant_mty`), ranks top/bottom names, and drills into market vs model CDS time series for selected bonds.

**APIs:** `bq.data.bics_level_1_sector_name`, `bq.data.cds_spread`, `bq.data.classification_name`, `bq.data.id`, `bq.data.issuer`, `bq.data.name`, `bq.data.px_last`, `bq.data.rating`, `bq.data.rsk_bb_issuer_default`, `bq.data.security_des`, `bq.data.yas_zspread_basis_constant_mty`, `bq.func.range`, `bq.univ.cds`

```python
import pandas as pd
import bql

bq = bql.Service()

universe = bq.univ.members('HYG US Equity')
sector = 'Technology'
rank = 5
basis = bq.data.yas_zspread_basis_constant_mty()

filtered = (
    universe
    .filter(bq.data.classification_name('BICS', '1') == sector)
    .filter(
        (basis.grouprank(order='desc') < (rank + 1))
        .or_(basis.grouprank(order='asc') < (rank + 1))
    )
)
data_items = {
    'Name': bq.data.name(),
    'Issuer': bq.data.issuer(),
    'Rating (SP)': bq.data.rating(),
    'BB Issuer Dflt. Risk': bq.data.rsk_bb_issuer_default(frq='Y'),
    'CDS-Zspread Basis': basis.round(2),
    'Price': bq.data.px_last().round(2),
}
response = bq.execute(
    bql.Request(filtered, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
df = df.sort_values(by='CDS-Zspread Basis', ascending=False)
# ... UI omitted: coverage bar, CDS basis time series vs price ...
```

### Issuer On-the-run Bonds

Builds issuer bond chains filtered by maturity-at-issue and payment rank, keeps the most recently announced on-the-run line per issuer, and charts OAS or yield history (including tenor slopes).

**APIs:** `bq.data.announce_dt`, `bq.data.cpn_typ`, `bq.data.crncy`, `bq.data.long_ult_parent_comp_name`, `bq.data.yrs_to_mty_issue`, `bq.data.name`, `bq.data.payment_rank`, `bq.data.spread`, `bq.data.yield_`, `bq.func.range`, `bq.univ.bonds`

```python
import pandas as pd
import bql

bq = bql.Service()
today = '2026-07-24'
issuer_list = ['AAPL US Equity', 'MSFT US Equity']
mty = 10
data_item = bq.data.spread(spread_type='OAS')

universe = bq.univ.bonds(issuer_list, consolidateduplicates=True, useactiveonly=False)
filtered_univ = universe.filter(
    (bq.data.yrs_to_mty_issue().between(mty - 0.5, mty + 0.5))
    .and_(bq.data.crncy() == 'USD')
    .and_(bq.data.cpn_typ() == 'FIXED')
)
data_items = {
    'Name': bq.data.name(),
    'Announce dt': bq.data.announce_dt(),
    'Issuer': bq.data.long_ult_parent_comp_name(),
    'Payment Rank': bq.data.payment_rank(),
    'Value': data_item.with_additional_parameters(
        dates=bq.func.range('-2Y', today)
    ).dropna(),
}
response = bq.execute(bql.Request(filtered_univ, data_items, with_params={'mode': 'cached'}))
bonds_info = pd.concat([item.df()[item.name] for item in response[:4]], axis=1)
df = response.get('Value').df().join(bonds_info)
# ... UI omitted: on-the-run filter, slope chart ...
```

### Leveraged Loan Index Monitor

Pulls leveraged-loan index constituents with bid price, 3Y discount margin, dual ratings, amount outstanding, and price change windows; supports filter-driven weighted-average summaries.

**APIs:** `bq.data.amt_outstanding`, `bq.data.classification_name`, `bq.data.discount_margin_3yr_bid`, `bq.data.id`, `bq.data.ln_agent`, `bq.data.long_comp_name`, `bq.data.px_bid`, `bq.data.rating`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()
index = 'I38932US Index'
bid = bq.data.px_bid()
moody = bq.data.rating(rating_source='moody')

data_items = {
    'ID': bq.data.id(),
    'Company Name': bq.data.long_comp_name(),
    'Industry': bq.data.classification_name(
        classification_scheme='bclass', classification_level='3'
    ),
    'Current Price': bid,
    'DM/3Y': bq.data.discount_margin_3yr_bid(),
    'Moody Rating': moody['BASE_RATING'],
    'S&P Rating': bq.data.rating(rating_source='sp')['BASE_RATING'],
    'Amount Outstanding': bq.data.amt_outstanding(),
    'Change on Day': bid - bq.data.px_bid(dates='-1d', fill='prev'),
    'Agent': bq.data.ln_agent(),
}
response = bq.execute(bql.Request(bq.univ.members(index), data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1)
# ... UI omitted: rating/industry/agent filters, MV-weighted summary ...
```

### Muni New Issue Spreads

Filters `municipalsuniv('active')` with composable BQL predicates (state, classification, sale date, maturity-at-issue), then averages YTW spread-to-maturity-at-issue by sale year/week.

**APIs:** `bq.data.bb_sale_date`, `bq.data.classification_description`, `bq.data.rtg_sp_initial`, `bq.data.state_code`, `bq.data.yrs_to_mty_issue`, `bq.data.ytw_spread_to_maturity_at_issu`, `bq.func.greaterthanorequals`, `bq.func.in_`, `bq.func.lessthanorequals`, `bq.univ.municipalsuniv`

```python
import bql

bq = bql.Service()

sale_date = bq.data.bb_sale_date()
universe = (
    bq.univ.municipalsuniv('active')
    .filter(bq.data.state_code().in_(['NY']))
    .filter(bq.data.classification_description().in_(['City']))
    .filter(bq.data.yrs_to_mty_issue().greaterthanorequals(4.5))
    .filter(bq.data.yrs_to_mty_issue().lessthanorequals(5.5))
    .filter(bq.data.bb_sale_date().greaterthanorequals('-3Y'))
)
data_items = {
    'Avg BVAL Spread': (
        bq.data.ytw_spread_to_maturity_at_issu()
        .group([sale_date.year(), sale_date.week()])
        .avg()
    ),
}
response = bq.execute(bql.Request(universe, data_items))
df = response[0].df()
# ... UI omitted: multi-universe tabs, weekly trend chart ...
```

### Relative Value Screening

Screens a bond universe for OAS/Z/G-spread outliers using rating-group z-scores (`groupzscore`), with threshold slider filtering rich/cheap names.

**APIs:** `bq.data.classification_name`, `bq.data.duration`, `bq.data.issuer`, `bq.data.name`, `bq.data.rating`, `bq.data.spread`, `bq.data.yield_`

```python
import pandas as pd
import bql

bq = bql.Service()

universe = bq.univ.members('I02701EU Index').filter(
    bq.data.classification_name() != 'Government'
)
measure = bq.data.spread(spread_type='oas')
rating = bq.data.rating()
data_items = {
    'Bond Name': bq.data.name(),
    'Issuer': bq.data.issuer(),
    'OAS': measure.round(2),
    'Rating': rating,
    'Yield': bq.data.yield_().round(2),
    'Duration': bq.data.duration().round(2),
    'Z-Score': measure.groupzscore(by=rating).round(2),
}
response = bq.execute(bql.Request(universe, data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1)
df = df.set_index('Bond Name').dropna(subset=['OAS'])
outliers = df[df['Z-Score'].abs() > 1]
# ... UI omitted: bar chart, z-score grid ...
```

### Sovereign Debt Maturity Profiles and Ratings

Builds a rated sovereign-equity universe via `equitiesuniv` + `translatesymbols`, pulls multi-agency issuer ratings/outlooks, and supports country selection for debt maturity profile views.

**APIs:** `bq.data.classification_name`, `bq.data.country_iso`, `bq.data.credit_rating_outlook`, `bq.data.name`, `bq.data.rating`, `bq.univ.countries`, `bq.univ.debt`, `bq.univ.equitiesuniv`, `bq.univ.translatesymbols`

```python
import bql
from functools import reduce

bq = bql.Service()

def rating_item(source, crncy='lc', horizon='lt'):
    return bq.data.rating(
        rating_source=source,
        rating_type='issuer',
        rating_horizon=horizon,
        rating_currency=crncy,
    )

def has_valid_rating(source):
    r = rating_item(source)
    return (r['value'] != bql.NA).and_(r['value'].in_(['', 'N.A.']).not_())

sovereign_universe = (
    bq.univ.equitiesuniv('all')
    .filter(bq.data.classification_name(classification_level='3') == 'Sovereign Government')
)
valid_sources = ('moody', 'sp', 'fitch', 'dbrs')
rating_condition = reduce(lambda x, y: x.or_(y), [has_valid_rating(s) for s in valid_sources])
universe = bq.univ.translatesymbols(
    sovereign_universe, targetidtype='composite'
).filter(rating_condition)
response = bq.execute(bql.Request(universe, {'iso': bq.data.country_iso()}))
# ... UI omitted: region picker, ratings grid, debt maturity chart ...
```

### TOMS Barbell Hedging

Loads a TOMS book via `bq.univ.members(..., type='toms')`, computes bond DV01, matches nearest futures by maturity, and sizes barbell or single-contract hedge ratios from futures BPV.

**APIs:** `bq.data.basic_dv01`, `bq.data.crncy`, `bq.data.fut_cont_size`, `bq.data.fut_px_val_bp`, `bq.data.fut_val_pt`, `bq.data.maturity_years`, `bq.data.position`, `bq.data.risk`, `bq.data.security_des`, `bq.data.workout_years`, `bq.univ.list`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()

book_univ = bq.univ.members(symbols=['MYBOOK'], type='toms', pricing_number=1)
bond_items = {
    'Name': bq.data.security_des(),
    'Currency': bq.data.crncy(),
    'Expected Maturity': bq.data.workout_years(),
    'Position': bq.data.position(pxnum=1),
    'basic_dv01': bq.data.basic_dv01(pxnum=1),
    'risk': bq.data.risk() * 100,
}
bonds = bq.execute(bql.Request(book_univ, bond_items, with_params={'mode': 'cached'}))
bond_df = pd.concat([item.df()[item.name] for item in bonds], axis=1)

fut_items = {
    'futures_maturity': bq.data.maturity_years(),
    'futures_px_val_bp': bq.data.fut_px_val_bp(),
    'futures_val_pt': bq.data.fut_val_pt(),
}
futs = bq.execute(bql.Request(['TYU6 Comdty', 'USU6 Comdty'], fut_items))
# ... UI omitted: merge_asof barbell hedge sizing, summary grid ...
```

### TOMS Relative Value

Combines TOMS book static fields (position, axes, sector) with historical spread/yield metrics, builds pairwise z-score RV pairs filtered by maturity proximity and sector match.

**APIs:** `bq.data.bb_composite`, `bq.data.classification_name`, `bq.data.crncy`, `bq.data.is_axed`, `bq.data.name`, `bq.data.position`, `bq.data.price`, `bq.data.risk`, `bq.data.spread`, `bq.data.ticker`, `bq.data.yield_`, `bq.func.range`, `bq.univ.members`

```python
import bql

bq = bql.Service()

book_univ = bq.univ.members(symbols=['MYBOOK'], type='toms', pricing_number=1)
lookback_days = 90
spread = bq.data.spread(spread_type='OAS').with_additional_parameters(
    dates=bq.func.range(f'-{lookback_days * 2}d', '0d'),
    fill='prev',
)
static_items = {
    'Name': bq.data.name(),
    'Tickers': bq.data.ticker(),
    'Sector': bq.data.classification_name('bclass', '3'),
    'Position': bq.data.position(pxnum=1),
}
ts_response = bq.execute(
    bql.Request(book_univ, {'OAS': spread.dropna(True)}, with_params={'mode': 'cached'})
)
static_response = bq.execute(bql.Request(book_univ, static_items))
# ... UI omitted: pairwise z-score grid, scatter overview, pair charts ...
```

### Treasury Yield Curve Evolution

Snapshots a yield curve (`curvemembers`) on two dates and compares mid `curve_rate` by tenor for curve-shift visualization.

**APIs:** `bq.data.curve_rate`, `bq.data.duration`, `bq.data.id`, `bq.univ.curvemembers`

```python
import pandas as pd
import bql

bq = bql.Service()
curve_ticker = 'YCUSTRUU Index'
date = '2026-07-22'

curve_members = bq.univ.curvemembers(curve_ticker, dates=date)
data_items = {
    'duration': bq.data.duration(dates=date),
    'tenor': bq.data.id()['tenor'],
    'rate': bq.data.curve_rate(side='mid', dates=date),
}
response = bq.execute(bql.Request(curve_members, data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1)
# ... UI omitted: date slider, prior vs recent curve chart ...
```

### XCCY Historical Spread Analysis

Screens a corporate bond list for local Z/ASW spread plus cross-currency spread history (`cross_currency` parameter), with maturity buckets, LQA score, and axe flags.

**APIs:** `bq.data.amt_outstanding`, `bq.data.axes`, `bq.data.crncy`, `bq.data.id_isin`, `bq.data.is_perpetual`, `bq.data.lqa_liquidity_score`, `bq.data.maturity_years`, `bq.data.name`, `bq.data.spread`, `bq.func.if_`, `bq.func.range`

```python
import bql

bq = bql.Service()

universe = bq.univ.bonds('NESNVX').filter(
    (bq.data.id_isin() != bql.NA)  # bare accessor is valid as a predicate
    .and_(bq.data.amt_outstanding(currency='USD') > 100 * (10 ** 6))
)
spread = bq.data.spread(spread_type='ASW')
data_items = {
    'ISIN': bq.data.id_isin()['value'],  # clean export/join value
    'Name': bq.data.name(),
    'ASW Spread': spread,
    'LQA Score': bq.data.lqa_liquidity_score(),
    'XCCY ASW Spread (GBP)': spread.with_additional_parameters(
        cross_currency='GBP',
        dates=bq.func.range('-720d', '-1d'),
    ),
}
response = bq.execute(bql.Request(universe, data_items))
# ... UI omitted: ISIN grid, maturity-bucket filters, history chart ...
```

## Get Data Official Tutorial: Fixed Income Family

```mermaid
flowchart LR
  A["Fixed Income Family"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### BQL for Fixed Income
- This notebook is designed to show off a variety of ways you can use BQL to perform fixed income analyses.
- Note: Supplements existing 02; focus new patterns from official quickstart.
- **Topics:** Quickstart: BQL for Fixed Income; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for financial data¶; Querying for an individual security¶; Querying for multiple data items¶; Querying for multiple securities¶
- **APIs:** `bq.data.amt_issued`, `bq.data.amt_outstanding`, `bq.data.bb_composite`, `bq.data.classification_name`, `bq.data.cntry_of_risk`, `bq.data.company_corp_ticker`, `bq.data.cpn`, `bq.data.cpn_typ`, `bq.data.crncy`, `bq.data.disc_margin`, `bq.data.id`, `bq.data.issue_dt`, `bq.data.issuer`, `bq.data.market_value`

```python
# Set the universe as a list of ticker
universe = ['GLOAN Index', 'ELOAN Index']

# Include multiple data items in the dictionary
data_items = {
    'Name': bq.data.name(),
    'Currency': bq.data.crncy(),
    'Market Value': bq.data.market_value(universe_type='projected'),
    'Member Count': bq.data.member_count(universe_type='projected'),
    'Coupon': bq.data.cpn(universe_type='projected'),
    'Amt Outstanding': bq.data.amt_outstanding(universe_type='projected'),
    'Total Return MTD': bq.data.total_return(
        universe_type='returns', 
        calc_interval='mtd'
    ),
    'Coupon Return MTD': bq.data.total_return(
        universe_type='returns', 
        calc_interval='mtd', 
        return_type='cpn'
    ),
    'Currency Return MTD': bq.data.total_return(
        universe_type='returns', 
        calc_interval='mtd', 
        return_type='currency'
    ),
    'Price Return MTD': bq.data.total_return(
        universe_type='returns', 
        calc_interval='mtd', 
        return_type='price'
    ),
}

# Build the query and execute the request
request = bql.Request(universe, data_items)
response = bq.execute(request)

# Use pandas to concatenate all the returned data items into a single
# DataFrame
data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

data
```

```python
# Set the universe as all S&P500 financial companies with a debt-to-EBITDA 
# ratio >= 3
# Then take the bonds of those index members
# Then filter those bonds to retain those with a fixed coupon maturing in
# greater than 10 years
universe = (
    bq.univ.members('SPX Index')
    .filter(
        (bq.data.net_debt_to_ebitda(fa_period_type='a') >= 3)
        .and_(bq.data.classification_name() != 'Financials')
    )
    .bonds()
    .filter(
        (bq.data.cpn_typ() == 'FIXED')
        .and_(bq.data.maturity() > '10Y')
    )
)

# Calculate the median yield by credit rating
median_yld_by_rating = (
    bq.data.yield_()
    .group(bq.data.rating())
    .median()
)

data_item = {'Median Yield by Rating': median_yld_by_rating}

# Build and execute the request, and display the results
request = bql.Request(universe, data_item)
response = bq.execute(request)

data = response[0].df()
data
```

### BQL for Bond Cashflows
- This notebook is designed to show off several ways you can use BQL to perform bond cashflow analysis using the cashflows() data item.
- **Topics:** Quickstart: BQL for Bond Cashflows; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying cashflows for a single bond¶; Querying projected cashflows¶; Querying historical and projected cashflows¶; Querying cashflows for a date range using matches()¶
- **APIs:** `bq.data.cashflows`, `bq.data.country_iso`, `bq.data.cpn`, `bq.data.maturity`, `bq.univ.bondsuniv`, `bq.univ.members`

```python
# Define the target universe, a filtered bond universe
universe = (
    bq.univ.bondsuniv('active')
    .filter(
        (bq.data.country_iso() == 'CA')
        .and_(bq.data.cpn() > 2)
        .and_(bq.data.maturity() < '2y')
    )
)

cashflows =  bq.data.cashflows()

year = cashflows['date'].year()
month = cashflows['date'].month()

# Define the target data, total cashflows per year and month
data_item = {
    'Principal': cashflows['value'].group([year, month]).sum(),
    'Interest': cashflows['interest'].group([year, month]).sum()
}

# Build and execute the BQL query
request = bql.Request(universe, data_item, with_params={'mode': 'cached'})
response = bq.execute(request)

data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
).dropna()

data.head()
```

### BQL for Fixed Income Company Analysis

> **Mapping authority:** this is the captured official tutorial for
> `id().value(universe_function, mapby='lineage')`. Use `08` for the
> user-confirmed DT110/DT679 interpretation and `23` for any substitution.
> Issuer, parent, fundamental, and equity-pricing outputs have different
> identity semantics; none is automatically a local tradable listing.

- This notebook demonstrates several ways you can use BQL to perform fixed income company analysis.
- **Topics:** Quickstart: BQL for Fixed Income Company Analysis; Open an interactive version; Table of contents¶; Setting up your environment¶; Defining a bond universe¶; Navigating the corporate structure¶; Retrieving bonds from an equity¶; Determining the issuer of a bond¶
- **APIs:** `bq.data.amt_issued`, `bq.data.amt_outstanding`, `bq.data.asset_cvrg_ratio`, `bq.data.bond_recovery_rate`, `bq.data.bs_tot_asset`, `bq.data.called_dt`, `bq.data.cf_free_cash_flow`, `bq.data.classification_name`, `bq.data.cpn`, `bq.data.cpn_typ`, `bq.data.crncy`, `bq.data.cur_ratio`, `bq.data.duration`, `bq.data.ebitda`

```python
universe = [
    'EJ729042 Corp', 
    'ZS7759443 Corp', 
    'AU348883 Corp'
]

def apply_value(univ_function):
    """
    Applies the value function to a BQL universe function, mapping to the
    correct entity by lineage.
    """
    return bq.data.id().value(univ_function, mapby='lineage')

data_items = {
    'Issuer': apply_value(bq.univ.issuerof()),
    'Parent': apply_value(bq.univ.parent()),
    'Ultimate Parent': apply_value(bq.univ.parent()),
    'Fundamental Ticker': apply_value(bq.univ.fundamentalticker()),
    'Equity Pricing Ticker': apply_value(bq.univ.equitypricingticker())
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df
```

```python
universe = bq.univ.fundamentalticker(['BT370062 Corp', 'ZN109633 Corp'])

params = {
    'fa_period_reference': bq.func.range('2023q1', '2025q1'),
    'fa_period_type': 'q'
}

data_items = {
    'Period': bq.data.net_debt_to_ebitda(**params)['Period'],
    'EBITDA Margin': bq.data.net_debt_to_ebitda(**params),
    'Return on Assets': bq.data.return_on_asset(**params),
    'Return on Equity': bq.data.return_com_eqy(**params),
    'Total Debt to EBITDA': bq.data.tot_debt_to_ebitda(**params),
    'Debt to Assets': bq.data.lt_debt_to_tot_asset(**params),
    'Total Debt to Equity %': bq.data.tot_debt_to_tot_eqy(**params)
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

df
```

### BQL for Liquidity Analysis
- This notebook is designed to introduce you to performing liquidity analysis using axes data and the Liquidity Assessment (LQA) framework.
- **Topics:** Quickstart: BQL for Liquidity Analysis; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying fixed income axes¶; Using axeduniv() to retrieve all axes¶; Using is_axed() to filter for axes¶; Aggregating axes by security or dealer¶
- **APIs:** `bq.data.amt_outstanding`, `bq.data.axes`, `bq.data.bb_composite`, `bq.data.bics_level_1_sector_name`, `bq.data.classification_name`, `bq.data.expected_daily_volume`, `bq.data.industry_sector`, `bq.data.is_axed`, `bq.data.liquidation_cost`, `bq.data.liquidation_horizon`, `bq.data.lqa_liquidity_score`, `bq.data.liquidity_sector`, `bq.data.liquidity_sector_score`, `bq.data.lqa_bid_ask_spread`

```python
# Define universe
universe = 'LUACTRUU Index'

# Filter universe for axed bonds on both sides
axed_universe = (
    bq.univ.members(universe)
    .filter(bq.data.is_axed(side='all') == True)
)

axes = bq.data.axes(aggregateby='security_dealer')
    
# Calculates total bid axe size per dealer in millions
total_bid = axes['bid_size'].group(axes['bid_dealer']).sum() / '1M'

# Computes size-weighted average bid price per dealer
wavg_bid = (
    axes['bid_price']
    .group(axes['bid_dealer'])
    .wavg(axes['bid_size'].group(axes['bid_dealer']))
    .round(2)
)

data_items = {
    'Total Bid Axes Size by Dealer': total_bid,
    'WAVG Bid Axe Price Weighted by Size': wavg_bid
}

request = bql.Request(axed_universe, data_items)
response = bq.execute(request) 

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df.dropna()
```

```python
# Define universe
universe = 'EH154422 Corp'

params = {
    'dates': bq.func.range('-10d', '0d'),
    'fill': 'prev'
}

bid = bq.data.px_bid(**params)  
ask = bq.data.px_ask(**params)
mid = bq.data.px_mid(**params)
last = bq.data.px_last(**params)

data_items = {
    'Date': bid['date'],
    'Bid': bid,
    'Ask': ask,
    'Mid Price': mid,
    'Last Price': last,
    'Absolute Spread': (ask - bid),
    'Relative Spread (%)': ((ask - bid) / mid) * 100,
    'Effective Spread (%)':  2 * ((last - mid) / mid).abs() * 100
}

request = bql.Request(universe, data_items)
response = bq.execute(request) 

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df.head()
```

### BQL for Loans, Munis, and CDS
> Restricted sustainable-finance material has been removed from this canonical section and retained only in non-indexed provenance.

- This canonical extract retains unrestricted loan, municipal-bond, and credit-default-swap patterns.
- **Topics:** loans by issuer; `loansuniv()`; municipal bonds; CDS; monthly time-series pivots.
- **APIs:** `bq.data.amt_outstanding`, `bq.data.bics_level_2_industry_group_name`, `bq.data.bs_tot_asset`, `bq.data.cds_spread`, `bq.data.classification_code`, `bq.data.classification_name`, `bq.data.deal_name`, `bq.data.id`, `bq.data.industry_sector`, `bq.data.issue_dt`, `bq.data.ln_tranche_size`, `bq.data.loan_typ`, `bq.data.long_comp_name`, `bq.data.maturity`

```python
universe = (
    bq.univ.members('B500 Index')
    .loans()
    .filter(
        bq.data.loan_typ().in_(['TERM', 'DELAY-DRAW TERM'])
    )
)

borrower = bq.data.deal_name()
industry = bq.data.classification_name('bclass', '3')

# Change in loan price over 1 month
loan_chg = bq.data.px_last(
    dates=bq.func.range(start='-1m', end='0d'), 
    fill='prev'
)['Value'].net_chg()

group_chg = loan_chg.groupavg(industry)
diff = loan_chg - group_chg

borrower = borrower.matches(diff > 0).dropna(remove_id=True)
industry = industry.matches(diff > 0).dropna(remove_id=True)
loan_chg = loan_chg.matches(diff > 0).dropna(remove_id=True)
group_chg = group_chg.matches(diff > 0).dropna(remove_id=True)
diff = diff.matches(diff > 0).dropna(remove_id=True)

data_items = {
    'Borrower': borrower,
    'Industry': industry,
    'Loan Performance': loan_chg,
    'Group Performance': group_chg,
    'Loan Performance vs. Group': diff,
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
data
```

Restricted sustainable-finance screening code was removed from the canonical corpus. See the non-indexed provenance archive.

### BQL for Monitoring Primary and Secondary Markets
- This notebook is designed to show off several ways you can use BQL to perform fixed income primary and secondary market analyses.
- **Topics:** Quickstart: BQL for Monitoring Primary and Secondary Markets; Open an interactive version; Table of contents¶; Setting up your environment¶; Primary market monitoring¶; Querying for issuance pricing¶; Querying for new issue compression and concession¶; Monitoring bond issuance activity¶
- **APIs:** `bq.data.amt_issued`, `bq.data.amt_outstanding`, `bq.data.announce_dt`, `bq.data.bb_composite`, `bq.data.bb_new_issue_spread_analysis`, `bq.data.benchmark_for_pricing`, `bq.data.classification_name`, `bq.data.cntry_of_risk`, `bq.data.cpn`, `bq.data.crncy`, `bq.data.publcly_announcd_indctr`, `bq.data.issuance_pricing`, `bq.data.issue_px`, `bq.data.long_comp_name`

```python
# Define universe
universe = (
    bq.univ.bondsuniv('all')
    .filter(
        (bq.data.classification_name('bclass', '1') == 'Corporate')
        .and_(bq.data.rtg_sp_initial() == 'BB+')
        .and_(bq.data.crncy() == 'EUR')
        .and_(bq.data.market_classification() != 'SSA')
        .and_(bq.data.classification_name('bclass', '2') 
              != 'Financial Insitutions')
    )
)

# Define data items 
data_items = {
    'Issuance': bq.data.amt_issued(currency='EUR').group(
        [
            bq.data.security_pricing_date().year(), 
            bq.data.security_pricing_date().month()
        ]
    ).sum(),
    'Maturity': bq.data.amt_outstanding(currency='EUR').group(
        [bq.data.maturity().year(), bq.data.maturity().month()]
    ).sum()
}

# Build and execute request
request = bql.Request(universe, data_items, with_params={'mode':'cached'})
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

# Display the DataFrame 
df.head()
```

### BQL for Private Credit
- **Topics:** Quickstart: BQL for Private Credit; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Screening for direct lending loans of an issuer¶; Analyzing the loans universe¶; Analyzing sector direct and non-direct loan distribution¶
- **APIs:** `bq.data.amt_outstanding`, `bq.data.classification_name`, `bq.data.cpn`, `bq.data.crncy`, `bq.data.disc_margin`, `bq.data.id`, `bq.data.index_price`, `bq.data.index_quality_alphabetic`, `bq.data.institutional_loan`, `bq.data.issue_dt`, `bq.data.issuer`, `bq.data.ln_current_margin`, `bq.data.ln_direct_lending`, `bq.data.ln_facility_amt`

```python
# # BQuant Desktop users: Uncomment the below code and run the cell to see the output

# loan_ids = [
#     'BL4850477',
#     'BL3877919',
#     'BL5187143',
#     'BL4814861',
# ]

# def build_bql_request(loan):
#     """
#     Constructs a single BQL request for holders data for each loan.
#     """
#     universe = bq.univ.holders(loan, view='lowest')
#     data_items = {
#         'Loan': bq.data.id()['orig_ids'],
#         'Holder Name': bq.data.id()['holder_name'],
#         'Position': bq.data.id()['position'],
#         'Market Value': bq.data.id()['reported_market_value']
#     }
#     return bql.Request(universe, data_items)

# # holders() only accepts a single ticker, therefore create a list of unique
# # requests for the holders of each loan and execute
# requests = [build_bql_request(loan) for loan in loan_ids]
# responses = bq.execute_many(requests)

# # Each response represents a single loan
# dfs = []
# for response in responses:
#     df = pd.concat([data_item.df() for data_item in response], axis=1)
#     df['Price'] = (df['Market Value'] / df['Position']) * 100
#     dfs.append(df)

# df = pd.concat(dfs, ignore_index=True).dropna(subset=['Price'])

# df.head()
```

```python
universe = (
    bq.univ.loansuniv('all')
    .filter(
        (bq.data.issue_dt() >= '-3m')
        .and_(
            (bq.data.ln_direct_lending()== True)
            .or_(bq.data.institutional_loan()== True)
        )
    )
)

data_items = {
    'Direct': bq.data.ln_direct_lending(),
    'Syndicated': bq.data.institutional_loan(),
    'Current Margin': bq.data.ln_current_margin(),
    'Sector': bq.data.classification_name('bics', '2')
}

# Build and execute the request and display the results
request = bql.Request(universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

df['Loan Type'] = (
    np.where(
        df['Direct'], 'Average Margin - Direct', 'Average Margin - Syndicated'
    )
)

df = (
    df.groupby(['Sector', 'Loan Type'])['Current Margin']
    .mean()
    .unstack('Loan Type')
)

df.round(2)
```

### BQL for Relative Value
- This notebook is designed to show off several ways you can use BQL to perform fixed income relative value analyses.
- **Topics:** Quickstart: BQL for Relative Value; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Analyzing a single security¶; Retrieving times series data for multiple data items¶; Retrieving cross-currency data¶
- **APIs:** `bq.data.amt_outstanding`, `bq.data.cds_spread`, `bq.data.classification_name`, `bq.data.cpn_typ`, `bq.data.crncy`, `bq.data.curve_strategy`, `bq.data.duration`, `bq.data.id`, `bq.data.issuer`, `bq.data.long_comp_name`, `bq.data.maturity_years`, `bq.data.name`, `bq.data.payment_rank`, `bq.data.px_last`

```python
bonds_list = [
    'JP322380AP98',
    'EU000A3K4DM9',
    'US25468PBW59',
    'US03969YAC21',
    'XS2491189408',
    'US71567RAV87'
]

def build_bql_request(bond):
    """
    Constructs a single BQL request for z-scores for each bond.
    """
    universe = bq.univ.list(bonds_list)

    spread = bq.data.spread(
        spread_type='Z', dates=bq.func.range('-1y', '0d'), fill='prev'
    )['value']
    base_spread = spread.value(bq.univ.list(bond)).dropna()['value']

    data_item = {
        bond: (spread - base_spread).zscore().last()
    }

    request = bql.Request(universe, data_item)
    return request

# Create a list of unique dated requests and execute the requests
requests = [build_bql_request(bond) for bond in bonds_list]
responses = bq.execute_many(requests)

# Each response represents a single bond, so create a final DataFrame
# with all of the bonds
dfs = []
for response, bond in zip(responses, bonds_list):
    single_bond_df = pd.concat(
        [data_item.df()[data_item.name] for data_item in response],
        axis=1
    )
    dfs.append(single_bond_df)
df = pd.concat(dfs, axis=1).fillna('-')

# Present the data as a pandas DataFrame
df
```

```python
# Specify the start and end dates
end_date = pd.to_datetime('today')
start_date = end_date - pd.DateOffset(months=6)

# Generate a list of end-of-month dates
end_of_months = pd.date_range(
    start=start_date,
    end=end_date,
    freq='m'
)

# Define function to build BQL request
def build_bql_request(date):
    """
    Constructs a single BQL request for z-scores for each bond.
    """
    universe = bq.univ.members('LF98TRUU Index')

    group = bq.data.classification_name('bclass', '4')

    data_item = {
        date.strftime('%Y-%m-%d'): (
            bq.data.spread(spread_type='OAS').group(group)
            .wavg(bq.data.id()['weights'].group(group))
        )
    }

    request = bql.Request(
        universe, data_item, with_params={'dates': date, 'fill': 'prev'}
    )
    return request

# Create a list of unique dated requests and execute the requests
requests = [build_bql_request(date) for date in end_of_months]
responses = bq.execute_many(requests)

# Each response represents a single date, so create a final DataFrame
# with all dates
dfs = []
for response, date in zip(responses, end_of_months):
    single_date_df = pd.concat(
        [data_item.df()[data_item.name] for data_item in response],
        axis=1
    )
    dfs.append(single_date_df.round(2))
    
df = pd.concat(dfs, axis=1).fillna('-')

# Present the data as a pandas DataFrame
df.head(10)
```

### BQL for Securitized Products
- Before you can run the examples in this notebook, you must first set up your environment by importing the necessary libraries and connecting to the BQL service.
- **Topics:** Quickstart: BQL for Securitized Products; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Screening securitized products¶; Screening securities with mortgagesuniv()¶; Screening mortgages from an issuer¶
- **APIs:** `bq.data.amt_outstanding`, `bq.data.bond_loss`, `bq.data.cashflows`, `bq.data.collateral_cashflows`, `bq.data.collateral_loss`, `bq.data.cpn`, `bq.data.crncy`, `bq.data.disc_margin`, `bq.data.id`, `bq.data.issue_dt`, `bq.data.maturity`, `bq.data.mtg_cmo_class`, `bq.data.mtg_deal_typ`, `bq.data.mtg_orig_amt`

> Catalog exception: scenario-aware `wal()` is official-example-observed but absent from `22`; `mtg_wal()` and `mtge_wal()` are both catalog candidates. FLDS-confirm before running the WAL request.

```python
# Define the target universe -  ABS PRIME AAA Auto bonds
universe = (
    bq.univ.mortgagesuniv('all')
    .filter(
        (bq.data.structured_prod_class_ast_cl() == 'AUTO')
        .and_(
            (bq.data.rtg_sp() == 'AAA')
            .or_(bq.data.rtg_moody() == 'AAA')
        )
        .and_(
            bq.data.structured_prod_class_cred_qual()
            .in_(['Prime', 'Super Prime'])
        )
        .and_(bq.data.mtg_cmo_class() == 'A3')
        .and_(bq.data.mtg_wal() >= 0.25)
    )
)

# Define target trades
trades = bq.data.trade_data(source='trace', dates=bq.func.range('-3m', '0d'))
trade_data = trades.matches(
    (trades['i_spread'] <= 300)
    .and_(trades['volume'] >= 1000)
)

# Define target data - adjusted volume weighted average of I-spread 
data_item = {
    'Trade Data': (
        (trade_data['i_spread'].group(trade_data['date']))
        .wavg((trade_data['adjusted_volume'].group(trade_data['date'])))
    )['value']
}

# Build and execute the request
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Present the data as a pandas DataFrame
df = response[0].df()
df.head()
```

```python
universe = 'BLUEM 19-26A AR Mtge'  

# Define common parameters
params = {
    'prepay_rate': '20',
    'prepay_type': 'CPR',
    'default_rate': '2', 
    'default_type': 'CDR', 
    'severity_rate': '30', 
    'severity_lag': '6',
    'market_date': 'realtime',
    'applyusersettings': 'y'
}

data_items = {
    'Price': bq.data.price(**params, price='100-16'),
    'Z-Spread': bq.data.spread(**params, spread_type='Z', price='100-16'),
    'Discount Margin': bq.data.disc_margin(**params, price='100-16'),
    # STOP: wal() is not in catalog 22; FLDS-confirm versus mtg_wal()/mtge_wal().
    'WAL': bq.data.wal(**params, price='100-16'),
    'Bond Loss $': bq.data.bond_loss(**params, basis='amount'),
    'Collat Loss %': bq.data.collateral_loss(
        **params, basis='pct_current_face'
    )
}

request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
df
```

### BQL for TOMS
- This notebook is designed to show off several ways you can use BQL to access and analyze your Trade Order Management Solutions (TOMS) books.
- **Topics:** Quickstart: BQL for TOMS; Open an interactive version; Table of contents¶; Prerequisites¶; Setting up your environment¶; Querying BQL for data¶; Accessing TOMS books with BQL¶; Querying for multiple books¶
- **APIs:** `bq.data.basic_cr01`, `bq.data.basic_dv01`, `bq.data.book_name`, `bq.data.classification_name`, `bq.data.crncy`, `bq.data.final_state`, `bq.data.id`, `bq.data.market_value`, `bq.data.name`, `bq.data.order_date`, `bq.data.order_security`, `bq.data.position`, `bq.data.px_last`, `bq.data.rating`

```python
universe = (
    bq.univ.ordersuniv(type='toms', dates=bq.func.range('-1y', '0d'))
    .filter(bq.data.order_security(pricing_number='101').left(2) == 'BB')
)

data_item = {
    'Orders': (
        bq.data.id()
        .group(
            bq.data.rating()
            .value(
                bq.data.order_security(pricing_number='101').to_ids(), 
                mapby='lineage'
            )
        )
        .count()['value']
    )
}
# Build and execute the BQL query
request = bql.Request(universe, data_item, with_params={'pxnum':'101'})
response = bq.execute(request)

# Use pandas to concatenate all the returned data items into a single
# DataFrame
df = response[0].df()

# Create a bar chart using Plotly
fig = px.bar(
    df,
    x=df.index,
    y='Orders',
    title="Order Distribution by Rating",
    template="plotly_dark"
)

fig.show()
```

```python
final_state = bq.data.final_state(pricing_number='101')

# Filter for orders which were not completed
universe = (
    bq.univ.ordersuniv(type='toms', dates=bq.func.range('-1y', '0d'))
    .filter(final_state != 'COMPLETED')
)

# Calculate hit ratio for each final state
data_item = {
    'Overall Hit': (
        bq.data.id()
        .groupcount(final_state) 
        / bq.data.id().count()
    ).group(final_state)
}

# Build and execute the BQL query
request = bql.Request(universe, data_item, with_params={'pxnum':'101'})
response = bq.execute(request)

# Use pandas to concatenate all the returned data items into a single
# DataFrame
df = response[0].df()

# Create a pie chart using Plotly
fig = px.pie(
    df,
    names=df.index,
    values="Overall Hit",
    title="Overall Hit Ratio",
    template="plotly_dark"
)

fig.show()
```

