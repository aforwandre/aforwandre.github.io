---
topic_id: "25"
title: ETF Capping Monitor Runtime Authority
role: project_runtime_authority
authority_for:
  - etf_capping_monitor_runtime
  - last_price_last_close_zero_fallback
  - etf_aim_request_shape
  - etf_asset_classifier_cash_fx
  - etf_dynamic_limit_rank
  - etf_monitor_display_filters
  - etf_copy_paste_desktop_hazards
not_authority_for:
  - general_api_signatures
  - substitution_workflow
  - incident_narrative
evidence_grades:
  - user-confirmed
  - practice-derived
risk_tier: high
routing_keywords:
  - Last Close
  - fill=prev
  - 6166 HK
  - 5371 TT
  - Primary FM
  - SHORT_NAME
  - PARSER_VERSION
  - np.infinite
  - Account Incomplete
  - Dynamic Limit
  - classify_asset
  - AIM_ACCOUNT_BATCH
  - SECURITY_BATCH
  - BGNL
mandatory_cross_checks:
  - 00-RAG-INDEX
  - 08-bql-data-items
  - 23-bql-substitution-due-diligence
  - 24-etf-field-migration-incident
  - project-etf-capping-monitor
restricted_sections: []
source_families:
  - user_confirmed_incident
  - desktop_observation
  - excel
---

# ETF Capping Monitor Runtime Authority

## Retrieval card (route card)

This is the **highway** to a running ETF Capping Monitor. The destination
is Desktop output: AIM holdings, company-group weights, Last Close / Real
Time, Monitor alerts. Follow this card. Do not wander `09`/`11`/`22`.
`BUNDLE_EXAMPLES.md` may reuse this app's shapes for a **new** goal; it is
not a second highway for this destination.

`08` / `23` / `24` are rest stops this card names (status codes, Thai
incident). They are not alternate routes for last-price or Dynamic Limit.

Code lives under `User scripts/ETF Capping Monitoring/`. Live runbook is
`etf_capping/config.py` only. Never import `config_redacted.py` in
production.

## Authority split (stop duplicate retrieval)

| Claim | Owner | Not owner |
|---|---|---|
| `market_status()` mapping, official empty codes, cached-stale trap | `08` § Market-status | this file copies codes only for runtime use |
| Excel/API substitution workflow | `23` | this file |
| GHG/CAST/DRSK/Thai identity incident | `24` | this file |
| Last Close date, holiday fill, weight-zero fallback, diagnostics | **this file** | `08`/`23`/`24` must point here |
| AIM one-account Request, classifier, cash FX invert, Dynamic Limit | **this file** | `11` AIM tutorial; `09` widgets |
| Launchpad/BQAP publish and Terminal Link | `15` | this file notes snapshot practice only |
| Company grouping / Thai Pricing Ticker | project `.mdc` + `08`/`24` | display-only columns below |
| MDX Scan membership / NameCN / signals | `26` | this file |

## Last-price, Last Close, and zero fallback

User-confirmed 2026-09-02 (`5371 TT Equity`) and 2026-09-02/03 weight rule.

**Primary rule:** Bloomberg last price decides the number. Status only
classifies an *empty* request.

1. Always request `px_last(..., fill="prev", currency="USD")` for every priced
   equity, including official empty-market statuses. Do not skip the request
   for `DLST`/`SUSP`/etc.
2. Carry any **numeric** last print, including `SUSP`/`Suspended` and a
   delisted name that still has a last print.
3. Last Close funds: request date = previous weekday (through yesterday), not
   the UK header clock. `fill="prev"` walks through an **exchange holiday** on
   that weekday, so the print may be the session before yesterday.
4. Real Time funds: request date = live calendar today, same `fill="prev"`.
   A holiday or not-yet-printed session still carries the last print.
5. Last Close `px_last` may use Request `mode=cached`. Descriptor
   `market_status()` / `name()` must **not** (`08` 6166 HK trap).

**Fallback (only when the last-price rule is not met):** request error, `N/A`,
`#N/A`, non-numeric, `Inf`, or empty after `fill="prev"`.

- Set **that holding only** `Price USD = 0` and `MV = 0`.
- Sibling weights still calculate (zero MV does not NaN the account).
- Official empty-market status + empty request: zero is **not** Missing Price
  (`Zero Price Market Status` diagnostic).
- Active/`ACTV` in this fallback remains **Missing Price / Data Issue**.
- Do **not** treat a holiday as zero when `fill="prev"` returned a number.
- Do **not** overwrite a returned last print with zero for `ACTV` or `ACQU`.

Engine must coerce with `pd.to_numeric(..., errors="coerce")` then
`replace([np.inf, -np.inf], np.nan)` **before** diagnostics, then `fillna(0)`
on `Price USD` after diagnostics. Do not write `np.isfinite` in files the
user hand-copies (`## Desktop copy-paste hazards`).

Index Future and FFX remain forced zero by asset class (`## Asset
classifier and cash FX`).

Thai unresolved mapping still blanks the foreign prefilled price, then the
same zero fallback applies. Local **Pricing Market Status** drives
empty-versus-carry; AIM status stays display-only.

## Descriptor cache trap (6166 HK Equity)

Desktop 2026-09-02: `market_status()` with Request `mode=cached` returned
stale `Delisted` for `6166 HK Equity`. Live item and FLDS BQL PR286 returned
`Active`. `SIMP_SEC_STATUS=CLOS` / `EXCH_TRADE_STATUS=N` means the HK market
is closed, not that the security is delisted.

`_fetch_descriptors` must not pass `with_params={"mode": "cached"}` on
`name()` + `market_status()`.

Do **not** attach `fundamentalticker()` or `crncy()` to that uncached
Request. Company mapping is a separate cached Request. Cash currency is
parsed from the Cash yellow key (`## Asset classifier and cash FX`), not
from a `crncy()` data item. Cached is per-Request, not a session default.

## Diagnostics that are not “every row is broken”

- **Account Incomplete** is contagious: one Missing Price / Reference Data
  Missing / missing quantity / zero MV sets `Has Data Issue` for **all**
  companies in that AIM. Account Summary `Companies == Data Issues` is this
  paint, not proof that every name failed.
- Dummy/odd tickers (for example `2543628D MK`, `.OZONPLC RU`) are real
  Missing Price drivers.
- Log `ResponseError` on a whole AIM (`ACCT02` / `ACCT14` / `ACCT19`)
  means the position fetch failed, not a price-status bug.

## Primary FM (not BQL)

User-confirmed Excel `ETF Capping Macro_v3` column Primary FM, copied into
`PRIMARY_FM_BY_AIM` in `config.py` (2026-09-02). 54 AIM codes. Names:
Sample FM 1, Sample FM 3, Sample FM 2, Sample FM 4.

Display/filter only. Does not change MV or weight.

| Surface | Placement |
|---|---|
| Monitor, Full Positions, Runbook | last column |
| Account Summary | immediately after Fund |
| App header dropdown | far right of Account / Show / Find; filters **Monitor only** |
| Full Positions dropdown | right of NAME, left of Export; independent of the header |

## Unresolved: Monitor Company → Excel `SHORT_NAME`

**Decision: Unresolved. Do not implement.**

Monitor **Company** is company-group display (`Parent/Issuer Name`: Exception
parent name → `fundamentalticker()` name → held `name()`). It is not the
listing short name.

`22` has `short_name()` with a **blank Description** (spelling only).
`ts_short_name()` and `index_short_name()` are different items and are
rejected as substitutes. Require the FLDS **BQL** tab (not API) plus identity:
company key versus held ticker. Do not convert the Excel mnemonic, probe
entitlement, or fall back to `name()`.

## Desktop copy-paste hazards

User hand-copies Python into BQuant Desktop. PDF/Preview can eat leading
spaces. After replacing `app.py` / `data.py` / `engine.py`: Restart Kernel →
Run All → Update. Log must show `PARSER_VERSION` from `data.py` (2026-09-02d
at this writing).

Desktop 2026-09-02: `AttributeError: module 'numpy' has no attribute
'infinite'` means the hand-copy wrote `np.infinite` instead of
`np.isfinite`. Production engine must use
`replace([np.inf, -np.inf], np.nan)` so that token is not required.

Legend/Incl-Ex: do not attach VegaExpr to those percent cells on Desktop
(cells go blank). Status remains Python strings. Status/alert chips may
keep VegaExpr colours; Incl/Ex must not.

## Publishing this app (practice pointer)

A published Launchpad/BQAP app is a **project snapshot**. Saving files does
not update colleagues. Republish from Management Center after each accepted
change. Share the Terminal Link; teammates open it in Launchpad, then may
find it under BQAP `<GO>` search. Pin-to-personal-BQAP-page controls are
`gap-uncaptured` in `15`. Managed Git is Enterprise-only.

## AIM request shape (one account per Request)

Frozen 2026-08-28 Desktop (`11` notes the same freeze; this file owns the
shape).

Universe: `bq.univ.members(type="AIM")`.
Keep `accounts`, `pxnum=1377`, and `profile="DEFAULT_PROFILE"` on
`with_params`. Do not move them onto `members()`. Do not add dates. Do not
use `ts_position()`. Do not substitute `param` for `pxnum`.

`accounts` is a **list of one AIM code** per Request: `{"accounts":
[account]}`. Do not pass a bare string. Do not pass the whole book in one
`accounts` list. `execute_many` in batches of `AIM_ACCOUNT_BATCH = 8`.

Current: `position_without_pending()["value"]`.
Projected: that item **plus** `pending_position()["value"]` (two items on
the same Request, or Current+Pending in pandas). Pending alone returned
all zeros; it is the pending component, not Projected.

Security-level caches (`px_last`, leftover DRSK, `fundamentalticker`) use
`SECURITY_BATCH = 150`.

## Asset classifier and cash FX

Match `ETF Capping Formula.xlsx` by yellow-key suffix. Length is part of
the rule. Do **not** call `bq.data.crncy()` or `security_typ()` to classify
AIM holdings for this app.

- ends with ` Curncy` and `len(text) > 11` → **FFX** (forced zero MV)
- ends with ` Curncy` otherwise → **Cash** (`USD Curncy` is 10 characters)
- ends with ` Index` → **Index Future** (forced zero MV)
- ends with ` Equity` → **Equity**
- else → **Others**

A 3-letter-code heuristic without the length cutoff mis-classifies FFX as
Cash.

Cash USD price (user-confirmed Desktop; `24` workbook-parity note is
historical — this arithmetic is frozen here):

- only `CCC Curncy` Cash keys (exactly two tokens, 3-letter alpha ISO, not
  `NAN`)
- `USD` → `1.0` (do not request FX)
- else `px_last(dates=..., fill="prev")` on `USD{CCY} BGNL Curncy`, then
  USD price = `1 /` that quote
- skip malformed tickers so the loop never requests `USDNAN BGNL Curncy`

Cash uses the same Last Close / Real Time as-of date as equities. Header
clock is Europe/London for display; `px_last` dates use the **live
calendar** date of the refresh.

## Dynamic Limit, Rank, Near Limit

Pandas on company groups after MV/Weight on the **held** ticker (`24`).
Do not invent BQL for these columns. A knowledge-only rebuild that leaves
Incl/Ex as NA has not reconstructed this app.

1. Rank **every** parent group in the AIM, including cash and other assets,
   by `Agg Wgt (incl cash)`, `method="min"`, descending.
2. `Dynamic Limit = Largest` when `Rank == 1` and `Largest` is present;
   otherwise `Capping`.
3. `Observed Weight = max(Agg Wgt incl cash, Agg Wgt ex cash)`.
4. `Headroom = Dynamic Limit − Observed Weight`.
5. `Utilisation = Observed Weight / Dynamic Limit`.
6. `Capping Status`: Breach if Observed ≥ Dynamic Limit; Near Limit if
   Observed ≥ `WARNING_RATIO` (0.98) × Dynamic Limit; else OK.
7. Non-equity rows: force `Capping Status = OK`.
8. `Status` = Capping Status when that is not OK, else Data Quality
   (Account Incomplete paint from `## Diagnostics`).

Monitor then keeps Equity rows for the capping comparison. Ranking cash
first is required for Rank-1 / Largest parity with the xlsx.

Incl/Ex Cash on the grid are Python percent **strings** plus Status. Do
not drive those cells with VegaExpr.

## App lifecycle

`MAIN.ipynb` displays the widgets only. Data loads when the user clicks
**Update**. Do not call `load_on_start()` in the ETF bootstrap.

MDX Scan **does** call `load_on_start()` once (`26`). Copying that
bootstrap here would fire BQL on every Kernel Restart / Run All.

## Reconstruction lesson (KB backtest 2026-09-03)

A knowledge-only rebuild from `25`/`08`/`11`/`24` matched AIM Current vs
Projected, uncached descriptors, `fill="prev"`, Thai identity, Account
Incomplete, Primary FM, and Update-only MAIN. It failed closed (correctly)
or guessed wrongly on:

1. `accounts` value type (string vs `[account]`).
2. Cash FX invert (`1/BGNL`) and USD=1.
3. Yellow-key classifier vs an extra `crncy()` request.
4. Entire Dynamic Limit / Rank / 0.98 Near Limit rule.

## Minimum shippable package (one pass)

If `User scripts/ETF Capping Monitoring/` is lost, rebuild from **this file**
+ project `.mdc` + `18`, not from `09`/`11`. `00` § 13 One-pass order.

| File | What this topic freezes | What it cannot invent |
|---|---|---|
| `etf_capping/config.py` | `WARNING_RATIO=0.98`, batches 8/150, table columns, placeholder AIM shape | Live 54 AIM codes, fund names, Exception/Thai override rows (restore `config.py` or re-type from the Excel runbook) |
| `etf_capping/data.py` | AIM Request, descriptors, `px_last`, cash FX pair, Thai leftover DRSK, Arrow parse | — |
| `etf_capping/engine.py` | coerce/inf, zero fallback, classifier, Dynamic Limit/Rank, Account Incomplete | — |
| `etf_capping/app.py` | Update-only; no VegaExpr on Incl/Ex; Primary FM placement | Full chrome/SVG/Export polish |
| `MAIN.ipynb` | Display + Update; no `load_on_start()` | — |

**First Desktop success:** Restart Kernel → Run All → Update → log shows
`PARSER_VERSION`; Monitor company weights use Last Close/Real Time +
`fill="prev"` + Dynamic Limit; Incl/Ex cells are visible strings; no
`np.infinite`. That is a running project. Matching every tab and the live
book is a second drop after `config.py` is restored.

Do not start a Desktop conversation to rediscover the regression checklist
below.

## Probe

`User scripts/ETF Capping Monitoring/probe_ticker.py` is pasted into a new
cell of the same `MAIN.ipynb` after Update. Set `T` to the suspect yellow
key. Read CACHE, STATUS REPR, DIAG, then live BQL `name` / `market_status` /
`px_last`.

## Regression that belongs here (not the mapping incident)

- [ ] No `mode=cached` on descriptor `market_status()` / `name()`.
- [ ] Every priced equity requests `px_last(..., fill="prev")`.
- [ ] Numeric last print is carried, including `SUSP`.
- [ ] Last Close as-of previous weekday; holiday uses fill, not a local
      holiday calendar.
- [ ] Failed last-price → that row Price/MV 0; siblings still weighted.
- [ ] Active empty last-price still Missing Price.
- [ ] Engine has no `np.isfinite` / `np.infinite` token.
- [ ] Primary FM is runbook text, not a BQL field.
- [ ] `SHORT_NAME` remains unimplemented until FLDS BQL tab + identity review.
- [ ] AIM Request uses `accounts=[one code]`; batches of 8; `pxnum` not `param`.
- [ ] No `crncy()` classifier; `Curncy` length > 11 is FFX; cash FX is
      `1 / USD{CCY} BGNL Curncy` (USD = 1).
- [ ] Dynamic Limit uses Rank 1 + Largest; Near Limit is 0.98 × limit.
- [ ] ETF `MAIN` does not auto-refresh; Incl/Ex have no VegaExpr.
