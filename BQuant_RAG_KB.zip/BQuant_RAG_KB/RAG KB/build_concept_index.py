"""Generate the closed-world concept census from canonical topics and rules.

Never edit CONCEPT_INDEX.md or CONCEPT_INDEX.json by hand. Curated hop
policy lives in concept_index_overlay.json.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any


KB = Path(__file__).resolve().parent
WORKSPACE = KB.parent
RULES = WORKSPACE / ".cursor" / "rules"
OVERLAY_PATH = KB / "concept_index_overlay.json"
CONCEPT_INDEX_MD = KB / "CONCEPT_INDEX.md"
CONCEPT_INDEX_JSON = KB / "CONCEPT_INDEX.json"

SKIP_TOPIC_NAMES = {
    "09-build-analysis.md",
    "11-sample-notebooks.md",
    "22-BQuant_DataItems.md",
    "CONCEPT_INDEX.md",
    "BQUANT_RAG_KNOWLEDGE_BASE.md",
}

# Bare Python noise. Keep bq.data.id via family=="data" in add_hit.
SKIP_BARE_TOKENS = {
    "and",
    "or",
    "not",
    "in",
    "is",
    "if",
    "for",
    "with",
    "from",
    "import",
    "true",
    "false",
    "none",
    "int",
    "str",
    "list",
    "dict",
    "set",
    "len",
    "print",
    "range",
    "type",
}

BQ_CALL = re.compile(
    r"\bbq\.(?P<family>data|univ|func)\.(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\("
)
HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
NEGATION = re.compile(
    r"\b(never|do not|don't|must not|stop\b|reject|prohibited|"
    r"not a |is not |do \*\*not\*\*)\b",
    re.IGNORECASE,
)

ROLE_RANK = {
    "prohibition": 0,
    "incident": 1,
    "hard_stop": 2,
    "freeze": 3,
    "diligence": 4,
    "primary_candidate": 5,
    "announcement": 6,
    "atlas": 7,
}

MAX_ROWS_PER_TOKEN = 40
MAX_SAMPLE = 96

REQUIRED_OVERLAY_KEYS = {
    "kind",
    "identity",
    "primary",
    "freeze",
    "prohibition",
    "do_not_open_for_implementation",
    "co_mentions_are_not_hops",
    "next_hops_if_must_resolve",
    "hop_policy",
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def relative(path: Path) -> str:
    return path.relative_to(WORKSPACE).as_posix()


def load_overlay() -> dict[str, Any]:
    payload = json.loads(read_text(OVERLAY_PATH))
    tokens = payload.get("tokens")
    if not isinstance(tokens, dict) or not tokens:
        raise RuntimeError("concept_index_overlay.json missing tokens")
    for name, row in tokens.items():
        missing = REQUIRED_OVERLAY_KEYS - set(row)
        if missing:
            raise RuntimeError(
                f"Overlay token {name!r} missing keys: {sorted(missing)}"
            )
        for key in (
            "primary",
            "freeze",
            "prohibition",
            "do_not_open_for_implementation",
            "co_mentions_are_not_hops",
            "next_hops_if_must_resolve",
        ):
            if not isinstance(row[key], list):
                raise RuntimeError(f"Overlay token {name!r} {key} must be a list")
        if not str(row["hop_policy"]).strip():
            raise RuntimeError(f"Overlay token {name!r} hop_policy is empty")
    return payload


def census_files() -> list[Path]:
    files: list[Path] = []
    files.extend(sorted(RULES.glob("*.mdc")))
    for path in sorted(KB.glob("*.md")):
        if path.name in SKIP_TOPIC_NAMES:
            continue
        if path.name.startswith("00-") or re.match(r"^\d{2}-", path.name):
            files.append(path)
    return files


def guess_role(rel_path: str, heading: str, line: str) -> str:
    blob = f"{heading} {line}".lower()
    lower = rel_path.lower()
    if "00-bquant-hard-stops" in lower:
        return "hard_stop"
    if "24-etf-field-migration" in lower:
        return "incident"
    if (
        "25-etf-capping" in lower
        or "26-mdx-scan" in lower
        or "27-etf-spread" in lower
        or "28-fi-index" in lower
    ):
        return "freeze"
    if (
        "project-etf-capping" in lower
        or "project-mdx-scan" in lower
        or "project-etf-spread" in lower
        or "project-fi-index" in lower
    ):
        return "freeze"
    if "21-bquant-whats-new" in lower:
        return "announcement"
    if "23-bql-substitution" in lower:
        return "diligence"
    if NEGATION.search(blob):
        return "prohibition"
    if "08-bql-data-items" in lower or "07-pybql-api-reference" in lower:
        return "primary_candidate"
    return "atlas"


def add_hit(
    hits: dict[str, dict[tuple[str, str], dict[str, Any]]],
    token: str,
    path: Path,
    heading: str,
    line: str,
    family: str,
) -> None:
    token = token.lower()
    if token in SKIP_BARE_TOKENS and family != "data":
        return
    rel = relative(path)
    heading = heading or "(no heading)"
    role = guess_role(rel, heading, line)
    key = (rel, heading)
    bucket = hits[token]
    sample = re.sub(r"\s+", " ", line).strip()
    if len(sample) > MAX_SAMPLE:
        sample = sample[: MAX_SAMPLE - 1] + "…"
    if key not in bucket:
        bucket[key] = {
            "path": rel,
            "heading": heading,
            "role": role,
            "hits": 0,
            "sample": sample,
            "families": set(),
        }
    row = bucket[key]
    row["hits"] += 1
    row["families"].add(family)
    if ROLE_RANK.get(role, 9) < ROLE_RANK.get(row["role"], 9):
        row["role"] = role
        row["sample"] = sample


def scan_file(
    path: Path,
    hits: dict[str, dict[tuple[str, str], dict[str, Any]]],
    overlay_tokens: dict[str, Any],
) -> None:
    heading = ""
    alias_patterns: list[tuple[str, re.Pattern[str]]] = []
    for name, spec in overlay_tokens.items():
        names = [name.replace("_", " "), name, *spec.get("aliases", [])]
        # Prefer explicit aliases; skip the auto space-form when it is a
        # single BQL identifier (fundamentalticker stays exact).
        unique: list[str] = []
        for alias in names:
            alias = str(alias).strip()
            if alias and alias not in unique:
                unique.append(alias)
        for alias in unique:
            if alias == name.replace("_", " ") and "_" in name and " " not in name:
                if name not in {"ultimate_parent", "fill_prev"}:
                    continue
            alias_patterns.append(
                (name, re.compile(re.escape(alias), re.IGNORECASE))
            )

    for raw in read_text(path).splitlines():
        heading_match = HEADING.match(raw)
        if heading_match:
            heading = heading_match.group(2).strip()
        for match in BQ_CALL.finditer(raw):
            add_hit(
                hits,
                match.group("name"),
                path,
                heading,
                raw,
                match.group("family"),
            )
        seen_overlay: set[str] = set()
        for name, pattern in alias_patterns:
            if name in seen_overlay:
                continue
            if pattern.search(raw):
                seen_overlay.add(name)
                add_hit(hits, name, path, heading, raw, "overlay")


def default_policy(token: str) -> dict[str, Any]:
    return {
        "kind": "uncurated",
        "identity": "unspecified",
        "primary": [],
        "freeze": [],
        "prohibition": [],
        "do_not_open_for_implementation": [],
        "co_mentions_are_not_hops": [],
        "next_hops_if_must_resolve": [],
        "hop_policy": (
            "No curated overlay. Use Census roles: prohibition/incident/"
            "hard_stop/freeze first. Do not hop from co-mentions. Prefer "
            "07/08 if those rows exist. Conflict → stop and ask."
        ),
    }


def serialize_hits(
    token_hits: dict[tuple[str, str], dict[str, Any]],
) -> tuple[list[dict[str, Any]], int, int]:
    rows = []
    for row in token_hits.values():
        rows.append(
            {
                "path": row["path"],
                "heading": row["heading"],
                "role": row["role"],
                "hits": row["hits"],
                "sample": row["sample"],
                "families": sorted(row["families"]),
            }
        )
    rows.sort(
        key=lambda item: (
            ROLE_RANK.get(item["role"], 9),
            item["path"],
            item["heading"],
        )
    )
    truncated = max(0, len(rows) - MAX_ROWS_PER_TOKEN)
    return rows[:MAX_ROWS_PER_TOKEN], truncated, len(rows)


def md_escape(text: str) -> str:
    return text.replace("|", "\\|").replace("\n", " ")


def render_markdown(
    overlay: dict[str, Any],
    census: dict[str, Any],
) -> str:
    overlay_tokens = overlay["tokens"]
    names = sorted(census)
    lines = [
        "---",
        "generated: true",
        "role: concept_census",
        "never_edit: true",
        "---",
        "",
        "# Concept index (generated)",
        "",
        "> Generated by `RAG KB/build_concept_index.py` via",
        "> `RAG KB/regenerate_kb_bundle.py`. Never edit this file.",
        "> Overlay: `RAG KB/concept_index_overlay.json`.",
        ">",
        "> **Do not read this file linearly.** Search the exact `## token`",
        "> heading. Named-app freezes on `25` / `26` / `27` / `28` / `29` /",
        "> project `.mdc` skip this index.",
        "",
        "## How to use",
        "",
        "1. Named destination or freeze card → stop; do not use this index.",
        "2. Clear composition goal → `BUNDLE_EXAMPLES.md` Goal table first",
        "   (one card). This index is for tokens not on that card.",
        "3. Open **this token only**. Read Policy, then Census. Prohibition",
        "   and incident rows are first-class — do not skip them.",
        "4. Independent relevance review: same identity layer, same universe,",
        "   required for **this** Request? Co-mention is not a hop.",
        "5. Next hop only if Policy lists it under `next_hops_if_must_resolve`",
        "   **and** review still needs it. Repeat census for that exact token.",
        "   Maximum two hops after the first census.",
        "6. Conflict, restriction, or blank evidence → stop (Rejected or",
        "   Unresolved). Then `23` if still substituting. Do not implement",
        "   from `09` / `11` / `22` description similarity.",
        "",
        "## Token list",
        "",
    ]
    for name in names:
        mark = "curated" if name in overlay_tokens else "census-only"
        lines.append(f"- [`{name}`](#{name}) ({mark})")
    lines.append("")
    for name in names:
        spec = overlay_tokens.get(name, default_policy(name))
        payload = census[name]
        lines.extend(
            [
                f"## {name}",
                "",
                "### Policy",
                "",
                f"- Kind: `{spec['kind']}`",
                f"- Identity: `{spec['identity']}`",
                f"- Hop policy: {spec['hop_policy']}",
            ]
        )
        for label, key in (
            ("Primary", "primary"),
            ("Freeze", "freeze"),
            ("Prohibition", "prohibition"),
            ("Do not open for implementation", "do_not_open_for_implementation"),
            ("Co-mentions are not hops", "co_mentions_are_not_hops"),
            ("Next hops if must-resolve", "next_hops_if_must_resolve"),
        ):
            values = spec.get(key) or []
            if values:
                joined = "; ".join(f"`{item}`" for item in values)
                lines.append(f"- {label}: {joined}")
        lines.extend(
            [
                "",
                "### Census",
                "",
                f"Locations (unique file+heading): {payload['location_count']}.",
            ]
        )
        if payload["truncated"]:
            lines.append(
                f"Table truncated to {MAX_ROWS_PER_TOKEN} rows "
                f"({payload['truncated']} omitted; unique locations still "
                f"counted above)."
            )
        lines.extend(
            [
                "",
                "| Role | File | Heading | Hits | Sample |",
                "|---|---|---|---:|---|",
            ]
        )
        for row in payload["rows"]:
            lines.append(
                "| `{role}` | `{path}` | {heading} | {hits} | {sample} |".format(
                    role=row["role"],
                    path=row["path"],
                    heading=md_escape(row["heading"]),
                    hits=row["hits"],
                    sample=md_escape(row["sample"]),
                )
            )
        lines.append("")
    return "\n".join(lines) + "\n"


def build_concept_index() -> tuple[str, str]:
    overlay = load_overlay()
    overlay_tokens: dict[str, Any] = overlay["tokens"]
    hits: dict[str, dict[tuple[str, str], dict[str, Any]]] = defaultdict(dict)
    for path in census_files():
        scan_file(path, hits, overlay_tokens)

    missing = [name for name in overlay_tokens if name not in hits]
    if missing:
        raise RuntimeError(
            "Overlay tokens with zero census hits: " + ", ".join(sorted(missing))
        )

    census: dict[str, Any] = {}
    for token, token_hits in hits.items():
        rows, truncated, location_count = serialize_hits(token_hits)
        census[token] = {
            "curated": token in overlay_tokens,
            "location_count": location_count,
            "truncated": truncated,
            "rows": rows,
        }

    md = render_markdown(overlay, census)
    payload = {
        "schema_version": 1,
        "generated_by": "RAG KB/build_concept_index.py",
        "overlay": relative(OVERLAY_PATH),
        "token_count": len(census),
        "curated_count": sum(1 for row in census.values() if row["curated"]),
        "tokens": census,
    }
    js = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    return md, js


def validate_generated_markdown(md: str) -> None:
    overlay = load_overlay()
    for name in overlay["tokens"]:
        if f"## {name}\n" not in md:
            raise RuntimeError(f"Generated concept index missing ## {name}")
    for needle in (
        "## How to use",
        "Co-mention is not a hop",
        "Independent relevance review",
        "BUNDLE_EXAMPLES.md",
    ):
        if needle not in md:
            raise RuntimeError(f"Concept index missing required phrase: {needle}")
