---
topic_id: "21"
title: BQuant What's New
role: release_authority
authority_for: [release_status, deprecation, Beta, platform_availability]
not_authority_for: [api_signatures, entitlement_authorization]
evidence_grades: [canonical, announcement-only]
risk_tier: normal
routing_keywords: [whats_new, release, deprecated, Beta, GA, Desktop, Enterprise]
mandatory_cross_checks: [00-RAG-INDEX, affected_topic, 22-BQuant_DataItems]
restricted_sections: [restricted_announcements_documentation_only]
source_families: [whats_new]
---

# BQuant What's New — Curated Release Digest

> Canonical rolling digest for BQuant product changes.
> Current source snapshot: `RAG KB/Raw source/What's New ｜ BQuant Desktop Help Center (2026_7_25 上午12：36：44).html`
> Snapshot date: 2026-07-25. Source coverage: June 2026 through June 2025, plus archived posts to October 2023.

---

## Retrieval and Ingestion Policy

- Use this file for release dates, deprecations, GA/Beta status, platform cutovers, and newly announced capabilities.
- Use routed topic files for implementation recipes; exact-search data-item names in `22` and use `08` for curated interpretation.
- A What's New mention proves announcement context, not the exact current PyBQL signature or entitlement. Exact-search data-item names in `22`; use FLDS/API verification only for unresolved semantics/signatures.
- Desktop and Enterprise availability flags must not be merged. Enterprise-only releases remain non-actionable for this Desktop project.
- New snapshots replace overlapping months in this digest. Do not append duplicate monthly entries.

```mermaid
flowchart LR
  S[New What's New HTML] --> X[Extract month, category, title, D/E]
  X --> D[Diff against current digest]
  D --> H[Promote hard cutovers to applicable MDC rules]
  D --> T[Patch domain topics and catalog/interpretation queues]
  D --> R[Replace overlapping digest months]
  H --> I[Update 00 router and 16 ledger]
  T --> I
  R --> I
  I --> K[Regenerate bundle]
```

## High-Impact Current State

### Portfolio Library
- **Version 2.1 (June 2026):** portfolio metadata properties include position type, source, currency, and asset class.
- General write operations — update, clear, save, review, and revert — are generally available in 2.1 and do not require the former beta enablement.
- `create_port_portfolio()` remains **Beta**.
- `PortfolioType` is deprecated in favor of `PositionType`.
- `list_portfolios()` includes currency and last-updated metadata.
- Portfolio date parameter migration: `as_of_dates` was renamed to `dates`.
- Legacy `bqport` is unsupported after April 2026; do not generate new `bqport` code.

### BQL methodology and defaults
- **LTM fundamentals:** the revised `fa_period_type` LTM blending methodology became mandatory after 2025-11-17. The former `new_method_ltm_blending='N'` opt-out is no longer available.
- **ESG scores:** since August 2025, ESG score queries default to the latest value; historical analysis must request dates explicitly.
- Cross-currency bond spread/yield history and daily analytics have expanded over time; availability still depends on item, currency, and entitlement.

### Desktop platform
- BQuant Desktop upgraded to JupyterLab **4.3.6** in July 2025.
- The ipywidgets v8 advisory warns that v7 behavior is not fully compatible; validate callbacks, layout properties, and upload widgets during migration.
- Desktop supports selectable Python Version Environments; test environment upgrades before production use.
- Project Favorites and Archive were added in July 2025.

## Rolling Monthly Digest

### June 2026
- **BQL — Desktop + Enterprise:** real-time new-issue screening aligned with SRCH/PREL workflows.
- **Portfolio Library 2.1 — Desktop + Enterprise:** metadata properties, expanded `list_portfolios()` output, GA write operations, Beta portfolio creation, and `PortfolioType` deprecation.
- **Help Center:** BQL for Securitized Products and Using pandas in BQuant.
- **Enterprise only:** GitHub Enterprise Cloud Integration.

### May 2026
- **Platform — Desktop + Enterprise:** BQAP search, sort, and filter redesign.
- **BQL — Desktop + Enterprise:** enhanced `fundamentalticker()` mapping for bond/loan issuers; `parent(type='CAST')` ultimate-parent mapping; Private Credit coverage.
- **Desktop:** Python Version Environments documentation.
- **Help Center:** Linking Components Together and new example/research pages.

### April 2026
- **BQL — Desktop + Enterprise:** sustainable-finance revenue exposure, repo/forward pricing, expanded municipal ratings, and municipal `fundamentalticker()` mappings.
- **Enterprise only:** connectivity verification documentation.

### March 2026
- **BQL — Desktop + Enterprise:** contributor economic forecasts, expanded labor-market indicators, `commodities()` universe, and longer cross-currency bond analytics history.
- **Help Center:** additional analysis examples and redesigned navigation landing pages.

### February 2026
- **Desktop + Enterprise:** PyBQL Release Notes and Aligning and Merging BQL Responses documentation.
- **Enterprise only:** Textual Analytics and LLM services documentation.

### January 2026
- **BQL — Desktop + Enterprise:** SBI bond classification, BNEF TRACT climate-transition revenue, and commodity-curve members.
- **Portfolio Library 1.8:** portfolio discovery/read/write evolution and migration from `bqport`.
- **Enterprise only:** snapshot-based apps and Core Enterprise capabilities.

### November 2025
- **BQL — Desktop + Enterprise:** US BDC Aggregate Index and expanded cross-currency spread/yield history.
- **Portfolio Library:** general availability, PRTU discovery/read, cash handling, `as_of_dates` → `dates`, and the April 2026 `bqport` support cutoff.
- **Enterprise only:** cron-expression schedules.

### October 2025
- **BQL — Desktop + Enterprise:** LTM blending methodology cutover, securitized-product analytics, and YAS custom analytics.
- **Enterprise only:** Equity Signal Lab releases.

### September 2025
- **BQL — Desktop + Enterprise:** COT data, policy-uncertainty series, and motor-vehicle series.
- **Desktop:** dedicated BFIN connectivity documentation.
- **Enterprise only:** cloud/private-connectivity and Equity Signal Lab content.

### August 2025
- **BQL — Desktop + Enterprise:** historical BI Credit Drivers, latest-by-default ESG scores, and historical BVAL risk measures.
- **Enterprise only:** Python files in schedules.

### July 2025
- **Platform — Desktop + Enterprise:** project Favorites and Archive.
- **Desktop:** JupyterLab 4.3.6.
- **BQL — Desktop + Enterprise:** industrial indicators, syndicated-loan issuance pricing, and leveraged-loan indices.

### June 2025
- **BQL — Desktop + Enterprise:** implied overnight rates and GHG forecasts.
- **Enterprise only:** Equity Signal Lab release.

## Archived Release Themes (May 2025–October 2023)

- Platform evolution: JupyterLab upgrades, debugger support, `%package` improvements, Ubuntu 22.04, maintenance notifications, network requirements, and ipywidgets v8 migration.
- BQL expansion: macro indicators, alternative data, ratings, issuance analytics, curves, cashflows, dividends, factor exposure, total return, calendars, and securitized analytics.
- Enterprise-only evolution: custom environments, Git, schedules, Derived Results, Sandbox/cloud integration, Intraday Analytics, Equity Signal Lab, BQPOpt, and scalable compute.
- Historical entries are discovery evidence only. Current implementation must follow the latest overlapping release and routed topic documentation.

## What's New–Observed API Queue

This section is an announcement index only. Canonical name cross-checks and interpretation status live in `08-bql-data-items.md` → **What's New–observed API queue**.

Critical boundary:
- `job_openings()` has no exact `22` match and must not be generated without user-supplied FLDS/API evidence.
- `parent(...)`, `fundamentalticker()`, `commodities()`, and `curvemembers(...)` are non-data-item APIs; `22` cannot validate them.
- All parameters, metadata, universe compatibility, and entitlement remain signature-gated even when a data-item name matches `22`.

## Future Snapshot Checklist

1. Keep the timestamped HTML in `RAG KB/Raw source/`.
2. Extract rows using `(month, category, normalized title)` as the primary key.
3. Replace overlapping months; append only genuinely newer months.
4. Promote changed deadlines, defaults, deprecations, and GA/Beta status to the applicable `.cursor/rules/*.mdc` and the domain topic.
5. Exact-search new data-item mnemonics in `22`; record matches and unresolved/non-data-item APIs in `08`.
6. Preserve Desktop/Enterprise availability flags.
7. Update `16` source count/snapshot date and regenerate the consolidated bundle.
