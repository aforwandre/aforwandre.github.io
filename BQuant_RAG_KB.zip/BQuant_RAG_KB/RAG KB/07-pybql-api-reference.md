---
topic_id: "07"
title: PyBQL API Reference
role: api_signature_reference
authority_for: [pybql_objects, request_response_api, documented_functions]
not_authority_for: [data_item_catalog, complete_universe_api]
evidence_grades: [canonical, tutorial-observed, user-confirmed]
risk_tier: normal
routing_keywords: [PyBQL, Service, Request, Response, execute_many, bq.univ, bq.func, bb_default_risk_obligor_ticker, cast_parent_equity_ticker, id_bb_company]
mandatory_cross_checks: [00-RAG-INDEX, 21-bquant-whats-new, 22-BQuant_DataItems]
restricted_sections: []
source_families: [api_reference, help_center]
---

# PyBQL API Reference (AI Compact)

> Purpose: Parameter-level PyBQL dictionary for coding assistants.  
> Complete data-item mnemonic catalog: `22-BQuant_DataItems.md`. Curated semantics: `08-bql-data-items.md`. Use cases: `11-sample-notebooks.md`.

## AI quick map
- Core classes: `Service`, `Request`, `Response` / Desktop `ArrowExecuteResponse`, `DataItem`, `let`, `combined_df`
- Accessors: `bq.data` / `bq.func` / `bq.univ`
- Group family: `group`, `ungroup`, `groupavg`, `grouprank`, `groupzscore`, `groupwinsorize`, ...
- Time series: `diff`, `pct_chg`, `pct_diff`, `rolling`, `cumsum`, `cumprod`, `range`, `today`
- Logic: `and_`, `or_`, `not_`, `if_`, `matches`, `between`, `in_`
- Never invent data-item names — exact-search `22`; use FLDS/current API docs only for unresolved names or signatures

```mermaid
flowchart LR
  S[bq = bql.Service] --> D[bq.data.*]
  S --> F[bq.func.*]
  S --> U[bq.univ.*]
  D --> R[bql.Request]
  F --> R
  U --> R
  R --> E[bq.execute]
  E --> DF["item.df() / pd.concat"]
```

## Compact entries

### Core / Service

### `_cde`
- `bql.Service.data._cde` | syntax `bq.data._cde(mnemonic, *args, **kwargs)`
- **Params:** `mnemonic` (str, required): CDE custom field mnemonic name (human-readable identifier created in CDE (Terminal CDE function)).; `*args` (tuple, optional): Positional data/frequency/fill parameters; valid groups: `(start, end, frq, fill)` or `(dates, fill)` / `frq` and `fill` optional within group.; `**kwargs` (dict, optional): Keyword data/frequency/fill parameters; valid groups: `(start, end, frq, fill)` or `(dates, fill)` / `frq` and `fill` optional within group.; `start` (str, optional): Inclusive start date; relative (e.g., `-1M`), absolute `YYYY-MM-DD`, or `bq.func.today()`; default `-1M`.; `end` (str, optional): Inclusive end date; relative/absolute/today(); default `-0d`.; `dates` (str | list, optional): As-of date (relative/absolute/today()) or date range via `bq.func.range()`.; `frq` (str, optional): Sampling frequency for time series; valid: `D,W,M,Q,S,Y`; default `D`.; `fill` (str, optional): Missing data fill; valid: `na, prev, next`; default `na`.
- **Does:** Returns custom data from Bloomberg Terminal CDE as a `bql.DataItem` usable in GET and in expressions. Date handling supports either explicit `(start, end, ...)` or `dates=...` (single date or `range(...)`).
- **Edges:** Missing custom data: controlled by `fill`; default `na` (i.e., missing remains missing).

### `bql.DataItem`
- `bql.DataItem` | syntax `bql.DataItem(name, metadata, output_column, positional_params, named_params)`
- **Params:** `name` (unknown, required): Not documented (constructor not intended for direct use).; `metadata` (unknown, required): Not documented.; `output_column` (unknown, required): Not documented.; `positional_params` (unknown, required): Not documented.; `named_params` (unknown, required): Not documented.
- **Does:** Represents a BQL universe, data item, or function, returned by other BQL APIs; supports chaining/nesting to build expressions.

### `bql.Service.(bqlItem method).let`
- `bql.Service.(bqlItem method).let` | syntax `bql_item.let(name=None)`
- **Params:** `name` (str, optional): Name for the resulting let Item (`_LetItem`).
- **Does:** Creates a Let Item wrapper for the current BqlItem (Python implementation of BQL `let()` clause) to name expressions for reuse/shortnames.
- **See also:** `bql.let()` : creates a Let Item from `(name, expression)` rather than from an existing Item.

### `bqlItem_parameters`
- `bql.Service.(BqlItem property).parameters` | syntax `<bql_item>.parameters`
- **Does:** Returns a dict of parameters constructed from `positional_params` and `named_params`.

### `bqlItem.with_additional_parameters`
- `bql.Service.(BqlItem method).with_additional_parameters` | syntax `<bql_item>.with_additional_parameters(**new_parameters)`
- **Params:** `new_parameters` (dict, required): Keyword parameters to add.
- **Does:** Returns a copy of the item with parameters supplemented by `new_parameters`. Conflict resolution: existing parameters win (new conflicting keys are ignored).
- **See also:** `with_updated_parameters()` : new parameters override existing on conflict.

### `bqlItem.with_parameters`
- `bql.Service.(BqlItem method).with_parameters` | syntax `<bql_item>.with_parameters(*args, **kwargs)`
- **Params:** `*args` (tuple, optional): Replacement positional parameters.; `**kwargs` (dict, optional): Replacement named parameters.
- **Does:** Returns a copy of the item with existing parameters replaced by provided args/kwargs.
- **See also:** `with_additional_parameters()` : supplements without overriding existing conflicts.; `with_updated_parameters()` : supplements and overrides conflicts.

### `bqlItem.with_updated_parameters`
- `bql.Service.(BqlItem method).with_updated_parameters` | syntax `<bql_item>.with_updated_parameters(**new_parameters)`
- **Params:** `new_parameters` (dict, required): Keyword parameters to add/override.
- **Does:** Returns a copy of the item with parameters supplemented by `new_parameters`. Conflict resolution: new parameters win (override existing keys).
- **See also:** `with_additional_parameters()` : existing parameters win on conflict.

### `bql.combined_df`
- `bql.combined_df` | syntax `bql.combined_df(response)`
- **Params:** `response` (bql.Response | Sequence[bql.SingleItemResponse], required): Response or sequence of SingleItemResponse.
- **Does:** Returns a pandas DataFrame combining multiple item responses via outer join on all non-value columns. If only one item in response: equivalent to that item's `.df()`.
- **Edges:** If non-value columns differ across items: behaves as if empty columns were inserted before joining. Deprecated since 0.140: use `pandas.concat([x.df()[x.name] for x in response], axis=1)` when `ID`/`DATE` are in the **index**. That concat **drops** a DATE **column** (Desktop Arrow timeseries) — keep keys and merge (`18`). `combined_df` remains a useful fallback when Arrow is not iterable.
- **See also:** `pandas.concat` : recommended replacement when dates live in the index.; `SingleItemResponse.df()` : per-item DataFrame (vs combined join across items).

### `bql.let`
- `bql.let` | syntax `bql.let(name, expression)`
- **Params:** `name` (str, required): Let variable name.; `expression` (bql.BqlItem, required): Expression to name.
- **Does:** Creates a Let Item (`_LetItem`) implementing BQL `let()` clause semantics for naming expressions.
- **See also:** `bqlItem.let()` : names an existing item (method form) vs function form taking `(name, expression)`.

### `bql.Request`
- `bql.Request` | syntax `bql.Request(universe, items, with_params=None, preferences=None)`
- **Params:** `universe` (bql.BqlItem | list[bql.BqlItem] | iterable[str] | str, required): Universe for FROM clause.; `items` (bql.BqlItem | list[bql.BqlItem], required): Data item(s) for GET clause.; `with_params` (dict, optional): Parameters applied across items/universes that accept them; omitted in WITH clause.; `preferences` (dict, optional): Output preferences (e.g., add non-default columns); emitted via `preferences()`.
- **Does:** Encapsulates universe + items + optional global parameters/preferences for execution via `Service.execute()`.
- **Edges:** A Python `str` (or list of `str`) is a **yellow-key security ID**, not a BQL function. Passing `"members('HSI Index')"` yields `Unable to parse request at '(['members('HSI'`. Index constituents: `bq.univ.members('HSI Index')`.

### `Request.to_string`
- `bql.Request.to_string` | syntax `<request>.to_string()`
- **Does:** Returns the BQL query string generated by the Request.

### `bql.Response`
- `bql.Response` | syntax `bql.Response(id=r, req)`
- **Params:** `id` (unknown, required): Not documented.; `req` (unknown, required): Not documented.
- **Does:** Sequence-like container of SingleItemResponse objects (one per requested item). Primary supported access: iterate/index then call `.df()` on each SingleItemResponse. `.single()` returns the only item response when exactly one exists.
- **Edges:** `.single()` raises exception if response contains more than one item. **Desktop:** `execute` / `execute_many` may return `ArrowExecuteResponse` (`bql.refactor.response.arrow_execute_response`). It is a valid response even when **not iterable**. Do not require `__iter__`. Extract with `len`/`[i]`, `.get(name)`, then `bql.combined_df`. `type(obj).__name__` containing `response` is the cheap success test; error tuples from `on_request_error` are not responses.
- **See also:** `SingleItemResponse.df()` : extract DataFrame per item.

### `Response.single`
- `bql.Response.single` | syntax `<response>.single()`
- **Does:** Returns the only SingleItemResponse if the response contains exactly one.
- **Edges:** Raises exception if more than one SingleItemResponse exists.
- **See also:** `response[0]` : index access (works regardless of count, but `.single()` enforces exactly-one).

### `bql.Service`
- `bql.Service` | syntax `bql.Service(preferences=None, query_parser=None)`
- **Params:** `preferences` (dict, optional): Default preferences for returned data.; `query_parser` (unknown, optional): Not documented.
- **Does:** Main entry point; provides accessors: `.data`, `.func`, `.univ`. Executes requests via `.execute()` / `.execute_many()`.

### `Service.execute`
- `bql.Service.execute` | syntax `bq.execute(request, callback=None, error_callback=None)`
- **Params:** `request` (str | bql.Request, required): Query string or Request object.; `callback` (callable, optional): Success callback taking `(response: bql.Response)`; if provided, return type changes.; `error_callback` (callable, optional): Error callback taking `(error_tuple)` where tuple has (error object, error message, traceback).
- **Does:** If `callback` and `error_callback` are None: returns `bql.Response`. If `callback` is provided: returns `bqlapi.promise.Promise`; data extraction must occur in callback.
- **Edges:** Return type changes when callback is passed (Response vs Promise).
- **See also:** `execute_many()` : async execution for multiple requests.

### `Service.execute_many`
- `bql.Service.execute_many` | syntax `bq.execute_many(requests, on_request_error=None, num_retries=0)`
- **Params:** `requests` (list[str | bql.Request], required): Requests or query strings.; `on_request_error` (callable, optional): Called on request failure; takes `(error_tuple)`; callback results included in returned results list.; `num_retries` (int, optional): Retry count; default 0.
- **Does:** Executes multiple requests asynchronously. Returns a generator of `bql.Response` objects.
- **Edges:** Error callback results included in returned results list (per docs). Zip results against the request-key sequence. A successful Desktop `ArrowExecuteResponse` is not iterable — do not treat that as `on_request_error` output (`18`, `09`).
- **See also:** `execute()` : single request execution.

### `Service.data`
- `bql.Service.data` | syntax `bq.data`
- **Does:** Namespace accessor for BQL data items.
- **See also:** `Service.data._cde` : access custom CDE fields (not in standard BQL data set).

### `data.bb_default_risk_obligor_ticker`
- `bql.Service.data.bb_default_risk_obligor_ticker` | syntax `bq.data.bb_default_risk_obligor_ticker(mode=null)`
- **Params:** `mode` (enumerated string, optional): Force cached snapshots taken several times a day, or real-time data (more current, slower). Default `null`. Accepted: `'CACHED'`, `'CACHED_ONLY'`, `'REALTIME'`, `'INTRADAY'`, `'DEFAULT'`, `'STAGE_INTERNAL'`. `'CACHED_ONLY'` and `'INTRADAY'` are currently unavailable.
- **Does:** Provides the equity ticker used to calculate default risk measures of a bond, corporate, or sovereign entity.
- **Associated columns:** `id` (string; ticker/security/group identifier; not default output); `value` (string; main obligor ticker; default output; header is `Value` or the `get()` expression).
- **Edges:** Non-default columns require Request `preferences` with `addCols` plus the column name. Exact `22` row exists as spelling only. This is a DRSK-family field, not a listing converter. Production ETF use is leftover Thai `/F` and `-R` pricing identity only (`08`, `23`, `24`). Never request it on a mixed equity/cash/index universe.
- **Desktop observation (user-confirmed 2026-08-28):** `bq.data.bb_default_risk_obligor_ticker()` with Request `with_params={'mode': 'cached'}` returned string tickers without the yellow-key `Equity` suffix (`NVDA US`, `017670 KS`), `None` for some equities, and retrieval errors for cash and index. Append ` Equity` before using the value as a yellow key.
- **Evidence:** user-supplied official BQL tab 2026-09-01 (IMG_6671); Desktop execute 2026-08-28 (IMG_6672).

### `data.cast_parent_equity_ticker`
- `bql.Service.data.cast_parent_equity_ticker` | syntax `bq.data.cast_parent_equity_ticker(mode=null)`
- **Params:** `mode` (enumerated string, optional): Force cached snapshots or real-time data. Default `null`. Accepted: `'CACHED'`, `'CACHED_ONLY'`, `'REALTIME'`, `'INTRADAY'`, `'DEFAULT'`, `'STAGE_INTERNAL'`. `'CACHED_ONLY'` and `'INTRADAY'` are currently unavailable.
- **Does:** Provides the equity ticker of the Capital Structure (CAST) parent (`ID146`, `CAST_PARENT_ID`).
- **Associated columns:** `id` (string; not default output); `value` (string; CAST parent equity ticker; default output).
- **Edges:** Non-default columns require Request `preferences` `addCols`. Exact `22` row: `cast_parent_equity_ticker() | Capital Structure Parent Equity Ticker`. User-confirmed 2026-09-01: not a premium/restricted ESG family. Native identity is capital-structure **parent** equity, not a local listing and not DT110/DT679. ETF production must not request it as a Thai Pricing Ticker or as a replacement company key (`08`, `23`, `24`). `parent(type='CAST')` is a separate universe operation and remains unapproved here.
- **Evidence:** user-supplied official BQL tab 2026-09-01 (IMG_6675).

### `data.id_bb_company`
- `bql.Service.data.id_bb_company` | syntax `bq.data.id_bb_company(mode=null)`
- **Params:** `mode` (enumerated string, optional): Force cached snapshots or real-time data. Default `null`. Accepted: `'CACHED'`, `'CACHED_ONLY'`, `'REALTIME'`, `'INTRADAY'`, `'DEFAULT'`, `'STAGE_INTERNAL'`.
- **Does:** Returns a persistent unique Bloomberg company identifier (`ID035`) for the issuer or a subset of the issuer. Assigned to companies identified in Bloomberg systems. Historical values are not available.
- **Associated columns:** `id` (string; not default output); `value` (integer; default output).
- **Official examples:** `['AAPL US Equity']` → `101695`; `['INDU Index']` → `170310`; `bq.univ.members('INDU Index')` returns one integer per member (for example `AXP UN Equity` → `100061`).
- **Asset-class notes:** mortgages/structured finance may not identify a unique entity; futures return the series identifier; warrants and depository receipts return the underlying company; mutual funds return the fund, not the fund family.
- **Edges:** Exact `22` row: `id_bb_company() | Bloomberg Company Identifier`. User-confirmed 2026-09-01: not a premium/restricted ESG family. The value is an integer company ID, not a yellow-key Pricing Ticker and not a local Thai listing. ETF production must not request it as a price mapper or as the displayed Company Key; HelpDesk grouping remains `fundamentalticker()` lineage (`08`, `23`, `24`).
- **Evidence:** user-supplied official BQL tab and examples 2026-09-01 (IMG_6676, IMG_6677, IMG_6678).

### `Service.func`
- `bql.Service.func` | syntax `bq.func`
- **Does:** Namespace accessor for BQL functions.

### `Service.univ`
- `bql.Service.univ` | syntax `bq.univ`
- **Does:** Namespace accessor for BQL universe functions.

## Recipe-observed universe/value operations

This is a routing index to captured official tutorials, not a complete
parameter dictionary. Universe operations are outside the `22` data-item
catalog; absence from `22` proves nothing.

| Operation | Captured intent | Canonical recipe |
|---|---|---|
| `members()` | Index/AIM/PORT constituents | `01`, `02`, `11`; account parameters remain project/FLDS-specific |
| `holdings()` | Fund/portfolio holdings | `01`, `11`; holdings metadata uses uppercase keys |
| `holders()` | Holders of one instrument | `02`; not interchangeable with holdings |
| `bonds()` / `debt()` | Bond chains/capital structure | `02` |
| `equitiesuniv()` / `bondsuniv()` | Broad screens | `01` / `02`; use cached mode where documented |
| `translatesymbols()` | Composite/fundamental symbol transformation | `01`; transformation is not local-listing proof |
| `issuerof()` / `parent()` | Issuer/parent analysis mappings | `02`; parent semantics/signature require evidence |
| `fundamentalticker()` | Company-level fundamental mapping | `02` Company Analysis + `08` |
| `equitypricingticker()` | Company Analysis mapping example | `02`; equity-universe/local-listing behavior unresolved |

The user-confirmed company consolidation pattern preserves the input row by
mapping the universe function through the ID item:

```python
fundamental_ticker = bq.data.id().value(
    bq.univ.fundamentalticker(),
    mapby="lineage",
)
```

Direct `bq.univ.fundamentalticker(securities)` transforms the universe and can
discard the original position identity. Use the value/lineage form when the
original row must survive.

`fundamentalticker()` is a company-level grouping/validation value. It is not
evidence of a tradable local Pricing Ticker. Apply `23` before using any
universe mapping for another identity layer.

### Second Measure (also in `08`)

Second Measure entitlement and batch safety are not resolved by this API
entry. Any new use requires `23` due diligence and current user evidence.

### `observed_sales`
- `bql.Service.data.observed_sales` | syntax `bq.data.observed_sales()`
- **Does:** Bloomberg Second Measure metric: aggregated consumer transaction spend for covered companies (US consumer panel, debit/credit card).
- **See also:** `observed_transactions`: count of transactions (vs spend).; `average_transaction_value`: average spend per transaction (vs total spend).; `observed_unique_customers`: unique customers (vs spend).; `transactions_per_customer` / `sales_per_customer` : per-customer normalisations (vs total spend).

### `observed_transactions`
- `bql.Service.data.observed_transactions` | syntax `bq.data.observed_transactions()`
- **Does:** Bloomberg Second Measure metric: aggregated consumer transaction count.
- **See also:** `observed_sales`: spend (vs count).; `average_transaction_value`: average ticket (vs count).; `observed_unique_customers`: unique customers (vs count).

### `average_transaction_value`
- `bql.Service.data.average_transaction_value` | syntax `bq.data.average_transaction_value()`
- **Does:** Bloomberg Second Measure metric: aggregated average ticket (average value per transaction).
- **See also:** `observed_sales`: total spend (vs average).; `observed_transactions`: total count (vs average).

### `observed_unique_customers`
- `bql.Service.data.observed_unique_customers` | syntax `bq.data.observed_unique_customers()`
- **Does:** Bloomberg Second Measure metric: aggregated unique customers transacting.
- **See also:** `transactions_per_customer` : transactions normalised by customers.; `sales_per_customer` : spend normalised by customers.

### `transactions_per_customer`
- `bql.Service.data.transactions_per_customer` | syntax `bq.data.transactions_per_customer()`
- **Does:** Bloomberg Second Measure metric: transaction count per customer.
- **See also:** `observed_transactions` : raw count (vs per-customer).; `observed_unique_customers` : customer base used for normalisation.; `sales_per_customer` : spend per customer (vs transactions per customer).

### `sales_per_customer`
- `bql.Service.data.sales_per_customer` | syntax `bq.data.sales_per_customer()`
- **Does:** Bloomberg Second Measure metric: spend per customer.
- **See also:** `observed_sales` : raw spend (vs per-customer).; `observed_unique_customers` : customer base used for normalisation.; `transactions_per_customer` : transactions per customer (vs spend per customer).

### Functions (`bq.func` / chained methods)

### `func.bins`
- `bql.Service.func.bins` | syntax `bq.func.bins(param1, bins, bin_names=None, bin_weights=None)`
- **Params:** `param1` (Item, required): Any function or data item.; `bins` (Any_scalar, required): Bin boundaries.; `bin_names` (String, optional): Bin names; default null.; `bin_weights` (Double, optional): Bin weights (must be doubles); default null.
- **Does:** Buckets values from `param1` into bins defined by `bins` (exact bucketing semantics not described beyond parameters).

### `func.group`
- `bql.Service.func.group` | syntax `bq.func.group(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to group from IDs in the universe.; `by` (Item | list[Item], required): Grouping method(s); for multiple levels use list `[...]` evaluated left-to-right.
- **Does:** Moves the identifier boundary to pool data across IDs (single group) or bucket IDs by `by` into multiple groups. Enables aggregate/stat functions (avg/sum/etc.) to operate within group boundaries rather than per-ID.
- **Edges:** Multi-level grouping: list order matters (left-to-right).
- **See also:** `ungroup()` : projects group results back to per-ID rows.; `groupavg` / `groupcount` / ... : shortcuts for `ungroup(<stat>(group()))`.

### `func.ungroup`
- `bql.Service.func.ungroup` | syntax `bq.func.ungroup(param1, ungroupalllevels=None, intersectwithuniv=None, ungrouporder='UNIVERSE')`
- **Params:** `param1` (Item, required): Must contain a nested `group()` expression (docs: cannot ungroup without grouping first).; `ungroupalllevels` (bool, optional): If multiple `group()` levels exist, ungroup all levels when true; default null (docs describe default as "only last group").; `intersectwithuniv` (bool, optional): Whether UNGROUP performs a universe intersection; default null.; `ungrouporder` (Enumerated String, required): Output ID order; default `"UNIVERSE"`; other value `"CURRENT"`.
- **Does:** Converts group-level results back into per-ID rows by moving identifier boundary back around each ID and projecting group results onto each ID. Used to enable iterating calculations where both operands must return matching rows per ID.
- **Edges:** Requires nested `group()`; otherwise invalid. If upstream expression reorders IDs (e.g., `sort()`), must use `ungrouporder='CURRENT'` to avoid "reordered input" error.
- **See also:** `groupavg` / `groupcount` / `groupmax` / `groupmedian` / `groupmin` / `grouprank` / `groupsort` / `groupstd` / `groupsum` / `groupvwap` / `groupzscore` : shortcuts for `ungroup(<stat>(group()))`.

### `func.groupavg`
- `bql.Service.func.groupavg` | syntax `bq.func.groupavg(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to average.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups values by `by`, computes average per group, then repeats the group average for each member (per-ID rows). Shortcut for `ungroup(avg(group()))`.
- **See also:** `avg(group())` : returns one row per group (not per ID) - cannot be used directly in per-ID arithmetic without ungrouping.; `wavg` / `groupvwap` : weighted variants.

### `func.groupcount`
- `bql.Service.func.groupcount` | syntax `bq.func.groupcount(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values/IDs to count.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups by `by`, counts values per group, then repeats the group count for each member (per-ID rows). Shortcut for `ungroup(count(group()))`.
- **See also:** `count(group())` : returns one row per group (not per ID) - mismatch in per-ID arithmetic unless ungrouped.

### `func.groupcut`
- `bql.Service.func.groupcut` | syntax `bq.func.groupcut(valueItem, by, n)`
- **Params:** `valueItem` (Item, required): Values to bucket.; `by` (Item | list[Item], required): Grouping method(s).; `n` (Int, required): Number of bins.
- **Does:** Applies `cut()` within groups and returns per-ID rows (implied by "group*" pattern; detailed narrative not included in this doc section).
- **See also:** `cut()` : per-ID bucketing (without group projection).

### `func.groupmax`
- `bql.Service.func.groupmax` | syntax `bq.func.groupmax(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to take max over.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups by `by`, computes max per group, then repeats the group max for each member (per-ID rows). Shortcut for `ungroup(max(group()))`.
- **See also:** `max(group())` : one row per group; use `groupmax` for per-ID projection.; `cummax()` : running maximum over time series.

### `func.groupmedian`
- `bql.Service.func.groupmedian` | syntax `bq.func.groupmedian(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to take median over.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups by `by`, computes median per group, then repeats the group median for each member (per-ID rows). Shortcut for `ungroup(median(group()))`.
- **See also:** `median(group())`: one row per group; use `groupmedian` for per-ID projection.

### `func.groupmin`
- `bql.Service.func.groupmin` | syntax `bq.func.groupmin(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to take min over.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups by `by`, computes min per group, then repeats the group min for each member (per-ID rows). Shortcut for `ungroup(min(group()))`.
- **See also:** `min(group())`: one row per group; use `groupmin` for per-ID projection.; `cummin()`: running minimum over time series.

### `func.grouprank`
- `bql.Service.func.grouprank` | syntax `bq.func.grouprank(valueItem, by, order='DESC', ties='MIN')`
- **Params:** `valueItem` (Item, required): Values to rank.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).; `order` (Enumerated String, optional): `"DESC"` (default) or `"ASC"`.; `ties` (Enumerated String, optional): `"MIN"` (default); other values `"MAX"`, `"AVG"`.
- **Does:** Groups by `by`, ranks values within each group, returns per-ID rows with each member's rank. Shortcut for `ungroup(rank(group()))`.
- **See also:** `rank(group())`: ranks within group but returns group-level identifier context; `grouprank` preserves per-ID association.

### `func.groupstd`
- `bql.Service.func.groupstd` | syntax `bq.func.groupstd(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to compute std over.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups by `by`, computes standard deviation per group, then repeats the group std for each member (per-ID rows). Shortcut for `ungroup(std(group()))`.
- **See also:** `std(group())`: one row per group; use `groupstd` for per-ID projection.

### `func.groupsum`
- `bql.Service.func.groupsum` | syntax `bq.func.groupsum(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to sum.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Groups by `by`, sums values per group, then repeats the group sum for each member (per-ID rows). Shortcut for `ungroup(sum(group()))`.
- **See also:** `sum(group())`: one row per group; use `groupsum` for per-ID projection.; `cumsum()`: running sum over time series.

### `func.groupvwap`
- `bql.Service.func.groupvwap` | syntax `bq.func.groupvwap(values, weights, by=None)`
- **Params:** `values` (Item, required): Values to average.; `weights` (Item, required): Weights; must return same number of rows as values.; `by` (Item | list[Item], optional): Grouping method(s); default null.
- **Does:** Computes weighted average within group(s) and repeats the group weighted average for each member (per-ID rows). Shortcut for `ungroup(wavg(group()))`.
- **Edges:** Requires alignment: weights must match values row counts (explicit).
- **See also:** `wavg(group())`: one row per group; `groupvwap` projects to per-ID rows.; `avg` / `groupavg`: unweighted variants.

### `func.groupwinsorize`
- `bql.Service.func.groupwinsorize` | syntax `bq.func.groupwinsorize(param1, threshold_type, lower_limit, upper_limit, by=None)`
- **Params:** `param1` (Item, required): Values to winsorize.; `threshold_type` (Enumerated String, required): Threshold method, default `"STD"`, other values `"RNG"`, `"PCT"`, `"SCALAR"`.; `lower_limit` (Double, required): Lower threshold parameter (meaning depends on threshold_type); default -3 for STD per docs.; `upper_limit` (Double, required): Upper threshold parameter (meaning depends on threshold_type); default 3 for STD per docs.; `by` (Item | list[Item], optional): Grouping method(s); default null.
- **Does:** Calculates winsorization thresholds from each group's distribution, caps outliers, returns per-ID winsorized values (projected back onto each ID). Supports STD/PCT/RNG/SCALAR thresholding.
- **Edges:** Threshold semantics vary by threshold type: `STD`: caps outside N standard deviations from group mean. `PCT`: caps outside percentile bounds. `RNG`: caps outside range defined as % of (max-min) around median.
- **See also:** `winsorize()`: per-ID winsorization (not group-based).; `groupwinsorize` vs `winsorize(group())` : `groupwinsorize` is the per-ID projected group version.

### `func.groupzscore`
- `bql.Service.func.groupzscore` | syntax `bq.func.groupzscore(valueItem, by)`
- **Params:** `valueItem` (Item, required): Values to z-score.; `by` (Item | list[Item], required): Grouping method(s) (can be omitted in usage to mean whole-universe grouping; docs still show parameter).
- **Does:** Computes z-scores within group(s) and returns per-ID rows. Shortcut for `ungroup(zscore(group()))`.
- **See also:** `zscore(group())`: computes z-scores on grouped data but loses per-ID association unless ungrouped.; `zscore()`: per-ID z-scores within each ID boundary (not cross-ID).

### `func.cumavg`
- `bql.Service.func.cumavg` | syntax `bq.func.cumavg(param1)`
- **Params:** `param1` (Item, required): Time series or grouped series.
- **Does:** Running average: each row is average of current value and all preceding rows. For rows that "should have" null/NA/NaN (e.g., non-trading day), returns previous row's value (explicit).
- **Edges:** Null/NaN/Infinity handling: non-trading day nulls are carried forward as previous value (explicit).
- **See also:** `avg()` / `avg(group())` / `groupavg()`: non-cumulative averages.; `wavg()` / `groupvwap()`: weighted averages (non-cumulative).

### `func.cummax`
- `bql.Service.func.cummax` | syntax `bq.func.cummax(param1)`
- **Params:** `param1` (Item, required): Time series or grouped series.
- **Does:** Running maximum over rows in a time series or down a grouped list.
- **Edges:** Empty rows (no price on non-trading days) appear; docs suggest using `dropna()` to remove them.
- **See also:** `max()` / `max(group())` / `groupmax()`: non-cumulative maximum.

### `func.cummin`
- `bql.Service.func.cummin` | syntax `bq.func.cummin(param1)`
- **Params:** `param1` (Item, required): Time series.
- **Does:** Running minimum over rows in a time series or down a grouped list.
- **Edges:** Empty rows (no price on non-trading days) appear; docs suggest using `dropna()` to remove them.
- **See also:** `min()` / `min(group())` / `groupmin()`: non-cumulative minimum.

### `func.cumprod`
- `bql.Service.func.cumprod` | syntax `bq.func.cumprod(param1)`
- **Params:** `param1` (Item, required): Series to multiply cumulatively.
- **Does:** Running product over a time series or grouped list. Common finance pattern shown: `cumprod(1 + return_series(...).dropna()) - 1` for cumulative return.
- **Edges:** `return_series()` returns null/NA on first day and on non-trading days; docs recommend `dropna()` before `cumprod`.
- **See also:** `product()`: non-cumulative product.

### `func.cumsum`
- `bql.Service.func.cumsum` | syntax `bq.func.cumsum(param1)`
- **Params:** `param1` (Item, required): Series to sum cumulatively.
- **Does:** Running sum over a time series or grouped list.
- **Edges:** `return_series()` returns null/NA on first day; docs recommend `dropna()` before `cumsum`.
- **See also:** `sum()` / `sum(group())` / `groupsum()`: non-cumulative sums.; `add()` / `+`: addition of multiple scalars/items (not cumulative).

### `func.diff`
- `bql.Service.func.diff` | syntax `bq.func.diff(param1, step=None)`
- **Params:** `param1` (Item, required): Time series values.; `step` (Int, optional): Number of row steps to compare; default null.
- **Does:** Periodic net change over a data range: compares each value to the prior available value (or step rows back). First row always NaN (no prior comparison).
- **Edges:** Returns NaN on days with no new value (e.g., non-trading days) and for first row (explicit). Use `dropna()` to suppress NaN rows (explicit).
- **See also:** `net_chg()`: single net change between start/end dates (not periodic).; `pct_diff()`: periodic percent change (not net change).

### `func.net_chg`
- `bql.Service.func.net_chg` | syntax `bq.func.net_chg(param1)`
- **Params:** `param1` (Item, required): Values over a data range.
- **Does:** Returns a single net (absolute) change between the first and last values in the specified data range.
- **See also:** `pct_chg()`: single percent change between two dates.; `diff()`: periodic net changes across the range.

### `func.pct_chg`
- `bql.Service.func.pct_chg` | syntax `bq.func.pct_chg(param1, negative_values='ABS_BASE')`
- **Params:** `param1` (Item, required): Values over a date range.; `negative_values` (Enumerated String, optional): Negative value handling; default `"ABS_BASE"`; other values:; `"NO_NEGATIVE_CROSSOVER"`; `"NO_NEGATIVE_BASE"`; `"NORMAL"`; `"ABS_BASE_NO_NEGATIVE_CROSSOVER"`
- **Does:** Returns a single percent change between the first and last values in the specified date range.
- **Edges:** Negative base/crossover handling depends on `negative_values` (explicit enum list; exact formulas not documented here).
- **See also:** `net_chg()`: absolute change (vs percent).; `pct_diff()`: periodic percent changes or percent difference between two series.

### `func.pct_diff`
- `bql.Service.func.pct_diff` | syntax `bq.func.pct_diff(param1, param2=None, step=None, negative_values='ABS_BASE')`
- **Params:** `param1` (Item, required): Primary series.; `param2` (Item, optional): Second series for percent difference between two items/expressions.; `step` (Int, optional): Row step for periodic comparison.; `negative_values` (Enumerated String, optional): Default `"ABS_BASE"`; other values:; `"NO_NEGATIVE_CROSSOVER"`; `"NO_NEGATIVE_BASE"`; `"NORMAL"`; `"ABS_BASE_NO_NEGATIVE_CROSSOVER"`
- **Does:** Periodic percent change over a date range (like daily % change), OR percent difference between two items/expressions. First row in periodic mode is NaN (no prior comparison).
- **Edges:** Returns NaN for first row and for non-trading days with missing values (explicit). Use `dropna()` to remove NaN rows (explicit). Negative base/crossover handling depends on `negative_values` (enum list provided; formulas not documented).
- **See also:** `pct_chg()`: single percent change between two dates (not periodic).; `diff()`: periodic net change (not percent).

### `func.rolling`
- `bql.Service.func.rolling` | syntax `bq.func.rolling(param1, iterationdates)`
- **Params:** `param1` (Item, required): Data item or expression to evaluate.; `iterationdates` (Date range, required): Range of sampling dates; can be relative or absolute (examples: `range('-1Y', '0D')`, `range('2017-01-01', '2017-03-31')`).
- **Does:** Evaluates `param1` on each date in `iterationdates` and returns the sampled outputs (used to "time-slice" complex calculations). Docs note: for rolling calculations, the data window inside `param1` should be relative.
- **Edges:** Missing data in underlying series can be mitigated by using `fill="PREV"` on underlying data items (explicitly suggested).

### `func.dayofmonth`
- `bql.Service.func.dayofmonth` | syntax `bq.func.dayofmonth(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning date(s) (main value or an associated data column via `['date']`).; `scalar` (Any_scalar, required): Literal date (absolute `YYYY-MM-DD` or relative like `0D`, `-4D`, `-1M`).
- **Does:** Returns day-of-month integer in `[1..31]` from a date input. Can be applied to associated date columns (e.g., `expr['date']`) rather than the main value.
- **See also:** `month()`, `year()`, `dayofweek()`: other date-part extractors.

### `func.dayofweek`
- `bql.Service.func.dayofweek` | syntax `bq.func.dayofweek(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning date(s) (main value or an associated data column via `['date']`).; `scalar` (Any_scalar, required): Literal date (absolute `YYYY-MM-DD` or relative like `0D`, `-4D`, `-1M`).
- **Does:** Returns day-of-week integer in `[1..7]`; 1 denotes Sunday. Can be applied to associated date columns (e.g., `expr['date']`).
- **See also:** `dayofmonth()`, `month()`, `year()`.

### `func.hour`
- `bql.Service.func.hour` | syntax `bq.func.hour(param1)`
- **Params:** `param1` (Item, required): Any function or data item.; `scalar` (Any_scalar, required): Literal value (type depends on item, intended for datetime/time-like).
- **Does:** Returns hour component from a datetime/time input.
- **See also:** `minute()`.

### `func.minute`
- `bql.Service.func.minute` | syntax `bq.func.minute(param1)`
- **Params:** `param1` (Item, required): Any function or data item.; `scalar` (Any_scalar, required): Literal value (type depends on item, intended for datetime/time-like).
- **Does:** Returns minute component from a datetime/time input.
- **See also:** `hour()`.

### `func.month`
- `bql.Service.func.month` | syntax `bq.func.month(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning date(s) (main value or an associated data column via `['date']`).; `scalar` (Any_scalar, required): Literal date (absolute `YYYY-MM-DD` or relative like `0D`, `-4D`, `-1M`).
- **Does:** Returns month-of-year integer in `[1..12]` from a date input. Can be applied to associated date columns (e.g., `expr['date']`).
- **See also:** `dayofmonth()`, `year()`.

### `func.range`
- `bql.Service.func.range` | syntax `bq.func.range(start='0D', end='0d', frqstep=None, frq=None)`
- **Params:** `start` (Date|Int|String, optional): Start of inclusive range, can be relative (e.g., `"-1M"`, `"0D"`), absolute `"YYYY-MM-DD"`, or `today()`; default `"0D"` (signature-dependent).; `end` (Date|Int|String, optional): End of inclusive range; can be relative, absolute, or `today()`; default `"0D"` (signature-dependent).; `frqstep` (Int, optional): Positive integer step size between sampled points; default null.; `frq` (Enumerated String, optional): Frequency unit/type for data ranges; default null. Values: `"D", "W", "M", "Q", "S", "Y", "CW", "CM", "CQ", "CS", "CY"`.; `cdr` (Enumerated String, required in that signature): Calendar week setting, values `"5D", "7D"`.
- **Does:** Returns an inclusive range of dates, integers, or strings between start and end. For data ranges: sampling frequency defaults to daily; can be modified by `frq`/`frqstep`; `cdr` can exclude weekends (`"5D"`).
- **Edges:** Data range semantics: Relative dates: non-positive integer + unit (e.g., `"-3D"`, `"0D"`); shorter unit between start/end controls sampling frequency (documented).
- **See also:** `today()`: used as fixed end date for fixed ranges.; `'0D'`: used as rolling today marker in rolling ranges (see `today()`).

### `func.today`
- `bql.Service.func.today` | syntax `bq.func.today()`
- **Does:** Returns the current day's date (timestamp/date value). Used as a fixed today endpoint in fixed data ranges (e.g., `range('2019-01-01', today())`).
- **See also:** `'0D'`: use in rolling date ranges (`range('-3D', '0D')`) vs `today()` for fixed ranges.

### `func.year`
- `bql.Service.func.year` | syntax `bq.func.year(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning date(s) (main value or an associated data column via `['date']`).; `scalar` (Any_scalar, required): Literal date (absolute `YYYY-MM-DD` or relative like `0D`, `-4D`, `-1M`).
- **Does:** Returns year (YYYY) from a date input. Can be applied to associated date columns (e.g., `expr['date']`).
- **See also:** `month()`, `dayofmonth()`, `dayofweek()`.

### `func.concat`
- `bql.Service.func.concat` | syntax `bq.func.concat(param1, scalar)`
- **Params:** `param1` (Item, required): Any function or data item.; `param2` (Item, required): Any function or data item returning value(s) to concatenate; at least one operand must be string.; `scalar` (Any_scalar, required): Literal value to concatenate.; `scalar2` (Any_scalar, required): Literal value to concatenate.
- **Does:** Concatenates two values into a single string; output is always string. At least one operand must be a string; cannot concatenate two non-string types (e.g., double+double, date+date).
- **See also:** Operator `+`: can perform same concatenation when types allow (string concatenation).

### `func.left`
- `bql.Service.func.left` | syntax `bq.func.left(param1, num_chars)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `text` (str, required): Literal string to manipulate (alias of param1 in signature).; `num_chars` (Int, required): Number of characters to extract from left; includes whitespace/special chars; must be positive integer.
- **Does:** Extracts leftmost `num_chars` characters from a string.
- **See also:** `right()`: extracts from right side.; `len()`: returns string length.

### `func.len`
- `bql.Service.func.len` | syntax `bq.func.len(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `scalar` (Any_scalar, required): Literal string.
- **Does:** Returns number of characters in a string (includes whitespace/special chars).
- **See also:** `left()` / `right()`: substring extraction.

### `func.replace`
- `bql.Service.func.replace` | syntax `bq.func.replace(param1, start_num, num_chars, new_text)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `start_num` (Int, required): 1-based start position to begin replacement; must be positive integer.; `num_chars` (Int, required): Number of characters to replace.; `new_text` (String, required): Replacement substring (literal or from an expression returning string).
- **Does:** Rewrites part of a string by replacing `num_chars` starting at `start_num` with `new_text`.

### `func.right`
- `bql.Service.func.right` | syntax `bq.func.right(param1, num_chars)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `text` (str, required): Literal string to manipulate (alias of param1 in signature).; `num_chars` (Int, required): Number of characters to extract from right; includes whitespace/special chars; must be positive integer.
- **Does:** Extracts rightmost `num_chars` characters from a string.
- **See also:** `left()`: extracts from left side.; `len()`: returns string length.

### `func.startswith`
- `bql.Service.func.startswith` | syntax `bq.func.startswith(param1, scalar)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `param2` (Item, required): Any function or data item returning string(s) to compare against.; `scalar` (Any_scalar, required): Literal string to compare.; `scalar2` (Any_scalar, required): Literal string to compare.
- **Does:** Returns TRUE if the first characters of the first string match the second string; else FALSE.

### `func.tolower`
- `bql.Service.func.tolower` | syntax `bq.func.tolower(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `scalar` (Any_scalar, required): Literal string.
- **Does:** Converts string characters to lowercase.
- **See also:** `toupper()` : uppercase conversion.

### `func.toupper`
- `bql.Service.func.toupper` | syntax `bq.func.toupper(param1)`
- **Params:** `param1` (Item, required): Any function or data item returning string(s).; `scalar` (Any_scalar, required): Literal string.
- **Does:** Converts string characters to uppercase.
- **See also:** `tolower()` : lowercase conversion.

### `func.all`
- `bql.Service.func.all` | syntax `bq.func.all(param1)`
- **Params:** `param1` (Item, required): Predicate expression returning multiple TRUE/FALSE values (time series or grouped series).
- **Does:** Returns TRUE if predicate is TRUE for all rows within the current identifier boundary; FALSE if any row is FALSE. Default boundary is per-ID; can be changed by grouping (e.g., `group(...).all()`).
- **See also:** `any()` : TRUE if predicate TRUE for any row.; `not_()` : Invert predicate.; `group()` : change boundary for evaluation.

### `func.and_`
- `bql.Service.func.and_` | syntax `bq.func.and_(param1, scalar)`
- **Params:** `param1` (Item, required): Predicate/condition returning TRUE/FALSE.; `param2` (Item, required): Predicate/condition returning TRUE/FALSE.; `scalar` (Any_scalar, required): Literal TRUE/FALSE.; `scalar2` (Any_scalar, required): Literal TRUE/FALSE.
- **Does:** Logical AND of two conditions; TRUE only if both are TRUE. Equivalent to Python/BQL operator `and_` (explicitly stated).
- **See also:** `or_()` : inclusive OR.; `xor()` : exclusive OR.; `not_()` : inversion.

### `func.any`
- `bql.Service.func.any` | syntax `bq.func.any(param1)`
- **Params:** `param1` (Item, required): Predicate expression returning multiple TRUE/FALSE values (time series or grouped series).
- **Does:** Returns TRUE if predicate is TRUE for any row within the current identifier boundary; FALSE if all rows are FALSE. Default boundary is per-ID; can be changed by grouping (e.g., `group(...).any()`).
- **See also:** `all()` : TRUE only if all rows TRUE.

### `func.between`
- `bql.Service.func.between` | syntax `bq.func.between(param1, lscalar, rscalar)`
- **Params:** `param1` (Item, required): Value to test.; `lscalar` (Any_scalar, required): Literal range start.; `rscalar` (Any_scalar, required): Literal range end.; `param2` (Item, required): Range boundary (start or end depending on position).; `param3` (Item, required): Range boundary (end).; `scalar` (Any_scalar, required): Literal boundary (start or end depending on position).
- **Does:** Returns TRUE if `param1` is within inclusive range `[start, end]`; else FALSE. All three values must be same type (number or date) (explicit).
- **See also:** `in_()` : membership in list (vs numeric/date interval).

### `func.equals`
- `bql.Service.func.equals` | syntax `bq.func.equals(param1, rscalar)`
- **Params:** `param1` (Item, required): Value(s) to compare.; `param2` (Item, required): Value(s) to compare.; `lscalar` (Any_scalar, required): Literal value.; `rscalar` (Any_scalar, required): Literal value.; `lscalar_list` (Any_scalar, required): Literal list of values.; `rscalar_list` (Any_scalar, required): Literal list of values.
- **Does:** Returns TRUE if values are equal; else FALSE. Equivalent to operator `==` (explicit).
- **Edges:** Docs note (elsewhere) that comparisons on non-trading days can yield TRUE when both operands are null/NA (explicitly stated under notequals example; applies conceptually to equality too).
- **See also:** `notequals()` : inequality.; Operator `==` : same as `equals()`.

### `func.greater`
- `bql.Service.func.greater` | syntax `bq.func.greater(param1, rscalar)`
- **Params:** `param1` (Item, required): Value(s) to compare.; `param2` (Item, required): Value(s) to compare.; `lscalar` (Any_scalar, required): Literal value.; `rscalar` (Any_scalar, required): Literal value.; `lscalar_list` (Any_scalar, required): Literal list of values.; `rscalar_list` (Any_scalar, required): Literal list of values.
- **Does:** Returns TRUE if first value > second value; else FALSE. Equivalent to operator `>` (explicit).
- **See also:** `greaterthanequals()` : >= comparison.; `less()` / `lessthanequals()` : inverse comparisons.

### `func.greaterthanequals`
- `bql.Service.func.greaterthanequals` | syntax `bq.func.greaterthanequals(param1, rscalar)`
- **Params:** `param1` (Item, required): Value(s) to compare.; `param2` (Item, required): Value(s) to compare.; `lscalar` (Any_scalar, required): Literal value.; `rscalar` (Any_scalar, required): Literal value.; `lscalar_list` (Any_scalar, required): Literal list of values.; `rscalar_list` (Any_scalar, required): Literal list of values.
- **Does:** Returns TRUE if first value >= second value; else FALSE. Equivalent to operator `>=` (explicit).
- **See also:** `greater()` : > comparison.

### `func.if_`
- `bql.Service.func.if_` | syntax `bq.func.if_(condition_expression, true_expression, false_expression)`
- **Params:** `condition_expression` (Boolean, required): Predicate evaluated per universe member (ID).; `true_expression` (Unknown, required): Returned when condition_expression is TRUE (can be Item/scalar/string/another if_()).; `false_expression` (Unknown, required): Returned when condition_expression is FALSE.
- **Does:** Iterates over universe IDs; returns true_expression for IDs where condition is TRUE, else false_expression. Supports nested `if_()` for multi-branch logic.
- **See also:** `matches()` : filters rows of a series by predicate (vs per-ID branching).; `and_()` / `or_()` / `xor()` / `not_()` : predicate construction helpers.

### `func.in_`
- `bql.Service.func.in_` | syntax `bq.func.in_(param1, rscalar_list)`
- **Params:** `param1` (Item, required): Value(s) to test for membership.; `lscalar` (Any_scalar, required): Literal value to test.; `rscalar_list` (Any_scalar, required): Literal list of candidate values.
- **Does:** Returns TRUE if value is in the provided list; else FALSE.
- **See also:** `between()` : inclusive range test (vs discrete list).

### `func.less`
- `bql.Service.func.less` | syntax `bq.func.less(param1, rscalar)`
- **Params:** `param1` (Item, required): Value(s) to compare.; `param2` (Item, required): Value(s) to compare.; `lscalar` (Any_scalar, required): Literal value.; `rscalar` (Any_scalar, required): Literal value.; `lscalar_list` (Any_scalar, required): Literal list of values.; `rscalar_list` (Any_scalar, required): Literal list of values.
- **Does:** Returns TRUE if first value < second value; else FALSE. Equivalent to operator `<` (explicit).
- **See also:** `lessthanequals()` : <= comparison.

### `func.lessthanequals`
- `bql.Service.func.lessthanequals` | syntax `bq.func.lessthanequals(param1, rscalar)`
- **Params:** `param1` (Item, required): Value(s) to compare.; `param2` (Item, required): Value(s) to compare.; `lscalar` (Any_scalar, required): Literal value.; `rscalar` (Any_scalar, required): Literal value.; `lscalar_list` (Any_scalar, required): Literal list of values.; `rscalar_list` (Any_scalar, required): Literal list of values.
- **Does:** Returns TRUE if first value <= second value; else FALSE. Equivalent to operator `<=` (explicit).
- **See also:** `less()` : < comparison.

### `func.matches`
- `bql.Service.func.matches` | syntax `bq.func.matches(param1, param2)`
- **Params:** `param1` (Item, required): Data item/expression whose output rows will be filtered.; `param2` (Item, required): Predicate (Boolean expression) applied row-wise to screen param1 output.
- **Does:** Filters values returned by param1: keeps rows where predicate TRUE, suppresses rows where predicate FALSE. By default, still returns a row per universe member even if no matches; non-matching rows have NA value (explicit note); can drop with `dropna(remove_id=True)`.
- **Edges:** Non-matching rows: present but empty unless post-processed with `dropna(remove_id=True)` (explicit).
- **See also:** `univ.filter()` : Filters IDs in FROM clause (universe-level) vs `matches()` filters values in GET clause (row-level).

### `func.not_`
- `bql.Service.func.not_` | syntax `bq.func.not_(param1)`
- **Params:** `param1` (Item, required): Predicate/condition returning TRUE/FALSE.; `scalar` (Any_scalar, required): Literal TRUE/FALSE.
- **Does:** Logical NOT: returns TRUE if input condition is FALSE; else FALSE.
- **See also:** `and_()` / `or_()` / `xor()` : predicate combinators.

### `func.notequals`
- `bql.Service.func.notequals` | syntax `bq.func.notequals(param1, rscalar)`
- **Params:** `param1` (Item, required): Value(s) to compare.; `param2` (Item, required): Value(s) to compare.; `lscalar` (Any_scalar, required): Literal value.; `rscalar` (Any_scalar, required): Literal value.; `lscalar_list` (Any_scalar, required): Literal list of values.; `rscalar_list` (Any_scalar, required): Literal list of values.
- **Does:** Returns TRUE if values are different; FALSE if values are the same. Equivalent to operator `!=` (explicit).
- **Edges:** Docs explicitly note: on non-trading days, both operands may be null/NA, and output displays TRUE; use `dropna()` to remove null/NA rows (explicit).
- **See also:** `equals()` : equality.; `dropna()` : remove null/NA rows after comparison.

### `func.or_`
- `bql.Service.func.or_` | syntax `bq.func.or_(param1, scalar)`
- **Params:** `param1` (Item, required): Predicate/condition returning TRUE/FALSE.; `param2` (Item, required): Predicate/condition returning TRUE/FALSE.; `scalar` (Any_scalar, required): Literal TRUE/FALSE.; `scalar2` (Any_scalar, required): Literal TRUE/FALSE.
- **Does:** Inclusive OR: TRUE if one or both conditions TRUE; FALSE only if both FALSE.
- **See also:** `and_()`, `xor()`, `not_()`

### `func.xor`
- `bql.Service.func.xor` | syntax `bq.func.xor(param1, scalar)`
- **Params:** `param1` (Item, required): Predicate/condition returning TRUE/FALSE.; `param2` (Item, required): Predicate/condition returning TRUE/FALSE.; `scalar` (Any_scalar, required): Literal TRUE/FALSE.
- **Does:** Exclusive OR: TRUE if exactly one condition is TRUE; FALSE if both TRUE or both FALSE.
- **See also:** `or_()` : inclusive OR.; `and_()`, `not_()`
