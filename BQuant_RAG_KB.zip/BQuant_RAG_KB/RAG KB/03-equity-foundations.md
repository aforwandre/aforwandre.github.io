---
topic_id: "03"
title: Equity Foundations
role: onboarding_map
authority_for: [equity_learning_path]
not_authority_for: [api_signatures, data_item_semantics]
evidence_grades: [canonical]
risk_tier: normal
routing_keywords: [equity, onboarding, learning]
mandatory_cross_checks: [00-RAG-INDEX, 01-bql-for-equities]
restricted_sections: []
source_families: [workspace_curation]
---

# Developing in BQuant — Equity Foundations

> AI-oriented learning map for equity workflows in CURSOR_BQNT.
> Execution: Bloomberg BQuant only (Python 3.11). Local Cursor is for design and review.

---

## What This Path Covers

Equity development in BQuant centers on PyBQL universe construction, multi-item requests, group-prefix ranking/scoring, and interactive Plotly dashboards. You do not need Help Center navigation chrome — follow the linked topic files below.

```mermaid
flowchart TD
    A[05 Get Started] --> B[06 Get Data / 22 Catalog]
    B --> C[01 BQL for Equities]
    C --> D{Goal}
    D -->|Screening / scoring| E[19 Equity Scoring Model]
    D -->|Event study| F[20 Earnings Surprise]
    D -->|Field lookup| G[08 BQL Data Items]
    C --> H[11 Sample Notebooks snippets]
    E --> I[15 Share Results — Launchpad app]
    F --> I
```

---

## Core Skills Checklist

1. **Environment** — `import bql; bq = bql.Service()`; kernel-global namespace; Run All after reordering cells.
2. **Requests** — `bql.Request(universe, data_items)` with dict labels; `pd.concat` for multi-item responses.
3. **Universes** — `equitiesuniv`, `members`, `peers`, `holdings`; index weights via `id()['weights']` (lowercase) vs holdings `['WEIGHTS']` (uppercase).
4. **Filtering** — `univ.filter()` with `.and_()` / `.or_()`; cached mode on large screens.
5. **Ranking** — `grouprank`, `groupzscore`, `groupmedian`; `matches()` when filter must not recalculate group stats.
6. **Visualization** — Plotly with `fig.batch_update()`; ipywidgets for interactivity.

---

## Topic File Map

| Topic | File | Use when |
|-------|------|----------|
| Equities quickstart | `01-bql-for-equities.md` | First BQL patterns, filtering, scoring examples |
| Data-item catalog / semantics | `22-BQuant_DataItems.md`, `08-bql-data-items.md` | Exact names first; curated meaning and Second Measure fields |
| Scoring model | `19-equity-scoring-model.md` | Multi-factor equity screens |
| Earnings surprise | `20-earnings-surprise.md` | Event-driven momentum research |
| Snippet index | `11-sample-notebooks.md` | Copy-paste PyBQL patterns across asset classes |
| Pandas in BQuant | `18-using-pandas.md` | Post-BQL transforms |

---

## Project Practice Notes

- Local Cursor is for design/authoring only; execute BQL solely inside Bloomberg BQuant (Python 3.11).
- Never invent equity data mnemonics — exact-search `22`; use Terminal FLDS only for absent/ambiguous names or unresolved signatures.
- Allowed libraries: BQL, Pandas, Plotly, ipywidgets (no external APIs).
- Equity quickstarts and scoring examples: `01-bql-for-equities.md`, `19-equity-scoring-model.md`, `20-earnings-surprise.md`.
- Help Center equity example cards (peers, options, filings, Second Measure): see `01` section **Help Center Example Recipes (Equities)**; title catalog in `16`.
- Official Get Data equity family tutorials (Corporate Actions, Derivatives, Monitoring, Factors, Idea Generation, Alternative Data, Equities Tutorial): see `01` section **Get Data Official Tutorial: Equities Family**.
- Consumer transaction (Second Measure) items: `08-bql-data-items.md`.
