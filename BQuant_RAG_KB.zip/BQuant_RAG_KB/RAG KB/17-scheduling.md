---
topic_id: "17"
title: Scheduling Desktop Stop Card
role: platform_stop
authority_for: [desktop_scheduling_unavailable]
not_authority_for: [enterprise_scheduler_api]
evidence_grades: [canonical, gap-uncaptured]
risk_tier: stop
routing_keywords: [schedule, cron, nightly, recurring]
mandatory_cross_checks: [00-RAG-INDEX, 05-get-started, 21-bquant-whats-new]
restricted_sections: []
source_families: [help_center, whats_new]
---

# Scheduling — Desktop Stop Card

> This project is BQuant Desktop-only. Recurring schedules are unavailable and must not be proposed as an implementation path.

## Decision

| Request | Closed-world response |
|---------|-----------------------|
| Recurring/cron execution | Stop: Enterprise-only; offer a manual Run All workflow |
| Schedule a `.py` file | Stop: Enterprise-only |
| Automated nightly/periodic job | Stop: no Desktop scheduler; keep notebook logic idempotent for manual execution |
| User later confirms Enterprise entitlement | Request current Scheduling Help Center source before designing; no standalone page body is captured |

## Evidence

- What's New records cron-expression schedules (November 2025) and `.py` schedule support (August 2025), both Enterprise-only.
- No standalone Scheduling HTML exists in the current Raw source snapshot.
- Reusable manual-run design rules live in `05-get-started.md`; date-boundary patterns live in `02-bql-for-fixed-income.md`.
