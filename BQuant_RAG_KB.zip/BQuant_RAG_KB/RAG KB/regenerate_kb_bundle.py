"""Validate and rebuild the closed-world BQuant knowledge artifacts."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from build_bundle_examples import (
    BUNDLE_EXAMPLES_JSON,
    BUNDLE_EXAMPLES_MD,
    build_bundle_examples,
    validate_generated_markdown as validate_bundle_examples_markdown,
)
from build_concept_index import (
    CONCEPT_INDEX_JSON,
    CONCEPT_INDEX_MD,
    build_concept_index,
    validate_generated_markdown,
)


KB = Path(__file__).resolve().parent
WORKSPACE = KB.parent
RULES = WORKSPACE / ".cursor" / "rules"
BUNDLE = KB / "BQUANT_RAG_KNOWLEDGE_BASE.md"
MANIFEST = KB / "RAG_KB_MANIFEST.json"
INDEXING_IGNORE = WORKSPACE / ".cursorindexingignore"

TOPIC_METADATA_KEYS = {
    "topic_id",
    "title",
    "role",
    "authority_for",
    "not_authority_for",
    "evidence_grades",
    "risk_tier",
    "routing_keywords",
    "mandatory_cross_checks",
    "restricted_sections",
    "source_families",
}

REQUIRED_ALWAYS_RULES = {
    "00-bquant-hard-stops.mdc",
    "01-bquant-retrieval-protocol.mdc",
    "02-bql-substitution-due-diligence.mdc",
    "03-bql-pandas-safety.mdc",
    "95-visual-diff-gate.mdc",
}

EXPECTED_INDEX_EXCLUSIONS = {
    "/RAG KB/BQUANT_RAG_KNOWLEDGE_BASE.md",
    "/RAG KB/RAG_KB_MANIFEST.json",
    "/RAG KB/Raw source/",
    "/RAG KB/Official scripts/",
    "/RAG KB/Restricted reference/",
    "/RAG KB/22-BQuant_DataItems.md",
    "/RAG KB/CONCEPT_INDEX.md",
    "/RAG KB/CONCEPT_INDEX.json",
    "/RAG KB/BUNDLE_EXAMPLES.json",
    "/RAG KB/Technical_Analysis_Indicators.txt",
    "/RAG KB/09-build-analysis.md",
    "/RAG KB/11-sample-notebooks.md",
}

# Frontend files that must remain in the default semantic index.
FORBIDDEN_INDEX_EXCLUSIONS = {
    "/RAG KB/BUNDLE_EXAMPLES.md",
    "/RAG KB/00-RAG-INDEX.md",
    "/RAG KB/25-etf-capping-monitor.md",
    "/RAG KB/26-mdx-scan.md",
    "/RAG KB/27-etf-spread-monitor.md",
    "/RAG KB/28-fi-index-change.md",
    "/RAG KB/29-fi-spread-movement-monitoring.md",
}

ROUTE_ANCHORS = {
    "02-bql-for-fixed-income.md": {
        "### BQL for Fixed Income Company Analysis",
    },
    "06-get-data-overview.md": {
        "## Excel/API and substitution gate",
        "## Field Discovery — Catalog First, FLDS When Needed",
    },
    "07-pybql-api-reference.md": {
        "## Recipe-observed universe/value operations",
    },
    "08-bql-data-items.md": {
        "## Canonical company-ticker mapping",
        "## Market-status zero-price rule",
        "## Thai foreign-board local pricing safety",
    },
    "11-sample-notebooks.md": {
        "### BQL for AIM",
    },
    "15-share-results.md": {
        "## What a Published App Is",
        "## Snapshot versus auto-sync (user-confirmed practice, 2026-09-02)",
    },
    "18-using-pandas.md": {
        "### Desktop Arrow timeseries: keep DATE (practice-derived, 2026-08-27)",
    },
    "20-earnings-surprise.md": {
        "## Desktop request and response gate",
    },
    "23-bql-substitution-due-diligence.md": {
        "## Mandatory workflow",
        "## Risk score",
        "## Decision record",
    },
    "24-etf-field-migration-incident.md": {
        "## Failure chain",
        "## Correct architecture",
        "## Regression checklist",
    },
    "25-etf-capping-monitor.md": {
        "## Last-price, Last Close, and zero fallback",
        "## Unresolved: Monitor Company → Excel `SHORT_NAME`",
        "## Primary FM (not BQL)",
        "## AIM request shape (one account per Request)",
        "## Asset classifier and cash FX",
        "## Dynamic Limit, Rank, Near Limit",
        "## Minimum shippable package (one pass)",
    },
    "26-mdx-scan.md": {
        "## Member metadata and NameCN",
        "## Member and benchmark OHLCV",
        "## Pandas signal port (not BQL)",
        "## Minimum shippable package (one pass)",
    },
    "27-etf-spread-monitor.md": {
        "## What this card freezes",
        "## Periods and as-of date",
        "## Unresolved: bid, ask, and peer requests",
        "## Minimum shippable package (one pass)",
    },
    "28-fi-index-change.md": {
        "## Membership request",
        "## Projected month",
        "## Minimum shippable package",
    },
    "29-fi-spread-movement-monitoring.md": {
        "## Monitoring contract",
        "## Request and validation boundaries",
        "## Minimum shippable package",
    },
}

ROUTER_REGRESSION_CASES = {
    "DT110 parent ticker": {
        "DT110",
        "`08` § Canonical company-ticker mapping",
        "`23`",
    },
    "Thai /F local price": {
        "Thai `/F TB Equity` or N-NDVR local price",
        "project ETF rule + `24`",
        "pricing identity",
    },
    "Thai N-NDVR unresolved mapping": {
        "N-NDVR yellow key is `-R TB Equity`",
        "`08` § Thai foreign-board local pricing safety",
        "project ETF rule + `24`",
    },
    "API-only Excel field": {
        "Excel, BDP, BDH, API field, DT*, PR* migration",
        "`23` § Mandatory workflow",
        "user FLDS if unresolved",
    },
    "CAST listing proxy": {
        "Parent/CAST/obligor/listing proxy",
        "`24` § Failure chain",
        "reject as Thai price or DT110 replacement",
    },
    "fundamentalticker as price": {
        "A company/fundamental ticker is not automatically a tradable pricing ticker",
        "`24` § Failure chain",
        "run `23`",
    },
    "GHG mapping": {
        "ESG/GHG/climate/sustainable",
        "| STOP |",
        "do not open archived recipes for code generation",
    },
    "Arrow DATE": {
        "Pandas, Arrow, DATE, concat, execute_many",
        "`18`",
        "`07` Response + `09` Error Log",
    },
    "AIM ts_position": {
        "Current/Projected AIM position",
        "`11` § BQL for AIM",
        "project rule",
    },
    "market_status cached 6166": {
        "`market_status()` cached / PR286 / 6166 HK",
        "`08` § Market-status zero-price rule",
        "ETF runtime `25`",
    },
    "Last Close holiday fill": {
        "Last Close, holiday fill, last-price zero fallback",
        "`25` § Last-price, Last Close, and zero fallback",
        "`08` for field mapping only",
    },
    "BQAP Terminal Link": {
        "Launchpad publish, Terminal Link, BQAP, auto-sync",
        "`15` § Snapshot versus auto-sync",
        "ETF app practice in `25`",
    },
    "SHORT_NAME unresolved": {
        "ETF Monitor Company / Excel `SHORT_NAME`",
        "`25` § Unresolved: Monitor Company",
        "`08` blank-description trap",
    },
    "Primary FM not BQL": {
        "ETF Primary FM column or filter",
        "`25` § Primary FM",
        "not a BQL field",
    },
    "ETF Dynamic Limit": {
        "ETF Dynamic Limit / Rank / Near Limit",
        "`25` § Dynamic Limit",
        "do not add `crncy()`",
    },
    "MDX Scan runtime": {
        "MDX Scan any runtime change",
        "`26` then project `.mdc`",
        "`09` widgets/errors",
    },
    "MDX NameCN identity": {
        "MDX NameCN / Traditional Chinese security name",
        "`26` § Member metadata and NameCN",
        "do not use `name_chinese_traditional()`",
    },
    "one-pass reconstruction": {
        "Lost user-script rebuild / one-pass Desktop app",
        "`00` § 13 One-pass",
        "do not iterate by guessing",
    },
    "concept census": {
        "CONCEPT_INDEX.md",
        "Independent relevance review",
        "Co-mention is not a hop",
    },
    "proven bundles": {
        "BUNDLE_EXAMPLES.md",
        "Goal table",
        "third highway",
    },
    "destination navigator": {
        "## 2. Destinations (the route table)",
        "### Destination path (always first)",
        "Do **not** search `01`–`26`",
    },
    "unresolved catalog-only field": {
        "catalog-only",
        "stop and request",
        "22-BQuant_DataItems.md",
    },
}

FORBIDDEN_CANONICAL_CALL = re.compile(
    r"bq\.data\.(?:"
    r"esg|ghg|climate|sustainab|eu_tax|carbon|emission|temp_score|"
    r"green_bond|fossil_fuel|pct_women"
    r")",
    flags=re.IGNORECASE,
)

FORBIDDEN_PRODUCTION_CALL = re.compile(
    r"bq\.data\.(?:"
    r"esg|ghg|climate|sustainab|eu_tax|carbon|emission|temp_score|"
    r"green_bond|fossil_fuel|pct_women|cast_parent|"
    r"id_bb_company"
    r")",
    flags=re.IGNORECASE,
)

FORBIDDEN_CAST_UNIVERSE = re.compile(
    r"bq\.univ\.parent\s*\([^)]*CAST",
    flags=re.IGNORECASE,
)

APPROVED_ETF_DATA_CALLS = {
    "bb_default_risk_obligor_ticker",
    "id",
    "market_status",
    "name",
    "pending_position",
    "position_without_pending",
    "px_last",
}

APPROVED_ETF_UNIVERSE_CALLS = {
    "fundamentalticker",
    "members",
}

APPROVED_MDX_DATA_CALLS = {
    "classification_name",
    "id",
    "name",
    "official_trad_local_lang_sec_nm",
    "px_high",
    "px_last",
    "px_low",
    "px_open",
    "px_volume",
}

APPROVED_MDX_UNIVERSE_CALLS = {
    "members",
}

APPROVED_SPREAD_DATA_CALLS = {
    "crncy",
    "etf_undl_index_ticker",
    "exch_code",
    "fund_benchmark",
    "fund_benchmark_prim",
    "fund_class_assets",
    "fund_class_assets_crncy",
    "fund_comp_name",
    "actively_managed",
    "cur_mkt_cap",
    "fund_asset_class_focus",
    "fund_expense_ratio",
    "fund_flow",
    "fund_geo_focus",
    "fund_industry_focus",
    "fund_open_shr_class",
    "fund_strategy",
    "fund_total_assets",
    "fund_total_assets_crncy",
    "fund_typ",
    "id",
    "id_bb_company",
    "id_isin",
    "long_comp_name",
    "name",
    "px_ask",
    "px_bid",
    "px_last",
    "px_mid",
    "nav_tracking_error",
    "fund_net_asset_val",
    "tot_return_index_gross_dvds",
    "tracking_error",
}

APPROVED_SPREAD_UNIVERSE_CALLS = {
    "fundsuniv",
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def relative(path: Path) -> str:
    return path.relative_to(WORKSPACE).as_posix()


def parse_scalar(value: str) -> Any:
    value = value.strip()
    if not value:
        return None
    if value.startswith("[") and value.endswith("]"):
        content = value[1:-1].strip()
        if not content:
            return []
        return [
            item.strip().strip("\"'")
            for item in content.split(",")
            if item.strip()
        ]
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    if re.fullmatch(r"\d+", value):
        return int(value)
    return value.strip("\"'")


def parse_frontmatter(path: Path) -> tuple[dict[str, Any], str]:
    text = read_text(path)
    if not text.startswith("---\n"):
        raise RuntimeError(f"Missing YAML frontmatter: {relative(path)}")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise RuntimeError(f"Unclosed YAML frontmatter: {relative(path)}")
    block = text[4:end]
    body = text[end + 5 :]
    metadata: dict[str, Any] = {}
    active_key: str | None = None
    for raw_line in block.splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        if raw_line.startswith("  - "):
            if active_key is None:
                raise RuntimeError(
                    f"List item without key in {relative(path)}: {raw_line}"
                )
            current = metadata.setdefault(active_key, [])
            if not isinstance(current, list):
                raise RuntimeError(
                    f"Mixed scalar/list metadata in {relative(path)}: {active_key}"
                )
            current.append(raw_line[4:].strip().strip("\"'"))
            continue
        if ":" not in raw_line:
            raise RuntimeError(
                f"Malformed frontmatter in {relative(path)}: {raw_line}"
            )
        key, value = raw_line.split(":", 1)
        active_key = key.strip()
        parsed = parse_scalar(value)
        metadata[active_key] = [] if parsed is None else parsed
    return metadata, body


def topic_sources() -> list[Path]:
    sources = [KB / "00-RAG-INDEX.md"]
    for number in range(1, 30):
        matches = sorted(KB.glob(f"{number:02d}-*.md"))
        if len(matches) != 1:
            raise RuntimeError(
                f"Expected one canonical source for {number:02d}, got {matches}"
            )
        sources.append(matches[0])
    return sources


def rule_sources() -> list[Path]:
    rules = sorted(RULES.glob("*.mdc"))
    if not rules:
        raise RuntimeError("No Cursor rules found in .cursor/rules/")
    return rules


def canonical_sources() -> list[Path]:
    return [*rule_sources(), *topic_sources()]


def headings(text: str) -> list[dict[str, Any]]:
    rows = []
    for line in text.splitlines():
        match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if match:
            title = match.group(2).strip()
            slug = re.sub(r"[^a-z0-9\s-]", "", title.lower())
            slug = re.sub(r"[\s-]+", "-", slug).strip("-")
            rows.append(
                {
                    "level": len(match.group(1)),
                    "title": title,
                    "slug": slug,
                }
            )
    return rows


def line_count(text: str) -> int:
    return len(text.splitlines())


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def source_record(path: Path, known_topics: list[Path]) -> dict[str, Any]:
    metadata, body = parse_frontmatter(path)
    text = read_text(path)
    references = []
    for candidate in known_topics:
        if candidate == path:
            continue
        if candidate.name in text or candidate.stem in text:
            references.append(relative(candidate))
    return {
        "path": relative(path),
        "lines": line_count(text),
        "sha256": sha256(text),
        "metadata": metadata,
        "headings": headings(body),
        "cross_links": sorted(references),
    }


def manifest_int(router_metadata: dict[str, Any], key: str) -> int:
    value = router_metadata.get(key)
    if not isinstance(value, int):
        raise RuntimeError(f"Router metadata requires integer {key}")
    return value


def validate_balanced_fences(paths: list[Path]) -> None:
    for path in paths:
        fence_lines = sum(
            line.lstrip().startswith("```")
            for line in read_text(path).splitlines()
        )
        if fence_lines % 2:
            raise RuntimeError(f"Unbalanced code fences: {relative(path)}")


def validate_rules(rules: list[Path]) -> None:
    names = {path.name for path in rules}
    missing = REQUIRED_ALWAYS_RULES - names
    if missing:
        raise RuntimeError(f"Missing mandatory rules: {sorted(missing)}")
    obsolete = {
        "bquant-core.mdc",
        "bql-pandas-safety.mdc",
        "rag-maintenance.mdc",
        "etf-capping-monitor.mdc",
        "mdx-scan.mdc",
    } & names
    if obsolete:
        raise RuntimeError(f"Superseded rules still present: {sorted(obsolete)}")

    for path in rules:
        metadata, _ = parse_frontmatter(path)
        if not metadata.get("description"):
            raise RuntimeError(f"Rule lacks description: {relative(path)}")
        always_apply = metadata.get("alwaysApply")
        if path.name in REQUIRED_ALWAYS_RULES:
            if always_apply is not True:
                raise RuntimeError(
                    f"Mandatory rule must be alwaysApply: {relative(path)}"
                )
        elif always_apply is not False:
            raise RuntimeError(
                f"Scoped rule must set alwaysApply false: {relative(path)}"
            )
        if always_apply is False and not metadata.get("globs"):
            raise RuntimeError(f"Scoped rule lacks globs: {relative(path)}")


def validate_topic_metadata(topics: list[Path]) -> None:
    topic_ids = []
    for expected, path in enumerate(topics[1:], start=1):
        metadata, _ = parse_frontmatter(path)
        missing = TOPIC_METADATA_KEYS - metadata.keys()
        if missing:
            raise RuntimeError(
                f"Topic metadata missing {sorted(missing)}: {relative(path)}"
            )
        topic_id = str(metadata["topic_id"]).zfill(2)
        if topic_id != f"{expected:02d}":
            raise RuntimeError(
                f"Topic ID mismatch in {relative(path)}: {topic_id}"
            )
        topic_ids.append(topic_id)
        for key in (
            "authority_for",
            "not_authority_for",
            "evidence_grades",
            "routing_keywords",
            "mandatory_cross_checks",
            "source_families",
        ):
            if not isinstance(metadata[key], list) or not metadata[key]:
                raise RuntimeError(
                    f"Topic metadata {key} must be a non-empty list: "
                    f"{relative(path)}"
                )
        if not isinstance(metadata["restricted_sections"], list):
            raise RuntimeError(
                f"restricted_sections must be a list: {relative(path)}"
            )
    if len(set(topic_ids)) != 29:
        raise RuntimeError("Topic IDs are not unique")


def validate_source_counts(
    router_metadata: dict[str, Any],
    topics: list[Path],
) -> None:
    expected_markdown = manifest_int(
        router_metadata,
        "canonical_markdown_sources",
    )
    if len(topics) != expected_markdown:
        raise RuntimeError(
            f"Canonical source mismatch: expected={expected_markdown}, "
            f"actual={len(topics)}"
        )

    catalog = KB / "22-BQuant_DataItems.md"
    rows = re.findall(
        r"^\| ([^|]+\(\)) \|",
        read_text(catalog),
        flags=re.MULTILINE,
    )
    expected_items = manifest_int(router_metadata, "data_items_count")
    if len(rows) != expected_items or len(set(rows)) != expected_items:
        raise RuntimeError(
            f"Catalog invariant failed: rows={len(rows)}, unique={len(set(rows))}, "
            f"expected={expected_items}"
        )

    raw_count = sum(1 for _ in (KB / "Raw source").rglob("*.html"))
    expected_raw = manifest_int(router_metadata, "raw_html_sources")
    if raw_count != expected_raw:
        raise RuntimeError(
            f"Raw HTML mismatch: expected={expected_raw}, actual={raw_count}"
        )

    official_root = KB / "Official scripts"
    ledger = official_root / "00-OFFICIAL-SCRIPTS-INDEX.md"
    ledger_rows = re.findall(
        r"^\| (CREDIT|EQUITY|FX) \| ([^|]+) \| `([^`]+)` \|$",
        read_text(ledger),
        flags=re.MULTILINE,
    )
    expected_projects = manifest_int(router_metadata, "official_script_projects")
    if len(ledger_rows) != expected_projects:
        raise RuntimeError(
            f"Official-script mismatch: expected={expected_projects}, "
            f"actual={len(ledger_rows)}"
        )
    for domain, metadata_key in (
        ("EQUITY", "official_script_equity"),
        ("CREDIT", "official_script_credit"),
        ("FX", "official_script_fx"),
    ):
        actual = sum(row[0] == domain for row in ledger_rows)
        expected = manifest_int(router_metadata, metadata_key)
        if actual != expected:
            raise RuntimeError(
                f"Official {domain} mismatch: expected={expected}, actual={actual}"
            )
    missing_files = [
        path
        for _, _, path in ledger_rows
        if not (official_root / path).is_file()
    ]
    if missing_files:
        raise RuntimeError(
            f"Official-script ledger has missing files: {missing_files}"
        )

    ledger_text = read_text(KB / "16-home.md")
    for token in ("**158**", "**18**", "13 EQUITY", "4 CREDIT", "1 FX"):
        if token not in ledger_text:
            raise RuntimeError(f"Coverage ledger missing count token: {token}")


def validate_route_anchors() -> None:
    router = read_text(KB / "00-RAG-INDEX.md")
    required_router_sections = {
        "## 2. Destinations (the route table)",
        "### Destination path (always first)",
        "### Proven bundle path",
        "### High-risk path",
        "## 4. Risk classification",
        "## 5. Authority by claim type",
        "## 8. Intent atlas (not for named destinations)",
        "## 13. Anti-amnesia checklist",
    }
    for section in required_router_sections:
        if section not in router:
            raise RuntimeError(f"Router missing section: {section}")
    for filename, anchors in ROUTE_ANCHORS.items():
        text = read_text(KB / filename)
        if f"`{filename.split('-', 1)[0]}`" not in router and filename not in router:
            raise RuntimeError(f"Router does not target {filename}")
        for anchor in anchors:
            if anchor not in text:
                raise RuntimeError(
                    f"Missing routed heading in {filename}: {anchor}"
                )


def validate_router_regressions() -> None:
    router = read_text(KB / "00-RAG-INDEX.md")
    for query, expected_tokens in ROUTER_REGRESSION_CASES.items():
        missing = [
            token
            for token in sorted(expected_tokens)
            if token not in router
        ]
        if missing:
            raise RuntimeError(
                f"Router regression failed for {query!r}: missing {missing}"
            )


def validate_indexing_policy() -> None:
    text = read_text(INDEXING_IGNORE)
    active = {
        line.strip()
        for line in text.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }
    missing = EXPECTED_INDEX_EXCLUSIONS - active
    if missing:
        raise RuntimeError(
            f".cursorindexingignore missing exclusions: {sorted(missing)}"
        )
    forbidden = {"/User scripts/", "/RAG KB/"}
    present_forbidden = forbidden & active
    if present_forbidden:
        raise RuntimeError(
            f"Indexing policy hides working/canonical trees: "
            f"{sorted(present_forbidden)}"
        )
    blocked = FORBIDDEN_INDEX_EXCLUSIONS & active
    if blocked:
        raise RuntimeError(
            "Indexing policy hides frontend retrieval files: "
            + ", ".join(sorted(blocked))
        )


def validate_restricted_leakage(topics: list[Path]) -> None:
    for path in topics:
        if path.name in {
            "00-RAG-INDEX.md",
            "22-BQuant_DataItems.md",
        }:
            continue
        match = FORBIDDEN_CANONICAL_CALL.search(read_text(path))
        if match:
            raise RuntimeError(
                f"Restricted executable call in {relative(path)}: "
                f"{match.group(0)}"
            )

    project = WORKSPACE / "User scripts" / "ETF Capping Monitoring"
    production_paths = [
        *sorted((project / "etf_capping").glob("*.py")),
        project / "MAIN.ipynb",
    ]
    for path in production_paths:
        text = read_text(path)
        match = FORBIDDEN_PRODUCTION_CALL.search(text)
        if match:
            raise RuntimeError(
                f"Forbidden production call in {relative(path)}: "
                f"{match.group(0)}"
            )
        match = FORBIDDEN_CAST_UNIVERSE.search(text)
        if match:
            raise RuntimeError(
                f"Forbidden CAST production call in {relative(path)}"
            )
        data_calls = set(
            re.findall(r"\bbq\.data\.([A-Za-z_]\w*)", text)
        )
        universe_calls = set(
            re.findall(r"\bbq\.univ\.([A-Za-z_]\w*)", text)
        )
        unapproved_data = data_calls - APPROVED_ETF_DATA_CALLS
        unapproved_universe = universe_calls - APPROVED_ETF_UNIVERSE_CALLS
        if unapproved_data:
            raise RuntimeError(
                f"Unreviewed ETF BQL data calls in {relative(path)}: "
                f"{sorted(unapproved_data)}"
            )
        if unapproved_universe:
            raise RuntimeError(
                f"Unreviewed ETF BQL universe calls in {relative(path)}: "
                f"{sorted(unapproved_universe)}"
            )

    mdx_project = WORKSPACE / "User scripts" / "MDX Scan"
    mdx_paths = [
        *sorted((mdx_project / "mdx_scan").glob("*.py")),
        mdx_project / "MAIN.ipynb",
    ]
    for path in mdx_paths:
        if not path.is_file():
            continue
        text = read_text(path)
        match = FORBIDDEN_PRODUCTION_CALL.search(text)
        if match:
            raise RuntimeError(
                f"Forbidden production call in {relative(path)}: "
                f"{match.group(0)}"
            )
        data_calls = set(
            re.findall(r"\bbq\.data\.([A-Za-z_]\w*)", text)
        )
        universe_calls = set(
            re.findall(r"\bbq\.univ\.([A-Za-z_]\w*)", text)
        )
        unapproved_data = data_calls - APPROVED_MDX_DATA_CALLS
        unapproved_universe = universe_calls - APPROVED_MDX_UNIVERSE_CALLS
        if unapproved_data:
            raise RuntimeError(
                f"Unreviewed MDX BQL data calls in {relative(path)}: "
                f"{sorted(unapproved_data)}"
            )
        if unapproved_universe:
            raise RuntimeError(
                f"Unreviewed MDX BQL universe calls in {relative(path)}: "
                f"{sorted(unapproved_universe)}"
            )

    spread_root = WORKSPACE / "User scripts" / "ETF Spread Monitoring"
    if spread_root.is_dir():
        for path in sorted(spread_root.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in {".py", ".ipynb", ".md"}:
                continue
            text = read_text(path)
            data_calls = set(re.findall(r"\bbq\.data\.([A-Za-z_]\w*)", text))
            universe_calls = set(re.findall(r"\bbq\.univ\.([A-Za-z_]\w*)", text))
            unapproved_data = data_calls - APPROVED_SPREAD_DATA_CALLS
            unapproved_universe = universe_calls - APPROVED_SPREAD_UNIVERSE_CALLS
            if unapproved_data or unapproved_universe:
                raise RuntimeError(
                    "Unapproved ETF Spread BQL call in "
                    f"{relative(path)}: data={sorted(unapproved_data)} "
                    f"universe={sorted(unapproved_universe)}"
                )


def validate_required_recipe_anchors() -> None:
    required = {
        "01-bql-for-equities.md": "## Production Recipes from Official Scripts",
        "02-bql-for-fixed-income.md": "## Production Recipes from Official Scripts",
        "09-build-analysis.md": "## Production App Architecture from Official Scripts",
        "11-sample-notebooks.md": "## Production Recipes from Official Scripts (FX)",
        "18-using-pandas.md": "## Production Response Normalization from Official Scripts",
        "19-equity-scoring-model.md": "## PIT Quartile Long/Short Extension",
    }
    for filename, anchor in required.items():
        if anchor not in read_text(KB / filename):
            raise RuntimeError(f"Missing RAG anchor in {filename}: {anchor}")


RUNTIME_OWNER_FILE = "25-etf-capping-monitor.md"
RUNTIME_OWNER_PHRASE = "Last Close funds: request date = previous weekday"
STALE_SPLIT_PHRASES = (
    "Last Close is as-of the previous weekday",
    "walks back through an exchange holiday on that weekday",
)
POINTER_FILES = (
    "08-bql-data-items.md",
    "23-bql-substitution-due-diligence.md",
    "24-etf-field-migration-incident.md",
)


def validate_runtime_single_owner(topics: list[Path]) -> None:
    """Keep Last Close / zero-fallback in `25` only so retrieval cannot pick a stale copy."""
    owner = next((path for path in topics if path.name == RUNTIME_OWNER_FILE), None)
    if owner is None:
        raise RuntimeError(f"Missing runtime authority file: {RUNTIME_OWNER_FILE}")
    owner_text = read_text(owner)
    if RUNTIME_OWNER_PHRASE not in owner_text:
        raise RuntimeError(
            f"{RUNTIME_OWNER_FILE} missing owner phrase: {RUNTIME_OWNER_PHRASE}"
        )
    for path in topics:
        if path.name in {"00-RAG-INDEX.md", RUNTIME_OWNER_FILE}:
            continue
        text = read_text(path)
        if RUNTIME_OWNER_PHRASE in text:
            raise RuntimeError(
                f"Runtime recipe leaked into {path.name}; owner is {RUNTIME_OWNER_FILE}"
            )
        for stale in STALE_SPLIT_PHRASES:
            if stale in text:
                raise RuntimeError(
                    f"Stale Last Close recipe still in {path.name}: {stale!r}"
                )
    for filename in POINTER_FILES:
        text = read_text(KB / filename)
        if "`25`" not in text:
            raise RuntimeError(
                f"{filename} must point last-price runtime claims to `25`"
            )


MDX_OWNER_FILE = "26-mdx-scan.md"
MDX_OWNER_PHRASE = "official_trad_local_lang_sec_nm"
STALE_MDX_NAMECN = "{'NameCN': bq.data.name_chinese_traditional()}"
MDX_POINTER_FILES = (
    "08-bql-data-items.md",
    "09-build-analysis.md",
)


def validate_mdx_runtime_single_owner(topics: list[Path]) -> None:
    """Keep MDX NameCN / OHLCV / signal port in `26` so `09` cannot teach a substitute."""
    owner = next((path for path in topics if path.name == MDX_OWNER_FILE), None)
    if owner is None:
        raise RuntimeError(f"Missing runtime authority file: {MDX_OWNER_FILE}")
    owner_text = read_text(owner)
    if MDX_OWNER_PHRASE not in owner_text:
        raise RuntimeError(
            f"{MDX_OWNER_FILE} missing owner phrase: {MDX_OWNER_PHRASE}"
        )
    if "HISTORY_RANGE_START = '-6m'" not in owner_text:
        raise RuntimeError(f"{MDX_OWNER_FILE} missing OHLCV lookback freeze")
    for filename in MDX_POINTER_FILES:
        text = read_text(KB / filename)
        if STALE_MDX_NAMECN in text:
            raise RuntimeError(
                f"{filename} still teaches name_chinese_traditional() as NameCN"
            )
        if "`26`" not in text:
            raise RuntimeError(
                f"{filename} must point MDX NameCN / runtime claims to `26`"
            )


SPREAD_OWNER_FILE = "27-etf-spread-monitor.md"
SPREAD_OWNER_PHRASE = (
    "The operator selected the quote fields"
)


def validate_spread_runtime_single_owner(topics: list[Path]) -> None:
    """Keep the unapproved quote-field stop on route card 27 only."""
    owner = next((path for path in topics if path.name == SPREAD_OWNER_FILE), None)
    if owner is None:
        raise RuntimeError(f"Missing runtime authority file: {SPREAD_OWNER_FILE}")
    if SPREAD_OWNER_PHRASE not in read_text(owner):
        raise RuntimeError(
            f"{SPREAD_OWNER_FILE} missing owner phrase: {SPREAD_OWNER_PHRASE}"
        )
    for path in topics:
        if path.name == SPREAD_OWNER_FILE:
            continue
        if SPREAD_OWNER_PHRASE in read_text(path):
            raise RuntimeError(
                f"Spread quote freeze leaked into {path.name}; "
                f"owner is {SPREAD_OWNER_FILE}"
            )


def validate_sources(rules: list[Path], topics: list[Path]) -> None:
    router_metadata, _ = parse_frontmatter(topics[0])
    validate_balanced_fences([*rules, *topics])
    validate_rules(rules)
    validate_topic_metadata(topics)
    validate_source_counts(router_metadata, topics)
    validate_route_anchors()
    validate_router_regressions()
    validate_indexing_policy()
    validate_restricted_leakage(topics)
    validate_required_recipe_anchors()
    validate_runtime_single_owner(topics)
    validate_mdx_runtime_single_owner(topics)
    validate_spread_runtime_single_owner(topics)


def build_manifest(rules: list[Path], topics: list[Path]) -> dict[str, Any]:
    known_topics = topics
    router_metadata, _ = parse_frontmatter(topics[0])
    return {
        "schema_version": 1,
        "generated_by": "RAG KB/regenerate_kb_bundle.py",
        "corpus": {
            "mode": router_metadata["corpus_mode"],
            "official_cutoff": router_metadata["official_corpus_cutoff"],
            "local_user_evidence_through": router_metadata[
                "local_user_evidence_through"
            ],
            "canonical_topic_count": len(topics),
            "rule_count": len(rules),
        },
        "load_policies": {
            "default_semantic": [
                "RAG KB/00-RAG-INDEX.md",
                "RAG KB/BUNDLE_EXAMPLES.md",
                "RAG KB/01-08, 10, 12-21, 23-29 (not 09, not 11)",
                ".cursor/rules/*.mdc",
            ],
            "exact_search_only": [
                "RAG KB/22-BQuant_DataItems.md",
                "RAG KB/CONCEPT_INDEX.md",
            ],
            "path_open_atlas": [
                "RAG KB/09-build-analysis.md",
                "RAG KB/11-sample-notebooks.md",
            ],
            "explicit_audit_only": [
                "RAG KB/Raw source/",
                "RAG KB/Official scripts/",
                "RAG KB/Restricted reference/",
            ],
            "generated_offline_only": [
                relative(BUNDLE),
                relative(MANIFEST),
                "RAG KB/CONCEPT_INDEX.json",
                "RAG KB/BUNDLE_EXAMPLES.json",
            ],
            "quarantined": ["RAG KB/Technical_Analysis_Indicators.txt"],
        },
        "route_anchors": {
            filename: sorted(values)
            for filename, values in sorted(ROUTE_ANCHORS.items())
        },
        "router_regressions": {
            query: sorted(values)
            for query, values in sorted(ROUTER_REGRESSION_CASES.items())
        },
        "rules": [
            source_record(path, known_topics)
            for path in rules
        ],
        "topics": [
            source_record(path, known_topics)
            for path in topics
        ],
    }


def source_table(sources: list[Path]) -> str:
    rows = ["| Source | Lines | SHA256 |", "|---|---:|---|"]
    for path in sources:
        text = read_text(path)
        rows.append(
            f"| `{relative(path)}` | {line_count(text)} | "
            f"`{sha256(text)[:16]}` |"
        )
    return "\n".join(rows)


def render_bundle(rules: list[Path], topics: list[Path]) -> str:
    sources = [*rules, *topics]
    header = f"""# BQUANT_RAG_KNOWLEDGE_BASE

> Generated by `RAG KB/regenerate_kb_bundle.py`; never edit directly.
> Contains scoped rules and canonical `RAG KB/00`–`29`.
> Excluded from default indexing to prevent duplicate retrieval.
> Use only for explicit portable/offline single-file search.

## Source Integrity Summary

{source_table(sources)}
"""
    sections = [header]
    for path in sources:
        sections.append(
            f"\n\n{'=' * 72}\n"
            f"# SOURCE FILE: {relative(path)}\n"
            f"{'=' * 72}\n\n"
            f"{read_text(path).rstrip()}\n"
        )
    return "".join(sections)


def render_manifest(manifest: dict[str, Any]) -> str:
    return json.dumps(
        manifest,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n"


def check_output(path: Path, expected: str) -> None:
    if not path.is_file():
        raise RuntimeError(f"Generated output missing: {relative(path)}")
    actual = read_text(path)
    if actual != expected:
        raise RuntimeError(f"Generated output is stale: {relative(path)}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate sources and fail if generated outputs are stale.",
    )
    args = parser.parse_args()

    rules = rule_sources()
    topics = topic_sources()
    validate_sources(rules, topics)
    concept_md, concept_json = build_concept_index()
    validate_generated_markdown(concept_md)
    bundle_ex_md, bundle_ex_json = build_bundle_examples()
    validate_bundle_examples_markdown(bundle_ex_md)
    manifest_text = render_manifest(build_manifest(rules, topics))
    bundle_text = render_bundle(rules, topics)

    if args.check:
        check_output(MANIFEST, manifest_text)
        check_output(BUNDLE, bundle_text)
        check_output(CONCEPT_INDEX_MD, concept_md)
        check_output(CONCEPT_INDEX_JSON, concept_json)
        check_output(BUNDLE_EXAMPLES_MD, bundle_ex_md)
        check_output(BUNDLE_EXAMPLES_JSON, bundle_ex_json)
        print(
            f"integrity=ok topics={len(topics)} rules={len(rules)} "
            f"bundle_lines={line_count(bundle_text)} "
            f"concept_index={CONCEPT_INDEX_MD.name} "
            f"bundle_examples={BUNDLE_EXAMPLES_MD.name}"
        )
        return

    MANIFEST.write_text(manifest_text, encoding="utf-8")
    BUNDLE.write_text(bundle_text, encoding="utf-8")
    CONCEPT_INDEX_MD.write_text(concept_md, encoding="utf-8")
    CONCEPT_INDEX_JSON.write_text(concept_json, encoding="utf-8")
    BUNDLE_EXAMPLES_MD.write_text(bundle_ex_md, encoding="utf-8")
    BUNDLE_EXAMPLES_JSON.write_text(bundle_ex_json, encoding="utf-8")
    print(
        f"rebuilt={BUNDLE.name} manifest={MANIFEST.name} "
        f"concept_index={CONCEPT_INDEX_MD.name} "
        f"bundle_examples={BUNDLE_EXAMPLES_MD.name} "
        f"topics={len(topics)} rules={len(rules)} "
        f"bundle_lines={line_count(bundle_text)}"
    )


if __name__ == "__main__":
    main()
