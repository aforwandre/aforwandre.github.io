---
topic_id: "28"
title: FI Index Change Runtime Authority
role: project_runtime_authority
authority_for:
  - fi_index_change_runtime
  - fi_index_membership_diff
  - fi_index_projected_month
not_authority_for:
  - etf_capping_monitor_runtime
  - mdx_scan_runtime
  - general_api_signatures
  - entitlement
  - catalog_existence
evidence_grades:
  - practice-derived
  - canonical
  - catalog-only
risk_tier: high
routing_keywords:
  - LEGATRUU
  - MEMB
  - members dates
  - setdiff
  - weights
  - cache contract
  - MBS
  - TBA
  - FI Index Change
mandatory_cross_checks:
  - 00-RAG-INDEX
  - 02-bql-for-fixed-income
  - 18-using-pandas
  - project-fi-index-change
restricted_sections: []
source_families:
  - desktop_observation
  - help_center
---

# FI Index Change Runtime Authority

## Retrieval card (route card)

This is the highway to the Fixed Income Index change app. The destination
is Desktop output: month-end bond adds and exits for one fixed-income
index, a pre-effective projected month, and a Country / Sector / Tenor /
Rating / Currency dashboard. Follow this card. Do not wander `09` / `11` /
`22`.

Code lives under `User scripts/FI Index Change/`. The operator confirmed
on 2026-10-22: default index `LEGATRUU Index`, one selected month-end per
Update, Phase 1 analytics undated. A later instruction the same day
replaced the six-month history with that single month-end. On 2026-10-31
the operator changed the default Book to `All`.

`02` § Project Practice Notes is the membership-diff authority (the
Desktop V4.3 Global Aggregate tracker). This card freezes one comparison
around that recipe. It does not replace `02`.

There is no manual version stamp. Cache reuse is keyed to
`FIELD_CONTRACT` in `fi_index_change/cache.py`, derived from the frozen
item list in `field_library.py`. Editing that list invalidates old cache
entries automatically. Do not add a `REQUEST_STAMP` or `PARSER_VERSION`
back. An unregistered `PARSER_VERSION` would still fail the bundle check.

## Authority split

| Claim | Owner | Not owner |
|---|---|---|
| One-month membership diff, `setdiff` trap, weekend month-end, MBS/TBA mask, lowercase `weights` | `02` § Project Practice Notes | this file copies the rules for runtime use |
| Arrow response parse, `ID` lineage | `18` and the ETF `data.py` parse shape | do not invent a third concat |
| Which items this app requests, projected date, cache, dashboard | **this file** | `09` widget tutorials |
| ETF last price, AIM, classifier | `25` | this file |
| MDX NameCN / OHLCV | `26` | this file |
| `rating()` letter-versus-number shape | Unresolved until the first Desktop frame | do not invent a numeric scale |

## Membership request

One request per effective date. Universe is
`bq.univ.members(index_ticker, dates='YYYY-MM-DD')`. Never `member`.
Never `setdiff()`: it strips `id()['weights']`. Never `holdings()` and
never uppercase `WEIGHTS` for this universe.

Phase 1 items, undated, `with_params={'mode': 'cached'}`:

| Output name | Call |
|---|---|
| Name | `bq.data.name()` |
| Issuer | `bq.data.long_comp_name()` |
| Sector | `bq.data.classification_name()` |
| Country | `bq.data.country_full_name()` |
| Currency | `bq.data.crncy()` |
| Security Type | `bq.data.security_typ()` |
| Maturity | `bq.data.maturity()` |
| Tenor | `bq.data.mty_years_tdy()` |
| Rating | `bq.data.rating()` |
| Coupon | `bq.data.cpn()` |
| OAS | `bq.data.spread(spread_type='OAS')` |
| Z-Spread | `bq.data.spread(spread_type='Z')` |
| I-Spread | `bq.data.spread(spread_type='I')` |
| Duration | `bq.data.duration()` |
| Duration | `bq.data.duration()` |
| Modified Duration | `bq.data.duration(duration_type="MODIFIED")` |
| Effective Duration | `bq.data.duration(duration_type="EFFECTIVE")` |
| OASD | `bq.data.duration(duration_type="SPREAD")` |
| Yield | `bq.data.yield_()` |
| YTM | `bq.data.yield_(yield_type="YTM")` |
| YTW | `bq.data.yield_(yield_type="YTW")` |
| Weight | `bq.data.id()['weights']` |
| ISIN | `bq.data.id_isin()['value']` |
| SEDOL | `bq.data.id_sedol1()['value']` |

`MBSM` (`bq.data.mtge_modified_duration()`) was removed from this table on
2026-11-02 on operator-supplied Desktop evidence: both month-ends of
`LEGATRUU Index` returned
`ItemBuilderError: MBSM: AttributeError: No BQL data item named
'mtge_modified_duration'`. The item is listed as `Mod Duration` in the
`22` catalog, but catalog presence is not a BQL signature. Because the
failure is a required item, `data.py` returned an empty frame for the whole
month, which also produced the "unavailable" month lines and the
"Market Value incomplete" turnover note. No confirmed replacement exists in
this corpus, so it stays out rather than being guessed. Do not re-add it
without a dated Desktop confirmation of the BQL item name in the FLDS
BQL tab.

The duration block is four items from one builder, frozen on 2026-11-02 at
the operator's request: `Duration`, `Modified Duration`, `Effective Duration`
and `OASD`. Only `duration_type` distinguishes them, the same shape as
`spread(spread_type=...)` and `yield_(yield_type=...)`.

**Status: verified on Desktop, 2026-11-02.** The operator ran this build and
it completed. That confirms three things and no more:

1. `bq.data.duration(duration_type="MODIFIED")`, `("EFFECTIVE")` and
   `("SPREAD")` are accepted by BQL in this account inside a live `Request` —
   no `ItemBuilderError`, no rejected item.
2. The three-request split described below finishes inside the two-minute limit
   on `LEGATRUU Index`, where a single 22-item and a single 23-item request had
   each already timed out.
3. `OASD` as a request name does not collide with `OAS` in the app's filter
   logic, which compares whole column names.

It does **not** confirm the numeric semantics. The run completing tells you the
calls are real; it does not tell you that `'SPREAD'` shifts the OAS curve
rather than the benchmark curve, nor that `Duration` and `Modified Duration`
hold different numbers. Both remain open and are settled by comparing columns,
not by another request.

Provenance. The three `duration_type` value strings come from
operator-supplied FLDS BQL tab text dated 2026-11-02, which lists `'SPREAD'`
as "Spread Duration (OAS Duration)". A search of the whole corpus for
`duration_type` returns only this project's own text, so treat FLDS as the
authority and do not widen this block by guessing a fourth value.

Two things stay unverified:

- **Is `Duration` already Modified?** The supplied list calls plain
  `duration()` the "default duration" without naming the measure. If the
  default is Modified then `Modified Duration` is the same number under a
  second request name — an extra request slot for no new information. Compare
  the two columns bond-by-bond on one Desktop batch.
- **Is `'SPREAD'` the OAS-curve measure?** "Spread Duration (OAS Duration)"
  treats two related but different measures as synonyms. For a bond with no
  embedded option they agree; for an MBS/TBA or a callable they can diverge,
  because spread duration shifts the benchmark curve while OAS duration
  shifts the OAS curve. `LEGATRUU Index` holds both kinds, so this is a live
  distinction and not a theoretical one.

Two failure modes this block has actually produced, both of which looked like
a naming problem and were not:

- `OAD` (`option_adj_duration_sov_crv()`) and `ESPD`
  (`spread_duration_effective()`) were the catalog spellings tried first.
  Neither had a call site anywhere in the corpus, and both returned a column
  with every value null while `OAS`, `Z-Spread`, `I-Spread`, `Duration` and
  `Yield` returned real values in the same response. **An all-null column says
  the value did not arrive; it does not say the name is wrong.**
  `spread_duration_effective` was in fact a correctly-called documented item.
  Do not restore either without FLDS text for that specific spelling.
- Four items from one builder can fail silently by returning the same numbers
  under different names. `data._parse_response` now compares the four duration
  columns and appends a note naming the pair when two match on every row that
  carries both. Watch for that line: it means `duration_type` was ignored and
  the four columns are one measure.

`hb_oas_eff_durtn()` must not be read as the `OASD` column even though
`CONCEPT_INDEX` aliases `OASD` to it: `hb_*` is the fund-holdings family
(`hb_asset_class_focus`, `hb_market_cap_focus` sit beside it), so it is a
portfolio-level metric and an identity mismatch for single securities. The
catalog rows that read as "OAS spread duration" at security level are
`mid_oas_spread_dur_sov_contrib()` (`22:14232`) and
`mid_oas_spread_dur_swap_contrib()` (`22:14233`); neither has a signature in
this corpus and neither is requested.

`YTM` and `YTW` are not items. They are the parameter form of `yield_()`:
`bq.data.yield_(yield_type="YTM")` and `bq.data.yield_(yield_type="YTW")`,
taken verbatim from two official Desktop demo apps
(`Raw source/Bond Pair Relative Value`, `In [14]`; `Raw source/TOMS Relative
Value`, `In [20]`), which also use `yield_type="YTC"` for yield to call.
`What's New` documents the parameter. The previously frozen
`yield_to_maturity()` and `yield_to_worst()` were catalog spellings only, with
zero call sites in this corpus, and both returned an all-null column on
2026-11-02. Do not restore them. Note that the official demos never place
`yield_()` and `yield_(yield_type="YTM")` in the same item dict, so whether
`YTM` duplicates the plain `Yield` column is still unverified and needs one
Desktop run comparing the two columns.

The analytics block is ten items, chosen by the operator on 2026-11-02:
`OAS`, `Z-Spread`, `I-Spread`, `Duration`, `Modified Duration`, `Effective
Duration`, `OASD`, `Yield`, `YTM`, `YTW`. With the 13 identity columns the
field table is 23 items.

**Those 23 items are not sent as one request.** `config.SPLIT_REQUESTS` is
`True` as of 2026-11-02, so each date is fetched with three `bq.execute`
calls, one per `field_library.ANALYTICS_GROUPS` entry:

| Request | Items | Count |
|---|---|---|
| identity | Name, Issuer, Sector, Country, Currency, Security Type, Maturity, Tenor, Rating, Coupon, Weight, ISIN, SEDOL | 13 |
| analytics 1 | OAS, Z-Spread, I-Spread, Yield, YTM, YTW | 6 |
| analytics 2 | Duration, Modified Duration, Effective Duration, OASD | 4 |

The split is by measure family, not by count. Spreads and yields are
reference-curve lookups; every duration is evaluated by a model per bond, so a
timeout names the family it happened in. Durations are the last group on
purpose: if that request fails, the identity and spread/yield frames have
already returned, and the month still shows securities, weights, spreads and
yields with a note naming the missing measures instead of an empty table.

A group that fails outright **refuses the cache**. That is the difference
between a measure that legitimately came back blank and a request that never
returned: caching the second would make the next Update read the incomplete
month back and never retry the family that failed. A blank column inside a
frame that arrived is still cacheable, which is the rule the earlier
`required_columns()` change established.

The history that produced the split. The earlier build carried 22 analytics
(36 items) and `bq.execute` answered both month-ends of `LEGATRUU Index` with
`ResponseError: [BQLTimeoutError] - The query took too long to complete.
Error: #N/A Query Timed Out.`, including the automatic retry that dropped
`Market Value`. That retry removed one item out of 36 and could not shorten
the query. The two backup builds that did answer carried 16 or 17 items with
3 analytics. `DMAT` and `MACM` were the closed-form pair the timed-out build
carried, and they are no longer requested. The 22-item set completed for
`LEGATRUU Index` on 2026-10-30 while 2026-09-30 timed out in the same Update,
and the 23-item single request then timed out as well, which is what turned
`SPLIT_REQUESTS` on. The split build then **completed on 2026-11-02**, so the
working width in this project is the three-request shape, not one wide request.
So breadth is a load-bearing variable, not the sole one, and "it timed out" is
not by itself proof that an item is wrong. Do not re-widen this table, and do
not turn the split back off, without a dated Desktop timing that shows one
request of that width completes inside the two-minute limit.

State a claim about breadth with what was actually observed. The record for
this table is one date answering and an adjacent earlier date timing out in
the same run, which rules out a misspelt item (a bad name fails on every
date) and leaves the date itself as an open factor. The names are
established: the 36-item build reached `bq.execute`, which means BQL
accepted every item left after `MBSM` was removed.

Considered and rejected. This table is the record of what was ruled out, so
a later pass does not re-introduce one of these by accident. None of them is
requested by `field_library.py`; the mnemonics are kept only so the decision
can be re-read.

| Short | Call | Why it is not requested |
|---|---|---|
| ASW | `bq.data.spread(spread_type='ASW')` | Fourth spread; adds a swap-curve measure to every bond. Entitlement and sign convention unconfirmed. |
| DMAT | `bq.data.duration_maturity()` | Closed-form duration, replaced on 2026-11-02. `Duration`, `Modified Duration`, `Effective Duration` and `OASD` now come from the `duration()` builder. |
| MACM | `bq.data.mty_dur_mid()` | Macaulay duration at mid, replaced on 2026-11-02 by the same `duration()` block. Macaulay is not one of the four requested measures. |
| MACA | `bq.data.mty_dur_ask()` | Ask-side duplicate of `MACM`; the book is not priced at ask. |
| MODA | `bq.data.ask_modified_duration_domestic()` | Domestic ask-side variant of the same measure. |
| MODC | `bq.data.mid_modified_duration_contrib()` | Contribution to a portfolio measure, not a bond measure. |
| OASD | `bq.data.hb_oas_eff_durtn()` | Catalog spelling of "Holdings Based OAS Effective Duration"; a fund-holdings metric, not a security measure. The requested `OASD` column is `bq.data.duration(duration_type="SPREAD")`, a different item. Do not re-add this one as its replacement. |
| EFFD | `bq.data.mli_eff_dur()` | Third effective-duration series; same pruning rule as `OASD`. |
| MBSM | `bq.data.mtge_modified_duration()` | No such BQL item in this account; see the `MBSM` note above. |
| NYTW | `bq.data.net_yield_to_worst()` | After-tax net yield; the book is shown gross. |
| OASM | `bq.data.oas_mid_yield_to_maturity()` | Mid-side pairing of a yield already requested. |
| OASA | `bq.data.oas_ask_yield_to_maturity()` | Ask-side pairing of a yield already requested. |
| YID | `bq.data.yield_on_issue_date()` | Historical issue-date yield, not a current measure. |
| ATYA | `bq.data.yas_after_tax_yield_ask()` | After-tax ask yield; the book is shown gross. |

`crncy()` and `security_typ()` classify the bond book for this CREDIT
app (currency dimension and the MBS/TBA mask from `02`). They are not
an ETF holding classifier. After Update, the Currency box lists the
distinct `crncy()` values on the extracted snapshots for the selected
book. Before Update it is only `(All)`. Switching Book rebuilds that
list from the rows already extracted. It does not request another field.

`country_full_name()` arrives upper case from Bloomberg. The screen shows
it in Excel PROPER style (first letter of each word upper, the rest lower),
so `UNITED STATES` renders as `United States`. Rows in
`COUNTRY_NAME_OVERRIDES` in `fi_index_change/config.py` are replaced first
and then title-cased, so `BRITAIN` renders as `United Kingdom` and `SNAT`
renders as `Supranational`. The match ignores case and extra spaces; add a
row there to override another name. On an MBS/TBA row a blank Country or
Sector becomes `MBS/TBA` and a blank Currency becomes `USD`; the same
blanks stay `(blank)` on a Standard bond. A bond whose ID ends with
`MUNICIPAL_ID_SUFFIX` (`Muni`) is a US municipal bond: Country and Sector
become `Municipal` and Currency becomes `USD`. Both MBS/TBA and Municipal
rows show `NR` in Rating and classify as `NR`. Do not fall
back to `country_iso()`.

Do not call `credit_rating()`. Do not `replacena(0)` on coupon or
`replacena(9999)` on OAS before the weighted average. Missing stays
missing. OAS values at or above 9000 are excluded from the average only.

`SPLIT_REQUESTS` in `fi_index_change/config.py` stays `False`. If a Desktop month times
out, set it `True` and restart the kernel: identity items stay on the
first request (including Weight); all OAS/Z-Spread/I-Spread, duration, and
yield analytics move to a second request merged on `ID`. Do not drop the month.

That switch is the only approved way to narrow a request. It is a trade, not
a speed-up: it replaces one wide request with two narrower ones, so the total
wall-clock can go **up** even though each query is more likely to fit inside
the two-minute limit. With `QUERY_ATTEMPTS = 2` it is up to four `bq.execute`
calls per date. Turn it on for a month that times out; do not leave it on as a
default and do not split the analytics side again into a third request.

Execute month-ends one `bq.execute` at a time. A failed month is
unavailable. Do not diff against an empty side (that would mark the
whole book as added or exited). Do not cache an empty frame or a frame
whose Weight column is missing or entirely null.

**A timeout is never this app's Python (measured 2026-11-02).** One complete
local pass — parsing both month-ends, alignment, every render path and both
export tables on 5,000 rows — took 837 ms, under 1% of the 120-second budget.
The two-month parse alone is about 330 ms. `BQLTimeoutError` is raised inside
`bq.execute`, so it is evidence about the request or the date, never about
`prepare_members`, `summarize`, the merge, or the rendering. Do not go looking
for a Python hot spot when a month times out.

**Merge key is `ID` alone (2026-11-02).** An undated member response is a
snapshot; the date comes from the request as `AS_OF_DATE`. Never merge item
frames on `["ID", "DATE"]`: the analytics items return a `DATE` column and the
identity items do not, so once two analytics disagreed about their as-of the
outer join turned one row per bond into one row per (bond, item). Deduplicating
that frame then kept a single row per `ID`, and because `Weight` was merged
last the surviving row carried the weight and nothing else. The sheet showed
every bond as `(blank)` Country/Sector, `Missing` tenor, `NR` rating and
`(blank)` currency, while the ID-driven `MBS/TBA` and `Municipal` labels still
worked. Collapse each item frame to one row per `ID` *before* merging, keep the
last non-null value per column, merge on `ID`, and drop `DATE` from the item
frames. Say so in the log when the items reported different `DATE` values.

A column that arrives with every value null is not the same as an item that
did not parse. Log it separately, together with the columns the item did
return, so an all-null sheet is never silent.


`Market Value` was removed on 2026-11-02 and no item is optional any more.
It rode on the same single members request and its only consumer published
an index-MV ratio, but that publish was gated on a currency basis this
account has never confirmed, so the field was fetched on every Update and
then discarded. Turnover keeps the approximate definition it always showed
(ratio 1.0), so no displayed number changed.

A timeout is retried once, unchanged. That is `config.QUERY_ATTEMPTS = 2`
and `data._execute_attempts()`. The operator's evidence on 2026-11-02 is
that a repeat Update answers in seconds after a first attempt that ran close
to the limit, which means the first attempt warmed the Bloomberg-side cache
(`mode='cached'`) rather than that the request was wrong. The retry
therefore re-sends the same items to the same date and drops nothing;
nothing is optional, so there is nothing to drop. Only a timeout-bearing
failure is retried: `data.is_timeout()` looks for `BQLTimeoutError`,
`took too long`, `query timed out`, or `timeout`. A rejected item name, a
missing entitlement, or a bad ticker is deterministic and fails on the first
attempt with no retry. The separate, earlier retry that this does NOT
reinstate dropped `Market Value` on any failure: it removed 1 item out of
36, could not shorten a request that was too wide, and paid a second
two-minute timeout for nothing. Worst case per Update is
`QUERY_ATTEMPTS x 2 dates x the Desktop limit`, and the log reports each
attempt's elapsed seconds so a near-limit success is visible instead of
silent.


Diff on string `ID` after `reset_index`. A security id that arrives as
an unnamed index is named `ID` before that reset. A default row-number
index is left alone. Duplicate IDs: keep last and log the count. Blank
IDs are dropped. An empty parse logs returned column names.

If the absolute weight sum is at most 1.05, multiply by 100 so the
dashboard speaks in index percent points. Otherwise keep the returned
weight. A sum between 1.05 and 2.5 is not a unit that can be inferred, so it
is left unscaled rather than multiplied on a guess. This is the same members-weight scale check as MDX, applied
because both reads are `id()['weights']`.

## Projected month

Bloomberg publishes adds and exits before the effective date. `02`
records that `members(..., dates=)` follows the rebalance boundary:
a calendar month-end that falls on a weekend can pull the next set.
This app uses that boundary on purpose.

Weekend rule, from `02`: `pd.bdate_range(end=calendar_month_end, periods=1)`
rolls Saturday and Sunday back to the last weekday. It does not contain
an exchange-holiday calendar. Do not invent one.

Let `today` be the machine's normalized calendar date (not a UK display
clock). Let `this_effective` be the last weekday of today's calendar
month.

- If `today` is before `this_effective`, the projected date is
  `this_effective`. The dropdown default is that date.
- If `today` is on or after `this_effective`, that month has locked.
  The projected date is the last weekday of the next calendar month.
  The dropdown default stays `this_effective`. The next month is labeled
  Projected in the dropdown.

The dropdown lists `MONTH_END_CHOICES` dates (18). Choosing a date does
not request data. Update requests exactly two snapshots: the selected
effective date and the previous month-end weekday. It does not request
the other dropdown dates.

A projected selection is not written to the historical cache. A completed
month-end is reused from cache when the manifest carries the current
`FIELD_CONTRACT`.

The projected `members(dates=future effective date)` call is the same
function as the historical call. The first Desktop run must confirm
that a date still ahead of today returns the announced set when MEMB
has published it. Until that observation exists, the app fails closed:
a request error or an empty frame is "projected unavailable", not
"no changes". Two successful frames with the same IDs are a real empty
change list ("no projected adds or exits"). Turnover uses the
approximate definition with no index-MV input (see Monthly turnover). Do not
add a separate index-level analytics request, and do not cache a projected
month.

## Pandas rules

MBS/TBA mask from `02`, always computed, never used as a silent drop:

```text
Security Type contains MBS, TBA, or Pool (na=False)
or ID contains Mtge (na=False)
```

The detail panel sits under the bucket summary and lists the adds and
exits in the clicked bucket. There is no separate adds-and-exits grid.
The Book selection box defaults to All, so one screen carries the Standard
bonds and the MBS/TBA rows together. Picking Standard still keeps
roll-month TBA codes out of the list; picking MBS/TBA shows only
that book. One pick wins; two picks, or no pick, fall back to
`DEFAULT_BOOK` (All). The switch never sends a new request.

Add and Exit are ID set differences inside the selected book. A bond
that stays in the index and only changes Country or Sector is not an
add or an exit. Begin and End counts are the full selected book in
that bucket, so a reclassification shows up there.

Both charts follow the Bloomberg dark theme: transparent paper and plot
backgrounds, light text and grid, unchanged bar colours. The chart width is
capped at 80% of a full-screen 1,920 px view: `CHART_WIDTH_PX` is
`min(FILTER_ROW_WIDTH_PX, int(SCREEN_WIDTH_PX * CHART_MAX_SCREEN_RATIO))`,
which is 1,536 px today. `FILTER_ROW_WIDTH_PX` is still the nine selection
boxes (300+300+220+220+220+220+260+260+220 plus eight 8 px gaps = 2,284 px),
so the charts deliberately stop short of the Book box instead of running to
the right edge of the filter row. The operator asked for this on 2026-11-01.
`FILTER_WIDTHS`, `FILTER_GAP_PX`, `FILTER_ROW_WIDTH_PX`, `SCREEN_WIDTH_PX`,
`CHART_MAX_SCREEN_RATIO`, and `CHART_WIDTH_PX` live in `config.py`.
Each chart is wrapped in a same-width HBox AND its Plotly layout sets
`width=CHART_WIDTH_PX` with `autosize=False`; the HBox alone does not size
a FigureWidget on Desktop. The tables keep their own width. The local
preview receives the same widths in its payload. A viewport narrower than
1,920 px scrolls the charts sideways instead of shrinking them: a fixed
pixel width is required for `FigureWidget`, so this is accepted, not a bug.

Both Main tab tables keep one column visible while the body scrolls sideways
(`PIN_FIRST_COLUMN`, operator request 2026-11-01). ipydatagrid 1.4.0 has no
frozen-column trait, so `_pinned_view()` moves that column into the index and
`base_row_header_size` widens the non-scrolling row-header gutter. The summary
table pins its dimension column (the group key). The detail bond table pins
`ID` (`PIN_DETAIL_COLUMN`), not `Action`: `Add` / `Exit` repeats and says
nothing about which bond is under the cursor, while `ID` is unique and is the
key the diff itself uses. `PIN_DETAIL_ROW_HEADER_MAX_PX` is 300, so a long
yellow key is not cut at the summary's 220 px cap. The gutter is gated on
`hasattr(DataGrid, "base_row_header_size")`; when the trait is missing the
table keeps every column in the scrolling body, because traitlets swallows an
unknown keyword silently and the label would be cut at 64 px instead. The row
header stays shown via `header_visibility="all"`; 1.4.0 has no `row_headers`
trait. A row-header click opens the row like a body click: the frontend's
`primary_key_row` is the dataset row, mapped back through `ipydguuid`, so a
string or repeated index label is not used as a row key. The HTML fallback and
the preview use `position: sticky; left: 0` on the pinned cell, on a white
table block, because the Desktop shell is dark.

Both charts are horizontal and signed. Add weight is positive to the
right of the zero axis; Exit weight is negative to the left. The bucket
chart uses the same Add Weight plus Exit Weight order as the Bucket
summary table, skips only buckets whose Add Weight and Exit Weight are both
zero (an offsetting Add/Exit pair stays in), draws the top 20 of the remaining
buckets, then one aggregated `Others` row (at most 21 lines;
`BUCKET_CHART_TOP` in `config.py`). The detail
chart runs top to bottom from the largest Add to the largest Exit by
signed weight. The detail table repeats that signed order and shows an
Exit weight as a negative number. Export still writes positive weights.
The bucket table keeps its Add Weight plus Exit Weight order. Each measure
keeps its Begin and End columns together and adds one `+/- <measure>`
column (End minus Begin) for Count, Weight, every selected spread, every
selected duration, every selected yield, and Tenor; the Add and Exit
count/weight block stays at the end. The summary always calculates the
Begin / End / +/- blocks for all three spreads and all three duration and
three yield fields; the screen shows the selected blocks, while Export
Summary carries all of them. Every net is a difference of weighted
averages (undefined when either side has no valid value).

Duration and Yield short labels in tables (selection box names in brackets):
`Duration` (Duration), `Modified Duration` (Modified duration), `Effective
Duration` (Effective duration), `OASD` (Option adjusted spread duration);
`Yield` (Yield), `YTM` (Yield to maturity), `YTW` (Yield to worst). The four
duration measures all come from the `duration()` builder; see the
request-width note above for their provenance.

Tenor buckets from numeric `mty_years_tdy`: 0–1Y, 1–3Y, 3–5Y, 5–7Y,
7–10Y, 10–20Y, 20Y+, Missing. An MBS/TBA row with no numeric tenor uses
`N.A.` (`TENOR_NOT_APPLICABLE` in `config.py`), not `Missing` or a blank
filter value; a real numeric tenor keeps its normal bucket.

Rating classification from the raw `rating()` text: exactly three values,
IG, HY, and NR. IG is investment grade (BBB- / Baa3 and above). HY is
high yield (BB+ / Ba1 and below). NR is everything else: no usable letter
grade, which covers a blank, a stated NR or WR, `N.A.` on an MBS/TBA or
Municipal row, and a vendor numeric scale. Do not map 24 or any other
number onto a letter until a Desktop frame shows the scale; the number
stays visible in the Rating column and is classified NR. The footnote
under the controls states these definitions on screen.

Classification labels are standardized by ID across both loaded
snapshots. `align_snapshot_labels()` in `engine.py` applies one value per
ID to Book, Country, Sector, Tenor Bucket, Rating, Rating Bucket, and
Currency: if the latest snapshot has a usable value it wins even when the
value changed; if the latest value is missing, the previous snapshot's
value fills both sides. IDs that exist on only one date keep that date's
values. Weights and analytics are never copied. So a bond cannot be IG on
one side and NR on the other, and the Rating filter has one category per
bond. `rating_class_conflicts()` is the check that proves it; it must
return no IDs, and the payload log reports any it finds.

Weighted averages skip nulls, non-finite values, and OAS >= 9000.
Weights that are null or not positive are skipped. Zero coupon stays in
the coupon average.

Dimension filters apply after the ID diff, to display only. Every filter
starts on `(All)`, which is a rest label rather than a data value; picking
one or more real values narrows that column. Export ignores the filters.
The Add / Exit detail list applies every active filter, not only the
current dimension's key. The list, its counts, weights, and chart all use
`_filtered_changes()`.

## Filter cascade bug (2026-10-31)

Symptom: a newly added bond showed `Rating = AAA`, `Rating Bucket = IG` in
the Bond detail table, yet it appeared in the Add / Exit list under both
the `IG` and the `NR` Rating selections. The bond was
present on only one month-end (an Add or Exit), so the cross-snapshot label
alignment did not apply to it.

Root cause: `_bucket_changes()` in `app.py` filtered the change rows only
by the current Bucket-summary dimension key and ignored the other filter
widgets. `summarize()` was correct; the detail list was not. Example:
Rating filter = `NR`, dimension = Country, click a Country row; the
detail list returned every change in that Country, including IG bonds.
Choosing `IG` also showed the same bond, so it looked like the bond sat in
two Rating buckets. One-sided Add / Exit rows made the leak easy to see.

Fix: `_filtered_changes()` applies
`apply_dimension_filters(change_export_frame(...), self._current_filters())`
before `_bucket_changes()` applies the dimension key. The detail list,
counts, weights, and bond chart all use that single filtered set. The
preview mirrors it with `matchesFilters()` and must ignore the `(All)`
marker when deciding whether a filter is active.

Guard: `test_detail_list_applies_every_active_filter` in
`tests/test_app_contract.py`, plus the preview checks
`detail list inherits the Rating filter` and
`NR rating filter has rows`. If the same ID appears under two Rating
selections again, check this filter cascade first; do not change
`align_snapshot_labels()` or the rating definitions.

Second guard, added 2026-11-02: `rating_class_conflicts()` in `engine.py`
compares the two month-ends and must return no IDs. `fetch_index_payload()`
adds a note when it does. It is a check, not the fix; the fix above is the
filter cascade.

## Index box

There is no local suggestion list. Paste an Index yellow key. A partial
ticker does not call BQL, and Update remains the only membership request.

When the text is one completed yellow key ending in ` Index`, the box
requests `long_comp_name()` for that one ID and shows the returned string
under the input. The operator confirmed on 2026-10-30 that, on an Index
yellow key, this item is the index title. It does not search the security
database. `22` still describes the same item as the issuer when it is
requested on a bond; the Issuer column keeps that use. A blank or failed
name stays visible. It is not replaced with a guessed title.

If `members()` comes back with an entitlement, permission, or license
error, the screen says `No Data Access License under this BBG ID` and
does not present an empty add/exit list as a real diff. A `403` stays a
disconnected session (`05`). An empty snapshot stays unavailable, not
this license message.

The top controls are Dimension and Bonds. The filter row is Country,
Sector, Tenor, Rating, Currency, Spread, Duration, Yield, then Book. All five
selection boxes are multi-select and use the same rows=10 height as the
other filters.

- Spread: `(All)`, `OAS`, `Z-Spread`, `I-Spread` (default `OAS`).
- Duration: `(All)`, then `Duration`, `Modified Duration`, `Effective
  Duration`, `OASD` (default `Duration`).
- Yield: `(All)`, then `Yield`, `YTM`, `YTW` (default `Yield`).
- Book: `(All)`, `Standard`, `MBS/TBA`.

`(All)` expands every item in that box. A picked subset expands just those
blocks in the headline, Bucket summary, bond detail list, and bond field
table. Selecting one book uses it, while both books or `(All)` means `All`.
The selection boxes use descriptive labels; table, Export Summary, Changes,
and Full Position headers use the short keys shown above. Export Changes,
Export Summary, and Full Position retain every spread, duration, and yield
column. No selection sends a new BQL request.

The selection line under the controls states the comparison on screen and
is a coloured box (green when the loaded pair matches, amber when an edit
is pending). The headline below it (As of previous / As of selected / Add / Exit / full-book
counts) is bold inside the same green box; an unavailable comparison uses
amber and a refused license uses red. The line under its date/book label:
`2026-09-30 → 2026-10-30 (All). The figures, Bucket summary, and charts below
follow this scope; Full book lines are all books.` The next line is
`Scope: Book = ...; filters = ...` and updates with Book and the filter
widgets. The two Full book sentences start on their own line after the
turnover sentence.
Editing the index text or the month-end marks that edit pending without
sending a request. Book, dimension, and the `(All)` filters still redraw
the loaded rows.

The footnotes under the controls are generated by `caption_html()` in
`engine.py` and hold three things: the as-of dates (Add/End = selected
month-end, Exit/Begin = previous month-end), the IG / HY bucket definitions,
and the turnover formula. The turnover line states
`Exit weight (previous month-end) + Add weight (selected month-end) x
(ending index MV / beginning index MV)`, plus `Turnover Rate` and the
`(approx)` fallback label. A failed Update falls back to the generic wording
without dates. Keep them short. Do not put update scope, chart order, the
Begin/End definition, Country, license, `403`, or empty-book text in the
footnotes: chart order sits on the chart axis, Begin/End sits under the
Bucket summary heading, and request or license errors belong in the live
status line.

The status lines never disable a table. `render()` calls the idempotent
`_bind_events()` before rebuilding the panels, so an Environment status
refresh cannot leave the bucket or bond rows without click handlers.

## Detail panel and export

A click reads the row already loaded. It does not send another BQL
request. The detail summary reads e.g. `12 adds and 8 exits. Add weight
1.36%, Exit weight 1.10%, Net weight 0.26%.` The bond table keeps every
row of the bucket. The signed chart above it shows at most the Top 10
Adds and the Top 10 Exits, so a 30,000-bond index stays readable; its
height grows with the row count (up to 20 rows) and every bar keeps its
label. Bar labels are the bond name only: do not prefix `Add` or `Exit`;
the bar colour and chart title carry the action. Clicking one of those
bonds puts its field table BELOW the bond table, so the grid does not move;
the short note above the table states which bond is selected.

The grids receive only the columns in their own table definition, and any
date column is converted to a plain `YYYY-MM-DD` string before it reaches
`ipydatagrid`. Hidden helper columns such as `Maturity` and `AS_OF_DATE`
must never be passed to the widget: a NaT maturity (common on MBS/TBA)
makes `Date.toISOString()` raise `RangeError: Invalid time value` and the
whole grid fails to instantiate. The bond detail field table formats
`Maturity` and `AS_OF_DATE` the same way.

The app has three tabs: Main, Export, and Full Position. There is no Export
CSV button and no file is written; a packaged BQuant App user cannot reach
the Desktop filesystem. The Export tab starts with a `Data` dropdown
(Changes / Summary). Changes is every add and exit in the selected book,
with Weight in percent points, independent of the Bonds dropdown and
dimension filters; Summary is the current Bucket summary. The Full
Position tab starts with a `Date` dropdown (Start date / End date): Start
is the previous month-end, End is the selected month-end, and the table
lists every constituent of the whole index, Standard and MBS/TBA
together, independent of the Book selection and filters. Its columns are
the CSV export data columns minus the changes-only `Action`; `AS_OF_DATE`
identifies the month-end.

Hard rule: every copy table repeats the column names as its FIRST DATA
ROW, because a widget DataGrid copy does not carry the header. All three
tables (Changes, Summary, Full Position start/end) do it through
`export_display_frame()` in `engine.py`; do not remove that row. Add
weight and End weight are the index weight on the selected month-end;
Exit weight and Begin weight are the previous month-end, so the two
weights are not the same as-of date.

`PERCENT_COLUMNS = ("Weight",)` appends `%` to the single `Weight` column of
Changes and Full Position, because the operator asked for that column on
2026-11-01. The summary columns named `Begin Weight`, `End Weight`,
`+/- Weight`, `Add Weight`, and `Exit Weight` stay plain percent points; the
request did not cover them and their header already says Weight. Do not widen
the suffix without a new request.

## Monthly turnover

Monthly turnover follows the Bloomberg definition:

```text
TURNOVER = (MVBeginningDrops + MVEndingAdditions) / MVBeginningIndex
```

Provenance: this formula arrived on 2026-10-31 from an external Bloomberg
fixed-income index methodology document fetched with a web tool. It is
**not** in the local corpus and no dated user-supplied copy is on file.
Keep it labelled as an external definition: do not treat it as a RAG KB
verified item, and re-confirm it from a user-supplied dated document
before any number is quoted outside the app. The guarded implementation
below stays as written; the ratio is always 1.0 today, so every number this
formula prints is `(approx)`.

In weight terms (weights are percent points of their own date's index):

```text
Turnover (index %) = ExitWeight_T0 + AddWeight_T2 x (MV_T2 / MV_T0)
```

`ExitWeight_T0` is the previous month-end weight and `AddWeight_T2` is the
selected month-end weight. The ratio `MV_T2 / MV_T0` is the only extra input;
the app does not need per-bond Par, Price, or Accrued fields.

### Data source and fallback

There is no index-MV data source. `bq.data.market_value()` was removed from
the request on 2026-11-02, so `Turnover (index %)` is computed with the ratio
fixed at 1.0 and always carries `(approx)`. `engine.summarize` still accepts an
`index_mv_ratio`, so a restored source would need no formula change, but
nothing in `data.py` sets one.

Why it was removed despite being a single field: per-bond values are only
additive across a multi-currency index when every member reports the same
currency, that basis was never confirmed for this account, and the publish was
therefore blocked on every run. The field cost one item on a request that
already runs against the two-minute timeout, and its removal changes no
displayed number. Re-adding it means restoring the builder, the optional
retry, and a dated Desktop confirmation of the currency basis for one
multi-currency index month-end.

### Screen fields

- Headline: `Monthly turnover X%`; `(approx)` always, because no index-MV
  ratio is requested;
  `(filtered)` when a filter is active. `(book)` is added when the Book is not
  All, because the headline follows the selected book.
- Bucket summary: `Turnover (index %)` is that bucket's contribution to the
  beginning-index turnover, so the rows sum to the filtered index turnover.
- Bucket summary: `Turnover Rate (%)` is
  `Turnover (index %) / Begin Weight x 100`; it is blank when the bucket has
  no beginning weight.
- Export Summary carries both columns automatically.
- The two definitions also sit inside the Bucket Summary panel, directly
  under `<b>Begin</b> = previous month-end, <b>End</b> = selected month-end.
  Add/Exit are ID membership changes.`: `Turnover (index %)` = Exit Weight (prior
  month-end) + Add Weight (selected month-end) x ending/beginning index MV,
  and `Turnover Rate (%)` = Turnover (index %) / Begin Weight x 100 (blank
  when Begin Weight is 0).

The official Bloomberg turnover is index-level. The bucket columns are an
attribution of that number, not a separately published official bucket
turnover. For official turnover, Exit uses T0 (beginning drops), not a
pre-rebalance T1 weight. T1 remains useful only for the separate
rebalance-boundary analysis.

## Cache

CSV under `User scripts/FI Index Change/cache/`, plus `manifest.json`.
Parquet is not used: pyarrow is not a confirmed Desktop package and
`pip` is forbidden. Historical files are reused when the manifest entry
carries the current `FIELD_CONTRACT` and Weight is present. The contract
is derived from `field_library.ITEM_NAMES`, so adding or removing an item
invalidates old cache entries automatically. There is no stamp to bump by
hand. The projected month is requested on every Update and is not written
to the historical cache.

## MAIN lifecycle

`MAIN.ipynb` displays the UI and waits for Update. Do not copy the MDX
`load_on_start` refresh. `render()` starts with the fixed `TITLE_HTML`
header from `app.py` (20px bold). Neither the title nor the status line
carries a version stamp. After replacing `.py` files on Desktop,
Restart Kernel, then Run All, then Update.

Desktop runs Python 3.11. An f-string expression must not contain a
backslash there (PEP 701 only lands in 3.12). Compute the value first and
interpolate the variable. `tests/test_compat.py` scans the uploaded files
for this and fails the suite if one comes back.

## Fail closed

- Yellow key must end with ` Index`. Otherwise do not request.
- Missing Weight, empty snapshot, or request exception: that comparison
  is unavailable. Do not diff the surviving side against an empty side.
- Do not fill a failed weight with zero.
- Do not widen the universe when a field is missing.
- No ESG, GHG, climate, or sustainable-finance item.
- Do not execute BQL on the authoring Mac.

## Minimum shippable package

1. `fi_index_change/config.py` — index, default book, month-end dropdown length, split switch (off).
2. `fi_index_change/field_library.py` — the item table above.
3. `fi_index_change/data.py` — sequential members requests, Arrow-safe
   parse, CSV cache.
4. `fi_index_change/engine.py` — dates, ID diff, buckets, weighted
   averages.
5. `fi_index_change/app.py` — Update, one month-end dropdown, detail under the bucket summary, grids.
6. `MAIN.ipynb` — Update only.

## Unresolved until Desktop

> Historically this section held the decisions taken against the in-BQuant
> assistant's 2026-10-23 reply. The duration rows in it are now settled by real
> Desktop evidence (2026-11-02); the assistant's advice was right about the
> parameter form and wrong about nothing that this card relies on, but it was
> still not evidence when it was written.

The in-BQuant assistant is not an authority. Its replies are often
wrong. When a reply conflicts with this card or with `02`, keep the
RAG KB. The 2026-10-23 reply was not an executed Desktop frame.
Decisions:

| Topic | Decision | Reason |
|---|---|---|
| Future `members(dates=)` | Keep. Empty projected diff stays an empty change list | Assistant said a future date returns the announced set after publication, and the locked set before publication. No executed rows were returned |
| Effective date | Reject calendar month-end on a weekend | `02` says a weekend calendar month-end can pull the next projected set. This app keeps the last weekday. May 2026 is `2026-05-29`. October 2026 is `2026-10-30` |
| Weight item | Keep `id()['weights']` | `bq.data.weights()` is a different item. Equity replication reads `weights()['VALUE']`. The assistant also omitted an executed sum |
| Diff key | Keep yellow-key `ID`, and keep the MBS/TBA book split | The assistant's ISIN/CUSIP sample omitted `['value']`. `id_cusip()['value']` is the documented accessor. TBA isolation is the `02` control |
| `rating()` | Keep bare `rating()` in Phase 1 | Official samples use `rating_source='sp'` and `rating_source='moody'` with `['BASE_RATING']`. The assistant used uppercase `SP` / `MOODY` / `FITCH` on `bondsuniv`, not on index members |
| OAS, Z-Spread, I-Spread, duration, yield, tenor | Stay undated in Phase 1 | The assistant says an undated item is as of today. Dated `fill='prev'` on each item remains Phase 3 |
| Sector | Keep `classification_name()` | `market_sector_des()` is an equity-universe filter in `19`. The same reply later used BICS |
| Country | Keep `country_full_name()`. Display overrides live in `COUNTRY_NAME_OVERRIDES` | The operator replaced the ISO display. `BRITAIN` shows as `UNITED KINGDOM`. Do not fall back to `country_iso()` |
| `member_count` | Do not add a second request | `02` uses lowercase `universe_type='projected'` and `'returns'`. The assistant uppercased both |
| Request width | One cached Request per date was the default until 2026-11-02. `SPLIT_REQUESTS = True` is now the shipped default, splitting into identity + spread/yield + duration | A single 23-item request returned `#N/A Query Timed out` on 2026-11-02 and the split build then completed, so the wide single request is no longer the default. The assistant's `LBUSTRUU` field list is still not this app's item table, so its width advice remains non-evidence |

Still unresolved on a real Desktop frame:

- Projected `members(dates=upcoming effective weekday)` returns the announced set after MEMB publication.
- `rating()` values are letters, numbers, or mixed.
- ~~Whether the split three-request fetch of 23 items on `LEGATRUU Index`
  finishes inside the Desktop timeout~~ — **answered 2026-11-02: it does.**
  The operator ran the split build (13 identity, 6 spreads+yields, 4
  durations) and it completed, after a single 23-item request had returned
  `#N/A Query Timed out` the same day and a single 36-item request had timed
  out on both month-ends. What is still open is not finishing but *content*:
  whether all four duration columns carried values, and whether they carried
  distinct values. The app prints a note when two duration columns match on
  every row, so one run's log settles it. Every request remains bounded by
  the same two-minute limit, so a later failure reports which group it
  happened in; report that group name and the elapsed time rather than
  changing several names at once.
- `bq.data.market_value()` is no longer requested, so nothing about the
  per-bond MV currency basis is being tested. The open question is retired
  rather than answered: turnover uses the approximate definition with a
  ratio of 1.0.
- If the official turnover basis is ever wanted back: restore the per-bond
  `bq.data.market_value()` item, compare its sum with one index-level
  `bq.data.market_value(universe_type='projected')` value for the same date,
  and only then publish the ratio. A mismatch means the sum is in local
  currency and is not an index market value.
- Dated OAS / Z-Spread / I-Spread / every duration and yield field /
  rating at the effective date, with `fill='prev'`, is Phase 3.
- `duration()` and `yield_()` are confirmed. Official Desktop pages and
  official scripts call both (`Raw source/BQL for Fixed Income Company
  Analysis`, `Official scripts/CREDIT/Bond Curves Comparison with
  History.md`). The confirmed yields are `yield_()` and
  `yield_(yield_type="YTM"|"YTW"|"YTC")`, taken from `Raw source/Bond Pair
  Relative Value` (`In [14]`) and `Raw source/TOMS Relative Value`
  (`In [20]`). `yield_type` is a parameter on `yield_()`, not a separate item;
  `What's New` documents the parameter.
- `option_adj_duration_sov_crv()` and `spread_duration_effective()` had exact
  catalog spelling in `22` (`17010`, `20230`) and nothing else: no tutorial,
  no official script, no official Desktop page calls either one. Both were
  **retired on 2026-11-02** after returning an all-null column on this index,
  which is a data result rather than a naming fault. Catalog presence is
  spelling evidence only; it never establishes that a value will arrive.
- The duration measures are reached through one builder instead:
  `duration()`, `duration(duration_type="MODIFIED")`, `("EFFECTIVE")` and
  `("SPREAD")`. See the duration section above for the verified status, the
  FLDS provenance, and the two semantics questions that remain open.
