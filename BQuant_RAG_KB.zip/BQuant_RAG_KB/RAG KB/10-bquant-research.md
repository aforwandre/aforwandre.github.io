---
topic_id: "10"
title: BQuant Research Coverage
role: research_index
authority_for: [captured_research_topics, non_executable_boundaries]
not_authority_for: [api_signatures, production_recipes]
evidence_grades: [canonical, gap-uncaptured]
risk_tier: normal
routing_keywords: [research, whitepaper, Assistant, frequencygram]
mandatory_cross_checks: [00-RAG-INDEX, 16-home]
restricted_sections: []
source_families: [help_center]
---

# BQuant Research

> Thin index of Bloomberg-curated research themes relevant to CURSOR_BQNT.
> Notebooks are authored locally, executed on the work Bloomberg machine.

---

## Research Theme Index

| Theme | Example topics | Related project files |
|-------|------------------|----------------------|
| Equity factor / reversal | Short-term reversal, min-variance factor L/S | `01-bql-for-equities.md`, `19-equity-scoring-model.md` |
| Earnings / alt data | Earnings surprise momentum, KPI forecasting | `20-earnings-surprise.md`, `08-bql-data-items.md` (Second Measure) |
| Volatility / derivatives | VIX term-structure strategies | `11-sample-notebooks.md` |
| Portfolio optimization | Multi-period / transaction-cost concepts | Out of locked stack unless user explicitly requests an approved dependency |
| Municipal bonds | Primary market performance vs benchmarks | `02-bql-for-fixed-income.md`, `12-bql-fixed-income-screening.md` |
| Volatility structure | Frequencygram / variance-ratio strategies | `11-sample-notebooks.md` |

Bloomberg publishes full notebooks on the BQuant Research page inside Help Center. Treat them as reference implementations — adapt patterns into this project's PyBQL object syntax.

> Execution boundary: snippets that reference `PortfolioAnalytics`, `charting`, or `src.*` depend on supporting files not present in this corpus. They are non-executable research evidence; never generate those imports unless the user supplies the files.

The 2026-07-25 What's New snapshot indexes **Frequencygram and Variance Ratio Trading Strategy** and **Multi-Quarter Sales Revenue Forecasting**. Their linked notebook bodies are not captured, so these are discovery titles rather than ingested recipes.

---

## How to Use Research Notebooks Here

1. Skim the published notebook for data items and universe logic.
2. Exact-search every BQL data-item mnemonic in `22`; use FLDS for absent/ambiguous candidates or unresolved parameters.
3. Rewrite in object syntax (`bql.Request` + `bq.data.*`) unless string BQL is required.
4. Copy finished logic into numbered topic files (`01`–`20`) when it becomes a reusable pattern; keep release metadata in `21`.

---

## Project Practice Notes

- Research notebooks in this project are authored locally in Cursor, then manually transferred to Bloomberg BQuant for execution.
- Prefer object-syntax PyBQL (`bql.Request` + `bq.data.*`) over string queries unless string syntax is required.
- For field uncertainty, search `22` first and request Terminal FLDS only when the catalog and curated references do not resolve it.
- Allowed stack: BQL, Pandas, Plotly, ipywidgets — no external APIs.

## Catalog pointers (deduplicated)

- Help Center Examples title index → `16-home.md` (or Intent→File in `RAG KB/00-RAG-INDEX.md`)
- Get Data / Build Analysis official recipes → topic files via `RAG KB/00-RAG-INDEX.md` (not duplicated here)
- Portfolio API / Quickstart → `14-bql-for-port-prep.md`
- pandas chapters → `18-using-pandas.md`
- Desktop limits → `bquant-core.mdc` + `05` / `17`

## Build Analysis Official: BQuant Assistant

> Limited beta. It suggests code but cannot execute PyBQL, create live DataFrames, inspect unattached notebook state, detect installed packages, or preserve chat context across project shutdowns.

### Prompting checklist
- Attach or explicitly select the relevant code; the assistant is not automatically aware of notebook contents.
- Tutorial-observed commands: `@file` attaches a file, `/clear` clears the conversation, and `/info` displays session information.
- Session context is narrow: the Help Center snapshot states that only the most recent two prompts are remembered.
- State the desired result, format, libraries, error handling, and initialization requirements.
- Split BQL work into small tasks and require the Desktop-safe stack from `bquant-core.mdc`.
- Verify uncertain mnemonics against `22`; verify unresolved parameters/metadata with current API docs or Terminal FLDS.
- Run and validate suggestions manually in BQuant. Never assume generated package dependencies are installed or allowed.
- Apply Bloomberg AI guardrails, Acceptable Use Policy, and AI Services terms. English prompts are the documented optimized path; validate non-English interpretation carefully.

## White Papers / Strategy Notebooks (Help Center)

> Dense extracts from Help Center white-paper notebooks. Treat as research examples; cross-check fields in `22` and use FLDS only when unresolved. Desktop BQL limits apply.

### White Paper: Contango Conditional Short VIX Strategy
- Abstract - Shorting the VIX without Volmageddon-like events: how futures term structure knowledge can enhance the short volatility strategy. White Paper - Contango Conditional Short VIX Strategy.
- **Topics:** Open an interactive version; Introduction¶; Configuration¶; Import required libraries¶; Methodology¶; Retrieve data¶; Calculate excess return series of synthetic future¶; Calculate returns for varying strategies¶
- **Key points:**
  - Import required libraries
  - Methodology Retrieve data
  - Calculate excess return series of synthetic future
  - Calculate returns for varying strategies
  - Required BQuant datasets: BQL
  - Additional libraries outside standard environment: None
  - Supporting files provided: analytics.py - Object that computes different portfolio analytics on returns series

```python
pa = PortfolioAnalytics()
stats = pd.concat(
    [
        pa.summary_stats(stop_at_date(excess_ret_leverage, end_date).astype(float)).rename(
            columns={0: "Short Futures"}
        ),
        pa.summary_stats(stop_at_date(excess_ret_leverage_contango, end_date).astype(float)).rename(
            columns={0: "Short Futures in Contango"}
        ),
        pa.summary_stats(stop_at_date(excess_ret_leverage_high_basis_slope, end_date).astype(float)).rename(
            columns={0: "Short Futures in Contango with High Basis Slope"}
        ),
    ],
    axis=1,
)
```

```python
paths = pd.concat(
    [
        stop_at_date(wealth_path, end_date).rename("Short Futures"),
        stop_at_date(wealth_path_contango, end_date).rename("Short Futures in Contango"),
        stop_at_date(wealth_path_basis_slope, end_date).rename(
            "Short Futures in Contango with High Basis Slope"
        ),
    ],
    axis=1,
)

fig = px.line(paths, template="plotly_dark")
fig = fig.update_layout(
    xaxis_title="", yaxis_title="Growth of $1", legend=dict(title="", orientation="h")
)
```

### White Paper: Equity Factor Investing Strategy
- Abstract - Different combinations of long-short portfolios (Q1-Q5) of different factors give better risk adjusted returns than the long-short factor portfolios. White Paper - Equity Factor Investing Strategy.
- **Topics:** Open an interactive version; Introduction¶; Configuration¶; Import required libraries¶; Methodology¶; Retrieve data from BQL¶; Combine long-short factor portfolios with equal weights¶; Combine long-short factor portfolios using inverse volatility weights¶
- **Key points:**
  - Import required libraries
  - Methodology Retrieve data from BQL
  - Combine long-short factor portfolios with equal weights
  - Combine long-short factor portfolios using inverse volatility weights
  - Combine long-short factor portfolios to minimize portfolio variance
  - Chart cumulative returns
  - Chart dynamic weights

```python
# Create DataFrame for inverse volatility weights
df1 = pd.DataFrame({
    'Category': factors,
    'Value': wts_inv_vol.squeeze()
})

# Create DataFrame for minimum variance weights
df2 = pd.DataFrame({
    'Category': factors,
    'Value': wts_min_var.squeeze()
})

# Define color mapping for both charts
colors_dict = dict(zip(factors, colors))

# Plot two pie charts with shared color mapping
charting.plot_two_pie_charts(
    df1,
    df2,
    title1="Weights inversely proportional to vol",
    title2="Weights that minimize the variance of portfolio",
    colors1=colors_dict,
    colors2=colors_dict
)
```

```python
# Configuration
random_seed = 1
n_portfolios = 1000

# Generate random weights 
rng = np.random.default_rng(random_seed)
n_factors = len(factors)
weights = rng.random((n_portfolios, n_factors))

# Normalize weights
weights /= weights.sum(axis=1, keepdims=True)  

# Create portfolio returns 
factor_returns = df.iloc[:, :n_factors].values
portfolio_returns = factor_returns @ weights.T

# Create DataFrame with better column naming
portfolio_df = pd.DataFrame(
    portfolio_returns, 
    columns=[f'portfolio_{i+1:04d}' for i in range(n_portfolios)], 
    index=df.index
)

# Calculate portfolio metrics 
portfolio_metrics = pd.DataFrame({
    'return': portfolio_df.apply(pa.annual_return),
    'stddev': portfolio_df.apply(pa.annual_vol)
})

# Highlight individual portfolios and their combinations
factors_strats = factors + ['WtsEqual', 'WtsInvVol', 'WtsMinVar']
colors = [
    'red', 'limegreen', 'yellow', 'violet', 'orange', 
    'hotpink', 'deepskyblue', 'mediumturquoise'
]

highlights = [
    (float(summary_stats[strategy].values[1]) / 100,  
     float(summary_stats[strategy].values[0]) / 100,  
     strategy,
     colors[i % len(colors)])
    for i, strategy in enumerate(factors_strats)
    if strategy in summary_stats.columns
]

# Create plot
fig = charting.plot_scatter_with_highlights(
    portfolio_metrics['stddev'], 
    portfolio_metrics['return'],
    highlights=highlights,
    title='Risk vs Return Analysis - Monthly Rebalanced Portfolios',
    marker_size=4.5,
    fig_height=800,
    fig_width=800
)
# ... truncated ...
```

### White Paper: Primary Market Performance for US Municipal Bonds
- Abstract - Can an equal-weighted combination of tax-exempt municipal bonds outperform tenor-matched benchmarks on average, illustrating the relative attractiveness of new issues?
- **Topics:** Open an interactive version; Introduction¶; Configuration¶; Import required libraries¶; Methodology¶; Retrieve data from BQL¶; Relative performance by state¶; Relative performance by ultimate borrower in Georgia¶
- **Key points:**
  - Import required libraries
  - Methodology Retrieve data from BQL
  - Relative performance by state
  - Relative performance by ultimate borrower in Georgia
  - Relative performance by ratings
  - Relative performance by ultimate borrower within a sector
  - Required BQuant datasets: Equity data using BQL

```python
lookback = '-1y'
window = '8d'
end_date = dt.date(2025, 6, 30)
window = '8d'
min_coupon_percent = 3
max_coupon_percent = 5

df_benchmark_1y = get_benchmark_and_tenor_data(index, tenors, lookback, end_date)

df_bond_data_1y = get_bond_data(
    window=window,
    end_date=end_date,
    lookback=lookback,
    coupon_range=(min_coupon_percent, max_coupon_percent)
    )

df_final_1y = compute_relative_performance(df_bond_data_1y, df_benchmark_1y)

dfp = df_final_1y[df_final_1y.Sector == 'Airports'].copy()
# Get the yyyy-mm for month of sale:
dfp['Month of sale'] = pd.to_datetime(dfp['Issue Date']).dt.strftime('%Y-%m') 
plot_grouped_metric(dfp, group_by='Ultimate borrower', secondary='Month of sale')
```

```python
import datetime as dt
import pandas as pd

import bql
from src.data_handler import (
    get_benchmark_and_tenor_data, 
    get_bond_data, 
    compute_relative_performance
)
from src.charting import (
    plot_grouped_metric,
    plot_grouped_metric_stacked
)
```

### White Paper: Earnings Surprise Momentum Strategy
- Abstract - Do positive earnings announcements surprises lead to higher price momentum than negative surprises? White Paper - Earnings Surprise Momentum Strategy.
- **Topics:** Open an interactive version; Introduction¶; Configuration¶; Import required libraries¶; Methodology¶; Retrieve data from BQL¶; Compute earnings surprise as percent of estimated EPS or stock price¶; Combine returns prior to and after the earnings announcement¶
- **Key points:**
  - Import required libraries
  - Methodology Retrieve data from BQL
  - Compute earnings surprise as percent of estimated EPS or stock price
  - Combine returns prior to and after the earnings announcement
  - Compute mean returns for positive and negative surprises
  - Visualize the average return for positive and negative earnings surprises
  - Implement a trading strategy

```python
def combine_returns(
    df_earnings_surprise,
    df_prices_and_returns,
    n_days_before=5,
    n_days_after=20,
):
    # Series of day offsets from the announcement date
    day_offsets = [x for x in range(-n_days_before, n_days_after + 1)]

    df = df_earnings_surprise.copy()
    for day_offset in day_offsets:
        # Temporary df where the px column is named (e.g. '-1D') so it merges
        # with this new name
        df_rtn_temp = df_prices_and_returns[['Return']].rename(
            columns={'Return': f'{day_offset}D'}
        )
        # Shift the returns up x rows within the same company so as we iterate,
        # when we merge the px with the REVISION_DATE from df, we are merging a
        # shifted value each time
        # Additional -1 as day 0 is the day after the announcement
        df_rtn_temp = df_rtn_temp.groupby('FIGI').shift(-day_offset - 1)

        df = pd.merge(
            df, df_rtn_temp, how='left', left_index=True, right_index=True
        )
    # Drop any rows with no returns for a certain date, e.g. if a company has
    # just reported so there is no announce_date + 20D yet
    df = df.dropna(subset=[f'{x}D' for x in day_offsets])
    return df

df_combined_returns = combine_returns(
    df_earnings_surprise, df_prices_and_returns
)
```

```python
def plot_strategy_results(
    df_strategy_dollar_neutral,
    df_strategy_const_weights,
    start_date=datetime.date(2010, 1, 1),
    end_date=None,
):
    if start_date is not None:
        df_strategy_dollar_neutral = df_strategy_dollar_neutral[
            df_strategy_dollar_neutral.index >= start_date
        ]
        df_strategy_const_weights = df_strategy_const_weights[
            df_strategy_const_weights.index >= start_date
        ]

    if end_date is not None:
        df_strategy_dollar_neutral = df_strategy_dollar_neutral[
            df_strategy_dollar_neutral.index <= end_date
        ]
        df_strategy_const_weights = df_strategy_const_weights[
            df_strategy_const_weights.index <= end_date
        ]

    df = pd.concat(
        [
            df_strategy_dollar_neutral.cumsum(),
            df_strategy_const_weights.cumsum(),
        ],
        axis=1,
    ).reset_index()
    df.columns = [
        'Date', 
        'Dollar neutral strategy', 
        'Constant weight strategy'
    ]

    sr_dollar_neutral = round(
        compute_sharpe_ratio(df_strategy_dollar_neutral['Return']), 2
    )
    sr_const_weights = round(
        compute_sharpe_ratio(df_strategy_const_weights['Return']), 2
    )
    return charting.build_strategy_returns_fig(
        df, sr_dollar_neutral, sr_const_weights
    )
```
