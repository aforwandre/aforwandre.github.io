---
generated: true
role: proven_bundle_examples
never_edit: true
---

# Proven bundle examples (generated)

> Generated from Desktop-proven `User scripts/` and official
> BQuant apps distilled into `01`/`02`/`09`/`18`.
> Registry: `bundle_examples_registry.json`. Never edit this file.
>
> Official BQuant apps are product demos used to sell BQuant.
> Treat their **code usage** as authoritative. They are not a
> full product spec. Goal table copies distilled Production
> Recipes, not the unindexed OCR archive.
> These cards outrank `09`/`11` tutorials and CONCEPT_INDEX for a
> **clear goal**. They are **not** a third highway for ETF/MDX,
> ETF Spread, or FI Index Change: those stay on `25` / `26` / `27` /
> `28` / `29`.

## How to use

1. Named destination in `00` § 2 → that route card. Stop here.
2. Else, match **one** Goal table row. Read that card only.
3. Borrow **code usage** (Request idiom, identity, do-not list).
   Do not copy a demo's feature limits as the freeze.
4. Freeze a new route card before writing a new `User scripts/`
   project. New BQL not on the card → `CONCEPT_INDEX` then `23`.
5. Do not copy live `config.py` AIM codes. Do not copy Thai/DRSK
   leftover into an unrelated app.

## How this file evolves

- `regenerate_kb_bundle.py` re-extracts registered functions from
  production parsers. PARSER_VERSION drift fails integrity until
  the registry is reviewed.
- A new `User scripts/<Project>/**/data.py` with `PARSER_VERSION`
  and no registry row fails integrity. That is the promotion gate:
  freeze the app, then add project + example rows.
- Official BQuant apps: product demos. Add a Goal table row from
  the distilled Production Recipe in `01`/`02`/`09`/`18` for
  **code usage**. Do not copy `Official scripts/` OCR files, and
  do not copy a demo's feature set as the freeze.
- Uncurated folders starting with `_` are ignored (scratch tests).

## Goal table

| Goal | Card | Proven in | Evidence |
|---|---|---|---|
| Point-in-time factor backtest (one request per rebalance date) | `official_pit_factor_backtest` | `official_equity` (`01`) | `official-bquant-app` |
| Equity universe adapter that keeps members/holdings/PORT weight keys together | `official_equity_universe_weight` | `official_equity` (`01`) | `official-bquant-app` |
| Inject one index series into a member-level expression | `official_index_value_injection` | `official_equity` (`01`) | `official-bquant-app` |
| A/H dual-listing premium from mapped tickers plus FX | `official_ah_dual_listing` | `official_equity` (`01`) | `official-bquant-app` |
| Technical monitor: pull prices in BQL, compute MA/crossover in pandas | `official_technical_monitor_pandas_ma` | `official_equity` (`01`) | `official-bquant-app` |
| Pair analytics on one aligned price matrix (not one Request per pair) | `official_pair_analytics` | `official_equity` (`01`) | `official-bquant-app` |
| Bond/loan ownership via holders() one instrument per Request | `official_holders_batch` | `official_credit` (`02`) | `official-bquant-app` |
| Issuer curve with independent historical snapshots | `official_issuer_curve_snapshots` | `official_credit` (`02`) | `official-bquant-app` |
| Mortgage/ABS screen then single-security drill-down | `official_mortgagesuniv_screen_then_detail` | `official_credit` (`02`) | `official-bquant-app` |
| Thin MAIN notebook plus AppController, bind observers once | `official_thin_app_architecture` | `official_app` (`09`) | `official-bquant-app` |
| Normalize one response or execute_many without losing lineage | `official_response_normalization` | `official_pandas` (`18`) | `official-bquant-app` |
| Current or Projected AIM positions for one account | `aim_one_account_positions` | `etf_capping` (`25`) | `user-desktop-freeze` |
| Batch BQL requests and keep request lineage when some fail | `execute_many_labeled_lineage` | `etf_capping` (`25`) | `user-desktop-freeze` |
| Names plus market_status without Request mode=cached | `uncached_market_status_descriptors` | `etf_capping` (`25`) | `user-desktop-freeze` |
| Company grouping key via fundamentalticker lineage | `company_grouping_lineage` | `etf_capping` (`25`) | `user-desktop-freeze` |
| USD last price with holiday fill=prev (Last Close vs Real Time) | `last_price_fill_prev_usd` | `etf_capping` (`25`) | `user-desktop-freeze` |
| Classify holdings from yellow-key suffix (not crncy/security_typ) | `yellow_key_asset_classifier` | `etf_capping` (`25`) | `user-desktop-freeze` |
| Cash yellow keys to USD via USD{CCY} BGNL invert | `cash_fx_bgnl_invert` | `etf_capping` (`25`) | `user-desktop-freeze` |
| Index members + split NameCN request + daily OHLCV range | `index_members_namecn_ohlcv` | `mdx_scan` (`26`) | `user-desktop-freeze` |
| MAIN that displays UI and waits for an Update click before BQL | `main_update_only` | `etf_capping` (`25`) | `user-desktop-freeze` |
| MAIN that runs one refresh when the kernel starts | `main_load_on_start` | `mdx_scan` (`26`) | `user-desktop-freeze` |
| Port a Futu/TDX daily formula to pandas (not BQL field names) | `futu_formula_pandas_port` | `mdx_scan` (`26`) | `user-desktop-freeze` |

## official_pit_factor_backtest

- Goal: Point-in-time factor backtest (one request per rebalance date)
- Keywords: `PIT`, `backtest`, `members dates`, `ntile`, `execute_many`
- Identity: `equity_index_members`
- Authority: 01 § Production Recipe: PIT Factor Backtest
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: query today's members and attach historical fundamentals; use OCR factor aliases as mnemonic authority
- Source: `RAG KB/01-bql-for-equities.md`

### Production Recipe: PIT Factor Backtest

**Evidence:** script-verified composition from *Fundamental Backtester*, constrained by the canonical point-in-time rules above.

The non-negotiable design is one request per rebalance date. Backdate both index membership and factor/return observations; do not query today's members and attach historical fundamentals.

```python
def build_rebalance_request(
    rebalance_date,
    next_rebalance_date,
    index_ticker,
    signal,
):
    universe = bq.univ.members(index_ticker, dates=rebalance_date)
    weight = bq.data.id()['weights']  # members() metadata: lowercase
    bucket = signal.ntile(4)
    holding_period_return = bq.data.day_to_day_tot_return_gross_dvds(
        dates=bq.func.range(rebalance_date, next_rebalance_date),
    ).prod()
    items = {
        'Signal': signal,
        'Quartile': bucket,
        'Weight': weight,
        'Holding Period Return': holding_period_return,
    }
    return bql.Request(
        universe,
        items,
        with_params={'fill': 'prev', 'mode': 'cached'},
    )

requests = [
    build_rebalance_request(start, end, 'INDU Index', signal)
    for start, end in zip(rebalance_dates[:-1], rebalance_dates[1:])
]
responses = list(
    bq.execute_many(requests, on_request_error=handle_request_error)
)
```

Production sequence:

1. Generate explicit business rebalance dates; do not use calendar period ends that can land on weekends.
2. Backdate `members(..., dates=rebalance_date)`.
3. Apply fiscal-period and `as_of_date` controls to each fundamental item when the strategy requires PIT statements/estimates.
4. Execute bounded batches with `execute_many`; retain the request date on each frame.
5. Use a holding-period return over each adjacent rebalance interval, not a single-date return.
6. Build quartile returns locally; verify whether the intended spread is quartile 4 minus 1 or the reverse before compounding.
7. Compare against a separately retrieved benchmark and calculate rolling volatility, Sharpe, beta, information ratio, active return, and drawdown.

The backtester uses a second valid outlier pattern: compute a sector-relative z-score and cap it with `if_`. This does not replace the separate `.group().winsorize().avg()` aggregation rule.

```python
sector_z = raw_signal.group(sector).zscore().ungroup()
signal = bq.func.if_(
    sector_z > 3,
    3,
    bq.func.if_(sector_z < -3, -3, sector_z),
)
```

Do not use the script archive's OCR-reconstructed factor aliases as mnemonic authority. Start with the verified factor fields in this file / `19`, then exact-search `22`.

## official_equity_universe_weight

- Goal: Equity universe adapter that keeps members/holdings/PORT weight keys together
- Keywords: `members`, `holdings`, `PORT`, `weights`, `WEIGHTS`
- Identity: `equity_universe_weight`
- Authority: 01 § Universe Adapter with Explicit Weight Semantics
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: return a universe object without its weight recipe; use setdiff() when later calculations need those weights; promote the OCR lowercase PORT key
- Source: `RAG KB/01-bql-for-equities.md`

### Production Recipe: Universe Adapter with Explicit Weight Semantics

**Evidence:** script-verified across *Fundamental Backtester*, *BI Thematic Exposure*, and other equity apps.

Keep the universe branch and weight recipe together. A generic adapter that returns only a universe object is unsafe because the hidden metadata key differs.

```python
def equity_universe_and_weight(kind, identifier, as_of=None):
    if kind == 'Index':
        universe = bq.univ.members(identifier, dates=as_of)
        weight = bq.data.id()['weights']
    elif kind == 'Fund Holdings':
        universe = bq.univ.holdings(identifier, dates=as_of)
        weight = bq.data.id()['WEIGHTS']
    elif kind == 'Portfolio':
        universe = bq.univ.members(identifier, type='PORT')
        weight = bq.data.id()['WEIGHTS']
    elif kind == 'Ticker List':
        universe = bq.univ.list(identifier)
        weight = bq.data.cur_mkt_cap()
    else:
        raise ValueError(f'Unsupported equity universe kind: {kind}')
    return universe, weight
```

Treat this as a shape contract:

- `members` and `holdings` are not interchangeable.
- Preserve the branch-specific metadata until after the BQL response is materialized.
- Do not use `setdiff()` when later calculations require those weights.
- Normalize to a common application column such as `Weight` only after extraction.
- The BI-theme photo showed a lowercase portfolio key, but that conflicts with the verified portfolio rule in this file and `bql-pandas-safety.mdc`; it remains OCR-observed and is not promoted.

## official_index_value_injection

- Goal: Inject one index series into a member-level expression
- Keywords: `bq.func.value`, `attribution`, `index_level`
- Identity: `equity_index_vs_members`
- Authority: 01 § Index Attribution with Injected Index Series
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: treat indx_divisor() bracket keys as 22 mnemonics without verifying shape
- Source: `RAG KB/01-bql-for-equities.md`

### Production Recipe: Index Attribution with Injected Index Series

**Evidence:** script-verified from the text-pasted `app.ipynb` in *Index Performance Drivers, Attribution & Trends*.

Use `bq.func.value()` when a member-level expression needs one value from a separate index universe:

```python
index_universe = bq.univ.list([index_ticker])
index_level = bq.func.value(
    bq.data.px_last(dates=as_of_date),
    index_universe,
).group().avg()

member_move = bq.data.px_last(
    dates=bq.func.range(start_date, end_date),
    fill='prev',
).pct_chg()
breadth_up = bq.data.id().matches(member_move > 0).group().count()
breadth_down = bq.data.id().matches(member_move < 0).group().count()
```

For sector attribution:

1. Freeze the constituent universe at the attribution start date.
2. Group by a verified classification item.
3. Use official member weights when attributing the index; market-cap weights are a different analytical choice.
4. Retrieve the index divisor/position metadata only through a verified index recipe.
5. Keep index-level and member-level frames separate until their dates and units are explicit.

The source app also calculates point contribution from member position metadata and `indx_divisor()`. The exact position bracket key is script-observed metadata rather than a `22` mnemonic, so verify its current response shape before copying that extension.

## official_ah_dual_listing

- Goal: A/H dual-listing premium from mapped tickers plus FX
- Keywords: `A/H`, `a_over_h_share_conversion`, `CNY`, `HKD`
- Identity: `equity_dual_listing`
- Authority: 01 § A/H Dual-Listing Premium
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: invent the A ticker by string transform; promote photographed forward-dividend parameter signatures
- Source: `RAG KB/01-bql-for-equities.md`

### Production Recipe: A/H Dual-Listing Premium

**Evidence:** script-verified from *A/H Share Premium Calculator*; `a_over_h_share_conversion()` exists in `22`.

```text
active HK equity screen
-> request H price + mapped A ticker
-> request A price for mapped tickers
-> request CNY/HKD FX
-> merge all three time series on DATE
-> premium = A price in HKD / H price - 1
-> rolling mean / standard deviation / z-score
```

Operational rules:

- Keep the mapped A-share ticker as data, not as an assumed string transformation.
- Apply corporate-action adjustment consistently to both equity legs.
- Align FX with `fill='prev'` only across justified market-calendar gaps.
- Drop incomplete triples before calculating the premium.
- Treat forward-dividend adjustment as a separate optional layer; its photographed parameter signature is not promoted here.

## official_technical_monitor_pandas_ma

- Goal: Technical monitor: pull prices in BQL, compute MA/crossover in pandas
- Keywords: `crossover`, `heatmap`, `px_last`, `moving average`
- Identity: `equity_price_then_pandas`
- Authority: 01 § Technical Monitor with Drill-Down
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: infer a BQL MA data-item signature from an OCR script
- Source: `RAG KB/01-bql-for-equities.md`

### Production Recipe: Technical Monitor with Drill-Down

**Evidence:** practice-derived from *Relative Strength Finder* and *Multi-Market MA Heatmap & Monitor*. The crossover calculation is pure Pandas; the price pull uses canonical equity time-series patterns.

```python
def crossover_flags(fast: pd.Series, slow: pd.Series) -> pd.DataFrame:
    difference = fast - slow
    sign = np.sign(difference)
    return pd.DataFrame({
        'Cross Up': (sign.shift(1) <= 0) & (sign > 0),
        'Cross Down': (sign.shift(1) >= 0) & (sign < 0),
    })
```

App composition:

1. Retrieve a bounded equity universe and price history.
2. Pivot to a date × ticker matrix before rolling calculations.
3. Compute current signals locally and aggregate by sector/size bucket.
4. Render the breadth matrix once.
5. Bind heatmap/grid selection to a per-ticker chart; update existing `FigureWidget`s with `batch_update()` rather than recreating the full dashboard.

Do not infer an MA data-item signature from an OCR script. If BQL-native MA parameters are unresolved, retrieve `px_last` (and OHLC if needed) and calculate the rolling series in Pandas. When parsing Desktop Arrow OHLC, keep the `DATE` column (`18`).

## official_pair_analytics

- Goal: Pair analytics on one aligned price matrix (not one Request per pair)
- Keywords: `cointegration`, `ADF`, `hedge ratio`, `px_last`
- Identity: `equity_price_matrix`
- Authority: 01 § Pair Analytics
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: issue one BQL request per pair; add pip for statsmodels
- Source: `RAG KB/01-bql-for-equities.md`

### Production Recipe: Pair Analytics

**Evidence:** script-verified composition from *Cointegration Pairs Trading* plus canonical `px_last` retrieval.

Keep BQL and statistics separated:

```text
BQL: universe -> px_last history -> date x ticker matrix
Pandas/statsmodels: align/drop NA -> OLS hedge ratio -> residual spread -> ADF
Plotly: p-value matrix -> click -> pair price/spread drill-down
```

Desktop safety:

- Cap the universe before the O(n²) pair loop.
- Use one aligned price matrix rather than one BQL request per pair.
- Treat a low ADF p-value as a statistical screen, not a trading guarantee.
- Recompute the hedge ratio on the selected historical window; do not mix windows between the matrix and drill-down.

`statsmodels` is an additional dependency. Use it only when already available or after explicit package approval; do not add `pip` instructions.

## official_holders_batch

- Goal: Bond/loan ownership via holders() one instrument per Request
- Keywords: `holders`, `orig_ids`, `holder_name`, `ownership`
- Identity: `credit_holders`
- Authority: 02 § Bond / Loan Ownership
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: replace holders() with equity/fund holdings(); concatenate Summary and Lowest as the same grain
- Source: `RAG KB/02-bql-for-fixed-income.md`

### Production Recipe: Bond / Loan Ownership

**Evidence:** canonical single-instrument `holders()` behavior from the Private Credit tutorial, reinforced by the *Bond Ownership Dashboard* application.

`holders()` accepts one instrument per universe. Batch ownership work by building one request per bond/loan and preserving the source instrument on every response.

```python
def build_holder_request(instrument):
    universe = bq.univ.holders(instrument, view='lowest')
    items = {
        'Instrument': bq.data.id()['orig_ids'],
        'Holder Name': bq.data.id()['holder_name'],
        'Position': bq.data.id()['position'],
        'Market Value': bq.data.id()['reported_market_value'],
    }
    return bql.Request(universe, items)

requests = [build_holder_request(instrument) for instrument in instruments]
responses = list(bq.execute_many(requests))

frames = []
for instrument, response in zip(instruments, responses):
    frame = pd.concat(
        [item.df()[item.name] for item in response],
        axis=1,
    )
    frame['Requested Instrument'] = instrument
    frames.append(frame.reset_index())

ownership = pd.concat(frames, ignore_index=True)
```

Production extensions from the dashboard:

- Use `view='Summary'` for institution-level ownership and `view='Lowest'` for fund-level detail; do not concatenate them as if they had the same grain.
- Keep **institution**, **fund**, and **underlying holding detail** as separate shapes/tabs.
- Compute ownership change only after aligning holder identity and observation date.
- Defer fund look-through until a user selects an aggregate holder row; this avoids downloading every fund constituent.
- Treat missing detailed holdings as a valid empty state, not an exception.
- Use bounded batches and an `on_request_error` callback for long instrument lists.
- A dated ownership comparison requires two explicit `holders(..., dates=...)` snapshots. Preserve both snapshot dates before calculating changes.

Do not replace `holders()` with equity/fund `holdings()`: they answer different questions.

## official_issuer_curve_snapshots

- Goal: Issuer curve with independent historical snapshots
- Keywords: `issuer curve`, `rating waterfall`, `historical snapshot`
- Identity: `credit_issuer_curve`
- Authority: 02 § Issuer Curve with Historical Comparisons
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: mutate the current snapshot into a historical one; drop the rating filter and download a broad bond universe; infer a regression signature from chart labels
- Source: `RAG KB/02-bql-for-fixed-income.md`

### Production Recipe: Issuer Curve with Historical Comparisons

**Evidence:** script-verified composition from *Bond Curves Comparison with History*, using the canonical bond-chain/curve concepts in this file.

1. Resolve the issuer or explicit bond universe.
2. Pull the cross-sectional bond descriptors and selected pricing metric for one date.
3. Apply currency, sector, coupon, maturity, rating, and amount filters before regression.
4. Fit the selected curve/regression to the filtered points.
5. Store each historical snapshot independently; never mutate the current snapshot into a historical one.
6. Overlay current and selected historical curves, then bind point clicks to bond detail.

The curve app uses a conservative rating waterfall for peer selection: Bloomberg, then S&P, Moody's, and Fitch normalized scales, skipping missing/NR observations. If no valid rating bucket exists, return an intentionally empty universe rather than dropping the rating filter and downloading a broad bond universe.

```python
def valid_rating(value):
    return (value != 24).and_(value != bql.NA)

consolidated_rating = bq.func.if_(
    valid_rating(bbg_rating),
    bbg_rating,
    bq.func.if_(
        valid_rating(sp_rating),
        sp_rating,
        bq.func.if_(
            valid_rating(moodys_rating),
            moodys_rating,
            bq.func.if_(
                valid_rating(fitch_rating),
                fitch_rating,
                bql.NA,
            ),
        ),
    ),
)
```

Desktop-safe lazy-load pattern:

```text
render controls disabled
-> user chooses universe
-> first explicit Run loads bonds
-> enable data-dependent controls
-> field/date changes update only the affected traces
```

The application supports multiple regression choices, but exact regression parameter values remain governed by the verified recipes/API references. Do not infer a regression signature from chart labels.

## official_mortgagesuniv_screen_then_detail

- Goal: Mortgage/ABS screen then single-security drill-down
- Keywords: `mortgagesuniv`, `screen`, `drill-down`
- Identity: `credit_mortgagesuniv`
- Authority: 02 § Securitized-Product Screen and Drill-Down
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: run expensive scenario/cashflow fields on the full screen universe
- Source: `RAG KB/02-bql-for-fixed-income.md`

### Production Recipe: Securitized-Product Screen and Drill-Down

**Evidence:** canonical `mortgagesuniv` tutorial plus application composition from *Asset-backed Security Analysis*.

Use two request levels:

- **Screen request:** a tightly filtered `mortgagesuniv` universe with only grid/sort fields.
- **Single-security request:** expensive scenario/cashflow analytics only after the user selects one result.

```python
screen_universe = bq.univ.filter(
    bq.univ.mortgagesuniv('all'),
    screen_predicate,
)
screen_response = bq.execute(
    bql.Request(
        screen_universe,
        screen_items,
        with_params={'mode': 'cached'},
    )
)
```

Production rules:

- Keep universe filters and chart-axis selectors separate.
- Validate that both selected axes exist and are numeric before plotting.
- Register result observers once; repeated `Run` clicks must not stack callbacks.
- Use a single-security detail query for scenario-dependent fields.
- Normalize preliminary/provisional rating labels before grouping; the application strips a trailing `(P)` marker and whitespace.
- WAL field/signature ambiguity remains FLDS-gated as documented in the securitized-products tutorial below.

## official_thin_app_architecture

- Goal: Thin MAIN notebook plus AppController, bind observers once
- Keywords: `AppController`, `MAIN.ipynb`, `_events_bound`, `lazy-load`
- Identity: `app_lifecycle`
- Authority: 09 § Production App Architecture from Official Scripts
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: let views invent BQL fields from arbitrary text; stack Run observers on every click; treat the demo tab set as the user's product spec
- Source: `RAG KB/09-build-analysis.md`

## Production App Architecture from Official Scripts

Repeated across the 2026-08-26 EQUITY/CREDIT script ingest: *Bespoke Factor Analysis*, *Index Performance Drivers*, *Bond Ownership Dashboard*, *Bond Curves Comparison*, *Asset-backed Security Analysis*, and the technical monitors.

### Thin notebook, importable application

For a multi-view app, keep the notebook as a bootstrapper:

```text
MAIN.ipynb
  -> add project root to sys.path
  -> import AppController
  -> app = AppController()
  -> display(app.render())

controllers/
  app_controller.py      dependency wiring, defaults, tab composition
  error_log.py           shared status/log helpers
views/
  chart_tab.py           widgets + callbacks + rendering
  summary_tab.py
models/
  engine.py              BQL orchestration + analytics
data/
  field_library.py       verified field/category mappings
```

This separation is **practice-derived**. Exact BQL fields remain in the routed domain file (`01` or `02`) and must pass the field/signature gate.

### State ownership contract

- The controller owns shared configuration and creates each tab once.
- Each tab owns its widgets, output container, and log widget.
- The model/engine returns DataFrames or typed results; it does not call `display`.
- Views do not build ad-hoc BQL fields from arbitrary text. They select from a verified field registry.
- Callback code reads widget state at execution time; avoid stale module-level globals.
- After replacing application `.py` files on BQuant, Restart Kernel then Run All; `import` is cached (`09` Error Log).

```python
class AppController:
    def __init__(self, service, field_registry):
        self.chart_log = create_log_widget()
        self.summary_log = create_log_widget()
        self.chart_tab = ChartTab(service, field_registry, self.chart_log)
        self.summary_tab = SummaryTab(
            service,
            field_registry,
            self.summary_log,
        )

    def render(self):
        tabs = widgets.Tab(children=[
            self.chart_tab.render(),
            self.summary_tab.render(),
        ])
        tabs.set_title(0, 'Chart')
        tabs.set_title(1, 'Summary')
        return tabs
```

### Bind observers exactly once

Repeated `Run` calls must not register additional observers.

```python
class Dashboard:
    def __init__(self):
        self._events_bound = False
        self.run_button = widgets.Button(description='Run')
        self.universe = widgets.Dropdown(options=[])
        self.output = widgets.Output()
        self._bind_events()

    def _bind_events(self):
        if self._events_bound:
            return
        self.run_button.on_click(self._run)
        self.universe.observe(self._on_universe_change, names='value')
        self._events_bound = True
```

For lambdas created in loops, freeze the current value:

```python
for field in fields:
    button.on_click(lambda event, field=field: remove_field(field))
```

Prefer `functools.partial` when the callback has several bound arguments.

When one callback must correct another widget's value, prevent recursive updates:

```python
def set_date_without_recursion(widget, value, handler):
    widget.unobserve(handler, names='value')
    try:
        widget.value = value
    finally:
        widget.observe(handler, names='value')
```

For coupled date pickers, a small re-entry flag is also valid:

```python
if self._fixing_dates:
    return
self._fixing_dates = True
try:
    fix_date_range()
finally:
    self._fixing_dates = False
```

### Lazy-load expensive tabs and drill-downs

Official CREDIT applications repeatedly use a two-level request design:

```text
render placeholders and disabled data controls
-> explicit Run loads a bounded summary universe
-> enable controls
-> row/cell selection loads one security/fund detail
-> trace-only updates do not rerun the summary request
```

Use this for bond holders, fund look-through, securitized scenarios, issuer curves, and large equity monitors. It reduces Desktop timeout risk and prevents unnecessary downloads.

```python
def on_row_selected(change):
    row = selected_row(change)
    if row is None:
        detail_box.children = [empty_state('Select a row')]
        return
    detail_box.children = [spinner]
    try:
        detail = engine.fetch_detail(row['ID'])
        detail_box.children = [build_detail_grid(detail)]
    except Exception as exc:
        detail_box.children = [error_state(str(exc))]
```

### Stable request lifecycle

Every long callback should expose the same states:

```python
def run(_):
    run_button.disabled = True
    status.value = 'Loading...'
    with output:
        clear_output(wait=True)
        try:
            result = engine.run(progress_callback=update_progress)
            render_result(result)
            status.value = 'Completed'
        except Exception as exc:
            status.value = f'Error: {exc}'
        finally:
            run_button.disabled = False
```

Do not swallow request failures and then render an empty chart as success. Distinguish:

- no rows matched;
- detail unavailable;
- partial request failures;
- entitlement/signature failure;
- timeout / request too broad.

### Update figures in place

Create expensive `FigureWidget`s once and update all properties inside one batch:

```python
with figure.batch_update():
    trace.x = frame.index
    trace.y = frame['Value']
    figure.layout.title = title
```

Heatmap/grid click handlers should update only the drill-down view. Rebuilding the whole `VBox` on each click loses selection state and may duplicate callbacks.

### Widget compatibility checks

The official scripts include older and newer widget idioms. On Desktop JupyterLab 4.3.6 / ipywidgets v8:

- validate `observe(..., names='value')` payloads;
- validate `FileUpload.value` shape before reading;
- avoid mutating tuple-valued `children` in place;
- test DataGrid selection payloads and renderer expressions;
- run the notebook from a fresh kernel to catch hidden cell-order state.

---

## official_response_normalization

- Goal: Normalize one response or execute_many without losing lineage
- Keywords: `response_to_frame`, `execute_many`, `REQUEST_KEY`, `DATE`
- Identity: `response_shape`
- Authority: 18 § Production Response Normalization from Official Scripts
- Evidence: `official-bquant-app`
- Proven parser / ingest: `official-bquant-app-2026-08-26`
- Do not: assume Arrow results are iterable; concat unlike shapes before normalizing; use this demo helper in place of AIM labeled error-tuples
- Source: `RAG KB/18-using-pandas.md`

## Production Response Normalization from Official Scripts

Repeated across both EQUITY and CREDIT applications in the 2026-08-26 ingest. This section is domain-neutral Pandas glue; it does not authorize any BQL mnemonic or universe signature.

### Normalize one multi-item response

```python
def response_to_frame(response, request_key=None):
    """Convert one BQL response to a value-only, deduplicated DataFrame.

    Index-aligned path (official scripts). If DATE is a **column**
    (Desktop Arrow timeseries), use `item_value_frame` + `merge_item_frames`
    above instead of `frame[[item.name]]`.
    """
    parts = []
    for item in response:
        frame = item.df()
        if item.name in frame.columns:
            frame = frame[[item.name]]
        parts.append(frame)

    if not parts:
        return pd.DataFrame()

    result = pd.concat(parts, axis=1)
    result = result.loc[:, ~result.columns.duplicated()]
    result.index.name = result.index.name or 'ID'
    result = result.reset_index()
    if request_key is not None:
        result['REQUEST_KEY'] = request_key
    return result
```

Why:

- BQL `ID` commonly arrives as the index.
- Concatenating complete `item.df()` frames can duplicate metadata columns.
- A request key is essential when `execute_many` returns one response per date, bond, loan, fund, or issuer.
- **Desktop Arrow:** iterating `for item in response` can fail (`TypeError: not iterable`). Index by `range(len(response))` or `.get(name)`. If that loop never runs, do not treat the object as an `on_request_error` payload.

### Normalize `execute_many` without losing lineage

```python
def responses_to_frame(request_keys, responses):
    frames = []
    for request_key, response in zip(request_keys, responses):
        try:
            frame = response_to_frame(response, request_key=request_key)
        except Exception as exc:
            frame = pd.DataFrame({
                'REQUEST_KEY': [request_key],
                'ERROR': [str(exc)],
            })
        frames.append(frame)
    return pd.concat(frames, ignore_index=True, sort=False)
```

Never assume response order is self-describing. Zip against the request-key sequence and add lineage immediately.

Keep batches economically meaningful and bounded. A screen-photo reconstruction that issues one request for every business day is not a production precedent for Desktop. Prefer rebalance dates, month-end business dates, or explicit user-selected snapshots.

### Separate values from metadata intentionally

Some workflows need attached columns such as normalized rating scale, weights, position type, calculation universe, or observation date. Do not drop all metadata globally.

```python
def keep_available(frame, required=(), optional=()):
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f'Missing required columns: {missing}')
    columns = list(required) + [
        column for column in optional
        if column in frame.columns and column not in required
    ]
    return frame.loc[:, columns]
```

Use a shape contract per request:

```text
required: columns needed for the calculation
optional: useful metadata if returned
lineage: request date / instrument / universe key added locally
errors: retained separately, never interpreted as data
```

### Normalize before combining unlike shapes

Do not directly concatenate:

- time series with static descriptors;
- holder aggregates with fund holding details;
- current curve points with historical snapshots;
- index-member frames from different rebalance dates.

Instead, normalize each shape and join on explicit keys:

```python
prices = prices.sort_values(['ID', 'DATE'])
descriptors = descriptors.drop_duplicates('ID')
result = prices.merge(
    descriptors,
    on='ID',
    how='left',
    validate='many_to_one',
)
```

For dated snapshots:

```python
snapshot['AS_OF_DATE'] = pd.Timestamp(request_date)
snapshots = pd.concat(snapshot_frames, ignore_index=True)
snapshots = snapshots.drop_duplicates(
    subset=['AS_OF_DATE', 'ID'],
    keep='last',
)
```

### Partial failures and empty states

- An empty valid response is not the same as a failed request.
- Preserve request-level errors in an error frame/log.
- Never log a successful `ArrowExecuteResponse` as a request error merely because it is not iterable (`09`).
- Do not fill missing financial observations with zero unless zero has a defined economic meaning.
- Before ratios, replace infinite results and validate denominators.
- Before pivoting, detect duplicate key combinations; choose an explicit aggregation rather than relying on an accidental first row.

```python
ratio = numerator.div(denominator.where(denominator.ne(0)))
ratio = ratio.replace([np.inf, -np.inf], np.nan)
```

### CREDIT-specific shape warning

`holders`, bond curves, cashflows, and securitized scenario outputs frequently include hierarchy/date/scenario columns that do not resemble an equity date × ticker price matrix. Preserve those dimensions until the requested aggregation is explicit.

### EQUITY-specific shape warning

Point-in-time backtests must retain both the rebalance/request date and the security ID. A flat ID-only concat can silently overwrite membership changes or attach current membership to historical signals.

### Equity price history to analytical matrix

Pair, correlation, relative-strength, and technical-monitor workflows repeatedly use the same reshape:

```python
long_prices = price_response.reset_index()
price_matrix = (
    long_prices
    .pivot(index='DATE', columns='ID', values='Price')
    .sort_index()
)
```

Validate duplicate `DATE`/`ID` keys before pivoting. Align/drop missing observations once at the matrix level, then run pair loops locally; do not issue one BQL request per pair.

For factor backtests whose bucket labels become float-like column names after pivoting, inspect the actual columns before calculating the spread:

```python
required = {1.0, 4.0}
if not required.issubset(quartile_returns.columns):
    raise ValueError('Both extreme quartiles are required')
quartile_returns['Q4-Q1'] = (
    quartile_returns[4.0] - quartile_returns[1.0]
)
```

## aim_one_account_positions

- Goal: Current or Projected AIM positions for one account
- Keywords: `AIM`, `position_without_pending`, `pending_position`, `pxnum`, `DEFAULT_PROFILE`
- Identity: `position_quantity`
- Authority: 25 § AIM request shape
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: ts_position(); accounts as a bare string; whole book in one accounts list; move accounts/pxnum onto members()
- Source: `User scripts/ETF Capping Monitoring/etf_capping/data.py`

```python
def _position_item(bq, position_mode: str):
    # Desktop 2026-08-28 IMG_6673/6674, same with_params, no dates.
    # Current: POSITION_WITHOUT_PENDING().VALUE returned the live book.
    # pending_position().value alone returned all zeros; it is the pending
    # component, not Projected. Projected is Current + Pending, which returned
    # the non-zero book in IMG_6674.
    if position_mode == "Current":
        return bq.data.position_without_pending()["value"]
    if position_mode == "Projected":
        return (
            bq.data.position_without_pending()["value"]
            + bq.data.pending_position()["value"]
        )
    raise ValueError("position_mode must be 'Current' or 'Projected'")

def _aim_request(bq, account: str, position_mode: str):
    """Locked AIM request from the 2026-08-28 Desktop tests.

    ``accounts``, ``pxnum=1377``, and ``profile='DEFAULT_PROFILE'`` stay on
    ``with_params``. Do not move them onto ``members()``. Do not add dates.
    Do not substitute ``param`` for ``pxnum``.
    """
    universe = bq.univ.members(type="AIM")
    return bql.Request(
        universe,
        {"Position": _position_item(bq, position_mode)},
        with_params={
            "accounts": [account],
            "pxnum": 1377,
            "profile": "DEFAULT_PROFILE",
        },
    )
```


## execute_many_labeled_lineage

- Goal: Batch BQL requests and keep request lineage when some fail
- Keywords: `execute_many`, `on_request_error`, `labeled_requests`
- Identity: `response_shape`
- Authority: 18 + 25 practice
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: value-only concat that drops ID/DATE; assume every result is a DataFrame
- Source: `User scripts/ETF Capping Monitoring/etf_capping/data.py`

```python
def _execute_many(bq, labeled_requests, item_names, errors):
    if not labeled_requests:
        return []
    responses = list(
        bq.execute_many(
            [request for _, request in labeled_requests],
            on_request_error=_on_request_error,
            num_retries=1,
        )
    )
    parsed = []
    for (label, _request), response in zip(labeled_requests, responses):
        parsed.append((label, _parse_response(response, label, item_names, errors)))
    if len(responses) < len(labeled_requests):
        for label, _request in labeled_requests[len(responses) :]:
            errors.append(f"{label}: execute_many returned no response")
        errors.append(
            f"execute_many returned {len(responses)} responses for "
            f"{len(labeled_requests)} requests"
        )
    elif len(responses) > len(labeled_requests):
        errors.append(
            f"execute_many returned {len(responses)} responses for "
            f"{len(labeled_requests)} requests; extra responses were ignored"
        )
    return parsed
```


## uncached_market_status_descriptors

- Goal: Names plus market_status without Request mode=cached
- Keywords: `market_status`, `6166`, `PR286`, `descriptor`
- Identity: `status_not_price`
- Authority: 08 status codes; runtime 25
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: mode=cached on market_status Request; attach fundamentalticker() or crncy() to this Request
- Source: `User scripts/ETF Capping Monitoring/etf_capping/data.py`

```python
def _fetch_descriptors(
    bq,
    tickers: list[str],
    errors: list[str],
    progress,
) -> pd.DataFrame:
    if not tickers:
        return pd.DataFrame()
    if progress is not None:
        progress(f"Resolving names and market status for {len(tickers)} securities…")
    items = {
        "Name": bq.data.name(),
        "Market Status": bq.data.market_status(),
    }
    # Do not pass Request mode=cached here. Desktop 2026-09-02: cached
    # market_status() returned Delisted for 6166 HK Equity, while the same
    # item without cached, and FLDS BQL PR286, returned Active.
    requests = [
        (
            f"descriptor_{number}",
            bql.Request(batch, items),
        )
        for number, batch in enumerate(_chunks(tickers, SECURITY_BATCH), start=1)
    ]
    frames = [
        frame
        for _, frame in _execute_many(
            bq,
            requests,
            tuple(items),
            errors,
        )
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame()
    descriptors = pd.concat(frames, ignore_index=True, sort=False)
    descriptors = descriptors.rename(columns={"ID": "Ticker"})
    return descriptors.drop_duplicates("Ticker", keep="last")
```


## company_grouping_lineage

- Goal: Company grouping key via fundamentalticker lineage
- Keywords: `fundamentalticker`, `mapby`, `DT110`, `company grouping`
- Identity: `company_grouping`
- Authority: project-etf-capping-monitor.mdc + 08
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: use as Pricing Ticker; cast_parent_equity_ticker(); id_bb_company(); copy Thai/DRSK leftover into a new app without 23/24
- Source: `User scripts/ETF Capping Monitoring/etf_capping/data.py`

```python
def _fetch_fundamental_tickers(
    bq,
    tickers: list[str],
    errors: list[str],
    progress,
) -> pd.DataFrame:
    """Company grouping identity only. HelpDesk DT110/DT679 replacement.

    Official 2026-09-01 tabs confirm ``cast_parent_equity_ticker(mode=null)``
    (CAST parent equity ticker, ID146) and ``id_bb_company(mode=null)``
    (integer company ID, ID035) are not premium. Do not request either here:
    CAST is a parent ticker, and ``id_bb_company()`` is not a yellow key.
    """
    equity_tickers = sorted(
        {
            str(ticker).strip()
            for ticker in tickers
            if classify_asset(ticker) == "Equity"
        }
    )
    if not equity_tickers:
        return pd.DataFrame(columns=["Ticker", "Fundamental Ticker"])
    if progress is not None:
        progress(
            f"Resolving fundamental company mapping for "
            f"{len(equity_tickers)} equities…"
        )
    fundamental_ticker = bq.data.id().value(
        bq.univ.fundamentalticker(),
        mapby="lineage",
    )
    requests = [
        (
            f"fundamental_ticker_{number}",
            bql.Request(
                batch,
                {"Fundamental Ticker": fundamental_ticker},
                with_params={"mode": "cached"},
            ),
        )
        for number, batch in enumerate(
            _chunks(equity_tickers, SECURITY_BATCH),
            start=1,
        )
    ]
    frames = [
        frame
        for _, frame in _execute_many(
            bq,
            requests,
            ("Fundamental Ticker",),
            errors,
        )
        if not frame.empty
    ]
    if not frames:
        return pd.DataFrame(columns=["Ticker", "Fundamental Ticker"])
    mappings = pd.concat(frames, ignore_index=True, sort=False)
    mappings = mappings.rename(columns={"ID": "Ticker"})
    return mappings[["Ticker", "Fundamental Ticker"]].drop_duplicates(
        "Ticker",
        keep="last",
    )
```


## last_price_fill_prev_usd

- Goal: USD last price with holiday fill=prev (Last Close vs Real Time)
- Keywords: `px_last`, `fill=prev`, `Last Close`, `Real Time`
- Identity: `pricing`
- Authority: 25 § Last-price, Last Close, and zero fallback
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: snapshot px_last without dates when history bars are required (see MDX OHLCV card); pass UK header clock into the BQL date
- Source: `User scripts/ETF Capping Monitoring/etf_capping/data.py`

```python
def _price_date(price_type: str, today: date) -> date:
    """Bloomberg as-of date for one runbook pricing rule.

    ``today`` is the live calendar date of the refresh, not the UK UI clock.
    Last Close uses the previous weekday, i.e. through yesterday. Exchange
    holidays on that weekday are not listed here: ``px_last`` ``fill='prev'``
    walks back to the last print as of that date, which may be the session
    before yesterday. Real Time uses ``today`` with the same fill, so a
    holiday or not-yet-printed session still carries the last available
    print. A later engine fallback to zero applies only when that request
    returns no usable last price.
    """
    return _previous_weekday(today) if price_type == "Last Close" else today
```


## yellow_key_asset_classifier

- Goal: Classify holdings from yellow-key suffix (not crncy/security_typ)
- Keywords: `classify_asset`, `Curncy`, `FFX`, `yellow key`
- Identity: `display_or_book_class`
- Authority: 25 § Asset classifier and cash FX
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: crncy(); security_typ()
- Source: `User scripts/ETF Capping Monitoring/etf_capping/engine.py`

```python
def classify_asset(ticker: str) -> str:
    """Match the asset classification in ETF Capping Formula.xlsx."""
    text = _clean_text(ticker)
    if text.endswith(" Curncy"):
        return "FFX" if len(text) > 11 else "Cash"
    if text.endswith(" Index"):
        return "Index Future"
    if text.endswith(" Equity"):
        return "Equity"
    return "Others"
```


## cash_fx_bgnl_invert

- Goal: Cash yellow keys to USD via USD{CCY} BGNL invert
- Keywords: `BGNL`, `Cash`, `USD Curncy`
- Identity: `pricing`
- Authority: 25 § Asset classifier and cash FX
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: USDNAN BGNL Curncy; request FX for USD cash
- Source: `User scripts/ETF Capping Monitoring/etf_capping/data.py`

```python
def _cash_currency_code(ticker) -> str:
    """Return the 3-letter ISO code from a short cash yellow key.

    Only ``USD Curncy`` / ``EUR Curncy`` style tickers qualify. Missing,
    NaN, FFX, or malformed values return '' so the cash FX loop never
    requests ``USDNAN BGNL Curncy``.
    """
    if classify_asset(ticker) != "Cash":
        return ""
    parts = str(ticker).strip().upper().split()
    if len(parts) != 2 or parts[1] != "CURNCY":
        return ""
    code = parts[0]
    if len(code) != 3 or not code.isalpha() or code == "NAN":
        return ""
    return code
```


## index_members_namecn_ohlcv

- Goal: Index members + split NameCN request + daily OHLCV range
- Keywords: `members`, `HSI Index`, `NameCN`, `official_trad_local_lang_sec_nm`, `px_open`, `range('-6m','0d')`
- Identity: `index_members`
- Authority: 26 § Member metadata and NameCN; § Member and benchmark OHLCV
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-08-28c`
- Do not: singular member; id()['WEIGHTS'] (holdings, not members); name_chinese_traditional(); snapshot px_last without dates; ETF Update-only MAIN
- Source: `User scripts/MDX Scan/mdx_scan/data.py`

```python
def fetch_scan_payload(progress=None) -> ScanPayload:
    """Pull live HSI membership + daily OHLCV for members and benchmarks."""
    bq = _require_bql()
    errors: list[str] = []

    def note(message: str) -> None:
        if progress is not None:
            progress(message)

    date_range = bq.func.range(HISTORY_RANGE_START, HISTORY_RANGE_END)
    ohlcv_items = {
        'Open': bq.data.px_open(dates=date_range),
        'High': bq.data.px_high(dates=date_range),
        'Low': bq.data.px_low(dates=date_range),
        'Close': bq.data.px_last(dates=date_range),
        'Volume': bq.data.px_volume(dates=date_range),
    }

    note(f'parser {PARSER_VERSION}: resolving live {HSI_INDEX} members...')
    meta_request = bql.Request(
        bq.univ.members(HSI_INDEX),
        {
            'Name': bq.data.name(),
            'Sector': bq.data.classification_name(),
            'Weight': bq.data.id()['weights'],
        },
        with_params={'mode': 'cached'},
    )
    meta = _parse_response(
        bq.execute(meta_request),
        'members',
        errors,
        item_names=('Name', 'Sector', 'Weight'),
    )
    if not meta.empty:
        meta['ID'] = meta['ID'].astype(str)
        meta = _normalize_weights(meta)
        cn = _parse_response(
            bq.execute(bql.Request(
                bq.univ.members(HSI_INDEX),
                {'NameCN': bq.data.official_trad_local_lang_sec_nm()},
                with_params={'mode': 'cached'},
            )),
            'members_cn',
            errors,
            item_names=('NameCN',),
        )
        if not cn.empty and 'NameCN' in cn.columns:
            cn['ID'] = cn['ID'].astype(str)
            meta = meta.merge(cn[['ID', 'NameCN']].drop_duplicates('ID'), on='ID', how='left')

    member_ids = [] if meta.empty else meta['ID'].drop_duplicates().tolist()
    note(f'HSI members: {len(member_ids)}. Pulling daily OHLCV...')

    labeled_requests = []
    for i, batch in enumerate(_chunks(member_ids, MEMBER_OHLCV_BATCH), start=1):
        labeled_requests.append((
            f'member_ohlcv_{i}',
            bql.Request(batch, ohlcv_items, with_params={'mode': 'cached'}),
        ))
    for ticker in all_bench_tickers():
        labeled_requests.append((
            f'bench::{ticker}',
            bql.Request(ticker, ohlcv_items),
        ))

    ohlcv_parts = []
    if labeled_requests:
        responses = list(
            bq.execute_many(
                [request for _, request in labeled_requests],
                on_request_error=_on_request_error,
                num_retries=1,
            )
        )
        for (label, _request), response in zip(labeled_requests, responses):
            frame = _parse_response(
                response,
                label,
                errors,
                item_names=OHLCV_ITEM_NAMES,
            )
            if frame.empty:
                continue
            frame = frame.copy()
            frame['Bucket'] = 'HSI' if label.startswith('member_ohlcv') else 'BENCH'
            ohlcv_parts.append(frame)

    ohlcv = pd.concat(ohlcv_parts, ignore_index=True, sort=False) if ohlcv_parts else pd.DataFrame()
    if not ohlcv.empty:
        for col in OHLCV_ITEM_NAMES:
            if col in ohlcv.columns:
                ohlcv[col] = pd.to_numeric(ohlcv[col], errors='coerce')
        keys = [c for c in ('ID', 'DATE') if c in ohlcv.columns]
        if 'DATE' not in keys:
            errors.append(f'ohlcv missing DATE; columns={list(ohlcv.columns)}')
        ohlcv = ohlcv.dropna(subset=[c for c in keys + ['Close'] if c in ohlcv.columns])
        ohlcv = ohlcv.drop_duplicates(subset=keys, keep='last') if keys else ohlcv
        ohlcv = ohlcv.sort_values(keys) if keys else ohlcv

    note(
        f'Members={len(member_ids)}  bars={0 if ohlcv.empty else len(ohlcv)}'
        + (f'  notes={len(errors)}' if errors else '')
    )
    return ScanPayload(members=meta, ohlcv=ohlcv, errors=errors)
```


## main_update_only

- Goal: MAIN that displays UI and waits for an Update click before BQL
- Keywords: `Update`, `MAIN.ipynb`, `ETF Capping`
- Identity: `app_lifecycle`
- Authority: 25 § Minimum shippable package
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-09-02d`
- Do not: copy MDX load_on_start into an Update-only app
- Source: `User scripts/ETF Capping Monitoring/MAIN.ipynb`

```python
import sys
from pathlib import Path

from IPython.display import display

ROOT = Path.cwd()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from etf_capping.app import ETFCappingMonitor
from etf_capping.data import PARSER_VERSION

print('ETF Capping parser', PARSER_VERSION)

app = ETFCappingMonitor()
display(app.render())

# Data is loaded only when the user clicks Update.
# Optional: call app.load_on_start() to refresh immediately.
```


## main_load_on_start

- Goal: MAIN that runs one refresh when the kernel starts
- Keywords: `load_on_start`, `MAIN.ipynb`, `MDX`
- Identity: `app_lifecycle`
- Authority: 26 § Minimum shippable package
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-08-28c`
- Do not: copy ETF Update-only MAIN into a scan app
- Source: `User scripts/MDX Scan/MAIN.ipynb`

```python
import sys
from pathlib import Path

from IPython.display import display

ROOT = Path.cwd()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mdx_scan.app import MDXScanApp
from mdx_scan.data import PARSER_VERSION
from mdx_scan.mdx_engine import FORMULA_VERSION

print('MDX parser', PARSER_VERSION, 'formula', FORMULA_VERSION)

app = MDXScanApp()
display(app.render())
app.load_on_start()
```


## futu_formula_pandas_port

- Goal: Port a Futu/TDX daily formula to pandas (not BQL field names)
- Keywords: `PCTB`, `Futu`, `Wilder`, `MDX_futu_formula`
- Identity: `pandas_not_bql`
- Authority: 26 § Pandas signal port
- Evidence: `user-desktop-freeze`
- Proven parser / ingest: `2026-08-28c`
- Do not: search 22 for PCTB/VS/DD60; add a 5-minute or 1-minute scan to this Desktop app
- Pointers: `User scripts/MDX Scan/Source/MDX_futu_formula.txt`, `User scripts/MDX Scan/mdx_scan/mdx_engine.py`, `RAG KB/26-mdx-scan.md`
