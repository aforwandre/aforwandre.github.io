---
topic_id: "16"
title: BQuant Coverage Ledger
role: coverage_ledger
authority_for: [captured_pages, source_gaps, official_script_ledger_summary]
not_authority_for: [implementation_recipes, api_signatures]
evidence_grades: [canonical, gap-uncaptured]
risk_tier: normal
routing_keywords: [coverage, page, source, GAP_REGISTRY, official_scripts]
mandatory_cross_checks: [00-RAG-INDEX]
restricted_sections: []
source_families: [workspace_manifest]
---

# BQuant Coverage Ledger

## Retrieval card

Use this file only to determine whether a Help Center page/source family was
captured, which canonical topic owns it, whether a page body is missing, or
where an official-script pattern was distilled.

Do not use this file as an implementation router. Start every implementation
question at `00-RAG-INDEX.md`.

## Workspace coverage

| Source family | Captured files | Canonical destination |
|---|---:|---|
| Research strategy notebooks | 4 | `10` |
| Event Studies API/modules | 10 | `09` (Beta/non-production) |
| Visualizations/DataGrid/callbacks | 14 | `09` |
| Pandas/Desktop comparison | 11 | `18`, `05` |
| Portfolio Library/API | 15 | `14` |
| Projects/JupyterLab/Assistant | 12 | `05`, `10` |
| Get Data/BQL tutorials | 32 | `01`, `02`, `06`, `08`, `11`, `12`, `14` |
| Help Center examples | 57 | routed domain topics |
| Help Center landing pages | 2 | `05`, this ledger |
| What’s New snapshots | 1 | `21` + affected topics |
| **Total raw HTML** | **158** | `00` routes canonical content |

Coverage means reusable concepts, API constraints, and warnings were
represented. It does not mean every page body, UI chrome, output, or literal
example was copied.

## Official-script coverage

The provenance archive contains **18** projects:

- 13 EQUITY
- 4 CREDIT
- 1 FX

| Domain | Project | Canonical destination |
|---|---|---|
| CREDIT | Asset-backed Security Analysis | `02` securitized recipe; `09` lazy detail |
| CREDIT | BDC Direct Loan Pricer | `02` direct-loan recipe |
| CREDIT | Bond Curves Comparison with History | `02` curve recipe; `09` lazy loading |
| CREDIT | Bond Ownership Dashboard | `02` ownership; `18` request lineage |
| EQUITY | A/H Share Premium Calculator | `01` A/H recipe; `18` DATE alignment |
| EQUITY | Index Performance Drivers, Attribution & Trends | `01` attribution; `09` architecture |
| EQUITY | FCN KI/KO Monitor | `01` barrier lifecycle; `09` file UI |
| EQUITY | Relative Strength Finder | `01` technical/pair analysis |
| EQUITY | Periodic Table Asset Performance Rotation | `01` monitoring composition; `09` grid |
| EQUITY | Participant wise OI dashboard | composition only; ticker list incomplete |
| EQUITY | Equity Futures Basis & Roll | `01` futures composition |
| EQUITY | Cointegration Pairs Trading | `01` pair analytics; `09` drill-down |
| EQUITY | Fundamental Backtester | `01` PIT; `18` lineage |
| EQUITY | BI Thematic Exposure | `01` universe adapter; OCR keys gated |
| EQUITY | Consensus Estimates Revisions | `20` UI shape only; OCR aliases rejected |
| EQUITY | Bespoke Factor Analysis | `09` controller/view/model |
| EQUITY | Multi-Market MA Heatmap & Monitor | `01`/`09` composition; signatures gated |
| FX | Cross Currency Basis Swap Spread | `11` CCBS; `18` response handling |

Exact paths and source types are in
`Official scripts/00-OFFICIAL-SCRIPTS-INDEX.md`.

Official-script rules:

- text-pasted patterns can support `script-verified` composition;
- OCR reconstructions support search/UI composition only;
- unclear mnemonics, parameters, ticker lists, and glue code remain
  `OCR-observed`;
- `fundamentalticker()` lineage is sourced from the captured Company Analysis
  tutorial, not the official-script archive.

## GAP_REGISTRY

These page bodies were not captured. Their neighboring titles do not permit
inference.

| Area | Missing page body | Permitted fallback | Required action |
|---|---|---|---|
| Get Started | About BQuant Desktop; BQuant Quickstart; Management Center; Network Requirements | `05` captured constraints | Request the exact page/source |
| Share Results | Publishing BQuant Apps; Apps overview; App limits; Desktop–Enterprise Compatibility | `15` partial practice | Request the exact page/source |
| Build Analysis | Linking Components Together | `09` callback patterns only | Request the linked page |
| Enterprise | Scheduling; Git; Custom Environments; Sandbox Storage | Desktop hard stop | Do not design for Desktop |

`gap-uncaptured` is a terminal evidence state, not permission to reconstruct
an API from adjacent pages.

## Restricted material

Historical ESG/GHG/climate/sustainable-finance pages are present in the raw
archive and exact data-item catalog, but execution is prohibited. Canonical
topics contain only the stop/incident policy; restricted examples are
non-indexed provenance.

Do not route restricted requests to implementation recipes.

## Catalog coverage

`22-BQuant_DataItems.md` contains 22,513 unique snapshot codes. It is:

- exact-search-only;
- authoritative only for snapshot spelling/existence;
- not an entitlement, semantic, signature, parameter, or universe source;
- outside normal semantic indexing.

Blank descriptions, invalid `*-2()` aliases, and non-data-item APIs require
the handling in `00`, `08`, and `23`.

## Indexing policy

Canonical semantic sources are `00`–`21`, `23`, `24`, and `25`, plus scoped rules.
The following remain explicitly readable but are excluded from default
semantic indexing:

- generated bundle and integrity manifest;
- raw HTML;
- official-script archive;
- restricted-reference archive;
- exact catalog `22`;
- unqualified post-cutoff/model-authored technical-analysis draft.

Do not use `.cursorignore` for these sources because that would block explicit
audit access.

## Maintenance

After changing canonical topics, rules, source counts, or indexing policy:

```shell
python3 "RAG KB/regenerate_kb_bundle.py"
python3 "RAG KB/regenerate_kb_bundle.py" --check
```

The builder must validate this file's 158/18/13/4/1 counts against `00`, the
raw archive, and the official-script ledger.
