---
topic_id: "04"
title: Fixed Income Foundations
role: onboarding_map
authority_for: [fixed_income_learning_path]
not_authority_for: [api_signatures, data_item_semantics]
evidence_grades: [canonical]
risk_tier: normal
routing_keywords: [fixed_income, credit, onboarding, learning]
mandatory_cross_checks: [00-RAG-INDEX, 02-bql-for-fixed-income]
restricted_sections: []
source_families: [workspace_curation]
---

# Developing in BQuant — Fixed Income Foundations

> AI-oriented learning map for fixed-income workflows in CURSOR_BQNT.
> Execution: Bloomberg BQuant only (Python 3.11). Local Cursor is for design and review.

---

## What This Path Covers

Fixed-income BQuant work spans bond universes, spread/yield analytics, index constituent tracking, cashflow aggregation, and credit screening. Start with universe helpers (`bondsuniv`, `members`, `bonds`, `debt`), then layer filters and group-prefix ranking.

```mermaid
flowchart TD
    A[05 Get Started] --> B[06 Get Data / 22 Catalog]
    B --> C[02 BQL for Fixed Income]
    C --> D[12 FI Screening Recipes]
    C --> E[08 Verified FI Fields]
    D --> F{Workflow}
    F -->|Index rebalance| G[02 Index Diff Tracker]
    F -->|Spread monitor| H[11 Sample Notebooks FI snippets]
    F -->|Dashboard| I[15 Share Results]
    G --> J[18 Using Pandas — post-BQL diff]
```

---

## Core Skills Checklist

1. **Universes** — `bondsuniv('Active')`, `members(index)`, `bonds(equity)`, `debt(..., issuedby=...)`.
2. **Spreads & yields** — `spread(spread_type='OAS'|'I')`, `yield_()`; time series with `func.range` + `fill='prev'`.
3. **Filtering** — Multi-condition `.filter()` with rating, maturity, sector, size cutoffs.
4. **Ranking** — `grouprank` for top movers; `groupzscore` for outliers.
5. **Cashflows** — `cashflows()` with `matches` + `between`; group by year/month.
6. **Index ops** — Independent dated pulls; Pandas `isin()` diff; **never** `setdiff()` when weights needed.

---

## Topic File Map

| Topic | File | Use when |
|-------|------|----------|
| FI quickstart | `02-bql-for-fixed-income.md` | Bond queries, filtering, index diff masterpiece |
| FI screening | `12-bql-fixed-income-screening.md` | Production screen recipes + cached mode |
| Verified fields | `08-bql-data-items.md` | `id_sedol1`, weights case, MBS fields |
| Snippet index | `11-sample-notebooks.md` | FI PyBQL copy-paste patterns |
| Pandas post-processing | `18-using-pandas.md` | Set diff, pivot, export |

---

## Critical Safety Rules (Short)

- **Weights:** `bq.univ.members()` → `id()['weights']` (lowercase). `holdings()` → `['WEIGHTS']` (uppercase).
- **Identifiers:** `id_sedol1()['value']`, `id_isin()['value']` — not `id_sedol`.
- **setdiff():** Strips index metadata. Fetch universes separately; diff in Pandas. Full pattern: `02-bql-for-fixed-income.md`.
- **MBS/TBA:** Filter with `security_typ` + `Mtge` ID masks; `na=False` on string filters.
- **Month-end:** Use last business day for index membership dates.

---

## Project Practice Notes

- Local Cursor is for design/authoring only; execute BQL solely inside Bloomberg BQuant (Python 3.11).
- Never invent FI mnemonics — exact-search `22`; use Terminal FLDS only for absent/ambiguous names or unresolved signatures.
- Core FI references: `02-bql-for-fixed-income.md`, `12-bql-fixed-income-screening.md`, `08-bql-data-items.md`, `22-BQuant_DataItems.md`.
- Help Center FI example cards (credit heatmap, TOMS, muni, loans, CDS, curves): `02` / `12`; title catalog in `16`.
- Official Get Data FI family tutorials (Cashflows, Company Analysis, Liquidity, Loans/Munis/CDS, Private Credit, RV, Securitized, TOMS, primary/secondary monitoring): see `02` section **Get Data Official Tutorial: Fixed Income Family**.
