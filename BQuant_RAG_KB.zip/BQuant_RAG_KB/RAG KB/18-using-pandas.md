---
topic_id: "18"
title: Using Pandas with BQL Responses
role: response_shape_authority
authority_for: [Arrow_response_shape, DATE_lineage, execute_many_normalization]
not_authority_for: [data_item_semantics, api_entitlement]
evidence_grades: [practice-derived, script-verified, canonical]
risk_tier: normal
routing_keywords: [pandas, ArrowExecuteResponse, DATE, concat, merge, execute_many]
mandatory_cross_checks: [00-RAG-INDEX, 07-pybql-api-reference, 09-build-analysis]
restricted_sections: []
source_families: [desktop_observation, official_script, help_center]
---

# Using pandas with BQL Responses

> AI-oriented practice reference (Help Center chrome removed).

> **Desktop precedence rule:** the 2026-08-27 Arrow/DATE practice-derived
> contract in this file overrides generic Help Center value-only concat
> snippets whenever `ID` or `DATE` is returned as a column. Official examples
> remain source evidence, but they are not a safe universal parser.

## AI quick map
- `ID` is index; concat value columns only
- Composite group index split → pivot → restore labels
- Merge time series with static fields on `ID`
- Production normalization: preserve execute_many request lineage, shape contracts, partial errors, domain dimensions
- Desktop Arrow: `DATE` may be a column; do not slice `item.df()[item.name]` then `dropna(['DATE'])`

```mermaid
flowchart LR
  R[BQL Response] --> V["item.df()[item.name]"]
  V --> C[pd.concat axis=1]
  C --> P[pivot / isin / merge]
```

## Project Practice Notes: BQL → Pandas Data Flow

### Dictionary Column Renaming

Wrap request items in a dict to rename output columns:

```python
request = bql.Request(universe, {'OAS_Spread': bq.data.spread(spread_type='OAS')})
```

### Metadata Extraction

Calling `bq.data.rating()` also attaches hidden columns such as `NORMALIZED_SCALE` for sorting. Extract with bracket syntax:

```python
rating = bq.data.rating()
normalized = rating['NORMALIZED_SCALE']
```

### Boolean Indexing

```python
high_oas = df[df['OAS_Spread'] > 105]
```

### `.loc[]` Label Selection

```python
subset = df.loc[df['Rating'] == 'BBB', ['Rating', 'OAS_Spread']]  # row filter + column select
value = df.loc['BBB:9.0:0-3', 'OAS_Spread']  # BQL composite index cell
```

### Composite Index Split SOP

Multi-level `.group(by=[...])` yields string indexes such as `A+:6.0:0-3`:

```python
# 1. Split into columns
df[['rating', 'num_rating', 'bin']] = df.index.to_series().str.split(':', expand=True)

# 2. Force numeric type (avoid sort bugs)
df['num_rating'] = pd.to_numeric(df['num_rating'])
```

### Pivot + Label Restore

```python
pivoted = df.pivot(index='num_rating', columns='bin', values='OAS_Spread')

# Map numeric Y-axis (6.0) back to letter rating (A+)
rating_map = df.set_index('num_rating')['rating'].drop_duplicates()
pivoted.index = pivoted.index.map(rating_map)
```

### Aligning Multi-Item Responses

```python
# Prefer value columns only to avoid duplicate metadata columns
# Safe when ID / DATE live in the **index** (classic Response).
df = pd.concat([item.df()[item.name] for item in response], axis=1)

# Drop duplicate columns if present
df = df.loc[:, ~df.columns.duplicated()]
df.index.name = 'ID'  # ID is index, not a column
```

### Desktop Arrow timeseries: keep DATE (practice-derived, 2026-08-27)

On BQuant Desktop, `item.df()` for `px_open` / `px_high` / `px_low` / `px_last` / `px_volume` often has `DATE` as a **column**. The value-only slice above then drops it.

Do not:

```python
frame = item.df()[[item.name]]          # drops DATE if it was a column
pd.concat(parts, axis=1)               # duplicates ID/DATE if they are columns
ohlcv.dropna(subset=['ID', 'DATE', 'Close'])  # KeyError: ['DATE']
```

`str(KeyError(['DATE']))` is `"['DATE']"`. An app header that prints `str(exc)` looks like a column list, not a traceback (`09`).

Keep keys, then merge:

```python
def item_value_frame(item, preferred_name=None):
    frame = item.df().copy()
    if frame.index.name or getattr(frame.index, 'nlevels', 1) > 1:
        frame = frame.reset_index()
    name = preferred_name or item.name
    keep = [c for c in ('ID', 'DATE', name) if c in frame.columns]
    piece = frame.loc[:, keep].copy() if keep else frame
    if 'DATE' in piece.columns:
        piece['DATE'] = pd.to_datetime(piece['DATE'], errors='coerce')
    return piece


def merge_item_frames(frames):
    if not frames:
        return pd.DataFrame()
    keys = ['ID', 'DATE'] if all('DATE' in f.columns for f in frames) else ['ID']
    merged = frames[0]
    for extra in frames[1:]:
        overlap = [c for c in extra.columns if c not in keys]
        merged = merged.merge(extra[keys + overlap], on=keys, how='outer')
    return merged
```

Use index-aligned `concat(axis=1)` only when `ID`/`DATE` are **not** columns. Before `dropna(subset=['DATE'])`, test `'DATE' in frame.columns` and log `columns=...` instead of raising.

`ArrowExecuteResponse` is often not iterable. Do not require `__iter__` to accept a response (`07`, `09`).

### Combining Time Series with Static Fields

```python
df_timeseries = pd.concat([df_px, df_volume], axis=1)
df_final = df_timeseries.merge(df_name, on='ID', how='left')
```

## Production Response Normalization from Official Scripts

Repeated across both EQUITY and CREDIT applications in the 2026-08-26 ingest. This section is domain-neutral Pandas glue; it does not authorize any BQL mnemonic or universe signature.

### Normalize one multi-item response

```python
def response_to_frame(response, request_key=None):
    """Convert one BQL response to a value-only, deduplicated DataFrame.

    Index-aligned path (official scripts). If DATE is a **column**
    (Desktop Arrow timeseries), use `item_value_frame` + `merge_item_frames`
    above instead of `frame[[item.name]]`.
    """
    parts = []
    for item in response:
        frame = item.df()
        if item.name in frame.columns:
            frame = frame[[item.name]]
        parts.append(frame)

    if not parts:
        return pd.DataFrame()

    result = pd.concat(parts, axis=1)
    result = result.loc[:, ~result.columns.duplicated()]
    result.index.name = result.index.name or 'ID'
    result = result.reset_index()
    if request_key is not None:
        result['REQUEST_KEY'] = request_key
    return result
```

Why:

- BQL `ID` commonly arrives as the index.
- Concatenating complete `item.df()` frames can duplicate metadata columns.
- A request key is essential when `execute_many` returns one response per date, bond, loan, fund, or issuer.
- **Desktop Arrow:** iterating `for item in response` can fail (`TypeError: not iterable`). Index by `range(len(response))` or `.get(name)`. If that loop never runs, do not treat the object as an `on_request_error` payload.

### Normalize `execute_many` without losing lineage

```python
def responses_to_frame(request_keys, responses):
    frames = []
    for request_key, response in zip(request_keys, responses):
        try:
            frame = response_to_frame(response, request_key=request_key)
        except Exception as exc:
            frame = pd.DataFrame({
                'REQUEST_KEY': [request_key],
                'ERROR': [str(exc)],
            })
        frames.append(frame)
    return pd.concat(frames, ignore_index=True, sort=False)
```

Never assume response order is self-describing. Zip against the request-key sequence and add lineage immediately.

Keep batches economically meaningful and bounded. A screen-photo reconstruction that issues one request for every business day is not a production precedent for Desktop. Prefer rebalance dates, month-end business dates, or explicit user-selected snapshots.

### Separate values from metadata intentionally

Some workflows need attached columns such as normalized rating scale, weights, position type, calculation universe, or observation date. Do not drop all metadata globally.

```python
def keep_available(frame, required=(), optional=()):
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f'Missing required columns: {missing}')
    columns = list(required) + [
        column for column in optional
        if column in frame.columns and column not in required
    ]
    return frame.loc[:, columns]
```

Use a shape contract per request:

```text
required: columns needed for the calculation
optional: useful metadata if returned
lineage: request date / instrument / universe key added locally
errors: retained separately, never interpreted as data
```

### Normalize before combining unlike shapes

Do not directly concatenate:

- time series with static descriptors;
- holder aggregates with fund holding details;
- current curve points with historical snapshots;
- index-member frames from different rebalance dates.

Instead, normalize each shape and join on explicit keys:

```python
prices = prices.sort_values(['ID', 'DATE'])
descriptors = descriptors.drop_duplicates('ID')
result = prices.merge(
    descriptors,
    on='ID',
    how='left',
    validate='many_to_one',
)
```

For dated snapshots:

```python
snapshot['AS_OF_DATE'] = pd.Timestamp(request_date)
snapshots = pd.concat(snapshot_frames, ignore_index=True)
snapshots = snapshots.drop_duplicates(
    subset=['AS_OF_DATE', 'ID'],
    keep='last',
)
```

### Partial failures and empty states

- An empty valid response is not the same as a failed request.
- Preserve request-level errors in an error frame/log.
- Never log a successful `ArrowExecuteResponse` as a request error merely because it is not iterable (`09`).
- Do not fill missing financial observations with zero unless zero has a defined economic meaning.
- Before ratios, replace infinite results and validate denominators.
- Before pivoting, detect duplicate key combinations; choose an explicit aggregation rather than relying on an accidental first row.

```python
ratio = numerator.div(denominator.where(denominator.ne(0)))
ratio = ratio.replace([np.inf, -np.inf], np.nan)
```

### CREDIT-specific shape warning

`holders`, bond curves, cashflows, and securitized scenario outputs frequently include hierarchy/date/scenario columns that do not resemble an equity date × ticker price matrix. Preserve those dimensions until the requested aggregation is explicit.

### EQUITY-specific shape warning

Point-in-time backtests must retain both the rebalance/request date and the security ID. A flat ID-only concat can silently overwrite membership changes or attach current membership to historical signals.

### Equity price history to analytical matrix

Pair, correlation, relative-strength, and technical-monitor workflows repeatedly use the same reshape:

```python
long_prices = price_response.reset_index()
price_matrix = (
    long_prices
    .pivot(index='DATE', columns='ID', values='Price')
    .sort_index()
)
```

Validate duplicate `DATE`/`ID` keys before pivoting. Align/drop missing observations once at the matrix level, then run pair loops locally; do not issue one BQL request per pair.

For factor backtests whose bucket labels become float-like column names after pivoting, inspect the actual columns before calculating the spread:

```python
required = {1.0, 4.0}
if not required.issubset(quartile_returns.columns):
    raise ValueError('Both extreme quartiles are required')
quartile_returns['Q4-Q1'] = (
    quartile_returns[4.0] - quartile_returns[1.0]
)
```

## Get Data Official Tutorial: Aligning Responses

Supplement to pandas response handling.

```mermaid
flowchart LR
  A["Aligning Responses"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### Aligning and Merging BQL Responses
- When you query data from BQL, the results are returned as a bql.Response object that contains one or more bql.SingleItemResponse objects. You can then call bql.SingleItemResponse.df() to get the data as a pandas DataFrame.
- **Topics:** Overview; Single data item; Inspecting a DataFrame’s shape; Multiple data items of the same shape; Cleaning up your data; Multiple data items with different shapes
- **APIs:** `bq.data.name`, `bq.data.px_last`, `bq.data.px_volume`, `bq.func.range`

```python
import bql, pandas as pd
bq = bql.Service()

universe = ["IBM US Equity", "VOD LN Equity"]

# retrieve price and volume time-series data from the past week
data_items = {
      "px": bq.data.px_last(dates=bq.func.range("-1w", "0d")),
      "volume": bq.data.px_volume(dates=bq.func.range("-1w", "0d"))
}
request = bql.Request(universe, data_items)
response = bq.execute(request)

# get price data
df_px = response[0].df()

# get volume data
df_volume = response[1].df()

# confirm that both DataFrames share the same index
if (df_px.index.equals(df_volume.index)):
    print("DataFrames share the same index and can be combined.")

df_combined = pd.concat([df_px, df_volume], axis=1)
df_combined.head()
```


## Build Analysis Official: Using pandas in BQuant

Official pandas-in-BQuant chapters (Help Center). Keep BQL ID-as-index and concat patterns from practice notes below/above.

```mermaid
flowchart LR
  R[BQL Response] --> DF[DataFrame]
  DF --> C[Clean/Select/Sort]
  C --> J[Combine/Reshape]
  J --> G[Group/Transform]
```

### Using pandas in BQuant
- These set of examples demonstrate some of the most common methods and how they can be utilized in a BQuant context, typically by applying them to a DataFrame containing Bloomberg data retrieved using BQL.
- **Topics:** Quickstart: Using pandas in BQuant; Open an interactive version; See also¶
- **Key points:**
  - Indexing Operations
  - Grouping and Aggregating Data
  - Transforming Data

### Understanding Your Data
- Setting up your environment Understanding pandas objects pd.DataFrame() pd.Series() Foundational methods head()/tail() - Returning first and last rows describe() - Generating summary statistics isna()/notna() - Identifying missing data value_counts() - Counting distinct values
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Understanding pandas objects¶; pd.DataFrame()¶; pd.Series()¶; Foundational methods¶; head()/tail() - Returning first and last rows¶
- **Key points:**
  - Understanding pandas objects pd.DataFrame()
  - Foundational methods head()/tail() - Returning first and last rows
  - describe() - Generating summary statistics
  - isna()/notna() - Identifying missing data
  - value_counts() - Counting distinct values
  - Rows and columns
  - An index (row labels)
  - Each row represents a date observation for IBM.

```python
# Define the universe, a single security
universe = 'IBM US Equity'

# Define the target data, a time series of end-of-day prices for the last year
data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-1y', '0d'))
}

# Create the BQL request
request = bql.Request(universe, data_item)

# Execute the request
response = bq.execute(request)

# Turn the first and only item in the response into DataFrame
df_raw = response[0].df()

# Display the DataFrame
df_raw
```

```python
universe = bq.univ.members('B500 Index')

data_item = {'Sector': bq.data.gics_sector_name()}

request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()

# Display first five rows
df.head()
```

### Indexing Operations
- Setting up your environment Foundational methods reset_index() - Turning the index into a column set_index() - Setting a column as the index reindex() - Aligning the DataFrame to a new index Going further MultiIndex operations get_level_values() - Retrieving values from a specific index level droplevel() - Removing one level from a MultiIndex unsta
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; reset_index() - Turning the index into a column¶; set_index() - Setting a column as the index¶; reindex() - Aligning the DataFrame to a new index¶; Going further¶
- **Key points:**
  - Foundational methods reset_index() - Turning the index into a column
  - set_index() - Setting a column as the index
  - reindex() - Aligning the DataFrame to a new index
  - Going further MultiIndex operations get_level_values() - Retrieving values from a specific index level
  - droplevel() - Removing one level from a MultiIndex
  - unstack() - Moving an index level into columns
  - stack() - Moving column labels into the index

```python
# Define the universe - members of the B500 Index
universe = bq.univ.members('B500 Index')

# Define name and price data items
data_item = {
    'Name': bq.data.name(),
    'Price': bq.data.px_last(fill='prev')
}

# Create the BQL request
request = bql.Request(universe, data_item)

# Execute the request
response = bq.execute(request)

# Convert the two responses into DataFrames and concatenate them
df_raw = pd.concat(
    [item.df()[item.name] for item in response],
    axis=1,
)

# Preview data
df_raw.head()
```

```python
# Define the universe 
universe = ['AAPL US Equity', 'MSFT US Equity']

# Define name and price data items
data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-4d','0d'), fill='prev')
}

# Create the BQL request
request = bql.Request(universe, data_item)

# Execute the request
response = bq.execute(request)

# Turn first and only item in the response into DataFrame
df_raw = response[0].df()

# Preview data
df_raw.head()
```

### Cleaning Data
- Setting up your environment Foundational methods dropna() - Removing missing values fillna() - Replacing missing values replace() - Replacing specific values drop_duplicates() - Removing duplicate rows
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; dropna() - Removing missing values¶; fillna() - Replacing missing values¶; replace() - Replacing specific values¶; drop_duplicates() - Removing duplicate rows¶
- **Key points:**
  - Foundational methods dropna() - Removing missing values
  - fillna() - Replacing missing values
  - replace() - Replacing specific values
  - drop_duplicates() - Removing duplicate rows

```python
# Define the universe
universe = bq.univ.members('B2000 Index').filter(bq.data.is_eps() >= 0)

# Calculate Price / EPS ratio
data_item = {
    'Price / EPS': bq.data.px_last() / bq.data.is_eps()
}

# Create the BQL request
request = bql.Request(universe, data_item)

# Execute the request
response = bq.execute(request)

# Convert response to a DataFrame and sort
df_raw = response[0].df().sort_values('Price / EPS')

# Preview data
df_raw
```

## Advanced pandas mini-recipes (official chapter backstop)

Use these after converting BQL responses to DataFrames. BQL `ID` starts as an index; reset it only when a column-based operation requires it.

### Index and MultiIndex

```python
# Index ↔ columns
flat = df_raw.reset_index()
indexed = flat.set_index(["ID", "DATE"]).sort_index()

# Read/drop/rearrange levels
ids = indexed.index.get_level_values("ID")
date_only = indexed.droplevel("ID")
wide = indexed["Price"].unstack("ID")
long = wide.stack().rename("Price").to_frame()

# Align to a required index
aligned = wide.reindex(required_dates)
```

### Clean, select, and sort

```python
clean = (
    df_raw
    .fillna({"Sector": "Unknown"})
    .replace({"Sector": {"N/A": "Unknown"}})
    .drop_duplicates()
)

selected = clean.where(clean["Price"] > 0)
masked = clean.mask(clean["Price"] <= 0)
top = clean.sort_index().nlargest(10, "Market Cap")
bottom = clean.nsmallest(10, "Market Cap")
```

### Time-series nearest join

```python
# Both sides must be sorted by the merge key.
left = trades.sort_values("DATE")
right = reference.sort_values("DATE")

joined = pd.merge_asof(
    left,
    right,
    on="DATE",
    by="ID",
    direction="backward",
)
```

### Reshape and grouped calculations

```python
long = df_wide.reset_index().melt(
    id_vars=["ID"],
    var_name="Metric",
    value_name="Value",
)

sector_weighted = df_raw.groupby("Sector").apply(
    lambda group: (
        group["Total Return"] * group["Market Cap"]
    ).sum() / group["Market Cap"].sum()
)

df_raw["Sector Mean"] = (
    df_raw.groupby("Sector")["Total Return"].transform("mean")
)
```

```python
universe = 'IBM US Equity'

# Time series of end-of-day prices over the 10 days
data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-10d', '0d'))
}

# Create the BQL request
request = bql.Request(universe, data_item)

# Execute the request
response = bq.execute(request)

# Turn first and only item in the response into DataFrame
df_raw = response[0].df()

# Preview data
df_raw
```

### Selecting Data
- Setting up your environment Foundational methods head()/tail() - Returning first and last rows loc()/iloc() - Label/position-based indexing isna()/notna() - Filtering missing data Going further where()/mask() - Conditional filtering
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; head()/tail() - Returning first and last rows¶; loc()/iloc() - Label/position-based indexing¶; isna()/notna() - Filtering missing data¶; Going further¶
- **Key points:**
  - Foundational methods head()/tail() - Returning first and last rows
  - loc()/iloc() - Label/position-based indexing
  - isna()/notna() - Filtering missing data
  - Going further where()/mask() - Conditional filtering
  - isna() returns True where values are missing (NaN).
  - notna() returns True where values are present.

```python
universe = 'IBM US Equity'

# Time series of end-of-day prices over the last year
data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-1y', '0d'))
}

# Create the BQL request, ensuring the PERIOD column is included
request = bql.Request(universe, data_item)

# Execute the request
response = bq.execute(request)

# Turn first and only item in the response into DataFrame
df_raw = response[0].df()

df_raw
```

```python
# Define the target universe
universe = 'NVDA US Equity'

# Define the target data
data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-20d', '0d'))
}

# Build and execute the BQL query
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Convert the response to a DataFrame
df_raw = response[0].df()

# Display the DataFrame
df_raw
```

### Sorting Data
- Setting up your environment Foundational methods sort_values() - Sorting by column values sort_index() - Sorting by index labels nlargest() - Selecting the largest values nsmallest() - Selecting the smallest values
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; sort_values() - Sorting by column values¶; sort_index() - Sorting by index labels¶; nlargest() - Selecting the largest values¶; nsmallest() - Selecting the smallest values¶
- **Key points:**
  - Foundational methods sort_values() - Sorting by column values
  - sort_index() - Sorting by index labels
  - nlargest() - Selecting the largest values
  - nsmallest() - Selecting the smallest values

```python
# Define the target universe
universe = bq.univ.members("B500 Index")

# Define the target data
data_item = {
    "Market Cap": bq.data.cur_mkt_cap(),
    "Sector": bq.data.gics_sector_name()
}

# Build and execute the BQL query
request = bql.Request(universe, data_item)
response = bq.execute(request)

# Use pandas to concatenate all the returned data items into a 
# single DataFrame
df_raw = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

# Display the first five rows 
df_raw.head()
```

```python
# Import required libraries
import pandas as pd
import bql

# Connect to BQL
bq = bql.Service()
```

### Combining Data
- Setting up your environment Foundational methods pd.concat() - Stacking DataFrames vertically/horizontally join()/merge() - SQL-like joins Going further merge_asof() - Nearest-match merging for time series
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; pd.concat() - Stacking DataFrames vertically/horizontally¶; join()/merge() - SQL-like joins¶; Going further¶; merge_asof() - Nearest-match merging for time series¶
- **Key points:**
  - Foundational methods pd.concat() - Stacking DataFrames vertically/horizontally
  - join()/merge() - SQL-like joins
  - Going further merge_asof() - Nearest-match merging for time series

```python
# Get price and volume data for IBM
universe = 'IBM US Equity'

params = {
    'dates': bq.func.range('-5d', '0d'),
    'fill': 'prev'
}

data_items = {
    'Price': bq.data.px_last(**params),
    'Volume': bq.data.px_volume(**params)
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

# Extract responses into seperate DataFrames
df_price = response[0].df()
df_volume = response[1].df()
```

```python
# Get market data for a different universe from BQL
universe = bq.univ.members('B500 Index').fundamentalticker()

data_items = {
    'Price': bq.data.px_last(),
    'Market_Cap': bq.data.cur_mkt_cap()
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

df_market = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)
df_market.head()
```

### Reshaping Data
- Setting up your environment Foundational methods pivot() - Reshape from long to wide format Going further melt() - Reshape from wide to long format
- **Topics:** Reshaping data; Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; pivot() - Reshape from long to wide format¶; Going further¶; melt() - Reshape from wide to long format¶
- **Key points:**
  - Foundational methods pivot() - Reshape from long to wide format
  - Going further melt() - Reshape from wide to long format

```python
# Get multiple financial metrics for a few securities (wide format)
universe = ['IBM US Equity', 'AAPL US Equity', 'MSFT US Equity']

data_items = {
    'Price': bq.data.px_last(),
    'Volume': bq.data.px_volume(),
    'Market_Cap': bq.data.cur_mkt_cap()
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

# Combine all data items into one DataFrame
df_wide = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)
df_wide
```

```python
# Get price data for multiple securities
universe = ['IBM US Equity', 'AAPL US Equity', 'MSFT US Equity']

data_item = {
    'Price': bq.data.px_last(dates=bq.func.range('-10d', '0d'))
}

request = bql.Request(universe, data_item)
response = bq.execute(request)

# Concatenate all securities into one DataFrame
df_raw = pd.concat([item.df() for item in response])
df_raw = df_raw.reset_index()

# Display first 10 rows
df_raw.head(10)
```

### Grouping and Aggregating Data
- Some of these operations can also be performed within BQL directly. The recommended approach varies by use case.
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; groupby() - Aggregating by columns¶; std()/median()/describe() - Statistical aggregations¶; groupby() with agg() - Multiple aggregations¶; Going further¶
- **Key points:**
  - Foundational methods groupby() - Aggregating by columns
  - std()/median()/describe() - Statistical aggregations
  - groupby() with agg() - Multiple aggregations
  - Going further groupby() with apply() - Applying custom functions
  - transform() - Broadcasting group calculations

```python
# Get data for B500 Index constituents
universe = bq.univ.members('B500 Index')

data_items = {
    'Sector': bq.data.gics_sector_name(),
    'Country': bq.data.country_full_name(),
    'Price': bq.data.px_last(),
    'PE Ratio': bq.data.pe_ratio(), 
    'Market Cap': bq.data.cur_mkt_cap(),
    'Volume': bq.data.px_volume(), 
    'Total Return': bq.data.total_return()
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

# Combine into a DataFrame
df_raw = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df_raw.head(10)
```

```python
# Get data for B500 Index constituents
universe = bq.univ.members('B500 Index')

data_items = {
    'Sector': bq.data.gics_sector_name(),
    'Market Cap': bq.data.cur_mkt_cap(),
    'Total Return': bq.data.total_return()
}

request = bql.Request(universe, data_items)
response = bq.execute(request)

# Combine into a DataFrame
df_raw = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df_raw.groupby('Sector').apply(
  lambda g: np.average(
      g['Total Return'],
      weights=g['Market Cap']
  )
)
```

### Transforming Data
- Setting up your environment Foundational methods astype() - Casting a specific type rename() - Renaming columns shift() - Comparing current and previous values Going further apply() - Applying custom functions transform() - Applying functions preserving shape map() - Applying functions elementwise
- **Topics:** Open an interactive version; Table of contents¶; Setting up your environment¶; Foundational methods¶; astype() - Casting a specific type¶; rename() - Renaming columns¶; shift() - Comparing current and previous values¶; Going further¶
- **Key points:**
  - Foundational methods astype() - Casting a specific type
  - rename() - Renaming columns
  - shift() - Comparing current and previous values
  - Going further apply() - Applying custom functions
  - transform() - Applying functions preserving shape
  - map() - Applying functions elementwise

```python
def weighted_avg(group):
    """Returns a weighted average EPS per group."""
    return (group['PE Ratio'] * group['Weight']).sum() / group['Weight'].sum()

# Pass the function into apply
df_raw.groupby('Sector').apply(weighted_avg)
```

```python
universe = 'IBM US Equity'

# Time series of annual sales from 2020-2024
data_item = {
    'Sales': bq.data.sales_rev_turn(
        fa_period_reference=bq.func.range('2020', '2024'),
        fa_period_type='A'
    )
}

# Create the BQL request, ensuring the PERIOD column is included
request = bql.Request(
    universe, 
    data_item, 
    preferences={'addcols': 'PERIOD'}
)

# Execute the request
response = bq.execute(request)

# Turn first and only item in the response into DataFrame
df_raw = response[0].df()

df_raw
```

