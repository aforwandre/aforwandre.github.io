---
topic_id: "24"
title: ETF Field Migration Incident and Prevention
role: incident_case_study
authority_for:
  - etf_mapping_incident
  - thai_foreign_line_business_rule
  - substitution_regressions
not_authority_for:
  - general_api_signatures
  - data_item_entitlement_catalog
evidence_grades:
  - user-confirmed
  - practice-derived
risk_tier: high
routing_keywords:
  - GHG
  - fundamentalticker
  - Thai
  - /F
  - N-NDVR
  - DRSK
  - CAST
  - DT110
  - DT679
mandatory_cross_checks:
  - 23-bql-substitution-due-diligence
  - 08-bql-data-items
  - 25-etf-capping-monitor
  - project-etf-capping-monitor
restricted_sections: []
source_families:
  - user_conversation
  - helpdesk
  - excel
  - desktop_observation
---

# ETF Field Migration Incident and Prevention

## Retrieval card

Use this case when converting Excel/API fields, selecting a company/listing
mapping, handling Thai `/F TB Equity` or N-NDVR (`-R TB Equity`), or
evaluating a field that returns a convenient ticker from an unrelated product
family.

This is dated user-confirmed/practice-derived evidence. It documents what
failed and why. General BQL signatures still require their normal authorities.

## Incident summary

During migration of the ETF Capping workbook to BQuant, a company-mapping
requirement was initially solved with a GHG-related ticker field. The user
later supplied Bloomberg HelpDesk evidence that:

- bulk ESG/GHG extraction requires Premium entitlement and can trigger
  Bloomberg account suspension;
- DT110 (`FUNDAMENTAL_TICKER`) and DT679 (`ISSUER_EQUITY_TICKER`) return the
  same content for this use case; and
- the supported BQL approach is the `bq.univ.fundamentalticker()` lineage
  pattern already present in the captured Company Analysis tutorial.

The failure was not a missing-corpus problem. It was a retrieval failure:
searching the data-item catalog for a ticker-shaped proxy before searching the
official tutorial for the business intent.

## Business requirement

The monitor has separate identity layers:

| Layer | ETF requirement |
|---|---|
| AIM position | Preserve the exact account ticker and quantity |
| Company capping group | Exception override, then canonical fundamental company mapping |
| Thai price | Use the corresponding active local Thai listing only |
| Display/status | Show AIM identity; show local Pricing Ticker/status separately |

For Thai foreign-line stocks, the fund is permitted to hold only the foreign
line. That line is illiquid: when a trade occurs its price aligns with the
local line, but otherwise its last price can remain stale while the liquid
local line moves. Therefore:

- the `/F TB Equity` or `-R TB Equity` AIM ticker and quantity must remain
  unchanged;
- the foreign-line historical price must not be used for daily market value;
- only the verified local `TB Equity` listing supplies the daily price;
- an unresolved local mapping must fail closed rather than fall back to the
  sparse foreign-line price.

This pricing policy is a dated business override to the workbook's literal
original-ticker price formula.

On 2026-09-01 the user confirmed that N-NDVR AIM tickers end in
`-R TB Equity` and follow the same local-price hierarchy as `/F`, including
leftover HelpDesk-confirmed `bb_default_risk_obligor_ticker()` after override
and strip fail.

## Failure chain

### 1. API/BQL namespace confusion

An Excel or FLDS API mnemonic was treated as if it could be translated
mechanically into `bq.data.*`. BQuant uses BQL/PyBQL items and universe
functions. An API-only field does not become BQL through naming similarity or
CDE.

### 2. Catalog-first proxy selection

The search looked for data items whose descriptions contained company,
parent, coverage, or ticker terms. Catalog existence was treated as semantic
approval. This bypassed the official Company Analysis pattern:

```python
fundamental_ticker = bq.data.id().value(
    bq.univ.fundamentalticker(),
    mapby="lineage",
)
```

The universe function is not validated by the data-item catalog. The catalog
also contains a similarly named data item, which is not evidence of
equivalence.

### 3. Restricted GHG proxy

A GHG coverage ticker happened to return a useful company ticker and was used
as a mapping proxy. That crossed into a restricted Premium product family and
caused account-suspension risk. Convenient output did not make the field
semantically or operationally safe.

### 4. Default-risk obligor as Thai listing map

A default-risk obligor ticker can return local Thai-looking values. Its native
semantics are obligor/credit-risk identity, not foreign-board-to-local listing
conversion. Catalog spelling is not authorization. Mixed-universe DRSK, then
Pandas filtering, remains a hard reject because the sensitive request has
already been sent for every security.

On 2026-09-01 the user supplied HelpDesk confirmation that
`bb_default_risk_obligor_ticker()` is usable in this app as a leftover
pricing mapper only: after approved override and validated `/F`/`-R` strip
fail, request it only for remaining Thai `/F` and `-R` AIM tickers, accept
only a cleaned local `TB Equity`, and keep DRSK output as Pricing Ticker
identity. That guarded path does not authorize DRSK as a company key, mixed
universe, or HK/US mapper.

### 5. CAST parent as Thai listing map

CAST was proposed as a lower-risk replacement. Official BQL tab 2026-09-01
(IMG_6675) confirms `cast_parent_equity_ticker(mode=null)` is the CAST parent
equity ticker (`ID146`), not a premium field. `DELTA/F TB Equity` still showed
the semantic failure: CAST returned the Taiwanese parent, not the Thai local
listing. Multiplying the Thai position quantity by that parent's price would
be a silent wrong-company/wrong-market valuation. Entitlement does not change
that identity mismatch.

Official `id_bb_company(mode=null)` (IMG_6676–6678, `ID035`) returns an
integer company identifier (`AAPL US Equity` → `101695`). That is not a
yellow-key Pricing Ticker and is not the HelpDesk DT110/DT679 replacement.

### 6. Filtering after a broad request

One proposed pattern requested the obligor field for a mixed regional
universe, then used Pandas to keep Thai rows. The sensitive request had already
been sent for every security. Post-request filtering cannot reduce Bloomberg
request scope.

### 7. Fundamental ticker used as price

An intermediate implementation accepted an already-local-looking fundamental
ticker as the Pricing Ticker. This was removed. Fundamental mapping is
company-level evidence; the corpus does not prove that its output is the
correct tradable Thai local listing.

## Rejected alternatives

| Candidate | Why rejected |
|---|---|
| ESG/GHG coverage ticker | Restricted product family; wrong proxy purpose |
| Default-risk obligor ticker as mixed-universe or company mapper | Credit-risk identity; entitlement family; not listing semantics; post-filter does not shrink the request |
| Default-risk leftover after HelpDesk (guarded) | Allowed only for leftover Thai `/F` and `-R` pricing identity; still reject mixed universe and company-key use |
| CAST parent/equity ticker | Official CAST parent ticker (ID146); can return a foreign parent rather than Thai local line; not premium, still wrong identity |
| `id_bb_company()` as mapper | Official integer company ID (ID035); not a yellow-key listing or Pricing Ticker |
| Fundamental ticker as Pricing Ticker | Company/grouping granularity, not listing proof |
| General `listings()` guess | Catalog existence without resolved shape/selection recipe |
| Mixed-universe request then Pandas filter | Does not narrow the request sent to Bloomberg |
| Foreign-line price fallback | Violates the business requirement and can be materially stale |

## Correct architecture

### Required valuation order

1. Preserve the exact AIM position ticker and quantity.
2. Resolve the approved Pricing Ticker for that held security.
3. Calculate each position's USD market value and security-level weight.
4. Attach the separate company/grouping key.
5. Sum the already-calculated position values/weights by company only for the
   final capping comparison.

A parent/fundamental ticker must never replace a subsidiary/listing ticker,
quantity, or price. Different legal securities can have different prices and
conversion ratios even when they share one company key.

### Company grouping

1. Apply hard business Exception overrides.
2. Use
   `bq.data.id().value(bq.univ.fundamentalticker(), mapby="lineage")`.
3. Fall back to the original AIM ticker when company mapping is not
   applicable, with a diagnostic where required.

Runbook `Level` remains display information because HelpDesk confirmed DT110
and DT679 content is the same for this use case.

### Thai pricing

1. Detect original AIM tickers ending `/F TB Equity` or `-R TB Equity`.
2. Preserve original ticker and quantity.
3. Build local candidates before BQL:
   - reviewed `THAI_PRICING_RULES` override first;
   - otherwise remove the terminal `/F` or `-R` marker deterministically.
4. Fetch ordinary descriptors, market status, and company mapping for original
   and candidate IDs in one batched cache.
5. Accept a strip/override candidate only if:
   - it ends in `TB Equity`;
   - it contains no `/F` and is not itself a `-R` line;
   - it returns `Name` or `Market Status`; and
   - original and candidate have the same non-empty company-level fundamental
     mapping.
6. For leftover unresolved Thai foreign lines only, request
   `bb_default_risk_obligor_ticker()`, fetch reference data for any new local
   IDs, and accept a cleaned local `TB Equity` with `Name` or `Market Status`.
   Label the source `HelpDesk DRSK`. This is Pricing Ticker identity only.
7. Use the accepted local ticker only for price and pricing status.
8. If still unresolved, leave Pricing Ticker empty, emit a structured
   diagnostic, and do not request the foreign-line price.

Known reviewed non-mechanical override:

```text
CPNREI/F TB Equity -> CPNREIT TB Equity
```

Simple removal would create the invalid candidate `CPNREI TB Equity`.

### N-NDVR Thai pricing extension

- Preserve the exact `-R TB Equity` AIM ticker and quantity.
- Use a reviewed local Thai Pricing Ticker before calculating position MV and
  Weight: override, validated `-R` strip, then leftover HelpDesk DRSK.
- Do not reuse the N-NDVR line's sparse price.
- Do not treat DRSK, CAST, or the company key as the held position identity.

### Market status

- Preserve the AIM ticker's status for position display.
- Runtime last-price, Last Close as-of date, holiday fill, and sibling-weight
  zero fallback are owned by `25`. This incident file must not carry a second
  copy of that recipe.
- Cached `market_status()` is a field trap in `08` (`6166 HK Equity`).
- An unresolved Thai mapping has no approved pricing status and remains a
  missing-price/data-quality case.

## Prevention gates

- `P1` — Route Excel/API migration to `23` before catalog search.
- `P2` — Search official tutorials for the business intent.
- `P3` — Distinguish data items from universe functions.
- `P4` — Treat catalog presence as spelling evidence only.
- `P5` — Reject restricted and cross-product proxy fields.
- `P6` — Separate position, grouping, issuer, and pricing identities.
- `P7` — Pre-filter a sensitive/narrow universe before creating a request;
  post-request Pandas filtering does not count.
- `P8` — Reassess every user/AI-proposed alternative independently.
- `P9` — Preserve reviewed non-mechanical overrides.
- `P10` — Define fail-closed behavior and regression guards before coding.

## Regression checklist

- [ ] No production Python contains ESG/GHG data-item calls.
- [ ] No Thai pricing path calls CAST parent or `id_bb_company()`.
- [ ] DRSK is requested only for leftover Thai `/F` and `-R` AIM tickers.
- [ ] Original `/F TB Equity` and `-R TB Equity` ticker and quantity survive
      calculation.
- [ ] Every non-Thai position MV uses its own held ticker's approved price;
      parent/fundamental mapping is attached only after position Weight.
- [ ] Position `Weight` remains security-level and is not overwritten by
      company aggregate weight.
- [ ] Pricing Ticker always ends `TB Equity` and contains no `/F` or leftover
      `-R`.
- [ ] `CPNREI/F TB Equity` maps only to the reviewed `CPNREIT TB Equity`.
- [ ] A normal strip candidate requires ordinary local reference evidence and
      same-company validation.
- [ ] Fundamental mapping is never assigned directly as Pricing Ticker.
- [ ] Unresolved mapping does not request or reuse the foreign-line price.
- [ ] Local Pricing Ticker `px_last(..., fill="prev")` is requested even for
      official empty-market statuses; numeric last-price and Last Close
      fallback checks live in `25`.
- [ ] Original, strip-candidate, and leftover DRSK local IDs use batched
      caches.
- [ ] BQL requests remain narrow and Desktop-safe.
- [ ] Production `bq.data.*` and `bq.univ.*` calls match the reviewed project
      allowlist; any new call fails static validation pending due diligence.

## Workbook parity boundaries

The incident resolution does not silently settle other workbook/app policy
differences:

- direct USD pricing versus local price plus FX;
- previous-value fill versus row-level zero/error behavior;
- account-level Data Issue versus row-level zero;
- Exception-key construction.

Last-price fill, Account Incomplete paint, BGNL cash FX invert, and
grouped-company Rank / Dynamic Limit are frozen in `25`. Do not re-open
them here. Remaining Exception-key construction still needs the live
`config.py` override table plus `23` if the key rule changes.

## Evidence provenance

- User conversation and Bloomberg HelpDesk statements supplied on 2026-08-31
  and 2026-09-01.
- User-confirmed ETF Capping workbook and Desktop observations, including the
  2026-08-28 AIM tests (IMG_6673/6674: Current, pending-alone zeros, Current
  plus Pending as Projected, BGNL `px_last`) and the official DRSK BQL tab
  (IMG_6671) plus Desktop obligor-ticker execute (IMG_6672). Official CAST
  parent and `id_bb_company` BQL tabs (IMG_6675–6678) confirm those items are
  not premium; they remain unused as Thai price or Company Key.
- Adjacent Cursor conversation export:
  `cursor_bquant_bql_field_options.txt` (exported 2026-08-31).
- Captured official Company Analysis pattern in
  `02-bql-for-fixed-income.md`.
- Current ETF Capping project implementation and pure-Pandas tests.

This case supersedes earlier chat recommendations that treated GHG, CAST
parent, or a fundamental company ticker as local-listing shortcuts. Mixed-universe
DRSK remains rejected. Leftover Thai `/F`/`-R` DRSK is a dated HelpDesk-guarded
pricing exception, not a general listing proxy.
