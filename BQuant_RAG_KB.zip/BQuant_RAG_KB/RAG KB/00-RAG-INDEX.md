---
corpus_mode: closed-world
official_corpus_cutoff: 2026-07-25
local_user_evidence_through: 2026-10-24
retrieval_mode: destination-first
canonical_markdown_sources: 30
raw_html_sources: 158
data_items_extract_date: 2026-07-25
data_items_count: 22513
official_script_projects: 18
official_script_equity: 13
official_script_credit: 4
official_script_fx: 1
generated_bundle: RAG KB/BQUANT_RAG_KNOWLEDGE_BASE.md
generated_manifest: RAG KB/RAG_KB_MANIFEST.json
bundle_builder: RAG KB/regenerate_kb_bundle.py
catalog_policy: exact-search-only
high_risk_global_scan: detour-only
navigation_mode: destination-first
---

# 00 — BQuant Closed-World Navigator

> For a **named destination**, read **§ 2 only**, then the one route card.
> Do not read the rest of this file. The atlas (§ 3–§ 14) is for questions
> that are not a named Desktop app.

Hard constraints: `.cursor/rules/00-bquant-hard-stops.mdc`.
Detours (new BQL): `.cursor/rules/02-bql-substitution-due-diligence.mdc`.

**Optimal route** = vibe coding with fewest turns until Desktop-deployable.
Wrong BQL is expensive. Prefer one freeze question over a wrong field.
Not fewest lines of Python.

## 1. Non-negotiable contract

- **Highest priority:** never request, probe, test, generate, or use ESG, GHG,
  climate, or sustainable-finance data items for any purpose. A violation can
  cause the user's Bloomberg account to be suspended or deleted.
- Avoid separately licensed or entitlement-unknown fields. If no confirmed
  core-data alternative exists, stop and require Bloomberg HelpDesk evidence
  for the FLDS BQL tab, semantics, entitlement, and permitted request breadth.
- Official Help Center/catalog evidence is frozen at **2026-07-25**.
- Dated user-supplied HelpDesk, Excel, FLDS, and Desktop evidence can be added
  after that cutoff, but must remain labeled `user-confirmed`.
- Never use web search, external Bloomberg pages, or model memory to fill a
  BQuant evidence gap.
- Never execute BQL locally.
- BQuant Desktop is the runtime. AIM Enterprise and PORT Enterprise are data
  entitlements, not BQuant Enterprise compute features.

## 2. Destinations (the route table)

If a row matches, open **only** that route card. Stop. Do not open § 8.

| Destination (required Desktop output) | Route card | Rest stops the card names | Do not enter | First-success |
|---|---|---|---|---|
| ETF Capping Monitor: AIM holdings, company-group capping, Last Close / Real Time, Monitor alerts | `25` + `project-etf-capping-monitor.mdc` | `08` status codes; `18` Arrow; `24` only for Thai/CAST incident; `15` publish | `09` Error Log as BQL source; `11` `ts_position`; `22` similar names; `crncy()` classifier; VegaExpr on Incl/Ex | Update → PARSER_VERSION; weights use `fill="prev"` + Dynamic Limit; Incl/Ex visible |
| MDX Scan: Hang Seng members, daily OHLCV, PCTB/VS/DD60/signals, optional NameCN | `26` + `project-mdx-scan.mdc` + `Source/MDX_futu_formula.txt` | `09` Play/legend/Arrow traps; `18` DATE merge | `name_chinese_traditional()`; snapshot `px_last`; inventing BUY from legend keys; ETF Update-only MAIN | `load_on_start` → history bars + pandas signals + legend definitions |
| ETF Spread Monitoring: HSBC book spread table and chart, taxonomy/flows, benchmark peers | `27` + `project-etf-spread-monitor.mdc` | `18` Arrow DATE; `23` before any quote field | catalog-similar `spread()`; loan-quote examples in `02`; `25` last-price or `26` OHLCV as this request | Update → live table + chart from typed book; Run/Flows load taxonomy; Search prices benchmark peers (≤200); quote fields user-confirmed 2026-10-24, units/entitlement still unverified |
| FI Index Change: month-end bond adds and exits for one fixed-income index, including the pre-effective projected set | `28` + `project-fi-index-change.mdc` | `02` § Project Practice Notes membership diff; `18` Arrow response | `setdiff()`; `credit_rating()`; equity holdings weights; ESG | Update → cached field contract; diff on `ID`; projected month labeled |
| FI Spread Movement Monitoring: Top 10 increases and decreases in spread for a confirmed fixed-income universe | `29` + `project-fi-spread-movement-monitoring.mdc` | `02` credit recipes; `18` if historical responses; `23` before every BQL field or source | unverified units/entitlement; guessed universe beyond the signed LEGATRUU scope; local BQL; ASKB | Local tests → narrow Desktop validation run after user sign-off (2026-10-24); production only after FLDS/units/entitlement review |
| A **new** named Desktop app | Freeze a route card first (same shape as `25`/`26`: BQL list, identity, pandas, MAIN, fail-closed) | `18` if timeseries; `05` limits | Coding from `09`/`11` tutorials; catalog-similar substitutes | User signs the freeze, then one-pass files |

Live AIM codes, fund names, and exception tickers are **payload**, not
route. Restore `config.py` (or re-type from the Excel runbook). Pixel
chrome is not first-success.

Proven Request shapes also live in `BUNDLE_EXAMPLES.md` (Goal table).
Official BQuant apps are product demos used to sell BQuant: their **code
usage** is authoritative; their feature set is not a real-user spec.
User scripts freeze this shop's named destinations. Use the Goal table
for a **new** composition goal. It is not a third highway for ETF/MDX.

Project `.mdc` files apply whenever the destination is discussed, even if
no matching file is open.

`01`–`24` are the atlas. Default semantic index excludes `09` and `11`
(tutorial magnets). Open them by path only when a route card names them.

## 3. Retrieval procedure

### Destination path (always first)

1. Apply hard stops.
2. Match the user's required Desktop output to § 2. If it matches, open
   **only** that route card (`25`, `26`, `27`, `28`, or `29`) and the rest stops the card
   names. Implement the output contract. Stop. Do not read § 4–§ 14.
3. If there is no destination, use the Proven bundle path below, then
   freeze a route card. Do not write `User scripts/` yet.
4. Cross-check a `bq.data.*` mnemonic with exact `22` only when the route
   card uses it or a detour proposes it.

### Proven bundle path

Use when § 2 did **not** match, but the user has a clear composition goal
(AIM one-account positions, PIT factor backtest, `holders()` batch,
thin MAIN + AppController, and the other Goal table rows).

1. Open `BUNDLE_EXAMPLES.md`. Match **one** Goal table row. Stop.
2. Borrow **code usage** (identity + Request idiom + do-not list). Do
   not copy live `config.py` payload. Do not copy a demo's feature
   limits as the freeze.
3. Freeze a new route card (`25`/`26` shape) before writing `User scripts/`.
4. Fields not on that example still go through `CONCEPT_INDEX` then `23`.

This is not a third highway for ETF/MDX.

### Normal path

Use when the user is not asking for a running app.

1. Classify domain and claim type (§ 5).
2. Open **one** § 8 intent-atlas row, not a whole long file.
3. Exact-search `22` for any data item mentioned.
4. Stop when the authority chain is incomplete.

### High-risk path

Detour only (§ 4). Do not use this path to rebuild a named destination.

1. Open `23-bql-substitution-due-diligence.md`.
2. Exact-search `## token` in `CONCEPT_INDEX.md` (not `@Codebase`). Read
   Policy + Census for **that candidate only**. Independent relevance review
   of those rows; prohibition/incident/hard-stop rows are first-class.
   Co-mention is not a hop. Next hop only if Policy lists
   `next_hops_if_must_resolve` and this Request still needs it; maximum two
   hops. Restriction or conflict → stop.
3. Also search business synonyms, the source Excel/API field, official
   tutorial patterns, restricted-family terms, prior incidents,
   `unresolved` / `OCR` / `catalog-only` / `REFERENCE ONLY`, and negatives
   (`not`, `never`, `do not`). Targeted search, not a tour of `01`–`26`.
4. Read the named sections the search actually hits.
5. For `bq.data.*`, exact-search `22`; do not use fuzzy catalog hits.
6. For universe/functions/libraries, use `07`, `14`, or an official tutorial.
7. Score the candidate; seek counter-evidence.
8. If there is no confirmed BQL equivalent, ask for the FLDS BQL tab.
9. Re-run the review on each user-supplied candidate.
10. Record Approved, Rejected, or Unresolved before writing production code.

A destination rebuild has a three-file ceiling: route card + project `.mdc`
+ the rest stop the card names. Global scan is not a substitute for a
missing freeze.

## 4. Risk classification

Classify after matching a destination (§ 2), not before.

### Destination follow (default for named apps)

Stay on the route card. Do **not** open the High-risk detour path. Do **not** search `01`–`26`. Rest stops only when the card points to them.

### Normal risk

Explain a documented function; UI-only change that does not change data
semantics. One § 8 row.

### High risk (detour only)

Use only when the work **leaves** a frozen route:

- a new or replacement `bq.data.*`, `bq.univ.*`, metadata key, CDE, or
  Portfolio Library API;
- Excel/BDP/BDH/API/DT/PR migration;
- unresolved company/issuer/listing/pricing identity;
- catalog-only, OCR-only, blank-description, or entitlement-unknown families;
- a fallback that would change quantity, price, MV, weight, or alert status
  **and is not already frozen on the route card**.

Building or rebuilding ETF Capping from `25`, or MDX Scan from `26`, is
**not** this path.

### Immediate stop

Stop before loading implementation recipes when the request requires:

- ESG/GHG/climate/sustainable-finance execution;
- BQuant Enterprise-only runtime features on Desktop;
- local BQL execution;
- an uncaptured `16` coverage gap;
- a claim after the official cutoff without user-supplied evidence;
- an unverified OCR/catalog/announcement signature;
- a replacement whose product family, entitlement, identity level, or
  failure mode remains unresolved.

## 5. Authority by claim type

| Claim | Primary authority | Mandatory cross-check |
|---|---|---|
| Safety, platform, restricted use | `.cursor/rules/00-bquant-hard-stops.mdc` | `05`, `17`, project rule |
| Data-item spelling/existence | `22` exact Code row | `08` semantics |
| Data-item semantics/traps | `08` | domain recipe + `22` |
| PyBQL/API signature | `07`, `14`, official tutorial | `21` release status |
| Universe transformation/mapping | official tutorial in `01`/`02`/`11` | `07`, `08` |
| Implementation recipe | routed domain topic | `05`, `18`, project rule |
| Desktop response/Pandas shape | `18` practice-derived contract | `07`, `09` |
| Release/GA/Beta/deprecation | `21` | affected API topic |
| Coverage gap | `16` | request missing source |
| User business rule | dated HelpDesk/Excel/FLDS evidence | `23` decision record; project `25` if ETF monitor, `26` if MDX Scan |

No source has universal precedence. Match the authority to the claim.
Named destinations override this table: use § 2.

## 6. Evidence and entitlement taxonomy

### Evidence grades

- `canonical`: captured Help Center/API evidence with resolved use.
- `script-verified`: text-pasted official product-demo script. Code usage
  is authoritative; feature depth is not a real-user spec.
- `practice-derived`: verified composition, Pandas, UI, or business practice;
  it cannot create a new BQL signature.
- `user-confirmed`: dated HelpDesk, Excel, FLDS, or Desktop behavior supplied
  by the user.
- `OCR-observed`: search lead only; never a signature.
- `announcement-only`: release discovery only.
- `catalog-only`: spelling/existence only.
- `restricted-documentation`: retained historical material; never executable.
- `gap-uncaptured`: stop and request the source.

### Entitlement classes

- `restricted`: ESG/GHG/climate/sustainable-finance; execution prohibited.
- `known-data-entitlement`: AIM or PORT data on Desktop.
- `avoid-unless-helpdesk-confirmed`: LQA, BVAL, S3, Second Measure, foot
  traffic, BI, sentiment, model/opaque fields, and any unfamiliar or
  separately licensed family. Prefer a confirmed core-data alternative.
  DRSK leftover Thai pricing, CAST parent ticker, and `id_bb_company()` have
  2026-09-01 user/official-tab confirmation they are not premium; identity
  fit is still governed by `08`/`23`/`24`.
- `unknown`: do not infer entitlement from a catalog description or words
  such as “premium”; request FLDS/product evidence.

Unknown does not mean prohibited. It means production code is blocked until
the evidence gate is resolved.

## 7. Catalog contract

`22-BQuant_DataItems.md` contains 22,513 data-item codes from the
2026-07-25 user environment.

- Search exact code as `| mnemonic() |`.
- A hit proves snapshot spelling/existence only.
- A blank Description has no semantic authority.
- `*-2()` rows are extraction aliases and invalid Python identifiers; never
  generate them.
- Similar descriptions are candidates, not replacements.
- Parameters, metadata, universes, point-in-time behavior, entitlement, and
  response shape require other authorities or FLDS.
- `bq.univ.*`, `bq.func.*`, `_cde`, and Portfolio Library are outside this
  catalog.
- Never load the full catalog into a normal answer.

## 8. Intent atlas (not for named destinations)

Skip this table when § 2 already matched. One row only.

| Intent or trigger | Primary section | Required cross-check / outcome |
|---|---|---|
| Excel, BDP, BDH, API field, DT*, PR* migration | `23` § Mandatory workflow | `06` § Field Discovery; exact `22`; user FLDS if unresolved |
| Any new/substitute BQL field or API | `23` § Mandatory workflow | targeted detour + risk score + decision record |
| Company/issuer grouping, DT110, DT679 | `08` § Canonical company-ticker mapping | `02` § BQL for Fixed Income Company Analysis |
| Thai `/F TB Equity` or N-NDVR local price | `08` § Thai foreign-board local pricing safety | project ETF rule + `24`; N-NDVR yellow key is `-R TB Equity`; leftover DRSK is HelpDesk-guarded |
| Parent/CAST/obligor/listing proxy | `07`/`08` official CAST and `id_bb_company` tabs | `24` § Failure chain; reject as Thai price or DT110 replacement; run `23` |
| A/H dual listing | `01` § Production Recipe: A/H Dual-Listing Premium | `18` DATE alignment |
| `translatesymbols`, COMPOSITE, PRIMARY listing | `01` § Universes | distinguish from company grouping and local pricing |
| `members`, `holdings`, `holders`, `debt`, `bonds` | domain `01`/`02` universe section | `07` Request contract; do not search only `22` |
| Exact data item or description | targeted `22` search | `08` semantics; FLDS if blank/multiple |
| Catalog exception (`headline_eps`, `credit_rating`, `wal`, `job_openings`) | `08` § Catalog Exception Registry | stop unless current FLDS resolves |
| Associated columns/metadata | `08` § Dictionary Renaming & Metadata | `18` response shape |
| `_cde` | `07` § `_cde` | not an API-to-BQL bridge; run `23` |
| `value(..., mapby='lineage')` | `02` § BQL for Fixed Income Company Analysis | `07` § Recipe-observed universe/value operations |
| Current/Projected AIM position | `11` § BQL for AIM | project rule; ETF one-account shape in `25` |
| PORT/PREP/Portfolio Library | `14` | `21`; no new `bqport`; review before writes |
| Equity screen/factor/PIT | `01`, `19` named recipe | `18` + `05` cached/timeout |
| Credit/FI screen | `02`, `12` named recipe | CREDIT/EQUITY boundary + `18` |
| FX/rates/curves | `11` FX section | pricing-source signature gate |
| Economics/calendar | `13` | `18`; locked-stack check |
| Widgets/Plotly/DataGrid/app lifecycle | `09` | project runtime `25`/`26` for named-app BQL; `05` |
| Desktop copy-paste `np.infinite` / kernel stale import | `09` § Error Log | ETF runtime `25` if monitor files |
| Pandas, Arrow, DATE, concat, execute_many | `18` | `07` Response + `09` Error Log |
| Desktop limits, timeout, 403, kernel | `05` | narrow requests; entitlement is not a retry loop |
| Launchpad publish, Terminal Link, BQAP, auto-sync | `15` § Snapshot versus auto-sync | `05` Desktop limits; ETF app practice in `25` |
| Scheduling/cron/nightly | `17` | Desktop stop |
| What’s New, GA/Beta/deprecation | `21` | announcement is not signature evidence |
| Coverage/page availability | `16` | `gap-uncaptured` means stop |
| ESG/GHG/climate/sustainable | STOP | do not open archived recipes for code generation |
| Official-script provenance/OCR | Official scripts ledger | route to distilled canonical topic; OCR cannot promote |
| `market_status()` cached / PR286 / 6166 HK | `08` § Market-status zero-price rule | ETF runtime `25`; do not use `23`/`24` as the recipe |
| Last Close, holiday fill, last-price zero fallback | `25` § Last-price, Last Close, and zero fallback | `08` for field mapping only |
| ETF Monitor Company / Excel `SHORT_NAME` | `25` § Unresolved: Monitor Company | `08` blank-description trap; `23` if proposing a BQL field |
| ETF Primary FM column or filter | `25` § Primary FM | not a BQL field; `config.py` only |
| ETF Capping Monitor any runtime change | `25` then project `.mdc` | `24` only for mapping incident; `23` before any new BQL |
| Lost user-script rebuild / one-pass Desktop app | `00` § 13 One-pass | project runtime topic first; do not iterate by guessing |
| Proven Request shape (new app, not ETF/MDX rebuild) | `BUNDLE_EXAMPLES.md` Goal table | one card; official = usage authority (demo, not product spec); then freeze |
| ETF Dynamic Limit / Rank / Near Limit / `classify_asset` / cash BGNL | `25` § Dynamic Limit and § Asset classifier | not BQL; do not invent a data item; do not add `crncy()` |
| ETF AIM `accounts` list or `pxnum` | `25` § AIM request shape | `11` tutorial `ts_position()` is not this app |
| MDX Scan any runtime change | `26` then project `.mdc` | `09` widgets/errors; `18` DATE; `23` before any new BQL |
| MDX NameCN / Traditional Chinese security name | `26` § Member metadata and NameCN | `08` identity split; do not use `name_chinese_traditional()` |
| MDX PCTB / VS / DD60 / BUY-SELL signals | `26` § Pandas signal port | not catalog fields; daily Futu file + pandas |
| ETF Spread Monitoring period, placeholder source, or quote field | `27` then project `.mdc` | `23` before any bid/ask field; placeholder is not a request |
| FI Index Change membership, projected month, or dashboard | `28` then project `.mdc` | `02` § Project Practice Notes; do not use `setdiff()` |
| Catalog-similar name fields as substitutes | `23` § Mandatory workflow | `08` + project runtime; `22` similarity is not approval |

## 9. Domain boundary gate

Before using a recipe, answer:

1. Is the requested universe EQUITY, CREDIT, FX/rates, fund, economics,
   portfolio, or account positions?
2. Is the output a security identity, company identity, issuer identity,
   pricing identity, or analytical grouping?
3. Does the recipe preserve the original row lineage and required metadata?
4. Is the intended failure behavior skip, zero, fail closed, or account-level
   invalidation?

If any answer materially changes the implementation and is not in evidence,
ask the user before coding.

Key boundaries:

- `holdings()` is not `holders()`.
- A company/fundamental ticker is not automatically a tradable pricing ticker.
- A bond issuer mapping is not a bond universe.
- A Python string Request universe is a yellow-key ID, not BQL source text.
- AIM/PORT data entitlement does not enable Enterprise compute features.

## 10. Canonical file registry

| File | Role in the navigator |
|---|---|
| `00` § 2 | Destination table (highway index) |
| `25` / `26` / `27` / `28` / `29` | Route cards for the live Desktop apps |
| `CONCEPT_INDEX.md` | Exact `## token` census + hop policy; **not** semantic index |
| `BUNDLE_EXAMPLES.md` | Proven compositions (Goal table); indexed; not a third highway |
| `01`–`08`, `10`, `12`–`21`, `23`–`24` | Atlas — open the section a card, § 8, or census names |
| `09`, `11` | Atlas tutorials; **not in default semantic index**; path-open only |
| `22` | Exact-search catalog only |

| File | Authority role |
|---|---|
| `01` | Equity BQL universes and implementation recipes |
| `02` | Fixed-income BQL universes and implementation recipes |
| `03` | Equity onboarding map |
| `04` | Fixed-income onboarding map |
| `05` | Desktop environment, limits, and troubleshooting |
| `06` | Query anatomy and field-discovery procedure |
| `07` | PyBQL object/API reference and resolved signatures |
| `08` | Data-item semantics, traps, and catalog exceptions |
| `09` | UI/app architecture and Desktop error patterns |
| `10` | Research-page coverage and non-executable boundaries |
| `11` | Funds, FX, commodities, AIM, and sample recipes |
| `12` | Fixed-income screening recipes |
| `13` | Economics and calendar recipes |
| `14` | PORT/PREP and Portfolio Library |
| `15` | Sharing/publishing evidence and gaps |
| `16` | Help Center coverage ledger and gap registry |
| `17` | Desktop scheduling stop card |
| `18` | Pandas/Arrow/response normalization |
| `19` | Equity and credit scoring |
| `20` | Earnings-surprise implementation |
| `21` | What’s New, release, Beta, and deprecation status |
| `22` | Exact data-item catalog only |
| `23` | Mandatory substitution/migration due diligence |
| `24` | ETF mapping incident and prevention case study |
| `25` | ETF Capping Monitor route card |
| `26` | MDX Scan route card |
| `27` | ETF Spread Monitoring route card |
| `28` | FI Index Change route card |
| `29` | FI Spread Movement Monitoring route card |

## 11. Large-file section anchors

Use search for headings before reading large atlas files. Named apps skip
this list and stay on `25` / `26` / `27` / `28` / `29`.

- `00`: **§ 2 Destinations**; then stop for named apps. Atlas: § 8, § 13.
- `CONCEPT_INDEX.md`: exact `## token` (Policy then Census). Do not read linearly.
- `BUNDLE_EXAMPLES.md`: Goal table, then one card. Skip when § 2 already matched.
- `01`: `## Universes`; `## Production Recipes from Official Scripts`.
- `02`: `## Universes`; `### BQL for Fixed Income Company Analysis`.
- `07`: exact `###` API; recipe-observed universe/value operations.
- `08`: Canonical company mapping; Market Status (field trap only); Thai
  safety. Runtime last-price is `25`.
- `18`: Desktop Arrow DATE; execute_many lineage.
- `23`: workflow, risk score, decision record (detours only).
- `24`: failure chain (Thai/CAST incident only).
- `25` / `26` / `27` / `28` / `29`: the route cards.
- `27`: `## Unresolved: bid, ask, and peer requests`; `## Minimum shippable package (one pass)`.
- `28`: `## Membership request`; `## Projected month`; `## Minimum shippable package`.
- `29`: `## Request and validation boundaries`; `## Minimum shippable package`.

## 12. Official-script provenance policy

The archive contains 18 projects: 13 EQUITY, 4 CREDIT, and 1 FX.
Those apps are product demos Bloomberg ships to sell BQuant. Their
**code usage** is authoritative (Bloomberg would not demo a broken
Request). They are still demos: features may be thin and may not match
a real user's job. Named destinations stay on `25` / `26` / `27` / `28` / `29`. Do not
replace a real freeze with a demo's feature set.

- Implement usage from canonical distilled Production Recipes (`01` /
  `02` / `09` / `18`). The Goal table copies those recipes; it does not
  copy the unindexed archive.
- Text-pasted official scripts support `script-verified` composition.
- OCR photos support application shape and search leads only. OCR is
  not the shipped demo and cannot establish a new API signature.
- Do not promote unclear mnemonics, parameters, ticker lists, or glue
  code. Restricted ESG examples never become cards.
- `fundamentalticker()` lineage and general `listings()` mapping are not
  evidenced by the official-script archive; use the Help Center authorities.
- Consensus Revisions OCR, BI Thematic bracket keys, incomplete participant
  OI tickers, and FX OCR parameter conflicts remain non-promotable.

## 13. Anti-amnesia checklist

Before final BQuant code or advice:

- [ ] Hard stops applied; no restricted data or unsupported runtime feature.
- [ ] Destination matched in `00` § 2. Named apps stay on the route card;
      do not start a global `01`–`26` search; do not keep reading `00`.
- [ ] If this is a **new** composition goal, one `BUNDLE_EXAMPLES.md` Goal
      table card was checked. Official usage was borrowed; a demo's
      feature limits were not copied as the freeze.
- [ ] Vibe-coding drop is one complete package (below). No stub that
      needs a Desktop round to discover a freeze already on the card.
- [ ] Detour (`23`) only if leaving the route card.
- [ ] Data-item spelling exact-checked in `22` when a mnemonic is used.
- [ ] Identity layers kept separate; Arrow `ID`/`DATE` preserved.
- [ ] Missing evidence requested from the user instead of inferred.
- [ ] Bundle is not loaded with routed topics.

### One-pass Desktop reconstruction (vibe coding)

The cost to minimize is **chat turns + Desktop debug + file patches** until
a deployable running app. The user hand-copies Python onto BQuant Desktop
(Restart Kernel → Run All → Update / `load_on_start`). A skeleton, a stub,
or a question the route card already answered, each costs a round. A
**wrong field** can cost days and licence risk.

**Do not:**

- Ship `data.py` and wait for a Desktop error before writing `engine.py`.
- Ask whether to use `fill="prev"`, `accounts=[one]`, NameCN mnemonic, or
  Play milliseconds when the route card already froze them.
- Implement Unresolved items (`SHORT_NAME`) “to see if it works”.
- Discover `mode=cached` on `market_status`, VegaExpr-blank Incl/Ex,
  `np.infinite`, or Arrow `DATE` by trial on Desktop — those are on the
  checklist.

**Before any Python:**

1. Name the project runtime topic (`25`, `26`, or a new topic the user
   freezes). Read it in full.
2. If a BQL call, identity mapping, date/fill, pandas formula, or MAIN
   lifecycle is not on that card, **stop**. One freeze question is cheaper
   than a wrong Request.
3. Do not implement named-app BQL from `09` Error Log, `11` tutorials, or
   `22` description similarity.

**Write files in this order, in one assistant drop:**

1. `config.py` — constants and table **structure**. Live AIM codes are
   user data, not encyclopedia facts.
2. `data.py` — every frozen BQL Request.
3. `engine.py` / pandas port — every frozen business formula.
4. `app.py` — enough UI to exercise the freeze.
5. `MAIN.ipynb` — exact lifecycle (`25` Update-only vs `26` one refresh).

**Deployable first drop:** Restart Kernel → Run All → freeze checklist
passes. Later tiny diffs are only for a Desktop fact **not** on the card.

A **new** app has no numbered route card yet. `25` through `28` are already taken. First deliverable is the route card, then
the package. Coding before that freeze is the long vibe-coding loop.

## 14. Maintenance and integrity

- Canonical sources are this navigator plus `01`–`29`.
- Generated outputs are `BQUANT_RAG_KNOWLEDGE_BASE.md`,
  `RAG_KB_MANIFEST.json`, `CONCEPT_INDEX.md`, `CONCEPT_INDEX.json`,
  `BUNDLE_EXAMPLES.md`, and `BUNDLE_EXAMPLES.json`; never edit them
  directly. Curated hop policy is `concept_index_overlay.json`. Proven
  composition registry is `bundle_examples_registry.json`.
- Default semantic index excludes `09`, `11`, `22`, `CONCEPT_INDEX.md`,
  the bundle, raw HTML, official scripts, and restricted reference.
  `BUNDLE_EXAMPLES.md` stays indexed. Route cards `25`/`26`/`27`/`28`/`29` stay indexed.
  Open `09`/`11` by path when a card names them. New functions: exact
  `## token` in `CONCEPT_INDEX.md`.
- After editing canonical knowledge, rules, or indexing policy:

```shell
python3 "RAG KB/regenerate_kb_bundle.py"
python3 "RAG KB/regenerate_kb_bundle.py" --check
```
