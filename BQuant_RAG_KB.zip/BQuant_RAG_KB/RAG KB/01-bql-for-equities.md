---
topic_id: "01"
title: BQL for Equities
role: domain_recipe
authority_for: [equity_universes, equity_bql_recipes]
not_authority_for: [entitlement, release_status, catalog_existence]
evidence_grades: [canonical, script-verified, practice-derived, OCR-observed]
risk_tier: normal
routing_keywords: [equity, members, holdings, translatesymbols, A/H, factor]
mandatory_cross_checks: [00-RAG-INDEX, 08-bql-data-items, 18-using-pandas, 22-BQuant_DataItems]
restricted_sections: []
source_families: [help_center, official_script]
---

# BQL for Equities

**AI quick map**
- `Setup` — `bq = bql.Service()`
- `Single / Multi Item` — dict keys label columns; concat multi-item responses
- `Multi Ticker` — list universes accept ticker / ISIN / CUSIP / FIGI / index
- `Dates & Timeseries` — `dates=`, `bq.func.range()`, `.dropna()` / `.pct_chg()`
- `Fundamentals & Estimates` — period parameters and point-in-time behavior
- `Universes` — members, peers, symbols, lists, and PORT
- `Aggregation` / `Filtering` — grouped metrics and screens
- `Advanced Scoring Pointers` — route to `19`
- `Response → DataFrame Patterns` — ID index and multi-item concat
- `Production Recipes from Official Scripts` — PIT factor backtest, universe adapter, technical/pair monitors, futures composition

**Field gate:** exact-search data-item names in `22`; use `08` for meaning/metadata and current API/FLDS only when signatures remain unresolved.

---

## Setup

```python
import pandas as pd
import bql

bq = bql.Service()
```

**Request pattern**

```python
request = bql.Request(universe, data_items)          # or single bq.data.* item
response = bq.execute(request)
df = response[0].df()                                # single item
# multi-item: pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Cached mode** (large screens / fundamentals)

```python
params = {'mode': 'cached'}
request = bql.Request(universe, data_items, with_params=params)
response = bq.execute(request)
```

---

## Single / Multi Item

**Single equity (ticker or FIGI)**

```python
universe = 'BBG000BLNNH6'
data_items = {
    'Name': bq.data.name(),
    'Price': bq.data.px_last(),
    'Volume': bq.data.px_volume(),
    'P/E': bq.data.pe_ratio(),
    'Mkt Cap': bq.data.cur_mkt_cap(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

Dict **keys** become column labels; **values** are BQL data items.

---

## Multi Ticker

```python
universe = [
    'IBM US Equity',    # Bloomberg ticker
    'US5949181045',     # ISIN
    '037833100',        # CUSIP
    'BBG00DW3SZS1',     # FIGI
    'UKX Index',        # index ticker
]
data_items = {
    'Name': bq.data.name(),
    'PE': bq.data.pe_ratio(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

---

## Dates & Timeseries

**Point-in-time (absolute date `YYYY-MM-DD`)**

```python
universe = 'NVDA US Equity'
date = '2022-12-07'
data_item = {'Price': bq.data.px_last(dates=date)}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Date range → drop NAs (weekends / holidays)**

```python
universe = 'NVDA US Equity'
date_range = bq.func.range('2023-12-01', '2023-12-14')
data_item = {'Price': bq.data.px_last(dates=date_range).dropna()}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

**Relative range + fill + single-row pct change**

```python
universe = 'NVDA US Equity'
last_week = bq.func.range('-1w', '0d')
data_item = {
    'Price Change': bq.data.px_last(dates=last_week, fill='prev').pct_chg()
}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

---

## Fundamentals & Estimates

Common params: `fa_period_type` (`'Q'`, `'A'`, `'BT'`), `fa_period_offset`, `fa_period_reference`, `fa_adjusted`, `currency`.

```python
universe = 'AAPL US Equity'
sales = bq.data.sales_rev_turn(
    fa_period_reference=bq.func.range('2021Q1', '2023Q4'), fa_period_type='Q',
)
ebitda_estimate = bq.data.ebitda(fa_period_offset=bq.func.range(1, 3), fa_period_type='A')
eps_estimate = bq.data.is_eps(
    fa_period_offset='1', fa_period_type='BT', fa_adjusted='Y',
)  # e.g. VOD LN Equity universe

data_items = {'Sales': sales, 'EBITDA Est': ebitda_estimate, 'EPS Est': eps_estimate}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)

# Index members — annual sales
request = bql.Request(
    bq.univ.members('INDU Index'),
    {'Sales': bq.data.sales_rev_turn(fa_period_type='BA')},
)
df = bq.execute(request)[0].df()
```

---

## Universes

### Index members & point-in-time membership

```python
universe = bq.univ.members('INDU Index')
# backdated membership:
universe_asof = bq.univ.members('INDU Index', dates='2023-10-01')

data_items = {
    'Annual EPS': bq.data.is_eps(fa_period_type='A', dates='2023-10-01'),
    'Estimated EPS': bq.data.is_eps(
        fa_period_offset='1', fa_period_type='A', dates='2023-10-01'
    ),
}
request = bql.Request(universe_asof, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Correct vs traps (Desktop, 2026-08-27):** use `bq.univ.members('HSI Index')`. Never `bq.univ.member` (singular). Never pass the Python string `"members('HSI Index')"` as `Request.universe` — that `str` is a ticker (`07`) and parses as `(['members('HSI'`. Details: `09` Error Log.

### translatesymbols (composite / fundamental ticker)

This transforms the working universe and can remove the original listing
identity. It is not equivalent to preserving rows with
`id().value(bq.univ.fundamentalticker(), mapby='lineage')`, and a
`FUNDAMENTALTICKER` target is not proof of a local tradable Pricing Ticker.
Use `08` for company semantics and `23` before applying it as a replacement.

```python
universe = (
    bq.univ.members('INDU Index')
    .translatesymbols(targetidtype='COMPOSITE')   # or 'FUNDAMENTALTICKER'
)
data_item = {'Volume': bq.data.px_volume(dates='2024-06-17')}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

### Peers

```python
universe = bq.univ.peers('VOD LN Equity', type='BLOOMBERG_BEST_FIT')
# type='CUSTOM' → last RV/EQRV peer set on Terminal

data_items = {
    'P/E': bq.data.pe_ratio(),
    'EPS': bq.data.is_eps(currency='USD', fa_adjusted='Y'),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### value() + relativeindex() — outperformance vs relative index

```python
universe = bq.univ.peers('VOD LN Equity', type='BLOOMBERG_BEST_FIT')
return_1y = bq.data.total_return(calc_interval='1y')
index_return_1y = return_1y.value(universe=bq.univ.relativeindex(), mapby='lineage')
outperformance = return_1y - index_return_1y

data_item = {'Outperformance': outperformance}
request = bql.Request(universe, data_item)
response = bq.execute(request)
df = response[0].df()
```

### equitiesuniv (global equity screen base)

```python
mkt_cap_usd_trillion = bq.data.cur_mkt_cap(currency='USD') / 1e12
universe = (
    bq.univ.equitiesuniv(['ACTIVE', 'PRIMARY'])
    .filter(mkt_cap_usd_trillion > 2)
)
data_items = {
    'Name': bq.data.name(),
    'Mkt Cap ($T)': mkt_cap_usd_trillion,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### Private portfolio (Terminal PRTU) & saved list

```python
# Portfolio ID from PRTU upper-right corner
portfolio = bq.univ.members('your_portfolio_id', type='PORT')
data_items = {
    '1M Return': bq.data.total_return(calc_interval='1M'),
    'Weights': bq.data.id()['WEIGHTS'],   # holdings/portfolio → uppercase
}
# request = bql.Request(portfolio, data_items)
# response = bq.execute(request)
# df = pd.concat([field.df()[field.name] for field in response], axis=1)

universe = bq.univ.savedlist(name='Watchlist', source='security_worksheets')
request = bql.Request(universe, {'Name': bq.data.name()})
response = bq.execute(request)
df = response[0].df()
```

**Weights key case:** `bq.univ.members()` → `bq.data.id()['weights']` (lowercase); `bq.univ.holdings()` / portfolios → `['WEIGHTS']`.

---

## Aggregation (group / avg / wavg / cut / zscore / grouprank)

### group().avg() / wavg() / cut()

```python
universe = bq.univ.members('INDU Index')
return_1y = bq.data.total_return(calc_interval='1Y')
sector = bq.data.classification_name(classification_scheme='BICS')
grouped_wgts = bq.data.id()['weights'].group(sector)
ev_to_sales = bq.data.ev_to_sales()

data_items = {
    'Avg Return': return_1y.group(sector).avg(),
    'Wgtd Avg Return': return_1y.group(by=sector).wavg(weights=grouped_wgts),
    'EV to Sales Quantile': ev_to_sales.group().cut(100).ungroup(),
}
request = bql.Request(universe, data_items)
df = pd.concat([item.df()[item.name] for item in bq.execute(request)], axis=1)
```

### groupzscore() / grouprank()

```python
universe = bq.univ.members('INDU Index')
sector = bq.data.classification_name(classification_scheme='BICS')
eps_3y_growth = bq.data.is_eps(
    fa_period_offset=bq.func.range(-2, 0), fa_period_type='A',
).pct_chg()
data_items = {
    'Sector': sector,
    'EPS z-score': bq.data.is_eps().groupzscore(by=sector),
    'Earnings Growth 3Y': eps_3y_growth,
    'Earnings Growth 3Y Sector Rank': eps_3y_growth.grouprank(by=sector),
}
df = pd.concat([item.df()[item.name] for item in bq.execute(bql.Request(universe, data_items))], axis=1)
```

**Group-prefix family:** `grouprank`, `groupavg`, `groupmedian`, `groupzscore`, `groupsort` — use in filters or data items; behavior differs when chained inside `.filter()` vs output columns.

---

## Filtering (filter / and_ / or_ / matches)

### Market cap screen

```python
mkt_cap_usd_trillion = bq.data.cur_mkt_cap(currency='USD') / 1e12
universe = (
    bq.univ.equitiesuniv(['ACTIVE', 'PRIMARY'])
    .filter(mkt_cap_usd_trillion > 2)
)
```

### Upside to analyst target (peers)

```python
target_price = bq.data.best_target_price()
price = bq.data.px_last()
upside_potential = (target_price / price - 1) * 100

universe = (
    bq.univ.peers('IBM US Equity', type='BLOOMBERG_BEST_FIT')
    .filter(upside_potential > 10)
)
data_items = {
    'Name': bq.data.name(),
    'Price': price,
    'Target Price': target_price,
    'Upside Potential (%)': upside_potential,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### EPS estimate revision filter

```python
est_eps_series = bq.data.is_eps(
    fa_period_offset='1',
    fa_period_type='BT',
    dates=bq.func.range('-3M', '0D'),
    fill='prev',
)
universe = bq.univ.members('INDU Index').filter(est_eps_series.pct_chg() > 5)
data_items = {
    'Name': bq.data.name(),
    'Est EPS Chg (%)': est_eps_series.pct_chg(),
    'Est EPS -3M': est_eps_series.first(),
    'Est EPS Current': est_eps_series.last(),
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### and_() — intersection (∩)

```python
fundamental_params = {
    'fa_period_type': 'A',
    'fa_period_offset': bq.func.range(-4, 0),
}
sales_growth_5y = bq.data.sales_rev_turn(**fundamental_params).pct_chg()
earnings_growth_5y = bq.data.net_income(**fundamental_params).pct_chg()

universe = (
    bq.univ.members('INDU Index')
    .filter((sales_growth_5y > 0).and_(earnings_growth_5y > 0))
)
data_items = {
    'Name': bq.data.name(),
    'Sales Growth 5Y': sales_growth_5y,
    'Earnings Growth 5Y': earnings_growth_5y,
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### or_() — union (∪)

```python
dates = bq.func.range('-1Y', '0D')
cash_divs_count = bq.data.dividends(ex_date=dates).count()
stock_divs_count = bq.data.stock_divs(effective_date=dates).count()
stock_splits_count = bq.data.stock_splits(effective_date=dates).count()
rights_count = bq.data.rights_offerings(effective_date=dates).count()
spinoffs_count = bq.data.spinoffs(effective_date=dates).count()

universe = (
    bq.univ.peers('AZN LN Equity', type='BLOOMBERG_BEST_FIT')
    .filter(
        (cash_divs_count > 0)
        .or_(stock_divs_count > 0)
        .or_(stock_splits_count > 0)
        .or_(rights_count > 0)
        .or_(spinoffs_count > 0)
    )
)
```

### Mixed operators + BICS industry filter

```python
industry = bq.data.classification_name(
    classification_scheme='BICS',
    classification_level='2',
)
industries = ['Software & Tech Services', 'Tech Hardware & Semiconductors']
return_1m = bq.data.total_return(calc_interval='1M') * 100
return_1y = bq.data.total_return(calc_interval='1Y') * 100

universe = (
    bq.univ.members('INDU Index')
    .filter(industry.in_(industries).and_((return_1m > 0).or_(return_1y > 5)))
)
```

### grouprank in filter — top EPS growers

```python
eps_3y = bq.data.is_eps(
    fa_period_offset=bq.func.range(-2, 0),
    fa_period_type='A',
)
universe = (
    bq.univ.members('INDU Index')
    .filter(eps_3y.pct_chg().grouprank() <= 3)
)
data_items = {
    'Earnings -3Y': eps_3y.first(),
    'Earnings': eps_3y.last(),
    'Earnings Growth 3Y': eps_3y.pct_chg(),
    'Earnings Growth 3Y Rank': eps_3y.pct_chg().grouprank(),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### grouprank(by=sector) — top EBITDA growth per sector

```python
sector = bq.data.classification_name(classification_scheme='BICS')
ebitda_5y_pct_chg = bq.data.ebitda(
    fa_period_offset=bq.func.range(-4, 0),
    fa_period_type='A',
).pct_chg()

universe = (
    bq.univ.members('INDU Index')
    .filter(ebitda_5y_pct_chg.grouprank(by=sector) == 1)
)
data_items = {
    'Sector': sector,
    'EBITDA Growth 5Y': ebitda_5y_pct_chg,
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### matches() — preserve pre-filter group stats

Using `groupzscore()` inside a **data item** recalculates on the filtered universe; `matches()` keeps original bucket values.

```python
dps_growth = bq.data.dividend_per_share_1_year_growth(
    fa_period_type='A',
    fa_period_offset='1',
)
sector = bq.data.classification_name(classification_scheme='BICS')
dps_growth_zscore = dps_growth.groupzscore(by=sector)

universe = bq.univ.members('INDU Index')
data_items = {
    'DPS Growth Z-score': (
        dps_growth_zscore.matches(dps_growth_zscore > 0.5).dropna(remove_id=True)
    ),
}
request = bql.Request(universe, data_items)
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

---

## Advanced Scoring Pointers

Full factor-composite workflow (Value / Profitability / Momentum, Plotly, ipywidgets): **`19-equity-scoring-model.md`**.

**Sector-relative medians**

```python
universe = bq.univ.members('INDU Index')
sector = bq.data.classification_name()
pe_ratio = bq.data.pe_ratio()
eps_est_3m_chg = bq.data.is_eps(fa_period_offset='1', fa_period_type='bt')
sales_growth = bq.data.sales_rev_turn(
    fa_period_offset=bq.func.range(-3, 0),
    fa_period_type='a',
).pct_chg()

data_items = {
    'PE': pe_ratio,
    'PE vs Sector': pe_ratio / pe_ratio.groupmedian(by=sector),
    'EPS Est': eps_est_3m_chg,
    'EPS Est vs Sector': eps_est_3m_chg / eps_est_3m_chg.groupmedian(by=sector),
    'Rev Gr %': sales_growth,
    'Rev Gr % vs Sector': sales_growth / sales_growth.groupmedian(by=sector),
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Combined z-scores + apply_matches helper**

```python
def apply_matches(bql_item):
    """Retain originally calculated values for top combined-z names via matches()."""
    return bql_item.matches(combined_z_score.grouprank() <= 5).dropna(remove_id=True)

universe = bq.univ.members('INDU Index')
fcf_yield = bq.data.fcf_ev_yield()
roe = bq.data.return_com_eqy()
roic = bq.data.return_on_inv_capital()
fcf_yield_z = fcf_yield.groupzscore()
roe_z = roe.groupzscore()
roic_z = roic.groupzscore()
combined_z_score = fcf_yield_z + roe_z + roic_z

data_items = {
    'Combined Z-score': apply_matches(combined_z_score).groupsort(),
    'FCF Yield': apply_matches(fcf_yield),
    'FCF Yield Z-score': apply_matches(fcf_yield_z),
    'ROE': apply_matches(roe),
    'ROE Z-score': apply_matches(roe_z),
    'ROIC': apply_matches(roic),
    'ROIC Z-score': apply_matches(roic_z),
}
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Piotroski F-score** — build 9 `bq.func.if_(test, 1, 0)` flags on `return_on_asset`, `cf_cash_from_oper`, `net_chg()` pairs, etc.; sum → `f_score`; filter `f_score.grouprank() <= 5`. Full 9-test recipe in Bloomberg quickstart; composite factor UI in **`19-equity-scoring-model.md`**.

```python
# After defining f_score from nine if_() components:
universe = bq.univ.members('INDU Index').filter(f_score.grouprank() <= 5)
data_items = {'F-Score': f_score.groupsort()}  # add component columns as needed
```

---

## Response → DataFrame Patterns

```python
# Single item
df = response[0].df()

# Multi item — value columns only (avoids duplicate metadata)
# Safe when ID / DATE live in the **index**.
df = pd.concat([item.df()[item.name] for item in response], axis=1)
df.index.name = 'ID'   # ID is the index, not df['ID']

# Desktop Arrow timeseries: DATE is often a **column**.
# Do not slice [item.name] then dropna(subset=['DATE']) — KeyError ['DATE'] (`18`).

# Dedupe columns after concat
df = df.loc[:, ~df.columns.duplicated()]

# Time series + static field merge (different shapes)
universe = ['IBM US Equity', 'VOD LN Equity']
data_items = {
    'px': bq.data.px_last(dates=bq.func.range('-1w', '0d')),
    'volume': bq.data.px_volume(dates=bq.func.range('-1w', '0d')),
    'name': bq.data.name(),
}
response = bq.execute(bql.Request(universe, data_items))
df_ts = pd.concat([response[0].df(), response[1].df()], axis=1)
df_final = df_ts.merge(response[2].df(), on='ID', how='left')
```

---

## Production Recipes from Official Scripts (2026-08-26 ingest)

These recipes distill reusable patterns from 13 user-supplied official EQUITY projects. Evidence labels follow `rag-maintenance.mdc`: exact BQL signatures still defer to Official Tutorials, `22`, `07`/`08`, and FLDS when unresolved. OCR-only mnemonics were not promoted.

### Production Recipe: PIT Factor Backtest

**Evidence:** script-verified composition from *Fundamental Backtester*, constrained by the canonical point-in-time rules above.

The non-negotiable design is one request per rebalance date. Backdate both index membership and factor/return observations; do not query today's members and attach historical fundamentals.

```python
def build_rebalance_request(
    rebalance_date,
    next_rebalance_date,
    index_ticker,
    signal,
):
    universe = bq.univ.members(index_ticker, dates=rebalance_date)
    weight = bq.data.id()['weights']  # members() metadata: lowercase
    bucket = signal.ntile(4)
    holding_period_return = bq.data.day_to_day_tot_return_gross_dvds(
        dates=bq.func.range(rebalance_date, next_rebalance_date),
    ).prod()
    items = {
        'Signal': signal,
        'Quartile': bucket,
        'Weight': weight,
        'Holding Period Return': holding_period_return,
    }
    return bql.Request(
        universe,
        items,
        with_params={'fill': 'prev', 'mode': 'cached'},
    )

requests = [
    build_rebalance_request(start, end, 'INDU Index', signal)
    for start, end in zip(rebalance_dates[:-1], rebalance_dates[1:])
]
responses = list(
    bq.execute_many(requests, on_request_error=handle_request_error)
)
```

Production sequence:

1. Generate explicit business rebalance dates; do not use calendar period ends that can land on weekends.
2. Backdate `members(..., dates=rebalance_date)`.
3. Apply fiscal-period and `as_of_date` controls to each fundamental item when the strategy requires PIT statements/estimates.
4. Execute bounded batches with `execute_many`; retain the request date on each frame.
5. Use a holding-period return over each adjacent rebalance interval, not a single-date return.
6. Build quartile returns locally; verify whether the intended spread is quartile 4 minus 1 or the reverse before compounding.
7. Compare against a separately retrieved benchmark and calculate rolling volatility, Sharpe, beta, information ratio, active return, and drawdown.

The backtester uses a second valid outlier pattern: compute a sector-relative z-score and cap it with `if_`. This does not replace the separate `.group().winsorize().avg()` aggregation rule.

```python
sector_z = raw_signal.group(sector).zscore().ungroup()
signal = bq.func.if_(
    sector_z > 3,
    3,
    bq.func.if_(sector_z < -3, -3, sector_z),
)
```

Do not use the script archive's OCR-reconstructed factor aliases as mnemonic authority. Start with the verified factor fields in this file / `19`, then exact-search `22`.

### Production Recipe: Universe Adapter with Explicit Weight Semantics

**Evidence:** script-verified across *Fundamental Backtester*, *BI Thematic Exposure*, and other equity apps.

Keep the universe branch and weight recipe together. A generic adapter that returns only a universe object is unsafe because the hidden metadata key differs.

```python
def equity_universe_and_weight(kind, identifier, as_of=None):
    if kind == 'Index':
        universe = bq.univ.members(identifier, dates=as_of)
        weight = bq.data.id()['weights']
    elif kind == 'Fund Holdings':
        universe = bq.univ.holdings(identifier, dates=as_of)
        weight = bq.data.id()['WEIGHTS']
    elif kind == 'Portfolio':
        universe = bq.univ.members(identifier, type='PORT')
        weight = bq.data.id()['WEIGHTS']
    elif kind == 'Ticker List':
        universe = bq.univ.list(identifier)
        weight = bq.data.cur_mkt_cap()
    else:
        raise ValueError(f'Unsupported equity universe kind: {kind}')
    return universe, weight
```

Treat this as a shape contract:

- `members` and `holdings` are not interchangeable.
- Preserve the branch-specific metadata until after the BQL response is materialized.
- Do not use `setdiff()` when later calculations require those weights.
- Normalize to a common application column such as `Weight` only after extraction.
- The BI-theme photo showed a lowercase portfolio key, but that conflicts with the verified portfolio rule in this file and `bql-pandas-safety.mdc`; it remains OCR-observed and is not promoted.

### Production Recipe: Index Attribution with Injected Index Series

**Evidence:** script-verified from the text-pasted `app.ipynb` in *Index Performance Drivers, Attribution & Trends*.

Use `bq.func.value()` when a member-level expression needs one value from a separate index universe:

```python
index_universe = bq.univ.list([index_ticker])
index_level = bq.func.value(
    bq.data.px_last(dates=as_of_date),
    index_universe,
).group().avg()

member_move = bq.data.px_last(
    dates=bq.func.range(start_date, end_date),
    fill='prev',
).pct_chg()
breadth_up = bq.data.id().matches(member_move > 0).group().count()
breadth_down = bq.data.id().matches(member_move < 0).group().count()
```

For sector attribution:

1. Freeze the constituent universe at the attribution start date.
2. Group by a verified classification item.
3. Use official member weights when attributing the index; market-cap weights are a different analytical choice.
4. Retrieve the index divisor/position metadata only through a verified index recipe.
5. Keep index-level and member-level frames separate until their dates and units are explicit.

The source app also calculates point contribution from member position metadata and `indx_divisor()`. The exact position bracket key is script-observed metadata rather than a `22` mnemonic, so verify its current response shape before copying that extension.

### Production Recipe: A/H Dual-Listing Premium

**Evidence:** script-verified from *A/H Share Premium Calculator*; `a_over_h_share_conversion()` exists in `22`.

```text
active HK equity screen
-> request H price + mapped A ticker
-> request A price for mapped tickers
-> request CNY/HKD FX
-> merge all three time series on DATE
-> premium = A price in HKD / H price - 1
-> rolling mean / standard deviation / z-score
```

Operational rules:

- Keep the mapped A-share ticker as data, not as an assumed string transformation.
- Apply corporate-action adjustment consistently to both equity legs.
- Align FX with `fill='prev'` only across justified market-calendar gaps.
- Drop incomplete triples before calculating the premium.
- Treat forward-dividend adjustment as a separate optional layer; its photographed parameter signature is not promoted here.

### Production Recipe: Technical Monitor with Drill-Down

**Evidence:** practice-derived from *Relative Strength Finder* and *Multi-Market MA Heatmap & Monitor*. The crossover calculation is pure Pandas; the price pull uses canonical equity time-series patterns.

```python
def crossover_flags(fast: pd.Series, slow: pd.Series) -> pd.DataFrame:
    difference = fast - slow
    sign = np.sign(difference)
    return pd.DataFrame({
        'Cross Up': (sign.shift(1) <= 0) & (sign > 0),
        'Cross Down': (sign.shift(1) >= 0) & (sign < 0),
    })
```

App composition:

1. Retrieve a bounded equity universe and price history.
2. Pivot to a date × ticker matrix before rolling calculations.
3. Compute current signals locally and aggregate by sector/size bucket.
4. Render the breadth matrix once.
5. Bind heatmap/grid selection to a per-ticker chart; update existing `FigureWidget`s with `batch_update()` rather than recreating the full dashboard.

Do not infer an MA data-item signature from an OCR script. If BQL-native MA parameters are unresolved, retrieve `px_last` (and OHLC if needed) and calculate the rolling series in Pandas. When parsing Desktop Arrow OHLC, keep the `DATE` column (`18`).

### Production Recipe: OHLC Barrier Lifecycle

**Evidence:** practice-derived from *FCN KI/KO Monitor*, extending the simpler Help Center barrier visualizer.

For a worst-of note, request open/high/low/close once, normalize each underlying to the trade-date level, and evaluate the lifecycle in event order:

```text
trade-date normalization
-> observation-date calendar
-> worst-of/best-of path
-> KO check on eligible observation dates
-> truncate later path after KO
-> KI check only on the surviving lifecycle
-> maturity / no-event state
```

Do not evaluate KI over dates after an earlier KO. Align weekly/monthly observation dates to actual trading dates using a documented rule, and show that rule in the UI.

### Production Recipe: Pair Analytics

**Evidence:** script-verified composition from *Cointegration Pairs Trading* plus canonical `px_last` retrieval.

Keep BQL and statistics separated:

```text
BQL: universe -> px_last history -> date x ticker matrix
Pandas/statsmodels: align/drop NA -> OLS hedge ratio -> residual spread -> ADF
Plotly: p-value matrix -> click -> pair price/spread drill-down
```

Desktop safety:

- Cap the universe before the O(n²) pair loop.
- Use one aligned price matrix rather than one BQL request per pair.
- Treat a low ADF p-value as a statistical screen, not a trading guarantee.
- Recompute the hedge ratio on the selected historical window; do not mix windows between the matrix and drill-down.

`statsmodels` is an additional dependency. Use it only when already available or after explicit package approval; do not add `pip` instructions.

### Production Recipe: Equity Futures Basis / Roll Composition

**Evidence:** script-derived architecture from *Equity Futures Basis & Roll*; exact dividend-offset glue in the photo archive remains OCR-observed.

Use three explicit layers:

1. **Chain layer:** retrieve the futures chain and contract expiry/last-trade dates.
2. **Funding/dividend layer:** retrieve the funding curve and expected dividends using separately verified fields.
3. **Calculation layer:** vectorize days-to-expiry, funding cost, fair value, premium/discount, implied stock-borrow rate, and front/second-month roll.

Never substitute a cash-equity dividend field or a generic curve field for the photographed calls without `22` plus signature evidence. Keep snapshot-date callbacks separate from historical-chain retrieval so a UI date change does not rerun unrelated requests.

### Patterns intentionally not promoted

- *Consensus Estimates Revisions*: exact revision aliases/parameters are OCR-unresolved.
- *BI Thematic Exposure*: `theme_assessment` bracket keys and AIM wiring remain signature-gated.
- *Participant wise OI dashboard*: the `INDR*` ticker list is intentionally incomplete.
- *Multi-Market MA Heatmap & Monitor* and *Bespoke Factor Analysis*: several BQL helper signatures were reconstructed; only their pure-Python/UI composition is reused.

---

## Diagrams

### Equity BQL query flow

```mermaid
flowchart LR
    A[Define universe] --> B[Build data_items dict]
    B --> C["bql.Request(universe, data_items, with_params?)"]
    C --> D["bq.execute(request)"]
    D --> E{Items count}
    E -->|1| F["response[0].df()"]
    E -->|N| G["pd.concat item.df item.name"]
    F --> H[Pandas analysis / Plotly]
    G --> H
```

### Universe building (equity)

```mermaid
flowchart TD
    U[Start] --> M[bq.univ.members Index]
    U --> P[bq.univ.peers ticker]
    U --> E[bq.univ.equitiesuniv ACTIVE PRIMARY]
    U --> S[bq.univ.savedlist / PORT portfolio]
    M --> T[translatesymbols COMPOSITE]
    P --> F[".filter predicate"]
    E --> F
    M --> F
    F --> R[bql.Request + execute]
    P --> V["value relativeindex mapby lineage"]
    V --> R
```

---

## Help Center Example Recipes (Equities)

Dense cards curated from BQuant Desktop Help Center HTML snapshots in `RAG KB/Raw source/`. Scoring/earnings deep dives: see `19-equity-scoring-model.md`, `20-earnings-surprise.md`.

### Peer Ratio Comparison

Compare forward/trailing valuation ratios for a `bq.univ.peers` set; chart each name vs peer-average ratio history with z-score summary.

APIs: `bq.data.ev_to_ebit`, `bq.data.ev_to_ebitda`, `bq.data.ev_to_sales`, `bq.data.pe_ratio`, `bq.data.px_to_book_ratio`, `bq.func.range`, `bq.univ.peers`.

```python
security = 'IBM US Equity'
universe = bq.univ.peers(security, type='BLOOMBERG_BEST_FIT')
date_range = bq.func.range('-2Y', '-1D')
fwd = {'fa_period_offset': '1', 'fa_period_type': 'BT', 'fill': 'prev', 'dates': date_range}
ltm = {'fa_period_offset': '0', 'fa_period_type': 'LTM', 'fill': 'prev', 'dates': date_range}
data_items = {
    'Fwd PE': bq.data.pe_ratio(**fwd),
    'Fwd EV/EBITDA': bq.data.ev_to_ebitda(**fwd),
    'PB': bq.data.px_to_book_ratio(**ltm),
}
df = pd.concat([item.df() for item in bq.execute(bql.Request(universe, data_items))], axis=1)
```

### Peer Ownership Matrix

Cross-holdings matrix: which funds hold a reference ticker and selected peers; `bq.univ.holders` with `id()` metadata keys.

APIs: `bq.data.actively_managed`, `bq.data.cur_mkt_cap`, `bq.data.fund_*`, `bq.data.id`, `bq.data.px_last`, `bq.data.state_code`, `bq.univ.holders`.

```python
def build_holders_request(ticker):
    universe = (
        bq.univ.holders(ticker, view='Lowest')
        .filter(
            bq.data.id()['holder_type'].in_(['Fund', 'Institution'])
            .and_(bq.data.px_last() > 0)
        )
    )
    return bql.Request(universe, {
        'Fund ID': bq.data.id()['value'],
        'Position': bq.data.id()['position'],
        'Position Change': bq.data.id()['position_change'],
        'Market Value Holding ($M)': bq.data.id()['market_value'] / 1e6,
        'Institution Name': bq.data.id()['holder_name'],
    }, with_params={'mode': 'cached'})
```

### Equity Relative Value

Index-member valuation z-scores vs self, sector (bottom-up or mapped sector index), and index; weighted z-score grid with bar renderer for days outside threshold.

APIs: `bq.data.classification_name`, `bq.data.cur_mkt_cap`, `bq.data.ev_to_ebitda`, `bq.data.pe_ratio`, `bq.func.range`, `bq.univ.list`, `bq.univ.members`.

```python
index = 'SPX Index'
universe = (
    bq.univ.members(index).translatesymbols(targetidtype='composite')
    .union(bq.univ.list(index))
)
date_range = bq.func.range(f'{end_date}-2Y', end_date)
data_items = {
    'Sector': bq.data.classification_name(classification_scheme='GICS'),
    'Cur Mkt Cap ($B)': bq.data.cur_mkt_cap(dates=date_range, currency='USD') / 1e9,
    'Fwd PE': bq.data.pe_ratio(
        fa_period_offset='1', fa_period_type='BT', fa_period_type_source='A',
        dates=date_range,
    ),
}
df = bq.execute(bql.Request(universe, data_items, with_params={'mode': 'cached'})).get('Fwd PE').df()
```

### Equity Return Decomposition

Decompose TSR into price, NTM P/E re-rating, EPS growth, dividends; fiscal-year-weighted blended forward EPS from multi-FY estimates.

APIs: `bq.data.crncy`, `bq.data.eqy_fund_crncy`, `bq.data.headline_eps`, `bq.data.market_sector_des`, `bq.data.name`, `bq.data.px_last`, `bq.data.tot_return_index_gross_dvds`, `bq.func.range`.

> Catalog exception: `headline_eps()` is official-example-observed but has no exact `22` match. Do not assume `headline_eps_gaap()` is equivalent; confirm the current API/FLDS item before running this block.

```python
date_range = bq.func.range(start, end)
price = bq.data.px_last(dates=date_range, currency=currency, fill='prev')
tot_return = bq.data.tot_return_index_gross_dvds(dates=date_range, currency=currency, fill='prev')
eps_bf = bq.data.headline_eps(fa_period_offset='1', fa_period_type='BT', fa_period_type_source='A', dates=date_range, fill='prev')
data_items = {
    'Δ Price': price.last() / price.first(),
    'Δ NTM PE': (price / eps_bf).last() / (price / eps_bf).first(),
    'Δ NTM EPS': eps_bf.last() / eps_bf.first(),
    'TSR': tot_return.last() / tot_return.first(),
}
```

### Equity Scoring and Screening

Interactive factor screener with `matches()` cutoff — full recipe in `19-equity-scoring-model.md` (`groupcut` variant documented there).

APIs: `bq.data.classification_name`, `bq.data.ev_to_ebitda`, `bq.data.fcf_ev_yield`, `bq.data.market_sector_des`, `bq.data.name`, `bq.data.oper_margin`, `bq.data.pe_ratio`, `bq.data.px_to_sales_ratio`, `bq.data.return_com_eqy`, `bq.data.return_on_inv_capital`, `bq.data.total_return`, `bq.func.range`.

### Equity Broker Estimates

Broker-level annual EPS strips vs consensus/actuals; `preferences={'addcols': ['PERIOD', 'IN_CONSENSUS_BST', 'FIRM_NAME']}`.

APIs: `bq.data.is_eps`, `bq.data.market_sector_des`, `bq.func.range`.

```python
year_range = bq.func.range(datetime.today().year - 4, datetime.today().year + 2)
params = {'fa_period_reference': year_range, 'fa_period_type': 'A', 'fa_adjusted': 'Y', 'currency': 'USD'}
broker_eps = bq.data.is_eps(**params, fa_act_est_data='E', est_source='brokers_all_active')
universe = universe.translatesymbols(targetidtype='composite').filter(broker_eps.sum() != bql.NA)
response = bq.execute(bql.Request(universe, {
    'Actual': bq.data.is_eps(**params, fa_act_est_data='A'),
    'Broker EPS Estimate': broker_eps,
    'Consensus': bq.data.is_eps(**params, fa_act_est_data='E'),
}, preferences={'addcols': ['PERIOD', 'IN_CONSENSUS_BST', 'FIRM_NAME']}))
```

### Analyst Buy/Hold/Sell Recommendations

Point-in-time index membership via `execute_many` month-end snapshots; weighted buy/hold/sell stacks with target-price spread subplot.

APIs: `bq.data.best_analyst_rating`, `bq.data.best_target_price`, `bq.data.classification_name`, `bq.data.country_full_name`, `bq.data.cur_mkt_cap`, `bq.data.id`, `bq.data.market_sector_des`, `bq.data.px_last`, `bq.data.tot_buy_rec`, `bq.data.tot_hold_rec`, `bq.data.tot_sell_rec`, `bq.func.range`.

```python
def get_weight_item():
    if universe_picker.universe_type == 'Fund holdings':
        return bq.data.id()['WEIGHTS'] / 100
    if universe_picker.universe_type == 'Index members':
        return bq.data.id()['weights'] / 100
    mkt_cap = bq.data.cur_mkt_cap(currency='USD')
    return mkt_cap / mkt_cap.groupsum()

data_items = {
    'Consensus': bq.data.best_analyst_rating(),
    'Buys': bq.data.tot_buy_rec(), 'Holds': bq.data.tot_hold_rec(), 'Sells': bq.data.tot_sell_rec(),
    'Weights': get_weight_item(),
}
```

### Analyst Accuracy-based Consensus Estimates

Rank analysts by weighted MAPE on EPS + sales; inverse-MAPE weighted consensus vs plain consensus.

APIs: `bq.data.is_eps`, `bq.data.sales_rev_turn`, `bq.func.range`.

```python
est_params = {
    'fa_period_offset': bq.func.range('-6', '2'), 'fa_period_type': period_type,
    'fa_adjusted': 'Y', 'dates': bq.func.range('-5y', '0d'), 'fa_act_est_data': 'E',
}
act_params = {**est_params, 'fa_act_est_data': 'A', 'fa_filing_status': 'LR', 'dates': None}
data_items = {
    'est_eps': bq.data.is_eps(**est_params, est_source='brokers_all_active', fill='prev').dropna()['value'],
    'act_eps': bq.data.is_eps(**act_params).dropna()['value'],
}
preferences = {'addcols': ['as_of_date', 'revision_date', 'firm_name', 'analyst_name', 'period']}
```

### Factor Exposure-Based Peer Finder

Euclidean distance on `bq.data.factor_exposure(factor_name=...)` with manual raw/relative filters per component.

APIs: `bq.data.classification_name`, `bq.data.factor_exposure`, `bq.data.name`, `bq.univ.list`, `bq.univ.members`.

```python
universe = (
    bq.univ.members(comparison_index).translatesymbols(targetidtype='composite')
    .union(bq.univ.list(company))
)
data_items = {'Descriptive|Name': bq.data.name(), 'Descriptive|Sector': bq.data.classification_name()}
data_items['Size|Market Cap'] = bq.data.factor_exposure(factor_name='Market Cap')
response = bq.execute(bql.Request(universe, data_items, with_params={'dates': as_of_date}))
```

### Index Member Relative Performance

Pairwise return spread heatmap; click updates dual-security spread line with `FigureWidget.batch_update()`.

APIs: `bq.data.day_to_day_tot_return_gross_dvds`, `bq.func.range`, `bq.univ.list`, `bq.univ.members`.

```python
index_ticker = 'INDU Index'
universe = bq.univ.list(index_ticker).union(bq.univ.members(index_ticker))
dates = bq.func.range('-2y', '-1d')
df = bq.execute(bql.Request(
    universe, {'Return': bq.data.day_to_day_tot_return_gross_dvds(dates=dates).dropna()}
))[0].df()
```

### Index Member Correlation

Static correlation heatmap on index members; rolling correlation line on pair click.

APIs: `bq.data.name`, `bq.data.px_last`, `bq.func.range`, `bq.univ.members`.

```python
universe = bq.univ.members('INDU Index')
response = bq.execute(bql.Request(universe, {
    'Price': bq.data.px_last(dates=bq.func.range('-3y', '-1d')),
    'Name': bq.data.name(),
}))
df = response.get('Price').df().join(response.get('Name').df())
```

### Index Member Implied Volatility

Multi-expiry/strike IV grid with percentile and z-score variants; `bq.univ.holdings` or `bq.univ.members`.

APIs: `bq.data.classification_name`, `bq.data.cur_mkt_cap`, `bq.data.dividend_yield`, `bq.data.id`, `bq.data.implied_volatility`, `bq.data.name`, `bq.data.security_typ`, `bq.data.total_return`, `bq.data.turnover`, `bq.func.range`, `bq.univ.holdings`, `bq.univ.members`.

```python
item = bq.data.implied_volatility(expiry='1M', pct_moneyness='100', dates=bq.func.range('-1Y', '0D'))
data_items = {
    'IVol:1M 100%': item.dropna().last(),
    'IVol Pctl 1Y:1M 100%': item.cut(100).dropna().last(),
    'IVol Z-Score 1Y:1M 100%': item.zscore().dropna().last(),
    'Weights': bq.data.id()['weights'] / 100,
}
universe = bq.univ.members(ticker).filter(bq.data.security_typ() == 'Common Stock')
```

### Index Replication

Top-N weighted replica baskets vs index; tracking error by subset size; optional country aggregation.

APIs: `bq.data.country_full_name`, `bq.data.px_last`, `bq.data.weights`, `bq.func.range`, `bq.univ.members`.

```python
def get_starting_weights_index_members(index_ticker, start_date):
    universe = bq.univ.members(index_ticker, dates=start_date)
    data_items = {'Weights': bq.data.weights()['VALUE'] / 100, 'Country': bq.data.country_full_name()}
    return pd.concat([item.df() for item in bq.execute(
        bql.Request(universe, data_items, with_params={'fill': 'prev'})
    )], axis=1)

date_range = bq.func.range(start_date, '0D', cdr='5D')
prices = bq.execute(bql.Request(
    bq.univ.members(index_ticker, dates=start_date), {'Price': bq.data.px_last(dates=date_range)},
))[0].df()
```

### Equity Market Performance Treemap

Nested GICS treemap of index/fund returns; `bq.func.bins` for cap-size; fund holdings use `id()['WEIGHTS']`, while index members use `id()['weights']`.

APIs: `bq.data.classification_name`, `bq.data.country_full_name`, `bq.data.cur_mkt_cap`, `bq.data.id`, `bq.data.name`, `bq.data.px_high`, `bq.data.px_last`, `bq.data.px_low`, `bq.data.px_volume`, `bq.data.total_return`, `bq.data.turnover`, `bq.func.bins`, `bq.func.range`.

```python
dates = bq.func.range(f'-{lookback}', 'today')
price = bq.data.px_last(dates=dates, fill='prev')
mkt_cap = bq.data.cur_mkt_cap(currency='USD') / 1e9
weight_key = 'WEIGHTS' if universe_picker.universe_type == 'Fund holdings' else 'weights'
data_items = {
    'Sector': bq.data.classification_name(),
    'Price Pct Chg': price.pct_chg() / 100,
    'Total Rtn': bq.data.total_return(calc_interval=dates),
    'Cap Size': bq.func.bins(mkt_cap, [0.25, 2, 10, 200],
                             ['Micro Cap', 'Small Cap', 'Mid Cap', 'Large Cap', 'Mega Cap']),
    'Weight': bq.data.id()[weight_key] / 100,
}
fig = px.treemap(tree_df, names='child', parents='parent', values='box_size', color='Total Rtn')
```

### Correlated Asset Discovery

Anchor vs multi-universe correlation table across return horizons; optional date shift per comparison universe.

APIs: `bq.data.name`, `bq.data.px_last`, `bq.func.range`.

```python
def build_bql_request(universe, start_date, end_date, frequency):
    return bql.Request(universe, {
        'Name': bq.data.name()['value'],
        'Price': bq.data.px_last(dates=bq.func.range(start_date, end_date, frq=frequency)),
    }, with_params={'mode': 'cached'})

responses = bq.execute_many(
    [build_bql_request(anchor, start, end, frq)] +
    [build_bql_request(row['picker_value'], start, end, frq) for row in comparison_univ]
)
```

### Capital Allocation

Annual cash-flow decomposition with drill-down grids for buybacks, M&A, equity offerings on bar click.

APIs: `bq.data.bs_sh_out`, `bq.data.cap_expend_to_sales`, `bq.data.cf_*`, `bq.data.classification_name`, `bq.data.dvd_payout_ratio`, `bq.data.equity_offerings`, `bq.data.is_div_per_shr`, `bq.data.is_eps`, `bq.data.mergers`, `bq.data.name`, `bq.data.net_debt*`, `bq.data.rd_expend_to_net_sales`, `bq.data.return_on_inv_capital`, `bq.data.share_buybacks`, `bq.func.range`.

```python
period_range = bq.func.range(start_year, end_year)
params = {'fa_period_type': 'A', 'fa_period_reference': period_range, 'fa_act_est_data': 'A'}
data_items = {
    'CF From Ops (Bn)': bq.data.cf_cash_from_oper(**params) / 1e9,
    'Buybacks (Bn)': bq.data.cf_decr_cap_stock(**params) / 1e9,
    'M&A (Bn)': bq.data.cf_cash_for_acquis_subsidiaries(**params) / 1e9,
    'Dividends (Bn)': bq.data.cf_dvd_paid(**params) / 1e9,
    'ROIC': bq.data.return_on_inv_capital(**params),
}
daily_data = {
    'Share Buybacks': bq.data.share_buybacks(effective_date=bq.func.range(f'{start_year-1}-01-01', f'{end_year}-12-31')),
    'Mergers': bq.data.mergers(announced_date=daily_range, status='all'),
}
```

### Aggregated Filings Changes

Aggregate 13F/holdings position changes across institutions; top buy/sell drilldown by security.

APIs: `bq.data.classification_name`, `bq.data.id`, `bq.data.name`, `bq.data.px_last`, `bq.data.security_typ`, `bq.univ.holdings`.

```python
def build_holdings_request(ticker):
    universe = (
        bq.univ.holdings(ticker, filingsource='13F') if inst_mode else bq.univ.holdings(ticker)
    ).filter(bq.data.security_typ() == 'Common Stock')
    price = bq.data.px_last(currency='USD', fill='prev', dates=bq.data.id()['REPORT_DATE'].toscalar())
    return bql.Request(universe, {
        'ID': bq.data.id(), 'Price': price['VALUE'], 'Name': bq.data.name()['VALUE'],
        'Sector': bq.data.classification_name()['VALUE'],
    }, with_params={'mode': 'cached'})
```

### Option Open Interest Concentration

Filter `bq.univ.options` by min OI and expiry; bubble (expiry × strike) linked to stacked bar by strike.

APIs: `bq.data.expire_dt`, `bq.data.name`, `bq.data.open_int`, `bq.data.put_call`, `bq.data.px_last`, `bq.data.px_volume`, `bq.data.strike_px`, `bq.univ.options`.

```python
open_int = bq.data.open_int()
expiry = bq.data.expire_dt()
universe = bq.univ.options(ticker).filter(
    (open_int > minimum_open_int).and_(expiry < expiry_cutoff)
)
data_items = {'Open Int': open_int, 'Strike': bq.data.strike_px(), 'Put/Call': bq.data.put_call(), 'Expiry': expiry}
```

### Option Pin Risk

Index-wide OI/gamma concentration; map options to underlying via `issuer(...)` lineage; aggregate by strike/expiry.

APIs: `bq.data.cont_size`, `bq.data.exch_code`, `bq.data.expire_dt`, `bq.data.gamma`, `bq.data.id`, `bq.data.open_int`, `bq.data.pct_moneyness`, `bq.data.put_call`, `bq.data.px_last`, `bq.data.px_volume`, `bq.data.strike_px`, `bq.data.undl_ticker`, `bq.func.range`, `bq.univ.list`.

```python
def issuer(data_item):
    return data_item.value(bq.data.undl_ticker().to_ids(), mapby='lineage')

universe = bq.univ.list(tickers[i:i+50]).options().filter(
    bq.data.expire_dt() < expiry
    .and_(bq.data.pct_moneyness().between(mny_lower, mny_upper))
    .and_(bq.data.open_int() >= 0)
)
data_items = {
    'Open Int': bq.data.open_int(),
    'Spot Notional': bq.data.open_int() * bq.data.cont_size() * issuer(bq.data.px_last(fill='prev')),
}
```

### Knock In/Knock Out Barrier Visualizer

Price history with configurable absolute/percent barrier lines; multi-tab `ipywidgets` sidebar (minimal BQL: `px_last` only).

APIs: `bq.data.px_last`, `bq.func.range`.

```python
def get_data(tickers, lookback):
    price_series = bq.data.px_last(dates=bq.func.range('-' + lookback, '0d')).dropna()
    df = bq.execute(bql.Request(tickers, {'Price': price_series}))[0].df()
    return df.reset_index().set_index('DATE')
```

### Consumer Transaction Data Screener

Second Measure observed sales vs company KPI segments; QTD YoY vs consensus implied move.

APIs: `bq.data.classification_name`, `bq.data.cur_mkt_cap`, `bq.data.earnings_related_implied_move`, `bq.data.name`, `bq.data.observed_sales`, `bq.data.sales_rev_turn`, `bq.data.segment_name`, `bq.func.if_`, `bq.func.min`, `bq.func.range`.

```python
bsm_daily = bq.data.observed_sales(dates=bq.func.range('-545D', '0D')).dropna()
current_q_sales = bsm_daily.matches(
    (bsm_daily['DATE'] > current_q_start).and_(bsm_daily['DATE'] <= current_q_end)
).sum()
comparison_q_sales = bq.func.if_(
    bsm_daily.last()['DATE'] > current_q_end,
    comparison_q_sales_full.sum(),
    comparison_q_sales.first(days_elapsed).sum(),
)
data_items = {
    'Observed Sales YoY (Reporting QTD)': current_q_sales / comparison_q_sales - 1,
    'Implied Move': bq.data.earnings_related_implied_move() / 100,
}
```

### Consumer Transaction Data — Brand and Channel Sales

Observed sales by `brand=` or `channel=` parameter on `observed_sales`; FQ share and YoY plus QTD growth/contribution panels.

APIs: `bq.data.observed_sales`, `bq.data.sales_rev_turn`, `bq.func.range`.

```python
def build_data_items(category_type, categories, period_type, day_offset=None):
    kwargs = {}
    if period_type == 'FQ':
        kwargs = {'fa_period_reference': bq.func.range('2016-01-01', date.today().strftime('%Y-%m-%d')), 'fa_period_type': 'Q'}
    elif period_type == 'D':
        kwargs = {'dates': bq.func.range(f'-{day_offset}D', '0D')}
    sales = bq.data.observed_sales()
    items = {'All': sales.with_additional_parameters(**kwargs)}
    for cat in categories:
        kw = {**kwargs, category_type: cat.replace("'", "\\'")}
        items[cat] = sales.with_additional_parameters(**kw)
    return items
```

## Get Data Official Tutorial: Equities Family

```mermaid
flowchart LR
  A["Equities Family"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### BQL for Equities
- This notebook demonstrates several ways you can use BQL to perform equity analyses.
- Note: Supplements existing 01 recipes; keep unique patterns.
- **Topics:** Quickstart: BQL for Equities; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Querying for an individual equity¶; Querying for multiple data items¶; Querying for multiple tickers¶
- **APIs:** `bq.data.asset_turnover`, `bq.data.best_target_price`, `bq.data.bs_sh_out`, `bq.data.bs_tot_asset`, `bq.data.cf_cash_from_oper`, `bq.data.classification_name`, `bq.data.cur_mkt_cap`, `bq.data.cur_ratio`, `bq.data.dividend_per_share_1_year_growth`, `bq.data.dividends`, `bq.data.ebitda`, `bq.data.ev_to_sales`, `bq.data.fcf_ev_yield`, `bq.data.gross_margin`

```python
# Define the target universe, multiple securities, using several ID types
universe = [
    'IBM US Equity',    # Bloomberg Ticker
    'US5949181045',     # ISIN
    '037833100',        # CUSIP
    'BBG00DW3SZS1',     # FIGI
    'UKX Index'         # Index ticker
]

# Define your target data
data_items = {
    'Name': bq.data.name(),
    'PE': bq.data.pe_ratio()
}

# Build and execute the request and display the results
request = bql.Request(universe, data_items)
response = bq.execute(request)

data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
data
```

```python
universe = bq.univ.peers('VOD LN Equity', type='BLOOMBERG_BEST_FIT')

return_1y = bq.data.total_return(calc_interval='1y')
# Return of each equity ticker's relative index
index_return_1y = return_1y.value(
    universe=bq.univ.relativeindex(), 
    mapby='lineage'
)
# Equity ticker return vs each equity ticker's relative index return
outperformance = return_1y - index_return_1y

data_item = {'Outperformance': outperformance}

request = bql.Request(universe, data_item)
response = bq.execute(request)

response[0].df()
```

### BQL for Equities Tutorial
- This tutorial teaches you how to use the Bloomberg Query Language (BQL) to retrieve data for your research in the equity market.
- **Topics:** Open an interactive version; Introduction¶; Foundation of BQL for equities¶; The skills you need¶; Setting up your environment¶; Constructing a BQL equity universe¶; Holdings of a single fund or aggregated 13F holdings¶; Filter all available equities¶
- **APIs:** `bq.data.bs_customer_deposits`, `bq.data.cntry_of_domicile`, `bq.data.cur_mkt_cap`, `bq.data.ebitda`, `bq.data.id`, `bq.data.industry_group`, `bq.data.is_eps`, `bq.data.name`, `bq.data.net_income`, `bq.data.pe_ratio`, `bq.data.px_last`, `bq.data.px_volume`, `bq.data.sales_rev_turn`, `bq.func.range`

#### FA and estimates parameter canon
- `fa_period_type` selects annual/quarterly/semiannual/LTM-style period families; confirm supported values in current API docs or FLDS when unresolved.
- **LTM methodology cutover:** the revised blending methodology became mandatory after 2025-11-17. Do not generate the retired `new_method_ltm_blending='N'` opt-out.
- `fa_period_reference` anchors an explicit fiscal period or range. For point-in-time work, pair the item with a single `as_of_date` and deliberate `fa_period_offset`.
- Fundamentals may mix actuals and estimates by default. Use `fa_act_est_data='A'` when the workflow requires actual-only history.
- Estimate history is point-in-time: revisions unavailable at an earlier `as_of_date` can be `NaN`; use `fill='prev'` only when economically justified.
- Contributor-level estimate output can include `EST_SOURCE` / `BROKERS_ALL_ACTIVE` metadata and may require entitlement.
- Period parameters are data-item specific. Do not copy aliases or enum values between fields without current API/FLDS confirmation.

#### Holdings and historical portfolio caveats
- `holdings(..., dates=...)` is backdatable when supported.
- The official tutorial shows aggregated 13F holdings through a `type='13F'` pattern, while older examples use `filingsource='13F'`; confirm the active signature before coding.
- Historical `members(..., type='PORT', dates=...)` may require PORT/PREP entitlement. Desktop access must not be assumed; see `14`.

```python
all_active_primary_equities = bq.univ.equitiesuniv(['ACTIVE', 'PRIMARY'])

# Filter for banks with deposits greater than $150 Billion
filter_criterion = (
    (bq.data.industry_group() == 'Banks')
    .and_(bq.data.bs_customer_deposits(currency='USD') > 150e9)
    .and_(bq.data.cntry_of_domicile().in_(['FR', 'DE']))
)

# Join the 2 filters together and apply
universe = all_active_primary_equities.filter(filter_criterion)

data_items = {
    'Name': bq.data.name()
}

# Set the mode parameter to 'cached' to prevent the query from timing out
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)

data = response[0].df()
data.head()
```

```python
all_active_primary_equities = bq.univ.equitiesuniv(['ACTIVE', 'PRIMARY'])

# Filter for banks with deposits greater than $150 Billion
filter_criterion = (
    (bq.data.industry_group() == 'Banks')
    .and_(bq.data.bs_customer_deposits(currency='USD') > 150e9)
)

# Apply criteria to universe
universe = all_active_primary_equities.filter(filter_criterion)

data_items = {
    'Name': bq.data.name()
}

# Set the mode parameter to 'cached' to prevent the query from timing out
request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)

data = response[0].df()
data.head()
```

### BQL for Corporate Actions
- This notebook is designed to show off several ways you can use BQL to perform dividends and other corporate actions analyses.
- **Topics:** Quickstart: BQL for Corporate Actions; Open an interactive version; Table of contents¶; Setting up your environment¶; Actual and projected dividends¶; Querying dividends for a single ticker¶; Querying dividends for multiple tickers¶; Querying for projections¶
- **APIs:** `bq.data.buyback_programs`, `bq.data.classification_name`, `bq.data.delistings`, `bq.data.dividends`, `bq.data.equity_offerings`, `bq.data.eqy_sh_out`, `bq.data.is_eps`, `bq.data.mergers`, `bq.data.name`, `bq.data.px_last`, `bq.data.rights_offerings`, `bq.data.share_buybacks`, `bq.data.spinoffs`, `bq.data.stock_divs`

```python
# Set the universe as members of the index
universe = bq.univ.members('WORLD Index')

# Define a "total dividends" metric we can use to rank companies
shares = bq.data.eqy_sh_out()['value']
div_per_share = bq.data.dividends(
    ex_date=bq.func.range('-1y','0d'), 
    as_of_date=bq.func.today(), 
    type='all'
).sum()['value']
total_divs = (shares * div_per_share) / 1e6

# Filter with top() to find the companies with largest dividend returns
universe = universe.top(10, total_divs)

# Query for company names and the total dividends issued
data_item = {
    'Name': bq.data.name(),
    'Total Dividends': total_divs.groupsort()
}

# Build and execute the BQL query
request = bql.Request(universe, data_item)
response = bq.execute(request) 

# Concatenate all returned data items into a single DataFrame
data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)
data
```

```python
# Set the universe as members of the index
universe =  bq.univ.members('SXXP Index')

# Define a data item to get share buyback data from 2022
buybacks_data = bq.data.share_buybacks(
    effective_date=bq.func.range('2022-01-01','2022-12-31'),
    currency='USD'
).dropna(remove_id=True)

# Query specifically for buyback value and effective date of buyback
data_item = {
    'Buybacks': buybacks_data['value'] / 1e9,
    'Effective Date': buybacks_data['effective_date']
}

# Build and execute the BQL query
request = bql.Request(universe, data_item)
response = bq.execute(request) 

# Concatenate data into a Pandas DataFrame
data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

# Group the data by month for better readability
buybacks_by_month = data.groupby(
    data['Effective Date'].dt.to_period("M")
)['Buybacks'].sum().reset_index()
buybacks_by_month
```

### BQL for Equity Company Analysis
- **Topics:** Quickstart: BQL for Equity Company Analysis; Open an interactive version; Table of contents¶; Setting up your environment¶; Understanding company and peer context¶; Querying stock details and industry grouping¶; Querying segment and geographic revenue breakdown¶; Retrieving peers using univ.peers()¶
- **APIs:** `bq.data.ann_total_return`, `bq.data.beta`, `bq.data.bs_acct_payable`, `bq.data.bs_accts_rec_excl_notes_rec`, `bq.data.bs_cash_near_cash_item`, `bq.data.bs_tot_asset`, `bq.data.bs_tot_liab2`, `bq.data.cf_cash_for_acquis_subsidiaries`, `bq.data.cf_cash_for_divestitures`, `bq.data.cf_cash_from_oper`, `bq.data.cf_decr_cap_stock`, `bq.data.cf_dvd_paid`, `bq.data.cf_free_cash_flow`, `bq.data.cf_incr_cap_stock`

#### Segment universe (tutorial-observed; signature gate)

`bq.univ.segments('TICKER')` is the official tutorial pattern for segment/geographic revenue entities. Confirm the universe signature and requested segment fields in FLDS before adapting it.

```python
universe = 'IBM US Equity'

params = {
    "fa_period_type": "A",
    "fa_period_reference": bq.func.range('2020', '2025'),
    "fa_act_est_data": "A",
}

data_item = {
    "Period": bq.data.is_eps(**params)["PERIOD_END_DATE"],
    "CF From Ops (Bn)": bq.data.cf_cash_from_oper(**params) / 1e9,
    "Buybacks (Bn)": bq.data.cf_decr_cap_stock(**params) / 1e9,
    "M&A (Bn)": bq.data.cf_cash_for_acquis_subsidiaries(**params) / 1e9,
    "Divestitures (Bn)": bq.data.cf_cash_for_divestitures(**params) / 1e9,
    "Equity Offerings (Bn)": bq.data.cf_incr_cap_stock(**params) / 1e9,
    "Dividends (Bn)": bq.data.cf_dvd_paid(**params) / 1e9,
    "Net Capex (Bn)": (
        bq.data.chg_in_fxd_and_intang_ast_detailed(**params) / 1e9
    ),
    "Issuance/(Repayment) of Debt (Bn)": (
        bq.data.proc_fr_repaymnts_bor_detailed(**params) / 1e9
    )
}

request = bql.Request(universe, data_item)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df
```

```python
# Specify Advanced Micro Devices as the universe
target_security = bq.univ.list('AMD US Equity')
industry = bq.data.classification_name('bics', '3')
mkt_cap = bq.data.cur_mkt_cap()
country = bq.data.cntry_of_risk()

universe = (
    bq.univ.equitiesuniv(['active', 'primary'])
    .filter(
        (industry == industry.value(target_security))
        .and_(
            mkt_cap.between(
                mkt_cap.value(target_security) * 0.5, 
                mkt_cap.value(target_security) * 2
            )
        )
        .and_(country == country.value(target_security))
    )
)

# Define the target data using a dictionary to pull multiple data items
data_items = {
    'Name': bq.data.name(),
    'Price': bq.data.px_last(), 
    'Market Cap': mkt_cap
}

# Build and execute the request and display the results
request = bql.Request(universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)
df
```

### BQL for Equity Derivatives
- This notebook demonstrates several ways you can use BQL to perform equity derivatives analysis.
- **Topics:** Quickstart: BQL for Equity Derivatives; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Querying option data¶; Extracting current option data¶; Extracting current option greeks¶
- **APIs:** `bq.data.days_expire`, `bq.data.delta`, `bq.data.expiration_periodicity`, `bq.data.expire_dt`, `bq.data.gamma`, `bq.data.id_security_des`, `bq.data.implied_volatility`, `bq.data.ivol`, `bq.data.open_int`, `bq.data.pct_moneyness`, `bq.data.put_call`, `bq.data.px_last`, `bq.data.px_volume`, `bq.data.strike_px`

```python
universe = (
    bq.univ.options("MSFT US Equity")
    .filter(
        (
            (bq.data.put_call() == 'Call')
            .and_(bq.data.pct_moneyness() > 100)
        )
        .or_(
            (bq.data.put_call() == 'Put')
            .and_(bq.data.pct_moneyness() < 100)
        )
        .and_(bq.data.open_int() > 100)
        .and_(bq.data.ivol() > 0)
    )
    .filter(bq.data.expire_dt().grouprank(order='asc') == 1)
)

data_items = {
    'Strike': bq.data.strike_px(),
    'Put/Call': bq.data.put_call(),
    'Open Interest': bq.data.open_int(),
    'Implied Volatility': bq.data.ivol(), 
    'Moneyness': bq.data.pct_moneyness(),
    'Expiry': bq.data.expire_dt()
}

# Build and execute the request
request = bql.Request(universe, data_items)
response = bq.execute(request)

data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

data.sort_values(by=['Strike'], inplace=True)
data.head()
```

```python
# Define universe 
universe = (
    bq.univ.options('AAPL US Equity')
    .filter(
        (bq.data.put_call() == 'call')
        .and_(bq.data.expiration_periodicity() == 'monthly')
        .and_(bq.data.days_expire() < '3m')
        .and_(bq.data.open_int() > 0)
    )
)

# Define the target data
data_items = {
    'ID': bq.data.id_security_des(),
    'Option Price': bq.data.px_last(),
    'Strike': bq.data.strike_px(),
    'Moneyness': bq.data.pct_moneyness(),
    'Put/Call': bq.data.put_call(),
    'Expiry': bq.data.expire_dt(),
    'Volume': bq.data.px_volume(),
    'Open Interest': bq.data.open_int()
}

# Build and execute the BQL query
request = bql.Request(universe, data_items)
response = bq.execute(request)

# Present the data as a pandas DataFrame 
data = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

# Display the first five rows
data.head()
```

### BQL for Equity Monitoring
- This notebook demonstrates several ways you can use BQL to monitor equities.
- **Topics:** Quickstart: BQL for Equity Monitoring; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Querying for multiple tickers¶; Monitoring analyst recommendations¶; Single security consensus history¶
- **APIs:** `bq.data.calendar`, `bq.data.classification_name`, `bq.data.contributor_revisions`, `bq.data.cur_mkt_cap`, `bq.data.dividends`, `bq.data.eqy_rec_cons`, `bq.data.expected_report_dt`, `bq.data.id`, `bq.data.is_comp_eps_adjusted`, `bq.data.is_eps`, `bq.data.name`, `bq.data.num_insider_shares_purch`, `bq.data.num_insider_shares_sold`, `bq.data.pct_chg_insider_holdings`

```python
universe = bq.univ.members('B500 Index')

eps = bq.data.is_eps(
    fa_adjusted='y', fa_period_type='q', fa_period_offset='1'
)

rev_up = bq.data.contributor_revisions(
    data_item=eps, revision_type='numup', revision_window='1w'
)
    
rev_down = bq.data.contributor_revisions(
    data_item=eps, revision_type='numdn', revision_window='1w'
)

data_items = {
    'Name': bq.data.name(), 
    '% Positive Revisions (1W)': (rev_up / (rev_up + rev_down)) * 100,
    'Consensus EPS Change (1W)': (
        eps.with_updated_parameters(dates=bq.func.range('-1w', '0d'))
        .dropna()
        .pct_chg()
    ),
    'Price Change (1w)': (
        bq.data.px_last(dates=bq.func.range('-1w', '0d')).dropna().pct_chg()
    ),
    'Sector': bq.data.classification_name(
        classification_scheme='bics', classification_level='1'
    )
}

# Build and execute the request
request = bql.Request(universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df.sort_values('% Positive Revisions (1W)', ascending=False)
```

```python
# Define actual and estimated EPS data 
eps_actual = bq.data.is_comp_eps_adjusted(
    fa_period_type='q', 
    fa_period_offset=bq.func.range('-10','0'), 
    fa_filing_status='lr', 
    fa_act_est_data='a'
)

release_date = eps_actual['revision_date']

eps_estimate = bq.data.is_comp_eps_adjusted(
    fa_period_type='q', 
    fa_period_offset=bq.func.range('-10','0'), 
    fa_filing_status='lr', 
    fa_act_est_data='e'
)

universe = 'AAPL US Equity'

# Define the required data items, including rolling 1-day price change
data_items = {
    '1D Price Change': (
        bq.data.px_last(dates=bq.func.range('-3y', '0d'))
        .pct_diff()
    ),
    'Surprise': ((eps_actual - eps_estimate) / eps_estimate) * 100, 
    'release_date': release_date
}

# Build and execute the request 
request = bql.Request(universe, data_items, with_params={'fill': 'prev'})
response = bq.execute(request)

# Get price data and shift revision date to get price change on the 
# day after release
df_price = response[0].df()
df_price['REVISION_DATE'] = df_price['DATE'].shift(1)

# Pull surprise data and merge with price change data 
df1 = response[1].df()

df_merged = (
    df1
    .merge(
        df_price[['REVISION_DATE', '1D Price Change']],
        on=['REVISION_DATE'],
        how='left'
    )
)
df_merged
```

### BQL for Factor Exposures
- This notebook is designed to show off several ways you can use BQL to perform factor exposure analysis.
- **Topics:** Quickstart: BQL for Factor Exposures; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying factor exposure for a single stock¶; Specifying dates¶; Querying factor exposure for multiple stocks¶; Screening with factor exposure¶
- **APIs:** `bq.data.factor_exposure`, `bq.data.id`, `bq.data.name`, `bq.func.range`, `bq.univ.holdings`, `bq.univ.members`

```python
fund_list  = ['QQQ US Equity', 'SPY US Equity', 'VLUE US Equity']

def build_bql_request(fund):
    """
    Constructs a single BQL request for factor exposures for each fund.
    """
    universe = bq.univ.holdings(fund)

    # Create dictionary for factor names and parameters 
    factors = {
        'Value': 'value',
        'Size': 'size',
        'Momentum': 'momentum',
        'Quality': 'quality',
        'Volatility': 'vol',
        'Growth': 'growth',
        '30D Idiosyncratic Return': '30d_idiosync_ret'
    }

    # Get grouped weights
    wgts = bq.data.id()['WEIGHTS'].group()

    # Use dictionary comprehension to construct the data_items dictionary.
    # For each label and corresponding factor name in factors:
    # - Retrieve the factor exposure data
    # - Group it appropriately
    # - Compute the weighted average using the fund weights
    data_items = {
        name: (
            bq.data.factor_exposure(factor_name=factor)
            .group()
            .wavg(wgts)
        )
        for name, factor in factors.items()
    }

    params = {'mode': 'cached'}
    request = bql.Request(universe, data_items, with_params=params)
    return request
```

### BQL for Idea Generation
- This notebook demonstrates several ways you can use BQL to perform equity idea generation.
- **Topics:** Quickstart: BQL for Idea Generation; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Screening stocks¶; Screening the equities universe based on fundamental data¶; Screening index constituents based on technical indicators¶
- **APIs:** `bq.data.classification_name`, `bq.data.country_full_name`, `bq.data.cur_mkt_cap`, `bq.data.earn_yld`, `bq.data.factor_exposure`, `bq.data.gross_margin`, `bq.data.id`, `bq.data.macd`, `bq.data.name`, `bq.data.net_debt_to_ebitda`, `bq.data.pe_ratio`, `bq.data.px_last`, `bq.data.return_com_eqy`, `bq.data.rsi`

```python
# Define scores
value_score = bq.data.earn_yld().groupcut(n=10)
roe_score = bq.data.return_com_eqy().groupcut(n=10)

last_yr_sales = (
    bq.data.sales_rev_turn(fa_period_offset='-1', fa_period_type='A')
)
this_yr_sales = (
    bq.data.sales_rev_turn(fa_period_offset='0', fa_period_type='A')
)
growth_score = (this_yr_sales - last_yr_sales).groupcut(n=10)

# Add negative as lower is better
leverage_score = (-bq.data.net_debt_to_ebitda()).groupcut(n=10)

total_score = value_score + roe_score + growth_score + leverage_score

# Return members where the total score is > 30
universe = bq.univ.members('WORLD Index').filter(total_score > 30)

# Define target data items
data_items = {
    'Name': bq.data.name().groupsort(sortby=total_score), 
    'Earnings Yield': bq.data.earn_yld(),
    'Return on Equity': bq.data.return_com_eqy(), 
    'Last Yr Sales': last_yr_sales,
    'Current Sales': this_yr_sales
}

# Build and execute the BQL query, filling data with previous values
request = bql.Request(universe, data_items, with_params={'fill': 'prev'})
response = bq.execute(request)

# Present the data as a pandas DataFrame
df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

df
```

```python
# Define the starting universe, screening the B500 Index for
# selected data items and the top 10 stocks by total return

universe = (
    bq.univ.members('B500 Index')
    .filter(
        (bq.data.px_last() > bq.data.smavg(period=200))
        .and_(bq.data.smavg(period=50) > bq.data.smavg(period=200))
        .and_(bq.data.rsi() < 70)
        .and_(bq.data.macd() > bq.data.macd()['signal'])
    )
    .top(n=10, sortby=bq.data.total_return())
)

# Define the target data items to return using a dictionary to label 
# the columns
data_items = {
    'Name': bq.data.name(),
    'Price': bq.data.px_last(),
    '200-day Moving Average': bq.data.smavg(period=200),
    '1Y Total Return': bq.data.total_return()
}

# Build and execute the BQL query, filling data with previous values
request = bql.Request(universe, data_items, with_params={'fill': 'prev'})
response = bq.execute(request)

# Present the data as a pandas DataFrame
df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response],
    axis=1
)

# Show the top 10 stocks by total return
df.sort_values('1Y Total Return', ascending=False)
```

### BQL for Alternative Data
- This notebook demonstrates several ways you can use BQL to perform alternative data analyses using Bloomberg Second Measure transaction data, Placer.ai foot traffic data, and Similarweb web traffic data.
- **Topics:** Quickstart: BQL for Alternative Data; Open an interactive version; Table of contents¶; About alternative data¶; Bloomberg Second Measure (US Transaction Data)¶; Placer.ai (US Foot Traffic Data)¶; Similarweb (Global Web Traffic Data)¶; Setting up your environment¶
- **APIs:** `bq.data.average_transaction_value`, `bq.data.estimated_visits`, `bq.data.is_comp_sales`, `bq.data.name`, `bq.data.observed_sales`, `bq.data.observed_transactions`, `bq.data.observed_unique_customers`, `bq.data.sales_per_customer`, `bq.data.transactions_per_customer`, `bq.data.web_traffic_visits`, `bq.func.range`, `bq.func.rsq`, `bq.univ.members`

```python
# Define the target universe, multiple securities, using several ID types
universe = [
    'CMG US Equity',  # Bloomberg Ticker
    'US8552441094',   # ISIN
    'BBG000BBNYF6',   # FIGI
]

# Define your target data
data_items = {
    'Name': bq.data.name(),
    'Transaction Spend': bq.data.observed_sales(),
    'Transaction Average Ticket': bq.data.average_transaction_value(),
    # Foot Traffic Visits from placer.ai
    'Foot Traffic Visits': bq.data.estimated_visits(),
    # Web Traffic data from Similarweb
    'Web Traffic' : bq.data.web_traffic_visits() 
}

# Build the query and execute the request
request = bql.Request(universe, data_items)
response = bq.execute(request)

# Concatenate all columns in the response, not just the named data item
# columns
df = pd.concat(
    [data_item.df() for data_item in response],
    axis=1
)
# Drop duplicated metadata columns
df = df.loc[:, ~df.columns.duplicated()]
# Also drop SOURCE and CURRENCY columns
df.drop(columns=['SOURCE', 'CURRENCY'])
```

```python
universe = 'DRI US Equity'

last_three_periods = bq.func.range(start='-2', end='0')

data_item = {
    'Olive Garden': bq.data.observed_unique_customers(
        brand='Olive Garden',
        fa_period_offset=last_three_periods,
        fa_period_type='Q'
    ),
    'LongHorn Steakhouse': bq.data.observed_unique_customers(
        brand='LongHorn Steakhouse',
        fa_period_offset=last_three_periods,
        fa_period_type='Q'
    ),
    # Escape the quote by using `\\'` and surrounding everything
    # in double quotes
    "Ruth's Chris Steak House": bq.data.observed_unique_customers(
        brand="Ruth\\'s Chris Steak House",
        fa_period_offset=last_three_periods,
        fa_period_type='Q'
    )
}

request = bql.Request(universe, data_item)
response = bq.execute(request)

df = pd.concat(
    [data_item.df() for data_item in response],
    axis=1
)
df = df.loc[:, ~df.columns.duplicated()]
df = df.drop(columns=['SOURCE', 'BRAND'])
df
```

