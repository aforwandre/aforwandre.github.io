---
topic_id: "27"
title: ETF Spread Monitoring Runtime Authority
role: project_runtime_authority
authority_for:
  - etf_spread_monitor_runtime
  - etf_spread_period_window
  - etf_spread_placeholder_source
not_authority_for:
  - bid_ask_field_signature
  - peer_universe_request
  - general_api_signatures
evidence_grades:
  - practice-derived
risk_tier: high
routing_keywords:
  - ETF Spread
  - bid-ask
  - share class
  - placeholder
  - Custom period
mandatory_cross_checks:
  - 00-RAG-INDEX
  - 18-using-pandas
  - 23-bql-substitution-due-diligence
restricted_sections: []
source_families:
  - workspace_policy
---

# ETF Spread Monitoring Runtime Authority

## Retrieval card (route card)

This is the **highway** for ETF Spread Monitoring. The destination is a
Desktop app that compares historical bid-ask spreads for a configured set
of ETF share classes with a peer series, and redraws the table and the
line chart when the period changes.

Follow this card. Do not wander `02` loan-quote examples, `09` / `11`
tutorials, or `22` description similarity. `BUNDLE_EXAMPLES.md` may lend
the Update-only `MAIN` shape (`main_update_only`). It is not a second
highway, and it does not supply a quote field.

Code lives under `User scripts/ETF Spread Monitoring/`. The live list of
ETFs and share classes will be `etf_spread/config.py` only. The rows
shipped with the skeleton are samples.

Product scope for the skeleton was set on 2026-10-22: about 54 ETFs and
80-plus share classes, fixed periods plus a custom period, a table, and a
line chart. That scope does not approve a data item.

## Authority split

| Claim | Owner | Not owner |
|---|---|---|
| Period keys, as-of date, placeholder formula, Update-only `MAIN` | **this file** | `25` last-price rules; `26` OHLCV range |
| Arrow `DATE` once a real history pull exists | `18` | this file |
| Quote-field or peer-field substitution | `23`, then a signed section on **this file** | `22` spelling; catalog-similar `spread()` |
| AIM positions, company capping, Thai pricing | `25` | this file |
| Widgets, observers, in-place `FigureWidget` | `09` usage only | `09` is not a BQL source |

## What this card freezes

Practice-derived from the 2026-10-22 skeleton. These choices are about the
app shell. They are not a Bloomberg request.

- Universe, labels, listing tickers, currency, and peer-group ids come
  from `SHARE_CLASSES` in `config.py`. `share_class_id` is the book key.
  A listing ticker is display text until a later signed section makes it
  a pricing identity.
- `BOOK_SOURCE` and `PEER_SOURCE` default to `placeholder`. The Bloomberg
  source classes return an empty frame and a diagnostic. They do not build
  a request.
- One Refresh loads the cache for the selected Strategy. The tabs stay hidden until that click. Changing Strategy does not fetch until Refresh is clicked again. Period, share-class selection, and the Peer Average dropdown only slice that cache. They do not fetch again.
- Invalid quotes stay blank. The placeholder does not fill them with zero.
  A missing peer does not invent a line.
- `ask == bid` is a zero placeholder spread. `ask < bid` is blank
  (`crossed`). Non-positive or non-numeric quotes are blank (`missing`).
  This quote rule is reversible when the business formula is signed. It
  must not be replaced by `abs(ask - bid)`.
- The placeholder spread is `(ask - bid) / midpoint * 10000` when the
  quote is valid. The screen labels it as a placeholder bps figure.
- Sample rows in `SHARE_CLASSES` are not the live book. A disabled row is omitted from the placeholder fetch.
- The live book is `ISIN_BOOK`: one primary share class per fund, with `fund_name`, `isin`, the listing `ticker` such as `HSAX LN Equity`, and `order` such as `1`. The table follows that order. The same `fund_name` text is the group. One seed ISIN per fund name is sent through the 2026-10-22 HelpDesk share-class request. When one ISIN returns several listings, the typed ticker is the row that is kept. The company id is an umbrella filter only. It is not a pricing ticker and it is not a displayed company name.
- Peer funds are the rows in `etf_spread/peer_map.py`. Each row names one HSBC fund name, the same text as `IsinEntry.fund_name`, and one peer ISIN. Every share class of that fund uses the same peer list. Update resolves the peer ISIN to that fund's single primary share class, drops publication-currency lines that do not match `crncy()`, and keeps one ticker. A fund with more than one primary ISIN is skipped. No benchmark screen is sent.
- Do not add a parser version constant until the first Desktop pull is
  frozen and `bundle_examples_registry.json` has a reviewed row.
- No ESG, GHG, climate, or sustainable-finance item, including as a peer
  or mapping key.

Placeholder history is a Mon–Fri calendar ending on the latest weekday on
or before the refresh date. It is not an exchange calendar. The loaded
length is `HISTORY_BUSINESS_DAYS` (1400), which covers the `5Y` preset.
A custom start before the loaded minimum is reported and is not backfilled.

## Periods and as-of date

```python
PERIOD_KEYS = ("1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y", "Custom")
```

The as-of date is the last completed weekday (Monday–Friday) before today.
Today's realtime quote is not the end date. One-off exchange holidays are
not filtered; the schedule is Monday to Friday and each weekday uses that
day's bid and ask for the spread, and that day's mid for the spread percent.
The period figure is the average of those daily values. A weekday with no
quote keeps the previous bid, ask, and mid together, which keeps funds with
different market holidays on the same schedule. The quote request itself
has no `fill`.

Preset windows end on that as-of date. `1M`, `3M`, `6M`, `1Y`, `3Y`, and
`5Y` step back with a calendar offset. `YTD` starts on 1 January of the
as-of year. `Custom` uses the two date pickers, inclusive. A weekend
endpoint is kept as a bound; rows are ordinary date filters. Do not call
`busday_offset` on a picker value. A start after the end returns an empty
table and an empty chart with a diagnostic.

A period change updates the summary table and the line chart from the same
view. Create the `FigureWidget` once and replace its traces inside
`batch_update()`. Bind observers once.

## Unresolved: bid, ask, and peer requests

The ETF Spread quote items are user-confirmed for the validation build on 2026-10-24; the FLDS BQL tabs and the returned values are recorded in the first Desktop validation run.

Catalog spelling on 2026-07-25 (`22`) is not approval. Census rows for
`px_bid`, `px_ask`, `px_mid`, and `spread` are uncurated. `02` shows
`px_bid` on loan and bond examples. `spread()` appears there as a credit
spread, including OAS. None of those recipes is this app.

The operator selected the quote fields `PX_BID` / `PX_ASK` / `PX_MID` /
`PX_LAST` on 2026-10-22 and re-confirmed the selection in chat on
2026-10-24. The validation request uses bare quote items on the typed
listing ticker, `dates=bq.func.range("-5y", "0d")` with
`mode="cached"`, no `fill`, and batches of 8. Those requests go out
through `execute_many` in waves of 8. The two-minute Desktop limit in
`05` is one request, not the whole Refresh. Quote history, total return,
and fund flow stay separate requests and share one wave. Copying `25`'s
`fill="prev"` or `26`'s OHLCV range is still not this request. The
operator's spread is `PX_ASK - PX_BID`; spread % is that difference over
`PX_MID` times 100. This is user-confirmed validation scope, not proof
of entitlement, units, or signature semantics; the first Desktop run
must still record the FLDS tabs and the returned values.

Before any request is added, record a `23` decision with the FLDS BQL tab,
the item signature, entitlement, equity-versus-credit universe, currency,
fill, history bounds, batch size, and failure behavior. Re-run that review
for every candidate, including a user-supplied one.

User-named candidates on 2026-10-22, reviewed and left **Unresolved**:

```text
Decision ID: ETF-SPREAD-QUOTES-2026-10-22
Date: 2026-10-22
Project: ETF Spread Monitoring
Source field/API: operator-named PX_BID, PX_ASK, AVERAGE_BID_ASK_SPREAD
Business role: equity ETF quote and a vendor average spread
Candidate: px_bid(), px_ask(), average_bid_ask_spread()
Class: D for the first two, ? for the average
Evidence: 22 spelling only for all three. px_bid / px_ask census is
  uncurated and the worked calls are loan, bond, and FX/futures demos.
  average_bid_ask_spread has no census row and no signature.
  The FUNDS taxonomy dump is OCR-observed and says its own signatures
  are not established. Its keyword tables are partial and are not a
  runnable classifier.
Exact catalog result: px_bid() Bid Price; px_ask() Ask Price;
  average_bid_ask_spread() Average Bid Ask Spread. Spelling only.
Signature/universe result: not resolved for an equity ETF universe.
Entitlement and batch scope: not resolved. Do not probe.
Identity layers: ISIN list is the operator's book key. Parent fund is
  grouping. Listing ticker is not yet pricing identity. AUM would rank
  the main share class only after a signed assets field.
Fallback: no request. Pandas may compute ask minus bid when both quotes
  are already on a frame. Missing and crossed quotes stay blank.
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence):
  4 / 4 / 4 / 2 / 4 / 4
Counter-evidence: credit px_bid recipes are a different universe.
  average_bid_ask_spread_pct() is a different item. Official taxonomy
  universe fundsuniv(("active","primary")) keeps a primary listing,
  which is not "every share class".
Rejected alternatives: spread() as a bid-ask measure; copying the OCR
  keyword classifier; inventing a parent fund from the ISIN text.
User confirmations: absolute spread means ask minus bid. Peer display
  is median, average, high, and low. Peer membership uses the main
  share class (largest assets) only. ISINs will be typed into the app.
  None of these confirm a data-item signature.
Decision: Superseded by the operator confirmation on 2026-10-24; validation run only.
Required tests: first Desktop run record; the static allowlist now contains these items.
```

The pandas formula the operator stated is ask minus bid. That formula is
allowed on a frame the app already holds. It does not authorize the request
that would fill the frame.

The taxonomy and flow views may draw a treemap or a heatmap only from
columns already on a frame: asset class, geography, a segment supplied on
the row, fund, size, date, category, and flow. They must not reconstruct
`classify()` from the partial OCR keyword lists.

```text
Decision ID: ETF-SPREAD-FER-2026-10-22
Date: 2026-10-22
Project: ETF Spread Monitoring
Source field/API: operator-named FUND_EXPENSE_RATIO
Business role: compare one fund's expense ratio with peer median, average, high, and low
Candidate: fund_expense_ratio()
Class: ?
Evidence: 22 spelling. Description is "Expense Ratio". On 2026-10-22 the
  operator checked that the item returns a number. No separate gross/net
  parameter was named. This request uses the same ['value'] form as the
  other items in the HelpDesk share-class request.
Exact catalog result: fund_expense_ratio() | Expense Ratio. Spelling only.
Signature/universe result: fund_expense_ratio()['value'] on the active
  share-class universe. Gross versus net remains unlabeled.
Entitlement and batch scope: same share-class request, batches of 8.
  Do not send it as its own probe.
Identity layers: the ratio stays on the share-class row. It is not a
  price and not the fund group.
Fallback: a missing or non-numeric ratio stays blank. Do not substitute
  another expense or fee item. Do not fill it with zero.
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence):
  2 / 2 / 2 / 2 / 2 / 2
Counter-evidence: catalog-similar fee and average-asset items are
  different rows. None is a substitute.
Rejected alternatives: any other expense or fee mnemonic not named here.
User confirmations: 2026-10-22, the operator checked that
  fund_expense_ratio returns a number. A 0.3 percent ratio is displayed
  as 0.3, not 0.003. Do not rescale it.
Decision: Guarded approval on the share-class request only
Required tests: the item is in the approved call set. A non-numeric
  result stays blank. 0.3 stays 0.3.
```

```text
Decision ID: ETF-SPREAD-SHARE-CLASS-2026-10-22
Date: 2026-10-22
Project: ETF Spread Monitoring
Source field/API: operator-named FUND_SHR_CLASS_DESG
Business role: display name of one share class under the typed fund name
Candidate: fund_shr_class_desg()
Class: ?
Evidence: 22 spelling only. Description is "Fund Share Class Designation".
  No census row, no parameter list, and no tutorial call.
Exact catalog result: fund_shr_class_desg() | Fund Share Class Designation.
  Spelling only.
Signature/universe result: not resolved for an ISIN equity-ETF universe.
Entitlement and batch scope: not resolved. Do not probe.
Identity layers: the typed fund name is the group. The ISIN is the share
  class. This item would be the designation label, not the group key and
  not a price.
Fallback: leave the designation blank. Do not parse it out of the ISIN
  or the fund name. Do not substitute name().
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence):
  4 / 2 / 2 / 2 / 4 / 4
Counter-evidence: name() is a different item. A catalog description is
  not a signature.
Rejected alternatives: name() as the share-class designation.
User confirmations: the share-class label is this item. The operator
  still types only fund name and ISIN. This does not confirm the signature.
Decision: Unresolved
Required tests: no request for this item until this decision is Approved.
```

```text
Decision ID: ETF-SPREAD-CURRENCY-2026-10-22
Date: 2026-10-22
Project: ETF Spread Monitoring
Source field/API: operator-named CRNCY
Business role: display the share-class pricing currency next to the typed fund name and ISIN
Candidate: crncy()
Class: D
Evidence: 22 spelling "Currency". 08 syntax is crncy() with no value key.
  The FUNDS taxonomy dump photographs crncy()['value']. That dump says its
  signatures are not established. The two forms conflict.
Exact catalog result: crncy() | Currency. Spelling only.
Signature/universe result: not resolved. Do not choose between the bare
  call and the value key.
Entitlement and batch scope: not resolved. Do not probe.
Identity layers: currency is a display attribute of the ISIN. It is not
  the fund group, not the share-class designation, and not an asset class.
Fallback: leave currency blank. Do not parse a currency out of the fund
  name. Do not use this item to classify the holding.
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence):
  2 / 2 / 2 / 2 / 4 / 4
Counter-evidence: crncy() is prohibited as an ETF holding classifier on
  card 25. The OCR value-key form conflicts with 08.
Rejected alternatives: using crncy() to decide equity versus cash; copying
  the photographed value key before the conflict is resolved.
User confirmations: after the fund name and ISIN are typed, the script
  should fill the share-class currency from this item. This does not
  resolve the value-key conflict.
Decision: Approved for bare `bq.data.crncy()` on the share-class request. It is the display currency from `08`. Do not use `['value']`. Do not use it to classify a holding.
Desktop addendum 2026-10-30: on the peer listing, the same bare call returned columns `ID` and `CURRENCY` only. That `CURRENCY` column is the share-class currency. Treating it as metadata raised `no single value column` and the exception discarded every peer. Do not repeat that parse. One failed listing batch stays a note.
Required tests: a missing currency stays blank and does not stop the other columns. A peer listing item named Currency with only `ID` and `CURRENCY` becomes the share-class currency and does not raise.
```

```text
Decision ID: ETF-SPREAD-SHARE-LIST-2026-10-22
Date: 2026-10-22
Project: ETF Spread Monitoring
Source field/API: HelpDesk sample for the linked share-class list
Business role: list active share classes under one typed fund name
Candidate: id_bb_company()['value']; fundsuniv("active") filtered by that
  id; id()['value']; name()['value']; fund_comp_name()['value'];
  fund_open_shr_class()['value'];
  id_isin()['value']; with_params mode cached and showids f on the
  second request only
Class: D for the items, U for fundsuniv
Evidence: user-supplied HelpDesk reply dated 2026-10-22, inquiry
  H#1340912719. The sample starts from one ETF id, reads the umbrella
  id, then lists active share classes. 22 confirms the item spellings.
  01 says a list universe accepts an ISIN, so the seed id is the first
  ISIN typed for that fund name.
Exact catalog result: id_bb_company() Bloomberg Company Identifier;
  fund_open_shr_class() Open-end Share Class; id_isin() ISIN Number;
  name() Name; id() Returns the universe.
Signature/universe result: use the sample forms, including ['value'].
  fundsuniv takes "active" only. Do not add primary to that call.
Entitlement and batch scope: one seed and one share-class request per
  typed fund name, in batches of 8. Do not drop the company filter.
Identity layers: the typed fund name is the group. The company id is
  only the umbrella filter. The returned ticker is not a price. This
  does not authorize id_bb_company() as a pricing ticker or as the
  capping company key.
Fallback: a fund with no umbrella id is skipped and named in the
  diagnostic. The share-class table stays empty for that fund. Do not
  download an unfiltered fund universe.
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence):
  2 / 1 / 2 / 2 / 2 / 2
Counter-evidence: tutorial fundsuniv('ACTIVE', 'PRIMARY') keeps a
  primary listing. The photographed taxonomy universe is not this
  request. fund_shr_class_desg() was the earlier operator name and is
  not the sample field.
Rejected alternatives: fund_shr_class_desg() in this request; adding
  primary to fundsuniv; using the company id as a ticker.
User confirmations: the operator asked for the full share-class list
  and the primary share class, and for fund-level and share-class AUM.
  The sample answers the linked list only. On 2026-10-22 the operator
  added fund_comp_name() for the peer-list company name. Catalog
  description is "Fund Company Name". It uses the same ['value'] form.
  The typed fund name remains the group key.
Decision: Approved for this request shape only
Required tests: one seed per fund name; empty book and missing bql do
  not raise; a missing umbrella id does not widen the universe.
```

```text
Decision ID: ETF-SPREAD-FUND-FLOW-2026-10-23
Date: 2026-10-23
Project: ETF Spread Monitoring
Source field/API: operator asked for the official taxonomy and fund-flow heatmap on a second tab, with periods 1M, 3M, 6M, YTD, 1Y, 3Y, and 5Y. ASKB is not on this account.
Business role: net fund flow, USD millions, for the typed book only. The heatmap groups rows that are already on the book. It does not classify fund names.
Candidate: bq.data.fund_flow(dates=bq.func.range(start, end), currency='USD')
Class (U/D/M/P/C/L/X/?): D
Evidence: 22 spells fund_flow() as Fund Flow. 11 requests fund_flow(dates=bq.func.range(...), currency='USD') and sums that window. 07 range() accepts absolute YYYY-MM-DD and defaults a data range to daily. The official taxonomy file's fund_flow_sum reading is an OCR conflict and is not used.
Exact catalog result: fund_flow() Fund Flow. fund_flows() has an empty catalog description and is not used.
Signature/universe result: dates=range(start, end) and currency='USD' on the typed ticker list. Cached. No fill. The tutorial's .sum() is left off so each day remains; pandas then sums a week or a calendar month. A response with no DATE is discarded.
Entitlement and batch scope: the same fund-item family already used for this book. Typed tickers only, batches of 8. Not a market-wide fund universe.
Identity layers: the typed listing ticker is the flow id. ISIN is not the request id. The company id is not a flow id.
Fallback: a failed batch is named and skipped. A blank cell stays blank. Cells are not zero-filled. Flow percent is not drawn, because the showcase start-cap formula was not legible and cur_mkt_cap is not added for it.
Risk scores (Entitlement/Semantics/Breadth/Identity/Failure/Evidence): 2 / 1 / 2 / 1 / 1 / 2
Counter-evidence: the taxonomy photo conflicts fund_flow().sum() with fund_flow_sum(). The tutorial always sums one window, so the unsquashed daily series is guarded.
Rejected alternatives: fund_flow_sum; fund_flows(); cur_mkt_cap as a flow-percent denominator; the keyword classifier; ASKB.
User confirmations: 2026-10-23, use 1M, 3M, 6M, YTD, 1Y, 3Y, and 5Y, and do not use ASKB. On 2026-10-29 the operator confirmed, from the official ETF Taxonomy script, that `fund_flow` is the fund figure. Share classes of one fund are not added.
Decision: Guarded. One five-year daily pull. The dropdown only slices it. 1M and 3M sum by week. The other five sum by calendar month.
Required tests: empty tickers and missing bql do not raise; a repeated ticker is one flow; a blank group is left out; a missing bucket stays blank; a zero stays zero.
```

The ETF Taxonomy tab is a separate universe from the HSBC book. It loads primary ETFs on one exchange. Market cap uses `cur_mkt_cap(currency=, fill="prev")` without `.znav()`. Trailing flow uses `fund_flow(dates=range(...), currency=).sum()`. The heatmap rolls that sum. Keyword theme tables and ASKB are not copied. Flow% is net flow divided by start market cap, in percent, and stays blank when the start cap is missing or not positive.

A Bloomberg assistant reply is not a signature. When it conflicts with this card, this card stays. The book Strategy key is the text typed on `IsinEntry`, not `fund_strategy()`; it is not a table column and only drives the top dropdown and the fund menu.

The HSBC book benchmark column is `long_comp_name()['value']` of the index id built from `fund_benchmark_prim()['value']`. `etf_undl_index_ticker()` is not the display source and is not a peer predicate. Peer membership is `etf_spread/peer_map.py`, keyed by the same fund name as `IsinEntry.fund_name`. Each peer ISIN is resolved with `id_bb_company()['value']` and `fundsuniv(("active", "primary"))` filtered by that company, then one listing request on the unique primary ISIN. A fund is kept only when that primary list has exactly one ISIN. Publication-currency lines stay only when response `CURRENCY` equals `crncy()`; otherwise they are dropped, and one ticker remains per primary ISIN. `fund_benchmark()` remains on the unused Bloomberg Global showcase request only. `fund_strategy()` is not the peer key. `univ.peers` is not this screen. There is no 200-name cap on the hand-written list. The typed Strategy text is the Strategy dropdown above the tabs, not a BQL predicate. Fund choices on the HSBC ETF tab and on Peers Details follow that Strategy. Fund AUM is `fund_total_assets(currency='USD')` divided by one million. A Desktop print of that item was full dollars, not millions. Expense ratio stays on the vendor scale. `average_bid_ask_spread_pct(dates=range(...))` returned a daily series, not one window average, and is not the period formula. Period buttons, Custom, the Spread and Return checkboxes, and the Peer Average dropdown redraw the cached history and do not send a request. Total return uses `tot_return_index_gross_dvds(dates=range("-5y","0d"), currency="USD", fill="prev")` for the ETF, its peers, and its benchmark. It is not `px_last`. NAV Return is a separate cached request on those same identifiers: `fund_net_asset_val(dates=..., currency="USD", fill="prev")`. Catalog spelling is `fund_net_asset_val()` (Net Asset Value). `currency="USD"` is the sample-notebook argument. The percent is the same pandas `(end / start - 1) * 100`. The NAV Return checkbox sits between Return and Peer Average and starts on. It adds the NAV percent columns and a third chart. The NAV table and the NAV chart use that same Bmk Return column. There is no Bmk NAV Return column, and the benchmark index is not on the NAV request. A failed NAV batch does not blank the total-return history. The benchmark id is `fund_benchmark_prim()['value']` with ` Index` appended when that suffix is absent. Return percent is `(end level / start level - 1) * 100`. The start and end are the HSBC listing's quote dates: the last quote on or before each window edge, or the fund's first quote when that quote falls inside the window. A London holiday is not a peer or benchmark session. The value used is the last print on or before the HSBC quote date. A later print is not used. When Return is on, each selected period adds `Bmk Return %` and the return chart draws that line. The Flows tab uses one row per fund name in both show modes, and the heatmap rows keep the typed IsinEntry order, the same order as the HSBC ETF tab. Heatmap row labels are the long name of the kept share class; when two funds share one long name, each label is qualified with the typed fund name so the heatmap keeps one row per fund instead of collapsing them. The official ETF Taxonomy fund-flow drill requests `fund_flow` on a primary ETF universe and does not request a share-class flow. This screen keeps one listing ticker per fund, the Primary Yes row when that row is present, and does not add the other share classes. HSBC + Peers adds the peer funds' flows onto that line. The Fund menu redraws the heatmap from the cache. A ticker on both sides of the same fund counts once. It does not draw the taxonomy treemap.

Tracking error on the HSBC book is shown in two columns. Peers Details repeats those columns for each primary HSBC row. A peer row leaves Peer Avg blank. Last, fund assets, class assets, both tracking errors, and the benchmark name are loaded with the same request families as the HSBC book, on that peer's ticker or primary ISIN. The peer profile request still returns `fund_strategy()`, and that value is not displayed. Bmk Return on a peer row is that peer's own benchmark, not the HSBC benchmark. Its own spread and return still come from the history Refresh already loaded. A failed peer-facts batch leaves that column blank and does not clear the HSBC book or the peer spread and return already loaded. On Peers Details an HSBC row is bold and its fund-name cell is tinted. Number cells do not take a color expression, because attaching one has blanked values on this Desktop. ``Tracking Error`` is `tracking_error()['value']` on the typed ticker, in its own cached request; it is the PX_LAST-based number. ``NAV Tracking Error`` is `nav_tracking_error()['value']` in a second cached request; the catalog row is ``Net Asset Value Tracking Error`` and the operator confirmed on 2026-10-24 that the FLDS tab lists it and returns numbers. Both are converted to percent on screen (vendor value x100) and the headers are `1Y Tracking Error (%)` and `1Y NAV Tracking Error (%)`; the underlying data frame keeps the vendor number and the display helper multiplies it. The latest quote spread headers are `Latest Spread` and `Latest Spread %`. Period average headers stay `Avg Spread` and `Avg Spread %`. A failed batch leaves that column blank and does not drop the quotes.

The first tab is named HSBC ETF. Its table shows exactly the typed `ISIN_BOOK` rows, in typed order. A linked share class that is not typed is dropped, a typed line is never swapped for another class of that fund, and a typed line Bloomberg did not return keeps its typed identity with blank enrichment. There is no Primary Share only checkbox. Spread and Return default on. The third tab is Peers Details: each selected fund's typed `ISIN_BOOK` row, then that fund's primary peers. The HSBC anchors keep the typed IsinEntry order, the same order as the HSBC ETF tab. The HSBC rows are the typed lines; the peer rows are their primary peers. Its table follows the HSBC ETF Spread, Return, and Custom choices. The period buttons above both tables are the only standard-period control and share one open or closed state, so one press redraws both tables. Fund Info sits to the left of those buttons and starts open. Closing it hides Class Name, ISIN, Currency, Class AUM, PX_LAST, PX_BID, PX_ASK, Benchmark, and Primary on both tables. Fund Name and Fund AUM stay. Clicking a row on HSBC ETF plots the cached series for the selected mode: spread percent, return, or both charts stacked. The spread chart draws Spread % and Peer Avg Spread % only. The return chart draws Return %, Peer Avg Return %, and Bmk Return %. The legend is one line per series, under the plot. Peers Details repeats those charts under its table and adds one line for each Top 5 Peer. Chart Period is shared and only slices the cache. Peers only averages the peer tickers. HSBC + Peers averages the selected ticker and those peers. A missing member is left out of the mean. Period columns are Avg Spread % and Peer Avg Spread %. The absolute period average is not calculated and is not a table column. Latest Spread stays. The percent average includes every peer. The chart sits under the table, and the table height follows the row count.

Still open, and not frozen here:

- snapshot quotes on the share-class request are bare `px_bid()`, `px_ask()`, `px_mid()`, and `px_last()`. Absolute spread is ask minus bid. Percent spread is that difference divided by the mid, then multiplied by 100. A blank PX_MID is (PX_BID + PX_ASK) / 2 on every spread-percent path. Return does not use PX_MID. A peer row reads that mid from the quote history, because the table has no Mid column. Book history repeats `px_bid`, `px_ask`, and `px_mid` with `dates=range("-5y", "0d")` and cached mode. The request has no `fill`. Averages carry the previous spread onto weekdays that have no quote;
- the profile request, one seed ISIN per typed fund, reads `fund_strategy()['value']` and `fund_benchmark_prim()['value']`. It does not request `etf_undl_index_ticker()`, `fund_geo_focus()`, `fund_industry_focus()`, or `exch_code()`. The book table does not show Geographic Focus, Industry Focus, or Exchange. `fund_asset_class_focus` is not requested;
- whether the vendor average is absolute, percent, or already a window;
- the expense ratio is `fund_expense_ratio()['value']`, the net ratio after waivers. Help Centre on 2026-10-29 prints 0.04 for a 0.04 percent ratio. 0.09 stays 0.09;
- a peer listing keeps the line whose response CURRENCY matches `crncy()`. Other publication-currency lines are dropped, then one ticker is kept per primary ISIN. Desktop on 2026-10-30 returned `crncy()` on that listing with columns `ID` and `CURRENCY` only; that `CURRENCY` column is the share-class currency. One listing batch that cannot be read is noted and skipped. It does not discard the other batches;
- the live ISIN list, typed into `ISIN_BOOK`;
- the primary column is Yes or No from `fundsuniv(("active", "primary"))` filtered by the same umbrella id. It is not a new data item;
- the benchmark column is `long_comp_name()['value']` of the index id built from `fund_benchmark_prim()['value']`, then `name()['value']`, then that index id. The name request uses that index id. `etf_undl_index_ticker()` is not requested for the column. The index id is `fund_benchmark_prim()['value']` with ` Index` appended when the suffix is absent. Return history uses the same id. An empty cell or an N/A token, including one with a trailing description, is not turned into an index id and is not requested. Shown fund names, including each share-class row, the peer row, the dropdown label, the chart legend, and the flow row label, prefer `long_comp_name()['value']` (operator, 2026-10-30). The typed fund name stays the join key for the peer map, the strategy filter, and the one flow line per fund. A blank long name falls back to `name()` or the typed fund name. Class Name stays `fund_open_shr_class()`. The item is on the share-class list, the peer listing, and the benchmark name request. It is not on the quote request;
- fund-level assets are `fund_total_assets(currency='USD')` on one listing ticker per fund, the Primary Yes row when that row is present, in a request that does not include quotes. The result is the full dollar amount, is divided by one million, and is copied onto each share class of that fund. Rows are not summed. `fund_total_assets_crncy()` is not a conversion rate and is not requested for this column. Request-level `with_params={'currency': 'USD'}` is not used, because that would also convert bid, ask, and last. Share-class assets are `fund_class_assets()` and are already in millions. They ride in the same cached typed-ticker request as the bare quotes. That request has no `showids` and no request-level currency. A USD row is unchanged. A non-USD row uses `{CCY}USD Curncy`, otherwise `USD{CCY} Curncy`. `fund_class_assets_crncy()` is used only for that check and is not displayed. A missing spot stays blank;
- averages use the Monday–Friday schedule. One-off exchange holidays are not filtered; a weekday with no quote keeps the previous spread;
- an empty cell, a zero quote, a zero level, a zero asset amount, or an N/A token with any trailing description is blank. The token may be `N/A`, `#N/A`, `N.A.`, `NA` followed by a note, or `Not available` / `Not applicable`. A zero fund flow, a zero expense ratio, and a computed return of zero stay zero. `NA US Equity` is not a missing token;

## App lifecycle

`MAIN.ipynb` displays the widgets only. Data loads when the user clicks
**Refresh**, beside Strategy. The three tabs stay hidden until that click.
The first status word is Idle in red before the first Refresh, Loading in the
original color while Refresh is running, and Refreshed in green when that
pull finishes. Changing Strategy or Max Data range after that pull sets the
word to Please Click Refresh in red until the next Refresh. A second line says
Environment: Processing while Refresh or a cache redraw is running, then
Environment: Idle. That line is red while Processing and green while Idle.
A published app does not show the notebook kernel indicator.
Charts and the flow heatmap are written onto the Output widget's `outputs`
trait. `display()` inside that widget is kept only for the original click,
so a timer used to paint Processing would otherwise leave the chart blank.
Do not call `load_on_start()`. Copying the MDX bootstrap here
would fire a fetch on every Kernel Restart.

The skeleton fetch is local placeholder data. It is still behind Refresh,
so the later Bloomberg adapter cannot run just because the kernel started.

After replacing `.py` on Desktop: Restart Kernel → Run All → Refresh.

## Local history cache (practice-derived, 2026-11-02)

The operator asked for the `28` month-snapshot pattern on the daily history
pulls, on the stated assumption that a settled print is not back-dated. This
is app code only: no new item, no request-width change, no entitlement.

- `Use cache` sits beside Max Data range and defaults on
  (`cache.CACHE_ENABLED`). One CSV per kind (`quotes`, `returns`, `navs`,
  `flows`) plus `manifest.json` under `cache/`, created only by a write.
- A row is settled when its date is **before the last completed London
  session** (`last_completed_london_day()`). Settled rows are written once;
  rows on or after that session are re-requested every run because that print
  can still move.
- Stored columns are the raw request output (`ID`, `DATE`, `Bid`, `Ask`,
  `Mid` / `Level` / `Flow`), never `Spread`, `Percent Spread`, the return
  percent, or the `/ 1e6` flow scaling. Those are computed after the merge by
  the existing `_finish_*` helpers, so a formula change still applies.
- `SERIES_CONTRACT` is derived from the stored column set; `CACHE_GENERATION`
  is the manual token for "the same columns, a wrong stored row". A third
  token, the **request fingerprint** (`data.history_request_token()`), is a
  hash of the executable source of the four builders plus `_history_date_range`
  and `_combine_items`. It is bound at import so a runtime stub cannot move it,
  and it strips docstrings and comments so prose edits do not discard a
  five-year series. All three must match the manifest or the file is ignored.
  Without the fingerprint, changing `px_bid` to another item, dropping
  `fill="prev"`, or changing a currency would keep the column name and replay
  a wrong row forever.
- Per-identifier coverage, not per-file. A late head or an early stop becomes
  its own absolute-date request, so no window is silently skipped and no gap
  is left between what is stored and what is asked for. The relative
  `range("-5y", "0d")` is sent only for a fund with no stored history at all.
  This is also what makes a book or peer-list change need no cache action: a
  newly added identifier has no coverage and gets its own full window; a
  removed one keeps its rows, because a narrower Strategy selection must not
  delete another Strategy's history. Never add a prune keyed on "the
  identifiers this run asked for".
- The identifier is bound to a security, not to a string. `manifest.json`
  carries an `identities` ledger, `{identifier: ISIN}`, written only for the
  identifiers a save actually rewrote. `data.share_class_identities()` builds
  this run's map from the book directory frame (`Ticker` + `ISIN`) and the peer
  link frame (`Ticker` + `Primary ISIN`), so no extra request is sent. A known
  mismatch drops that identifier's stored rows and forces a whole-window
  request; the status detail names it. A ticker re-pointed to another share
  class, a peer whose primary listing moved, and a reused ticker are all this
  one case, and every other check in `cache.py` (dates, columns, request hash)
  passes on them. Fail-open by design: a missing ISIN on either side — a
  benchmark index id, or a run whose profile pull failed — proves nothing and
  keeps the rows. Never write the ledger without rewriting that identifier's
  rows in the same call, or the next read would accept the old rows as the new
  security.
- The answer is trimmed to the requested window (`cache.trim_to_window`), so a
  `1Y` run after a `5Y` run cannot answer with five years of rows.
- Fail-closed but not fail-hard: a missing/unreadable/mislabelled/all-blank
  file reads as no cache; a write refusal or `OSError` is a status note, never
  a failed Refresh. Do not add parquet or `pip`.
- `Use cache` off re-requests the whole window and writes nothing, which is
  the recovery path for a suspected back-dated change.


## Minimum shippable package (one pass)

Rebuild the shell from **this file** + project `.mdc` + the Update-only
shape. Do not rebuild it from `02` or from `25` pricing.

| File | What this topic freezes | What it cannot invent |
|---|---|---|
| `etf_spread/config.py` | Period keys, sample share-class schema, placeholder sources, 1400-day cache | The live ETF list, peer membership, any data item |
| `etf_spread/data.py` | Placeholder book and peer frames; Bloomberg adapters that return a diagnostic | A Request, a parser version constant |
| `etf_spread/cache.py` | Settled daily rows by kind, contract and generation tokens, gap planning, merge | A formula, a request, parquet |
| `etf_spread/engine.py` | Period slice, placeholder spread, blank invalid quotes, peer rows as their own series | A BQL formula |
| `etf_spread/app.py` | Update-only; period and selection redraw the table and the chart together | A live Bloomberg session |
| `MAIN.ipynb` | Display, then wait for Refresh | `load_on_start()` |

**First Desktop success for this shell:** Restart Kernel → Run All →
Refresh → the live HSBC book rows and Data-as-of line → changing `1M` / `1Y`
/ `Custom` changes both the table and the line chart → the Bloomberg
source choices show a diagnostic and draw no fake series.

A later drop, after the quote section above is signed, replaces the
placeholder sources. That drop is not authorized by this shell.

## Desktop incidents (do not repeat)

Recorded 2026-10-30 after the first live Refresh of this book. HSBC rows had already loaded. The peer screen was empty until the listing parser was corrected. The operator then confirmed the peers appear.

- `crncy()` on the peer listing returned columns `ID` and `CURRENCY` only. The status line was `Peer list failed: BQL item 'Currency' has no single value column; columns=['ID', 'CURRENCY']`. `CURRENCY` is the share-class currency for that item. Do not treat it as metadata and raise. Do not let that exception discard every peer. One unread listing batch is noted and skipped. The book path stayed on `_combine_items` and is not this parser.
- A few `peer_map.py` fund names that differ from `IsinEntry.fund_name` skip those funds only. Capitals and internal spaces stay. A partial mismatch does not blank the matched funds, their Peer Avg cells, or their HSBC + Peers flow. When every peer is blank, look for this parse error before blaming the names. The displayed `long_comp_name` is not the join key.
- The benchmark column and `Bmk Return %` use one id: `fund_benchmark_prim()['value']`, plus ` Index` when that suffix is absent. The column shows `long_comp_name()['value']` of that id, then `name()['value']`, then the id. Do not display `etf_undl_index_ticker()` in that column, and do not request it on the profile.
- Max Data range sits beside Strategy and is read only on Refresh. The default is `1Y`. Choosing `5Y` keeps the quote and return request at `range("-5y", "0d")`. Every other choice, including the default, uses the same weekday window as the period buttons, as absolute dates, on the quote, return, and flow requests. After that Refresh, period buttons, Chart Period, and Flows Period only offer windows inside the pull. The share-class grid does not get smaller, because its rows are funds, not days. The flow heatmap grows by 28 pixels per fund row and widens the left margin with the longest fund name, so a later row is not dropped to fit a fixed height.

## Regression that belongs here

- [ ] Requests run only from Refresh. Period, Custom, and the Flow period or show mode read the cache.
- [ ] No parser version constant until the bundle registry is reviewed.
- [ ] `MAIN` does not call `load_on_start()`.
- [ ] As-of is the last completed weekday; a no-quote weekday carries the previous quote.
- [ ] Preset windows and Custom use the cached frame. A period change does not fetch.
- [ ] Invalid quotes stay blank. Crossed quotes stay blank. Values are not zero-filled.
- [ ] A Bloomberg source selection returns a diagnostic and an empty series.
- [ ] `ISIN_BOOK` is the only live book; the legacy `SHARE_CLASSES` samples are not shown.
- [ ] The typed listing ticker is the quote key. Peer history follows `peer_map.py`. There is no 200-name cap. Both tracking-error columns are present, NAV before PX_LAST.
- [ ] Peer listing `crncy()` with only `ID` and `CURRENCY` fills the share-class currency. It does not raise, and one bad listing batch does not drop the other batches.
- [ ] A peer-map name that is not exactly `IsinEntry.fund_name` skips that fund only. `long_comp_name` is not the join key.
- [ ] The benchmark column and `Bmk Return %` use the `fund_benchmark_prim` index id. The column is not `etf_undl_index_ticker()`.
