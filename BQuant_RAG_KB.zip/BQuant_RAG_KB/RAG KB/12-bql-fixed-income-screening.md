---
topic_id: "12"
title: BQL for Fixed Income Screening
role: domain_recipe
authority_for: [fixed_income_screening, credit_factor_examples]
not_authority_for: [catalog_exceptions, entitlement]
evidence_grades: [canonical, practice-derived]
risk_tier: normal
routing_keywords: [screening, OAS, rating, credit_factor, mortgages, TOMS]
mandatory_cross_checks: [00-RAG-INDEX, 02-bql-for-fixed-income, 08-bql-data-items, 18-using-pandas]
restricted_sections: []
source_families: [help_center, workspace_recipe]
---

# BQL for Fixed Income Screening

> CURSOR_BQNT production recipe — not a Help Center mirror.
> Companions: `02-bql-for-fixed-income.md`, `22-BQuant_DataItems.md`, `08-bql-data-items.md`, `11-sample-notebooks.md`.
> Field gate: `22` confirms exact data-item names; `08` owns meaning/metadata; FLDS is only for unresolved ambiguity/signatures.

---

## Purpose

Fixed-income screening: define a bond universe → attach spread/yield/rating fields → `univ.filter()` → group-prefix ranking → Pandas post-process. Introductory BQL syntax lives in `02-bql-for-fixed-income.md`.

```mermaid
flowchart LR
    A[Universe] --> B[Data items]
    B --> C[univ.filter]
    C --> D{Large?}
    D -->|Yes| E["cached Request"]
    D -->|No| F[Standard Request]
    E --> G[execute]
    F --> G
    G --> H[Pandas concat / isin diff]
    H --> I[Display / CSV]
```

```python
import pandas as pd
import bql
bq = bql.Service()

def to_df(response):
    return pd.concat([item.df()[item.name] for item in response], axis=1)
```

**ID rule:** identifiers are on `df.index`, not a `'ID'` column.

---

## Universe Sources

| Source | PyBQL | Use |
|--------|-------|-----|
| Active bonds | `bq.univ.bondsuniv('Active')` | Broad IG/HY scans |
| Index | `bq.univ.members('LUACTRUU Index')` | Benchmark-relative |
| Issuer chain | `bq.univ.bonds(['AAPL US Equity'])` | Single-name curve |
| Capital structure | `bq.univ.debt('PARA US Equity', issuedby='ENTITY')` | Entity vs subs |
| Backdated | `.members(..., dates='-1m')` | Point-in-time membership |

**Weights:** `bq.data.id()['weights']` (lowercase) with `members()`. Uppercase `'WEIGHTS'` only for `holdings()`. See `08-bql-data-items.md`.

**setdiff() trap:** Server-side set ops strip index metadata (weights). Fetch each dated universe separately; diff with Pandas `isin()`. Full tracker: `02-bql-for-fixed-income.md`.

---

## Verified Screening Fields

Exact-search new mnemonics in `22`; use Terminal FLDS for ambiguous meanings or unresolved parameters/metadata.

| Field | Syntax | Role |
|-------|--------|------|
| OAS | `spread(spread_type='OAS')` | Rich/cheap vs curve |
| I-spread | `spread(spread_type='I', dates=..., fill='prev')` | Movers |
| Yield | `yield_()` | Carry buckets |
| Rating | `rating()` / `bb_composite()` | IG/HY cutoff |
| Coupon / maturity | `cpn_typ()`, `maturity()` | Structure filters |
| Sector / type | `classification_name()`, `security_typ()` | Sector; MBS isolation |
| Size / country | `amt_issued(currency='usd')`, `country_iso()` | Size / regional |
| IDs | `id_isin()['value']`, `id_sedol1()['value']` | Export — never `id_sedol` |

**MBS/TBA:** `classification_name()` often `None` on MBS. Use `security_typ` + `Mtge` ID masks; `na=False` on string filters (`02-bql-for-fixed-income.md`).

---

## Recipe 1: Multi-Condition `bondsuniv` Filter

Fixed-coupon financials, maturity < 3M, rated AA- or better:

```python
universe = (
    bq.univ.bondsuniv('Active')
    .filter(
        (bq.data.cpn_typ() == 'FIXED')
        .and_(bq.data.classification_name() == 'Financials')
        .and_(bq.data.maturity() < '3M')
        .and_(bq.data.bb_composite() >= 'AA-')
    )
)
df = bq.execute(bql.Request(universe, {'Spread': bq.data.spread(spread_type='OAS')}))[0].df()
```

Index size filter (LUACTRUU, issue > $500M): `amt = bq.data.amt_issued(currency='usd'); universe = bq.univ.members('LUACTRUU Index').filter(amt > 500e6)`.

**Chaining:** `.and_()` / `.or_()` (trailing underscore). Chain calls for 3+ predicates.

---

## Recipe 2: Top Spread Wideners (`grouprank` + `groupsort`)

Ten HY index bonds with largest 1M I-spread widening:

```python
sprd = bq.data.spread(spread_type='I', dates=bq.func.range('-1m', '0d'), fill='prev')
sprd_chg = sprd.net_chg()
universe = bq.univ.members('LF98TRUU Index').filter(sprd_chg.grouprank(order='desc') <= 10)
df = bq.execute(bql.Request(universe, {'Spread Change': sprd_chg.groupsort()}))[0].df()
```

`groupsort()` preserves rank order; `order='desc'` ranks largest values first.

---

## Recipe 3: Z-Score Outliers (`groupzscore`)

Energy-sector US Aggregate bonds — top 5 absolute spread-change z-scores over 1 week:

```python
universe = bq.univ.members('LBUSTRUU Index')
sector = bq.data.classification_name('BCLASS', '3')
u1 = bq.univ.filter(universe, sector == 'Energy')
spread_chg = bq.data.spread(dates=bq.func.range('-1w', '0d'), fill='prev').pct_chg()
z = spread_chg.groupzscore()
u2 = bq.univ.filter(u1, z.abs().grouprank() <= 5)
df = bq.execute(bql.Request(u2, {'Z-Spread Outliers': z.groupsort()}))[0].df()
```

`abs()` ignores tightening vs widening — selects largest statistical movers.

---

## Recipe 4: Cashflow Screening

**Single bond — date window via `matches` + `between`:**

```python
cf = bq.data.cashflows()
item = {'Principal': cf.matches(cf['date'].between('2025-01-01', '2030-01-01'))}
df = bq.execute(bql.Request('EC527035 Corp', item))[0].df()
```

**Index members — aggregate by year:**

```python
universe = bq.univ.members('I00108US Index')
yr = bq.data.cashflows()['date'].year()
items = {
    'Principal': bq.data.cashflows()['value'].group(yr).sum(),
    'Interest': bq.data.cashflows()['interest'].group(yr).sum(),
}
df = to_df(bq.execute(bql.Request(universe, items)))
```

**Filtered `bondsuniv` + monthly roll-up (cached recommended):**

```python
universe = (
    bq.univ.bondsuniv('active')
    .filter(
        (bq.data.country_iso() == 'CA')
        .and_(bq.data.cpn() > 2)
        .and_(bq.data.maturity() < '2y')
    )
)
cf = bq.data.cashflows()
yr, mo = cf['date'].year(), cf['date'].month()
items = {
    'Principal': cf['value'].group([yr, mo]).sum(),
    'Interest': cf['interest'].group([yr, mo]).sum(),
}
df = to_df(bq.execute(bql.Request(universe, items, with_params={'mode': 'cached'}))).dropna()
```

---

## Recipe 5: Rating-Bucket Median Yield

Two-stage: SPX names with high leverage → their long fixed bonds → median yield by rating:

```python
universe = (
    bq.univ.members('SPX Index')
    .filter(
        (bq.data.net_debt_to_ebitda(fa_period_type='a') >= 3)
        .and_(bq.data.classification_name() != 'Financials')
    )
    .bonds()
    .filter((bq.data.cpn_typ() == 'FIXED').and_(bq.data.maturity() > '10Y'))
)
med_yld = bq.data.yield_().group(bq.data.rating()).median()
df = bq.execute(bql.Request(universe, {'Median Yield by Rating': med_yld}))[0].df()
```

Aggregation with winsorize: `.group(...)` → `.winsorize(...)` → `.avg()`.

---

## Cached Mode

```python
response = bq.execute(bql.Request(universe, data_items, with_params={'mode': 'cached'}))
```

| Use cached | Skip cached |
|------------|-------------|
| `bondsuniv('Active')`, broad index pulls, cashflow roll-ups | Small issuer chains, single-bond debug |

Always pass a dict: `with_params={'mode': 'cached'}` — never broken string syntax.

---

## Post-Screen Pandas

```python
df = pd.concat([item.df()[item.name] for item in response], axis=1)
df.index.name = 'ID'

# Index membership diff (preserve weights — no setdiff)
df_added = df_latest[~df_latest.index.isin(df_previous.index)]
df_deleted = df_previous[~df_previous.index.isin(df_latest.index)]
```

Month-end index dates: last **business day**, not calendar month-end on weekends (`02-bql-for-fixed-income.md`).

---

## Project Practice Notes: Screening Safety

- Prefer `with_params={'mode': 'cached'}` for large `bondsuniv` / index screens; drop cache only when debugging or universes are small.
- Chain filters with `.and_()` / `.or_()`; aggregation order `.group(...)` → `.winsorize(...)` → `.avg()` when applicable.
- Index screens needing weights: independent universe pulls + Pandas diff — avoid `setdiff()` (`02-bql-for-fixed-income.md`).
- Identifiers: `id_sedol1()['value']`, `id_isin()['value']`; members weight `'weights'` (lowercase) — `08-bql-data-items.md`.
- String filters on nullable columns: `na=False` (MBS/TBA isolation).
- Month-end membership: last business day.
- Never invent mnemonics — search `22` first; request Terminal FLDS only when unresolved.

---

## Help Center Screening Recipes

Screening-, heatmap-, RV-, and liquidity-focused subset from Help Center FI examples. Full card set (17 examples): `02-bql-for-fixed-income.md` § Help Center Example Recipes (Fixed Income).

### Credit Spread Heatmap

Aggregates winsorized average OAS or Z-spread by rating and maturity bucket for a bond index universe, excluding government and perpetual bonds.

**APIs:** `bq.data.classification_name`, `bq.data.is_perpetual`, `bq.data.mty_years_tdy`, `bq.data.rating`, `bq.data.spread`

```python
import bql

bq = bql.Service()
universe = bq.univ.members('I02701EU Index').filter(
    (bq.data.classification_name() != 'Government')
    .and_(bq.data.is_perpetual() == 'N')
)
rating = bq.data.rating()
avg_oas = (
    bq.data.spread(spread_type='oas')
    .group(by=[rating['BASE_RATING'], rating['NORMALIZED_SCALE'].replacena(99),
                bq.data.mty_years_tdy().bins([3, 7, 10, 20], ['0-3', '3-7', '7-10', '10-20', '> 20'])])
    .winsorize(lower_limit=-3, upper_limit=3)
    .avg()
)
df = bq.execute(bql.Request(universe, {'Avg OAS': avg_oas}))[0].df()
# ... UI omitted: pivot rating × maturity heatmap ...
```

### Credit Factor Scoring

Maps index bonds to equity issuers, blends leverage metrics with OAS and 3-month return, z-scores by sector, ranks combined credit scores for outlier screening.

**APIs:** `bq.data.classification_name`, `bq.data.issuer`, `bq.data.name`, `bq.data.net_debt_to_ebitda`, `bq.data.net_interest_coverage`, `bq.data.spread`, `bq.data.tot_debt_to_tot_cap`, `bq.data.total_return`, `bq.func.range`, `bq.univ.issuerof`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()

def map_to_issuer(item):
    return item.value(bq.univ.issuerof(), mapby='lineage').znav()

universe = bq.univ.members('EMUSTRUU Index').filter(
    bq.data.classification_name() != 'Government'
)
data_items = {
    'Sector': bq.data.classification_name(),
    'Debt to EBITDA': map_to_issuer(bq.data.net_debt_to_ebitda(fa_period_type='BA') * -1),
    'Interest Coverage': map_to_issuer(bq.data.net_interest_coverage(fa_period_type='BA')),
    'Valuation Score': bq.data.spread(spread_type='OAS'),
    'Momentum Score': bq.data.total_return(calc_interval=bq.func.range('-3m', '0d')),
}
response = bq.execute(
    bql.Request(universe, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
)
df = pd.concat([item.df()[item.name] for item in response], axis=1).dropna()
# ... UI omitted: sector z-score, Combined Score rank ...
```

### Relative Value Screening

Rating-group z-scores on OAS/Z/G-spread with absolute-threshold slider to isolate rich/cheap bonds in any picked universe.

**APIs:** `bq.data.classification_name`, `bq.data.duration`, `bq.data.issuer`, `bq.data.name`, `bq.data.rating`, `bq.data.spread`, `bq.data.yield_`

```python
import pandas as pd
import bql

bq = bql.Service()
measure = bq.data.spread(spread_type='oas')
rating = bq.data.rating()
universe = bq.univ.members('I02701EU Index').filter(
    bq.data.classification_name() != 'Government'
)
data_items = {
    'Bond Name': bq.data.name(),
    'OAS': measure.round(2),
    'Rating': rating,
    'Z-Score': measure.groupzscore(by=rating).round(2),
}
response = bq.execute(bql.Request(universe, data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1)
df = df.set_index('Bond Name').dropna(subset=['OAS'])
screen = df[df['Z-Score'].abs() > 1]
```

### Bond Liquidity Shifts Across Sectors

Monthly LQA score pulls for index-member bonds by BICS sector; quantile-tier segmentation surfaces liquidity migration candidates.

**APIs:** `bq.data.classification_name`, `bq.data.lqa_liquidity_score`, `bq.data.liquidity_sector`, `bq.data.long_comp_name`, `bq.data.name`, `bq.func.range`, `bq.univ.members`

```python
import bql

bq = bql.Service()
lqa_score = bq.data.lqa_liquidity_score(dates=bq.func.range('-1M', '0D', frq='M'))
universe = (
    bq.univ.members('INDU Index')
    .filter(bq.data.classification_name('BICS', '1') == 'Financials')
    .bonds(issuedby='Credit_Family')
)
data_items = {
    'Bond Info': bq.data.name(),
    'Issuer': bq.data.long_comp_name(),
    'LQA Sector': bq.data.liquidity_sector(),
    'LQA Score': lqa_score,
}
response = bq.execute(
    bql.Request(universe, data_items, with_params={'mode': 'cached'})
)
# ... UI omitted: tier qcut, migration filter ...
```

### Bond Pair Relative Value

Pairwise spread/yield diffs with rolling z-scores; caps output at top absolute z-score pairs for heatmap screening.

**APIs:** `bq.data.mty_years_tdy`, `bq.data.name`, `bq.data.spread`, `bq.data.ticker`, `bq.func.range`, `bq.univ.bonds`

```python
import bql

bq = bql.Service()
universe = bq.univ.bonds('AAPL US Equity').filter(bq.data.maturity() > '5Y')
metric = bq.data.spread(spread_type='Z').with_additional_parameters(
    dates=bq.func.range('-180d', '0d'), fill='prev', pricing_source='BVAL'
)
response = bq.execute(bql.Request(universe, {
    'Z-Spread': metric,
    'name': bq.data.name(),
    'time_to_maturity': bq.data.mty_years_tdy(),
}))
# ... UI omitted: pairwise diff matrix, top-|z| cap ...
```

### Bond Sector Curve Analysis

NSS regression on issuer bond chain vs same-rating sector `bondsuniv` benchmark — curve-shape RV screen.

**APIs:** `bq.data.amt_outstanding`, `bq.data.bics_level_1_sector_name`, `bq.data.credit_rating`, `bq.data.duration`, `bq.data.regression`, `bq.data.yield_`, `bq.univ.bonds`, `bq.univ.bondsuniv`

> Catalog exception: `credit_rating()` is official-example-observed but absent from `22`. Do not substitute `bond_rating()` without confirming return scale and parameters via current API/FLDS.

```python
import bql

bq = bql.Service()
filt = (
    (bq.data.amt_outstanding() > '500M')
    .and_(bq.data.cpn_typ() == 'FIXED')
    .and_(bq.data.crncy() == 'USD')
)
issuer_univ = bq.univ.bonds('AAPL US Equity', issuedby='credit_family').filter(filt)
sector_univ = bq.univ.bondsuniv('active').filter(
    filt.and_(bq.data.credit_rating() == 'A')
    .and_(bq.data.bics_level_1_sector_name() == 'Technology')
)
reg = bq.data.regression(
    reg_by=bq.data.duration().group(),
    reg_value=bq.data.yield_().group(),
    regression_points=5.0,
    regression_type='nelson_siegel_svenson',
)
# ... UI omitted: issuer vs sector NSS overlay ...
```

### Default Risk Monitor

Ranks index/ETF names by extreme CDS–Z-spread basis per sector; drills into market vs model CDS for selected issuers.

**APIs:** `bq.data.classification_name`, `bq.data.cds_spread`, `bq.data.rsk_bb_issuer_default`, `bq.data.yas_zspread_basis_constant_mty`, `bq.func.range`, `bq.univ.cds`, `bq.univ.members`

```python
import bql

bq = bql.Service()
basis = bq.data.yas_zspread_basis_constant_mty()
universe = (
    bq.univ.members('HYG US Equity')
    .filter(bq.data.classification_name('BICS', '1') == 'Technology')
    .filter(
        (basis.grouprank(order='desc') < 6)
        .or_(basis.grouprank(order='asc') < 6)
    )
)
data_items = {
    'CDS-Zspread Basis': basis.round(2),
    'BB Issuer Dflt. Risk': bq.data.rsk_bb_issuer_default(frq='Y'),
}
response = bq.execute(
    bql.Request(universe, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
)
# ... UI omitted: basis coverage, CDS time series ...
```

### Issuer On-the-run Bonds

Filters issuer chains by maturity-at-issue and payment rank; keeps latest announced line per issuer for spread/yield trend or slope screening.

**APIs:** `bq.data.announce_dt`, `bq.data.yrs_to_mty_issue`, `bq.data.payment_rank`, `bq.data.spread`, `bq.func.range`, `bq.univ.bonds`

```python
import bql

bq = bql.Service()
data_item = bq.data.spread(spread_type='OAS')
filtered = bq.univ.bonds(['AAPL US Equity'], useactiveonly=False).filter(
    bq.data.yrs_to_mty_issue().between(9.5, 10.5)
)
data_items = {
    'Announce dt': bq.data.announce_dt(),
    'Issuer': bq.data.long_ult_parent_comp_name(),
    'Payment Rank': bq.data.payment_rank(),
    'Value': data_item.with_additional_parameters(dates=bq.func.range('-2Y', '0d')).dropna(),
}
response = bq.execute(bql.Request(filtered, data_items, with_params={'mode': 'cached'}))
# ... UI omitted: on-the-run dedupe, slope chart ...
```

### Muni New Issue Spreads

Composable `municipalsuniv` filters plus grouped average YTW spread-to-maturity-at-issue by sale week — new-issue richness screen.

**APIs:** `bq.data.bb_sale_date`, `bq.data.state_code`, `bq.data.yrs_to_mty_issue`, `bq.data.ytw_spread_to_maturity_at_issu`, `bq.func.greaterthanorequals`, `bq.func.in_`, `bq.univ.municipalsuniv`

```python
import bql

bq = bql.Service()
sale_date = bq.data.bb_sale_date()
universe = (
    bq.univ.municipalsuniv('active')
    .filter(bq.data.state_code().in_(['NY']))
    .filter(bq.data.yrs_to_mty_issue().greaterthanorequals(4.5))
)
data_items = {
    'Avg BVAL Spread': (
        bq.data.ytw_spread_to_maturity_at_issu()
        .group([sale_date.year(), sale_date.week()])
        .avg()
    ),
}
response = bq.execute(bql.Request(universe, data_items))
```

### Leveraged Loan Index Monitor

Loan index constituent screen: bid, 3Y DM, dual ratings, par/outstanding, and price change windows with filter-driven top/bottom lists.

**APIs:** `bq.data.amt_outstanding`, `bq.data.classification_name`, `bq.data.discount_margin_3yr_bid`, `bq.data.ln_agent`, `bq.data.px_bid`, `bq.data.rating`, `bq.univ.members`

```python
import pandas as pd
import bql

bq = bql.Service()
bid = bq.data.px_bid()
data_items = {
    'Company Name': bq.data.long_comp_name(),
    'Industry': bq.data.classification_name(classification_scheme='bclass', classification_level='3'),
    'Current Price': bid,
    'DM/3Y': bq.data.discount_margin_3yr_bid(),
    'Moody Rating': bq.data.rating(rating_source='moody')['BASE_RATING'],
    'Change on Day': bid - bq.data.px_bid(dates='-1d', fill='prev'),
    'Agent': bq.data.ln_agent(),
}
response = bq.execute(bql.Request(bq.univ.members('I38932US Index'), data_items))
df = pd.concat([item.df()[item.name] for item in response], axis=1)
```

### CDS-Driven Risk Dynamics

Maps issuer CDS to bond OAS/yield/duration, clusters normalized risk factors, flags cluster migrations — credit-regime shift screen.

**APIs:** `bq.data.cds_spread`, `bq.data.classification_name`, `bq.data.spread`, `bq.data.yield_`, `bq.func.range`, `bq.univ.cds`, `bq.univ.members`

```python
import bql

bq = bql.Service()
date_range = bq.func.range('-1Y', '0D', frq='CM')
cds = bq.data.cds_spread(dates=date_range)
issuer_cds = cds.value(bq.univ.cds(tenor='5Y'), mapby='LINEAGE')
universe = bq.univ.members('INDU Index').filter(
    bq.data.classification_name('BICS', '1') == 'Technology'
)
data_items = {
    'CDS Spread': issuer_cds,
    'Spread': bq.data.spread(spread_type='OAS', dates=date_range),
    'Yield': bq.data.yield_(dates=date_range),
}
response = bq.execute(
    bql.Request(universe, data_items, with_params={'fill': 'prev', 'mode': 'cached'})
)
# ... UI omitted: normalize, k-means, cluster-move grid ...
```

### TOMS Relative Value

Brief: TOMS book pairwise spread z-scores filtered by maturity gap and optional same-sector constraint; book overview scatter by position size.

**APIs:** `bq.data.classification_name`, `bq.data.is_axed`, `bq.data.position`, `bq.data.spread`, `bq.data.ticker`, `bq.func.range`, `bq.univ.members`

```python
import bql

bq = bql.Service()
book = bq.univ.members(symbols=['MYBOOK'], type='toms', pricing_number=1)
spread = bq.data.spread(spread_type='OAS').with_additional_parameters(
    dates=bq.func.range('-180d', '0d'), fill='prev'
)
static = bq.execute(bql.Request(book, {
    'Name': bq.data.name(),
    'Sector': bq.data.classification_name('bclass', '3'),
    'Position': bq.data.position(pxnum=1),
}))
ts = bq.execute(bql.Request(book, {'OAS': spread.dropna(True)}, with_params={'mode': 'cached'}))
# ... UI omitted: pairwise z-score RV grid, maturity/sector filters ...
```

## Get Data Official Tutorial: Fixed Income Screening (Official)

```mermaid
flowchart LR
  A["Fixed Income Screening (Official)"] --> B[Universe]
  B --> C[Data items / transforms]
  C --> D[Request / execute]
  D --> E[DataFrame]
```

### BQL for Fixed Income Screening
- This notebook is designed to show off several ways you can use BQL to perform fixed income screening.
- Note: Official screening quickstart supplement to 12.
- **Topics:** Quickstart: BQL for Fixed Income Screening; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying data for a single bond¶; Bottom-up screening¶; Using fixed income chains¶; Screening for comparable bonds¶
- **APIs:** `bq.data.cds_spread`, `bq.data.classification_name`, `bq.data.cntry_of_risk`, `bq.data.cpn_typ`, `bq.data.credit_rating_outlook`, `bq.data.crncy`, `bq.data.issue_dt`, `bq.data.issuer`, `bq.data.maturity`, `bq.data.maturity_years`, `bq.data.mtg_deal_typ`, `bq.data.mtg_orig_amt`, `bq.data.name`, `bq.data.original_tranche_amount`

```python
rating = bq.data.rating()
outlook = bq.data.credit_rating_outlook(credit_rating_source='sp') 
lookback = dt.date.today() - dt.timedelta(days=180)

# Filter universe for at-risk bonds 
universe = (
    bq.univ.bondsuniv('active')
    .filter(
        (bq.data.cntry_of_risk() == 'US')
        .and_(rating == 'BBB-')
        .and_(outlook == 'NEGATIVE')
        .and_(outlook['effective_date'].between(lookback, dt.date.today()))
    )
)

# Define data items
data_items = {
    'Name': bq.data.name(),
    'Issuer': bq.data.issuer(),
    'Rating': rating,
    'Outlook': outlook, 
    'Date': outlook['effective_date'],
    'OAS': bq.data.spread(spread_type='oas'),
    '1-week OAS % change': bq.data.spread(
        spread_type='OAS', dates=bq.func.range('-1w','0d'), fill='prev'
    ).pct_chg()
}

request = bql.Request(universe, data_items, with_params={'mode': 'cached'})
response = bq.execute(request)

df = pd.concat([item.df()[item.name] for item in response], axis=1)
df
```

```python
# Define the universe
universe = bq.univ.members('LF98TRUU Index')

# Define 1y spread z-score
spread_z_last = (
    bq.data.spread(
        spread_type='oas', dates=bq.func.range('-1y', '0d'), fill='prev'
    )
    .zscore()
    .last()
)

# Apply a z-score filter: greater than +/-2 standard deviations
filtered_universe = universe.filter(spread_z_last.abs() > 2)

# Request data for filtered bonds
data_items = {
    'Name': bq.data.name(),
    'Spread Z-Score': spread_z_last,
    'OAS': bq.data.spread(spread_type='oas')
}

request = bql.Request(filtered_universe, data_items)
response = bq.execute(request)

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

# Display DataFrame sorted by z-score and round values
df.sort_values('Spread Z-Score').round(2)
```

### BQL for Relative Value
- This notebook is designed to show off several ways you can use BQL to perform fixed income relative value analyses.
- **Topics:** Quickstart: BQL for Relative Value; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying BQL for data¶; Analyzing a single security¶; Retrieving times series data for multiple data items¶; Retrieving cross-currency data¶
- **APIs:** `bq.data.amt_outstanding`, `bq.data.cds_spread`, `bq.data.classification_name`, `bq.data.cpn_typ`, `bq.data.crncy`, `bq.data.curve_strategy`, `bq.data.duration`, `bq.data.id`, `bq.data.issuer`, `bq.data.long_comp_name`, `bq.data.maturity_years`, `bq.data.name`, `bq.data.payment_rank`, `bq.data.px_last`

```python
bonds_list = [
    'JP322380AP98',
    'EU000A3K4DM9',
    'US25468PBW59',
    'US03969YAC21',
    'XS2491189408',
    'US71567RAV87'
]

def build_bql_request(bond):
    """
    Constructs a single BQL request for z-scores for each bond.
    """
    universe = bq.univ.list(bonds_list)

    spread = bq.data.spread(
        spread_type='Z', dates=bq.func.range('-1y', '0d'), fill='prev'
    )['value']
    base_spread = spread.value(bq.univ.list(bond)).dropna()['value']

    data_item = {
        bond: (spread - base_spread).zscore().last()
    }

    request = bql.Request(universe, data_item)
    return request

# Create a list of unique dated requests and execute the requests
requests = [build_bql_request(bond) for bond in bonds_list]
responses = bq.execute_many(requests)

# Each response represents a single bond, so create a final DataFrame
# with all of the bonds
dfs = []
for response, bond in zip(responses, bonds_list):
    single_bond_df = pd.concat(
        [data_item.df()[data_item.name] for data_item in response],
        axis=1
    )
    dfs.append(single_bond_df)
df = pd.concat(dfs, axis=1).fillna('-')

# Present the data as a pandas DataFrame
df
```

```python
# Specify the start and end dates
end_date = pd.to_datetime('today')
start_date = end_date - pd.DateOffset(months=6)

# Generate a list of end-of-month dates
end_of_months = pd.date_range(
    start=start_date,
    end=end_date,
    freq='m'
)

# Define function to build BQL request
def build_bql_request(date):
    """
    Constructs a single BQL request for z-scores for each bond.
    """
    universe = bq.univ.members('LF98TRUU Index')

    group = bq.data.classification_name('bclass', '4')

    data_item = {
        date.strftime('%Y-%m-%d'): (
            bq.data.spread(spread_type='OAS').group(group)
            .wavg(bq.data.id()['weights'].group(group))
        )
    }

    request = bql.Request(
        universe, data_item, with_params={'dates': date, 'fill': 'prev'}
    )
    return request

# Create a list of unique dated requests and execute the requests
requests = [build_bql_request(date) for date in end_of_months]
responses = bq.execute_many(requests)

# Each response represents a single date, so create a final DataFrame
# with all dates
dfs = []
for response, date in zip(responses, end_of_months):
    single_date_df = pd.concat(
        [data_item.df()[data_item.name] for data_item in response],
        axis=1
    )
    dfs.append(single_date_df.round(2))
    
df = pd.concat(dfs, axis=1).fillna('-')

# Present the data as a pandas DataFrame
df.head(10)
```

### BQL for Liquidity Analysis
- This notebook is designed to introduce you to performing liquidity analysis using axes data and the Liquidity Assessment (LQA) framework.
- **Topics:** Quickstart: BQL for Liquidity Analysis; Open an interactive version; Table of contents¶; Setting up your environment¶; Querying fixed income axes¶; Using axeduniv() to retrieve all axes¶; Using is_axed() to filter for axes¶; Aggregating axes by security or dealer¶
- **APIs:** `bq.data.amt_outstanding`, `bq.data.axes`, `bq.data.bb_composite`, `bq.data.bics_level_1_sector_name`, `bq.data.classification_name`, `bq.data.expected_daily_volume`, `bq.data.industry_sector`, `bq.data.is_axed`, `bq.data.liquidation_cost`, `bq.data.liquidation_horizon`, `bq.data.lqa_liquidity_score`, `bq.data.liquidity_sector`, `bq.data.liquidity_sector_score`, `bq.data.lqa_bid_ask_spread`

```python
# Define universe
universe = 'LUACTRUU Index'

# Filter universe for axed bonds on both sides
axed_universe = (
    bq.univ.members(universe)
    .filter(bq.data.is_axed(side='all') == True)
)

axes = bq.data.axes(aggregateby='security_dealer')
    
# Calculates total bid axe size per dealer in millions
total_bid = axes['bid_size'].group(axes['bid_dealer']).sum() / '1M'

# Computes size-weighted average bid price per dealer
wavg_bid = (
    axes['bid_price']
    .group(axes['bid_dealer'])
    .wavg(axes['bid_size'].group(axes['bid_dealer']))
    .round(2)
)

data_items = {
    'Total Bid Axes Size by Dealer': total_bid,
    'WAVG Bid Axe Price Weighted by Size': wavg_bid
}

request = bql.Request(axed_universe, data_items)
response = bq.execute(request) 

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df.dropna()
```

```python
# Define universe
universe = 'EH154422 Corp'

params = {
    'dates': bq.func.range('-10d', '0d'),
    'fill': 'prev'
}

bid = bq.data.px_bid(**params)  
ask = bq.data.px_ask(**params)
mid = bq.data.px_mid(**params)
last = bq.data.px_last(**params)

data_items = {
    'Date': bid['date'],
    'Bid': bid,
    'Ask': ask,
    'Mid Price': mid,
    'Last Price': last,
    'Absolute Spread': (ask - bid),
    'Relative Spread (%)': ((ask - bid) / mid) * 100,
    'Effective Spread (%)':  2 * ((last - mid) / mid).abs() * 100
}

request = bql.Request(universe, data_items)
response = bq.execute(request) 

df = pd.concat(
    [data_item.df()[data_item.name] for data_item in response], 
    axis=1
)

df.head()
```

