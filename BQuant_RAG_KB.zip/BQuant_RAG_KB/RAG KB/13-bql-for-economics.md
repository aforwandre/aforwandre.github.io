---
topic_id: "13"
title: BQL for Economics
role: domain_recipe
authority_for: [economics_universes, macro_time_series, economic_calendar]
not_authority_for: [locked_stack_models, entitlement]
evidence_grades: [canonical, practice-derived]
risk_tier: normal
routing_keywords: [economics, macro, countries, calendar, forecasts]
mandatory_cross_checks: [00-RAG-INDEX, 05-get-started, 18-using-pandas, 22-BQuant_DataItems]
restricted_sections: []
source_families: [help_center]
---

# BQL for Economics

Dense PyBQL recipes for country-level macro data, time series, universe construction, grouping, and economic release calendars.

> Field gate: exact-search data-item names in `22`; use `08` for meaning/metadata and current API/FLDS only when signatures remain unresolved.

## Setup

```python
import pandas as pd
import bql

bq = bql.Service()
```

Country universes: `'US Country'`, `'DE Country'`, `'JP Country'`.

What's New announces contributor-level economic forecasts and an expanded labor-indicator family (March 2026). Exact catalog matches and the unresolved `job_openings()` alias are recorded in `08`.

```mermaid
flowchart LR
  U[Universe: country / countries region / list] --> D[Data dict bq.data.*]
  D --> R[bql.Request] --> E[bq.execute]
  E --> C[pd.concat or response0.df]
```

## Single Country Queries

Default CPI is YoY percent (`TRANSFORM`, `PERIOD_OVER_PERIOD` in metadata). Override with `period_over_period`:

```python
universe = 'US Country'

# YoY (default)
request = bql.Request(universe, {'CPI': bq.data.cpi()})
data = bq.execute(request)[0].df()

# MoM
request = bql.Request(universe, {'CPI': bq.data.cpi(period_over_period='MoM')})
data = bq.execute(request)[0].df()
```

**Multiple items, one country** — dict keys label columns:

```python
universe = 'DE Country'
data_items = {
    'GDP': bq.data.gdp(),
    'Policy Rate': bq.data.policy_rate(),
    'PMI': bq.data.pmi(),
    'Unemployment': bq.data.unemployment(),
    'Consumer Confidence': bq.data.consumer_confidence(),
    'Retail Sales': bq.data.retail_sales(),
    'Exports': bq.data.exports(),
    'Imports': bq.data.imports(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Multiple countries:**

```python
universe = ['US Country', 'DE Country', 'FR Country']
data_items = {
    'Current Account % GDP': bq.data.current_account_percent_gdp(),
    'Government Debt % GDP': bq.data.government_debt_percent_gdp(),
    'Budget Balance % GDP': bq.data.budget_balance_percent_gdp(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)
```

## Dates, Periods, and Time Series

| Mechanism | Example |
|-----------|---------|
| Point-in-time | `bq.data.gdp(dates='2022-12-07')` |
| Period reference | `bq.data.government_debt(period_reference='2023M12')` |
| Period range | `period_reference=bq.func.range('2013A', '2023A')` |
| Period offset | `period_offset=bq.func.range('-1Q', '2Q')` |
| Transform | `period_over_period='MoM'/'QoQ'/'YoY'`, `transform='LVL'` |

```python
universe = 'US Country'
period_range = bq.func.range('2013A', '2023A')

data_items = {
    'GDP Growth': bq.data.gdp(period_reference=period_range),
    'Average GDP Growth': bq.data.gdp(period_reference=period_range).avg(),
    'GDP Growth 10Y': bq.data.gdp(
        period_reference=period_range, transform='LVL',
    ).pct_chg(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)
```

Use `transform='LVL'` before `.pct_chg()` when you need level-based change.

## Estimates and Forward Periods

`ACT_EST_DATA` column: `A` actual, `E` estimate. Control via `act_est_data` (`A`, `E`, `AE`).

```python
universe = 'JP Country'
period_offset = bq.func.range('-1Q', '2Q')
response = bq.execute(bql.Request(universe, {'CPI': bq.data.cpi(period_offset=period_offset)}))
data = response[0].df().head()

# Multi-country: last estimate + z-score within country series
universe = ['JP Country', 'DE Country', 'US Country']
cpi = bq.data.cpi(period_offset=bq.func.range('-8Q', '1Q'))
data_items = {'CPI Est': cpi.last(), 'CPI Est Z-score': cpi.zscore().last()}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)
```

## Universe: `countries()`, Filter, Union

```python
universe = bq.univ.countries('Eurozone')
data_items = {
    'Name': bq.data.id()['COUNTRY_NAME'],
    'Unemployment': bq.data.unemployment(),
    'Business Confidence': bq.data.business_confidence(),
    'Retail Sales': bq.data.retail_sales(),
    'Policy Rate': bq.data.policy_rate(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Filter** — use `['VALUE']` for scalar comparisons:

```python
govt_debt = bq.data.government_debt_percent_gdp()['VALUE']
universe = bq.univ.countries('Western Europe').filter(govt_debt < 100)
data_items = {
    'Name': bq.data.id()['COUNTRY_NAME'],
    'Debt to GDP': govt_debt,
    'GDP Growth QoQ': bq.data.gdp(period_over_period='QoQ'),
    'Avg GDP Growth 3Y': bq.data.gdp(
        period_offset=bq.func.range('-3Y', '0Y'),
        period_type='Q',
        period_over_period='QoQ',
    ).avg(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)
```

**Union + filter:**

```python
gdp_growth = bq.data.gdp(
    period_over_period='YoY',
    period_reference=bq.func.range('2020A', '2023A'),
).avg()
universe = (
    bq.univ.countries('Sub-Saharan Africa')
    .union(bq.univ.countries('South Central America'))
    .union(bq.univ.countries('Asia'))
    .filter(gdp_growth > 5)
)
response = bq.execute(bql.Request(universe, {'GDP Growth': gdp_growth}))
data = response[0].df()[['GDP Growth']]
```

## Group Aggregates

```python
# Single-bucket average
universe = bq.univ.countries('Developed Markets')
data_items = {
    'Curr Account % GDP': bq.data.current_account_percent_gdp().group().avg(),
    'Gov Debt % GDP': bq.data.government_debt_percent_gdp().group().avg(),
    'Budget Bal % GDP': bq.data.budget_balance_percent_gdp().group().avg(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)

# Conditional buckets (if_)
inflation_level = bq.func.if_(bq.data.cpi() > 5, 'High Inflation', 'Low Inflation')
universe = bq.univ.countries('Eurozone')
data_items = {
    'Unemployment': bq.data.unemployment().group(inflation_level).avg(),
    'Retail Sales': bq.data.retail_sales().group(inflation_level).avg(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1)

# vs group average
universe = bq.univ.countries('Asia')
gdp = bq.data.gdp(period_over_period='YoY', period_offset='1A')
data_items = {
    'Name': bq.data.id()['COUNTRY_NAME'],
    'Estimated GDP Growth': gdp,
    'Estimated GDP Growth vs Region Avg': gdp - gdp.groupavg(),
}
response = bq.execute(bql.Request(universe, data_items))
data = pd.concat([item.df()[item.name] for item in response], axis=1).dropna()
```

Group-prefix helpers: `grouprank()`, `groupavg()`, `groupmedian()`.

## Economic Release Calendar

`bq.data.calendar` parameters: `dates`, `view` (`standard`/`condensed`/`extended`), `relevancy`, `subtype`.

Preferences: `addcols` / `dropcols` for metadata columns.

```python
universe = ['US Country', 'JP Country']
date_range = bq.func.range('-1W', '1M')

# Standard view
response = bq.execute(bql.Request(
    universe, {'Calendar': bq.data.calendar(dates=date_range, view='standard')},
))
data = response[0].df().head()

# Condensed labor market + extra columns
universe = 'US Country'
data_item = {'Calendar': bq.data.calendar(
    dates=date_range, view='condensed', subtype='labor_market',
)}
preferences = {'addcols': ['RELEVANCY', 'SOURCE_NAME']}
response = bq.execute(bql.Request(universe, data_item, preferences=preferences))
data = response[0].df().head()

# Extended G8, high relevancy, drop CONCEPT
universe = bq.univ.countries('G8')
data_item = {'Calendar': bq.data.calendar(
    dates=bq.func.range('0D', '1W'), view='extended', relevancy='high',
)}
preferences = {'dropcols': ['CONCEPT']}
response = bq.execute(bql.Request(universe, data_item, preferences=preferences))
data = response[0].df().head()
```

## Calendar: `matches()`, Surprise, Group Aggregation

`matches()` → NaN for non-matches → `.dropna(remove_id=True)`.

```python
universe = bq.univ.countries('G8')
calendar = bq.data.calendar(
    dates=bq.func.range('-4W', '0D'), relevancy='high', subtype='prices',
)
calendar = calendar.matches(calendar['SURPRISE'].abs() > 1).dropna(remove_id=True)

preferences = {
    'addcols': ['NUMBER_OF_SURVEYS', 'RELEVANCY', 'SURPRISE'],
    'dropcols': ['REVISION'],
}
response = bq.execute(bql.Request(
    universe, {'Calendar': calendar}, preferences=preferences,
))
data = response[0].df().head()
```

**Average surprise by country and event:**

```python
universe = bq.univ.countries('G8')
calendar = bq.data.calendar(
    dates=bq.func.range('-6M', '0D'), relevancy='high', subtype='prices',
)
calendar = calendar.matches(
    calendar['EVENT_NAME'].in_(['CPI MoM', 'CPI YoY']),
).dropna(remove_id=True)

surprise = calendar['SURPRISE'].group(
    by=[calendar['ID'], calendar['EVENT_NAME']],
).avg()

response = bq.execute(bql.Request(universe, {'Average Surprise': surprise}))
data = response[0].df()[['Average Surprise']]
data[['Country', 'Event']] = data.index.to_series().str.split(':', expand=True)
data.head()
```

Multi-item concat: `pd.concat([item.df()[item.name] for item in response], axis=1)`.

## Project Practice Notes

- Exact-search economic data-item mnemonics in `22`; use FLDS only for absent/ambiguous names or unresolved signatures.
- Prefer relative date ranges (`bq.func.range('-1y', '0d')`) with explicit `fill` when chaining transforms.
- Local Cursor does not execute BQL; transfer notebooks to Bloomberg BQuant for runs.

---

## Help Center Example Recipes (Economics)

### Point-in-Time Economic Forecasts

Build one BQL data item per historical as-of date; overlay faded forecast paths against the current CPI series.

APIs: `bq.data.cpi`, `bq.func.range`.

```python
def get_pit_forecast(country):
    date_range = pd.date_range(end='today', periods=50, freq='Q', normalize=True)
    cpi = bq.data.cpi(period_type='Q', period_reference=bq.func.range('2012Q1', '2025Q4'))
    data_items = {
        f'{d:%Y-%m-%d}': cpi.with_additional_parameters(dates=d)
        for d in date_range[::-1]
    }
    data_items['current'] = cpi.with_additional_parameters(dates=date_range[-1])
    response = bq.execute(bql.Request(country, data_items, with_params={'mode': 'cached'}))
    return {name: response.get(name).df() for name in data_items}

def build_figure(country_label, data_dict):
    fig = go.FigureWidget(data=[go.Scatter(
        x=data_dict['current']['PERIOD_REFERENCE_DATE'],
        y=data_dict['current']['current'],
        name='Current', line_color='white',
    )])
    for key, df in data_dict.items():
        if key == 'current':
            continue
        df = df[df['PERIOD_REFERENCE_DATE'] >= pd.to_datetime(key)].dropna(subset=[key])
        fig.add_trace(go.Scatter(
            x=df['PERIOD_REFERENCE_DATE'], y=df[key],
            name=key, opacity=0.2, line_color='darkorange', mode='lines',
        ))
    fig.update_layout(template='plotly_dark', title=f'{country_label} CPI: Point-in-Time Forecasts')
    return fig
```

### LatAm Implied Inflation Analysis

Country-specific nominal vs linkers/futures sides; snapshot cache keyed by `(country, curve_a, curve_b, as_of)`; single- vs dual-date display modes.

APIs: `bq.data.maturity`, `bq.data.series`, plus country-module bond/future/curve helpers (example-observed).

> The `cd.active_bonds(...)`, `countries`, and `build_snapshot(...)` names below come from supporting notebook modules and are **pseudo-code in this corpus**, not built-in PyBQL APIs. Do not paste this block without the source helper module; confirm underlying universes/fields through FLDS.

```python
# Filter linkers by series (Colombia example)
side_a = cd.active_bonds(['COLTES']).filter(bq.data.series() != 'UVR')
side_b = cd.active_bonds(['COLTES']).filter(bq.data.series() == 'UVR')

# Argentina: exclude short linkers
side_b = cd.active_bonds(['BONCER']).filter(bq.data.maturity() > '1m')

snap_inflation, tenors = build_snapshot(
    country, countries[country], curve_a, curve_b, as_of_date,
)
```

### Tariffs Dashboard

Monthly tariff levels via `px_last` with calendar-month frequency; pivot by Goods/Countries axes; styled HTML heat table with search filter.

APIs: `bq.data.px_last`, `bq.func.range`.

```python
def get_tariff_data(universe):
    item = bq.data.px_last(
        dates=bq.func.range('-1y', '0d', frq='cm'), fill='prev'
    ).last(13) / 100
    return bq.execute(bql.Request(universe, {'Value': item}))[0].df()

def pivot_df_date(df, y):
    opp = {'Goods': 'Countries', 'Countries': 'Goods'}[y]
    return (
        df[df[opp] == f'All {opp}']
        .pivot(columns='Date', index=y, values='Value')
    )

html = (
    pivot.style.background_gradient(cmap='Reds', axis=1)
    .format('{:.2%}', na_rep='-')
    .set_sticky(axis='columns')
    .to_html()
)
```

### Global Market Regime Recognition Model

Daily returns → `StandardScaler` → Gaussian Mixture; BIC elbow for regime count; regime bands on asset subplots + stacked posterior area chart.

APIs: `bq.data.px_last`, `bq.func.range`.

> Research concept only. The scaler/Gaussian-mixture implementation requires supporting dependencies outside this project's locked stack and is not retained as executable code. The Desktop-safe portion below stops at returns preparation.

```python
def get_asset_prices(universe, start_date, end_date):
    date_range = bq.func.range(start_date, end_date, frq='d')
    df = bq.execute(bql.Request(
        universe, {'Price': bq.data.px_last(dates=date_range).dropna()},
        with_params={'mode': 'cached'},
    ))[0].df()
    return df.pivot(index='DATE', columns='ID', values='Price').ffill()

returns = prices.pct_change().dropna()
```
