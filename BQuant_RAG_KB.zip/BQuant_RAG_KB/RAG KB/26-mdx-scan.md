---
topic_id: "26"
title: MDX Scan Runtime Authority
role: project_runtime_authority
authority_for:
  - mdx_scan_runtime
  - hsi_members_ohlcv_contract
  - mdx_namecn_field
  - mdx_pandas_signal_port
not_authority_for:
  - general_widget_errors
  - arrow_date_merge_shape
  - substitution_workflow
evidence_grades:
  - user-confirmed
  - practice-derived
risk_tier: high
routing_keywords:
  - MDX Scan
  - PCTB
  - HSI Index
  - NameCN
  - official_trad_local_lang_sec_nm
  - name_chinese_traditional
  - Play.interval
  - load_on_start
mandatory_cross_checks:
  - 00-RAG-INDEX
  - 08-bql-data-items
  - 09-build-analysis
  - 18-using-pandas
  - 23-bql-substitution-due-diligence
  - project-mdx-scan
restricted_sections: []
source_families:
  - user_confirmed_incident
  - desktop_observation
---

# MDX Scan Runtime Authority

## Retrieval card (route card)

This is the **highway** to a running MDX Scan. The destination is Desktop
output: live Hang Seng members, daily OHLCV, pandas MDX signals, optional
NameCN. Follow this card. Do not wander catalog Chinese-name rows or `09`
Error Log for BQL. `BUNDLE_EXAMPLES.md` may reuse this app's shapes for a
**new** goal; it is not a second highway for this destination.

`09` keeps Play/legend/Arrow traps. `18` keeps DATE merge. Signal math
needs `Source/MDX_futu_formula.txt` with this card.

Code lives under `User scripts/MDX Scan/`. Daily-only. Do not add
Enterprise intraday analytics or scheduled workloads.

## Authority split

| Claim | Owner | Not owner |
|---|---|---|
| `members` object vs Python-string universe | `01`/`07`; Error Log in `09` | this file copies the working Request |
| Arrow `DATE` / `execute_many` lineage | `18` | this file |
| Play interval, one-node HTML legend, HBox clip | `09` | this file notes placement only |
| NameCN mnemonic, OHLCV range/batch, signal port | **this file** | `08`/`09` must point here |
| Catalog-similar Chinese name as a substitute | `23` | never swap from `22` description text |

## Member metadata and NameCN

User-confirmed Desktop (`PARSER_VERSION` `2026-08-28c`).

```python
bq.univ.members('HSI Index')
```

First Request (`with_params={'mode': 'cached'}`):

- `Name` = `bq.data.name()`
- `Sector` = `bq.data.classification_name()`
- `Weight` = `bq.data.id()['weights']` (members: lowercase)

**NameCN is a second Request** on the same universe, merged on `ID`, so an
entitlement miss cannot drop Name/Sector/Weight. Live code also uses
`mode=cached` on that second Request.

Deployed NameCN (`22` exact): `bq.data.official_trad_local_lang_sec_nm()`
— Official Traditional Local Language Security Name.

Do **not** use `bq.data.name_chinese_traditional()` (Company Name in
Chinese Traditional) or `name_chinese_simplified()`. Different identity:
company name versus official local-language **security** name. Both exist
in `22`. Catalog similarity is not a substitute. Run `23` before any swap.

Never invent `_member_univ` helpers that exist on only one Request side.

## Member and benchmark OHLCV

Without this section a knowledge-only rebuild issues a **snapshot**
`px_last` (no `dates=`) and leaves PCTB empty. That is not this app.

Warmup for EMA60 / HHV60 / buy-history(40):

- `HISTORY_RANGE_START = '-6m'`
- `HISTORY_RANGE_END = '0d'`
- `date_range = bq.func.range(HISTORY_RANGE_START, HISTORY_RANGE_END)`

Items (names the pandas port expects):

- Open `px_open(dates=date_range)`
- High `px_high(dates=date_range)`
- Low `px_low(dates=date_range)`
- Close `px_last(dates=date_range)`
- Volume `px_volume(dates=date_range)`

Member batches: `MEMBER_OHLCV_BATCH = 40`, Request `mode=cached`.
Each benchmark ticker is its **own** Request, not mixed into a member
batch. Live code does **not** attach `mode=cached` on those bench
Requests. Cached is per-Request, not a session default.

Keep `ID` and `DATE` through parse/merge (`18`). Do not value-only concat.

## Benchmark yellow keys (user-confirmed)

Edit in `mdx_scan/config.py` if a Terminal ID fails. Do not invent aliases.

| Yellow key | Label | Group |
|---|---|---|
| `HSI Index` | Hang Seng | HK cash |
| `HSCEI Index` | HSCEI | HK cash |
| `HSTECH Index` | HSTECH | HK cash |
| `ESA Index` | S&P 500 | US equity-index future |
| `NQA Index` | Nasdaq 100 | US equity-index future |
| `DMA Index` | DJI | US equity-index future |

## Pandas signal port (not BQL)

`PCTB`, `VS`, `DD60`, BUY/SELL/WASH/DUMP/REVU/REVD/CONT/SQZ are **pandas**
on daily OHLCV. Do not search `22` for those names.

Formula authority for this Desktop app: daily
`User scripts/MDX Scan/Source/MDX_futu_formula.txt`.
`mdx_scan/mdx_engine.py` is the port of daily v4e.
`Source/MDX_futu_sig.txt` uses the same BOT. If the subplot file disagrees
with the main formula, stop and do not port one side only. Do not add a
5-minute or 1-minute scan, and do not put those formula files in this app.

A new Desktop app whose source is a Futu/TDX formula should pandas-port
the file, not invent BQL. Freeze smoothing before coding:

- Futu `SMA(X, N, 1)` is Wilder: `ewm(alpha=1/N, adjust=False)`.
- EMA uses `alpha = 2/(N+1)` (`ewm(span=N, adjust=False)`).
- `STD` is population (`ddof=0`).
- AND binds tighter than OR in the WASH reclaim clause.
- `PCTB = (Close - DN) / (UP - DN)`; `DD60 = Close / HHV60 - 1`.
- v4e BOT adds `Close >= Open` on top of bounce (`Close > prior Close`).
  A down bar does not buy. Thresholds stay `PCTB < 0.18` and `DD60 < -0.18`.
- Later flags overwrite earlier ones; BUY wins last
  (`SQZ` → `CONT` → `REVD` → `REVU` → `DUMP` → `WASH` → `SELL` → `BUY`).

Do not paste the full Futu file into other topics. Change the formula file
and the pandas port together.

Default params: N1=20, N2=14, N3=1.8, N5=5; cooldown 8 bars; buy lookback
40. UI clock is HKT, not the ETF Monitor UK header clock.

## Minimum shippable package (one pass)

If `User scripts/MDX Scan/` is lost, rebuild from **this file** + project
`.mdc` + `18`/`09` widget traps, not from catalog-similar names. `00` § 13
One-pass order.

| File | What this topic freezes | What it cannot invent |
|---|---|---|
| `mdx_scan/config.py` | `HSI Index`, benches, `-6m`/`0d`, batch 40, Play `900000`, params N1–N5 | — |
| `mdx_scan/data.py` | members + NameCN item + OHLCV range + Arrow merge | — |
| `mdx_scan/mdx_engine.py` | Wilder/STD/`PCTB` freeze, v4e `Close >= Open` on BOT, flag overwrite order | The full daily Futu listing — restore `Source/MDX_futu_formula.txt` with this topic; do not invent BUY/WASH from legend keys |
| `mdx_scan/app.py` | `load_on_start`, one-node legend after HBox | Pixel chrome |
| `MAIN.ipynb` | `display` then `load_on_start()` once | — |

**First Desktop success:** Restart Kernel → Run All → one refresh → HSI
members with history bars, optional NameCN, pandas signals, legend
definitions visible, Play interval in milliseconds. Daily bars only.
The refresh log shows parser `2026-08-28c` and formula `v4e`.

If the daily Futu file is also lost, stop and restore it. Do not approximate
BUY/SELL from `09` legend text.

## App lifecycle

`MAIN.ipynb` is a thin bootstrapper. After `display(app.render())` this app
calls `app.load_on_start()` **once**. That is one BQL refresh, not a live
workload (`05`).

Do **not** copy the ETF Monitor bootstrap: that app waits for **Update**
and does not auto-refresh (`25`).

`widgets.Play.interval` is milliseconds; 15 minutes = `900000` (`09`).
Keep legend keys and definitions in **one** HTML text node, placed after
the table/chart `HBox` (`09`).

After replacing `.py` on Desktop: Restart Kernel → Run All. Log must show
`PARSER_VERSION` from `data.py`.

## Reconstruction lesson (KB backtest 2026-09-03)

A knowledge-only rebuild from `01`/`09`/`18` matched membership, lowercase
weights, separate NameCN Request, Play/legend, Arrow `DATE`, and
`load_on_start`. It failed closed (correctly) on:

1. OHLCV `range('-6m','0d')` and member batch 40 — snapshot `px_last`
   instead of history.
2. Entire signal engine — legend keys without formulas.
3. Benchmark yellow keys.

NameCN spelling must stay in **this** file. `09` only points here so an
Error Log snippet cannot teach a different catalog row.

## Regression that belongs here

- [ ] Members universe is `bq.univ.members('HSI Index')`, not `member` or a
      Python string.
- [ ] Name/Sector/Weight stay on Request 1; NameCN is Request 2 merged on
      `ID`.
- [ ] NameCN is `official_trad_local_lang_sec_nm()`, not
      `name_chinese_traditional()`.
- [ ] OHLCV uses `range('-6m','0d')`; members batched at 40 with cached;
      benches are separate Requests.
- [ ] Signals are pandas from the daily v4e Futu file, not BQL data items.
- [ ] BOT requires `Close >= Open`. A down bar does not buy.
- [ ] `MAIN` calls `load_on_start()` once; Play interval is milliseconds.
- [ ] 5-minute and 1-minute scans are absent. Those Source files are not in this app.
