"""Generate proven bundle example cards.

Sources: Desktop-frozen User scripts, and official BQuant apps distilled
into canonical Production Recipes (01 / 02 / 09 / 18).

Never edit BUNDLE_EXAMPLES.md or BUNDLE_EXAMPLES.json by hand.
Registry: bundle_examples_registry.json.
"""

from __future__ import annotations

import ast
import hashlib
import json
import re
from pathlib import Path
from typing import Any


KB = Path(__file__).resolve().parent
WORKSPACE = KB.parent
USER_SCRIPTS = WORKSPACE / "User scripts"
REGISTRY_PATH = KB / "bundle_examples_registry.json"
BUNDLE_EXAMPLES_MD = KB / "BUNDLE_EXAMPLES.md"
BUNDLE_EXAMPLES_JSON = KB / "BUNDLE_EXAMPLES.json"

PARSER_VERSION_RE = re.compile(
    r"^PARSER_VERSION\s*=\s*['\"]([^'\"]+)['\"]",
    re.MULTILINE,
)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def relative(path: Path) -> str:
    return path.relative_to(WORKSPACE).as_posix()


def load_registry() -> dict[str, Any]:
    payload = json.loads(read_text(REGISTRY_PATH))
    if not payload.get("projects") or not payload.get("examples"):
        raise RuntimeError("bundle_examples_registry.json missing projects/examples")
    ids = [row["id"] for row in payload["examples"]]
    if len(ids) != len(set(ids)):
        raise RuntimeError("Duplicate bundle example ids")
    return payload


def resolve(rel: str) -> Path:
    path = WORKSPACE / rel
    if not path.is_file():
        raise RuntimeError(f"Registry path missing: {rel}")
    return path


def parser_version_in(source: str) -> str | None:
    match = PARSER_VERSION_RE.search(source)
    return match.group(1) if match else None


def extract_functions(source: str, names: list[str], rel: str) -> str:
    tree = ast.parse(source)
    blocks: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            segment = ast.get_source_segment(source, node)
            if not segment:
                raise RuntimeError(f"Cannot slice function {node.name} in {rel}")
            blocks[node.name] = segment.rstrip() + "\n"
    missing = [name for name in names if name not in blocks]
    if missing:
        raise RuntimeError(f"Missing functions {missing} in {rel}")
    return "\n".join(blocks[name] for name in names)


def extract_notebook_cell(path: Path, index: int) -> str:
    notebook = json.loads(read_text(path))
    cells = notebook.get("cells") or []
    if index < 0 or index >= len(cells):
        raise RuntimeError(f"Notebook cell {index} missing in {relative(path)}")
    source = cells[index].get("source") or []
    if isinstance(source, list):
        return "".join(source).rstrip() + "\n"
    return str(source).rstrip() + "\n"


def extract_heading(source: str, heading: str, rel: str) -> str:
    """Copy one markdown section through the next heading of the same level."""
    lines = source.splitlines(keepends=True)
    start = None
    level = None
    stripped = heading.strip()
    for index, line in enumerate(lines):
        if line.strip() == stripped:
            start = index
            level = len(line) - len(line.lstrip("#"))
            break
    if start is None or not level:
        raise RuntimeError(f"Heading {heading!r} missing in {rel}")
    end = len(lines)
    for index in range(start + 1, len(lines)):
        if not lines[index].startswith("#"):
            continue
        next_level = len(lines[index]) - len(lines[index].lstrip("#"))
        if next_level <= level:
            end = index
            break
    return "".join(lines[start:end]).rstrip() + "\n"


def fence(code: str, language: str = "python") -> str:
    body = code.rstrip() + "\n"
    return f"```{language}\n{body}```\n"


def discover_parser_projects() -> dict[str, str]:
    found: dict[str, str] = {}
    if not USER_SCRIPTS.is_dir():
        return found
    for project_dir in sorted(USER_SCRIPTS.iterdir()):
        if not project_dir.is_dir():
            continue
        if project_dir.name.startswith(("_", ".")):
            continue
        for data_path in sorted(project_dir.rglob("data.py")):
            if "tests" in data_path.parts:
                continue
            version = parser_version_in(read_text(data_path))
            if version:
                found[relative(data_path)] = version
    return found


def validate_projects(registry: dict[str, Any]) -> None:
    registered_files = {
        spec["parser_file"]: spec["expected_parser_version"]
        for spec in registry["projects"].values()
        if spec.get("parser_file")
    }
    discovered = discover_parser_projects()
    extra = sorted(set(discovered) - set(registered_files))
    if extra:
        raise RuntimeError(
            "Unregistered Desktop project(s) with PARSER_VERSION: "
            + ", ".join(extra)
            + ". Add them to bundle_examples_registry.json after the user "
            "freezes the app."
        )
    for rel, expected in registered_files.items():
        actual = parser_version_in(read_text(resolve(rel)))
        if actual != expected:
            raise RuntimeError(
                f"{rel} PARSER_VERSION={actual!r} but registry expects "
                f"{expected!r}. Update the registry after reviewing extracts."
            )


def build_example(registry: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    project = registry["projects"][spec["project"]]
    extract = spec["extract"]
    kind = extract["kind"]
    code = ""
    pointers: list[str] = []
    source_file = extract.get("file")
    if kind == "functions":
        path = resolve(extract["file"])
        code = extract_functions(read_text(path), extract["names"], extract["file"])
    elif kind == "notebook_cell":
        path = resolve(extract["file"])
        code = extract_notebook_cell(path, int(extract["index"]))
    elif kind == "pointer":
        pointers = list(extract["paths"])
        for rel in pointers:
            resolve(rel)
    elif kind == "heading":
        path = resolve(extract["file"])
        code = extract_heading(
            read_text(path),
            extract["heading"],
            extract["file"],
        )
    else:
        raise RuntimeError(f"Unknown extract kind {kind!r} for {spec['id']}")

    haystack = code
    if source_file and kind != "heading":
        haystack += "\n" + read_text(resolve(source_file))
    parser_file = project.get("parser_file")
    if parser_file:
        haystack += "\n" + read_text(resolve(parser_file))
    for needle in spec.get("must_contain") or []:
        if needle not in haystack:
            raise RuntimeError(
                f"Bundle {spec['id']} missing required production string: "
                f"{needle!r}"
            )

    return {
        "id": spec["id"],
        "goal": spec["goal"],
        "keywords": spec["keywords"],
        "project": spec["project"],
        "parser_version": project.get(
            "expected_parser_version",
            project.get("evidence", "official-bquant-app"),
        ),
        "evidence": spec.get(
            "evidence",
            project.get("evidence", "user-confirmed"),
        ),
        "route_card": project["route_card"],
        "authority": spec["authority"],
        "identity": spec["identity"],
        "do_not": spec["do_not"],
        "kind": kind,
        "source_file": source_file,
        "pointers": pointers,
        "code": code,
    }


def render_markdown(examples: list[dict[str, Any]]) -> str:
    lines = [
        "---",
        "generated: true",
        "role: proven_bundle_examples",
        "never_edit: true",
        "---",
        "",
        "# Proven bundle examples (generated)",
        "",
        "> Generated from Desktop-proven `User scripts/` and official",
        "> BQuant apps distilled into `01`/`02`/`09`/`18`.",
        "> Registry: `bundle_examples_registry.json`. Never edit this file.",
        ">",
        "> Official BQuant apps are product demos used to sell BQuant.",
        "> Treat their **code usage** as authoritative. They are not a",
        "> full product spec. Goal table copies distilled Production",
        "> Recipes, not the unindexed OCR archive.",
        "> These cards outrank `09`/`11` tutorials and CONCEPT_INDEX for a",
        "> **clear goal**. They are **not** a third highway for ETF/MDX,",
        "> ETF Spread, or FI Index Change: those stay on `25` / `26` / `27` /",
        "> `28` / `29`.",
        "",
        "## How to use",
        "",
        "1. Named destination in `00` § 2 → that route card. Stop here.",
        "2. Else, match **one** Goal table row. Read that card only.",
        "3. Borrow **code usage** (Request idiom, identity, do-not list).",
        "   Do not copy a demo's feature limits as the freeze.",
        "4. Freeze a new route card before writing a new `User scripts/`",
        "   project. New BQL not on the card → `CONCEPT_INDEX` then `23`.",
        "5. Do not copy live `config.py` AIM codes. Do not copy Thai/DRSK",
        "   leftover into an unrelated app.",
        "",
        "## How this file evolves",
        "",
        "- `regenerate_kb_bundle.py` re-extracts registered functions from",
        "  production parsers. PARSER_VERSION drift fails integrity until",
        "  the registry is reviewed.",
        "- A new `User scripts/<Project>/**/data.py` with `PARSER_VERSION`",
        "  and no registry row fails integrity. That is the promotion gate:",
        "  freeze the app, then add project + example rows.",
        "- Official BQuant apps: product demos. Add a Goal table row from",
        "  the distilled Production Recipe in `01`/`02`/`09`/`18` for",
        "  **code usage**. Do not copy `Official scripts/` OCR files, and",
        "  do not copy a demo's feature set as the freeze.",
        "- Uncurated folders starting with `_` are ignored (scratch tests).",
        "",
        "## Goal table",
        "",
        "| Goal | Card | Proven in | Evidence |",
        "|---|---|---|---|",
    ]
    for row in examples:
        lines.append(
            f"| {row['goal']} | `{row['id']}` | `{row['project']}` "
            f"(`{row['route_card']}`) | `{row['evidence']}` |"
        )
    lines.append("")
    for row in examples:
        lines.extend(
            [
                f"## {row['id']}",
                "",
                f"- Goal: {row['goal']}",
                f"- Keywords: {', '.join(f'`{item}`' for item in row['keywords'])}",
                f"- Identity: `{row['identity']}`",
                f"- Authority: {row['authority']}",
                f"- Evidence: `{row['evidence']}`",
                f"- Proven parser / ingest: `{row['parser_version']}`",
                f"- Do not: {'; '.join(row['do_not'])}",
            ]
        )
        if row["source_file"]:
            lines.append(f"- Source: `{row['source_file']}`")
        if row["pointers"]:
            joined = ", ".join(f"`{item}`" for item in row["pointers"])
            lines.append(f"- Pointers: {joined}")
        lines.append("")
        if row["code"]:
            if row["kind"] == "heading":
                lines.append(row["code"].rstrip())
                lines.append("")
            else:
                lines.append(fence(row["code"]))
                lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def build_bundle_examples() -> tuple[str, str]:
    registry = load_registry()
    validate_projects(registry)
    examples = [build_example(registry, spec) for spec in registry["examples"]]
    examples.sort(
        key=lambda row: 0 if row.get("evidence") == "official-bquant-app" else 1
    )
    md = render_markdown(examples)
    payload = {
        "schema_version": 1,
        "generated_by": "RAG KB/build_bundle_examples.py",
        "example_count": len(examples),
        "examples": [
            {
                **{key: value for key, value in row.items() if key != "code"},
                "code_sha256": hashlib.sha256(row["code"].encode()).hexdigest()[:16],
            }
            for row in examples
        ],
    }
    js = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    return md, js


def validate_generated_markdown(md: str) -> None:
    registry = load_registry()
    if "## Goal table" not in md:
        raise RuntimeError("BUNDLE_EXAMPLES.md missing Goal table")
    if "third highway" not in md:
        raise RuntimeError("BUNDLE_EXAMPLES.md missing highway disclaimer")
    if "product demo" not in md:
        raise RuntimeError("BUNDLE_EXAMPLES.md missing official-demo usage policy")
    for spec in registry["examples"]:
        if f"## {spec['id']}\n" not in md:
            raise RuntimeError(f"BUNDLE_EXAMPLES.md missing ## {spec['id']}")
